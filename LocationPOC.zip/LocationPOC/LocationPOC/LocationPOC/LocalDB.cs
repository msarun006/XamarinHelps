﻿using LocationPOC.Interface;
using SQLite;
using SQLite.Net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace LocationPOC
{
    public class LocalDB
    {
        private SQLiteConnection _sqlconnection;

        public LocalDB()
        {
            //Getting conection and Creating table  
            _sqlconnection = DependencyService.Get<ISQLite>().GetConnection();
            _sqlconnection.CreateTable<LocationModel>();
        }

        //Get all 
        public IEnumerable<LocationModel> GetAllLocation()
        {
            return (from t in _sqlconnection.Table<LocationModel>() select t).ToList();
        }

        //Get specific  
        //public LocationModel GetSingleLocation(int id)
        //{
        //    return _sqlconnection.Table<LocationModel>().FirstOrDefault(t => t.Id == id);
        //}

        //Delete specific 
        public void DeleteLocation(int id)
        {
            _sqlconnection.Delete<LocationModel>(id);
        }

        //Add new to DB  
        public void AddLocation(LocationModel location)
        {
            _sqlconnection.Insert(location);
        }
    }
}
