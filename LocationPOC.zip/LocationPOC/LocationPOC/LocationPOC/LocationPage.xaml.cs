﻿using Acr.UserDialogs;
using LocationPOC.Interface;
using Plugin.Connectivity;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace LocationPOC
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class LocationPage : ContentPage
    {
        IMyLocation loc;
        public LocationModel _locations;
        public LocalDB _localdb;
        public LocationPage()
        {
            InitializeComponent();

        }


        #region Button Click GetLocation
        private void btn_Clicked(object sender, EventArgs e)
        {
            //TimeSpan SetTime = new TimeSpan(0, 0, 20);

            lblLat.Text = string.Empty;
            lblLng.Text = string.Empty;
            StartTimer();
        }
        #endregion

        #region Timer Functionality
        private bool _isRunning;
        private TimeSpan TotalTime;
        private TimeSpan MakeTheTimeZero = TimeSpan.Zero;
        TimeSpan SetTime = new TimeSpan(0, 0, 20);
        TimeSpan InitialTime = new TimeSpan(0, 0, 0);
        private void StartTimer()
        {
            TotalTime = MakeTheTimeZero;
            _isRunning = true;
            RunTimer();
        }
        private void StopTimer()
        {
            _isRunning = false;
        }
        public async void RunTimer()
        {

            TimeSpan TimeElement = new TimeSpan();
            Device.StartTimer(new TimeSpan(0, 0, 1), () =>
            {


                TotalTime = TotalTime + TimeElement.Add(new TimeSpan(0, 0, 1));
                lblTimer.Text = string.Format("{0:hh\\:mm\\:ss}", TotalTime);          //Print the Timer
                if (TotalTime == SetTime)
                {
                    _isRunning = false;
                    GetLocation();
                    TotalTime = InitialTime;
                    _isRunning = true;

                }
                return _isRunning;
            });
        }
        #endregion

        #region GetLocation Functionality
        private async void GetLocation()
        {
            UserDialogs.Instance.ShowLoading("Getting Location...");
            loc = DependencyService.Get<IMyLocation>();
            IdentifyLocations = new ObservableCollection<ObtainedLocation>();
            loc.locationObtained += async (object sender,
                ILocationEventArgs e) =>
            {
                var lat = e.lat;
                var lng = e.lng;
                var isNetwotkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetwotkAvailable)
                {
                    IdentifyLocations.Add(new ObtainedLocation() { ObtainedLatitude = lat.ToString(), ObtainedLongitude = lng.ToString() });
                    if (IdentifyLocations.Count == 1)
                    {
                        string CurrentLatitude = lat.ToString();
                        string CurrentLongitude = lng.ToString();
                        await DisplayAlert("Alert", "Network is Connected", "Okey");
                        UserDialogs.Instance.Alert(CurrentLatitude, CurrentLongitude, "Okey");
                    }



                }

                else
                {

                    IdentifyLocations.Add(new ObtainedLocation() { ObtainedLatitude = lat.ToString(), ObtainedLongitude = lng.ToString() });
                    if (IdentifyLocations.Count == 1)
                    {
                        _locations = new LocationModel();
                        _localdb = new LocalDB();
                        lblLat.Text = lat.ToString();
                        lblLng.Text = lng.ToString();
                        _locations.SavedLatitude = lblLat.Text;
                        _locations.SavedLongitude = lblLng.Text;
                        _localdb.AddLocation(_locations);
                        await DisplayAlert("Alert", "Network is Unavailable saved in LocalDB", "Okey");
                        var savedLocations = _localdb.GetAllLocation();
                        LocationsList.ItemsSource = savedLocations;
                    }


                }
            };
            loc.ObtainMyLocation();
            UserDialogs.Instance.HideLoading();

        }
        #endregion

        #region Delete Item From Listview
        private async void ListView_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            var getuser = (LocationModel)e.SelectedItem;
            var location_ID = getuser.Id;
            bool accepted = await UserDialogs.Instance.ConfirmAsync("Are sure Delete this Location ", "", "Yes", "No");
            if (accepted)
            {
                _localdb = new LocalDB();
                _localdb.DeleteLocation(location_ID);
                UserDialogs.Instance.Toast("Location Deleted");
                _localdb = new LocalDB();
                var savedLocations = _localdb.GetAllLocation();
                LocationsList.ItemsSource = savedLocations;
            }
        }

        #endregion

        #region Observable collection with Class
        private ObservableCollection<ObtainedLocation> _identifyLocations;
        public ObservableCollection<ObtainedLocation> IdentifyLocations
        {
            get { return _identifyLocations; }
            set
            {
                if (_identifyLocations != value)
                {
                    _identifyLocations = value;
                    OnPropertyChanged();
                }
            }
        }
        public class ObtainedLocation
        {
            public string ObtainedLatitude { get; set; }
            public string ObtainedLongitude { get; set; }
        }
        #endregion
    }
}