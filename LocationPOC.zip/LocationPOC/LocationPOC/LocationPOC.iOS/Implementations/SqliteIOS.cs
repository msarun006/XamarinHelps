﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Foundation;
using UIKit;
using SQLite;
using System.IO;
using LocationPOC.iOS.Implementations;
using Xamarin.Forms;
using SQLite.Net;
using LocationPOC.Interface;

[assembly: Xamarin.Forms.Dependency(typeof(SqliteIOS))]
namespace LocationPOC.iOS.Implementations
{
    public class SqliteIOS : ISQLite
    {
        public SQLiteConnection GetConnection()
        {
            var fileName = "Locations.db3";
            var documentsPath = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            var libraryPath = Path.Combine(documentsPath, "..", "Library");
            var path = Path.Combine(libraryPath, fileName);

            var platform = new SQLite.Net.Platform.XamarinIOS.SQLitePlatformIOS();
            var connection = new SQLite.Net.SQLiteConnection(platform, path);

            return connection;
        }
    }
}