﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using LocationPOC.Interface;
using SQLite.Net;
using System.IO;
[assembly: Xamarin.Forms.Dependency(typeof(LocationPOC.Droid.Implementations.SqlLiteAndroid))]
namespace LocationPOC.Droid.Implementations
{
    class SqlLiteAndroid : ISQLite
    {
        public SQLiteConnection GetConnection()
        {
            var filename = "Locations.db3";
            var documentspath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);
            var path = Path.Combine(documentspath, filename);
            var platform = new SQLite.Net.Platform.XamarinAndroid.SQLitePlatformAndroid();
            var connection = new SQLite.Net.SQLiteConnection(platform, path);
            return connection;
        }
    }
}