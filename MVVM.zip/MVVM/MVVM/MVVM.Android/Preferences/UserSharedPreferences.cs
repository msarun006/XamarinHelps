﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using MVVM.Droid.Preferences;
using MVVM.Interfaces;

[assembly: Xamarin.Forms.Dependency(typeof(UserSharedPreferences))]
namespace MVVM.Droid.Preferences
{
    [Activity(Label = "UserPreferences")]
    class UserSharedPreferences : IUserPreferences
    {
        ISharedPreferences pref;

        public UserSharedPreferences()
        {
            pref = Application.Context.GetSharedPreferences("testsharedpreference", FileCreationMode.Private);
        }

        public void ClearPreferencesValueAndKey()
        {
            //  throw new NotImplementedException();
        }

        public string GetValue(string key)
        {

            string value = pref.GetString(key, string.Empty);
            return value;
        }

        public void SetValue(string key, string value)
        {
            // ISharedPreferences pref = Application.Context.GetSharedPreferences("testsharedpreference ", FileCreationMode.Private);
            ISharedPreferencesEditor edit = pref.Edit();
            edit.PutString(key, value);
            edit.Apply();
            edit.Commit();
        }
    }
}