﻿using System;
using Android.Content;
using Xamarin.Forms;
using Android.Locations;

using System.Threading.Tasks;
using Android.App;
using MVVM.Droid.Implementions;
using MVVM.Interfaces;

[assembly: Xamarin.Forms.Dependency(typeof(GetMyLocation))]

namespace MVVM.Droid.Implementions
{
    [Activity(Label = "GetMyLocation")]
    //public class LocationEventArgs : EventArgs, ILocationEventArgs
    //{
    //    public double lat { get; set; }
    //    public double lng { get; set; }
    //}

    //public class GetMyLocation : Java.Lang.Object,
    //                            IMyLocation,
    //                            ILocationListener
    //{
    //    LocationManager lm;
    //    public void OnProviderDisabled(string provider) { }
    //    public void OnProviderEnabled(string provider) { }
    //    public void OnStatusChanged(string provider,
    //        Availability status, Android.OS.Bundle extras)
    //    { }
    //    //---fired whenever there is a change in location---
    //    public void OnLocationChanged(Location location)
    //    {
    //        if (location != null)
    //        {
    //            LocationEventArgs args = new LocationEventArgs();
    //            args.lat = location.Latitude;
    //            args.lng = location.Longitude;
    //            locationObtained(this, args);
    //        };
    //    }
    //    //---an EventHandler delegate that is called when a location
    //    // is obtained---
    //    public event EventHandler<ILocationEventArgs>
    //        locationObtained;
    //    //---custom event accessor that is invoked when client
    //    // subscribes to the event---
    //    event EventHandler<ILocationEventArgs>
    //        IMyLocation.locationObtained
    //    {
    //        add
    //        {
    //            locationObtained += value;
    //        }
    //        remove
    //        {
    //            locationObtained -= value;
    //        }
    //    }
    //    //---method to call to start getting location---
    //    //public void ObtainMyLocation()
    //    //{

    //    //}

    //    public void ObtainMyLocation()
    //    {
    //        lm = (LocationManager)
    //            Forms.Context.GetSystemService(
    //                Context.LocationService);
    //        var GpsStatus = lm.IsProviderEnabled(LocationManager.GpsProvider);

    //        if (GpsStatus)
    //        {
    //            lm.RequestLocationUpdates(
    //            LocationManager.NetworkProvider,
    //                0,   //---time in ms---
    //                10,   //---distance in metres---
    //                this);

    //        }
    //        else
    //        {


    //        }

    //    }

    //    public bool IsGPSEnabled()
    //    {
    //        lm = (LocationManager)
    //          Forms.Context.GetSystemService(
    //              Context.LocationService);
    //        var GpsStatus = lm.IsProviderEnabled(LocationManager.GpsProvider);
    //        return GpsStatus;
    //    }

    //    public void EnableGPS()
    //    {
    //        String message = "Enable either GPS or any other location"
    //     + " service to find current location.  Click OK to go to"
    //     + " location services settings to let you do so.";
    //        //set alert for executing the task
    //        AlertDialog.Builder alert = new AlertDialog.Builder(Forms.Context);
    //        // alert.SetTitle("Location Services Not Active");
    //        alert.SetMessage(message);
    //        alert.SetPositiveButton("OK", (senderAlert, args) =>
    //        {
    //            Intent intent = new Intent(Android.Provider.Settings.ActionLocationSourceSettings);
    //            Forms.Context.StartActivity(intent);
    //        });

    //        alert.SetNegativeButton("CANCEL", (senderAlert, args) =>
    //        {

    //        });

    //        Dialog dialog = alert.Create();
    //        dialog.Show();
    //    }
    //        //---stop the location update when the object is set to
    //        // null---
    //        ~GetMyLocation()
    //    {
    //        lm.RemoveUpdates(this);
    //    }
    //}

    public class LocationEventArgs : EventArgs, ILocationEventArgs
    {
        public double lat { get; set; }
        public double lng { get; set; }
    }

    public class GetMyLocation : Java.Lang.Object,
                                IMyLocation,
                                ILocationListener
    {
        LocationManager lm;
        public void OnProviderDisabled(string provider) { }
        public void OnProviderEnabled(string provider) { }
        public void OnStatusChanged(string provider,
            Availability status, Android.OS.Bundle extras)
        { }
        //---fired whenever there is a change in location---
        public void OnLocationChanged(Location location)
        {
            if (location != null)
            {
                LocationEventArgs args = new LocationEventArgs();
                args.lat = location.Latitude;
                args.lng = location.Longitude;
                locationObtained(this, args);
            };
        }
        //---an EventHandler delegate that is called when a location
        // is obtained---
        public event EventHandler<ILocationEventArgs>
            locationObtained;
        //---custom event accessor that is invoked when client
        // subscribes to the event---
        event EventHandler<ILocationEventArgs>
            IMyLocation.locationObtained
        {
            add
            {
                locationObtained += value;
            }
            remove
            {
                locationObtained -= value;
            }
        }
        //---method to call to start getting location---
        public void ObtainMyLocation()
        {
            lm = (LocationManager)
                Forms.Context.GetSystemService(
                    Context.LocationService);
            lm.RequestLocationUpdates(
                LocationManager.NetworkProvider,
                    0,   //---time in ms---
                    0,   //---distance in metres---
                    this);
        }

        public bool IsGPSEnabled()
        {
            lm = (LocationManager)
              Forms.Context.GetSystemService(
                  Context.LocationService);
            var GpsStatus = lm.IsProviderEnabled(LocationManager.GpsProvider);
            return GpsStatus;
        }

        public void EnableGPS()
        {
            String message = "Enable Location and MAKE it as"
           + "  HIGH ACCURACY MODE.  Click OK to goto"
           + " Location Services Settings";
            //set alert for executing the task
            AlertDialog.Builder alert = new AlertDialog.Builder(Forms.Context);
            // alert.SetTitle("Location Services Not Active");
            alert.SetMessage(message);
            alert.SetPositiveButton("OK", (senderAlert, args) =>
            {
                Intent intent = new Intent(Android.Provider.Settings.ActionLocationSourceSettings);
                Forms.Context.StartActivity(intent);
            });

            alert.SetNegativeButton("CANCEL", (senderAlert, args) =>
            {

            });

            Dialog dialog = alert.Create();
            dialog.Show();
        }
        //---stop the location update when the object is set to
        // null---
        ~GetMyLocation()
        {
            lm.RemoveUpdates(this);
        }
    }
}