﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

using MVVM.Droid.Implementions;
using Xamarin.Forms;

[assembly: Dependency(typeof(CameraProvider))]

namespace MVVM.Droid.Implementions
{
  
     using System;
    using System.Threading.Tasks;

    using Android.App;
    using Android.Content;
    using Android.Provider;
    using Java.IO;

    using Environment = Android.OS.Environment;
    using Uri = Android.Net.Uri;
    using Utilities;
    using Xamarin.Forms;
    using Interfaces;

  

    public class CameraProvider : ICameraProvider
    {
        private static File file;
        private static File pictureDirectory;

        private static TaskCompletionSource<CameraResult> tcs; 

        public Task<CameraResult> TakePictureAsync()
        {
            Intent intent = new Intent(MediaStore.ActionImageCapture);

            pictureDirectory = new File(Environment.GetExternalStoragePublicDirectory(Environment.DirectoryPictures), "CameraAppDemo");

            if (!pictureDirectory.Exists())
            {
                pictureDirectory.Mkdirs();
            }

            file = new File(pictureDirectory, String.Format("photo_{0}.jpg", Guid.NewGuid()));
            AppSessionData._file = file;
            intent.PutExtra(MediaStore.ExtraOutput, Uri.FromFile(file));

            var activity = (Activity)Forms.Context;
            activity.StartActivityForResult(intent, 1);

            tcs = new TaskCompletionSource<CameraResult>();

            return tcs.Task;
        }

        public static void OnResult(Uri CroppedImage)
        {
            //if (resultCode == Result.Canceled)
            //{
            //    tcs.TrySetResult(null);
            //    return;
            //}

            //if (resultCode != Result.Ok)
            //{
            //    tcs.TrySetException(new Exception("Unexpected error"));
            //    return;
            //}

            CameraResult res = new CameraResult();
            res.Picture = ImageSource.FromFile(CroppedImage.Path);
            res.FilePath = CroppedImage.Path;
            res.ImageByteArray = System.IO.File.ReadAllBytes(CroppedImage.Path);
            tcs.TrySetResult(res);
        }
    }
}