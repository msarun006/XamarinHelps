﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using MVVM.Interfaces;
using Xamarin.Forms;
using MVVM.Utilities;
using Amazon.S3.Model;
using System.Threading.Tasks;
using Amazon.S3;

[assembly: Dependency(typeof(MVVM.Droid.Implementions.FileManager))]
namespace MVVM.Droid.Implementions
{
    [Activity(Label = "FileManager")]
    public class FileManager : IFileManager
    {
        public void DeleteImage(string filePath)
        {
            try
            {
                System.IO.File.Delete(filePath);
            }
            catch (Exception ex)
            {


            }
        }
        #region download_file_from S3
        async public Task<string> DownloadFile(string filename, string BucketName)
        {

            var S3Client = S3Utils.S3Client;
            string responseBody = "false";
            string path = Android.OS.Environment.GetExternalStoragePublicDirectory(Android.OS.Environment.DirectoryDownloads).AbsolutePath;
            string avatarFilepath = System.IO.Path.Combine(path, filename);
            if (System.IO.File.Exists(avatarFilepath))
            {
                //                GC.Collect();
                return avatarFilepath;
            }
            else
            {
                var request = new GetObjectRequest
                {
                    BucketName = BucketName,
                    Key = filename
                };
                try
                {
                    using (GetObjectResponse response = await S3Client.GetObjectAsync(request))
                    {
                        await response.WriteResponseStreamToFileAsync(avatarFilepath, true);
                        responseBody = avatarFilepath;
                        return responseBody;
                    }
                    //using (var response = await S3Client.GetObjectAsync(request))
                    //{

                    //    await response.WriteResponseStreamToFileAsync(avatarFilepath, true);
                    //    responseBody = avatarFilepath;
                    //}
                }
#pragma warning disable CS0168 // The variable 's3Exception' is declared but never used
                catch (AmazonS3Exception s3Exception)
#pragma warning restore CS0168 // The variable 's3Exception' is declared but never used
                {
                    responseBody = "user.png";
                    return responseBody;
                }
            }
        }
        #endregion
    }
}