﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.App;
using System;

namespace MVVM.Droid.CropImageServices
{
    [Activity(Label = "MonitoredActivity")]
    public class MonitoredActivity : Activity
    {
        #region IMonitoredActivity implementation

        public event EventHandler Destroying;
        public event EventHandler Stopping;
        public event EventHandler Starting;

        #endregion

        protected override void OnDestroy()
        {
            base.OnDestroy();

            if (Destroying != null)
            {
                Destroying(this, EventArgs.Empty);
            }
        }

        protected override void OnStop()
        {
            base.OnStop();

            if (Stopping != null)
            {
                Stopping(this, EventArgs.Empty);
            }
        }

        protected override void OnStart()
        {
            base.OnStart();

            if (Starting != null)
            {
                Starting(this, EventArgs.Empty);
            }
        }
    }
}