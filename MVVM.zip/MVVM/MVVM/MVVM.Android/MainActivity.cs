﻿using System;

using Android.App;
using Android.Content.PM;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
namespace MVVM.Droid
{
    using Acr.UserDialogs;
    using Android.Content;
    using Android.Graphics;
    using Android.Locations;
    using Android.Net;
    using Android.Provider;
    using CropImageServices;
    using GalaSoft.MvvmLight.Views;
    using Implementions;
    using Interfaces;
    using Java.IO;
    using Splat;
    using Utilities;
    using Views;
    using Xamarin.Forms;


    [Activity(Label = "MVVM", Icon = "@drawable/icon", Theme = "@style/MainTheme", MainLauncher = false, ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class MainActivity : global::Xamarin.Forms.Platform.Android.FormsAppCompatActivity
    {
        private static File pictureDirectory;
        private Uri mCropImagedUri;
        private int CROP_IMAGE = 100;
        private File newfile;
        protected override void OnCreate(Bundle bundle)
        {
            RequestWindowFeature(WindowFeatures.ActionBar);
            TabLayoutResource = Resource.Layout.Tabbar;
            ToolbarResource = Resource.Layout.Toolbar;
            base.OnCreate(bundle);
            Forms.Init(this, bundle);
            Xamarin.FormsMaps.Init(this, bundle);
            //UserDialogs.Init(this);
            UserDialogs.Init(() => (Activity)Forms.Context);

            //Interfaces.INavigation_Service navService = new Navigation_Service();
            //navService.RegisterViewModels(typeof(LoginPage).Assembly);

            //Locator.CurrentMutable.RegisterConstant(navService, typeof(INavigation_Service));
            LoadApplication(new App());
        }

        protected override void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            base.OnActivityResult(requestCode, resultCode, data);
            if (resultCode == Result.Ok)
            {
                if (resultCode == Result.Ok)
                {
                    if (requestCode == 1)
                    {
                        mCropImagedUri = Uri.FromFile(AppSessionData._file);
                        //get the Uri for the captured image

                        //carry out the crop operation
                        performCropImage(mCropImagedUri);


                    }
                    if (requestCode == 3)
                    {

                        CameraProvider.OnResult(mCropImagedUri);
                        //CroppingImageServices.CanGetURL = true;
                    }
                }

            }

        }
        private bool performCropImage(Uri mFinalImageUri)
        {
            try
            {
                if (mFinalImageUri != null)
                {
                    Intent cropIntent = new Intent(this, typeof(CropImage));
                    cropIntent.PutExtra("image-path", mFinalImageUri.Path);
                    cropIntent.PutExtra("scale", true);
                    //start the activity - we handle returning in onActivityResult
                    StartActivityForResult(cropIntent, 3);
                    return true;
                }
            }
            catch (ActivityNotFoundException anfe)
            {

                return false;
            }
            return false;
        }

        private File createNewFile(String prefix)
        {

            pictureDirectory = new File(Android.OS.Environment.GetExternalStoragePublicDirectory(Android.OS.Environment.DirectoryPictures), "BOI-APP");

            if (!pictureDirectory.Exists())
            {
                pictureDirectory.Mkdirs();
            }
            File file = new File(pictureDirectory, (prefix + System.DateTime.Now.Ticks.ToString() + ".jpg"));
            if (file.Exists())
            {
                //this wont be executed
                file.Delete();
                try
                {
                    file.CreateNewFile();
                }
                catch (IOException e)
                {

                }
            }

            return file;
        }
        private void performCrop(Android.Net.Uri picUri)
        {
            try
            {


                //call the standard crop action intent (the user device may not support it)
                Intent cropIntent = new Intent("com.android.camera.action.CROP");
                //indicate image type and Uri
                cropIntent.SetDataAndType(picUri, "image/*");
                //set crop properties
                cropIntent.PutExtra("crop", "true");
                //indicate aspect of desired crop
                cropIntent.PutExtra("aspectX", 1);
                cropIntent.PutExtra("aspectY", 1);
                //indicate output X and Y
                cropIntent.PutExtra("outputX", 256);
                cropIntent.PutExtra("outputY", 256);
                //retrieve data on return
                cropIntent.PutExtra("return-data", true);
                //start the activity - we handle returning in onActivityResult
                StartActivityForResult(cropIntent, 3);

            }
            catch (ActivityNotFoundException anfe)
            {
                //display an error message
                //String errorMessage = "Whoops - your device doesn't support the crop action!";
                //Toast toast = Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT);
                //toast.show();
            }
        }


        public void CheckGpsStatus()
        {

            var locationManager = (LocationManager)this.ApplicationContext.GetSystemService(Context.LocationService);

            var GpsStatus = locationManager.IsProviderEnabled(LocationManager.GpsProvider);

            if (!GpsStatus)
            {
                String message = "Enable Location and MAKE IT as"
           + "  HIGH ACCURACY MODE.  Click OK to goto"
           + " Location Services Settings";
                //set alert for executing the task


                AlertDialog.Builder alert = new AlertDialog.Builder(this);
                //alert.SetTitle("Location Services Not Active");
                alert.SetMessage(message);
                alert.SetPositiveButton("OK", (senderAlert, args) => {
                    Intent intent = new Intent(Settings.ActionLocationSourceSettings);
                    StartActivity(intent);
                });

                alert.SetNegativeButton("CANCEL", (senderAlert, args) => {

                });

                Dialog dialog = alert.Create();
                dialog.Show();



            }


        }



    }
    public static class AppSessionData
    {
        public static Java.IO.File _file;

    }
}

