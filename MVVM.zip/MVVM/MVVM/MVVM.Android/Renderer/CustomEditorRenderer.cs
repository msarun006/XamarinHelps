﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using MVVM.Renderer;
using MVVM.Droid.Renderer;
using Android.Content.Res;
using Android.Graphics.Drawables;
using Xamarin.Forms.Platform.Android;
using Android.Graphics;
using Xamarin.Forms;

[assembly: ExportRenderer(typeof(CustomEditor), typeof(CustomEditorRenderer))]
namespace MVVM.Droid.Renderer
{
    [Activity(Label = "CustomEditorRenderer")]
    public class CustomEditorRenderer : Xamarin.Forms.Platform.Android.EditorRenderer
    {
        protected override void OnElementChanged(ElementChangedEventArgs<Editor> e)
        {


            base.OnElementChanged(e);
            if (Control != null)
            {
                Control.SetHintTextColor(ColorStateList.ValueOf(global::Android.Graphics.Color.Gray));
                Control.SetBackgroundDrawable(null);
            }
            if (e.OldElement == null)
            {
                var nativeEditText = (global::Android.Widget.EditText)Control;
                var shape = new ShapeDrawable(new Android.Graphics.Drawables.Shapes.RectShape());
                shape.Paint.Color = Xamarin.Forms.Color.Black.ToAndroid();
                shape.Paint.SetStyle(Paint.Style.Stroke);
                nativeEditText.Background = shape;
            }



            //base.OnElementChanged(e);
            //if (Control != null)
            //{
            //    Control?.SetBackgroundResource(Resource.Drawable.CustomEditor);
            //}
        }
    }
}