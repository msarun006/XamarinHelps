﻿using MvvmHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace MVVM.ViewModels
{
    public class FullSizeImageViewModel : BaseViewModel
    {
        public FullSizeImageViewModel(ImageSource image ,string pagetitle)
        {
            Title = pagetitle;
            FullSizeIMage = image;
        }
        private ImageSource _fullSizeIMage;

        public ImageSource FullSizeIMage
        {
            get { return _fullSizeIMage; }
            set
            {
                if (value == _fullSizeIMage) return;
                _fullSizeIMage = value;
                OnPropertyChanged();

            }
        }
        private string _title;

        public string Title
        {
            get { return _title; }
            set
            {
                if (value == _title) return;
                _title = value;
                OnPropertyChanged();

            }
        }
    }
}
