﻿using MVVM.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;
using Acr.UserDialogs;
using MVVM.Services;
using MVVM.Preferences;
using MVVM.Interfaces;
using MVVM.Models;
using MvvmHelpers;
using GalaSoft.MvvmLight.Command;

namespace MVVM.ViewModels
{
    public class AuthLetterViewModel : BaseViewModel
    {

        public ICommand OnAuthorizatonLetterPageCommand { get; set; }

        INavigation nav;
        public AuthLetterViewModel(INavigation objNav)
        {
            nav = objNav;
            GetS3BucketDetails();
            OnAuthorizatonLetterPageCommand = new RelayCommand<string>(OnAuthorizationLetterPage);
            IsProceedButtonEnabled = true;
            ImageAuthorizationLetter = "letter.png";
        }

        private async void OnAuthorizationLetterPage(string sender)
        {

            switch (sender)
            {

                case "DoLogout":
                    bool status = await App.dialog.ShowAlertOKCancel("Are sure to Logout");
                    if (status)
                    {
                        App.Current.MainPage = new NavigationPage(new LoginPage());
                    }
                    break;

                case "DoLetterFullSize":
                    string fullSizeTitle = "BOI Authorization Letter";
                    await nav.PushAsync(new AuthFullIMage(ImageAuthorizationLetter, fullSizeTitle));
                    break;

                case "DoProceed":
                    IsProceedButtonEnabled = false;
                    UserDialogs.Instance.ShowLoading("Please wait...");
                    await Task.Delay(1000);
                    await nav.PushAsync(new FindCustomer());
                    UserDialogs.Instance.HideLoading();
                    break;
            }
        }

        private async void GetS3BucketDetails()
        {
            try
            {
                await Task.Delay(500);
                UserDialogs.Instance.ShowLoading("Loading...");
                var objHttpCommonService = new HttpCommonService();

                var result = await objHttpCommonService.GetAsync<S3BucketDetails>(AppSessionData.APIBaseURL + "api/bucket-details");
                if (result.code == 200)
                {
                    AppSessionData.S3Data = result.data;
                    await OnDownloadFileS3();
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                UserDialogs.Instance.HideLoading();
            }
        }
        private async Task OnDownloadFileS3()
        {
            if (AppPreferences.AuthorizationData == string.Empty)
            {
                AppPreferences.AuthorizationData = await DependencyService.Get<IFileManager>().DownloadFile("BOIAuthorizationLetter.jpg", AppSessionData.S3Data.bucketname);
            }
            ImageAuthorizationLetter = AppPreferences.AuthorizationData;

        }

    #region INotify Event Image Binding
        private ImageSource imageAuthorizationLetter;

        public ImageSource ImageAuthorizationLetter
        {
            get { return imageAuthorizationLetter; }
            set
            {
                if (value == imageAuthorizationLetter) return;
                imageAuthorizationLetter = value;
                OnPropertyChanged();

            }
        }

        private bool _isProceedButtonEnabled;

        public bool IsProceedButtonEnabled
        {
            get
            {
                return _isProceedButtonEnabled;
            }
            set
            {
                _isProceedButtonEnabled = value;
                OnPropertyChanged();
            }
        }
        #endregion

    }
}
