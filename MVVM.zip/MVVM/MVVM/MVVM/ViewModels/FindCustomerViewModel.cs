﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Views;
using MVVM.ApiData;
using MVVM.Interfaces;
using MVVM.Models;
using MVVM.Renderer;
using MVVM.Services;
using MVVM.Utilities;
using MVVM.Views;
using MvvmHelpers;
using Plugin.Media;
using Plugin.Media.Abstractions;
using Splat;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;
using static MVVM.ApiData.StatusResponse;

namespace MVVM.ViewModels
{
    public class FindCustomerViewModel : BaseViewModel
    {
        #region Declarations
        public byte[] FrontImageByte;
        public byte[] BackImageByte;
        public byte[] ConsentImageByte;
        private string CustomerArea;
        private string CustomerCity;
        private string CustomerState;
        private string CustomerPincode;

        public IdentityStatus item;
        private IdentityStatus _selStatus;
        public Picker obj;
        IMyLocation loc;
        bool isLocationEnabled = false;
        private ICameraProvider _cameraProvider;
        INavigation nav;
        #endregion

        #region  Commands Interface
        public ICommand OnFindCustomerPageCommand { get; set; }
        public ICommand SelectedStatusChanged { get; private set; }
    
        #endregion

        public FindCustomerViewModel(ICameraProvider cameraProvider, INavigation objNav)
        {
            if (cameraProvider == null)
            {
                throw new ArgumentNullException("cameraProvider");
            }
            this._cameraProvider = cameraProvider;
            nav = objNav;

            #region Commands Initialize & Assign

            OnFindCustomerPageCommand = new RelayCommand<string>(OnFindCustomerPage);
         
            SelectedStatusChanged = new Command(DoStatusComplete);
            #endregion

            #region startup page clear
            StatusName = "Select Status";
            FrontImageByte = null;
            BackImageByte = null;
            ConsentImageByte = null;
            IsFieldsEnabled = false;
            IsImageLayoutVisible = false;
            IsClearButtonEnabled = false;
            IsConfirmButtonEnabled = false;
            IsGetButtonEnabled = true;
            ImageFront = "landscape.png";
            ImageBack = "landscape.png";
            ImageConsent = "landscape.png";
            #endregion

        }

        private async void OnFindCustomerPage(string sender)
        {
            switch (sender)
            {

                case "DoShowAuthorizationLetter":
                    bool letterStatus = await App.dialog.ShowAlertOKCancel("Do you Want to See the Authorization Letter");
                    if (letterStatus)
                    {
                        try
                        {
                          App.Current.MainPage = new NavigationPage(new AuthorizationLetterPage());
                        }
                        catch(Exception ex)
                        {

                        }
                    }
                    break;
                case "DoLogout":
                    bool logStatus = await App.dialog.ShowAlertOKCancel("Are sure to Logout");
                    if (logStatus)
                    {
                        App.Current.MainPage = new NavigationPage(new LoginPage());
                    }
                    break;

                case "DoGetDetails":
                    #region GetDetailsFunction      
                       CustomerName = "";
                        CustomerMobile = "";
                        CustomerAddress = "";
                        CustomerComment = "";
                        StatusName = "Select Status";
                        item = null;
                        FrontImageByte = null;
                        BackImageByte = null;
                        ConsentImageByte = null;
                        IsImageLayoutVisible = false;
                        IsFieldsEnabled = true;
                        ImageFront = "landscape.png";
                        ImageBack = "landscape.png";
                        ImageConsent = "landscape.png";
                        lblLatitude = "";
                        lblLongitude = "";
                     
                    if (string.IsNullOrEmpty(CustomerID))
                    {
                        UserDialogs.Instance.Alert("Enter Customer ID", "Alert", "ok");
                        
                        return;
                    }
                    if (!CheckGPS())
                    {
                        UserDialogs.Instance.Alert("Enable GPS or Location Service", "Alert", "ok");
                       
                        return;
                    }

                    else
                    {
                        try
                        {
                            IsGetButtonEnabled = false;
                            UserDialogs.Instance.ShowLoading("Loading Details");
                            var objHttpCommonService = new HttpCommonService();
                            string customerid = CustomerID;
                            var result = await objHttpCommonService.GetAsync<GetDetailsResponseData>(AppSessionData.APIBaseURL + "api/clients?client_id=" + customerid);
                            if (result.code == 200)
                            {
                                if (result.data != null)
                                {
                                    CustomerName = result.data.name;
                                    CustomerMobile = result.data.comu_phone_num_1;
                                    CustomerAddress = result.data.address;
                                    CustomerArea = result.data.area;
                                    CustomerCity = result.data.city;
                                    CustomerState = result.data.state;
                                    CustomerPincode = result.data.pincode;
                                    IsClearButtonEnabled = true;
                                    var pickerlist = new List<StatusResponse.StatusDetails>();
                                    IdentifyStatusList = new ObservableCollection<IdentityStatus>();
                                    var pickerresult = await objHttpCommonService.GetAsync<StatusResponse>(AppSessionData.APIBaseURL + "api/clients-status");
                                    if (pickerresult.code == 200)
                                    {
                                        if (pickerresult.data != null)
                                        {
                                            for (int i = 0; i < pickerresult.data.Count(); i++)
                                            {
                                                IdentifyStatusList.Add(new IdentityStatus() { Description = pickerresult.data[i].name, ID = pickerresult.data[i].id.ToString() });
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    UserDialogs.Instance.HideLoading();
                                    IsGetButtonEnabled = true;
                                    UserDialogs.Instance.Alert(result.message.ToString(), "", "Ok");
                                 
                                }
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                IsGetButtonEnabled = true;
                                UserDialogs.Instance.Alert(result.message.ToString(), "", "Ok");
                            
                            }
                        }

                        catch (System.Reflection.TargetInvocationException et) { IsGetButtonEnabled = true; }

                        catch (Exception ex) { IsGetButtonEnabled = true; }

                        finally
                        {
                            UserDialogs.Instance.HideLoading();
                            IsGetButtonEnabled = true;
                        }
                    }
                    #endregion
                    break;

                case "OpenMap":
                    if (string.IsNullOrEmpty(CustomerName))
                    {
                        UserDialogs.Instance.Alert("Choose Customer ID and can Access the Customer Location", "Alert", "OK");
                    }
                    else
                    {
                        await nav.PushAsync(new MapPage(CustomerArea,CustomerCity,CustomerPincode,CustomerState));
                    }
                        break;
                case "DoFrontImageFullSize":
                    if (FrontImageByte != null)
                    {
                        string frontImageTitle = "AADHAAR Front Image";
                        await nav.PushAsync(new FullSizeImage(ImageFront, frontImageTitle));
                    }
                    break;
                case "DoBackImageFullSize":
                    if (BackImageByte != null)
                    {
                        string backImageTitle = "AADHAAR Back Image";
                        await nav.PushAsync(new FullSizeImage(ImageBack, backImageTitle));
                    }
                  
                    break;
                case "DoConsentImageFullSize":
                    if (ConsentImageByte != null)
                    {
                        string consentLetterTitle = "Consent Letter";
                        await nav.PushAsync(new FullSizeImage(ImageConsent, consentLetterTitle));
                    }
                  
                    break;


                case "OnTakeFrontImage":
                    var frontImageResult = await _cameraProvider.TakePictureAsync();
                    if (frontImageResult != null)
                    {
                        ImageFront = frontImageResult.Picture;

                        if (ImageFront == null)
                            return;
                        FrontImageByte = frontImageResult.ImageByteArray;
                    }
                    break;


                case "OnTakeBackImage":
                    var backImageResult = await _cameraProvider.TakePictureAsync();
                    if (backImageResult != null)
                    {
                        ImageBack = backImageResult.Picture;
                        BackImageByte = backImageResult.ImageByteArray;
                    }
                    break;

                case "OnTakeConsentImage":
                    var consentImageResult = await _cameraProvider.TakePictureAsync();
                    if (consentImageResult != null)
                    {
                        ImageConsent = consentImageResult.Picture;
                        ConsentImageByte = consentImageResult.ImageByteArray;
                    }
                    break;

                case "DoConfirm":
                    #region Confirm Details
                    if (string.IsNullOrEmpty(CustomerID))
                    {
                        UserDialogs.Instance.Alert("Enter Customer ID", "Alert", "ok");
                        return;
                    }
                    else if (StatusName == "Select Status")
                    {
                        UserDialogs.Instance.Alert("Select Status", "Alert", "ok");
                        return;
                    }

                    else if (string.IsNullOrEmpty(lblLatitude) && string.IsNullOrEmpty(lblLongitude))
                    {
                        UserDialogs.Instance.ShowLoading("Please wait Getting Current Location... ");
                        CheckGPS();
                        await Task.Delay(15000);
                        UserDialogs.Instance.HideLoading();
                        return;
                    }

                    else
                    {
                        if (item.Description == "Completed")
                        {
                            if (ImageFront != null || ImageBack != null)

                            {
                                if (FrontImageByte == null || BackImageByte == null)
                                {
                                    UserDialogs.Instance.Alert("Capture AADHAAR Front and Back Image", "Alert", "ok");
                                    return;
                                }
                            }
                            else
                            {
                                UserDialogs.Instance.Alert("Capture AADHAAR Front and Back Image", "Alert", "ok");
                                return;
                            }


                            UserDialogs.Instance.Toast("Current Location Obtained",1);

                            string _statusName = item.Description;
                            int statusId = Convert.ToInt32(item.ID);
                            string id = CustomerID;
                            string _customerName = CustomerName;
                            string _customerMobile = CustomerMobile;
                            string _customerAddress = CustomerAddress;
                            string _customerComment = CustomerComment;
                            string _latitude = lblLatitude;
                            string langtitude = lblLongitude;
                            byte[] imgFront = FrontImageByte;
                            byte[] imgBack = BackImageByte;
                            byte[] imgConsent = ConsentImageByte;
                            await nav.PushAsync(new CustomerDetails(id, _customerName, _customerMobile, _customerAddress, _customerComment, _latitude, langtitude, statusId, _statusName, imgFront, imgBack, imgConsent));
                        }
                        else
                        {
                            UserDialogs.Instance.Toast("Current Location Obtained",1);

                            string _statusName = item.Description;
                            int statusId = Convert.ToInt32(item.ID);
                            string id = CustomerID;
                            string _customerName = CustomerName;
                            string _customerMobile = CustomerMobile;
                            string _customerAddress = CustomerAddress;
                            string _customerComment = CustomerComment;
                            string lat = lblLatitude;
                            string lng = lblLongitude;
                            await nav.PushAsync(new CustomerDetails(id, _customerName, _customerMobile, _customerAddress, _customerComment, lat, lng, statusId, _statusName));
                        }
                    }
                        #endregion
                        break;


                case "DoClearFields":
                    #region Clear Fields
                    try
                    {
                        Device.BeginInvokeOnMainThread(() => {
                            if (IdentifyStatusList != null)
                            {
                                IdentifyStatusList.Clear();
                            }
                          
                            IsConfirmButtonEnabled = false;
                            CustomerID = "";
                            CustomerName = "";
                            CustomerMobile = "";
                            CustomerAddress = "";
                            CustomerComment = "";
                            StatusName = "Select Status";
                            FrontImageByte = null;
                            BackImageByte = null;
                            ConsentImageByte = null;
                            IsImageLayoutVisible = false;
                            ImageFront = "landscape.png";
                            ImageBack = "landscape.png";
                            ImageConsent = "landscape.png";
                            lblLatitude = "";
                            lblLongitude = "";
                            IsClearButtonEnabled = false;
                        });
                    }
                    catch (Exception ex)
                    {
                        App.dialog.ShowAlert("Fields are Empty");
                    }
                    #endregion
                  break;
          
            }

        }

        private void DoStatusComplete(object obj)
        {
          
               var picker = (Picker)obj;
            item = (IdentityStatus)picker.SelectedItem;
            if (item != null)
            {
                StatusName = item.Description;
                if (item.Description == "Completed")
                {
                    IsImageLayoutVisible = true;
                    IsConfirmButtonEnabled = true;
                }
                else
                {
                    IsImageLayoutVisible = false;
                    IsConfirmButtonEnabled = true;
                }
            }
        }

        #region INotify Events

        #region Binding Data

        private string _customerId;
        public string CustomerID
        {
            get { return _customerId; }
            set
            {
                if (value == _customerId) return;
                _customerId = value;
                OnPropertyChanged();
            }
        }

        private string _customerComment;
        public string CustomerComment
        {
            get { return _customerComment; }
            set
            {
                if (value == _customerComment) return;
                _customerComment = value;
                OnPropertyChanged();
            }
        }

        private string _customerName;
        public string CustomerName
        {
            get { return _customerName; }
            set
            {
                if (value == _customerName) return;
                _customerName = value;
                OnPropertyChanged();
            }
        }

        private string _customerMobile;
        public string CustomerMobile
        {
            get { return _customerMobile; }
            set
            {
                if (value == _customerMobile) return;
                _customerMobile = value;
                OnPropertyChanged();
            }
        }
        private string _customerAddress;
        public string CustomerAddress
        {
            get { return _customerAddress; }
            set
            {
                if (value == _customerAddress) return;
                _customerAddress = value;
                OnPropertyChanged();
            }
        }

        private string _customerStatus;
        public string CustomerStatus
        {
            get { return _customerStatus; }
            set
            {
                if (value == _customerStatus) return;
                _customerStatus = value;
                OnPropertyChanged();
            }
        }
        private string _statusName;
        public string StatusName
        {
            get { return _statusName; }
            set
            {
                if (value == _statusName) return;
                _statusName = value;
                OnPropertyChanged();
            }
        }

        private string _latitude;
        public string lblLatitude
        {
            get { return _latitude; }
            set
            {
                if (value == _latitude) return;
                _latitude = value;
                OnPropertyChanged();
            }
        }
        private string _lontitude;
        public string lblLongitude
        {
            get { return _lontitude; }
            set
            {
                if (value == _lontitude) return;
                _lontitude = value;
                OnPropertyChanged();
            }
        }

        private bool _isClearButtonEnabled;

        public bool IsClearButtonEnabled
        {
            get
            {
                return _isClearButtonEnabled;
            }
            set
            {
                _isClearButtonEnabled = value;
                OnPropertyChanged();
            }
        }
        private bool _isConfirmButtonEnabled;

        public bool IsConfirmButtonEnabled
        {
            get
            {
                return _isConfirmButtonEnabled;
            }
            set
            {
                _isConfirmButtonEnabled = value;
                OnPropertyChanged();
            }
        }



        

              private bool _isGetButtonEnabled;

        public bool IsGetButtonEnabled
        {
            get
            {
                return _isGetButtonEnabled;
            }
            set
            {
                _isGetButtonEnabled = value;
                OnPropertyChanged();
            }
        }



        #endregion

        #region Image Source Binding
        private ImageSource _imageFront;
        public ImageSource ImageFront
        {
            get
            { return this._imageFront; }
            set
            {
                if (Equals(value, this._imageFront))
                { return; }
                this._imageFront = value;
                OnPropertyChanged();
            }
        }

        private ImageSource _imageBack;
        public ImageSource ImageBack
        {
            get
            { return this._imageBack; }
            set
            {
                if (Equals(value, this._imageBack))
                { return; }
                this._imageBack = value;
                OnPropertyChanged();
            }
        }
        private ImageSource _imageConsent;
        public ImageSource ImageConsent
        {
            get
            { return this._imageConsent; }
            set
            {
                if (Equals(value, this._imageConsent))
                { return; }
                this._imageConsent = value;
                OnPropertyChanged();
            }
        }
        private bool _isImageLayoutVisible;

        public bool IsImageLayoutVisible
        {
            get
            {
                return _isImageLayoutVisible;
            }
            set
            {
                _isImageLayoutVisible = value;
                OnPropertyChanged("IsImageLayoutVisible");
            }
        }

        private bool _isFieldsEnabled;

        public bool IsFieldsEnabled
        {
            get
            {
                return _isFieldsEnabled;
            }
            set
            {
                _isFieldsEnabled = value;
                OnPropertyChanged("IsFieldsEnabled");
            }
        }

        #endregion

        #region observable Collection
        private ObservableCollection<IdentityStatus> _identifyStatusList;
        public ObservableCollection<IdentityStatus> IdentifyStatusList
        {
            get { return _identifyStatusList; }
            set
            {
                if (_identifyStatusList != value)
                {
                    _identifyStatusList = value;
                    OnPropertyChanged();
                }
            }
        }

        #endregion

        #endregion

      
        private bool CheckGPS()
        {

            bool returnValue;
            loc = DependencyService.Get<IMyLocation>();
            if (loc.IsGPSEnabled())
            {
                isLocationEnabled = true;
                returnValue = true;

                if (isLocationEnabled)
                {

                    loc.locationObtained += (object s,
                       ILocationEventArgs e) =>
                    {

                        var lat = e.lat;
                        var lng = e.lng;
                        lblLatitude = lat.ToString();
                        lblLongitude = lng.ToString();

                    };
                    loc.ObtainMyLocation();
                }
            }
            else
            {
                returnValue = false;
                loc.EnableGPS();


            }
            return returnValue;
        }
    }
    public class IdentityStatus
    {
        public string ID { get; set; }
        public string Description { get; set; }

    }


}
