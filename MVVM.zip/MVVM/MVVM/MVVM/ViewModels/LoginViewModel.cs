﻿using Acr.UserDialogs;
using MVVM.ApiData;
using MVVM.Interfaces;
using MVVM.Models;
using MVVM.Services;
using MVVM.Views;
using MvvmHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace MVVM.ViewModels
{
    public class LoginViewModel :BaseViewModel
    {
        IMyLocation loc;
        INavigation nav;
        public ICommand OnLoginCommand { get; set; }
        public LoginViewModel(INavigation ObjNav)
        {
            nav = ObjNav;
            IsLoginButtonEnabled = true;
            OnLoginCommand = new Command(DoLogin);
            //UserName = "dcollins@example.net";
            //Password = "123456";
            CheckGPS();
        }

        private async void DoLogin(object obj)
        {
            if (!CheckGPS())
            {
                UserDialogs.Instance.Alert("Enable GPS or Location Service", "Alert", "ok");
                return;
            }
            else if (string.IsNullOrEmpty(UserName))
            {
                UserDialogs.Instance.Alert("Enter Username", "Alert", "OK");
            }
            else if (string.IsNullOrEmpty(Password))
            {
                UserDialogs.Instance.Alert("Enter password", "Alert", "OK");
            }
            else
            {
                try
                {
                    IsLoginButtonEnabled = false;
                    UserDialogs.Instance.ShowLoading("Please Wait...");
                    var objLoginRequest = new LoginRequestData();
                    HttpCommonService objHttpCommonService = new HttpCommonService();
                    objLoginRequest.UserName = UserName;
                    objLoginRequest.Password = Password;
                    objLoginRequest.Client_ID = "2";
                    objLoginRequest.Client_Secret = "XLoZFkRXmLHJbQmCChhPJwcR4H0sJV4vjM4Iompy";
                    objLoginRequest.Gratn_Type = "password";

                    var result = await objHttpCommonService.PostAsync<LoginResponseData, LoginRequestData>(AppSessionData.APIBaseURL + "oauth/token", objLoginRequest);
                    if (result != null)
                    {
                        if (result.Code == 200)
                        {

                            AppSessionData.ActiveToken = result;
                            await nav.PushAsync(new AuthorizationLetterPage());
                            IsLoginButtonEnabled = true;
                        }
                        else
                        {
                            UserDialogs.Instance.Alert(result.Message, "", "Ok");
                            IsLoginButtonEnabled = true;
                        }

                    }

                    UserDialogs.Instance.HideLoading();
                    IsLoginButtonEnabled = true;

                }

                catch (Exception ex)
                {
                    UserDialogs.Instance.Alert(ex.Message.ToString(), "Error", "OK");
                    IsLoginButtonEnabled = true;
                }
            }
        }
        #region  INotify Events  Credentials

        private string _latitude;
        public string lblLatitude
        {
            get { return _latitude; }
            set
            {
                if (value == _latitude) return;
                _latitude = value;
                OnPropertyChanged();
            }
        }
        private string _lontitude;
        public string lblLongitude
        {
            get { return _lontitude; }
            set
            {
                if (value == _lontitude) return;
                _lontitude = value;
                OnPropertyChanged();
            }
        }
        private string _username;
        public string UserName
        {
            get { return _username; }
            set
            {
                if (value == _username) return;
                _username = value;
                OnPropertyChanged();
            }
        }

        private string _password;
        public string Password
        {
            get { return _password; }
            set
            {
                if (value == _password) return;
                _password = value;
                OnPropertyChanged();
            }
        }

        private bool _isloginButtonEnabled;
        private bool isLocationEnabled;

        public bool IsLoginButtonEnabled
        {
            get
            {
                return _isloginButtonEnabled;
            }
            set
            {
                _isloginButtonEnabled = value;
                OnPropertyChanged();
            }
        }

        #endregion
        private bool CheckGPS()
        {

            bool returnValue;
            loc = DependencyService.Get<IMyLocation>();
            if (loc.IsGPSEnabled())
            {
                isLocationEnabled = true;
                returnValue = true;

                if (isLocationEnabled)
                {

                    loc.locationObtained += (object s,
                       ILocationEventArgs e) =>
                    {

                        var lat = e.lat;
                        var lng = e.lng;
                        lblLatitude = lat.ToString();
                        lblLongitude = lng.ToString();

                    };
                    loc.ObtainMyLocation();
                }
            }
            else
            {
                returnValue = false;
                loc.EnableGPS();


            }
            return returnValue;
        }
    }
    //private bool CheckGPS()
    //{
    //    bool returnValue;
    //    loc = DependencyService.Get<IMyLocation>();
    //    if (loc.IsGPSEnabled())
    //    {

    //        returnValue = true;

    //    }
    //    else
    //    {
    //        returnValue = false;
    //        loc.EnableGPS();


    //    }
    //    return returnValue;
    //}

   
    }
 
