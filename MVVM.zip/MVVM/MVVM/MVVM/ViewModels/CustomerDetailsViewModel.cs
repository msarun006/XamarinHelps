﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using MVVM.ApiData;
using MVVM.Services;
using MVVM.Views;
using MvvmHelpers;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace MVVM.ViewModels
{
    public class CustomerDetailsViewModel : BaseViewModel
    {

        public ICommand OnDetailsPageCommand { get; set; }
        INavigation nav;
        private byte[] _frontImageStream;
        private byte[] _backImageStream;
        private byte[] _consentImageStream;
        public int StatusID;
        public CustomerDetailsViewModel(string objId, string objName, string objMobile, string objAddress, string objComment, string objLatitude, string objLongtitude, int objStatusId, string objStatusName, INavigation objNav)
        {
            nav = objNav;
            CustomerID = objId;
            StatusID = objStatusId;
            CustomerName = objName;
            CustomerMobile = objMobile;
            CustomerAddress = objAddress;
            CustomerComment = objComment;
            lblLatitude = objLatitude;
            lblLongitude = objLongtitude;
            StatusName = objStatusName;
            IsSubmitButtonEnabled = true;
            OnDetailsPageCommand = new RelayCommand<string>(DoCustomerDetails);
            IsImageLayoutVisible = false;
        }
        public CustomerDetailsViewModel(string objId, string objName, string objMobile, string objAddress, string objComment, string objLatitude, string objLongtitude, int objStatusId, string objStatusName, byte[] objImageFront, byte[] objImageBack, byte[] objImageConsent, INavigation objNav)
        {

            ImageConsent = "landscape.png";
            nav = objNav;
            CustomerID = objId;
            StatusID = objStatusId;
            CustomerName = objName;
            CustomerMobile = objMobile;
            CustomerAddress = objAddress;
            CustomerComment = objComment;
            lblLatitude = objLatitude;
            lblLongitude = objLongtitude;
            StatusName = objStatusName;
            OnDetailsPageCommand = new RelayCommand<string>(DoCustomerDetails);
            if (objImageFront != null)
            {
                _frontImageStream = objImageFront;
                var fstream = new MemoryStream(objImageFront);
                ImageFront = ImageSource.FromStream(() => fstream);
            }
            if (objImageBack != null)
            {
                _backImageStream = objImageBack;
                var fbstream = new MemoryStream(objImageBack);
                ImageBack = ImageSource.FromStream(() => fbstream);
            }
            if (objImageConsent != null)
            {
                _consentImageStream = objImageConsent;
                var constram = new MemoryStream(objImageConsent);
                ImageConsent = ImageSource.FromStream(() => constram);
            }
            IsSubmitButtonEnabled = true;
            IsImageLayoutVisible = true;
        }

        private async void DoCustomerDetails(string obj)
        {
            switch (obj)
            {
                case "DoBack":
                    await nav.PopAsync();
                    break;
                case "DoSubmitData":
                    SubmitData();
                    break;

            }
        }

        #region Binding Data

        private string _customerId;
        public string CustomerID
        {
            get { return _customerId; }
            set
            {
                if (value == _customerId) return;
                _customerId = value;
                OnPropertyChanged();
            }
        }

        private string _customerComment;
        public string CustomerComment
        {
            get { return _customerComment; }
            set
            {
                if (value == _customerComment) return;
                _customerComment = value;
                OnPropertyChanged();
            }
        }

        private string _customerName;
        public string CustomerName
        {
            get { return _customerName; }
            set
            {
                if (value == _customerName) return;
                _customerName = value;
                OnPropertyChanged();
            }
        }

        private string _customerMobile;
        public string CustomerMobile
        {
            get { return _customerMobile; }
            set
            {
                if (value == _customerMobile) return;
                _customerMobile = value;
                OnPropertyChanged();
            }
        }
        private string _customerAddress;
        public string CustomerAddress
        {
            get { return _customerAddress; }
            set
            {
                if (value == _customerAddress) return;
                _customerAddress = value;
                OnPropertyChanged();
            }
        }

        private string _customerStatus;
        public string CustomerStatus
        {
            get { return _customerStatus; }
            set
            {
                if (value == _customerStatus) return;
                _customerStatus = value;
                OnPropertyChanged();
            }
        }
        private string _statusName;
        public string StatusName
        {
            get { return _statusName; }
            set
            {
                if (value == _statusName) return;
                _statusName = value;
                OnPropertyChanged();
            }
        }

        private string _latitude;
        public string lblLatitude
        {
            get { return _latitude; }
            set
            {
                if (value == _latitude) return;
                _latitude = value;
                OnPropertyChanged();
            }
        }
        private string _lontitude;
        public string lblLongitude
        {
            get { return _lontitude; }
            set
            {
                if (value == _lontitude) return;
                _lontitude = value;
                OnPropertyChanged();
            }
        }


        
               private bool _isSubmitButtonEnabled;

        public bool IsSubmitButtonEnabled
        {
            get
            {
                return _isSubmitButtonEnabled;
            }
            set
            {
                _isSubmitButtonEnabled = value;
                OnPropertyChanged();
            }
        }

        #endregion

        #region Image Source Binding
        private ImageSource _imageFront;
        public ImageSource ImageFront
        {
            get
            { return this._imageFront; }
            set
            {
                if (Equals(value, this._imageFront))
                { return; }
                this._imageFront = value;
                OnPropertyChanged();
            }
        }

        private ImageSource _imageBack;
        public ImageSource ImageBack
        {
            get
            { return this._imageBack; }
            set
            {
                if (Equals(value, this._imageBack))
                { return; }
                this._imageBack = value;
                OnPropertyChanged();
            }
        }
        private ImageSource _imageConsent;
        public ImageSource ImageConsent
        {
            get
            { return this._imageConsent; }
            set
            {
                if (Equals(value, this._imageConsent))
                { return; }
                this._imageConsent = value;
                OnPropertyChanged();
            }
        }


        private bool _isImageLayoutVisible;

        public bool IsImageLayoutVisible
        {
            get
            {
                return _isImageLayoutVisible;
            }
            set
            {
                _isImageLayoutVisible = value;
                OnPropertyChanged("IsImageLayoutVisible");
            }
        }

        #endregion

        
        private async void SubmitData()
        {
            try
            {
                IsSubmitButtonEnabled = false;
                string geoURL = "http://maps.google.com/maps?q=" + lblLatitude + "," + lblLongitude;
                string FrontImageS3path = string.Empty;
                string BackImageS3path = string.Empty;
                string ConsentImageS3path = string.Empty;
                UserDialogs.Instance.ShowLoading("Uploading Data...");
                string frontImageFile = CustomerID + "AADHAARF.jpg";
                string BackImageFile = CustomerID + "AADHAARB.jpg";
                string ConsentImageFile = CustomerID + "BOIConsentLetter.jpg";
                if (StatusName.Contains("Complete"))
                { try
                    {
                        FrontImageS3path = await S3Manager.UploadFileToS3(frontImageFile, _frontImageStream, AppSessionData.S3Data.bucketname);
                        BackImageS3path = await S3Manager.UploadFileToS3(BackImageFile, _backImageStream, AppSessionData.S3Data.bucketname);
                        if (_consentImageStream != null)
                        {
                            ConsentImageS3path = await S3Manager.UploadFileToS3(ConsentImageFile, _consentImageStream, AppSessionData.S3Data.bucketname);
                        }
                    }
                    catch { }
                }
                var objHttpCommonService = new HttpCommonService();
                UpdateRequestData obj_update_request = new UpdateRequestData();
                obj_update_request.client_id = CustomerID;
                obj_update_request.phone = CustomerMobile;
                obj_update_request.address = CustomerAddress;
                obj_update_request.comments = CustomerComment;
                obj_update_request.aadhaar_front_image = FrontImageS3path;
                obj_update_request.aadhaar_back_image = BackImageS3path;
                obj_update_request.consent_letter_url = ConsentImageS3path;
                obj_update_request.status = StatusID;
                obj_update_request.latitude = lblLatitude;
                obj_update_request.longitude = lblLongitude;
                obj_update_request.geo_mapping_url = geoURL;

                var result = await objHttpCommonService.PostAsync<UpdateResponseData, UpdateRequestData>(AppSessionData.APIBaseURL + "api/aadhaar-update", obj_update_request);
                if (result != null && result.code == 200)
                {
                    UserDialogs.Instance.HideLoading();
                    UserDialogs.Instance.Alert("Data Uploaded Successfully..!", "Success", "Ok");
                    await Task.Delay(1000);
                     await nav.PushAsync(new FindCustomer());
                }
                else
                {
                    IsSubmitButtonEnabled = true;
                    UserDialogs.Instance.HideLoading();
                }

            }
            catch (Exception ex)
            {
                IsSubmitButtonEnabled = true;
              // App.dialog.ShowAlert(ex.Message.ToString());
             
            }
            finally { UserDialogs.Instance.HideLoading(); }
        }

    }
}

