﻿using MvvmHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms.Maps;
using Acr.UserDialogs;
using System.Windows.Input;
using GalaSoft.MvvmLight.Command;

namespace MVVM.ViewModels
{
    public class MapViewModel :BaseViewModel
    {
        Geocoder geoCoder;
        public string Area;
        public string City;
        public string Pincode;
        public string State;
        public static Map MapView { get; internal set; }
        public ICommand CommandMap { get; set; }
        public MapViewModel(string objCustomerArea, string objCustomerCity, string objCustomerPincode, string objCustomerState)
        {
         geoCoder = new Geocoder();
         Area = objCustomerArea;
         City = objCustomerCity;
         Pincode = objCustomerPincode;
         State = objCustomerState;
           MapView = new Map();
          Findlocation();
         CommandMap = new RelayCommand<string>(ShowMap);
      }
        public async void Findlocation()
        {
            try
            {
                MapView.Pins.Clear();
                var address = Area + City + Pincode + State;
                var approximateLocations = await geoCoder.GetPositionsForAddressAsync(address);
                foreach (var position in approximateLocations)
                {
                    MapView.MoveToRegion(MapSpan.FromCenterAndRadius(new Position(position.Latitude, position.Longitude), Distance.FromMiles(0)));

                    var mapPin = new Pin
                    {
                        Type = PinType.Place,
                        Position = position,
                        Label = "",
                        Address = "Customer Location"
                    };
                    MapView.Pins.Add(mapPin);
                }
            }
            catch(Exception ex)
            {
                UserDialogs.Instance.Alert(ex.Message.ToString(),"","ok");
            }
          
        }
        public async void ShowMap(string sender)
        {
            switch (sender)
            {
                case "ShowManualSearch":
                    IsEntryLayoutVisible = true;
                    break;

                case "DoManualSearch":
                    if (string.IsNullOrEmpty(AddressField))
                    {
                        UserDialogs.Instance.Alert("Enter the location", "Alert", "OK");
                    }
                    else
                    {

                        MapView.Pins.Clear();
                        var address = AddressField;
                        var approximateLocations = await geoCoder.GetPositionsForAddressAsync(address);
                        foreach (var position in approximateLocations)
                        {
                            // lbl_output_of_input.Text += position.Latitude + ", " + position.Longitude + "\n";
                            MapView.MoveToRegion(MapSpan.FromCenterAndRadius(new Position(position.Latitude, position.Longitude), Distance.FromMiles(0)));

                            var mapPin = new Pin
                            {
                                Type = PinType.Place,
                                Position = position,
                                Label = "",
                                Address = "Customer Location"
                            };
                            MapView.Pins.Add(mapPin);
                            IsEntryLayoutVisible = false;
                        }

                    }
                    break;


            }
          
        }

        #region Binding Property
        private string _addressField;
        public string AddressField
        {
            get { return _addressField; }
            set
            {
                if (value == _addressField) return;
                _addressField = value;
                OnPropertyChanged();
            }
        }

        private bool _isEntryLayoutVisible;

        public bool IsEntryLayoutVisible
        {
            get
            {
                return _isEntryLayoutVisible;
            }
            set
            {
                _isEntryLayoutVisible = value;
                OnPropertyChanged("IsEntryLayoutVisible");
            }
        }
        #endregion

     

   


    }
}
