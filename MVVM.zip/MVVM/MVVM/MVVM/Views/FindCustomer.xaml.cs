﻿using MVVM.Interfaces;
using MVVM.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MVVM.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class FindCustomer : ContentPage
    {
        public FindCustomer()
        {

            InitializeComponent();
            NavigationPage.SetHasBackButton(this, false);
            BindingContext = new FindCustomerViewModel(DependencyService.Get<ICameraProvider>(), Navigation);
        }


        private void FocusStatusPicker(object sender, EventArgs e)
        {
            PickerStatus.Focus();
        }


     
        protected override bool OnBackButtonPressed()
        {
            base.OnBackButtonPressed();

            // Custom logic for BackButtonPresssed
            Device.BeginInvokeOnMainThread(async () =>
            {
                var result = await DisplayAlert("Alert", "Are sure to Logout ", "Yes", "No");
                if (result)
                {
                    App.Current.MainPage = new NavigationPage(new LoginPage());
                }

            });

            return true; // prevent Xamarin.Forms from processing back button
        }

      
    }
}