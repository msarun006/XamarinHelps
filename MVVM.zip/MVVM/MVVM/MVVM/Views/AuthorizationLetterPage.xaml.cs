﻿using MVVM.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MVVM.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AuthorizationLetterPage : ContentPage
    {
        public AuthorizationLetterPage()
        {
            InitializeComponent();
            NavigationPage.SetHasBackButton(this,false);
            BindingContext = new AuthLetterViewModel(Navigation);
          
        }
        protected override bool OnBackButtonPressed()
        {
            base.OnBackButtonPressed();

            // Custom logic for BackButtonPresssed
            Device.BeginInvokeOnMainThread(async () =>
            {
                var result = await DisplayAlert("Alert", "Are sure to Logout ", "Yes", "No");
                if (result)
                {
                    App.Current.MainPage = new NavigationPage(new LoginPage());
                }

            });

            return true; // prevent Xamarin.Forms from processing back button
        }

      
    }
}