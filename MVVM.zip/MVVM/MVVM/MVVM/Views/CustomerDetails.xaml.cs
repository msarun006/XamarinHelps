﻿using MVVM.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MVVM.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CustomerDetails : ContentPage
    {

        public CustomerDetails(string id, string Name, string Mobile, string Address, string comment, string latitude, string longtitude, int statusid, string statusname)
        {
            InitializeComponent();
            BindingContext = new CustomerDetailsViewModel(id, Name, Mobile, Address, comment, latitude, longtitude, statusid, statusname, Navigation);
            layoutConsent.IsVisible = false;
            layoutAADHAARImage.IsVisible = false;
        }

        public CustomerDetails(string id, string Name, string Mobile, string Address, string comment, string latitude, string longtitude, int statusid, string statusname, byte[] frontImageByte, byte[] backImageByte, byte[] consentImageByte)
        {
            InitializeComponent();
            BindingContext = new CustomerDetailsViewModel(id, Name, Mobile, Address, comment, latitude, longtitude, statusid, statusname, frontImageByte, backImageByte, consentImageByte, Navigation);
        }
    }
}