﻿using MVVM.Interfaces;
using MVVM.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace MVVM.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class LoginPage : ContentPage
    {
        IMyLocation loc;
        bool isLocationEnabled = false;
        const string emailRegex = @"^(?("")("".+?(?<!\\)""@)|(([0-9a-z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-z])@))" +
                              @"(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-\w]*[0-9a-z]*\.)+[a-z0-9][\-a-z0-9]{0,22}[a-z0-9]))$";
        public LoginPage()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            BindingContext = new LoginViewModel(Navigation);

            var PasswordTap = new TapGestureRecognizer();
            lblHidePassword.GestureRecognizers.Add(PasswordTap);
            PasswordTap.Tapped += (s, e) =>
            {

                if (EntryPassword.IsPassword == true)
                {
                    lblHidePassword.Text = (string)Application.Current.Resources["ShowPassword"];
                    lblHidePassword.TextColor = Color.White;
                    EntryPassword.IsPassword = false;
                }
                else
                {
                    lblHidePassword.Text = (string)Application.Current.Resources["HidePassword"];
                    lblHidePassword.TextColor = Color.DarkOrange;
                    EntryPassword.IsPassword = true;

                }

            };

        }
        protected override bool OnBackButtonPressed()
        {
            base.OnBackButtonPressed();

            // Custom logic for BackButtonPresssed
            Device.BeginInvokeOnMainThread(async () =>
            {
                var result = await DisplayAlert("Warning", "Are you sure to exit from the app?", "Yes", "No");
                if (result)
                {
                    Android.OS.Process.KillProcess(Android.OS.Process.MyPid());
                }
            });

            return true; // prevent Xamarin.Forms from processing back button
        }

        private void EntryUsername_Unfocused(object sender, FocusEventArgs e)
        {
            var text = ((Entry)sender).Text;
            if (string.IsNullOrEmpty(text))
            {
                lblRightsign.Text = (string)Application.Current.Resources["WrongSign"];
                lblRightsign.IsVisible = true;
                lblRightsign.TextColor = Color.DarkOrange;
            }
            else
            {
                lblRightsign.Text = (string)Application.Current.Resources["RightSign"];
                lblRightsign.IsVisible = true;
                lblRightsign.TextColor = Color.White;
            }
        }

        private void EntryPassword_Focused(object sender, FocusEventArgs e)
        {
            lblHidePassword.IsVisible = true;
        }

        private void EntryUsername_TextChanged(object sender, TextChangedEventArgs e)
        {
          
            bool IsValid = false;
            IsValid = (Regex.IsMatch(e.NewTextValue, emailRegex, RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250)));
            ((Entry)sender).TextColor = IsValid ? Color.White : Color.White;
           
            if (IsValid == true)
            {
                lblRightsign.Text = (string)Application.Current.Resources["RightSign"];
                lblRightsign.IsVisible = true;
                lblRightsign.TextColor = Color.White;
            }
            else
            {
                lblRightsign.Text = (string)Application.Current.Resources["WrongSign"];
                lblRightsign.IsVisible = true;
                lblRightsign.TextColor = Color.DarkOrange;
            }
        }
    }
}