﻿using MVVM.ApiData;
using MVVM.Interfaces;
using MVVM.Models;
using MVVM.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace MVVM.Preferences
{
    public static class AppPreferences
    {
        public static IUserPreferences _userPref = DependencyService.Get<IUserPreferences>();
        public static IUserPreferences UserPreferences
        {
            get
            {
                return _userPref;
            }

        }

        public static bool IsFirstRun
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsFirstRun")))
                {
                    UserPreferences.SetValue("IsFirstRun", false.ToString());

                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsFirstRun"));
                }
            }
            set
            {
                UserPreferences.SetValue("IsFirstRun", value.ToString());
            }
        }



        public static string AuthorizationData
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("AuthorizationData")))
                {
                    UserPreferences.SetValue("AuthorizationData", false.ToString());

                    return "";
                }
                else
                {
                    return UserPreferences.GetValue("AuthorizationData");
                }
            }
            set
            {
                UserPreferences.SetValue("AuthorizationData", value.ToString());
            }
        }





        public static string Username
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("Username")))
                {
                    UserPreferences.SetValue("Username", false.ToString());

                    return "";
                }
                else
                {
                    return UserPreferences.GetValue("Username");
                }
            }
            set
            {
                UserPreferences.SetValue("Username", value.ToString());
            }
        }



        //ActiveToken
        public static S3ResponseData S3Data
        {
            get
            {
                string value = UserPreferences.GetValue("S3Data");

                if (string.IsNullOrEmpty(value))
                {
                    UserPreferences.SetValue("S3Data", Newtonsoft.Json.JsonConvert.SerializeObject(new S3ResponseData()));
                    return null;
                }
                else
                {
                    var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<S3ResponseData>(value);
                    return obj;

                }
            }
            set
            {
                if (value != null)
                {
                    var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
                    UserPreferences.SetValue("S3Data", jsonstring);
                }
                else
                {
                    UserPreferences.SetValue("S3Data", String.Empty);
                }
            }
        }

        public static LoginResponseData ActiveToken
        {
            get
            {
                string value = UserPreferences.GetValue("ActiveToken");

                if (string.IsNullOrEmpty(value))
                {
                    UserPreferences.SetValue("ActiveToken", Newtonsoft.Json.JsonConvert.SerializeObject(new LoginResponseData()));
                    return null;
                }
                else
                {
                    var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<LoginResponseData>(value);
                    return obj;
                }
            }
            set
            {
                if (value != null)
                {
                    var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
                    UserPreferences.SetValue("ActiveToken", jsonstring);
                }
                else
                {
                    UserPreferences.SetValue("ActiveToken", String.Empty);
                }
            }
        }




    }
}
