﻿using MVVM.Utilities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVM.ApiData
{
    public class LoginRequestData : BaseModel
    {
        public string _username, _password, _client_id, _client_secret, _grant_type;

        [JsonProperty(PropertyName = "username")]
        public string UserName
        {
            get { return _username; }
            set { _username = value; RaisePropertyChanged(); }
        }
        [JsonProperty(PropertyName = "password")]
        public string Password
        {
            get { return _password; }
            set { _password = value; RaisePropertyChanged(); }
        }
        [JsonProperty(PropertyName = "client_id")]
        public string Client_ID
        {
            get { return _client_id; }
            set { _client_id = value; RaisePropertyChanged(); }
        }
        [JsonProperty(PropertyName = "client_secret")]
        public string Client_Secret
        {
            get { return _client_secret; }
            set { _client_secret = value; RaisePropertyChanged(); }
        }
        [JsonProperty(PropertyName = "grant_type")]
        public string Gratn_Type
        {
            get { return _grant_type; }
            set { _grant_type = value; RaisePropertyChanged(); }
        }

    }
}
