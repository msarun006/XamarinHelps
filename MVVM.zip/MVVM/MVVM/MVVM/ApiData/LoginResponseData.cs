﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVM.ApiData
{
    public class LoginResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public int Code { get; set; }
        [JsonProperty(PropertyName = "message")]
        public string Message { get; set; }
        [JsonProperty(PropertyName = "token_type")]
        public string Token_Type { get; set; }
        [JsonProperty(PropertyName = "expires_in")]
        public string Expires_In { get; set; }
        [JsonProperty(PropertyName = "access_token")]
        public string Access_Token { get; set; }
        [JsonProperty(PropertyName = "refresh_token")]
        public string Refresh_Token { get; set; }
    }
}
