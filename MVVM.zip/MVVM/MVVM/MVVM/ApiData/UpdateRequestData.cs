﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVM.ApiData
{
    public class UpdateRequestData
    {
        public string client_id { get; set; }
        public string phone { get; set; }
        public string aadhaar_front_image { get; set; }
        public string aadhaar_back_image { get; set; }
        public string consent_letter_url { get; set; }
        public string address { get; set; }
        public string geo_mapping_address { get; set; }
        public int status { get; set; }
        public string comments { get; set; }
        public string latitude { get; set; }
        public string longitude { get; set; }
        public string geo_mapping_url { get; set; }


    }
}
