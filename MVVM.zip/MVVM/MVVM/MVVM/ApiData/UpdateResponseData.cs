﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVM.ApiData
{
    public class UpdateResponseData
    {
        public int code { get; set; }
        public string message { get; set; }
        public bool data_response { get; set; }
        public UpdateData data { get; set; }
    }

    public class UpdateData
    {
        public int id { get; set; }
        public string client_id { get; set; }
        public string acc_no { get; set; }
        public string zone { get; set; }
        public string branch { get; set; }
        public string branch_cd { get; set; }
        public string schm_code { get; set; }
        public string open_date { get; set; }
        public string pager_no { get; set; }
        public string comu_phone_num_1 { get; set; }
        public string comu_phone_num_2 { get; set; }
        public string email { get; set; }
        public string name { get; set; }
        public string address { get; set; }
        public string area { get; set; }
        public string state { get; set; }
        public string city { get; set; }
        public string pincode { get; set; }
        public int user_id { get; set; }
        public string flag_update { get; set; }
        public int flag_retrieve { get; set; }
        public string aadhaar_no { get; set; }
        public string aadhaar_front_image { get; set; }
        public string aadhaar_back_image { get; set; }
        public string created_at { get; set; }
        public string updated_at { get; set; }
    }
}
