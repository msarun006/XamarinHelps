﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVM.ApiData
{
    public class GetDetailsResponseData
    {
        public int code { get; set; }
        public string message { get; set; }
        public bool data_response { get; set; }
        public GetUserdetails data { get; set; }
    }

    public class GetUserdetails
    {
        public string name { get; set; }
        public string address { get; set; }
        public string comu_phone_num_1 { get; set; }
        public string area { get; set; }
        public string state { get; set; }
        public string city { get; set; }
        public string pincode { get; set; }
    }
}
