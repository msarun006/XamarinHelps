﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVM.ApiData
{
    public class StatusResponse
    {
        public int code { get; set; }
        public string message { get; set; }
        public bool data_response { get; set; }
        public List<StatusDetails> data { get; set; }

        public class StatusDetails
        {
            public int id { get; set; }
            public string name { get; set; }
            public string created_at { get; set; }
            public string updated_at { get; set; }


        }
    }
    

   
}
