﻿using Amazon;
using Amazon.Runtime;
using Amazon.S3;
using MVVM.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVM.Utilities
{
    public class S3Utils
    {
        private static BasicAWSCredentials cognitoCredentials;
        private static IAmazonS3 s3Client;
        private static string S3AccessKeyID = "AKIAJDBMKPRZXV4QSYOQ";
        private static string S3SecretAccessKey = "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";
        public static string BUCKET_NAME = "hiremee.photos";


        public static BasicAWSCredentials Credentials
        {
            get
            {

                if (cognitoCredentials == null)
                {
                    if (!string.IsNullOrEmpty(AppSessionData.S3Data.s3accesskeyid) && !string.IsNullOrEmpty(AppSessionData.S3Data.s3secretaccesskey))
                        cognitoCredentials = new BasicAWSCredentials(AppSessionData.S3Data.s3accesskeyid, AppSessionData.S3Data.s3secretaccesskey);
                }
                return cognitoCredentials;
            }
        }

        public static IAmazonS3 S3Client
        {
            get
            {
                if (s3Client == null && Credentials != null)
                {
                    s3Client = new AmazonS3Client(Credentials, RegionEndpoint.APSoutheast1);
                }
                return s3Client;
            }
        }



    }
}
