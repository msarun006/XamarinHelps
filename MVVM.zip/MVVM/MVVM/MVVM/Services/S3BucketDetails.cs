﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVM.Services
{
    public class S3BucketDetails
    {
        public int code { get; set; }
        public string message { get; set; }
        public bool data_response { get; set; }
        public S3ResponseData data { get; set; }
    }
}
