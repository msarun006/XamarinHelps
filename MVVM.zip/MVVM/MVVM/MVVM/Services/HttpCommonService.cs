﻿using Acr.UserDialogs;
using MVVM.Interfaces;
using Newtonsoft.Json;
using Plugin.Connectivity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace MVVM.Services
{
    public class HttpCommonService : IHttpCommanService
    {
        private HttpClient _client;
        private HttpResponseMessage _response;


        public HttpCommonService()
        {

        }

        #region PostAsnyc Method
        public async Task<T1> PostAsync<T1, T2>(string strURL, T2 model)
        {
            try
            {
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                // bool isHostReachable = await CrossConnectivity.Current.IsRemoteReachable(APIData.HOST_REACHABLE);
                if (isNetworkAvailable)
                {


                    var uri = new Uri(string.Format(strURL));
                    _client = CreateWebRequest(uri);
                    var json = JsonConvert.SerializeObject(model);
                    var content = new StringContent(json, Encoding.UTF8, "application/json");
                    _response = await _client.PostAsync(uri, content);
                    var result = await _response.Content.ReadAsStringAsync();
                    //_response.EnsureSuccessStatusCode();
                    //if (_response.IsSuccessStatusCode)
                    //{
                    var responseresult = JsonConvert.DeserializeObject<T1>(result);
                    return responseresult;
                    //}
                    //else
                    //{
                    //    return default(T1);

                    //}



                }
                else
                {
                   App.dialog.ShowAlert("Internet Not Available");
                    return default(T1);
                }
            }
            catch (Exception ex)
            {
                App.dialog.ShowAlert(ex.Message.ToString());
                return default(T1);
            }

        }
        #endregion

        #region GetAsync Method     
        public async Task<T1> GetAsync<T1>(string strURL)
        {
            try
            {
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                // bool isHostReachable = await CrossConnectivity.Current.IsRemoteReachable(APIData.HOST_REACHABLE);
                if (isNetworkAvailable)
                {


                    var uri = new Uri(string.Format(strURL));
                    _client = CreateWebRequest(uri);
                    _response = await _client.GetAsync(uri);
                    var result = await _response.Content.ReadAsStringAsync();
                    // _response.EnsureSuccessStatusCode();
                    var responseresult = JsonConvert.DeserializeObject<T1>(result);
                    return responseresult;

                }
                else
                {
                    App.dialog.ShowAlert("Internet Not Available");
                    return default(T1);
                }
            }
            catch (Exception ex)
            {

                App.dialog.ShowAlert(ex.Message.ToString());
                return default(T1);
            }

        }

        #endregion

        private HttpClient CreateWebRequest(Uri serviceUrl)
        {
            var handler = new HttpClientHandler() { UseCookies = false };
            _client = new HttpClient(handler) { BaseAddress = serviceUrl };
            _client.DefaultRequestHeaders.Add("ContentType", "application/json");
            if (!serviceUrl.ToString().Contains("token"))
                _client.DefaultRequestHeaders.Add("Authorization", "Bearer " + AppSessionData.ActiveToken.Access_Token);
            _client.DefaultRequestHeaders.Add("Connection", "keep-alive");
            _client.Timeout = new TimeSpan(0, 0, 15);
            return _client;
        }
    }
}
