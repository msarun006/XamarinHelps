﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVM.Services
{
    public class S3ResponseData
    {
        public string s3username { get; set; }
        public string s3accesskeyid { get; set; }
        public string s3secretaccesskey { get; set; }
        public string bucketname { get; set; }
    }
}
