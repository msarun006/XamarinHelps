﻿using Amazon.S3;
using Amazon.S3.Model;
using MVVM.Utilities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVM.Services
{
    public class S3Manager
    {

        public const string S3_BASE_URL = "https://s3-ap-southeast-1.amazonaws.com/";


        public static async Task<string> UploadFileToS3(string uploadAsFileName, byte[] image, string toWhichBucketName)
        {
            string s3path = string.Empty;
            try
            {

                Amazon.S3.Transfer.TransferUtilityUploadRequest _request = new Amazon.S3.Transfer.TransferUtilityUploadRequest();
                _request.BucketName = toWhichBucketName;
                _request.CannedACL = Amazon.S3.S3CannedACL.AuthenticatedRead;
                _request.Key = uploadAsFileName;
                using (Amazon.S3.Transfer.TransferUtility _transferUtility = new Amazon.S3.Transfer.TransferUtility(S3Utils.S3Client))
                {
                    using (var ms = new MemoryStream(image))
                    {
                        _request.InputStream = ms;
                        await _transferUtility.UploadAsync(_request);
                    }

                }
                //using (S3Utils.S3Client)
                //{
                //    PutObjectRequest request = new PutObjectRequest();
                //    //request.FilePath = "folder" + "/" + uploadAsFileName;
                //    request.ContentType = "image/jpg";
                //    request.Key = uploadAsFileName;

                //    request.BucketName = toWhichBucketName;
                //    request.CannedACL = S3CannedACL.AuthenticatedRead;
                //    //request.StorageClass = S3StorageClass.FindValue(uploadAsFileName);
                //    using (var ms = new MemoryStream(image))
                //    {
                //        request.InputStream = ms;
                //        PutObjectResponse response = await S3Utils.S3Client.PutObjectAsync(request);
                //    }                    
                //    s3path = S3_BASE_URL + toWhichBucketName + "/" + uploadAsFileName;

                //}
                s3path = S3_BASE_URL + toWhichBucketName + "/" + uploadAsFileName;
            }
            catch (AmazonS3Exception ex)
            {

                return s3path;
            }

            return s3path;
        }


        public static async Task<string> UploadFile(string filepath, string filekey, string bucket)
        {
            string s3path = string.Empty;
            string existingBucketName = bucket;
            string keyName = filekey;
            string filePath = filepath;



            try
            {


                //await GetS3Credentials("s3container");
                //Amazon.S3.Model.PutBucketRequest _PutBucketRequest = new Amazon.S3.Model.PutBucketRequest();
                Amazon.S3.Transfer.TransferUtilityUploadRequest _request = new Amazon.S3.Transfer.TransferUtilityUploadRequest();
                _request.BucketName = bucket;
                _request.FilePath = filepath;

                _request.StorageClass = S3StorageClass.ReducedRedundancy;
                _request.PartSize = 6291456; // 6 MB.
                _request.CannedACL = Amazon.S3.S3CannedACL.AuthenticatedRead;
                _request.Key = filekey;


                //PutObjectRequest prequest = new PutObjectRequest();
                //prequest.BucketName = bucket;
                //prequest.CannedACL = S3CannedACL.AuthenticatedRead;
                //prequest.Key = filekey;
                //prequest.FilePath = filepath;

                //await S3Utils.S3Client.PutObjectAsync(prequest);
                using (Amazon.S3.Transfer.TransferUtility _transferUtility = new Amazon.S3.Transfer.TransferUtility(S3Utils.S3Client))
                {
                    await _transferUtility.UploadAsync(_request);
                }

                //GetPreSignedUrlRequest request = new GetPreSignedUrlRequest();
                //request.BucketName = bucket;
                //request.Key = filekey;
                //request.Expires = DateTime.Now.AddYears(5);
                //request.Protocol = Protocol.HTTP;
                //string url = S3Utils.S3Client.GetPreSignedURL(request);

                s3path = S3_BASE_URL + bucket + "/" + filekey;
                //s3path = url;

            }
            catch (Amazon.S3.AmazonS3Exception exception)
            {
                s3path = string.Empty;
                System.Diagnostics.Debug.WriteLine("AMAZON-S3-EXCEPTION: Could not process upload request" + exception.StackTrace);
            }
            return s3path;
        }
        public static string GeneratePreSignedURL(string bucketName, string objectKey, int minutes)
        {
            string urlString = "";
            GetPreSignedUrlRequest request = new GetPreSignedUrlRequest
            {
                BucketName = bucketName,
                Key = objectKey,
                Expires = DateTime.Now.AddMinutes(minutes)

            };

            try
            {
                urlString = S3Utils.S3Client.GetPreSignedURL(request);
                //string url = s3Client.GetPreSignedURL(request1);
            }
            catch (AmazonS3Exception amazonS3Exception)
            {
                if (amazonS3Exception.ErrorCode != null &&
                    (amazonS3Exception.ErrorCode.Equals("InvalidAccessKeyId")
                    ||
                    amazonS3Exception.ErrorCode.Equals("InvalidSecurity")))
                {
                    System.Diagnostics.Debug.WriteLine("Check the provided AWS Credentials.");
                    System.Diagnostics.Debug.WriteLine(
                    "To sign up for service, go to http://aws.amazon.com/s3");
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine(
                    "Error occurred. Message:'{0}' when listing objects",
                     amazonS3Exception.Message);
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
            }

            return urlString;

        }
    }
}
