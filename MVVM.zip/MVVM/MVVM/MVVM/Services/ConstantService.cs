﻿using MVVM.ApiData;
using MVVM.Models;
using MVVM.Preferences;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVM.Services
{
    class ConstantService
    {
    }

    public static class AppSessionData
    {
        static AppSessionData()
        {

        }
        //new url 
        //public static string APIBaseURL = @"http://172.18.1.87:88/";
        // Public url//
       public static string APIBaseURL = @"http://182.75.9.172:83/";

        // public static string APIBaseURL = @"http://172.16.1.254:83/";//
        public static S3ResponseData S3Data { get { return AppPreferences.S3Data; } set { AppPreferences.S3Data = value; } }

        public static LoginResponseData ActiveToken { get { return AppPreferences.ActiveToken; } set { AppPreferences.ActiveToken = value; } }

    }

    public static class GlobalFlags
    {

        public static bool IsReturningFromCameraPage { get; set; }
        public static string CapturedImageUrl { get; set; }

        public static bool BackImage { get; set; }
        public static bool FrontImage { get; set; }



        public static string PdfPrintFilepath { get; set; }

        public static string isNewVisitors { get; set; }


        public static bool isReturnBackVisitorEntryForm { get; set; }



    }
}
