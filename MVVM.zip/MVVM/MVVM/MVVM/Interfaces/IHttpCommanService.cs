﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVVM.Interfaces
{
    public interface IHttpCommanService
    {
        Task<T1> PostAsync<T1, T2>(string url, T2 model);
        Task<T1> GetAsync<T1>(string url);
    }
}
