# KioskModeSample
Sample showing a robust way of doing Kiosk Mode in Xamarin.Android.

Greatly inspired by a [blog post by Andreas Schrade][post].

[post]: http://www.andreas-schrade.de/2015/02/16/android-tutorial-how-to-create-a-kiosk-mode-in-android/
