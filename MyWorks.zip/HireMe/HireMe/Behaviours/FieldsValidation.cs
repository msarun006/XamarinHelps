﻿using System;
using System.Text.RegularExpressions;
using Xamarin.Forms;

namespace HireMe
{
    public static class FieldsValidation
    {
        //public static bool ValidateUserFullName(string fullname)
        //{
        //    if (string.IsNullOrEmpty(fullname) || string.IsNullOrWhiteSpace(fullname)) return false;
        //    fullname = fullname.Trim();
        //    string pattern = (@"(^[a-zA-Z. ]{3,100}$)");
        //    int index = fullname.IndexOf(' ');
        //    if (index != -1 && index < 3) return false;
        //    if (fullname.Length <= 3)
        //    {
        //        if (fullname.Contains(" ") || fullname.Length < 3)
        //            return false;
        //        else
        //            return true;
        //    }
        //    else if (Regex.IsMatch(fullname.Trim(), pattern))
        //    {
        //        return true;
        //    }
        //    else
        //    {
        //        return false;
        //    }
        //}

        //public static bool ValidateUserLastName(string lastname)
        //{
        //    if (string.IsNullOrEmpty(lastname) || string.IsNullOrWhiteSpace(lastname)) return false;
        //    lastname = lastname.Trim();
        //    if (Regex.IsMatch(lastname, @"(^[a-zA-Z. ]{1,100}$)"))
        //    {
        //        return true;
        //    }
        //    else
        //    {
        //        return false;
        //    }
        //}
        //public static bool IsValidPassword(string password)
        //{
        //    string pattern = null;
        //    //Password must contain: Minimum 8 and Maximum 20 characters atleast 1 UpperCase Alphabet, 1 LowerCase Alphabet, 1 Number and 1 Special Character
        //    pattern = (@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$!@#$%^&*()_+=\[{\]};:<>|./?,-~`])[A-Za-z\d$!@#$%^&*()_+=\[{\]};:<>|./?,-~`]{8,20}");
        //    if (string.IsNullOrEmpty(password) || string.IsNullOrWhiteSpace(password)) return false;
        //    if (Regex.IsMatch(password, pattern))
        //    {
        //        return true;
        //    }
        //    else
        //    {
        //        return false;
        //    }
        //}

        //bool isvalid = true;

        //foreach (char ch in fullname)
        //{
        //    if (!char.IsLetter(ch) && ch != ' ') isvalid = false;
        //}

        //return isvalid;
        //public static bool ValidateMobileNumber(string mobilenumber)
        //{
        //    if (string.IsNullOrEmpty(mobilenumber)) return false;

        //    if (mobilenumber.Length != 10) return false;

        //    bool isnumber = true;

        //    foreach (char ch in mobilenumber)
        //    {
        //        if (!char.IsNumber(ch)) isnumber = false;
        //    }

        //    return isnumber;
        //}
        //public static bool ValidateCGPA(string number)
        //{
        //    if (string.IsNullOrEmpty(number.Trim())) return false;

        //    if (number.Length > 1) return false;

        //    bool isnumber = true;

        //    foreach (char ch in number)
        //    {
        //        if (!char.IsNumber(ch)) isnumber = false;
        //    }

        //    return isnumber;
        //}
        //public static bool ValidatePercentage(string number)
        //{
        //    return true;
        //}
        //public static bool ValidateAadhaarNumber(string aadhaarnumber)
        //{

        //    if (string.IsNullOrEmpty(aadhaarnumber.Trim())) return true;
        //    if (aadhaarnumber.Length != 12) return false;
        //    bool isNumber = true;
        //    foreach (char ch in aadhaarnumber)
        //    {
        //        if (!char.IsNumber(ch)) isNumber = false;
        //    }
        //    return isNumber;

        //}


        //public static bool isValidMobileNumber(string mobileNumber)
        //{

        //    if (string.IsNullOrEmpty(mobileNumber.Trim())) return true;
        //    if (mobileNumber.Length != 10) return false;
        //    bool isNumber = true;
        //    foreach (char ch in mobileNumber)
        //    {
        //        if (!char.IsNumber(ch)) isNumber = false;
        //    }
        //    return isNumber;
        //}

        //public static bool ValidatePincode(string collegepincodenumber)
        //{
        //    if (string.IsNullOrEmpty(collegepincodenumber.Trim())) return true;
        //    if (collegepincodenumber.Length != 6) return false;
        //    bool isNumber = true;
        //    foreach (char ch in collegepincodenumber)
        //    {
        //        if (!char.IsNumber(ch)) isNumber = false;
        //    }
        //    return isNumber;
        //}
        //public static bool IsValidEmail(string email)
        //{
        //    if (string.IsNullOrEmpty(email) || string.IsNullOrWhiteSpace(email)) return false;
        //    string pattern = null;
        //    pattern = @"^(?("")("".+?(?<!\\)""@)|(([0-9a-zA-Z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-zA-Z])@))" +
        //   @"(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-zA-Z][-\w]*[0-9a-zA-Z]*\.)+[a-z0-9A-Z][\-a-z0-9A-Z]{0,22}[a-z0-9A-Z]))$";
        //    if (Regex.IsMatch(email, pattern))
        //    {
        //        return true;
        //    }
        //    else
        //    {
        //        return false;
        //    }
        //}

        //public static string GetDeviceID()
        //{
        //    return Convert.ToString(DependencyService.Get<IMyDevice>().GetDeviceID());
        //}

        //public static string GetDeviceModel()
        //{
        //    return Convert.ToString(DependencyService.Get<IMyDevice>().GetDeviceModel());
        //}
    }
}
