﻿using System;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe
{
    public class ListViewBehaviours : Behavior<ListView>
{

	public static readonly BindableProperty CommandProperty = BindableProperty.Create(
		propertyName: "Command",
		returnType: typeof(ICommand),
		declaringType: typeof
		(ListViewBehaviours));

	public ICommand Command
	{
		get { return (ICommand)GetValue(CommandProperty); }
		set { SetValue(CommandProperty, value); }
	}



	protected override void OnAttachedTo(ListView bindable)
	{
		base.OnAttachedTo(bindable);
		bindable.ItemSelected += Bindable_ItemSelected;
		bindable.BindingContextChanged += Bindable_BindingContextChanged;

	}

	private void Bindable_BindingContextChanged(object sender, EventArgs e)
	{
		var lv = sender as ListView;
		BindingContext = lv?.BindingContext;

	}

	private void Bindable_ItemSelected(object sender, SelectedItemChangedEventArgs e)
	{


			 if (e.SelectedItem == null) {
                return; // ensures we ignore this handler when the selection is just being cleared
            }
		 
			Command.Execute(null);

			((ListView)sender).SelectedItem = null; 
		 


	}

	protected override void OnDetachingFrom(ListView bindable)
	{
		base.OnDetachingFrom(bindable);
		bindable.ItemSelected -= Bindable_ItemSelected;
		bindable.BindingContextChanged -= Bindable_BindingContextChanged;
        }
    }
}
