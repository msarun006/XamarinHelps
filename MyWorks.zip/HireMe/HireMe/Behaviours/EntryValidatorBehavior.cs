﻿using MvvmHelpers;
using Xamarin.Forms;
namespace HireMe
{
    public class EntryValidatorBehavior : Behavior<Entry>
    {
        public static readonly BindableProperty MaxLengthProperty = BindableProperty.Create("MaxLength", typeof(int), typeof(MaxLengthValidatorBehavior), 0);
        public static readonly BindablePropertyKey IsValidPropertyKey = BindableProperty.CreateReadOnly("IsValid", typeof(bool), typeof(MaxLengthValidatorBehavior), false);

        public static readonly BindableProperty IsValidProperty = IsValidPropertyKey.BindableProperty;

        public EntryEnableProperty EntryEnableProperty;
        public EntryValidatorBehavior()
        {
            EntryEnableProperty = new EntryEnableProperty();
        }
        public int MaxLength
        {
            get { return (int)GetValue(MaxLengthProperty); }
            set { SetValue(MaxLengthProperty, value); }
        }

        public bool IsValid
        {
            get { return (bool)base.GetValue(IsValidProperty); }
            private set { base.SetValue(IsValidPropertyKey, value); }
        }

        protected override void OnAttachedTo(Entry bindable)
        {
            bindable.TextChanged += bindable_TextChanged;
        }

        private void bindable_TextChanged(object sender, TextChangedEventArgs e)
        {
            decimal dummy;
            if (decimal.TryParse(e.NewTextValue, out dummy))
            {
                var exceededdecimal = (e.NewTextValue.Length - (e.NewTextValue.LastIndexOf('.') + 1)) > 2;
                if (dummy > MaxLength || exceededdecimal)
                    ((Entry)sender).Text = e.OldTextValue;
            }
            else
            {
                if (!string.IsNullOrEmpty(e.NewTextValue))
                    ((Entry)sender).Text = e.OldTextValue;
            }
            //if (MaxLength == 100)
            //{
            //    if (((Entry)sender).Text.Length != 0)
            //        EntryEnableProperty.IsEntryCGPA = false;
            //    else
            //        EntryEnableProperty.IsEntryCGPA = true;
            //}
            //else if (MaxLength == 10)
            //{
            //    //if (((Entry)sender).Text.Length != 0)
            //    //    EntryEnableProperty.IsEntryPercentage = false;
            //    //else
            //    //    EntryEnableProperty.IsEntryPercentage = true;
            //    //EntryEnableProperty.IsEntryPercentage = false;
            //    IsValid = false;
            //}
            
        }
        

        protected override void OnDetachingFrom(Entry bindable)
        {
            bindable.TextChanged -= bindable_TextChanged;

        }

        
    }
    public class EntryEnableProperty : BaseViewModel
    {
        private bool _isentryPercentage;

        public bool IsEntryPercentage
        {
            get { return _isentryPercentage; }
            set { _isentryPercentage = value; OnPropertyChanged(); }
        }

        private bool _isentryCGPA;

        public bool IsEntryCGPA
        {
            get { return _isentryCGPA; }
            set { _isentryCGPA = value; OnPropertyChanged(); }
        }

    }
}
