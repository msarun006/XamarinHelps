﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using HireMe.Models.Assessment;
using Plugin.Connectivity;
using HireMe.Helpers.Assessment;
using System.Threading.Tasks;
using System.Linq;
using Xamarin.Forms;
using HireMe.Models.Assessment.SQLTables;
using HireMe.Interface;
using Newtonsoft.Json;
using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.Services;

namespace HireMe.LocalDataBase
{
    public class SqliteOperations
    {
        #region  Variables Declaration
        public static LocalDB _localDB;
        private static HttpCommonService _commonservice { get; set; }
        public static List<ExamAnswersModel> ExamAnswerList { get; set; }
        public static List<ExamAnswerHistoryModel> ExamAnswersHistoryList { get; set; }
        public static List<ExamGroupModel> ExamAssignedGroupList { get; set; }
        public static List<FacialImageDetailsModel> ImageList { get; set; }
        public ExamAnswersModel _ExamAnswerData;
        public QuestionsRequestData _QuestionsDownloadRequest { get; set; }
        public EnglishQuestion _questionData { get; set; }
        public SaveImageToLocal _saveAndExtractImages { get; set; }
        #endregion

        #region Constructor
        public SqliteOperations()
        {
            _localDB = new LocalDataBase.LocalDB();
            _commonservice = new HttpCommonService();

            ExamAnswerList = new List<ExamAnswersModel>();
            ExamAnswersHistoryList = new List<ExamAnswerHistoryModel>();
            ExamAssignedGroupList = new List<ExamGroupModel>();
            _QuestionsDownloadRequest = new QuestionsRequestData();
            _questionData = new EnglishQuestion();
            _ExamAnswerData = new ExamAnswersModel();
            _saveAndExtractImages = new SaveImageToLocal();
        }
        #endregion

        #region check if any syncup data isavailable
        public bool CheckIfAnySyncupDataIsAvailable()
        {
            //var isSynced = _localDB.isRecordExistinAllTables();

            bool isSynced = true;
            try
            {
                if (_localDB.TableExists("EnglishQuestion"))
                {

                    var CheckAnswerList = _localDB.RetrieveNotSyncupAnswerList(false);
                    var CheckAnswerHistoryList = _localDB.RetrieveNotSyncupAnswerHistoryList(false);
                    var CheckExamCompletedList = _localDB.RetrieveNotSyncupExamCompletedList(false);
                    var CheckImageList = _localDB.RetriveImagesToUploadS3(false);
                    var CheckAlreadyUpdatedS3ImageList = _localDB.RetriveImagesToUploadHireMeeAssessmentServer(false);
                    //var CheckFeedbacks = _localDB.Retrive_un_syncup_feedback(false);
                    if ((CheckAnswerList != null && CheckAnswerList.Count() == 0) && (CheckAnswerHistoryList != null && CheckAnswerHistoryList.Count() == 0) && (CheckExamCompletedList != null && CheckExamCompletedList.Count() == 0) && (CheckImageList != null && CheckImageList.Count() == 0) && (CheckAlreadyUpdatedS3ImageList != null && CheckAlreadyUpdatedS3ImageList.Count() == 0))
                    {
                        isSynced = false;
                    }
                }
                else
                {
                    isSynced = false;
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                isSynced = false;
                // SendErrorMessageToServer(ex, "SqliteOperations.CheckIfAnySyncupDataIsAvailable");
            }

            return isSynced;
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        #region CheckSyncupDataExceptFacialImage
        public bool CheckSyncupDataExceptFacialImage()
        {
            //var IsSync = _localDB.isRecordExistinAllTables();

            bool isSynced = true;
            try
            {
                if (_localDB.TableExists("EnglishQuestion"))
                {
                    var CheckAnswerList = _localDB.RetrieveNotSyncupAnswerList(false);
                    var CheckAnswerHistoryList = _localDB.RetrieveNotSyncupAnswerHistoryList(false);
                    var CheckExamCompletedList = _localDB.RetrieveNotSyncupExamCompletedList(false);
                    //var CheckImageList = _localDB.RetriveImagesToUploadS3(false);
                    var CheckAlreadyUpdatedS3ImageList = _localDB.RetriveImagesToUploadHireMeeAssessmentServer(false);
                    //var CheckFeedbacks = _localDB.Retrive_un_syncup_feedback(false);
                    if ((CheckAnswerList != null && CheckAnswerList.Count() == 0) && (CheckAnswerHistoryList != null && CheckAnswerHistoryList.Count() == 0) && (CheckExamCompletedList != null && CheckExamCompletedList.Count() == 0) && (CheckAlreadyUpdatedS3ImageList != null && CheckAlreadyUpdatedS3ImageList.Count() == 0))
                    {
                        isSynced = false;
                    }
                }

                else
                {
                    isSynced = false;
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                isSynced = false;
                //SendErrorMessageToServer(ex, "SqliteOperations.CheckSyncupDataExceptFacialImage");
            }

            return isSynced;
        }
        #endregion



        #region BulkInsert Check If Any NotSyncupDataAvailable
        public async Task BulkInsert(string mode)
        {

            if (CheckSyncupDataExceptFacialImage())
            {
                await GetLocalDataAndUploadToServer(mode);
            }
            await GetFacialImagesAndUploadToS3(mode);
        }

        public async Task GetLocalDataAndUploadToServer(string mode)
        {
            try
            {

                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {
                    if (MessageStringConstants.IsAPIProcess)
                    {
                        MessageStringConstants.IsAPIProcess = false;
                        if (_localDB.TableExists("FacialImageDetailsModel") && _localDB.TableExists("ExamAnswersModel") && _localDB.TableExists("ExamAnswerHistoryModel") && _localDB.TableExists("ExamGroupModel") && _localDB.TableExists("AssignedExamModel") && _localDB.TableExists("FeedBackModelRequest"))
                        {
                            if (mode != "Auto")
                            {
                                UserDialogs.Instance.ShowLoading();
                            }
                            var bulkInsertRequest = new BulkInsertRequest();

                            ExamAnswerList = new List<ExamAnswersModel>();
                            ExamAnswersHistoryList = new List<ExamAnswerHistoryModel>();
                            ExamAssignedGroupList = new List<ExamGroupModel>();
                            ImageList = new List<FacialImageDetailsModel>();

                            ExamAnswerList = _localDB.RetrieveNotSyncupAnswerList(false).ToList();
                            ExamAnswersHistoryList = _localDB.RetrieveNotSyncupAnswerHistoryList(false).ToList();
                            ExamAssignedGroupList = _localDB.RetrieveNotSyncupExamCompletedList(false).ToList();
                            ImageList = _localDB.RetriveImagesToUploadHireMeeAssessmentServer(false).ToList();


                            AssignedExamModel AssignedExams;
                            AssignedExams = _localDB.RetrieveNotSyncupAssignedExamsList();
                            FeedBackModelRequest request = _localDB.Retrive_un_syncup_feedback(false);
                            bulkInsertRequest.ExamAnswers = ExamAnswerList;
                            bulkInsertRequest.ExamAnswersHistory = ExamAnswersHistoryList;
                            bulkInsertRequest.AssignedGroup = ExamAssignedGroupList;
                            bulkInsertRequest.AssignedExams = AssignedExams;
                            bulkInsertRequest.FacialImage = ImageList;
                            bulkInsertRequest.Feedback = request;


                            var result = await _commonservice.PostAsync<BulkInsertResponse, BulkInsertRequest>(APIData.API_BASE_URL + APIMethods.BulkInsertCopy, bulkInsertRequest);
                            if (result != null)
                            {

                                if (result.code == "200" && result.Data != null)
                                {
                                    //UserDialogs.Instance.HideLoading();
                                    if (mode != "Auto")
                                    {
                                        UserDialogs.Instance.HideLoading();
                                    }

                                    if (mode == "syncup")
                                    {
                                        if (AppPreferences.IsHindi)
                                        {
                                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.HindiDataSyncupSuccess, null, MessageStringConstants.OKHindi);
                                        }
                                        else
                                        {
                                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.DataSyncupSuccess);
                                        }

                                    }
                                    if (mode == "Manual")
                                    {
                                        if (AppPreferences.IsHindi)
                                        {
                                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.HindiSubmitExam, null, MessageStringConstants.OKHindi);
                                        }
                                        else
                                        {
                                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.SubmitExam);
                                        }
                                    }

                                    //Exam Answer Table
                                    var GetExamAnswersRecord = result.Data.ExamAnswers;
                                    foreach (var item in GetExamAnswersRecord)
                                    {
                                        var res1 = _localDB.RetrieveExamAnswerBasedonID(item.ID);
                                        foreach (var obj in res1)
                                        {
                                            obj.IsSynchedUp = true;
                                            _localDB.UpdateExamAnswer(obj);

                                        }
                                    }
                                    //var check1 = _localDB.GetAllExamAnswer();

                                    //Exam Answer History Table
                                    var GetExamAnswersHistoryRecord = result.Data.ExamAnswersHistory;
                                    foreach (var item in GetExamAnswersHistoryRecord)
                                    {
                                        var res2 = _localDB.RetrieveExamAnswerHistoryBasedonID(item.ID);
                                        foreach (var obj in res2)
                                        {
                                            obj.IsSynchedUp = true;
                                            _localDB.UpdateExamAnswerHistoryData(obj);
                                        }
                                    }

                                    //var check2 = _localDB.GetExamAnswerHistoryData();

                                    //Exam Completed Table
                                    var GetAssignedGroupRecord = result.Data.AssignedGroup;
                                    foreach (var item in GetAssignedGroupRecord)
                                    {
                                        var res3 = _localDB.RetrieveExamGroupModelBasedonID(item.ID);
                                        foreach (var obj in res3)
                                        {
                                            obj.IsSynchedUp = true;
                                            _localDB.UpdateExamCompletedData(obj);
                                        }
                                    }
                                    //var check3 = _localDB.GetAllExamCompletedData();


                                    //Exam FacialImageDetails Table
                                    var FacialImageResponse = result.Data.FacialImages;
                                    foreach (var item in FacialImageResponse)
                                    {
                                        var res4 = _localDB.RetrieveFacialImageDetailsBasedonID(item.ID);
                                        foreach (var obj in res4)
                                        {
                                            obj.IsSynchedUp = true;
                                            obj.IsUploadedInToS3 = true;
                                            _localDB.UpdateFacialImageData(obj);
                                        }
                                    }
                                    //var check4 = _localDB.GetAllFacialImageData();



                                    //Exam FeedbackModel Table
                                    var res5 = _localDB.Retrive_un_syncup_feedback(false);
                                    if (res5 != null)
                                    {
                                        res5.IsSynchedUp = true;
                                        _localDB.UpdateFeedbackModel(res5);
                                    }
                                    var check5 = _localDB.GetAllFeeback();
                                }
                                else
                                {
                                    UserDialogs.Instance.HideLoading();
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                                }
                            }
                            else if (mode != "Auto")
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                            }

                        }
                        MessageStringConstants.IsAPIProcess = true;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageStringConstants.IsAPIProcess = true;
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                //SendErrorMessageToServer(ex, "SqliteOperations.GetLocalDataAndUploadToServer");
            }
        }

        #endregion

        //#region UpdateAssignedTable 
        //void UpdateAssignedTable()
        //{
        //    try
        //    {
        //        //if all exam are finished means goto FeedbackPage otherwise SelectAndStartExamPage
        //        var res = _localDB.GetAllExamCompletedData();
        //        var completedGroupStatus = _localDB.GetCompletedGroupCount();
        //        if (res.Count() == completedGroupStatus.Count())
        //        {
        //            if (CheckIfAnySyncupDataIsAvailable())
        //            {
        //                UpdateAssignedExamCompleted("P");
        //            }
        //            else
        //            {
        //                UpdateAssignedExamCompleted("C");
        //            }
        //        }
        //        else
        //        {
        //            UpdateAssignedExamCompleted("P");
        //        }

        //    }
        //    catch (Exception e)
        //    {
        //        System.Diagnostics.Debug.WriteLine(e.Message);
        //        SendErrorMessageToServer(e, "SqliteOperations.UpdateAssignedTable");
        //    }
        //}
        //#endregion

        #region UpdateAssignedExamCompleted
        void UpdateAssignedExamCompleted(string status)
        {
            try
            {
                var item = _localDB.GetAllAssignedExamData();
                item.Status = status;
                _localDB.UpdateAssignedExamData(item);
                //var res = _localDB.GetAllAssignedExamData();

                //if (res.Count() > 0)
                //{
                //    foreach (var item in res)
                //    {
                //        item.Status = status;
                //        _localDB.UpdateAssignedExamData(item);
                //    }
                //}
                ////Checking purpose only
                //var CheckTable = _localDB.GetAllAssignedExamData();
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "SqliteOperations.UpdateAssignedExamCompleted");
            }
        }
        #endregion

        #region GetFacialImagesAndUploadToS3
        public async Task GetFacialImagesAndUploadToS3(string mode)
        {
            try
            {
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {
                    if (mode != "Auto")
                    {
                        UserDialogs.Instance.ShowLoading();
                    }

                    if (MessageStringConstants.IsSyncupProcess)
                    {
                        string _strMode = mode;
                        MessageStringConstants.IsSyncupProcess = false;

                        var FacialImages = _localDB.RetriveImagesToUploadS3(false);

                        foreach (var item in FacialImages)
                        {
                            try
                            {
                                string fileName = System.IO.Path.GetFileName("@" + item.FilePath);
                                var s3fileurl = await S3Manager.UploadFile(item.FilePath, AppPreferences.ExamID + "/" + AppPreferences.HireMeeID + "/" + fileName, AmazonS3BucketDetails.AssessmentImageBucket);
                                if (!string.IsNullOrEmpty(s3fileurl))
                                {
                                    item.IsUploadedInToS3 = true;
                                    item.IsSynchedUp = false;
                                    _localDB.UpdateFacialImageData(item);
                                }
                            }
                            catch (Exception ex)
                            {
                                item.IsUploadedInToS3 = true;
                                item.IsSynchedUp = true;
                                _localDB.UpdateFacialImageData(item);

                            }
                        }
                        MessageStringConstants.IsSyncupProcess = true;
                        if (CheckIfAnySyncupDataIsAvailable())
                        {
                            await GetLocalDataAndUploadToServer(_strMode);
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                MessageStringConstants.IsSyncupProcess = true;
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SqliteOperations.GetFacialImagesAndUploadToS3");
            }
        }
        #endregion

        #region Add CapturedFacialImage to LocalDB
        public void InsertFacialImageData(string filepath, string CapturedTime)
        {
            try
            {
                var _facialCaptureData = new FacialImageDetailsModel();
                string fileName = System.IO.Path.GetFileName("@" + filepath);
                _facialCaptureData.ImageName = fileName;
                _facialCaptureData.FilePath = filepath;
                _facialCaptureData.UpdatedDate = CapturedTime;
                _facialCaptureData.IsUploadedInToS3 = false;
                _facialCaptureData.IsSynchedUp = false;
                _facialCaptureData.AssignedID = AppPreferences.AssignedID;
                _localDB.AddFacialDetails(_facialCaptureData);
                //var FacialImageCountData = _localDB.GetAllFacialImageData();

            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SqliteOperations.InsertFacialImageData");
            }
        }
        #endregion

        #region InsertFullExamDetailsInToLocalDatabase
        public async Task InsertFullExamDetailsInToLocalDatabaseAsync(QuestionsResponseData result)
        {


            //_localDB.DeleteAllSavedData();
            //_localDB.DeleteAllExamAnswer();
            //_localDB.DeleteExamAnswerHistoryModel();
            //_localDB.DeleteAssignedExam();
            //_localDB.DeleteExamGroupModel();
            //_localDB.DeletePreviousFeedbacks();
            //_localDB.DeleteAllInsertedFacialImages();
            //DependencyService.Get<IDeleteAppData>().DeleteCapturedImageFile();


            AppPreferences.IsStartWithLogin = true;
            if (result.ServerTime != null)
            {
                AppPreferences.ServerDateTime = result.ServerTime.Ticks.ToString();
            }
            AppPreferences.ServerDate = result.ServerTime.Date.ToString("yyyy-MM-dd");
            AppPreferences.ExamTime = result.ElaspedTime;
            AppPreferences.ExamDuration = result.Duration;
            AppPreferences.ExamCenterName = result.ExamCentreName;
            AppPreferences.ExamName = result.ExamName;
            TimeSpan ExamDuration = TimeSpan.Parse(result.Duration);
            AppPreferences.ExamDurationHour = ExamDuration.Hours.ToString();
            AppPreferences.ExamDurationMinute = ExamDuration.Minutes.ToString();


            await _localDB.AddBulkData(result.EnglishQuestions);
            await _localDB.AddHindiBulkData(result.HindiQuestions);

            var imagequestion = _localDB.GetAllImageQuestion();
            var HindiImagequestion = _localDB.GetAllHindiImageQuestion();
            foreach (var item in imagequestion)
            {
                if (item.Question.Contains(".jpg") || item.Question.Contains(".jpeg") || item.Question.Contains(".png") || item.Question.Contains("gif"))
                {
                    item.Question = _saveAndExtractImages.SaveImageData(item.Question);
                }
                if (item.ChoiceA.Contains(".jpg") || item.ChoiceA.Contains(".jpeg") || item.ChoiceA.Contains(".png") || item.Question.Contains("gif"))
                {
                    item.ChoiceA = _saveAndExtractImages.SaveImageData(item.ChoiceA);
                }
                if (item.ChoiceB.Contains(".jpg") || item.ChoiceB.Contains(".jpeg") || item.ChoiceB.Contains(".png") || item.Question.Contains("gif"))
                {
                    item.ChoiceB = _saveAndExtractImages.SaveImageData(item.ChoiceB);
                }
                if (item.ChoiceC.Contains(".jpg") || item.ChoiceC.Contains(".jpeg") || item.ChoiceC.Contains(".png") || item.Question.Contains("gif"))
                {
                    item.ChoiceC = _saveAndExtractImages.SaveImageData(item.ChoiceC);
                }
                if (item.ChoiceD.Contains(".jpg") || item.ChoiceD.Contains(".jpeg") || item.ChoiceD.Contains(".png") || item.Question.Contains("gif"))
                {
                    item.ChoiceD = _saveAndExtractImages.SaveImageData(item.ChoiceD);
                }

                _localDB.UpdateQuestionsData(item);
            }

            foreach (var item in HindiImagequestion)
            {
                if (item.Question.Contains(".jpg") || item.Question.Contains(".jpeg") || item.Question.Contains(".png") || item.Question.Contains("gif"))
                {
                    item.Question = _saveAndExtractImages.SaveImageData(item.Question);
                }
                if (item.ChoiceA.Contains(".jpg") || item.ChoiceA.Contains(".jpeg") || item.ChoiceA.Contains(".png") || item.Question.Contains("gif"))
                {
                    item.ChoiceA = _saveAndExtractImages.SaveImageData(item.ChoiceA);
                }
                if (item.ChoiceB.Contains(".jpg") || item.ChoiceB.Contains(".jpeg") || item.ChoiceB.Contains(".png") || item.Question.Contains("gif"))
                {
                    item.ChoiceB = _saveAndExtractImages.SaveImageData(item.ChoiceB);
                }
                if (item.ChoiceC.Contains(".jpg") || item.ChoiceC.Contains(".jpeg") || item.ChoiceC.Contains(".png") || item.Question.Contains("gif"))
                {
                    item.ChoiceC = _saveAndExtractImages.SaveImageData(item.ChoiceC);
                }
                if (item.ChoiceD.Contains(".jpg") || item.ChoiceD.Contains(".jpeg") || item.ChoiceD.Contains(".png") || item.Question.Contains("gif"))
                {
                    item.ChoiceD = _saveAndExtractImages.SaveImageData(item.ChoiceD);
                }
                _localDB.UpdateHindiQuestionsData(item);
            }


            List<EnglishGroupDetail> objGroupDetails = new List<EnglishGroupDetail>();
            if (AppPreferences.IsHindi == true)
            {
                objGroupDetails = result.HindiGroupDetails;
            }
            else //if (AppPreferences.IsEnglish == true)
            {
                objGroupDetails = result.EnglishGroupDetails;
            }
            ExamGroupModel _ExamGroupModel;
            for (int i = 0; i < objGroupDetails.Count; i++)
            {


                _ExamGroupModel = new ExamGroupModel();
                _ExamGroupModel.AssignedID = AppPreferences.AssignedID;
                _ExamGroupModel.Status = "P";
                _ExamGroupModel.GroupID = result.EnglishGroupDetails[i].GroupID;
                _ExamGroupModel.StartTime = string.Empty;
                _ExamGroupModel.EndTime = string.Empty;
                _ExamGroupModel.IsSynchedUp = false;
                _ExamGroupModel.LastQuestionViewedPosition = 0;
                _localDB.AddExamCompletedData(_ExamGroupModel);


                objGroupDetails[i].TitleStatusColor = MessageStringConstants.NotStatedColor;
                objGroupDetails[i].QuestionGroupStatus[0].AnsweredQuestion = "0";
                objGroupDetails[i].QuestionGroupStatus[0].UnAnsweredQuestions = "0";
                objGroupDetails[i].QuestionGroupStatus[0].NotVisitedQuestions = result.EnglishGroupDetails[i].NoOfQuestions;
            }
            var serializeValue = JsonConvert.SerializeObject(objGroupDetails);
            AppPreferences.GroupDetailsSerialize = serializeValue;
            //AppPreferences.NoOfGroups = result.EnglishGroupDetails.Count().ToString() ?? string.Empty;



            // AssignedExam Insert
            AssignedExamModel _AssignedExamModel = new AssignedExamModel();
            //Replace AssignID value to ID value
            _AssignedExamModel.AssignedID = result.AssignedExams.Id.ToString();
            _AssignedExamModel.Status = result.AssignedExams.Status;
            _AssignedExamModel.AssignedDate = result.AssignedExams.AssignedDate.ToString();
            if (result.AssignedExams.ExamStartTime == null)
            {
                _AssignedExamModel.ExamStartTime = DateTime.Now.ToString();
            }
            else
            {
                _AssignedExamModel.ExamStartTime = result.AssignedExams.ExamStartTime.ToString();
            }
            if (result.AssignedExams.ExamEndTime == null)
            {
                _AssignedExamModel.ExamEndTime = DateTime.Now.ToString();

            }
            else
            {
                _AssignedExamModel.ExamEndTime = result.AssignedExams.ExamEndTime.ToString();
            }
            _AssignedExamModel.ReEvaluationStatus = result.AssignedExams.ReEvaluationStatus;
            _AssignedExamModel.LastUpdatedTime = result.AssignedExams.LastUpdatedTime;
            _AssignedExamModel.LastUpdatedQuestionID = result.AssignedExams.LastUpdatedQuestionID;
            _AssignedExamModel.ScoreUpdatedStatus = result.AssignedExams.ScoreUpdatedStatus;
            _AssignedExamModel.LastUpdatedGroupID = result.AssignedExams.LastUpdatedGroupID;
            _localDB.InsertAssignedExamData(_AssignedExamModel);

            // var CheckingPurposeOnly = _localDB.GetAllAssignedExamData();


        }
        #endregion

        #region DeleteAllLocalRecords
        public void DeleteAllLocalRecords()
        {
            _localDB.DropAllTables();

            DependencyService.Get<IDeleteAppData>().DeleteCapturedImageFile();
        }


        #endregion


    }
}
