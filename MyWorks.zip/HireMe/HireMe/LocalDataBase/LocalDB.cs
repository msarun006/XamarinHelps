﻿using HireMe.Helpers;
using HireMe.Interface;
using HireMe.Models.Assessment;
using HireMe.Models.Assessment.SQLTables;
using HireMe.Models.PRO_Assessment;
using SQLite;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Xamarin.Forms;
using static SQLite.SQLite3;

namespace HireMe.LocalDataBase
{
    public class LocalDB
    {
        private SQLiteAsyncConnection _sqlAsyncconnection;
        private SQLiteConnection _sqlconnection;
        private static readonly AsyncLock AsyncLock = new AsyncLock();
        public LocalDB()
        {
            try
            {
                var dbpath = Path.Combine(DependencyService.Get<ISQLite>().ExternalStoragePathToFile("HireMeeAssessment.db3"));
                _sqlAsyncconnection = new SQLiteAsyncConnection(dbpath);
                _sqlconnection = new SQLiteConnection(dbpath);
            }
            catch (SQLiteException ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "LocalDB.Constructor");
            }
        }

        #region Create CSR Tables
        public void CreateTables()
        {
            try
            {
                _sqlAsyncconnection.CreateTableAsync<EnglishQuestion>().Wait();
                _sqlAsyncconnection.CreateTableAsync<HindiQuestion>().Wait();
                _sqlAsyncconnection.CreateTableAsync<FacialImageDetailsModel>().Wait();
                _sqlAsyncconnection.CreateTableAsync<FeedBackModelRequest>().Wait();
                _sqlAsyncconnection.CreateTableAsync<ExamAnswersModel>().Wait();
                _sqlAsyncconnection.CreateTableAsync<ExamAnswerHistoryModel>().Wait();
                _sqlAsyncconnection.CreateTableAsync<ExamGroupModel>().Wait();
                _sqlAsyncconnection.CreateTableAsync<AssignedExamModel>().Wait();
            }
            catch (SQLiteException ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "LocalDB.CreateTables");
            }
        }
        #endregion

        #region Drop Tables
        public bool TableExists(string tablename)
        {
            const string cmdText = "SELECT name FROM sqlite_master WHERE type='table' AND name=?";
            var cmd = _sqlAsyncconnection.ExecuteScalarAsync<string>(cmdText, tablename).Result;
            return cmd != null;
        }
        public void DropAllTables()
        {
            try
            {
                AppPreferences.IsHindi = false;
                AppPreferences.IsEnglish = false;
                _sqlAsyncconnection.DropTableAsync<EnglishQuestion>();
                _sqlAsyncconnection.DropTableAsync<HindiQuestion>();
                _sqlAsyncconnection.DropTableAsync<FacialImageDetailsModel>();
                _sqlAsyncconnection.DropTableAsync<FeedBackModelRequest>();
                _sqlAsyncconnection.DropTableAsync<ExamAnswersModel>();
                _sqlAsyncconnection.DropTableAsync<ExamAnswerHistoryModel>();
                _sqlAsyncconnection.DropTableAsync<ExamGroupModel>();
                _sqlAsyncconnection.DropTableAsync<AssignedExamModel>();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }

        public void DeleteAllTables()
        {
            try
            {
                _sqlAsyncconnection.ExecuteAsync("delete from [EnglishQuestion]");
                _sqlAsyncconnection.ExecuteAsync("delete from [HindiQuestion]");
                _sqlAsyncconnection.ExecuteAsync("delete from [FacialImageDetailsModel]");
                _sqlAsyncconnection.ExecuteAsync("delete from [FeedBackModelRequest]");
                _sqlAsyncconnection.ExecuteAsync("delete from [ExamAnswersModel]");
                _sqlAsyncconnection.ExecuteAsync("delete from [ExamGroupModel]");
                _sqlAsyncconnection.ExecuteAsync("delete from [AssignedExamModel]");
                _sqlAsyncconnection.ExecuteAsync("delete from [ExamAnswerHistoryModel]");

            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        #region Questions Download Query
        //Get all 
        public List<EnglishQuestion> GetAllData()
        {
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        return _sqlAsyncconnection.QueryAsync<EnglishQuestion>("select * from [EnglishQuestion]").Result.ToList();
            //    }
            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}
            return _sqlAsyncconnection.QueryAsync<EnglishQuestion>("select * from [EnglishQuestion]").Result.ToList();
        }
        public List<HindiQuestion> GetAllHindiData()
        {

            return _sqlAsyncconnection.QueryAsync<HindiQuestion>("select * from [HindiQuestion]").Result.ToList();

        }

        //Get by Where Matched
        public List<EnglishQuestion> GetAllImageQuestion()
        {
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        return _sqlAsyncconnection.QueryAsync<EnglishQuestion>("select * from [EnglishQuestion] where IsImageQuestion = '1' ").Result.ToList();
            //    }
            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}
            return _sqlAsyncconnection.QueryAsync<EnglishQuestion>("select * from [EnglishQuestion] where IsImageQuestion = '1' ").Result.ToList();
        }
        public List<HindiQuestion> GetAllHindiImageQuestion()
        {

            return _sqlAsyncconnection.QueryAsync<HindiQuestion>("select * from [HindiQuestion] where IsImageQuestion = '1' ").Result.ToList();
        }
        public List<EnglishQuestion> GetAllHindiQuesitonsByGroupId(string GroupID)
        {
            return _sqlAsyncconnection.QueryAsync<EnglishQuestion>("select * from [HindiQuestion] where GroupID = ?", GroupID).Result.ToList();
        }

        public IEnumerable<EnglishQuestion> GetAllDataBasedOnGroupId(string GroupID)
        {
            //    try
            //    {
            //        using (await AsyncLock.LockAsync())
            //        {
            //            IEnumerable<EnglishQuestion> obj = _sqlAsyncconnection.QueryAsync<EnglishQuestion>("select * from [EnglishQuestion] where GroupID = ?", GroupID).Result.ToList();
            //            return obj;
            //        }
            //    }
            //    catch (SQLiteException sqliteException)
            //    {
            //        if (sqliteException.Result == Result.Busy ||
            //            sqliteException.Result == Result.Constraint)
            //        {
            //            // return await InsertAsync(entityList);
            //        }
            //        throw;
            //    }

            //var result = _sqlAsyncconnection.QueryAsync<EnglishQuestion>("select * from [EnglishQuestion] where GroupID = ?", GroupID).Result.ToList();


            var result = _sqlAsyncconnection.QueryAsync<EnglishQuestion>("select * from [EnglishQuestion] where GroupID = ?", GroupID).Result.ToList();
            return result;
        }


        public IEnumerable<HindiQuestion> GetAllHindiDataBasedOnGroupId(string GroupID)
        {
            //return _sqlAsyncconnection.QueryAsync<HindiQuestion>("select * from [HindiQuestion] where GroupID = ?", GroupID).Result.ToList();
            var result = _sqlAsyncconnection.QueryAsync<HindiQuestion>("select * from [HindiQuestion] where GroupID = ?", GroupID).Result.ToList();
            return result;
        }



        //Delete specific 


        public async Task<int> AddBulkData<EnglishQuestion>(List<EnglishQuestion> entityList)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    if (_sqlAsyncconnection != null) await _sqlAsyncconnection.InsertAllAsync(entityList);
                    return 1;
                }
            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    if (_sqlAsyncconnection != null) await _sqlAsyncconnection.InsertAllAsync(entityList);
                    return 1;
                }
                else
                    return 0;
                // throw;
            }
            //_sqlconnection.InsertAll(Data);
        }



        public async Task<int> AddHindiBulkData<HindiQuestion>(List<HindiQuestion> entityList)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    if (_sqlAsyncconnection != null) await _sqlAsyncconnection.InsertAllAsync(entityList);
                    return 1;
                }
            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    if (_sqlAsyncconnection != null) await _sqlAsyncconnection.InsertAllAsync(entityList);
                    return 1;
                }
                throw;
            }
            //_sqlAsyncconnection.InsertAll(Data);
        }


        //public async Task<int> AddBulkData(List<EnglishQuestion> Data)
        //{
        //    try
        //    {
        //        using (await AsyncLock())
        //        {
        //            if (_sqlconnection != null) await _sqlconnection.InsertAllAsync(Data);
        //           return 1;
        //        }
        //    }
        //    catch (SQLiteException sqliteException)
        //    {
        //        if (sqliteException.Result == Result.Busy ||
        //            sqliteException.Result == Result.Constraint)
        //        {
        //            //await _sqlconnection.InsertAllAsync(Data);
        //            return await InsertAsync(Data);
        //        }
        //        //throw;
        //    }

        //}

        //Update specific 
        public async void UpdateQuestionsData(EnglishQuestion Data)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    await _sqlAsyncconnection.UpdateAsync(Data);
                }
            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    await _sqlAsyncconnection.UpdateAsync(Data);
                }
                throw;
            }
            // _sqlconnection.UpdateAsync(Data);
        }

        public async void UpdateHindiQuestionsData(HindiQuestion Data)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    await _sqlAsyncconnection.UpdateAsync(Data);
                }
            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    await _sqlAsyncconnection.UpdateAsync(Data);
                }
                //throw;
            }
            // _sqlAsyncconnection.UpdateAsync(Data);
        }

        //Count the Data in LocalDB
        public int CountRecords()
        {
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        int rowCount;
            //        rowCount = _sqlAsyncconnection.Table<EnglishQuestion>().CountAsync().Result;
            //        return rowCount;
            //    }
            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}
            int rowCount;
            rowCount = _sqlAsyncconnection.Table<EnglishQuestion>().CountAsync().Result;
            return rowCount;
        }
        #endregion

        #region Exam Answer Query
        //Get all 
        public async Task<List<ExamAnswersModel>> GetAllExamAnswer()
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    return _sqlAsyncconnection.QueryAsync<ExamAnswersModel>("select * from [ExamAnswersModel] ").Result.ToList();
                }
            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    return _sqlAsyncconnection.QueryAsync<ExamAnswersModel>("select * from [ExamAnswersModel] ").Result.ToList();
                }
                else
                    return null;
                //throw;
            }

            //  return _sqlconnection.QueryAsync<ExamAnswersModel>("select * from [ExamAnswersModel] ").Result.ToList();
        }



        //Update isSynchUP Column based on ID
        public async void UpdateExamAnswersModelIsSynchUpBasedonID(int id)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    if (_sqlAsyncconnection != null)
                        await _sqlAsyncconnection.QueryAsync<ExamAnswersModel>("UPDATE [ExamAnswersModel] SET IsSynchedUp = 'true' WHERE ID = ?", id);
                }
            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    // return await InsertAsync(entityList);
                }
                throw;
            }
            // _sqlconnection.QueryAsync<ExamAnswersModel>("UPDATE [ExamAnswersModel] SET IsSynchedUp = 'true' WHERE ID = ?", id);  
        }





        public List<ExamAnswersModel> RetrieveNotSyncupAnswerList(bool IsSynchedUp)
        {
            try
            {

                return _sqlAsyncconnection.QueryAsync<ExamAnswersModel>("select * from [ExamAnswersModel] where IsSynchedUp = ?", IsSynchedUp).Result.ToList();


            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    return _sqlAsyncconnection.QueryAsync<ExamAnswersModel>("select * from [ExamAnswersModel] where IsSynchedUp = ?", IsSynchedUp).Result.ToList();
                }
                else
                    return null;
                //throw;
            }

            //return _sqlAsyncconnection.QueryAsync<ExamAnswersModel>("select * from [ExamAnswersModel] where IsSynchedUp = ?", IsSynchedUp).Result.ToList();
        }



        public List<ExamAnswersModel> RetrieveExamAnswerBasedonID(int ID)
        {
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        return _sqlAsyncconnection.QueryAsync<ExamAnswersModel>("select * from [ExamAnswersModel] where ID = ?", ID).Result.ToList();
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}
            return _sqlAsyncconnection.QueryAsync<ExamAnswersModel>("select * from [ExamAnswersModel] where ID = ?", ID).Result.ToList();
        }


        public List<ExamAnswersModel> GetAllAnswerBasedOnQuestionId(string QuestionID)
        {
            return _sqlAsyncconnection.QueryAsync<ExamAnswersModel>("select * from [ExamAnswersModel] where QuestionID = ?", QuestionID).Result.ToList();
        }
        public async Task<List<ExamAnswersModel>> GetAllExamAnswerBasedOnGroupId(string GroupID)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    return _sqlAsyncconnection.QueryAsync<ExamAnswersModel>("select * from [EnglishQuestion] where GroupID = ?", GroupID).Result.ToList();
                }

            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    // return await InsertAsync(entityList);
                }
                throw;
            }
            //   return _sqlconnection.QueryAsync<ExamAnswersModel>("select * from [EnglishQuestion] where GroupID = ?", GroupID).Result.ToList();
        }


        public int ExamAnswerCount()
        {
            int rowCount;
            return rowCount = _sqlAsyncconnection.Table<ExamAnswersModel>().CountAsync().Result;
        }





        //Add new to DB  
        public async void AddExamAnswer(ExamAnswersModel Data)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    await _sqlAsyncconnection.InsertAsync(Data);
                }

            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    await _sqlAsyncconnection.InsertAsync(Data);
                }
                throw;
            }
            //   _sqlconnection.InsertAsync(Data);
        }

        //Check GroupId Exist or Not
        public List<ExamAnswersModel> IsGroupAlreadyExist(string groupId)
        {
            // return _sqlconnection.Query<ExamAnswersModel>("select * from [ExamAnswersModel] where GroupId = ?", GroupId).ToList();

            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        return _sqlAsyncconnection.QueryAsync<ExamAnswersModel>("select * from [ExamAnswersModel] where GroupId = '" + groupId + "'").Result.ToList();
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}



            return _sqlAsyncconnection.QueryAsync<ExamAnswersModel>("select * from [ExamAnswersModel] where GroupId = '" + groupId + "'").Result.ToList();
        }



        //Update specific 
        public async void UpdateExamAnswer(ExamAnswersModel Data)
        {

            try
            {
                using (await AsyncLock.LockAsync())
                {
                    if (Data.ID != 0)
                        await _sqlAsyncconnection.UpdateAsync(Data);
                    else
                        await _sqlAsyncconnection.InsertAsync(Data);
                }

            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    if (Data.ID != 0)
                        await _sqlAsyncconnection.UpdateAsync(Data);
                    else
                        await _sqlAsyncconnection.InsertAsync(Data);
                }
                throw;
            }
            //  _sqlconnection.UpdateAsync(Data);
        }


        public List<ExamAnswersModel> UpdateUserAnsweredTable(int questionID)
        {
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        return _sqlAsyncconnection.QueryAsync<ExamAnswersModel>("select * from [ExamAnswersModel] where QuestionID = ?", questionID).Result.ToList();
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        return _sqlAsyncconnection.QueryAsync<ExamAnswersModel>("select * from [ExamAnswersModel] where QuestionID = ?", questionID).Result.ToList();
            //    }
            //    throw;
            //}
            return _sqlAsyncconnection.QueryAsync<ExamAnswersModel>("select * from [ExamAnswersModel] where QuestionID = ?", questionID).Result.ToList();
        }


        public List<ExamAnswersModel> GetAnsweredStatus(string groupId, string status)
        {
            // return _sqlconnection.Query<ExamAnswersModel>("select * from [ExamAnswersModel] where GroupId = ?", GroupId).ToList();
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        return _sqlAsyncconnection.QueryAsync<ExamAnswersModel>("select * from [ExamAnswersModel] where GroupId = '" + groupId + "' AND Status = '" + status + "'").Result.ToList();
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}
            return _sqlAsyncconnection.QueryAsync<ExamAnswersModel>("select * from [ExamAnswersModel] where GroupId = '" + groupId + "' AND Status = '" + status + "'").Result.ToList();
        }



        //#region CheckUserAlreadyAnsweredOrNot
        //public bool CheckUserAlreadyAnsweredOrNot(int questionID)
        //{
        //    bool isContainQuestionID = false;
        //    var value = _sqlconnection.Table<ExamAnswersModel>().Where(x => x.QuestionID == questionID).SingleOrDefault();
        //    // var a= _sqlconnection.Table<ExamAnswersModel>().FirstOrDefault( x => x.QuestionID == questionID);
        //    if (value != null)
        //    {
        //        isContainQuestionID = true;
        //    }
        //    return isContainQuestionID;
        //}
        //#endregion

        #region GetSelectedAnswerIfAlreadyAnswered
        public ExamAnswersModel GetSelectedAnswerIfAlreadyAnswered(int questionID)
        {
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        return _sqlAsyncconnection.QueryAsync<ExamAnswersModel>("select * from [ExamAnswersModel] where QuestionID = ?", questionID).Result.FirstOrDefault();
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}

            return _sqlAsyncconnection.QueryAsync<ExamAnswersModel>("select * from [ExamAnswersModel] where QuestionID = ?", questionID).Result.FirstOrDefault();

            //var value = _sqlconnection.Table<ExamAnswersModel>().Where(x => x.QuestionID == questionID).SingleOrDefault();
            //// var a= _sqlconnection.Table<ExamAnswersModel>().FirstOrDefault( x => x.QuestionID == questionID);
            //if (value != null)
            //{
            //    return value;
            //}
            //return null;
        }
        #endregion


        //Delete All Data from Table
        //public async void DeleteAllExamAnswer()
        //{
        //    try
        //    {
        //        using (await AsyncLock.LockAsync())
        //        {
        //            await _sqlAsyncconnection.DeleteAllAsync<ExamAnswersModel>();
        //        }

        //    }
        //    catch (SQLiteException sqliteException)
        //    {
        //        if (sqliteException.Result == Result.Busy ||
        //            sqliteException.Result == Result.Constraint)
        //        {
        //            await _sqlAsyncconnection.DeleteAllAsync<ExamAnswersModel>();
        //        }
        //        throw;
        //    }

        //}


        #endregion

        #region Exam Answer History
        public async void AddExamAnswerHistoryData(ExamAnswerHistoryModel Data)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    await _sqlAsyncconnection.InsertAsync(Data);
                }

            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    // return await InsertAsync(entityList);
                }
                throw;
            }

        }


        //Update isSynchUP Column based on ID
        public async void UpdateExamAnswerHistoryModelIsSynchUpBasedonID(int id)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    await _sqlAsyncconnection.QueryAsync<ExamAnswerHistoryModel>("UPDATE [ExamAnswerHistoryModel] SET IsSynchedUp = 'true' WHERE ID = ?", id);
                }

            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    await _sqlAsyncconnection.QueryAsync<ExamAnswerHistoryModel>("UPDATE [ExamAnswerHistoryModel] SET IsSynchedUp = 'true' WHERE ID = ?", id);
                }
                throw;
            }
            // _sqlconnection.QueryAsync<ExamAnswerHistoryModel>("UPDATE [ExamAnswerHistoryModel] SET IsSynchedUp = 'true' WHERE ID = ?", id);
        }

        public bool isRecordExistinAllTables()
        {
            bool isRecordExist = false;
            try
            // var rows =  (_sqlAsyncconnection.Table<ExamAnswerHistoryModel>().CountAsync().Result==0)?false:true;
            {
                bool IsExamAnswerHistoryModelExist = false;
                if (TableExists("AssignedExamModel"))
                {
                    //string cmdText = "select count(*) name from [ExamAnswerHistoryModel] where IsSynchedUp='false'";
                    var rows = _sqlAsyncconnection.Table<ExamAnswerHistoryModel>().CountAsync().Result;
                    if (rows != 0)
                        IsExamAnswerHistoryModelExist = true;
                    //bool IsExamAnswerHistoryModelExist = (_sqlAsyncconnection.Table<ExamAnswerHistoryModel>().CountAsync().Result == 0) ? false : true;
                    //cmdText = "select count(*) name from [AssignedExamModel] where IsSynchedUp='false'";
                    bool IsAssignedExamModelExist = (_sqlAsyncconnection.Table<AssignedExamModel>().CountAsync().Result == 0) ? false : true;
                    //cmdText = "select count(*) name from [ExamAnswersModel] where IsSynchedUp='false'";
                    bool IsExamAnswersModelExist = (_sqlAsyncconnection.Table<ExamAnswersModel>().CountAsync().Result == 0) ? false : true;
                    //cmdText = "select count(*) name from [ExamGroupModel] where IsSynchedUp='false'";
                    bool IsExamGroupModelExist = (_sqlAsyncconnection.Table<ExamGroupModel>().CountAsync().Result == 0) ? false : true;
                    //cmdText = "select count(*) name from [FacialImageDetailsModel] where IsSynchedUp='false'";
                    bool IsFacialImageDetailsModelExist = (_sqlAsyncconnection.Table<FacialImageDetailsModel>().CountAsync().Result == 0) ? false : true;
                    //cmdText = "select count(*) name from [FeedBackModelRequest] where IsSynchedUp='false'";
                    bool IsFeedbackModelExist = (_sqlAsyncconnection.Table<FeedBackModelRequest>().CountAsync().Result == 0) ? false : true;
                    if (IsExamAnswerHistoryModelExist && IsAssignedExamModelExist && IsExamAnswersModelExist && IsExamGroupModelExist && IsFeedbackModelExist && IsFacialImageDetailsModelExist)
                    {
                        isRecordExist = true;
                    }
                }


            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "LocalDB.isRecordExistinAllTables");
            }

            return isRecordExist;

        }
        public List<ExamAnswerHistoryModel> RetrieveExamAnswerHistoryBasedonID(int ID)
        {
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //      return _sqlAsyncconnection.QueryAsync<ExamAnswerHistoryModel>("select * from [ExamAnswerHistoryModel] where ID = ?", ID).Result.ToList();
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}
            return _sqlAsyncconnection.QueryAsync<ExamAnswerHistoryModel>("select * from [ExamAnswerHistoryModel] where ID = ?", ID).Result.ToList();
        }


        public List<ExamAnswerHistoryModel> RetrieveNotSyncupAnswerHistoryList(bool IsSynchedUp)
        {
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        return _sqlAsyncconnection.QueryAsync<ExamAnswerHistoryModel>("select * from [ExamAnswerHistoryModel] where IsSynchedUp = ?", IsSynchedUp).Result.ToList();
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}
            return _sqlAsyncconnection.QueryAsync<ExamAnswerHistoryModel>("select * from [ExamAnswerHistoryModel] where IsSynchedUp = ?", IsSynchedUp).Result.ToList();
        }

        public List<ExamAnswerHistoryModel> GetExamAnswerHistoryData()
        {
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        return _sqlAsyncconnection.QueryAsync<ExamAnswerHistoryModel>("select * from [ExamAnswerHistoryModel] ").Result.ToList();
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}
            return _sqlAsyncconnection.QueryAsync<ExamAnswerHistoryModel>("select * from [ExamAnswerHistoryModel] ").Result.ToList();


        }
        public List<ExamAnswerHistoryModel> CheckQuestionIdIsAlreadyExist(string QuestionID)
        {
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        return _sqlAsyncconnection.QueryAsync<ExamAnswerHistoryModel>("select * from [ExamAnswerHistoryModel] where QuestionID = ?", QuestionID).Result.ToList();
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}
            return _sqlAsyncconnection.QueryAsync<ExamAnswerHistoryModel>("select * from [ExamAnswerHistoryModel] where QuestionID = ?", QuestionID).Result.ToList();
        }

        //Update specific 
        public async void UpdateExamAnswerHistoryData(ExamAnswerHistoryModel Data)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    await _sqlAsyncconnection.UpdateAsync(Data);
                }

            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    await _sqlAsyncconnection.UpdateAsync(Data);
                }
                throw;
            }
            // _sqlconnection.UpdateAsync(Data);
        }

        //public async void DeleteExamAnswerHistoryModel()
        //{
        //    try
        //    {
        //        using (await AsyncLock.LockAsync())
        //        {
        //            await _sqlAsyncconnection.DeleteAllAsync<ExamAnswerHistoryModel>();
        //        }

        //    }
        //    catch (SQLiteException sqliteException)
        //    {
        //        if (sqliteException.Result == Result.Busy ||
        //            sqliteException.Result == Result.Constraint)
        //        {
        //            await _sqlAsyncconnection.DeleteAllAsync<ExamAnswerHistoryModel>();
        //        }
        //        throw;
        //    }
        //    // _sqlconnection.DeleteAllAsync<ExamAnswerHistoryModel>();
        //}





        #endregion

        #region ExamGroupModel
        public async void AddExamCompletedData(ExamGroupModel Data)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    await _sqlAsyncconnection.InsertAsync(Data);
                }

            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    await _sqlAsyncconnection.InsertAsync(Data);
                }
                throw;
            }
            // _sqlconnection.InsertAsync(Data);
        }


        //Update isSynchUP Column based on ID
        public async void UpdateExamGroupModelIsSynchUpBasedonID(int id)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    await _sqlAsyncconnection.QueryAsync<ExamGroupModel>("UPDATE [ExamGroupModel] SET IsSynchedUp = 'true' WHERE ID = ?", id);
                }

            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    await _sqlAsyncconnection.QueryAsync<ExamGroupModel>("UPDATE [ExamGroupModel] SET IsSynchedUp = 'true' WHERE ID = ?", id);
                }
                throw;
            }
            //_sqlconnection.QueryAsync<ExamGroupModel>("UPDATE [ExamGroupModel] SET IsSynchedUp = 'true' WHERE ID = ?", id);
        }

        public List<ExamGroupModel> RetrieveExamGroupModelBasedonID(int ID)
        {
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        return _sqlAsyncconnection.QueryAsync<ExamGroupModel>("select * from [ExamGroupModel] where ID = ?", ID).Result.ToList();
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}
            return _sqlAsyncconnection.QueryAsync<ExamGroupModel>("select * from [ExamGroupModel] where ID = ?", ID).Result.ToList();
        }


        public List<ExamGroupModel> RetrieveNotSyncupExamCompletedList(bool IsSynchedUp)
        {
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        return _sqlAsyncconnection.QueryAsync<ExamGroupModel>("select * from [ExamGroupModel] where IsSynchedUp = ?", IsSynchedUp).Result.ToList();
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}
            return _sqlAsyncconnection.QueryAsync<ExamGroupModel>("select * from [ExamGroupModel] where IsSynchedUp = ?", IsSynchedUp).Result.ToList();
        }

        public List<ExamGroupModel> GetAllExamCompletedData()
        {
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //          return _sqlAsyncconnection.QueryAsync<ExamGroupModel>("select * from [ExamGroupModel]").Result.ToList();
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}
            return _sqlAsyncconnection.QueryAsync<ExamGroupModel>("select * from [ExamGroupModel]").Result.ToList();

        }

        public ExamGroupModel CheckGroupIdIsAlreadyPresentInExamCompletedTable(string GroupID)
        {
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        return _sqlAsyncconnection.QueryAsync<ExamGroupModel>("select * from [ExamGroupModel] where GroupID = ?", GroupID).Result.ToList();
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}
            return _sqlAsyncconnection.QueryAsync<ExamGroupModel>("select * from [ExamGroupModel] where GroupID = ?", GroupID).Result.FirstOrDefault();
        }

        public List<ExamGroupModel> GetCompletedGroupCount()
        {
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        return _sqlAsyncconnection.QueryAsync<ExamGroupModel>("select * from [ExamGroupModel] where Status = ?", "C").Result.ToList();
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}
            return _sqlAsyncconnection.QueryAsync<ExamGroupModel>("select * from [ExamGroupModel] where Status = ?", "C").Result.ToList();
        }

        public async void UpdateExamCompletedData(ExamGroupModel Data)
        {
            try
            {
                await _sqlAsyncconnection.UpdateAsync(Data);
                //using (await AsyncLock.LockAsync())
                //{
                //    await _sqlAsyncconnection.UpdateAsync(Data);
                //}

            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    await _sqlAsyncconnection.UpdateAsync(Data);
                }
                throw;
            }
            //  _sqlconnection.UpdateAsync(Data);
        }


        #region AssignedExamModel
        //public async void AddAssignedExamData(AssignedExamModel Data)
        //{
        //    try
        //    {
        //        using (await AsyncLock.LockAsync())
        //        {
        //            await _sqlAsyncconnection.InsertAsync(Data);
        //        }

        //    }
        //    catch (SQLiteException sqliteException)
        //    {
        //        if (sqliteException.Result == Result.Busy ||
        //            sqliteException.Result == Result.Constraint)
        //        {
        //            await _sqlAsyncconnection.InsertAsync(Data);
        //        }
        //        throw;
        //    }
        //    //   _sqlconnection.InsertAsync(Data);
        //}


        //public List<AssignedExamModel> RetrieveNotSyncupAssignedExamsList()
        //{
        //    return _sqlconnection.Query<AssignedExamModel>("select * from [AssignedExamModel]").ToList();
        //}

        #endregion
        public AssignedExamModel RetrieveNotSyncupAssignedExamsList()
        {
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        var result = _sqlAsyncconnection.QueryAsync<AssignedExamModel>("select * from [AssignedExamModel]").Result.ToList();
            //        AssignedExamModel assignedExamModel = result[0];
            //        return assignedExamModel;
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}

            var assignedExamModel = _sqlAsyncconnection.QueryAsync<AssignedExamModel>("select * from [AssignedExamModel]").Result.FirstOrDefault();

            return assignedExamModel;
        }

        public AssignedExamModel GetAllAssignedExamData()
        {
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        return _sqlAsyncconnection.QueryAsync<AssignedExamModel>("select * from [AssignedExamModel]").Result.ToList();
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}
            return _sqlAsyncconnection.QueryAsync<AssignedExamModel>("select * from [AssignedExamModel]").Result.FirstOrDefault();
        }

        public async void UpdateAssignedExamData(AssignedExamModel Data)
        {
            try
            {

                await _sqlAsyncconnection.UpdateAsync(Data);
                //using (await AsyncLock.LockAsync())
                //{





                //}

            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    await _sqlAsyncconnection.UpdateAsync(Data);
                }
                throw;
            }

            //  _sqlconnection.UpdateAsync(Data);
        }

        public async void InsertAssignedExamData(AssignedExamModel Data)
        {
            try
            {


                using (await AsyncLock.LockAsync())
                {


                    await _sqlAsyncconnection.InsertAsync(Data);


                }

            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    await _sqlAsyncconnection.UpdateAsync(Data);
                }
                throw;
            }

            //  _sqlconnection.UpdateAsync(Data);
        }
        #endregion

        #region FacialImage CaptureUpdate Query
        //Add new to DB  
        public async void AddFacialDetails(FacialImageDetailsModel Data)
        {
            //  _sqlconnection.InsertAsync(Data);

            try
            {
                using (await AsyncLock.LockAsync())
                {
                    await _sqlAsyncconnection.InsertAsync(Data);
                }

            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    await _sqlAsyncconnection.InsertAsync(Data);
                }
                throw;
            }
        }



        //Get by Where Matched
        public List<FacialImageDetailsModel> Retrive_by_filePath(string filepath)
        {
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        return _sqlAsyncconnection.QueryAsync<FacialImageDetailsModel>("select * from [FacialImageDetailsModel] where ImageName = ?", filepath).Result.ToList();
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}
            return _sqlAsyncconnection.QueryAsync<FacialImageDetailsModel>("select * from [FacialImageDetailsModel] where ImageName = ?", filepath).Result.ToList();
        }

        //Delete specific 


        //Update specific 
        public async void UpdateFacialImageData(FacialImageDetailsModel Data)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    await _sqlAsyncconnection.UpdateAsync(Data);
                }

            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    await _sqlAsyncconnection.UpdateAsync(Data);
                }
                throw;
            }
            // _sqlconnection.UpdateAsync(Data);
        }


        //Get by Where Matched
        public async Task<List<FacialImageDetailsModel>> Update_by_filepath(string filepath)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    return _sqlAsyncconnection.QueryAsync<FacialImageDetailsModel>("UPDATE [FacialImageDetailsModel] SET IsUploadedInToS3 = 'true' WHERE ImageName = ?", filepath).Result.ToList();
                }

            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    return _sqlAsyncconnection.QueryAsync<FacialImageDetailsModel>("UPDATE [FacialImageDetailsModel] SET IsUploadedInToS3 = 'true' WHERE ImageName = ?", filepath).Result.ToList();

                }
                throw;
            }
            //  return _sqlconnection.QueryAsync<FacialImageDetailsModel>("UPDATE [FacialImageDetailsModel] SET IsUploadedInToS3 = 'true' WHERE ImageName = ?", filepath).Result.ToList();
        }



        //Get all 
        public List<FacialImageDetailsModel> GetAllFacialImageData()
        {
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        return _sqlAsyncconnection.QueryAsync<FacialImageDetailsModel>("select * from [FacialImageDetailsModel]").Result.ToList();
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}

            return _sqlAsyncconnection.QueryAsync<FacialImageDetailsModel>("select * from [FacialImageDetailsModel]").Result.ToList();

        }



        //Get by Where Matched
        public List<FacialImageDetailsModel> RetriveImagesToUploadS3(bool UploadState)
        {
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        return _sqlAsyncconnection.QueryAsync<FacialImageDetailsModel>("select * from [FacialImageDetailsModel] where IsUploadedInToS3 = ?", UploadState).Result.ToList();
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}
            return _sqlAsyncconnection.QueryAsync<FacialImageDetailsModel>("select * from [FacialImageDetailsModel] where IsUploadedInToS3 = ? LIMIT 100", UploadState).Result.ToList();
        }

        //Get by Where Matched
        public List<FacialImageDetailsModel> RetriveImagesToUploadHireMeeAssessmentServer(bool UploadState)
        {
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        return _sqlAsyncconnection.QueryAsync<FacialImageDetailsModel>("select * from [FacialImageDetailsModel] where IsUploadedInToS3 = '1' AND IsSynchedUp = ?", UploadState).Result.ToList();
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}
            return _sqlAsyncconnection.QueryAsync<FacialImageDetailsModel>("select ID,AssignedID,IsUploadedInToS3,ImageName,UpdatedDate,IsSynchedUp from [FacialImageDetailsModel] where IsUploadedInToS3 = '1' AND IsSynchedUp = ?", UploadState).Result.ToList();
        }


        public List<FacialImageDetailsModel> RetrieveFacialImageDetailsBasedonID(int ID)
        {

            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        return _sqlAsyncconnection.QueryAsync<FacialImageDetailsModel>("select * from [FacialImageDetailsModel] where ID = ?", ID).Result.ToList();
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}
            return _sqlAsyncconnection.QueryAsync<FacialImageDetailsModel>("select * from [FacialImageDetailsModel] where ID = ?", ID).Result.ToList();
        }

        #endregion

        #region Feedback Data Query
        //Add new to DB  
        //public async void AddFeedbackDetails(FeedBackModelRequest Data)
        //{
        //    try
        //    {
        //        using (await AsyncLock.LockAsync())
        //        {
        //            await _sqlAsyncconnection.InsertAsync(Data);
        //        }

        //    }
        //    catch (SQLiteException sqliteException)
        //    {
        //        if (sqliteException.Result == Result.Busy ||
        //            sqliteException.Result == Result.Constraint)
        //        {
        //            await _sqlAsyncconnection.InsertAsync(Data);
        //        }
        //        throw;
        //    }
        //    //  _sqlconnection.InsertAsync(Data);
        //}

        //Get all 
        public FeedBackModelRequest GetAllFeeback()
        {

            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        return _sqlAsyncconnection.QueryAsync<FeedBackModelRequest>("select * from [FeedBackModelRequest]").Result.ToList();
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}
            return _sqlAsyncconnection.QueryAsync<FeedBackModelRequest>("select * from [FeedBackModelRequest]").Result.FirstOrDefault();


        }

        //Get by Where Matched
        public FeedBackModelRequest Retrive_un_syncup_feedback(bool SyncUpState)
        {
            //try
            //{
            //    using (await AsyncLock.LockAsync())
            //    {
            //        return _sqlAsyncconnection.QueryAsync<FeedBackModelRequest>("select * from [FeedBackModelRequest] where IsSynchedUp = ?", SyncUpState).Result.ToList();
            //    }

            //}
            //catch (SQLiteException sqliteException)
            //{
            //    if (sqliteException.Result == Result.Busy ||
            //        sqliteException.Result == Result.Constraint)
            //    {
            //        // return await InsertAsync(entityList);
            //    }
            //    throw;
            //}
            return _sqlAsyncconnection.QueryAsync<FeedBackModelRequest>("select * from [FeedBackModelRequest] where IsSynchedUp = ?", SyncUpState).Result.FirstOrDefault();
        }

        //Get Count


        //Update specific 
        public async void UpdateFeedbackModel(FeedBackModelRequest Data)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    if (Data.ID != 0)
                    {
                        await _sqlAsyncconnection.UpdateAsync(Data);
                    }
                    else
                    {
                        await _sqlAsyncconnection.InsertAsync(Data);
                    }

                }
            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    await _sqlAsyncconnection.UpdateAsync(Data);
                }
                throw;
            }
            //  _sqlconnection.UpdateAsync(Data);
        }
        #endregion


        #region PRO Assessment Database works.

        #region DropAllPROTables
        public void DropAllPROTables()
        {
            try
            {
                //_sqlAsyncconnection.DropTableAsync<tbl_timer>();
                //_sqlAsyncconnection.DropTableAsync<ExamQuestions>();
                //_sqlAsyncconnection.DropTableAsync<Exam_Question_Options>();
                //_sqlAsyncconnection.DropTableAsync<Exam_Sub_Questions>();
                //_sqlAsyncconnection.DropTableAsync<AssessmentAnswer>();
                _sqlconnection.DropTable<tbl_timer>();
                _sqlconnection.DropTable<ExamQuestions>();
                _sqlconnection.DropTable<Exam_Question_Options>();
                _sqlconnection.DropTable<Exam_Sub_Questions>();
                _sqlconnection.DropTable<AssessmentAnswer>();
            }
            catch (SQLiteException ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "LocalDB.DropAllPROTables");
            }
        }
        #endregion


        #region Create PRO Tables
        public void DeletePROTables()
        {
            try
            {
                _sqlAsyncconnection.ExecuteAsync("delete from [tbl_timer]");
                _sqlAsyncconnection.ExecuteAsync("delete from [ExamQuestions]");
                _sqlAsyncconnection.ExecuteAsync("delete from [Exam_Question_Options]");
                _sqlAsyncconnection.ExecuteAsync("delete from [Exam_Sub_Questions]");
                _sqlAsyncconnection.ExecuteAsync("delete from [AssessmentAnswer]");
            }
            catch (SQLiteException ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "LocalDB.DeletePROTables");
            }
        }
        #endregion



        #region Create PRO Tables
        public void CreatePROTables()
        {
            try
            {
                //_sqlAsyncconnection.CreateTableAsync<tbl_timer>().Wait();
                //_sqlAsyncconnection.CreateTableAsync<ExamQuestions>().Wait();
                //_sqlAsyncconnection.CreateTableAsync<Exam_Question_Options>().Wait();
                //_sqlAsyncconnection.CreateTableAsync<Exam_Sub_Questions>().Wait();
                //_sqlAsyncconnection.CreateTableAsync<AssessmentAnswer>().Wait();
                _sqlconnection.CreateTable<tbl_timer>();
                _sqlconnection.CreateTable<ExamQuestions>();
                _sqlconnection.CreateTable<Exam_Question_Options>();
                _sqlconnection.CreateTable<Exam_Sub_Questions>();
                _sqlconnection.CreateTable<AssessmentAnswer>();
            }
            catch (SQLiteException ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "LocalDB.CreatePROTables");
            }
        }
        #endregion

        #region Add PRO Section details
        public async Task<int> AddPROSectionTimerDetails<tbl_timer>(List<tbl_timer> entityList)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    if (_sqlAsyncconnection != null) await _sqlAsyncconnection.InsertAllAsync(entityList);
                    return 1;
                }
            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    if (_sqlAsyncconnection != null) await _sqlAsyncconnection.InsertAllAsync(entityList);
                    return 1;
                }
                else
                    return 0;
                // throw;
            }
        }
        #endregion

        #region Get Section Start and End Time by section ID
        public tbl_timer GetPROSectionDetailsByID(int ID)
        {
            return _sqlAsyncconnection.QueryAsync<tbl_timer>("select * from [tbl_timer] where ID =" + ID + "").Result.FirstOrDefault();
        }


        public tbl_timer GetPROSectionTimerBySectionID(string sectionID)
        {
            return _sqlAsyncconnection.QueryAsync<tbl_timer>("select * from [tbl_timer] where section_id ='" + sectionID + "'").Result.FirstOrDefault();
        }
        #endregion
         

        #region Get Overall Section list
        public List<tbl_timer> GetAllPROSectionTimerList()
        {
            return _sqlAsyncconnection.QueryAsync<tbl_timer>("select * from [tbl_timer]").Result.ToList();
        }

        public List<tbl_timer> GetCompletedCount()
        {
            return _sqlAsyncconnection.QueryAsync<tbl_timer>("select * from [tbl_timer] where examstatus ='C'").Result.ToList();
        }
        public List<tbl_timer> GetElapsedCount()
        {
            return _sqlAsyncconnection.QueryAsync<tbl_timer>("select * from [tbl_timer] where examstatus ='E'").Result.ToList();
        }
        #endregion

        #region Update Section Time
        //public void UpdateTimerForFullExam(int ID, string elapsed_time, string examstatus)
        //{
        //    _sqlAsyncconnection.QueryAsync<tbl_timer>("update [tbl_timer] set examstatus = '" + examstatus + "' , elapsed_time = '" + elapsed_time + "' where ID =" + ID + "");
        //}

        //public void UpdateSectionTimer(string sectionid, string elapsed_time , string examstatus)
        //{
        //    _sqlAsyncconnection.QueryAsync<tbl_timer>("update [tbl_timer] set examstatus = '" + examstatus + "' , elapsed_time = '" + elapsed_time + "' WHERE section_id = '" + sectionid + "'");
        //}
      
        public void UpdateSectionTimerByID(int ID, string elapsed_time)
        {
            _sqlAsyncconnection.QueryAsync<tbl_timer>("update [tbl_timer] set  elapsed_time = '" + elapsed_time + "'  where ID =" + ID + "");
        }

        public void UpdateSectionStatusBySectionid(string sectionid,string examstatus)
        {
            _sqlAsyncconnection.QueryAsync<tbl_timer>("update [tbl_timer] set examstatus = '" + examstatus + "'  WHERE section_id = '" + sectionid + "' and examstatus!='C'");
        }
        public void UpdateSectionStatusBySectionid(string sectionid, string examstatus,string start_time)
        {
           _sqlAsyncconnection.QueryAsync<tbl_timer>("update [tbl_timer] set examstatus = '" + examstatus + "',starttime = '" + start_time + "'  WHERE section_id = '" + sectionid + "' and examstatus!='E'");
          //  _sqlAsyncconnection.QueryAsync<tbl_timer>("update [tbl_timer] set examstatus = '" + examstatus + "',starttime = '" + start_time + "'  WHERE section_id = '" + sectionid + "'");
        }
        public void UpdateSectionStatusEndTimeBySectionid(string sectionid, string examstatus, string end_time,string elapsed_time)
        {
             _sqlAsyncconnection.QueryAsync<tbl_timer>("update [tbl_timer] set examstatus = '" + examstatus + "',endtime = '" + end_time + "',elapsed_time = '" + elapsed_time + "' WHERE section_id = '" + sectionid + "' and examstatus!='E'");
          //  _sqlAsyncconnection.QueryAsync<tbl_timer>("update [tbl_timer] set examstatus = '" + examstatus + "',endtime = '" + end_time + "',elapsed_time = '" + elapsed_time + "' WHERE section_id = '" + sectionid + "'");
        }

        public void UpdateSectionTimerBySectionid(string sectionid, string elapsed_timer)
        {
            _sqlAsyncconnection.QueryAsync<tbl_timer>("update [tbl_timer] set elapsed_time = '" + elapsed_timer + "'  WHERE section_id = '" + sectionid + "'");
        }
        #endregion


        #region Get Overall Questions list
        public List<ExamQuestions> GetAllPROQuestionList()
        {
            return _sqlAsyncconnection.QueryAsync<ExamQuestions>("select * from [ExamQuestions]").Result.ToList();
        }
        #endregion


        #region Get Questions list by section ID
        public List<ExamQuestions> GetPROQuestionListBySectionID(int sectionID)
        {
            return _sqlAsyncconnection.QueryAsync<ExamQuestions>("select * from [ExamQuestions] where section_id = ?", sectionID).Result.ToList();
        }
        #endregion

        #region Add PRO Question details
        public async Task<int> AddPROQuestions<ExamQuestions>(List<ExamQuestions> entityList)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    if (_sqlAsyncconnection != null) await _sqlAsyncconnection.InsertAllAsync(entityList);
                    return 1;
                }
            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    if (_sqlAsyncconnection != null) await _sqlAsyncconnection.InsertAllAsync(entityList);
                    return 1;
                }
                else
                    return 0;
                // throw;
            }
        }
        #endregion


        #region Add PRO SubQuestion details
        public async Task<int> AddPROSubQuestions<Sub_Questions>(List<Sub_Questions> entityList)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    if (_sqlAsyncconnection != null) await _sqlAsyncconnection.InsertAllAsync(entityList);
                    return 1;
                }
            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    if (_sqlAsyncconnection != null) await _sqlAsyncconnection.InsertAllAsync(entityList);
                    return 1;
                }
                else
                    return 0;
                // throw;
            }
        }
        #endregion

        #region Add PRO AssessmentAnswer details
        public async Task<int> AddAssessmentAnswer<AssessmentAnswer>(List<AssessmentAnswer> entityList)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    if (_sqlAsyncconnection != null) await _sqlAsyncconnection.InsertAllAsync(entityList);
                    return 1;
                }
            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    if (_sqlAsyncconnection != null) await _sqlAsyncconnection.InsertAllAsync(entityList);
                    return 1;
                }
                else
                    return 0;
                // throw;
            }
        }
        #endregion

        #region Get Overall AssessmentAnswer List
        public List<AssessmentAnswer> GetAllAssessmentAnswer()
        {
            return _sqlAsyncconnection.QueryAsync<AssessmentAnswer>("select * from [AssessmentAnswer]").Result.ToList();
        }
        #endregion


        #region Get Overall Sub Question List
        public List<Exam_Sub_Questions> GetAllPROSubQuestionList()
        {
            return _sqlAsyncconnection.QueryAsync<Exam_Sub_Questions>("select * from [Exam_Sub_Questions]").Result.ToList();
        }
        #endregion

        #region Get SubQuestion list by section ID
        public List<Exam_Sub_Questions> GetPROSubQuestionListByQuestionID(int QuestionID)
        {
            return _sqlAsyncconnection.QueryAsync<Exam_Sub_Questions>("select * from [Exam_Sub_Questions] where subquestion_id = ?", QuestionID).Result.ToList();
        }
        #endregion

        #region Add PRO Option details
        public async Task<int> AddPROOptions<Exam_Question_Options>(List<Exam_Question_Options> entityList)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    if (_sqlAsyncconnection != null) await _sqlAsyncconnection.InsertAllAsync(entityList);
                    return 1;
                }
            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    if (_sqlAsyncconnection != null) await _sqlAsyncconnection.InsertAllAsync(entityList);
                    return 1;
                }
                else
                    return 0;
                // throw;
            }
        }
        #endregion

        #region Add PRO SubQuestions Details
        public async Task<int> AddPRO_SubQuestions<Exam_Sub_Questions>(List<Exam_Sub_Questions> entityList)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    if (_sqlAsyncconnection != null) await _sqlAsyncconnection.InsertAllAsync(entityList);
                    return 1;
                }
            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    if (_sqlAsyncconnection != null) await _sqlAsyncconnection.InsertAllAsync(entityList);
                    return 1;
                }
                else
                    return 0;
                // throw;
            }
        }
        #endregion

        #region GetExamAnswerBasedOnQuestionId
        public ExamQuestions GetQuestion_Palette_Enum_Id(int id)
        {
            return _sqlAsyncconnection.QueryAsync<ExamQuestions>("select * from [ExamQuestions] where id = ?", id).Result.FirstOrDefault();
        }

        public AssessmentAnswer GetExamAnswerBasedOnQuestionId(string id)
        {
            return _sqlAsyncconnection.QueryAsync<AssessmentAnswer>("select * from [AssessmentAnswer] where question_id = ?", id).Result.FirstOrDefault();
        }
        #endregion

        #region UpdateExamAnswerQuestionsData
        public async void Update_Question_Palette_Enum_Id(string question_Palette_Enum_Id, int id)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    if (_sqlAsyncconnection != null)
                        await _sqlAsyncconnection.QueryAsync<ExamQuestions>("UPDATE [ExamQuestions] SET resume_point='1', Question_Palette_Enum_Id = '" + question_Palette_Enum_Id + "' WHERE id = ?", id);
                }
            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    // return await InsertAsync(entityList);
                }
                // throw;
            }
            // _sqlconnection.QueryAsync<ExamAnswersModel>("UPDATE [ExamAnswersModel] SET IsSynchedUp = 'true' WHERE ID = ?", id);  
        }



        public async void Update_Resume_Point(string sectionID,string questionID)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    if (_sqlAsyncconnection != null)
                      //  await _sqlAsyncconnection.QueryAsync<ExamQuestions>("UPDATE [ExamQuestions] SET  resume_point = '0' WHERE section_id = ?", sectionID);
                    await _sqlAsyncconnection.QueryAsync<ExamQuestions>("UPDATE [ExamQuestions] SET  resume_point = '1', WHERE section_id = '"+ sectionID + "' and id='"+ questionID + "'");
                }
            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    // return await InsertAsync(entityList);
                }
                // throw;
            }
            // _sqlconnection.QueryAsync<ExamAnswersModel>("UPDATE [ExamAnswersModel] SET IsSynchedUp = 'true' WHERE ID = ?", id);  
        }

        public async void Update_Resume_Point(string sectionID)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    if (_sqlAsyncconnection != null)
                      //  await _sqlAsyncconnection.QueryAsync<ExamQuestions>("UPDATE [ExamQuestions] SET  resume_point = '0'" );
                    await _sqlAsyncconnection.QueryAsync<ExamQuestions>("UPDATE [ExamQuestions] SET  resume_point = '0' WHERE section_id = ?", sectionID);
                }
            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    // return await InsertAsync(entityList);
                }
                // throw;
            }
            // _sqlconnection.QueryAsync<ExamAnswersModel>("UPDATE [ExamAnswersModel] SET IsSynchedUp = 'true' WHERE ID = ?", id);  
        }




        public async Task UpdateExamAnswerAssessmentAnswerTable(string exam_answer, string subquestion_id, string question_id)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    if (_sqlAsyncconnection != null)
                        await _sqlAsyncconnection.QueryAsync<AssessmentAnswer>("UPDATE [AssessmentAnswer] SET exam_answer = '" + exam_answer + "',sub_question_id ='" + subquestion_id + "'  WHERE question_id =  '" + question_id + "'");
                }
            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    // return await InsertAsync(entityList);
                }
                // throw;
            }
            // _sqlconnection.QueryAsync<ExamAnswersModel>("UPDATE [ExamAnswersModel] SET IsSynchedUp = 'true' WHERE ID = ?", id);  
        }

        public async Task UpdateExamAnswerAssessmentLikertType(string exam_answer, string subquestion_id, string question_id)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    if (_sqlAsyncconnection != null)
                        await _sqlAsyncconnection.QueryAsync<AssessmentAnswer>("UPDATE [AssessmentAnswer] SET exam_answer = '" + exam_answer + "' WHERE  question_id =  '" + question_id + "'AND sub_question_id ='" + subquestion_id + "'");
                }
            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    // return await InsertAsync(entityList);
                }
                // throw;
            }
            // _sqlconnection.QueryAsync<ExamAnswersModel>("UPDATE [ExamAnswersModel] SET IsSynchedUp = 'true' WHERE ID = ?", id);  
        }

        public async void UpdateExamAnswerAssessmentAnswerTableByQuestionID(string question_id)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    if (_sqlAsyncconnection != null)
                        await _sqlAsyncconnection.QueryAsync<AssessmentAnswer>("UPDATE [AssessmentAnswer] SET exam_answer = '0'  WHERE question_id =  '" + question_id + "'");
                }
            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == Result.Busy ||
                    sqliteException.Result == Result.Constraint)
                {
                    // return await InsertAsync(entityList);
                }
                // throw;
            }
            // _sqlconnection.QueryAsync<ExamAnswersModel>("UPDATE [ExamAnswersModel] SET IsSynchedUp = 'true' WHERE ID = ?", id);  
        }
        #endregion

        #region Get Overall Option list
        public List<Exam_Question_Options> GetAllPROOptionList()
        {
            return _sqlAsyncconnection.QueryAsync<Exam_Question_Options>("select * from [Exam_Question_Options]").Result.ToList();
        }
        #endregion

        #region Get Option list by Question ID
        public List<Exam_Question_Options> GetPROOptionListByQuestionID(int question_id)
        {
            return _sqlAsyncconnection.QueryAsync<Exam_Question_Options>("select * from [Exam_Question_Options] where question_id = ?", question_id).Result.ToList();
        }
        #endregion

        #region Get QuestionAndOptions list using JOIN QUERY by Question ID
        public List<Exam_Sub_Questions> GetPROQuestionAndOptionListByQuestionID(string QuestionID)
        {
            //  string selectStr = "select m.company_id,d.options,d.id,m.question_type from ExamQuestions m inner join Exam_Question_Options d on d.question_id = m.id and m.question_type!=1";
            // string selectStr = "select  * from Sub_Questions sq inner join Exam_Question_Options eqo on  sq.subquestion_id = eqo.sub_question_id where sq.question_id = ?", QuestionID;
            var query = _sqlAsyncconnection.QueryAsync<Exam_Sub_Questions>("select  * from Sub_Questions sq inner join Exam_Question_Options eqo on  sq.question_id = eqo.question_id where sq.question_id= '" + QuestionID+"'").Result;
            return query.ToList();
        }
        #endregion

        #region GetSubQuestionsByQuestionId
        public List<Exam_Sub_Questions> GetSubQuestionsByQuestionId(int id)
        {
            return _sqlAsyncconnection.QueryAsync<Exam_Sub_Questions>("select * from [Exam_Sub_Questions] where question_id = ?", id).Result.ToList();
        }
        #endregion

        #region GetAssessmentAnswersByQuestionID
        public List<AssessmentAnswer> GetAssessmentAnswersByQuestionID(int QuestionID)
        {
            return _sqlAsyncconnection.QueryAsync<AssessmentAnswer>("select * from [AssessmentAnswer] where question_id = ?", QuestionID).Result.ToList();
        }
        #endregion

        #region Get Option list by SubQuestion ID
        public List<Exam_Question_Options> GetPRO_OptionListBySubQuestionID(string questionID, string subQuestionID)
        {
            //    return _sqlAsyncconnection.QueryAsync<Exam_Question_Options>(@"select options,exam_answer from [Exam_Question_Options] eqq join Exam_Sub_Questions esq on eqq.question_id=esq.question_id
            //        and esq.subquestion_id=eqq.subquestion_id where  question_id=" + questionID + " and subquestion_id =" + subQuestionID).Result.ToList();
            return _sqlAsyncconnection.QueryAsync<Exam_Question_Options>("select * from [Exam_Question_Options] where  question_id=" + questionID + " and sub_question_id =" + subQuestionID).Result.ToList();

        }
        #endregion


        #region Get_PRO_SubQuestionAnswers
        public List<AssessmentAnswer> Get_PRO_SubQuestionAnswers(string questionID, string subQuestionID)
        {
            return _sqlAsyncconnection.QueryAsync<AssessmentAnswer>("select exam_answer from [AssessmentAnswer] where  question_id=" + questionID + " and sub_question_id =" + subQuestionID).Result.ToList();
        }
        #endregion



        #endregion
    }
}