﻿using HireMe.Interface;
using SQLite.Net;
using SQLite.Net.Async;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace HireMe.LocalDataBase
{
    public class BaseOperations
    {
        public SQLiteAsyncConnection Connection;
        private static readonly AsyncLock AsyncLock = new AsyncLock();

        //public BaseOperations()
        //{
        //    Connection = DependencyService.Get<ISQLite>().GetAsyncConnection();

        //}

        public async Task<int> InsertAsync<T>(T entity)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    if (entity != null) await Connection.InsertAsync(entity);
                    return 1;
                }
            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == SQLite.Net.Interop.Result.Busy ||
                    sqliteException.Result == SQLite.Net.Interop.Result.Constraint)
                {
                    return await InsertAsync(entity);
                }
                throw;
            }

        }

        public async Task<int> InsertAllAsync<T>(List<T> entityList)
        {
            try
            {
                using (await AsyncLock.LockAsync())
                {
                    if (Connection != null) await Connection.InsertAllAsync(entityList);
                    return 1;
                }
            }
            catch (SQLiteException sqliteException)
            {
                if (sqliteException.Result == SQLite.Net.Interop.Result.Busy ||
                    sqliteException.Result == SQLite.Net.Interop.Result.Constraint)
                {
                    return await InsertAsync(entityList);
                }
                throw;
            }
        }
    }
}
