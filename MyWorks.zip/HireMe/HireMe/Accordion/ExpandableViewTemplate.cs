﻿using System.Linq;
using System.Threading.Tasks;
using Xamarin.Forms;
using Acr.UserDialogs;

namespace HireMe.Accordion
{


    public class ExpandableViewTemplate : StackLayout
    {
        public LocalDataBase.LocalDB _localDB;
        public bool isClicked = true;

        Label answered; Label notanswered; Label notvisited; Label totalQuestion; Label totalQuestionText;
        //Label startExam;
        BoxView answeredColor; BoxView notansweredColor; BoxView notvisitedColor;
        Image totalQuestionImage;
        CustomButton startExam;
        public ExpandableViewTemplate()
        {

            _localDB = new LocalDataBase.LocalDB();



            this.BackgroundColor = Color.FromHex("#ffffff");


            this.Orientation = StackOrientation.Vertical;
            this.VerticalOptions = LayoutOptions.FillAndExpand;
            this.HorizontalOptions = LayoutOptions.FillAndExpand;

            this.Margin = new Thickness(0, 1, 0, 4);

            Resources = new ResourceDictionary();
            if (Device.Idiom == TargetIdiom.Phone)
            {
                answered = new Label { VerticalOptions = LayoutOptions.CenterAndExpand, FontSize = 12, HorizontalTextAlignment = TextAlignment.Start, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.CenterAndExpand, TextColor = Color.Black };
                answeredColor = new BoxView { Margin = new Thickness(0, 2, 0, 0), VerticalOptions = LayoutOptions.CenterAndExpand, HorizontalOptions = LayoutOptions.Start, BackgroundColor = Color.Green, HeightRequest = 10, WidthRequest = 10 };
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                answered = new Label { VerticalOptions = LayoutOptions.CenterAndExpand, FontSize = 22, HorizontalTextAlignment = TextAlignment.Start, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.CenterAndExpand, TextColor = Color.Black };
                answeredColor = new BoxView { Margin = new Thickness(0, 2, 0, 0), VerticalOptions = LayoutOptions.CenterAndExpand, HorizontalOptions = LayoutOptions.Start, BackgroundColor = Color.Green, HeightRequest = 15, WidthRequest = 15 };
            }
            if (Device.Idiom == TargetIdiom.Phone)
            {
                notanswered = new Label { VerticalOptions = LayoutOptions.CenterAndExpand, FontSize = 12, HorizontalTextAlignment = TextAlignment.Start, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.CenterAndExpand, TextColor = Color.Black };
                notansweredColor = new BoxView { Margin = new Thickness(8, 2, 0, 0), VerticalOptions = LayoutOptions.Center, HorizontalOptions = LayoutOptions.Start, BackgroundColor = Color.Red, HeightRequest = 10, WidthRequest = 10 };
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                notanswered = new Label { VerticalOptions = LayoutOptions.CenterAndExpand, FontSize = 22, HorizontalTextAlignment = TextAlignment.Start, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.CenterAndExpand, TextColor = Color.Black };
                notansweredColor = new BoxView { Margin = new Thickness(8, 2, 0, 0), VerticalOptions = LayoutOptions.Center, HorizontalOptions = LayoutOptions.Start, BackgroundColor = Color.Red, HeightRequest = 15, WidthRequest = 15 };
            }

            if (Device.Idiom == TargetIdiom.Phone)
            {
                notvisited = new Label { VerticalOptions = LayoutOptions.CenterAndExpand, FontSize = 12, HorizontalTextAlignment = TextAlignment.Start, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.CenterAndExpand, TextColor = Color.Black };
                notvisitedColor = new BoxView { Margin = new Thickness(8, 2, 0, 0), VerticalOptions = LayoutOptions.Center, HorizontalOptions = LayoutOptions.Start, BackgroundColor = Color.FromHex("#ebebeb"), HeightRequest = 10, WidthRequest = 10 };
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                notvisited = new Label { VerticalOptions = LayoutOptions.CenterAndExpand, FontSize = 22, HorizontalTextAlignment = TextAlignment.Start, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.CenterAndExpand, TextColor = Color.Black };
                notvisitedColor = new BoxView { Margin = new Thickness(8, 2, 0, 0), VerticalOptions = LayoutOptions.Center, HorizontalOptions = LayoutOptions.Start, BackgroundColor = Color.Gray, HeightRequest = 15, WidthRequest = 15 };
            }

            if (Device.Idiom == TargetIdiom.Phone)
            {
                //startExam = new Label { TextColor = Color.White, Margin = new Thickness(3, 0, 10, 0), FontSize = 12, HorizontalOptions = LayoutOptions.End, VerticalOptions = LayoutOptions.Center, HeightRequest = 40, BackgroundColor = Color.FromHex("#8fc740"), HorizontalTextAlignment = TextAlignment.Center, VerticalTextAlignment = TextAlignment.Center };
                startExam = new CustomButton { TextColor = Color.Black, Margin = new Thickness(3, 0, 10, 0), FontSize = 12, HorizontalOptions = LayoutOptions.End, VerticalOptions = LayoutOptions.Center, HeightRequest = 40, BackgroundColor = Color.FromHex("#8fc740"), };
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                //startExam = new Label { TextColor = Color.White, Margin = new Thickness(3, 0, 10, 0), FontSize = 22, HorizontalOptions = LayoutOptions.End, VerticalOptions = LayoutOptions.Center, HeightRequest = 60, BackgroundColor = Color.FromHex("#8fc740"), HorizontalTextAlignment = TextAlignment.Center, VerticalTextAlignment = TextAlignment.Center };
                startExam = new CustomButton { TextColor = Color.Black, Margin = new Thickness(3, 0, 10, 0), FontSize = 22, HorizontalOptions = LayoutOptions.End, VerticalOptions = LayoutOptions.Center, HeightRequest = 60, BackgroundColor = Color.FromHex("#8fc740"), };
            }



            var examStatusLayout = new StackLayout { Margin = new Thickness(2, 0, 0, 0), Orientation = StackOrientation.Horizontal, HorizontalOptions = LayoutOptions.CenterAndExpand, VerticalOptions = LayoutOptions.Center };
            var startExamLayout = new StackLayout { Margin = new Thickness(2, 0, 0, 0), Orientation = StackOrientation.Horizontal, HorizontalOptions = LayoutOptions.CenterAndExpand, VerticalOptions = LayoutOptions.Center };


            var ExamGroupID = new Label { IsVisible = false };
            var GroupName = new Label { IsVisible = false };
            var NoOfQuestions = new Label { IsVisible = false };


            var GreenColorLine = new BoxView { BackgroundColor = Color.FromHex("#8fc740"), HeightRequest = 1, HorizontalOptions = LayoutOptions.FillAndExpand };


            examStatusLayout.Children.Add(answeredColor);
            examStatusLayout.Children.Add(answered);
            examStatusLayout.Children.Add(notansweredColor);
            examStatusLayout.Children.Add(notanswered);
            examStatusLayout.Children.Add(notvisitedColor);
            examStatusLayout.Children.Add(notvisited);
            examStatusLayout.Margin = new Thickness(0, 0, 0, 0);



            if (Device.Idiom == TargetIdiom.Phone)
            {
                totalQuestion = new Label { VerticalOptions = LayoutOptions.Center, HorizontalTextAlignment = TextAlignment.Start, FontSize = 12, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.Start, TextColor = Color.Black };
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                totalQuestion = new Label { VerticalOptions = LayoutOptions.Center, HorizontalTextAlignment = TextAlignment.Start, FontSize = 22, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.Start, TextColor = Color.Black };
            }

            if (Device.Idiom == TargetIdiom.Phone)
            {
                totalQuestionText = new Label { VerticalOptions = LayoutOptions.Center, HorizontalTextAlignment = TextAlignment.Start, FontSize = 12, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.Start };
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                totalQuestionText = new Label { VerticalOptions = LayoutOptions.Center, HorizontalTextAlignment = TextAlignment.Start, FontSize = 22, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.Start };
            }


            startExamLayout.Orientation = StackOrientation.Horizontal;
            startExamLayout.HorizontalOptions = LayoutOptions.FillAndExpand;
            startExamLayout.VerticalOptions = LayoutOptions.FillAndExpand;

            if (AppPreferences.IsHindi)
            {
                totalQuestionText.Text = "कुल प्रश्न  -";
            }
            else
            {
                totalQuestionText.Text = "Total Questions  -";
            }

            totalQuestionText.TextColor = Color.Black;
            if (Device.Idiom == TargetIdiom.Phone)
            {
                totalQuestionImage = new Image { Source = "questionmark", HeightRequest = 15, WidthRequest = 15 };
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                totalQuestionImage = new Image { Source = "questionmark", HeightRequest = 25, WidthRequest = 25 };
            }
            startExamLayout.Margin = new Thickness(10, 5, 0, 5);
            startExamLayout.Children.Add(totalQuestionImage);
            startExamLayout.Children.Add(totalQuestionText);
            startExamLayout.Children.Add(totalQuestion);
            var gridStartExamLayout = new Grid
            {
                ColumnDefinitions =
            {
          new ColumnDefinition { Width =  GridLength.Star },
          new ColumnDefinition { Width =  GridLength.Auto },
            },
            };

            gridStartExamLayout.VerticalOptions = LayoutOptions.FillAndExpand;

            gridStartExamLayout.Margin = new Thickness(0, 0, 0, 6);

            gridStartExamLayout.Children.Add(startExamLayout, 0, 0);
            gridStartExamLayout.Children.Add(startExam, 1, 0);







            //this.Children.Add(examStatusLayout);
            //this.Children.Add(GreenColorLine);
            //this.Children.Add(startExamLayout);


            var grid = new Grid
            {
                RowDefinitions = {
          new RowDefinition { Height =  GridLength.Star },
          new RowDefinition { Height =  GridLength.Auto },
          new RowDefinition { Height = GridLength.Star },
           },
            };

            grid.VerticalOptions = LayoutOptions.FillAndExpand;



            grid.Children.Add(gridStartExamLayout, 0, 2);
            grid.Children.Add(GreenColorLine, 0, 1);
            grid.Children.Add(examStatusLayout, 0, 0);




            this.Children.Add(grid);

            this.Children.Add(ExamGroupID);
            this.Children.Add(GroupName);
            this.Children.Add(NoOfQuestions);


            answered.SetBinding(Label.TextProperty, "AnsweredQuestion");
            notanswered.SetBinding(Label.TextProperty, "UnAnsweredQuestions");
            notvisited.SetBinding(Label.TextProperty, "NotVisitedQuestions");
            ExamGroupID.SetBinding(Label.TextProperty, "QuestionGroupID");
            GroupName.SetBinding(Label.TextProperty, "GroupName");
            NoOfQuestions.SetBinding(Label.TextProperty, "NoOfQuestions");
            totalQuestion.SetBinding(Label.TextProperty, "NoOfQuestions");

            if (AppPreferences.IsHindi)
            {
                startExam.Text = "   परीक्षा शुरू करें   ";
            }
            else
            {
                startExam.Text = "   Start Exam   ";
            }

            #region StartExam Click Event
            //var tapGestureRecognizer = new TapGestureRecognizer();
            startExam.Clicked += async (s, e) =>
            {

                if (isClicked)
                {
                    isClicked = false;


                    if (!string.IsNullOrEmpty(ExamGroupID.Text))
                    {
                        if (IsCompleted(ExamGroupID.Text))
                        {
                            if (AppPreferences.IsHindi)
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.AlreadyExamCompletedHindi, null, MessageStringConstants.OKHindi);
                            }
                            else
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.AlreadyExamCompleted);
                            }

                        }
                        else
                        {
                            //start the exam
                            if (ExamGroupID.Text == "4")
                            {

                                if (AppPreferences.IsHindi == true)
                                {
                                    var data = _localDB.GetAllHindiDataBasedOnGroupId("4");
                                    string[] values = { "behaviouralexaminationpage", ExamGroupID.Text, GroupName.Text, data.Count().ToString() };
                                    MessagingCenter.Send(this, "ExpandableViewTemplate", values);
                                }
                                else //if (AppPreferences.IsEnglish == true)
                                {
                                    var data = _localDB.GetAllDataBasedOnGroupId("4");
                                    string[] values = { "behaviouralexaminationpage", ExamGroupID.Text, GroupName.Text, data.Count().ToString() };
                                    MessagingCenter.Send(this, "ExpandableViewTemplate", values);
                                }
                            }
                            else
                            {
                                if (AppPreferences.IsHindi == true)
                                {
                                    if (ExamGroupID.Text == "1")
                                    {
                                        var data = _localDB.GetAllDataBasedOnGroupId(ExamGroupID.Text);
                                        string[] values = { "normalexaminationpage", ExamGroupID.Text, GroupName.Text, data.Count().ToString() };
                                        MessagingCenter.Send(this, "ExpandableViewTemplate", values);
                                    }
                                    else
                                    {
                                        var data = _localDB.GetAllHindiDataBasedOnGroupId(ExamGroupID.Text);
                                        string[] values = { "normalexaminationpage", ExamGroupID.Text, GroupName.Text, data.Count().ToString() };
                                        MessagingCenter.Send(this, "ExpandableViewTemplate", values);
                                    }
                                }
                                else  //if (AppPreferences.IsEnglish == true)
                                {
                                    var data = _localDB.GetAllDataBasedOnGroupId(ExamGroupID.Text);
                                    string[] values = { "normalexaminationpage", ExamGroupID.Text, GroupName.Text, data.Count().ToString() };
                                    MessagingCenter.Send(this, "ExpandableViewTemplate", values);
                                }


                            }
                        }


                    }
                }
                await Task.Run(async () =>
                {
                    await Task.Delay(500);
                    isClicked = true;
                });
            };
            //startExam.GestureRecognizers.Add(tapGestureRecognizer);
            #endregion
        }



        private bool IsCompleted(string ExamGroupID)
        {
            bool IsComplete = false;
            if (AppPreferences.ExamMode == "True")
            {
                var res = _localDB.CheckGroupIdIsAlreadyPresentInExamCompletedTable(ExamGroupID);
                if (res != null && res.Status == "C")
                {
                    IsComplete = true;
                }
                //if (res.Count() > 0)
                //{
                //    foreach (var item in res)
                //    {
                //        if (item.Status == "C")
                //        {
                //            IsComplete = true;
                //        }
                //    }
                //}
            }

            return IsComplete;
        }

        //public void DataSyncTimerStart()
        //{
        //    int t = Models.Assessment.Constants.DataSyncInterval;
        //    Device.StartTimer(TimeSpan.FromSeconds(t), () =>
        //    {
        //        MessagingCenter.Send(this, "StartSyncSerivce", "Syncronization started from Internet availability ");
        //        return true; // True = Repeat again, False = Stop the timer
        //    });
        //}
    }
}







