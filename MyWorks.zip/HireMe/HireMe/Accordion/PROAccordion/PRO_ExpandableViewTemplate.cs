﻿using Acr.UserDialogs;
using HireMe.Models.PRO_Assessment;
using HireMe.Views.PRO_Assessment;
using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using System;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace HireMe.Accordion
{


    public class PRO_ExpandableViewTemplate : StackLayout
    {
        public LocalDataBase.LocalDB _localDB;
        public bool isClicked = true;

        Label answered;
        Label notanswered; Label notvisited;


        Label totalQuestion; Label totalQuestionText;


        Label sectionDurationtext; Label sectionDurationValue;


        //Label startExam;
        BoxView answeredColor; BoxView notansweredColor; BoxView notvisitedColor;

        Image totalQuestionImage;
        Image sectionDurationImage;

        CustomButton startExam;
        public PRO_ExpandableViewTemplate()
        {

            _localDB = new LocalDataBase.LocalDB();



            this.BackgroundColor = Color.FromHex("#ffffff");


            this.Orientation = StackOrientation.Vertical;
            this.VerticalOptions = LayoutOptions.FillAndExpand;
            this.HorizontalOptions = LayoutOptions.FillAndExpand;

            this.Margin = new Thickness(0, 1, 0, 4);

            Resources = new ResourceDictionary();
            if (Device.Idiom == TargetIdiom.Phone)
            {
                answered = new Label { VerticalOptions = LayoutOptions.StartAndExpand, FontSize = 12, HorizontalTextAlignment = TextAlignment.Start, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.StartAndExpand, TextColor = Color.Black };
                answeredColor = new BoxView { Margin = new Thickness(0, 2, 0, 0), VerticalOptions = LayoutOptions.CenterAndExpand, HorizontalOptions = LayoutOptions.Start, BackgroundColor = Color.Green, HeightRequest = 10, WidthRequest = 10 };
            }


            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                answered = new Label { VerticalOptions = LayoutOptions.StartAndExpand, FontSize = 22, HorizontalTextAlignment = TextAlignment.Start, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.StartAndExpand, TextColor = Color.Black };
                answeredColor = new BoxView { Margin = new Thickness(0, 2, 0, 0), VerticalOptions = LayoutOptions.CenterAndExpand, HorizontalOptions = LayoutOptions.Start, BackgroundColor = Color.Green, HeightRequest = 15, WidthRequest = 15 };
            }
            if (Device.Idiom == TargetIdiom.Phone)
            {
                notanswered = new Label { VerticalOptions = LayoutOptions.CenterAndExpand, FontSize = 12, HorizontalTextAlignment = TextAlignment.Start, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.CenterAndExpand, TextColor = Color.Black };
                notansweredColor = new BoxView { Margin = new Thickness(8, 2, 0, 0), VerticalOptions = LayoutOptions.Center, HorizontalOptions = LayoutOptions.Start, BackgroundColor = Color.Red, HeightRequest = 10, WidthRequest = 10 };
            }




            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                notanswered = new Label { VerticalOptions = LayoutOptions.CenterAndExpand, FontSize = 22, HorizontalTextAlignment = TextAlignment.Start, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.CenterAndExpand, TextColor = Color.Black };
                notansweredColor = new BoxView { Margin = new Thickness(8, 2, 0, 0), VerticalOptions = LayoutOptions.Center, HorizontalOptions = LayoutOptions.Start, BackgroundColor = Color.Red, HeightRequest = 15, WidthRequest = 15 };
            }

            if (Device.Idiom == TargetIdiom.Phone)
            {
                notvisited = new Label { VerticalOptions = LayoutOptions.CenterAndExpand, FontSize = 12, HorizontalTextAlignment = TextAlignment.Start, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.CenterAndExpand, TextColor = Color.Black };
                notvisitedColor = new BoxView { Margin = new Thickness(8, 2, 0, 0), VerticalOptions = LayoutOptions.Center, HorizontalOptions = LayoutOptions.Start, BackgroundColor = Color.FromHex("#ebebeb"), HeightRequest = 10, WidthRequest = 10 };
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                notvisited = new Label { VerticalOptions = LayoutOptions.CenterAndExpand, FontSize = 22, HorizontalTextAlignment = TextAlignment.Start, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.CenterAndExpand, TextColor = Color.Black };
                notvisitedColor = new BoxView { Margin = new Thickness(8, 2, 0, 0), VerticalOptions = LayoutOptions.Center, HorizontalOptions = LayoutOptions.Start, BackgroundColor = Color.Gray, HeightRequest = 15, WidthRequest = 15 };
            }

            if (Device.Idiom == TargetIdiom.Phone)
            {
                //startExam = new Label { TextColor = Color.White, Margin = new Thickness(3, 0, 10, 0), FontSize = 12, HorizontalOptions = LayoutOptions.End, VerticalOptions = LayoutOptions.Center, HeightRequest = 40, BackgroundColor = Color.FromHex("#8fc740"), HorizontalTextAlignment = TextAlignment.Center, VerticalTextAlignment = TextAlignment.Center };
                startExam = new CustomButton { TextColor = Color.Black, Margin = new Thickness(3, 0, 10, 0), FontSize = 12, HorizontalOptions = LayoutOptions.End, VerticalOptions = LayoutOptions.Center, HeightRequest = 40, BackgroundColor = Color.FromHex("#8fc740"), };
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                //startExam = new Label { TextColor = Color.White, Margin = new Thickness(3, 0, 10, 0), FontSize = 22, HorizontalOptions = LayoutOptions.End, VerticalOptions = LayoutOptions.Center, HeightRequest = 60, BackgroundColor = Color.FromHex("#8fc740"), HorizontalTextAlignment = TextAlignment.Center, VerticalTextAlignment = TextAlignment.Center };
                startExam = new CustomButton { TextColor = Color.Black, Margin = new Thickness(3, 0, 10, 0), FontSize = 22, HorizontalOptions = LayoutOptions.End, VerticalOptions = LayoutOptions.Center, HeightRequest = 60, BackgroundColor = Color.FromHex("#8fc740"), };
            }





            var examStatusLayout = new StackLayout { Margin = new Thickness(2, 5, 0, 0), Orientation = StackOrientation.Horizontal, HorizontalOptions = LayoutOptions.StartAndExpand, VerticalOptions = LayoutOptions.StartAndExpand };
            var startExamLayout = new StackLayout { Margin = new Thickness(2, 0, 0, 0), Orientation = StackOrientation.Horizontal, HorizontalOptions = LayoutOptions.CenterAndExpand, VerticalOptions = LayoutOptions.Center };




            if (Device.Idiom == TargetIdiom.Phone)
            {
                sectionDurationValue = new Label { VerticalOptions = LayoutOptions.Center, HorizontalTextAlignment = TextAlignment.Start, FontSize = 12, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.Start, TextColor = Color.Black };
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                sectionDurationValue = new Label { VerticalOptions = LayoutOptions.Center, HorizontalTextAlignment = TextAlignment.Start, FontSize = 22, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.Start, TextColor = Color.Black };
            }

            if (Device.Idiom == TargetIdiom.Phone)
            {
                sectionDurationtext = new Label { VerticalOptions = LayoutOptions.Center, HorizontalTextAlignment = TextAlignment.Start, FontSize = 12, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.Start };
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                sectionDurationtext = new Label { VerticalOptions = LayoutOptions.Center, HorizontalTextAlignment = TextAlignment.Start, FontSize = 22, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.Start };
            }


            sectionDurationtext.Text = "Section Duration  : ";


            examStatusLayout.Orientation = StackOrientation.Horizontal;
            examStatusLayout.HorizontalOptions = LayoutOptions.FillAndExpand;
            examStatusLayout.VerticalOptions = LayoutOptions.FillAndExpand;
            examStatusLayout.Margin = new Thickness(0, 10, 0, 0);

            var ExamGroupID = new Label { IsVisible = false };
            var GroupName = new Label { IsVisible = false };
            var NoOfQuestions = new Label { IsVisible = false };


            var SectionContent = new Label { IsVisible = false };
            var SectionID = new Label { IsVisible = false };
            var SectionName = new Label { IsVisible = false };
            var SectionDuration = new Label { IsVisible = false };
            var SectionCount = new Label { IsVisible = false };
            var QuestionType = new Label { IsVisible = false };
            var ExamStatus = new Label { IsVisible = false };




            var GreenColorLine = new BoxView { BackgroundColor = Color.FromHex("#8fc740"), HeightRequest = 1, HorizontalOptions = LayoutOptions.FillAndExpand };


            // examStatusLayout.Children.Add(answeredColor);
            //   examStatusLayout.Children.Add(answered);
            //  examStatusLayout.Children.Add(notansweredColor);
            //  examStatusLayout.Children.Add(notanswered);
            //  examStatusLayout.Children.Add(notvisitedColor);
            //  examStatusLayout.Children.Add(notvisited);
            //  examStatusLayout.Margin = new Thickness(0, 0, 0, 0);



            if (Device.Idiom == TargetIdiom.Phone)
            {
                totalQuestion = new Label { VerticalOptions = LayoutOptions.Center, HorizontalTextAlignment = TextAlignment.Start, FontSize = 12, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.Start, TextColor = Color.Black };
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                totalQuestion = new Label { VerticalOptions = LayoutOptions.Center, HorizontalTextAlignment = TextAlignment.Start, FontSize = 22, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.Start, TextColor = Color.Black };
            }

            if (Device.Idiom == TargetIdiom.Phone)
            {
                totalQuestionText = new Label { VerticalOptions = LayoutOptions.Center, HorizontalTextAlignment = TextAlignment.Start, FontSize = 12, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.Start };
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                totalQuestionText = new Label { VerticalOptions = LayoutOptions.Center, HorizontalTextAlignment = TextAlignment.Start, FontSize = 22, VerticalTextAlignment = TextAlignment.Start, HorizontalOptions = LayoutOptions.Start };
            }


            startExamLayout.Orientation = StackOrientation.Horizontal;
            startExamLayout.HorizontalOptions = LayoutOptions.FillAndExpand;
            startExamLayout.VerticalOptions = LayoutOptions.FillAndExpand;

            if (AppPreferences.IsHindi)
            {
                totalQuestionText.Text = "कुल प्रश्न  -";
            }
            else
            {
                totalQuestionText.Text = "Total Questions  : ";
            }

            totalQuestionText.TextColor = Color.Black;
            if (Device.Idiom == TargetIdiom.Phone)
            {
                totalQuestionImage = new Image { Source = "questionmark", HeightRequest = 15, WidthRequest = 15 };
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                totalQuestionImage = new Image { Source = "questionmark", HeightRequest = 25, WidthRequest = 25 };
            }


            if (Device.Idiom == TargetIdiom.Phone)
            {
                sectionDurationImage = new Image { Source = "questionmark", HeightRequest = 15, WidthRequest = 15 };
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                sectionDurationImage = new Image { Source = "questionmark", HeightRequest = 25, WidthRequest = 25 };
            }



            startExamLayout.Margin = new Thickness(10, 5, 0, 5);
            startExamLayout.Children.Add(totalQuestionImage);
            startExamLayout.Children.Add(totalQuestionText);
            startExamLayout.Children.Add(totalQuestion);

            examStatusLayout.Margin = new Thickness(10, 5, 0, 5);
            examStatusLayout.Children.Add(sectionDurationImage);
            examStatusLayout.Children.Add(sectionDurationtext);
            examStatusLayout.Children.Add(sectionDurationValue);



            var gridStartExamLayout = new Grid
            {
                ColumnDefinitions =
            {
          new ColumnDefinition { Width =  GridLength.Star },
          new ColumnDefinition { Width =  GridLength.Auto },
            },
            };

            gridStartExamLayout.VerticalOptions = LayoutOptions.Center;

            gridStartExamLayout.Margin = new Thickness(0, 0, 0, 6);

            gridStartExamLayout.Children.Add(startExamLayout, 0, 0);
            gridStartExamLayout.Children.Add(startExam, 1, 0);





            var grid = new Grid
            {
                RowDefinitions = {
          new RowDefinition { Height =  GridLength.Auto },
          new RowDefinition { Height =  GridLength.Auto },
        //  new RowDefinition { Height = GridLength.Auto },
         },
            };




            grid.VerticalOptions = LayoutOptions.FillAndExpand;
            grid.Children.Add(examStatusLayout, 0, 0);
            //grid.Children.Add(GreenColorLine, 0, 1);
            grid.Children.Add(gridStartExamLayout, 0, 1);



            this.Children.Add(grid);


            //  this.Children.Add(ExamGroupID);
            //   this.Children.Add(GroupName);



            this.Children.Add(SectionContent);
            this.Children.Add(SectionID);
            this.Children.Add(NoOfQuestions);
            this.Children.Add(SectionName);
            this.Children.Add(SectionDuration);
            this.Children.Add(SectionCount);
            this.Children.Add(QuestionType);
            this.Children.Add(ExamStatus);




            SectionContent.SetBinding(Label.TextProperty, "section_content");
            SectionID.SetBinding(Label.TextProperty, "section_id");

            SectionName.SetBinding(Label.TextProperty, "name");
            SectionDuration.SetBinding(Label.TextProperty, "duration");
            SectionCount.SetBinding(Label.TextProperty, "section_count");

            NoOfQuestions.SetBinding(Label.TextProperty, "section_count");
            totalQuestion.SetBinding(Label.TextProperty, "section_count");

            sectionDurationValue.SetBinding(Label.TextProperty, "section_duration");
            QuestionType.SetBinding(Label.TextProperty, "question_type");

            ExamStatus.SetBinding(Label.TextProperty, "section_status");



            if (AppPreferences.IsHindi)
            {
                startExam.Text = "   परीक्षा शुरू करें   ";
            }
            else
            {
                startExam.Text = "   Start Exam   ";
            }

            #region StartExam Click Event
            startExam.Clicked += async (s, e) =>
            {
                if (isClicked)
                {
                    isClicked = false;
                    var status = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Camera);
                    var storage = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Storage);
                    if (status != PermissionStatus.Granted || storage != PermissionStatus.Granted)
                    {
                        var results = await CrossPermissions.Current.RequestPermissionsAsync(new[] { Permission.Camera, Permission.Storage });
                        status = results[Permission.Camera];
                        storage = results[Permission.Storage];
                    }
                    if (status == PermissionStatus.Granted && storage == PermissionStatus.Granted)
                    {
                        #region Start Exam Operations
                        SectionInstructionContent objContent = new HireMe.Models.PRO_Assessment.SectionInstructionContent();
                        objContent.section_content = SectionContent.Text;
                        objContent.name = SectionName.Text;
                        objContent.section_count = SectionCount.Text;
                        objContent.section_id = SectionID.Text;
                        objContent.isshow_instruction = false;
                        objContent.section_duration = SectionDuration.Text;
                        AppPreferences.SectionInstruction = SectionContent.Text ?? string.Empty;

                        tbl_timer obj;

                        if (AppPreferences.TestPinMasterData.duration_type == Convert.ToString((int)duration_type.ExamDuration))
                        {
                            obj = _localDB.GetPROSectionDetailsByID(1);
                        }
                        else
                        {

                            obj = _localDB.GetPROSectionTimerBySectionID(SectionID.Text);
                        }

                        if (obj.elapsed_time != null)
                        {
                            if (obj.examstatus == "E" || obj.elapsed_time == "0")
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.ExamTimeOutMessage);
                            }
                            else
                            {
                                if (string.IsNullOrEmpty(objContent.section_content))
                                {
                                    App.Current.MainPage = new NavigationPage(new PRO_ExamPage(objContent));
                                }
                                else
                                {
                                    App.Current.MainPage = new NavigationPage(new PRO_ExamInstructionPage(objContent));
                                }
                            }
                        }
                        #endregion
                    }
                    else if (status != PermissionStatus.Unknown)
                    {
                        UserDialogs.Instance.HideLoading();
                        UserDialogs.Instance.Toast(MessageStringConstants.PermissionMessage);
                    }
                }
                await Task.Run(async () =>
                {
                    await Task.Delay(500);
                    isClicked = true;
                });
            };
            #endregion
        }
    }
}







