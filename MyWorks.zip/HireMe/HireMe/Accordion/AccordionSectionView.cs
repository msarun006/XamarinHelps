﻿using System.Collections;
using Xamarin.Forms;

namespace HireMe.Accordion
{
    public class AccordionSectionView : StackLayout
    {
        private bool _isExpanded = false;
        private StackLayout _content = new StackLayout { HeightRequest = 0 };
        private Color _headerColor = Color.FromHex("#ffffff");
        private ImageSource _arrowRight = ImageSource.FromFile("rightarrow.png");
        private ImageSource _arrowDown = ImageSource.FromFile("downarrow.png");

        private StackLayout _header = new StackLayout();
        //private Image _headerIcon = new Image { VerticalOptions = LayoutOptions.Center };
       // private Label _headerTitle = new Label { TextColor = Color.White, VerticalTextAlignment = TextAlignment.Center, HeightRequest = 30};
        private DataTemplate _template;




           

       private Image _ArrowIcon = new Image { Margin = new Thickness(0, 0, 10, 0), HorizontalOptions = LayoutOptions.End, VerticalOptions = LayoutOptions.Center, Aspect = Aspect.AspectFit, HeightRequest = 20, WidthRequest = 15 };






        public static readonly BindableProperty ItemsSourceProperty =
            BindableProperty.Create(
                propertyName: "ItemsSource",
                returnType: typeof(IList),
                declaringType: typeof(AccordionSectionView),
                defaultValue: default(IList),
                propertyChanged: AccordionSectionView.PopulateList);

        public IList ItemsSource
        {
            get { return (IList)GetValue(ItemsSourceProperty); }
            set { SetValue(ItemsSourceProperty, value); }
        }



        public static readonly BindableProperty TitleProperty =
            BindableProperty.Create(
                propertyName: "GroupName",
                returnType: typeof(string),
                declaringType: typeof(AccordionSectionView),
                propertyChanged: AccordionSectionView.ChangeTitle);

        
        public string Title
        {
            get { return (string)GetValue(TitleProperty); }
            set { SetValue(TitleProperty, value); }
        }



        public static readonly BindableProperty TitleStatusColorProperty =
            BindableProperty.Create(
                propertyName: "TitleStatusColor",
                returnType: typeof(string),
                declaringType: typeof(AccordionSectionView),
                propertyChanged: AccordionSectionView.ChangeTitleColor);


        public string TitleStatusColor
        {
            get { return (string)GetValue(TitleStatusColorProperty); }
            set { SetValue(TitleStatusColorProperty, value); }
        }








        private Label _headerTitle;
        private BoxView _headerTitleCompletedStatus;
        public AccordionSectionView(DataTemplate itemTemplate, ScrollView parent)
        {
            _template = itemTemplate;
            //   _headerTitle.BackgroundColor = _headerColor;
            _ArrowIcon.Source = _arrowRight;
            // _headerIcon.Source = _arrowRight;

          //  _arrowRight.Text = (string)Application.Current.Resources["RightArrowIcon"]; 
            _header.BackgroundColor = _headerColor;

            //_header.Children.Add(_headerIcon, new Rectangle(0, 1, .1, 1), AbsoluteLayoutFlags.All);
            //_header.Children.Add(_headerTitle, new Rectangle(1, 1, .9, 1), AbsoluteLayoutFlags.All);

            _header.Orientation = StackOrientation.Horizontal;

            _header.HeightRequest = 50;
            if (Device.Idiom == TargetIdiom.Phone)
            {
                _headerTitle = new Label
                {
                    Margin = new Thickness(5, 5, 0, 5),
                    HorizontalOptions = LayoutOptions.StartAndExpand,
                    VerticalOptions = LayoutOptions.Center,
                    HeightRequest = 40,
                    FontSize = 15,
                    TextColor = Color.Black,
                    VerticalTextAlignment = TextAlignment.Center
                };
            }
            else if (Device.Idiom == TargetIdiom.Tablet)
            {
                _headerTitle = new Label
                {
                    Margin = new Thickness(5, 5, 0, 5),
                    HorizontalOptions = LayoutOptions.StartAndExpand,
                    VerticalOptions = LayoutOptions.Center,
                    HeightRequest = 40,
                    FontSize = 24,
                    TextColor = Color.Black,
                    VerticalTextAlignment = TextAlignment.Center
                };
            }


            _headerTitleCompletedStatus = new BoxView
            {
                HeightRequest = 15,
                WidthRequest = 15,
                VerticalOptions = LayoutOptions.Center,
                HorizontalOptions = LayoutOptions.Center,
             
                Margin = new Thickness(5, 0, 0, 0),
                
            };



            //  _header.Children.Add(_BoxViewIcon);

            _header.Children.Add(_headerTitleCompletedStatus);

            _header.Children.Add(_headerTitle);

            _header.Children.Add(_ArrowIcon);
        


            this.Margin = 0;

            this.Spacing = 0;
            this.Children.Add(_header);
            this.Children.Add(_content);

            _header.GestureRecognizers.Add(
                new TapGestureRecognizer
                {
                    Command = new Command(async () =>
                    {
                        if (_isExpanded)
                        {
                            _ArrowIcon.Source = _arrowRight;
                            _content.HeightRequest = 0;
                            _content.IsVisible = false;
                            _isExpanded = false;
                        }
                        else
                        {
                             _ArrowIcon.Source = _arrowDown;
                            _content.BackgroundColor = Color.FromHex("#fffff");
                            // _content.HeightRequest = _content.Children.Count * 80;
                            _content.HeightRequest = 100;
                            _content.IsVisible = true;
                            _isExpanded = true;

                            // Scroll top by the current Y position of the section
                            if (parent.Parent is VisualElement)
                            {
                                await parent.ScrollToAsync(0, this.Y, true);
                            }
                        }
                    })
                }
            );
        }

        void ChangeTitle()
        {
            _headerTitle.Text = this.Title;
        
        }

        void ChangeTitleColor()
        {
            _headerTitleCompletedStatus.BackgroundColor = Color.FromHex(this.TitleStatusColor);

        }



        void PopulateList()
        {
            _content.Children.Clear();

            foreach (object item in this.ItemsSource)
            {
                var template = (Xamarin.Forms.View)_template.CreateContent();
                template.BindingContext = item;
                _content.Children.Add(template);
            }
        }

        static void ChangeTitle(BindableObject bindable, object oldValue, object newValue)
        {
            if (oldValue == newValue) return;
            ((AccordionSectionView)bindable).ChangeTitle();
        }

        static void ChangeTitleColor(BindableObject bindable, object oldValue, object newValue)
        {
            if (oldValue == newValue) return;
            ((AccordionSectionView)bindable).ChangeTitleColor();
        }

        static void PopulateList(BindableObject bindable, object oldValue, object newValue)
        {
            if (oldValue == newValue) return;
            ((AccordionSectionView)bindable).PopulateList();
        }
    }
}
