﻿using Acr.UserDialogs;
using MvvmHelpers;
using Plugin.Connectivity;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels
{
    public class InternetUnavailableViewModel : BaseViewModel
    {
        string _value;
        public ICommand OnCheckInternetCommand { get; set; }
        public InternetUnavailableViewModel(string className)
        {
            AppPreferences.Is_HireMee_PRO_User = false;
            _value = className;
            OnCheckInternetCommand = new Command(CheckInternetConnection);
        }

        private async void CheckInternetConnection(object obj)
        {
            //Show Videos Page
            UserDialogs.Instance.ShowLoading();
            await Task.Delay(5000);
            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
            if (isNetworkAvailable)
            {

                if (_value == "Dashboard" && AppSessionData.ActiveToken.UserType == UserType.JobSeeker)
                {
                    Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                    return;
                }
                else if (_value == "VideoProfilePage" && AppSessionData.ActiveToken.UserType == UserType.JobSeeker)
                {
                    Application.Current.MainPage = new NavigationPage(new VideoProfilePage(true));
                    return;
                }
                else if (_value == "SeekerPersonalAndEducationPage" && AppSessionData.ActiveToken.UserType == UserType.JobSeeker)
                {
                    Application.Current.MainPage = new NavigationPage(new SeekerPersonalAndEducationPage(true));
                    return;
                }
                else if (AppSessionData.ActiveToken.UserType == UserType.Recruiter)
                {
                    Application.Current.MainPage = new DashBoardMaster(UserType.Recruiter);
                    return;
                }
                UserDialogs.Instance.HideLoading();


            }
            else
            {
                UserDialogs.Instance.HideLoading();
                await UserDialogs.Instance.AlertAsync("Please TURN ON Internet service", "HireMee", "ok");
            }
        }
    }
}
