﻿using HireMe.Models.Recruiter;
using MvvmHelpers;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.Recruiter
{
    public class AdvancedSearchOptionViewModel : BaseViewModel
    {
        INavigation navigationService;
        public ICommand OnApplyCommand { get; set; }
        public AdvancedSearchOptionViewModel(SearchDetailRequestData data, INavigation objNav)
        {
            AdvancedSearchParams = data;
            navigationService = objNav;
            #region Initial Values Binding
            EnglishLowerValue = SplitScore(data.EnglishScoreValue)[0];
            EnglishUpperValue = SplitScore(data.EnglishScoreValue)[1];
            QuantitativeLowerValue = SplitScore(data.QuantitativeScoreValue)[0];
            QuantitativeUpperValue = SplitScore(data.QuantitativeScoreValue)[1];
            PersonalCompetenciesLowerValue = SplitScore(data.PersonalCompetencies)[0];
            PersonalCompetenciesUpperValue = SplitScore(data.PersonalCompetencies)[1];
            IntellectualOrientationLowerValue = SplitScore(data.Intellectualorientation)[0];
            IntellectualOrientationUpperValue = SplitScore(data.Intellectualorientation)[1];
            EmotionalCompetenciesLowerValue = SplitScore(data.Emotionalcompetencies)[0];
            EmotionalCompetenciesUpperValue = SplitScore(data.Emotionalcompetencies)[1];
            MotivationalCompetenciesLowerValue = SplitScore(data.MotivationalCompetencies)[0];
            MotivationalCompetenciesUpperValue = SplitScore(data.MotivationalCompetencies)[1];
            InterpersonalCompetenciesLowerValue = SplitScore(data.InterpersonalCompetencies)[0];
            InterpersonalCompetenciesUpperValue = SplitScore(data.InterpersonalCompetencies)[1];
            LogicalLowerValue = SplitScore(data.LogicalScoreValue)[0];
            LogicalUpperValue = SplitScore(data.LogicalScoreValue)[1];
            CommunicationLowerValue = SplitScore(data.CommunicationScoreValue)[0];
            CommunicationUpperValue = SplitScore(data.CommunicationScoreValue)[1];
            TechnicalLowerValue = SplitScore(data.TechnicalScoreValue)[0];
            TechnicalUpperValue = SplitScore(data.TechnicalScoreValue)[1];
            AptitudeLowerValue = SplitScore(data.AptitudeScoreValue)[0];
            AptitudeUpperValue = SplitScore(data.AptitudeScoreValue)[1];
            #endregion
            OnApplyCommand = new Command(OnApply);
        }

        public void OnLowerValue(string ClassId, string value)
        {
            switch (ClassId)
            {
                case "Verbal":
                    EnglishLowerValue = value;
                    break;
                case "Quantitative":
                    QuantitativeLowerValue = value;
                    break;
                case "Logical":
                    LogicalLowerValue = value;
                    break;
                case "Aptitude":
                    AptitudeLowerValue = value;
                    break;
                case "Interpersonal":
                    InterpersonalCompetenciesLowerValue = value;
                    break;
                case "Personal":
                    PersonalCompetenciesLowerValue = value;
                    break;
                case "Emotional":
                    EmotionalCompetenciesLowerValue = value;
                    break;
                case "Motivational":
                    MotivationalCompetenciesLowerValue = value;
                    break;
                case "Intellectual":
                    IntellectualOrientationLowerValue = value;
                    break;
                case "Communication":
                    CommunicationLowerValue = value;
                    break;
                case "Technical":
                    TechnicalLowerValue = value;
                    break;
            }

        }
        public void OnUpperValue(string ClassId, string value)
        {
            switch (ClassId)
            {
                case "Verbal":
                    EnglishUpperValue = value;
                    break;
                case "Quantitative":
                    QuantitativeUpperValue = value;
                    break;
                case "Logical":
                    LogicalUpperValue = value;
                    break;
                case "Aptitude":
                    AptitudeUpperValue = value;
                    break;
                case "Interpersonal":
                    InterpersonalCompetenciesUpperValue = value;
                    break;
                case "Personal":
                    PersonalCompetenciesUpperValue = value;
                    break;
                case "Emotional":
                    EmotionalCompetenciesUpperValue = value;
                    break;
                case "Motivational":
                    MotivationalCompetenciesUpperValue = value;
                    break;
                case "Intellectual":
                    IntellectualOrientationUpperValue = value;
                    break;
                case "Communication":
                    CommunicationUpperValue = value;
                    break;
                case "Technical":
                    TechnicalUpperValue = value;
                    break;

            }

        }

        private void OnApply(object obj)
        {

            AdvancedSearchParams.EnglishScoreValue = EnglishLowerValue + ',' + EnglishUpperValue;
            AdvancedSearchParams.QuantitativeScoreValue = QuantitativeLowerValue + ',' + QuantitativeUpperValue;
            AdvancedSearchParams.CommunicationScoreValue = CommunicationLowerValue + ',' + CommunicationUpperValue;
            AdvancedSearchParams.AptitudeScoreValue = AptitudeLowerValue + ',' + AptitudeUpperValue;
            AdvancedSearchParams.TechnicalScoreValue = TechnicalLowerValue + ',' + TechnicalUpperValue;
            AdvancedSearchParams.PersonalCompetencies = PersonalCompetenciesLowerValue + ',' + PersonalCompetenciesUpperValue;
            AdvancedSearchParams.InterpersonalCompetencies = InterpersonalCompetenciesLowerValue + ',' + InterpersonalCompetenciesUpperValue;
            AdvancedSearchParams.Emotionalcompetencies = EmotionalCompetenciesLowerValue + ',' + EmotionalCompetenciesUpperValue;
            AdvancedSearchParams.MotivationalCompetencies = MotivationalCompetenciesLowerValue + ',' + MotivationalCompetenciesUpperValue;
            AdvancedSearchParams.Intellectualorientation = IntellectualOrientationLowerValue + ',' + IntellectualOrientationUpperValue;
            AdvancedSearchParams.LogicalScoreValue = LogicalLowerValue + ',' + LogicalUpperValue;
            navigationService.PopAsync();
        }



    

        private string[] SplitScore(string Score)
        {
            return Score.Split(',');
        }

        #region Binding Properties
        private SearchDetailRequestData _advancedSearchParams;
        public SearchDetailRequestData AdvancedSearchParams
        {
            get { return _advancedSearchParams; }
            set { _advancedSearchParams = value; OnPropertyChanged(); }
        }
        private string _EnglishLower;
        public string EnglishLowerValue
        {
            get { return _EnglishLower; }
            set { _EnglishLower = value; OnPropertyChanged(); }
        }
        private string _EnglishUpper;
        public string EnglishUpperValue
        {
            get { return _EnglishUpper; }
            set { _EnglishUpper = value; OnPropertyChanged(); }
        }
        private string _QuantitativeLower;
        public string QuantitativeLowerValue
        {
            get { return _QuantitativeLower; }
            set { _QuantitativeLower = value; OnPropertyChanged(); }
        }
        private string _QuantitativeUpper;
        public string QuantitativeUpperValue
        {
            get { return _QuantitativeUpper; }
            set { _QuantitativeUpper = value; OnPropertyChanged(); }
        }
        private string _CommunicationLower;
        public string CommunicationLowerValue
        {
            get { return _CommunicationLower; }
            set { _CommunicationLower = value; OnPropertyChanged(); }
        }
        private string _CommunicationUpper;
        public string CommunicationUpperValue
        {
            get { return _CommunicationUpper; }
            set { _CommunicationUpper = value; OnPropertyChanged(); }
        }
        private string _AptitudeLower;
        public string AptitudeLowerValue
        {
            get { return _AptitudeLower; }
            set { _AptitudeLower = value; OnPropertyChanged(); }
        }
        private string _AptitudeUpper;
        public string AptitudeUpperValue
        {
            get { return _AptitudeUpper; }
            set { _AptitudeUpper = value; OnPropertyChanged(); }
        }
        private string _TechnicalLower;
        public string TechnicalLowerValue
        {
            get { return _TechnicalLower; }
            set { _TechnicalLower = value; OnPropertyChanged(); }
        }
        private string _TechnicalUpper;
        public string TechnicalUpperValue
        {
            get { return _TechnicalUpper; }
            set { _TechnicalUpper = value; OnPropertyChanged(); }
        }
        private string _personalCompetenciesLower;
        public string PersonalCompetenciesLowerValue
        {
            get { return _personalCompetenciesLower; }
            set { _personalCompetenciesLower = value; OnPropertyChanged(); }
        }
        private string _personalCompetenciesUpper;
        public string PersonalCompetenciesUpperValue
        {
            get { return _personalCompetenciesUpper; }
            set { _personalCompetenciesUpper = value; OnPropertyChanged(); }
        }
        private string _interpersonalCompetenciesLower;
        public string InterpersonalCompetenciesLowerValue
        {
            get { return _interpersonalCompetenciesLower; }
            set { _interpersonalCompetenciesLower = value; OnPropertyChanged(); }
        }
        private string _interpersonalCompetenciesUpper;
        public string InterpersonalCompetenciesUpperValue
        {
            get { return _interpersonalCompetenciesUpper; }
            set { _interpersonalCompetenciesUpper = value; OnPropertyChanged(); }
        }
        private string _emotionalCompetenciesLower;
        public string EmotionalCompetenciesLowerValue
        {
            get { return _emotionalCompetenciesLower; }
            set { _emotionalCompetenciesLower = value; OnPropertyChanged(); }
        }
        private string _emotionalCompetenciesUpper;
        public string EmotionalCompetenciesUpperValue
        {
            get { return _emotionalCompetenciesUpper; }
            set { _emotionalCompetenciesUpper = value; OnPropertyChanged(); }
        }
        private string _motivationalCompetenciesLower;
        public string MotivationalCompetenciesLowerValue
        {
            get { return _motivationalCompetenciesLower; }
            set { _motivationalCompetenciesLower = value; OnPropertyChanged(); }
        }
        private string _motivationalCompetenciesUpper;
        public string MotivationalCompetenciesUpperValue
        {
            get { return _motivationalCompetenciesUpper; }
            set { _motivationalCompetenciesUpper = value; OnPropertyChanged(); }
        }
        private string _intellectualOrientationLower;
        public string IntellectualOrientationLowerValue
        {
            get { return _intellectualOrientationLower; }
            set { _intellectualOrientationLower = value; OnPropertyChanged(); }
        }
        private string _intellectualOrientationUpper;
        public string IntellectualOrientationUpperValue
        {
            get { return _intellectualOrientationUpper; }
            set { _intellectualOrientationUpper = value; OnPropertyChanged(); }
        }
        private string _logicalLower;
        public string LogicalLowerValue
        {
            get { return _logicalLower; }
            set { _logicalLower = value; OnPropertyChanged(); }
        }
        private string _logicalUpper;
        public string LogicalUpperValue
        {
            get { return _logicalUpper; }
            set { _logicalUpper = value; OnPropertyChanged(); }
        }

        #endregion
    }
}
