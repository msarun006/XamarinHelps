﻿using System;
using HireMe.Models.Recruiter;
using Xamarin.Forms;
using System.Collections.ObjectModel;
using MvvmHelpers;
using Acr.UserDialogs;
using Plugin.Connectivity;
using System.Windows.Input;
using HireMe.UI;
using System.Linq;
using System.Threading.Tasks;
using HireMe.Helpers;
using System.Diagnostics;

namespace HireMe.ViewModels.Recruiter
{
    public class RecruiterSearchResultViewModel : BaseViewModel
    {
        public bool isClicked = true;
        private INavigation navigation;
        private SearchResponseText searchDetailData;
        private string strSearchid;
        ObservableCollection<RecruitersearchBO> _tempRecruitersearchBO;

        private HttpCommonService _commonservice { get; set; }
        public RecentSearchListItemClickedRequestData RecentSearchListItemClickedRequestData { get; set; }
        public SearchDetailResponse SearchDetailResponse { get; set; }


        private ObservableCollection<RecruitersearchBO> _ItemSource;
        public ObservableCollection<RecruitersearchBO> ItemSource
        {
            get { return _ItemSource; }
            set { _ItemSource = value; OnPropertyChanged(); }
        }

        public RecruiterSearchResultViewModel(INavigation navigation, SearchResponseText searchDetailData)
        {
            _commonservice = new HttpCommonService();
            this.navigation = navigation;
            this.searchDetailData = searchDetailData;
            isEnabledSearchBar = true;
            ItemSource = new ObservableCollection<RecruitersearchBO>();
            _tempRecruitersearchBO = new ObservableCollection<RecruitersearchBO>();
            ItemSource.Clear();
            ItemSource = new ObservableCollection<RecruitersearchBO>(searchDetailData.searchDetails);
            _tempRecruitersearchBO = new ObservableCollection<RecruitersearchBO>(searchDetailData.searchDetails);
            SearchPlaceHolderText = "Search Candidate";
        }




        public RecruiterSearchResultViewModel(INavigation navigation, string strSearchid)
        {
            _commonservice = new HttpCommonService();
            this.navigation = navigation;
            this.strSearchid = strSearchid;

            RecentSearchListItemClickedRequestData = new RecentSearchListItemClickedRequestData();
            SearchDetailResponse = new SearchDetailResponse();


            RecentSearchListItemClickedRequestData.HiremeeID = AppSessionData.ActiveToken.HireMeID;
            RecentSearchListItemClickedRequestData.Token = AppSessionData.ActiveToken.Token;
            RecentSearchListItemClickedRequestData.SearchId = strSearchid;
            SearchPlaceHolderText = "Search Candidate";
            BindSearchResultList();

        }
        #region Searchbar Controls
        private bool _isVisibleSearchbarCancel;
        public bool IsVisibleSearchbarCancelButton
        {
            get { return _isVisibleSearchbarCancel; }
            set { _isVisibleSearchbarCancel = value; OnPropertyChanged(); }
        }
        public bool _isEnabledSearchBar;

        public bool isEnabledSearchBar
        {
            set { _isEnabledSearchBar = value; OnPropertyChanged(); }
            get { return _isEnabledSearchBar; }
        }
        public string _SearchText;
        public string SearchText
        {
            set
            {
                _SearchText = value;
                SearchText_TextChanged();
                OnPropertyChanged();
            }
            get { return _SearchText; }
        }
        public Command OnSearchClearCommand => new Command(() =>
        {

            SearchText = string.Empty;


        });
        private string _searchPlaceHolder;
        public string SearchPlaceHolderText
        {
            get { return _searchPlaceHolder; }
            set { _searchPlaceHolder = value; OnPropertyChanged(); }
        }
        private void DynamicSearchPlaceholder()
        {
            SearchPlaceHolderText = "Search Candidate";

        }

        public void SearchText_TextChanged()
        {
            var searchtext = SearchText;
            if (string.IsNullOrEmpty(searchtext))
            {
                SearchPlaceHolderText = "Search Candidate";
                ItemSource = new ObservableCollection<RecruitersearchBO>(_tempRecruitersearchBO);
                IsVisibleSearchbarCancelButton = false;
                return;
            }


            IsVisibleSearchbarCancelButton = true;
            var searchresults = _tempRecruitersearchBO.Where((obj) => obj.profileDetails.FullName.ToLower().Contains(searchtext.ToLower())
                                                             || obj.educationalDetails.CourseName.ToLower().Contains(searchtext.ToLower())
                                                            || obj.educationalDetails.CourseType.ToLower().Contains(searchtext.ToLower()));
            ItemSource = new ObservableCollection<RecruitersearchBO>(searchresults);


        }

        #endregion

        private async void BindSearchResultList()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {

                    var result = await _commonservice.PostAsync<SearchDetailResponse, RecentSearchListItemClickedRequestData>(APIData.API_BASE_URL + APIMethods.Previousrecruitersearch, RecentSearchListItemClickedRequestData);
                    if (result != null)
                    {
                        if (result.code == "200")
                        {
                            isEnabledSearchBar = true;
                            UserDialogs.Instance.HideLoading();
                            // objSearchDetails = new RecruitersearchBO();
                            this.searchDetailData = result.SearchDetailData;
                            ItemSource = new ObservableCollection<RecruitersearchBO>(result.SearchDetailData.searchDetails);
                            _tempRecruitersearchBO = new ObservableCollection<RecruitersearchBO>(result.SearchDetailData.searchDetails);
                        }
                        else
                        {
                            isEnabledSearchBar = false;
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(result.message);
                        }
                    }
                }
                else
                {
                    isEnabledSearchBar = false;
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                SendErrorMessageToServer(ex, "RecruiterSearchResultViewModel.BindSearchResultList");
            }
        }

        private RecruitersearchBO _SelectedItem;
        public RecruitersearchBO SelectedItem
        {
            get { return _SelectedItem; }
            set { _SelectedItem = value; OnPropertyChanged(); }
        }

      
        #region ProfileViewCountIncreseAPICall
        private async void ProfileViewCountIncreseAPICall(RecruitersearchBO objSearchDetails)
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                var request = new ProfileViewerRequestData();
                request.HiremeeID = AppSessionData.ActiveToken.HireMeID;
                request.Token = AppSessionData.ActiveToken.Token;
                request.candidate_hiremee_id = objSearchDetails.candidateID;
                if (objSearchDetails.searchId == 0)
                {
                    request.search_id = objSearchDetails.searchId.ToString();
                }
                else
                {
                    request.search_id = objSearchDetails.searchId.ToString();
                }

                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {
                    var result = await _commonservice.PostAsync<ProfileViewerResponseData, ProfileViewerRequestData>(APIData.API_BASE_URL + APIMethods.RecruiterProfileviewer, request);
                    if (result != null)
                    {
                        UserDialogs.Instance.HideLoading();
                        if (result.code == "200")
                        {
                            var recruiterToCandidate = new CandidateDetailsPage(objSearchDetails, _ItemSource, searchDetailData.searchId, searchDetailData.searchname);
                            await navigation.PushAsync(recruiterToCandidate);
                        }
                        else
                        {
                            await UserDialogs.Instance.AlertAsync(result.message);
                        }  
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "RecruiterSearchResultViewModel.ProfileViewCountIncreseAPICall");
            }
        }
        #endregion
        public ICommand SelectedCommand => new Command(async () =>
        {
            if (isClicked)
            {
                isClicked = false;

                ProfileViewCountIncreseAPICall(SelectedItem);

               
            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });
        });

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
