﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;
using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using MvvmHelpers;
using Xamarin.Forms;
using HireMe.ViewModels;
using HireMe.Helpers;

namespace HireMe
{
    public class RecruiterDashboardViewModel : BaseViewModel
	{
		private HttpCommonService _commonservice { get; set; }
		public ICommand RecruiterCommand { get; set; }
		public RecruiterDashboardModel RecruiterDashboardModel { get; set; }
		public INavigation _navigationservice;
     
        public RecruiterDashboardViewModel(INavigation nav)
        {
            _commonservice = new HttpCommonService();
            _navigationservice = nav;
            RecruiterCommand = new RelayCommand<string>(TapEventCommand);
            RecruiterDashboardModel = new RecruiterDashboardModel();

            if (Device.RuntimePlatform.Equals("Android"))
            {
                //Track Page 
                GoogleAnalyticService.Track_App_Page("Android RecruiterDashboardPage");
            }
            //or iOS 
            else
            {  //Track Page 
                GoogleAnalyticService.Track_App_Page("iOS  RecruiterDashboardPage");
            }


            if (string.IsNullOrEmpty(AppPreferences.ProfilePicture))
            {
                ProfileImage = (string)Application.Current.Resources["IconUser"];
                AppPreferences.ProfilePicture = ProfileImage;
            }
            else
            {
                ProfileImage = AppPreferences.ProfilePicture;
            }


            GetRecruiterDetails();

            MessagingCenter.Subscribe<ChangeProfilePictrurePageViewModel, string>(this, "ChangeProfilePicture", ChangeProfilePicture);
          
        }
        
    
        private void ChangeProfilePicture(ChangeProfilePictrurePageViewModel sender, string path)
        {
            ProfileImage = path;
        }

        #region Click Event Command 
        /// <summary>
		/// Click Event Method
		/// </summary>
       private async void TapEventCommand(string sender)
		{
			switch (sender)
			{

				case "Edit":
					await _navigationservice.PushAsync(new RecruiterProfilePage());
					break;

				case "ProfileImage":
                   
                        
                        await _navigationservice.PushAsync(new ChangeProfilePicturePage());
                    
                   
					break;

			}
		}
		#endregion

		#region GetRecruiterDetails 
		/// <summary>
		/// Webserivce call for RecruiterDetails
		/// </summary>
		public async Task GetRecruiterDetails()
		{

			try
			{
                Device.BeginInvokeOnMainThread(async () =>
                {
                UserDialogs.Instance.ShowLoading();
                if (string.IsNullOrEmpty(AppPreferences.S3AccessKeyID))
                {
                    var obj = new S3Utils();
                    await obj.GetS3Credentials();
                }

                var statusResult = await _commonservice.PostAsync<RecruiterDashboardResponseData, RecruiterDashboardModel>(APIData.API_BASE_URL + APIMethods.RecruiterDashboard, RecruiterDashboardModel);
                if (statusResult != null)
                {
                        CheckVersionUpdates _CheckVersionUpdates = new CheckVersionUpdates();
                        _CheckVersionUpdates.CheckVersion(statusResult.apiVersionCheck);

                        if (AppPreferences.OldVersion == true)
                        {
                            UserDialogs.Instance.HideLoading();
                            Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                            return;
                        }
                        else if (AppPreferences.OldVersion == false)
                        {
                        if (statusResult.RecruiterProfilePicture != null)
                    {
                            AppPreferences.IsAdmin_CompanyProfile = string.Empty;

                        if (!string.IsNullOrEmpty(statusResult.RecruiterProfilePicture.S3_ID))
                        {
                               AppPreferences.IsAdmin_CompanyProfile = statusResult.RecruiterPersonalDetails.IsAdmin;
                                if (AppPreferences.IsAdmin_CompanyProfile == "1")
                                {
                                    BindProfilePic(statusResult.RecruiterProfilePicture.S3_ID,AmazonS3BucketDetails.CompanyLogoBucket);
                                }
                                else
                                {
                                    BindProfilePic(statusResult.RecruiterProfilePicture.S3_ID, AmazonS3BucketDetails.PhotoBucket);
                                }
                        }
                    }

                         BindPersonalDetail(statusResult.RecruiterPersonalDetails); 
                        BindRecruiterDashboardDetails(statusResult.RecruiterDashboardDetails);
                        // BindProfileCompletedPercentage(statusResult.RecruiterProfileCompletePercentage);
                        CurrentProgress = Convert.ToDouble(statusResult.RecruiterProfileCompletePercentage.TotalWeightage) / 100;
                        ProfileScore = statusResult.RecruiterProfileCompletePercentage.TotalWeightage + "%";                    
                       
                    }
				      UserDialogs.Instance.HideLoading();
                    }
                });

				


			}
			catch (Exception ex)
			{
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "RecruiterDashboardViewModel.GetRecruiterDetails");
                //await UserDialogs.Instance.AlertAsync(ex.Message);
            }
		}
        #endregion

        #region BindProfilePic
        private void BindProfilePic(string s3_id,string strBucketName)
        {
            try
            {
                if (!string.IsNullOrEmpty(s3_id))
                {
                    var Imagedownloader = new S3ImageDownloder();
                    Imagedownloader.DownloadProfilePicture(s3_id, strBucketName);
                }
                else
                {
                    AppPreferences.ProfilePicture = (string)Application.Current.Resources["IconUser"];
                }
                ProfileImage = AppPreferences.ProfilePicture;
                MessagingCenter.Send(this, "ChangeProfilePicture", ProfileImage);
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "RecruiterDashboardViewModel.BindProfilePic");
            }
        }

        #endregion

        #region BindPersonalDetail

        private async void BindPersonalDetail(RecruiterProfiledetails recruiterPersonalDetails)
		{
            try
            {
                if (recruiterPersonalDetails != null)
                {
                    if (recruiterPersonalDetails.IsAdmin =="1")
                    {
                        UserName = recruiterPersonalDetails.CompanyName ?? string.Empty;
                    }
                    else
                    {
                        UserName = recruiterPersonalDetails.FullName ?? string.Empty;
                    }
                   
                    EmailID = recruiterPersonalDetails.EmailAddress;
                    HiremeeID = AppSessionData.ActiveToken.HireMeID;
                    MobileNo = recruiterPersonalDetails.MobileNumber;

                    AppPreferences.userName = UserName;

                    string[] details = { UserName, EmailID, "HireMee ID : " + HiremeeID };
                    MessagingCenter.Send(this, "UserDetails", details);
                }
            }
            catch (Exception ex)
            {
                //await UserDialogs.Instance.AlertAsync(ex.Message);
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "RecruiterDashboardViewModel.BindPersonalDetail");
            }
        }
		#endregion

		#region BindRecruiterDashboardDetails
		private async void BindRecruiterDashboardDetails(Recruiterdashboard recruiterDashboardDetails)
		{
            try
            {
                if (recruiterDashboardDetails != null)
			{
				TotalSearchCriterias = recruiterDashboardDetails.SearchHistoryTotal;
				SelectedProfile = recruiterDashboardDetails.CandidateSelectionTotal;
				RejectedProfile = recruiterDashboardDetails.CandidateRejectionTotal;
				InvitedProfile = recruiterDashboardDetails.InvitedProfiles;
                CandidateHired = recruiterDashboardDetails.candidatehired;
                TotalJobPosting = recruiterDashboardDetails.totaljobposting;
                ClosedJobs = recruiterDashboardDetails.closedjobs;
                 ActiveJobs = recruiterDashboardDetails.activejobs;


                }
            }
            catch (Exception ex)
            {
                //await UserDialogs.Instance.AlertAsync(ex.Message);
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "RecruiterDashboardViewModel.BindRecruiterDashboardDetails");

            }
        }
        #endregion

  //      #region BindProfileCompletedPercentage
  //      private async void BindProfileCompletedPercentage(RecruiterProfileweightage recruiterProfileCompletePercentage)
  //      {
  //          try
  //          {
  //              if (recruiterProfileCompletePercentage != null)
  //              {
  //                  int personal;
  //                  int profilepic;
  //                  int companyname;

  //                  if (!int.TryParse(recruiterProfileCompletePercentage.PersonalDetails, out personal))
  //                  {
  //                      personal = 0;
  //                  }

  //                  if (!int.TryParse(recruiterProfileCompletePercentage.ProfilePic, out profilepic))
  //                  {
  //                      profilepic = 0;
  //                  }
  //                  if (!int.TryParse(recruiterProfileCompletePercentage.CompanyName, out companyname))
  //                  {
  //                      companyname = 0;
  //                  }
  //                  CurrentProgress = ((double)(personal + profilepic + companyname)) / 100.0;
  //                  int total = personal + profilepic + companyname;
  //                  ProfileScore = total + "%";
  //                  // Set value to progress bar
  //                  //await ProgressBarScore.ProgressTo(percentage, 1, Easing.Linear);
  //              }
  //          }
  //          catch (Exception ex)
  //          {
  //              // await UserDialogs.Instance.AlertAsync(ex.Message);
  //              System.Diagnostics.Debug.WriteLine(ex.Message);
  //              SendErrorMessageToServer(ex, "RecruiterDashboardViewModel.BindProfileCompletedPercentage");
  //          }
  //      }

		//#endregion

		#region private property

		private string _userName;
		public string UserName
		{
			get { return _userName; }
			set
			{
				_userName = value;
				OnPropertyChanged();
			}
		}

		private string _emailID;
		public string EmailID
		{
			get { return _emailID; }
			set
			{
				_emailID = value;
				OnPropertyChanged();
			}
		}

		private string _mobileNo;
		public string MobileNo
		{
			get { return _mobileNo; }
			set
			{
				_mobileNo = value;
				OnPropertyChanged();
			}
		}

		private string _hiremeeID;
		public string HiremeeID
		{
			get { return _hiremeeID; }
			set
			{
				_hiremeeID = value;
				OnPropertyChanged();
			}
		}

		private string _profileScore;
		public string ProfileScore
		{
			get { return _profileScore; }
			set
			{
				_profileScore = value;
				OnPropertyChanged();
			}
		}

		private string _totalSearchCriterias;
		public string TotalSearchCriterias
		{
			get { return _totalSearchCriterias; }
			set
			{
				_totalSearchCriterias = value;
				OnPropertyChanged();
			}
		}

		private string _selectedProfile;
		public string SelectedProfile
		{
			get { return _selectedProfile; }
			set
			{
				_selectedProfile = value;
				OnPropertyChanged();
			}
		}

		private string _invitedProfile;
		public string InvitedProfile
		{
			get { return _invitedProfile; }
			set
			{
				_invitedProfile = value;
				OnPropertyChanged();
			}
		}

		private string _rejectedProfile;
		public string RejectedProfile
		{
			get { return _rejectedProfile; }
			set
			{
				_rejectedProfile = value;
				OnPropertyChanged();
			}
		}

        private string _CandidateHired;
        public string CandidateHired
        {
            get { return _CandidateHired; }
            set
            {
                _CandidateHired = value;
                OnPropertyChanged();
            }
        }

        private string _TotalJobPosting;
        public string TotalJobPosting
        {
            get { return _TotalJobPosting; }
            set
            {
                _TotalJobPosting = value;
                OnPropertyChanged();
            }
        }

        private string _ClosedJobs;
        public string ClosedJobs
        {
            get { return _ClosedJobs; }
            set
            {
                _ClosedJobs = value;
                OnPropertyChanged();
            }
        }

        private string _ActiveJobs;
        public string ActiveJobs
        {
            get { return _ActiveJobs; }
            set
            {
                _ActiveJobs = value;
                OnPropertyChanged();
            }
        }

        private string _profileImage;
		public string ProfileImage
		{
			get { return _profileImage; }
			set
			{
				_profileImage = value;
				OnPropertyChanged();

			}
		}

        private double _currentProgress=0;
        public double CurrentProgress
        {
            get { return _currentProgress; }
            set
            {
                _currentProgress = value;
                OnPropertyChanged();
            }
        }

        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}

