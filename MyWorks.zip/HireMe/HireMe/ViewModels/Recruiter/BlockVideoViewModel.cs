﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using HireMe.Helpers;
using HireMe.Models.Recruiter;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.Recruiter
{
    public class BlockVideoViewModel : BaseViewModel
    {
        private string _candidateID;
        private int _resocureType;
        private HttpCommonService _commonservice { get; set; }
        private VideoBlockRequest objRequestData { get; set; }
        public ICommand OnblockVideoPageCommand { get; set; }
        INavigation NavigationService;
        public BlockVideoViewModel(string candidateID, int resocureType,INavigation objNav)
        {
            NavigationService = objNav;
            _commonservice = new HttpCommonService();
            objRequestData = new VideoBlockRequest();
            _candidateID = candidateID;
            _resocureType = resocureType;
            OnblockVideoPageCommand = new RelayCommand<string>(OnBlock);
        }

        private async void OnBlock(string sender)
        {
            switch (sender)
            {
                case "DoCancel":
                    await NavigationService.PopAsync();
                    break;
                case "DoBlock":
                    #region Block Button Click Event
                    if (!string.IsNullOrEmpty(EntryBlockContent))
                    {
                        try
                        {
                            UserDialogs.Instance.ShowLoading();
                            objRequestData.CandidateHireMeeIDs = _candidateID;
                            objRequestData.resourcetype_id = _resocureType.ToString();
                            objRequestData.abuse_reason = EntryBlockContent;

                            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                            if (isNetworkAvailable)
                            {
                                var result = await _commonservice.PostAsync<VideoBlockRespense, VideoBlockRequest>(APIData.API_BASE_URL + APIMethods.AbouseReport, objRequestData);
                                UserDialogs.Instance.HideLoading();
                                if (result != null)
                                {
                                    if (result.code == "200")
                                    {
                                        await UserDialogs.Instance.AlertAsync(result.message);
                                        await NavigationService.PopAsync();
                                    }
                                }

                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync("Error: Please check your network connection.");
                            }
                        }
                        catch (Exception ex)
                        {
                            UserDialogs.Instance.HideLoading();
                            SendErrorMessageToServer(ex, "BlockVideoViewModel.OnBlock");
                            //await UserDialogs.Instance.AlertAsync(ex.Message, "HirMee", "OK");
                        }
                    } 
                    else
                    {
                        await UserDialogs.Instance.AlertAsync("Enter your Comments");
                    }

                    #endregion
                    break;

            }
        }

        private string _entryBlockContent;

        public string EntryBlockContent
        {
            get { return _entryBlockContent; }
            set { _entryBlockContent = value; OnPropertyChanged(); }
        }

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
