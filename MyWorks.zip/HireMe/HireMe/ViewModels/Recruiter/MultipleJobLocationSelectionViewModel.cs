﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.Models;
using HireMe.Models.JobSeeker;
using HireMe.Models.Recruiter;
using MvvmHelpers;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace HireMe
{
    public  class MultipleJobLocationSelectionViewModel : BaseViewModel
    {

        ObservableCollection<JobLocation> _JobLocationList;
        public bool isClicked = true;
        private HttpCommonService _commonservice { get; set; }
        private string SearchName = "";
        private List<JobLocation> SelectionSkills;
        List<JobLocation> perferedJobLocationList;
        INavigation Navigation;
        string PageName;
        public MultipleJobLocationSelectionViewModel(INavigation navigation, string pageName, List<JobLocation> skills)
        {

            //if (AppSessionData.ActiveToken.UserType == UserType.JobSeeker)
            //{
            //    isSearchViewVisible = false;
            //}
            //else
            //{
            //    isSearchViewVisible = true;
            //}

            Navigation = navigation;
            PageName = pageName;
            SelectionSkills = skills;
            _commonservice = new HttpCommonService();
            perferedJobLocationList = new List<JobLocation>();
            BindData();

            DoneClicked = new Command(onDoneClicked);
            btnSendIsDestructive = false;
        }

        public Boolean _btnSendIsDestructive;
        public Boolean btnSendIsDestructive
        {
            get { return _btnSendIsDestructive; }
            set { _btnSendIsDestructive = value; OnPropertyChanged(); }
        }

        public Command DoneClicked
        {
            get;
            set;
        }

        private bool _isSearchViewVisible;
        public bool isSearchViewVisible
        {
            get { return _isSearchViewVisible; }
            set { _isSearchViewVisible = value; OnPropertyChanged(); }
        }


        public List<JobLocation> _ItemSource;
        public List<JobLocation> ItemSource
        {
            get { return _ItemSource; }
            set { _ItemSource = value; OnPropertyChanged(); }
        }

        #region Searchbar Controls
        private bool _isVisibleSearchbarCancel;
        public bool IsVisibleSearchbarCancelButton
        {
            get { return _isVisibleSearchbarCancel; }
            set { _isVisibleSearchbarCancel = value; OnPropertyChanged(); }
        }
        public bool _isEnabledSearchBar;

        public bool isEnabledSearchBar
        {
            set { _isEnabledSearchBar = value; OnPropertyChanged(); }
            get { return _isEnabledSearchBar; }
        }
        public string _SearchText;
        public string SearchText
        {
            set
            {
                _SearchText = value;
                SearchText_TextChanged();
                OnPropertyChanged();
            }
            get { return _SearchText; }
        }
        public Command OnSearchClearCommand => new Command(() =>
        {
                        SearchText = string.Empty;
        });
        private string _searchPlaceHolder;
        public string SearchPlaceHolderText
        {
            get { return _searchPlaceHolder; }
            set { _searchPlaceHolder = value; OnPropertyChanged(); }
        }
        private void DynamicSearchPlaceholder()
        {
            SearchPlaceHolderText = "Search Preferred Job Location";

        }

        public void SearchText_TextChanged()
        {
            var searchtext = SearchText;
            if (string.IsNullOrEmpty(searchtext))
            {
                if (perferedJobLocationList.Count > 0)
                {
                    ItemSource = perferedJobLocationList;
                    IsVisibleSearchbarCancelButton = false;
                }
                else
                {
                    IsVisibleSearchbarCancelButton = false;
                    BindData();

                }

                return;
            }
            IsVisibleSearchbarCancelButton = true;
            var searchresults = perferedJobLocationList.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
            ItemSource = searchresults;

        }

        #endregion
        async void BindData()
        {
            Debug.WriteLine("@ DynamicListPage.PreferredJobLocation");
            int currentYear = DateTime.Now.Year;
            perferedJobLocationList = new List<JobLocation>();

            if (_JobLocationList == null)
            {
                try
                {
                    UserDialogs.Instance.ShowLoading();
                    BaseRequestDTO objBaseRequestDTO = new BaseRequestDTO();
                    var responseobj = await _commonservice.PostAsync<PreferredJobLocationResponse,BaseRequestDTO>(APIData.API_BASE_URL + APIMethods.PreferredJobLocation, objBaseRequestDTO);
                if (responseobj != null)
                    {
                        if (responseobj.code == "200" && responseobj.response != null)
                        {
                            foreach (var item in responseobj.response)
                            {
                                perferedJobLocationList.Add(new JobLocation { ID = item.id.ToString(), Title = item.PreferredJobLocation });
                            }
                            isEnabledSearchBar = true;
                            _JobLocationList = new ObservableCollection<JobLocation>(perferedJobLocationList);
                            UserDialogs.Instance.HideLoading();
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            isEnabledSearchBar = false;
                            await UserDialogs.Instance.AlertAsync(responseobj.message);
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        isEnabledSearchBar = false;
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                    UserDialogs.Instance.HideLoading();
                    SendErrorMessageToServer(ex, "MultipleJobLocationSelectionViewModel.BindData");
                }


            }
            
            if (SelectionSkills != null && SelectionSkills.Count > 0)
            {

                if (_JobLocationList.Count > 0 && SelectionSkills.Count > 0)
                {
                    foreach (var obj in _JobLocationList)
                    {
                        obj.IsSelected = false;
                        foreach (var selectionSkill in SelectionSkills)
                        {
                            if (obj.ID == selectionSkill.ID)
                            {
                                obj.IsSelected = selectionSkill.IsSelected;
                            }
                        }
                    }
                }
            }

            ItemSource = perferedJobLocationList;
        }

        public async void onDoneClicked()
        {
            if (isClicked)
            {
                isClicked = false;
                btnSendIsDestructive = true;

                MultipleJobLocationSelectionModel objSelectionBO = new MultipleJobLocationSelectionModel();
                List<JobLocation> selectedJobLocation = new List<JobLocation>();

                if (_JobLocationList != null)
                {
                    foreach (var year in _JobLocationList)
                    {
                        objSelectionBO.SearchName = SearchName;
                        objSelectionBO.YearID = year.ID;
                        objSelectionBO.Title = year.Title;
                        objSelectionBO.IsSelected = year.IsSelected;
                        objSelectionBO.CreatedOn = DateTime.Now;
                        if (year.IsSelected)
                        {
                            selectedJobLocation.Add(year);
                        }
                    }
                }


                updateSelectedSkill(selectedJobLocation);

                //if (PageName == "RecruiterSearchVideoProfile")
                //{
                //    MessagingCenter.Send<MultipleJobLocationSelectionViewModel, List<JobLocation>>(this, "RecruiterSearchVideoProfile", selectedJobLocation);
                //}

                //Navigation.PopAsync();
            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });

        }

        private async void updateSelectedSkill(List<JobLocation> selectedJobLocation)
        {
            try
            {

                if (AppSessionData.ActiveToken.UserType == UserType.JobSeeker)
                {

                    if (PageName == "SeekerPersonalandEducational")
                    {
                        MessagingCenter.Send<MultipleJobLocationSelectionViewModel, List<JobLocation>>(this, "SeekerPersonalandEducational_PreferredJobLocation", selectedJobLocation);
                    }
                    await Navigation.PopAsync();



                }
                else
                {
                    if (PageName == "RecruiterSearchVideoProfile")
                    {
                        MessagingCenter.Send<MultipleJobLocationSelectionViewModel, List<JobLocation>>(this, "RecruiterSearchVideoProfile", selectedJobLocation);
                    }
                    await Navigation.PopAsync();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                await Navigation.PopAsync();
                SendErrorMessageToServer(ex, "MultipleJobLocationSelectionViewModel.updateSelectedSkill");
            }
        }

        public async void On_Toggled(object sender, ToggledEventArgs e)
        {
            var selectedJobLocation = ((Switch)sender).BindingContext as JobLocation;

            //var count = 0;
            //foreach (var obj in _JobLocationList)
            //{
            //    if (obj.IsSelected)
            //        count++;
            //}

            try
            {
                //if (AppSessionData.ActiveToken.UserType == UserType.JobSeeker)
                //{
                    var skillscount = 0;
                    foreach (var skill in _JobLocationList)
                    {
                        if (skill.IsSelected)
                            skillscount++;
                    }
                    //if (AppSessionData.ActiveToken.UserType == UserType.JobSeeker && skillscount > 3)

                    if (skillscount > 3)
                    {
                        selectedJobLocation.IsSelected = false;
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectedMaximumPerferedJobLocation);
                    }
                    //else if (selectedJobLocation.IsSelected)
                    //{
                    //    SelectionSkills.Add(selectedJobLocation);
                    //}
                    //else if (!selectedJobLocation.IsSelected)
                    //{
                    //    SelectionSkills.Remove(selectedJobLocation);
                    //}
                //}

            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "MultipleJobLocationSelectionViewModel.On_Toggled");
            }


        }

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

    }
}