﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.Models.Recruiter;
using HireMe.UI;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.Recruiter
{
    public class RecruiterDraftEmailPageViewModel : BaseViewModel
    {
        string strSearchid;
        string selectedTemplateID;
        string strselectedCandidatelist = string.Empty;
        public TemplateRecruiterListRequestData objRequestData { get; set; }
        public MailtoSelectedCandidatesRequestData objSendMailRequestData { get; set; }
        public HttpCommonService _commmonService { get; set; }
        public ICommand SelectedStatusChanged { get; private set; }
        INavigation navigarionService;
        public ICommand FocusDatePickerCommand { get; set; }
        public ICommand FocusTimePickerCommand { get; set; }
        
        public ICommand OnPreviewCommand { get; set; }
        public Emailtemplate item;

        public RecruiterDraftEmailPageViewModel(string selectedCandidatelist, string searchID,INavigation objNav)
        {
            FocusTimePickerCommand = new Command(OnFocusTimePicker);
            FocusDatePickerCommand = new Command(OnfocusDatePicker);
            OnPreviewCommand = new Command(DoPreview);
            navigarionService = objNav;
            strSearchid = searchID;
            strselectedCandidatelist = selectedCandidatelist;
            objRequestData = new TemplateRecruiterListRequestData();
            objSendMailRequestData = new MailtoSelectedCandidatesRequestData();
            _commmonService = new HttpCommonService();
            UserDialogs.Instance.ShowLoading();
             LoadTemplates();
            UserDialogs.Instance.HideLoading();
            DateLabel = "Select Date";
            TimeLabel = "Select InterviewTime";
            SelectedStatusChanged = new Command(DoSelectItem);

        }

        private void OnFocusTimePicker(object obj)
        {
            var timepicker = (TimePicker)obj;
            timepicker.Focus();
            InterviewTime = timepicker.Time;
        }

        private void DoPreview(object obj)
        {
            SendMailToSelectedCandidate();
        }

        private void OnfocusDatePicker(object obj)
        {
            var datepicker = (DatePicker)obj;
            datepicker.Focus();
            var mindate = DateTime.Now;
            datepicker.MinimumDate = mindate;
            //DateLabel = datepicker.Date.ToString("dd-MM-yyyy");
        }

        #region LoadTemplates in Picker 
        private async Task LoadTemplates()
        {
            try
            {
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {
                    UserDialogs.Instance.ShowLoading();
                    var result = await _commmonService.PostAsync<TemplateRecruiterListResponseData, TemplateRecruiterListRequestData>(APIData.API_BASE_URL + APIMethods.Templatelist, objRequestData);
                    if (result != null)
                    {
                        IdentifyStatusList = new ObservableCollection<Emailtemplate>();
                        if (result.code == "200" && result.Response != null)
                        {
                            var res = result.Response.EmailTemplates;
                            if (res != null)
                            {
                                for (int i = 0; i < res.Count(); i++)
                                {
                                    IdentifyStatusList.Add(new Emailtemplate() { Title = res[i].Title, ID = res[i].ID });
                                }

                            }

                        }
                    }
                    UserDialogs.Instance.HideLoading();
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
            {
                //await UserDialogs.Instance.AlertAsync(ex.Message);
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "RecruiterDraftEmailPageViewModel.LoadTemplates");

            }
        }

        #endregion
        private Command<object> datechagedcommand;
        public Command<object> DateChangedCommand
        {
            get { return datechagedcommand ?? (datechagedcommand = new Command<object>(async arg => await OnDateChangedCommand(arg))); }
        }


        private async Task OnDateChangedCommand(object sender)
        {
            var datepicker = (DatePicker)sender;
            DateLabel = datepicker.Date.ToString("yyyy-MM-dd");
        }


        #region  Send Mail Event
        public async void SendMailToSelectedCandidate()
        {
            if (string.IsNullOrEmpty(selectedTemplateID))
            {
                await UserDialogs.Instance.AlertAsync("Select Template");
            }
            else if (string.IsNullOrEmpty(EditorMailContent))
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterEmailContent);
            }
            else if (DateLabel == "Select Date")
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectDate);
            }
            else if (string.IsNullOrEmpty(EntryInterviewPlace))
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectPlace);
            }
          
         

            else
            {
                try { 
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {
                UserDialogs.Instance.ShowLoading();
                objSendMailRequestData.SearchID = strSearchid;
                objSendMailRequestData.CandidateHireMeeIDs = strselectedCandidatelist;
                objSendMailRequestData.MailTemplate = selectedTemplateID.ToString();
                objSendMailRequestData.Subject = EditorMailContent.Trim();
                objSendMailRequestData.InterviewDate = DateLabel;
                 objSendMailRequestData.InterviewTime = InterviewTime.ToString(@"hh\:mm");
                objSendMailRequestData.InterviewLocation = EntryInterviewPlace;
                objSendMailRequestData.AnyLink = Entrylink;
              
                    var result = await _commmonService.PostAsync<PreviewtoSelectedCandidatesResponseData, MailtoSelectedCandidatesRequestData>(APIData.API_BASE_URL + APIMethods.SendMailPreview, objSendMailRequestData);

                    if (result != null)
                    {
                        if (result.code == "200" && result.Response != null)
                        {

                            await navigarionService.PushAsync(new MailTemplatePage(objSendMailRequestData, result.Response.Mailcontent));

                        }
                    }
                    UserDialogs.Instance.HideLoading();


                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
                {
                    // await UserDialogs.Instance.AlertAsync(ex.Message);
                    System.Diagnostics.Debug.WriteLine(ex.Message);
                    SendErrorMessageToServer(ex, "RecruiterDraftEmailPageViewModel.SendMailToSelectedCandidate");
                }
            }
            
        }

        #endregion

      
        private void DoSelectItem(object obj)
        {
            var picker = (Picker)obj;
            item = (Emailtemplate)picker.SelectedItem;
            if (item != null)
            {
                StatusName = item.Title;
                selectedTemplateID = item.ID.ToString();
            }
        }

       

        #region Binding Properties
        private TimePicker _timePickerTime;
        public TimePicker TimePickerTime
        {
            get { return _timePickerTime; }
            set { _timePickerTime = value; OnPropertyChanged(); }
        }
        private ObservableCollection<Emailtemplate> _identifyStatusList;
        public ObservableCollection<Emailtemplate> IdentifyStatusList
        {
            get { return _identifyStatusList; }
            set
            {
                if (_identifyStatusList != value)
                {
                    _identifyStatusList = value;
                    OnPropertyChanged();
                }
            }
        }
        private TimeSpan _interviewTime;

        public TimeSpan InterviewTime 
        {
            get { return _interviewTime; } 
            set { _interviewTime = value; OnPropertyChanged(); } 
        }
        private string _statusName;
        public string StatusName
        {
            get { return _statusName; }
            set
            {
                if (value == _statusName) return;
                _statusName = value;
                OnPropertyChanged();
            }
        }
        private string _dateLabel;
        public string DateLabel
        {
            get { return _dateLabel; }
            set
            {
                if (value == _dateLabel) return;
                _dateLabel = value;
                OnPropertyChanged();
            }
        }
        
        private string _timeLabel;
        public string TimeLabel
        {
            get { return _timeLabel; }
            set { _timeLabel = value; OnPropertyChanged(); }
        }


        private string _editorMailContent;
        public string EditorMailContent
        {
            get { return _editorMailContent; }
            set
            {
                if (value == _editorMailContent) return;
                _editorMailContent = value;
                OnPropertyChanged();
            }
        }

        private string _entryInterviewPlace;
        public string EntryInterviewPlace
        {
            get { return _entryInterviewPlace; }
            set { _entryInterviewPlace = value; OnPropertyChanged(); }
        }
        private string _entrylink;
        public string Entrylink
        {
            get { return _entrylink; }
            set { _entrylink = value; OnPropertyChanged(); }
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

    }

}
