﻿using MvvmHelpers;
using System.Collections.ObjectModel;
using HireMe.Models.Recruiter;

namespace HireMe.ViewModels.Recruiter
{
    public class CandidateCertificationViewModel : BaseViewModel
    {
        //public ICommand OnCommand { get; set; }

        private ObservableCollection<CertificationsData> item;
        public CandidateCertificationViewModel(ObservableCollection<CertificationsData> certifications)
        {
            //OnCommand = new Command(DoOperation);
            CertificationItemSource = certifications;
        }

        //private void DoOperation(object obj)
        //{
        //    if (obj.ToString() == "Cancel")
        //    {
        //        PopupNavigation.PopAsync();
        //    }
        //}


        private ObservableCollection<CertificationsData> _certificationItemSource;
        public ObservableCollection<CertificationsData> CertificationItemSource
        {
            get { return _certificationItemSource; }
            set { _certificationItemSource = value; OnPropertyChanged(); }
        }
       
    }
}
