﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.Models.Recruiter;
using MvvmHelpers;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace HireMe.ViewModels.Recruiter
{
    public class MultipleStateSelectionViewModel : BaseViewModel
    {
        ObservableCollection<States> _stateList;
        public bool isClicked = true;
        private HttpCommonService _commonservice { get; set; }
        private string SearchName = "";
        private List<States> SelectionSkills;
        List<States> statelist;
        INavigation Navigation;
        string PageName;


        public MultipleStateSelectionViewModel(INavigation navigation, string pageName, List<States> skills)
        {

            Navigation = navigation;
            PageName = pageName;
            SelectionSkills = skills;
            _commonservice = new HttpCommonService();
            statelist = new List<States>();
            BindStateData();

            DoneClicked = new Command(onDoneClicked);
            btnSendIsDestructive = false;
        }

        public Boolean _btnSendIsDestructive;
        public Boolean btnSendIsDestructive
        {
            get { return _btnSendIsDestructive; }
            set { _btnSendIsDestructive = value; OnPropertyChanged(); }
        }

        public Command DoneClicked
        {
            get;
            set;
        }

        public List<States> _StateListItemSource;
        public List<States> StateListItemSource
        {
            get { return _StateListItemSource; }
            set { _StateListItemSource = value; OnPropertyChanged(); }
        }

        #region Searchbar Controls
        private bool _isVisibleSearchbarCancel;
        public bool IsVisibleSearchbarCancelButton
        {
            get { return _isVisibleSearchbarCancel; }
            set { _isVisibleSearchbarCancel = value; OnPropertyChanged(); }
        }

        public bool _isEnabledSearchBar;
        public bool isEnabledSearchBar
        {
            set { _isEnabledSearchBar = value; OnPropertyChanged(); }
            get { return _isEnabledSearchBar; }
        }

        public string _SearchText;
        public string SearchText
        {
            set
            {
                _SearchText = value;
                SearchText_TextChanged();
                OnPropertyChanged();
            }
            get { return _SearchText; }
        }
        public Command OnSearchClearCommand => new Command(() =>
        {

            SearchText = string.Empty;


        });
        private string _searchPlaceHolder;
        public string SearchPlaceHolderText
        {
            get { return _searchPlaceHolder; }
            set { _searchPlaceHolder = value; OnPropertyChanged(); }
        }
        private void DynamicSearchPlaceholder()
        {
            SearchPlaceHolderText = "Search State";

        }

        public void SearchText_TextChanged()
        {
            var searchtext = SearchText;
            if (string.IsNullOrEmpty(searchtext))
            {


                if (statelist.Count > 0)
                {
                    StateListItemSource = statelist;
                    IsVisibleSearchbarCancelButton = false;
                }
                else
                {
                    IsVisibleSearchbarCancelButton = false;
                    BindStateData();

                }

                return;
            }
            IsVisibleSearchbarCancelButton = true;
            var searchresults = statelist.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
            StateListItemSource = searchresults;
        }
        #endregion



        async void BindStateData()
        {
            Debug.WriteLine("@ DynamicListPage.BindStateData");
            
            statelist = new List<States>();

            if (_stateList == null)
            {
                try
                {
                    UserDialogs.Instance.ShowLoading();
                    var requestdata = new MasterTableRequestData()
                    {
                        HiremeeID = AppSessionData.ActiveToken.HireMeID,
                        Token = AppSessionData.ActiveToken.Token,
                        TableName = "state"
                    };

                    var responseobj = await _commonservice.PostAsync<StateResponseData, MasterTableRequestData>(APIData.API_BASE_URL + APIMethods.MasterTables, requestdata);
                    if (responseobj != null)
                    {
                        if (responseobj.code == "200" && responseobj.Response.Response != null)
                        {
                            foreach (var item in responseobj.Response.Response)
                            {
                                statelist.Add(new States { ID = item.ID.ToString(), Title = item.Title });
                            }
                            isEnabledSearchBar = true;
                            _stateList = new ObservableCollection<States>(statelist);
                            UserDialogs.Instance.HideLoading();
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            isEnabledSearchBar = false;
                            await UserDialogs.Instance.AlertAsync(responseobj.message);
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        isEnabledSearchBar = false;
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                    UserDialogs.Instance.HideLoading();
                    SendErrorMessageToServer(ex, "MultipleStateSelectionViewModel.BindStateData");
                }


            }


            //MultipleYearSelectionHelper objSelectionHelper = new MultipleYearSelectionHelper();
            //  List<MultipleYearSelectionBO> selectedSkills = objSelectionHelper.GetData(SearchName);
            if (SelectionSkills != null && SelectionSkills.Count > 0)
            {

                if (_stateList.Count > 0 && SelectionSkills.Count > 0)
                {
                    foreach (var skills in _stateList)
                    {
                        skills.IsSelected = false;
                        foreach (var selectionSkill in SelectionSkills)
                        {
                            if (skills.ID == selectionSkill.ID)
                            {
                                skills.IsSelected = selectionSkill.IsSelected;
                            }
                        }
                    }
                }
            }

            StateListItemSource = statelist;
        }

        public async void onDoneClicked()
        {
            if (isClicked)
            {
                isClicked = false;
                btnSendIsDestructive = true;

                //MultipleYearSelectionHelper objSelectionHelper = new MultipleYearSelectionHelper();
                //List<MultipleYearSelectionBO> lstMultipleSkillSelection = objSelectionHelper.GetData(SearchName);

                //if (lstMultipleSkillSelection.Count > 0)
                //{
                //    objSelectionHelper.DeleteData();
                //}


                MultipleStateSelectionBO objSelectionBO = new MultipleStateSelectionBO();
                List<States> selectedStates = new List<States>();

                if (_stateList != null)
                {
                    foreach (var state in _stateList)
                    {
                        objSelectionBO.SearchName = SearchName;
                        objSelectionBO.StateID = state.ID;
                        objSelectionBO.Title = state.Title;
                        objSelectionBO.IsSelected = state.IsSelected;
                        objSelectionBO.CreatedOn = DateTime.Now;
                        //objSelectionHelper.AddData(objSelectionBO);
                        if (state.IsSelected)
                        {
                            selectedStates.Add(state);
                        }
                    }
                }


                if (PageName == "RecruiterSearchVideoProfile")
                {
                    MessagingCenter.Send<MultipleStateSelectionViewModel, List<States>>(this, "RecruiterSearchVideoProfile", selectedStates);
                }

                Navigation.PopAsync();
            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });
        }


        public async void OnSkill_Toggled(object sender, ToggledEventArgs e)
        {
            var selectedState = ((Switch)sender).BindingContext as States;

            var skillscount = 0;
            foreach (var state in _stateList)
            {
                if (state.IsSelected)
                    skillscount++;
            }

            if (skillscount > 3)
            {
                selectedState.IsSelected = false;
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectedMaximumstate);
            }

        }

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

    }
}
