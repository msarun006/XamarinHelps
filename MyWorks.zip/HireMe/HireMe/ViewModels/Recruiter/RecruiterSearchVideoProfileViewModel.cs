﻿using System;
using MvvmHelpers;
using System.Collections.Generic;
using Xamarin.Forms;
using Plugin.Connectivity;
using Acr.UserDialogs;
using HireMe.UI;
using System.Threading.Tasks;
using HireMe.Models.Recruiter;
using HireMe.Views.Recruiter;
using HireMe.Views;
using HireMe.ViewModels;
using HireMe.ViewModels.Recruiter;
using HireMe.Helpers;

namespace HireMe
{
    public class RecruiterSearchVideoProfileViewModel : BaseViewModel
    {

        #region Object Creation
        SearchDetailRequestData data;
        Educational_Details _modifiededucationalDetails;
        Skill _modifiededucationalSkill;
        private List<Skill> skills;
        private List<Year> years;

        private List<CommonBO> MultipleCollegeData;
        private List<CommonBO> MultipleCourseTypeData;
        private List<CommonBO> MultipleCourseData;
        private List<CommonBO> MultipleSpecializationData;
        private List<CommonBO> MultipleCityData;

        private List<JobLocation> jobLocation;
        private List<States> states;


        private HttpCommonService _commonservice { get; set; }
        string _SearchName, _CollegeName, _CourseType, _CourseName, _Skill, _Specialization, _YearofCompletion, _jobLocations, _state, _city;
        public bool isClicked = true;
        INavigation Navigation;
        #endregion

        public RecruiterSearchVideoProfileViewModel(INavigation navigation)
        {
            data = new SearchDetailRequestData();
            _modifiededucationalDetails = new Educational_Details();
            _modifiededucationalSkill = new Skill();
            Navigation = navigation;

            _commonservice = new HttpCommonService();
            if (Device.RuntimePlatform.Equals("Android"))
            {
                //Track Page 
                GoogleAnalyticService.Track_App_Page("Android RecruiterSearchVideoProfile");
            }
            //or iOS 
            else
            { //Track Page 
                GoogleAnalyticService.Track_App_Page("iOS  RecruiterSearchVideoProfile");
            }

            OnButtonClickEvent = new Command<string>(CallCommonFunction);
            RecruiterSearchVideoProfileModel = new RecruiterSearchVideoProfileModel();



            MessagingCenter.Subscribe<DynamicListPageViewModel, CommonListItemSource>(this, "RecruiterSearchVideoProfile", (sender, arg) =>
            {
                SetFieldValue(arg.fieldType, arg);
            });



            MessagingCenter.Subscribe<MultipleSkillsSelectionViewModel, List<Skill>>(this, "RecruiterSearchVideoProfile", (sender, arg) =>
            {
                SetFieldValue(Constants.FieldType.PrimarySkill, arg);
            });


            MessagingCenter.Subscribe<MultipleSelectionViewModel, List<CommonBO>>(this, Constants.FieldType.College, (sender, arg) =>
            {
                SetFieldValue(Constants.FieldType.College, arg);
            });


            MessagingCenter.Subscribe<MultipleSelectionViewModel, List<CommonBO>>(this, Constants.FieldType.CourseType, (sender, arg) =>
            {
                SetFieldValue(Constants.FieldType.CourseType, arg);
            });

            MessagingCenter.Subscribe<MultipleSelectionViewModel, List<CommonBO>>(this, Constants.FieldType.Course, (sender, arg) =>
            {
                SetFieldValue(Constants.FieldType.Course, arg);
            });

            MessagingCenter.Subscribe<MultipleSelectionViewModel, List<CommonBO>>(this, Constants.FieldType.Specialization, (sender, arg) =>
            {
                SetFieldValue(Constants.FieldType.Specialization, arg);
            });

            MessagingCenter.Subscribe<MultipleSelectionViewModel, List<CommonBO>>(this, Constants.FieldType.City, (sender, arg) =>
            {
                SetFieldValue(Constants.FieldType.City, arg);
            });

            MessagingCenter.Subscribe<MultipleYearSelectionPageViewModel, List<Year>>(this, "RecruiterSearchVideoProfile", (sender, arg) =>
            {
                SetFieldValue(Constants.FieldType.YearOfCompletion, arg);
            });

            MessagingCenter.Subscribe<MultipleJobLocationSelectionViewModel, List<JobLocation>>(this, "RecruiterSearchVideoProfile", (sender, arg) =>
            {
                SetFieldValue(Constants.FieldType.PreferredJobLocation, arg);
            });

            MessagingCenter.Subscribe<MultipleStateSelectionViewModel, List<States>>(this, "RecruiterSearchVideoProfile", (sender, arg) =>
            {
                SetFieldValue(Constants.FieldType.State, arg);
            });


        }


        #region ClearAll
        void ClearAll()
        {
            data = new SearchDetailRequestData();
            _modifiededucationalDetails = new Educational_Details();
            skills = new List<Skill>();
            years = new List<Year>();
            MultipleCollegeData = new List<CommonBO>();
            MultipleCourseData = new List<CommonBO>();
            MultipleCourseTypeData = new List<CommonBO>();
            MultipleSpecializationData = new List<CommonBO>();
            MultipleCityData = new List<CommonBO>();
            jobLocation = new List<JobLocation>();
            states = new List<States>();
            if (!string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.SearchTitle))
            {
                RecruiterSearchVideoProfileModel.SearchTitle = string.Empty;
            }
            if (!string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.CollegeName))
            {
                RecruiterSearchVideoProfileModel.CollegeName = string.Empty;
            }
            if (!string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.CourseType))
            {
                RecruiterSearchVideoProfileModel.CourseType = string.Empty;
            }
            if (!string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.CourseName))
            {
                RecruiterSearchVideoProfileModel.CourseName = string.Empty;
            }
            if (!string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.Specialization))
            {
                RecruiterSearchVideoProfileModel.Specialization = string.Empty;
            }
            if (!string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.Skill))
            {
                RecruiterSearchVideoProfileModel.Skill = string.Empty;
            }
            if (!string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.YearOfCompletion))
            {
                RecruiterSearchVideoProfileModel.YearOfCompletion = string.Empty;
            }
            if (!string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.JobLocations))
            {
                RecruiterSearchVideoProfileModel.JobLocations = string.Empty;
            }

            if (!string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.State))
            {
                RecruiterSearchVideoProfileModel.State = string.Empty;
            }
            if (!string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.City))
            {
                RecruiterSearchVideoProfileModel.City = string.Empty;
            }
            if (!string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.DesignationText))
            {
                RecruiterSearchVideoProfileModel.DesignationText = string.Empty;
            }
        }
        #endregion


        #region IsValid
        public bool IsValid()
        {
            bool valid = false;
            //if (string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.SearchTitle))
            //{
            //    Device.BeginInvokeOnMainThread(async () =>
            //    {
            //        await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterSearchName);

            //    });

            //    valid = true;
            //}
            if (string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.CollegeName) &&
                     string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.CourseType) &&
                     string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.CourseName) &&
                     string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.Specialization) &&
                     string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.Skill) &&
                     string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.City) &&
                     string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.YearOfCompletion) &&
                     string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.State) &&
                string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.JobLocations))
            {
                Device.BeginInvokeOnMainThread(async () =>
                {
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectAtleastOneField);

                });

                valid = true;
            }

            else
            {
                if (!string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.SearchTitle))
                {
                    _SearchName = RecruiterSearchVideoProfileModel.SearchTitle;
                }
                else
                {
                    _SearchName = string.Empty;
                }
                if (!string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.CollegeName))
                {
                    _CollegeName = _modifiededucationalDetails.college_id;
                }
                else
                {
                    _CollegeName = string.Empty;
                }
                if (!string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.CourseType))
                {
                    _CourseType = _modifiededucationalDetails.coursetype_id;
                }
                else
                {
                    _CourseType = string.Empty;
                }
                if (!string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.CourseName))
                {
                    _CourseName = _modifiededucationalDetails.course_id;
                }
                else
                {
                    _CourseName = string.Empty;
                }
                if (!string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.Specialization))
                {
                    _Specialization = _modifiededucationalDetails.specialization_id;
                }
                else
                {
                    _Specialization = string.Empty;
                }
                if (!string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.Skill))
                {
                    _Skill = _modifiededucationalSkill.ID;
                }
                else
                {
                    _Skill = string.Empty;
                }
                if (!string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.YearOfCompletion))
                {
                    _YearofCompletion = RecruiterSearchVideoProfileModel.YearOfCompletion;
                }
                else
                {
                    _YearofCompletion = string.Empty;
                }
                if (!string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.JobLocations))
                {
                    _jobLocations = RecruiterSearchVideoProfileModel.JobLocationID;
                }
                else
                {
                    _jobLocations = string.Empty;
                }
                if (!string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.State))
                {
                    _state = RecruiterSearchVideoProfileModel.StateID;
                }
                else
                {
                    _state = string.Empty;
                }
                if (!string.IsNullOrEmpty(RecruiterSearchVideoProfileModel.City))
                {
                    _city = _modifiededucationalDetails.city_id;
                }
                else
                {
                    _city = string.Empty;
                }
            }

            return valid;
        }
        #endregion

        #region Retrieve seeker list using SearchCandidate Click Event
        public async void SearchCandidate()
        {
            if (isClicked)
            {
                isClicked = false;
                try
                {
                    if (!IsValid())
                    {
                        UserDialogs.Instance.ShowLoading();
                        System.Diagnostics.Debug.WriteLine("@ RecruiterSearchVideoProfile.SearchCandidate");
                        data.CourseID = _CourseName;
                        data.Designation = string.Empty;
                        data.StateID = _state;
                        data.CityID = _city;
                        data.CourseType = _CourseType;
                        data.CollegeID = _CollegeName;
                        data.SpecializationID = _Specialization;
                        data.SkillID = _Skill;
                        data.YearOfCompletion = _YearofCompletion;
                        data.SearchName = AppSessionData.ActiveToken.HireMeID + "-" + DateTime.Now.ToString();//string.Empty;
                        data.JobLocation = _jobLocations;
                        if (RecruiterSearchVideoProfileModel.DesignationText != null)
                            data.Designation = RecruiterSearchVideoProfileModel.DesignationText;
                        else
                            data.Designation = string.Empty;
                        var statusResult = await _commonservice.PostAsync<SearchDetailResponse, SearchDetailRequestData>(APIData.API_BASE_URL + APIMethods.RecruiterSearch, data);
                        if (statusResult != null)
                        {
                            UserDialogs.Instance.HideLoading();
                            if (statusResult.code == "200")
                            {
                                if (statusResult.SearchDetailData != null)
                                {
                                    string searchid = Convert.ToString(statusResult.SearchDetailData.searchId);
                                    if (statusResult.SearchDetailData.searchDetails.Count != 0)
                                    {
                                        await Navigation.PushAsync(new RecruiterSearchResult(statusResult.SearchDetailData));
                                    }
                                    else
                                    {
                                        await UserDialogs.Instance.AlertAsync("No Candidates Found");
                                    }
                                }
                                else
                                {
                                    await UserDialogs.Instance.AlertAsync("No Candidates Found");
                                }

                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(statusResult.message);
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                        }
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine(ex);
                    SendErrorMessageToServer(ex, "RecruiterSearchVideoProfileViewModel.SearchCandidate");
                }
            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });

        }
        #endregion

        public async void CallCommonFunction(string obj)
        {

            if (isClicked)
            {
                isClicked = false;

                if (obj.ToString() == "clearall")
                {
                    isClicked = true;
                    ClearAll();
                }
                else if (obj.ToString() == "resendsearch")
                {
                    await Navigation.PushAsync(new RecruiterRecentSearchPage());
                }
                else if (obj.ToString() == "advancedsearch")
                {
                    await this.Navigation.PushAsync(new AdvancedSearchOption(data));
                }
                else if (obj.ToString() == "collegenametapped")
                {
                    await this.Navigation.PushAsync(new MutipleSelectionPage(Constants.FieldType.College, MultipleCollegeData));
                }
                else if (obj.ToString() == "coursetypetapped")
                {

                    //  NavigateToDynamicListPage(Constants.FieldType.CourseType, "1");
                    await this.Navigation.PushAsync(new MutipleSelectionPage(Constants.FieldType.CourseType, MultipleCourseTypeData));
                }
                else if (obj.ToString() == "coursenametapped")
                {
                    if (_modifiededucationalDetails.coursetype_id != null && !string.IsNullOrWhiteSpace(AppPreferences.SelectedCourseTypeID))
                    {
                        await this.Navigation.PushAsync(new MutipleSelectionPage(Constants.FieldType.Course, MultipleCourseData));
                        //NavigateToDynamicListPage(Constants.FieldType.Course, _modifiededucationalDetails.coursetype_id);
                    }
                    else
                    {
                        RecruiterSearchVideoProfileModel.CourseName = string.Empty;
                        await UserDialogs.Instance.AlertAsync("Select CourseType");
                    }
                }
                else if (obj.ToString() == "specializationtapped")
                {
                    if (_modifiededucationalDetails.course_id != null)
                    {
                        await this.Navigation.PushAsync(new MutipleSelectionPage(Constants.FieldType.Specialization, MultipleSpecializationData));
                        //NavigateToDynamicListPage(Constants.FieldType.Specialization, _modifiededucationalDetails.course_id);
                    }
                    else
                    {
                        await UserDialogs.Instance.AlertAsync("Select Course");
                    }
                }
                else if (obj.ToString() == "skilltapped")
                {
                    if (CrossConnectivity.Current.IsConnected)
                    {
                        //  await this.Navigation.PushAsync(new MultipleSkillSelection(skills, "RecruiterSearchVideoProfile"));
                        await this.Navigation.PushAsync(new MultipleSkillsSelectionPage("RecruiterSearchVideoProfile", skills, "1"));
                    }
                    else
                    {
                        UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                    }
                }
                else if (obj.ToString() == "yearofcompletion")
                {
                    await this.Navigation.PushAsync(new MultipleYearSelectionPage("RecruiterSearchVideoProfile", years));
                }
                else if (obj.ToString() == "state")
                {
                    await this.Navigation.PushAsync(new MultipleStateSelectionPage("RecruiterSearchVideoProfile", states));
                }
                else if (obj.ToString() == "city")
                {
                    if (_modifiededucationalDetails.state_id != null && !string.IsNullOrWhiteSpace(AppPreferences.SelectedStateID))
                    {
                        await this.Navigation.PushAsync(new MutipleSelectionPage(Constants.FieldType.City, MultipleCityData));
                        //NavigateToDynamicListPage(Constants.FieldType.Course, _modifiededucationalDetails.coursetype_id);
                    }
                    else
                    {
                        RecruiterSearchVideoProfileModel.State = string.Empty;
                        await UserDialogs.Instance.AlertAsync("Select State");
                    }
                }

                else if (obj.ToString() == "PreferredJobLocation")
                {
                    await this.Navigation.PushAsync(new MultipleJobLocationSelectionPage("RecruiterSearchVideoProfile", jobLocation));
                }
                else if (obj.ToString() == "search")
                {
                    isClicked = true;
                    SearchCandidate();
                }
            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });

        }




        #region NavigateToDynamicListPage
        public void NavigateToDynamicListPage(String _fieldType, String _fieldValue)
        {
            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
            if (isNetworkAvailable)
            {
                this.Navigation.PushAsync(new DynamicListPage("RecruiterSearchVideoProfile", _fieldType, _fieldValue));
            }
            else
            {
                UserDialogs.Instance.Toast("Check Internet Connection");

            }

        }
        #endregion



        #region SetFieldValue
        public void SetFieldValue(string fieldtype, object fieldvalue)
        {


            if (fieldtype == Constants.FieldType.PrimarySkill)
            {
                skills = ((List<Skill>)fieldvalue);

                string skilltext = string.Empty;
                string skillparams = string.Empty;
                int skillscount = skills.Count;
                int counter = 0;
                foreach (var skill in skills)
                {
                    counter++;
                    skilltext += skill.SkillName;
                    skillparams += skill.ID;
                    if (counter < skillscount)
                    {
                        skilltext += ", ";
                        skillparams += ",";
                    }
                }

                RecruiterSearchVideoProfileModel.Skill = skilltext;
                _modifiededucationalSkill.ID = skillparams;
                _modifiededucationalSkill.SkillName = skilltext;
            }
            else if (fieldtype == Constants.FieldType.CollegeList)
            {
                MultipleCollegeData = ((List<CommonBO>)fieldvalue);
                string textdata = string.Empty;
                string textparams = string.Empty;
                int Collegecount = MultipleCollegeData.Count;
                int counter = 0;
                foreach (var item in MultipleCollegeData)
                {
                    counter++;
                    textdata += item.Title;
                    textparams += item.ID;
                    if (counter < Collegecount)
                    {
                        textdata += ", ";
                        textparams += ",";
                    }
                }
                RecruiterSearchVideoProfileModel.CollegeName = textdata;
                _modifiededucationalDetails.college_name = textdata;
                _modifiededucationalDetails.college_id = textparams;




            }
            else if (fieldtype == Constants.FieldType.CourseType)
            {
                MultipleCourseTypeData = ((List<CommonBO>)fieldvalue);
                string textdata = string.Empty;
                string textparams = string.Empty;
                int CourseTypecount = MultipleCourseTypeData.Count;
                int counter = 0;
                foreach (var item in MultipleCourseTypeData)
                {
                    counter++;
                    textdata += item.Title;
                    textparams += item.ID;
                    if (counter < CourseTypecount)
                    {
                        textdata += ", ";
                        textparams += ",";
                    }
                }
                RecruiterSearchVideoProfileModel.CourseType = textdata;
                _modifiededucationalDetails.course_type_name = textdata;
                _modifiededucationalDetails.coursetype_id = textparams;
                AppPreferences.SelectedCourseTypeID = textparams;



                RecruiterSearchVideoProfileModel.CourseName = string.Empty;
                MultipleCourseData = new List<CommonBO>();


            }

            else if (fieldtype == Constants.FieldType.Course)
            {
                MultipleCourseData = ((List<CommonBO>)fieldvalue);
                string textdata = string.Empty;
                string textparams = string.Empty;
                int CourseTypecount = MultipleCourseData.Count;
                int counter = 0;
                foreach (var item in MultipleCourseData)
                {
                    counter++;
                    textdata += item.Title;
                    textparams += item.ID;
                    if (counter < CourseTypecount)
                    {
                        textdata += ", ";
                        textparams += ",";
                    }
                }
                RecruiterSearchVideoProfileModel.CourseName = textdata;
                _modifiededucationalDetails.course_name = textdata;
                _modifiededucationalDetails.course_id = textparams;
                AppPreferences.SelectedCourseID = textparams;


                RecruiterSearchVideoProfileModel.Specialization = string.Empty;
                MultipleSpecializationData = new List<CommonBO>();


            }

            else if (fieldtype == Constants.FieldType.Specialization)
            {
                MultipleSpecializationData = ((List<CommonBO>)fieldvalue);
                string textdata = string.Empty;
                string textparams = string.Empty;
                int CourseTypecount = MultipleSpecializationData.Count;
                int counter = 0;
                foreach (var item in MultipleSpecializationData)
                {
                    counter++;
                    textdata += item.Title;
                    textparams += item.ID;
                    if (counter < CourseTypecount)
                    {
                        textdata += ", ";
                        textparams += ",";
                    }
                }
                RecruiterSearchVideoProfileModel.Specialization = textdata;
                _modifiededucationalDetails.specialization_name = textdata;
                _modifiededucationalDetails.specialization_id = textparams;


            }
            else if (fieldtype == Constants.FieldType.City)
            {
                MultipleCityData = ((List<CommonBO>)fieldvalue);
                string textdata = string.Empty;
                string textparams = string.Empty;
                int citycount = MultipleCityData.Count;
                int counter = 0;
                foreach (var item in MultipleCityData)
                {
                    counter++;
                    textdata += item.Title;
                    textparams += item.ID;
                    if (counter < citycount)
                    {
                        textdata += ", ";
                        textparams += ",";
                    }
                }
                RecruiterSearchVideoProfileModel.City = textdata;
                _modifiededucationalDetails.city_name = textdata;
                _modifiededucationalDetails.city_id = textparams;

            }
            else if (fieldtype == Constants.FieldType.YearOfCompletion)
            {
                // labelYearofCompletion.Text = ((CompletionYear)fieldvalue).Title;

                years = ((List<Year>)fieldvalue);

                string skilltext = string.Empty;
                string skillparams = string.Empty;
                int yearscount = years.Count;
                int counter = 0;
                foreach (var year in years)
                {
                    counter++;
                    skilltext += year.Title;
                    skillparams += year.ID;
                    if (counter < yearscount)
                    {
                        skilltext += ", ";
                        skillparams += ",";
                    }
                }

                RecruiterSearchVideoProfileModel.YearOfCompletion = skilltext;
                _modifiededucationalDetails.year_of_completion = skilltext;

            }


            else if (fieldtype == Constants.FieldType.State)
            {
                states = ((List<States>)fieldvalue);

                string title = string.Empty;
                string id = string.Empty;
                int length = states.Count;
                int counter = 0;
                foreach (var skill in states)
                {
                    counter++;
                    id += skill.ID;
                    title += skill.Title;
                    if (counter < length)
                    {
                        id += ",";
                        title += ", ";
                    }
                }
                if (counter == 0)
                {
                    RecruiterSearchVideoProfileModel.State = string.Empty;

                }
                else
                {
                    RecruiterSearchVideoProfileModel.State = title;
                    RecruiterSearchVideoProfileModel.StateID = id;
                    _modifiededucationalDetails.state_id = id;
                    AppPreferences.SelectedStateID = _modifiededucationalDetails.state_id;
                    _modifiededucationalDetails.state_name = title;

                    RecruiterSearchVideoProfileModel.City = string.Empty;
                    MultipleCityData = new List<CommonBO>();

                }

            }

            //else if (fieldtype == Constants.FieldType.State)
            //{
            //    // labelYearofCompletion.Text = ((CompletionYear)fieldvalue).Title;

            //    years = ((List<Year>)fieldvalue);

            //    string skilltext = string.Empty;
            //    string skillparams = string.Empty;
            //    int yearscount = years.Count;
            //    int counter = 0;
            //    foreach (var year in years)
            //    {
            //        counter++;
            //        skilltext += year.Title;
            //        skillparams += year.ID;
            //        if (counter < yearscount)
            //        {
            //            skilltext += ", ";
            //            skillparams += ",";
            //        }
            //    }

            //    RecruiterSearchVideoProfileModel.YearOfCompletion = skilltext;
            //    _modifiededucationalDetails.year_of_completion = skilltext;

            //}
            else if (fieldtype == Constants.FieldType.PreferredJobLocation)
            {
                // labelYearofCompletion.Text = ((CompletionYear)fieldvalue).Title;

                jobLocation = ((List<JobLocation>)fieldvalue);

                string skilltext = string.Empty;
                string skillparams = string.Empty;
                int yearscount = jobLocation.Count;
                int counter = 0;
                foreach (var year in jobLocation)
                {
                    counter++;
                    skilltext += year.Title;
                    skillparams += year.ID;
                    if (counter < yearscount)
                    {
                        skilltext += ", ";
                        skillparams += ",";
                    }
                }

                RecruiterSearchVideoProfileModel.JobLocations = skilltext;
                RecruiterSearchVideoProfileModel.JobLocationID = skillparams;
                // _modifiededucationalDetails.p = skilltext;

            }
        }
        #endregion





        public Command OnButtonClickEvent
        {
            get;
            set;
        }


        private RecruiterSearchVideoProfileModel recruiterSearchVideoProfileModel;
        public RecruiterSearchVideoProfileModel RecruiterSearchVideoProfileModel
        {
            get { return recruiterSearchVideoProfileModel; }
            set { recruiterSearchVideoProfileModel = value; OnPropertyChanged(); }

        }

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion


    }
}
