﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using HireMe.Helpers;
using MvvmHelpers;
using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.Recruiter
{
    public class CommentPopupViewModel : BaseViewModel
    {
        string candidateid;
        ObservableCollection<Recruitercommentsdetail> _CandidateComments;
        private HttpCommonService _commonservice { get; set; }
        public ICommand AddCommentCommand { get; set; }
        INavigation Navigation;
        public bool isClicked = true;
        public CommentPopupViewModel(string objcandidateid, ObservableCollection<Recruitercommentsdetail> CandidateComments, INavigation nav)
        {
            candidateid = objcandidateid;
            Navigation = nav;
            _commonservice = new HttpCommonService();
            AddCommentCommand = new RelayCommand<string>(DoOperation);
            if (CandidateComments == null)
            {
                _CandidateComments = new ObservableCollection<Recruitercommentsdetail>();
            }
            else
            {
                _CandidateComments = CandidateComments;
            }
        }

        private string _commenttext;
        public string CommentText
        {
            get { return _commenttext; }
            set { _commenttext = value; OnPropertyChanged(); }
        }

        private async void DoOperation(string sender)
        {
            switch (sender)
            {
                case "OnSubmit":
                    if (isClicked)
                    {
                        isClicked = false;
                        if (string.IsNullOrEmpty(CommentText))
                    {
                        await UserDialogs.Instance.AlertAsync("Enter your Comments");
                    }
                    else
                    {
                        try
                        {
                            UserDialogs.Instance.ShowLoading();
                            var requestdata = new MasterTableRequestData()
                            {
                                HiremeeID = AppSessionData.ActiveToken.HireMeID,
                                Token = AppSessionData.ActiveToken.Token,
                                CandidateID = candidateid,
                                RecruiterComment = CommentText.Trim(),
                            };
                            var responseobj = await _commonservice.PostAsync<CommentsResponseText, MasterTableRequestData>(APIData.API_BASE_URL + APIMethods.Comment, requestdata);
                            if (responseobj != null)
                            {
                                if (responseobj.code == "200")
                                {
                               
                                    var obj = new Recruitercommentsdetail()
                                    {
                                        fullname = AppPreferences.userName,
                                        recruiter_comments = CommentText.Trim(),
                                        created_at = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                                    };
                                    _CandidateComments.Add(obj);

                                    UserDialogs.Instance.HideLoading();

                                    UserDialogs.Instance.Toast(responseobj.message);
                                    CommentText = string.Empty;
                                    await Navigation.PopAsync();
                                }
                                else
                                {
                                    UserDialogs.Instance.HideLoading();
                                    await UserDialogs.Instance.AlertAsync(responseobj.message);
                                    await Navigation.PopAsync();
                                }
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                            }
                        }
                        catch (Exception ex)
                        {
                            Debug.WriteLine(ex.Message);
                            UserDialogs.Instance.HideLoading();
                            SendErrorMessageToServer(ex, "CommentPopupViewModel.DoOperation");
                        }
                    }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                case "OnCancel":
                    await Navigation.PopAsync();
                    break;
            }
        }

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
