﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using HireMe.Helpers;
using HireMe.Models.Recruiter;
using MvvmHelpers;
using Plugin.Connectivity;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.Recruiter
{
    public class CandidateEducationViewModel : BaseViewModel
    {
        private HttpCommonService _commonservice { get; set; }
        public CandidateEducationRequest BaseRequest;
        string _candidateID;
        public ICommand OnCommand { get; set; }
        public CandidateEducationViewModel(string candidateID)
        {
            _candidateID = candidateID;
            _commonservice = new HttpCommonService();
            BaseRequest = new CandidateEducationRequest();
            ItemSource = new ObservableCollection<Educational_Details>();
            OnCommand = new RelayCommand<string>(DoOperation);
            BindEducationalDetailsToView();
        }

        private void DoOperation(string obj)
        {
            switch (obj)
            {
                case "Cancel":
                    PopupNavigation.PopAsync();
                    break;
            }
        }

        public async Task BindEducationalDetailsToView()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                try
                {
                    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                    if (isNetworkAvailable)
                    {
                        UserDialogs.Instance.ShowLoading();
                        BaseRequest.Candidate_HireMeeID = _candidateID;
                        var statusResult = await _commonservice.PostAsync<EducationalDetailsEntrieResponse, CandidateEducationRequest>(APIData.API_BASE_URL + APIMethods.GetEducationDetails, BaseRequest);
                     
                        if (statusResult != null)
                        {
                            if (statusResult.code == "200")
                            {
                                if (statusResult.responseText.educational_details != null)
                                {
                                    for (int i = 0; i < statusResult.responseText.educational_details.Length; i++)
                                    {
                                        Educational_Details obj = new Educational_Details();
                                        obj.hiremee_id = statusResult.responseText.educational_details[i].hiremee_id;
                                        obj.coursetype_id = statusResult.responseText.educational_details[i].coursetype_id;
                                        obj.course_type_name = statusResult.responseText.educational_details[i].course_type_name;
                                        obj.course_id = statusResult.responseText.educational_details[i].course_id;
                                        obj.course_name = statusResult.responseText.educational_details[i].course_name;
                                        obj.specialization_id = statusResult.responseText.educational_details[i].specialization_id;
                                        obj.specialization_name = statusResult.responseText.educational_details[i].specialization_name;
                                        obj.educational_level = statusResult.responseText.educational_details[i].educational_level;
                                        obj.board_id = statusResult.responseText.educational_details[i].board_id;
                                        obj.board_name = statusResult.responseText.educational_details[i].board_name;
                                        obj.school_name = statusResult.responseText.educational_details[i].school_name;
                                        obj.college_id = statusResult.responseText.educational_details[i].college_id;
                                        obj.college_name = statusResult.responseText.educational_details[i].college_name;
                                        obj.university_id = statusResult.responseText.educational_details[i].university_id;
                                        obj.university_name = statusResult.responseText.educational_details[i].university_name;
                                        obj.year_of_completion = statusResult.responseText.educational_details[i].year_of_completion;
                                        obj.cgpa = statusResult.responseText.educational_details[i].cgpa;
                                        obj.percentage = statusResult.responseText.educational_details[i].percentage;
                                        obj.backlog = statusResult.responseText.educational_details[i].backlog;
                                        obj.zip_code = statusResult.responseText.educational_details[i].zip_code;


                                        obj.DisplayCourseTypeName = statusResult.responseText.educational_details[i].course_type_name;
                                        if (string.IsNullOrEmpty(statusResult.responseText.educational_details[i].board_name))
                                        {
                                            obj.DisplayBoardNameOrUniversityName = statusResult.responseText.educational_details[i].university_name;
                                        }
                                        else
                                        {
                                            obj.DisplayBoardNameOrUniversityName = statusResult.responseText.educational_details[i].board_name;
                                        }

                                        if (string.IsNullOrEmpty(statusResult.responseText.educational_details[i].school_name))
                                        {
                                            obj.DisplaySchoolNameOrCollegeName = statusResult.responseText.educational_details[i].college_name.Replace("\r\n", string.Empty); ;
                                        }
                                        else
                                        {
                                            obj.DisplaySchoolNameOrCollegeName = statusResult.responseText.educational_details[i].school_name.Replace("\r\n", string.Empty); ;

                                        }



                                        if (string.IsNullOrEmpty(statusResult.responseText.educational_details[i].cgpa) || statusResult.responseText.educational_details[i].cgpa == "0" || statusResult.responseText.educational_details[i].cgpa == "0.0" || statusResult.responseText.educational_details[i].cgpa == "0.00")
                                        {
                                            obj.DisplayCGPAOrPercentage = statusResult.responseText.educational_details[i].percentage + " % - ";
                                        }
                                        else
                                        {
                                            obj.DisplayCGPAOrPercentage = statusResult.responseText.educational_details[i].cgpa + " CGPA - ";
                                        }

                                        obj.DisplayYearOfPassing = statusResult.responseText.educational_details[i].year_of_completion;
                                        ItemSource.Add(obj);

                                    }
                                }

                                UserDialogs.Instance.HideLoading();
                            }
                        }else
                        {
                            UserDialogs.Instance.HideLoading();
                        }

                    }
                }
                catch (Exception ex)
                {
                    //await UserDialogs.Instance.AlertAsync(ex.Message);
                    UserDialogs.Instance.HideLoading();
                    System.Diagnostics.Debug.WriteLine(ex.Message);
                    SendErrorMessageToServer(ex, "CandidateEducationViewModel.BindEducationalDetailsToView");
                }
            });
        }
        #region Private Properties
        private ObservableCollection<Educational_Details> _ItemSource;
        public ObservableCollection<Educational_Details> ItemSource
        {
            get { return _ItemSource; }
            set { _ItemSource = value; OnPropertyChanged(); }
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
