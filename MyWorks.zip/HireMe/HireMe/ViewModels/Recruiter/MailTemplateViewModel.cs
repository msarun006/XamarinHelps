﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using HireMe.Helpers;
using HireMe.Models.Recruiter;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.Recruiter
{
   public class MailTemplateViewModel : BaseViewModel
    {
        private HttpCommonService _commonservice { get; set; }
        
        public bool isClicked = true;
        public ICommand OnSendMailTapped { get; set; }

        INavigation navigation;
        private MailtoSelectedCandidatesRequestData objRequestData;
        private string mailcontent;

        public MailTemplateViewModel(INavigation navigation, MailtoSelectedCandidatesRequestData objRequestData, string mailcontent)
        {
            _commonservice = new HttpCommonService();
            this.navigation = navigation;
            this.objRequestData = objRequestData;
            this.mailcontent = mailcontent;
            MailContent = mailcontent;
            OnSendMailTapped = new RelayCommand<string>(OnClick);
        }

        private async void OnClick(string sender)
        {
            switch (sender)
            {
                case "sendmail":
                    #region OpenCompany
                    if (isClicked)
                    {
                        isClicked = false;
                        try
                        {
                            UserDialogs.Instance.ShowLoading();
                            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                            if (isNetworkAvailable)
                            {

                                var result = await _commonservice.PostAsync<MailSelectedCandidatesResponseData, MailtoSelectedCandidatesRequestData>(APIData.API_BASE_URL + APIMethods.Mailtoselectedcandidates, objRequestData);
                                if (result != null)
                                {
                                    if (result.code == "200")
                                    {
                                        UserDialogs.Instance.HideLoading();
                                        await UserDialogs.Instance.AlertAsync(result.message);
                                        await navigation.PopToRootAsync();
                                    }
                                    else
                                    {
                                        UserDialogs.Instance.HideLoading();
                                        await UserDialogs.Instance.AlertAsync(result.message);
                                    }
                                }
                                else
                                {
                                    UserDialogs.Instance.HideLoading();
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                                }
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                            }
                        }
                        catch (Exception ex)
                        {
                            UserDialogs.Instance.HideLoading();
                            System.Diagnostics.Debug.WriteLine(ex.Message);
                            SendErrorMessageToServer(ex, "MailTemplateViewModel.OnClick");
                        }


                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    #endregion
                    break;
            }
        }


        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        private string _MailContent;

        public string MailContent
        {
            get { return _MailContent; }
            set { _MailContent = value; OnPropertyChanged(); }
        }
    }
}
