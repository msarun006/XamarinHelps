﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using HireMe.Helpers;
using HireMe.Models.Recruiter;
using HireMe.UI;
using HireMe.Views.Recruiter;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.Recruiter
{
    public class CandidateDetailsViewModel : BaseViewModel
    {
        RecruitersearchBO _objSearchDetails;
        ObservableCollection<RecruitersearchBO> _candidateslist;
        private int SearchID;
        private string SearchName;
        public bool isClicked = true;
        private string _fromSelectedCandidatePage;
        INavigation _navigationservice;
        private HttpCommonService _commonservice { get; set; }
        public ICommand CadidateDetailsCommand { get; set; }

      
        public CandidateDetailsViewModel(INavigation nav, RecruitersearchBO objSearchDetails, ObservableCollection<RecruitersearchBO> candidateslist, string selectedPage)
        {
           
               _objSearchDetails = objSearchDetails;
            SearchID = objSearchDetails.searchId;
            _fromSelectedCandidatePage = selectedPage;
            _candidateslist = candidateslist;
            ToolbarIconSelect = string.Empty;
            ToolbarIconReject = string.Empty;
            _commonservice = new HttpCommonService();
            _navigationservice = nav;
            CadidateDetailsCommand = new RelayCommand<string>(DoOperation);
            if (_objSearchDetails.selected != null && _objSearchDetails.IsHiredLabelVisiblePropery)
            {
                IslblHired = true;
                IsbtnHireMe = false;
            }
            else
            {
                IslblHired = false;
                IsbtnHireMe = true;

            }
            loadDefault(objSearchDetails);
        }
        public CandidateDetailsViewModel(INavigation nav, RecruitersearchBO objSearchDetails, ObservableCollection<RecruitersearchBO> candidateslist, int searchID, string searchName)
        {
            
            _objSearchDetails = objSearchDetails;
            SearchID = searchID;
            SearchName = searchName;
            _candidateslist = candidateslist;
            _navigationservice = nav;
            _commonservice = new HttpCommonService();
            if (objSearchDetails.IsBtnDisablePropery)
            {
                ToolbarIconSelect = string.Empty;
                ToolbarIconReject = string.Empty;
            }
            IslblHired = false;
            IsbtnHireMe = false;
            CadidateDetailsCommand = new RelayCommand<string>(DoOperation);
            loadDefault(objSearchDetails);

        }
        public CandidateDetailsViewModel(INavigation nav, RecruitersearchBO objSearchDetails)
        {
           
            _objSearchDetails = objSearchDetails;
            _navigationservice = nav;
            IslblHired = false;
            IsbtnHireMe = false;
            ToolbarIconSelect = string.Empty;
            ToolbarIconReject = string.Empty;
            _commonservice = new HttpCommonService();
            CadidateDetailsCommand = new RelayCommand<string>(DoOperation);
            loadDefault(objSearchDetails);
        }






        //#region ProfileViewCountIncreseAPICall
        //private async void ProfileViewCountIncreseAPICall(RecruitersearchBO objSearchDetails)
        //{
        //    try
        //    {
        //        var request = new ProfileViewerRequestData();
        //        request.HiremeeID = AppSessionData.ActiveToken.HireMeID;
        //        request.Token = AppSessionData.ActiveToken.Token;
        //        request.candidate_hiremee_id = objSearchDetails.candidateID;
        //        if (objSearchDetails.searchId == 0)
        //        {
        //            request.search_id = SearchID.ToString();
        //        }
        //        else
        //        {
        //            request.search_id = objSearchDetails.searchId.ToString();
        //        }

        //        bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
        //        if (isNetworkAvailable)
        //        {
        //            var result = await _commonservice.PostAsync<ProfileViewerResponseData, ProfileViewerRequestData>(APIData.API_BASE_URL + APIMethods.RecruiterProfileviewer, request);
        //            if (result !=null)
        //            {

        //                if (result.Code == "203")
        //                {
        //                    await UserDialogs.Instance.AlertAsync(result.Message);
        //                    await _navigationservice.PopAsync();
        //                }
        //            }





        //        }
        //        else
        //        {
        //            await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Debug.WriteLine(ex.Message);
        //        SendErrorMessageToServer(ex, "CandidateDetailsViewModel.ProfileViewCountIncreseAPICall");
        //    }
        //}
        //#endregion

        #region Private Methods
        private bool _islblHired = false;
        public bool IslblHired
        {
            get { return _islblHired; }
            set { _islblHired = value; OnPropertyChanged(); }
        }

        private bool _isbtnHireMe;
        public bool IsbtnHireMe
        {
            get { return _isbtnHireMe; }
            set { _isbtnHireMe = value; OnPropertyChanged(); }
        }

        private string _profilepic;
        public string profilepic
        {
            get { return _profilepic; }
            set { _profilepic = value; OnPropertyChanged(); }
        }

        private string _toolbariconselect = (string)Application.Current.Resources["SelectIcon"];
        public string ToolbarIconSelect
        {
            get { return _toolbariconselect; }
            set { _toolbariconselect = value; OnPropertyChanged(); }
        }
        private string _toolbariconreject = (string)Application.Current.Resources["RejectIcon"];
        public string ToolbarIconReject
        {
            get { return _toolbariconreject; }
            set { _toolbariconreject = value; OnPropertyChanged(); }
        }

        #region Text Properties
        private string _lblusername;
        public string LblUserName
        {
            get { return _lblusername; }
            set { _lblusername = value; OnPropertyChanged(); }
        }

        private string _lblhiremeid;
        public string LblHireMeID
        {
            get { return _lblhiremeid; }
            set { _lblhiremeid = value; OnPropertyChanged(); }
        }
        private string _lbluniversity;
        public string LblUniverSity
        {
            get { return _lbluniversity; }
            set { _lbluniversity = value; OnPropertyChanged(); }
        }
        private string _lblCollege;
        public string LblCollege
        {
            get { return _lblCollege; }
            set { _lblCollege = value; OnPropertyChanged(); }
        }

        

              private string _disablity;
        public string Disablity
        {
            get { return _disablity; }
            set { _disablity = value; OnPropertyChanged(); }
        }

        private string _lblcourse;
        public string LblCourse
        {
            get { return _lblcourse; }
            set { _lblcourse = value; OnPropertyChanged(); }
        }
        private string _lblCourseType;
        public string LblCourseType
        {
            get { return _lblCourseType; }
            set { _lblCourseType = value; OnPropertyChanged(); }
        }
        private string _lblSpecialization;
        public string LblSpecialization
        {
            get { return _lblSpecialization; }
            set { _lblSpecialization = value; OnPropertyChanged(); }
        }
        private string _lblSkills;
        public string LblSkills
        {
            get { return _lblSkills; }
            set { _lblSkills = value; OnPropertyChanged(); }
        }
        private string _lblyearofcompletion;
        public string Lblyearofcompletion
        {
            get { return _lblyearofcompletion; }
            set { _lblyearofcompletion = value; OnPropertyChanged(); }
        }
        #endregion

        #region Label Assessment score Properties
        private string _preferredJobLocation;

        public string PreferredJobLocation
        {
            get { return _preferredJobLocation; }
            set { _preferredJobLocation = value; OnPropertyChanged(); }
        }

        private string _lblVerbal;
        public string LblVerbal
        {
            get { return _lblVerbal; }
            set { _lblVerbal = value; OnPropertyChanged(); }
        }
        private string _lblLogical;
        public string LblLogical
        {
            get { return _lblLogical; }
            set { _lblLogical = value; OnPropertyChanged(); }
        }
        private string _lblTechnical;
        public string lblTechnical
        {
            get { return _lblTechnical; }
            set { _lblTechnical = value; OnPropertyChanged(); }
        }
        private string _lblCommunication;
        public string lblCommunication
        {
            get { return _lblCommunication; }
            set { _lblCommunication = value; OnPropertyChanged(); }
        }
        private string _lblQuantitative;
        public string lblQuantitative
        {
            get { return _lblQuantitative; }
            set { _lblQuantitative = value; OnPropertyChanged(); }
        }
        private string _lblPersonalCompetencies;
        public string lblPersonalCompetencies
        {
            get { return _lblPersonalCompetencies; }
            set { _lblPersonalCompetencies = value; OnPropertyChanged(); }
        }
        private string _lblEmotionalCompetencies;
        public string lblEmotionalCompetencies
        {
            get { return _lblEmotionalCompetencies; }
            set { _lblEmotionalCompetencies = value; OnPropertyChanged(); }
        }
        private string _lblMotivationalCompetencies;
        public string lblMotivationalCompetencies
        {
            get { return _lblMotivationalCompetencies; }
            set { _lblMotivationalCompetencies = value; OnPropertyChanged(); }
        }
        private string _lblIntellectualOrientation;
        public string lblIntellectualOrientation
        {
            get { return _lblIntellectualOrientation; }
            set { _lblIntellectualOrientation = value; OnPropertyChanged(); }
        }
        private string _lblInterPersonalCompetencies;
        public string lblInterPersonalCompetencies
        {
            get { return _lblInterPersonalCompetencies; }
            set { _lblInterPersonalCompetencies = value; OnPropertyChanged(); }
        }
        private string _lblAptitude;
        public string lblAptitude
        {
            get { return _lblAptitude; }
            set { _lblAptitude = value; OnPropertyChanged(); }
        }
        private string _lblStaticText;
        public string lblStaticText
        {
            get { return _lblStaticText; }
            set { _lblStaticText = value; OnPropertyChanged(); }
        }
        private string _lblPercentage;
        public string lblPercentage
        {
            get { return _lblPercentage; }
            set { _lblPercentage = value; OnPropertyChanged(); }
        }
        #endregion

        #region Arrow Tapped
        private bool _isfirstgrid = true;
        public bool IsFirstGrid
        {
            get { return _isfirstgrid; }
            set { _isfirstgrid = value; OnPropertyChanged(); }
        }
        private bool _issecondfgrid = false;
        public bool IsSecondGrid
        {
            get { return _issecondfgrid; }
            set { _issecondfgrid = value; OnPropertyChanged(); }
        }

        private bool _isleftarrowenable = false;
        public bool IsLeftArrowEnable
        {
            get { return _isleftarrowenable; }
            set { _isleftarrowenable = value; OnPropertyChanged(); }
        }
        private bool _isrightarrowenable = false;
        public bool IsRightArrowEnable
        {
            get { return _isrightarrowenable; }
            set { _isrightarrowenable = value; OnPropertyChanged(); }
        }

        private Color _leftarrowcolor = Color.Gray;
        public Color LeftArrowColor
        {
            get { return _leftarrowcolor; }
            set { _leftarrowcolor = value; OnPropertyChanged(); }
        }
        private Color _rightarrowcolor = Color.Black;
        public Color RightArrowColor
        {
            get { return _rightarrowcolor; }
            set { _rightarrowcolor = value; OnPropertyChanged(); }
        }
        #endregion

        #endregion

        #region loadDefault
        private void loadDefault(RecruitersearchBO objSearchDetails)
        {
            try
            {
                IsVisibleEmptyCertifications = false;
                IsVisibleCertifications = false;
                CertificationItemSource = new ObservableCollection<CertificationsData>();
                UserDialogs.Instance.ShowLoading();
                //ProfileViewCountIncreseAPICall(objSearchDetails);
                //BindProfilePic(objSearchDetails.ProfilePicture);
                profilepic = objSearchDetails.ProfilePicture.S3_ID;
                LblUserName = objSearchDetails.profileDetails.FullName;
                if (objSearchDetails.profileDetails.CandidateDisablity == "0")
                {
                    Disablity = "No";
                }
                else if (objSearchDetails.profileDetails.CandidateDisablity == "1")
                {
                    Disablity = "Yes";
                }
                LblHireMeID = objSearchDetails.candidateID;
                LblUniverSity = objSearchDetails.educationalDetails.UniversityName;
                LblCollege = objSearchDetails.educationalDetails.CollegeName.Replace("\r\n", string.Empty);
                LblCourse = objSearchDetails.educationalDetails.CourseName;
                LblCourseType = objSearchDetails.educationalDetails.CourseType;
                LblSpecialization = objSearchDetails.educationalDetails.mSpecializationName;
                if (string.IsNullOrEmpty(objSearchDetails.educationalDetails.Skills)|| string.IsNullOrWhiteSpace(objSearchDetails.educationalDetails.Skills))
                {
                    LblSkills = "N/A";
                }
                else
                {
                    LblSkills = objSearchDetails.educationalDetails.Skills;
                }
                Lblyearofcompletion = objSearchDetails.educationalDetails.YearOfCompletion;
               
                if (objSearchDetails.certifications.Count != 0)
                {
                    
                    foreach (var item in objSearchDetails.certifications)
                    {
                        CertificationItemSource.Add(new CertificationsData() { certification_name = item.certification_name,certification_year=item.certification_year });
                    }
                    if (CertificationItemSource != null)
                    {
                        IsVisibleCertifications = true;
                        IsVisibleEmptyCertifications = false;
                    }
                    else
                    {
                        IsVisibleEmptyCertifications = true;
                        IsVisibleCertifications = false;
                    }
                }
                else
                {
                   
                    IsVisibleEmptyCertifications = true;
                    IsVisibleCertifications = false;
                }


                if (objSearchDetails.prefer_job_location != null)
                {
                    string LocationName = string.Empty;
                    int PreferredJobLocationCount = objSearchDetails.prefer_job_location.Count;
                    int counter = 0;
                    foreach (var item in objSearchDetails.prefer_job_location)
                    {
                        counter++;
                        LocationName += item.prefer_job_location;
                        if (counter < PreferredJobLocationCount)
                        {
                            LocationName += ", ";
                        }
                    }
                    if (counter != 0)
                    {
                        PreferredJobLocation = LocationName;
                    }
                    else
                    {
                        PreferredJobLocation ="N/A";
                    }
                       
                }
                if (objSearchDetails.assessment != null)
                {
                    LblVerbal = objSearchDetails.assessment.verbalaptitude.ToString();
                    LblLogical = objSearchDetails.assessment.logicalreasoning.ToString();
                    lblTechnical = objSearchDetails.assessment.technicalcoredomain.ToString();
                    lblCommunication = objSearchDetails.assessment.communication.ToString();
                    lblQuantitative = objSearchDetails.assessment.quantitativeaptitude.ToString();
                    lblPersonalCompetencies = objSearchDetails.assessment.personalcompetencies.ToString();
                    lblEmotionalCompetencies = objSearchDetails.assessment.emotionalcompetencies.ToString();
                    lblMotivationalCompetencies = objSearchDetails.assessment.motivationalcompetencies.ToString();
                    lblIntellectualOrientation = objSearchDetails.assessment.intellectualorientation.ToString();
                    lblInterPersonalCompetencies = objSearchDetails.assessment.interpersonalcompetencies.ToString();
                    lblAptitude = objSearchDetails.assessment.technicalcomputerfundamental.ToString();
                }
                if (objSearchDetails.educationalDetails.CGPA == "" || objSearchDetails.educationalDetails.CGPA == "0.00")
                {
                    lblStaticText = "Percentage";
                    lblPercentage = objSearchDetails.educationalDetails.Percentage;
                }
                else
                {
                    lblStaticText = "CGPA";
                    lblPercentage = objSearchDetails.educationalDetails.CGPA;
                }
                UserDialogs.Instance.HideLoading();
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "CandidateDetailsViewModel.loadDefault");
            }
        }
        #endregion

        //#region BindProfilePic
        //private void BindProfilePic(ProfilePicture profileImage)
        //{
        //    Debug.WriteLine("@ CandidateDetailsPage.BindProfilePic");

        //    var profilepicsource = (string)Application.Current.Resources["IconUser"];
        //    if (profileImage != null)
        //    {
        //        profilepic = profileImage.S3_ID;
        //    }
        //    else
        //    {
        //        profilepic = profilepicsource;
        //    }
        //}
        //#endregion

        private async void DoOperation(string sender)
        {
            switch (sender)
            {
                case "OnbtnComment":
                    if (isClicked)
                    {
                        isClicked = false;
                        await _navigationservice.PushAsync(new ViewPreviousComment(_objSearchDetails.candidateID));
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                case "OnbtnVideoProfile":
                    if (CrossConnectivity.Current.IsConnected)
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            var videoplayer = new RecruiterPlayVideo(_objSearchDetails.profileDetails.FullName, _objSearchDetails.AboutMeVideoDetails, _objSearchDetails.SkillVideoDetails, _objSearchDetails.AmbitionVideoDetails, _objSearchDetails.candidateID, SearchID.ToString());
                            await _navigationservice.PushAsync(videoplayer);
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(500);
                            isClicked = true;
                        });
                    }
                    else
                    {
                        UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                    }
                    break;


                case "ShowCertificate":
                    if (CrossConnectivity.Current.IsConnected)
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            if (CertificationItemSource != null)
                            {
                                await _navigationservice.PushAsync(new CandidateCertificationPage(CertificationItemSource));
                            }
                            else
                            {
                              UserDialogs.Instance.Alert(MessageStringConstants.NoRecordsFound);
                            }
                          
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(500);
                            isClicked = true;
                        });
                    }
                    else
                    {
                        UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                    }
                    break;
                    



                case "OnHireMeClicked":
                    OnHireMeeClicked();
                    break;

                case "moreTapped":
                    if (CrossConnectivity.Current.IsConnected)
                    {
                        if (isClicked)
                        {
                            isClicked = false;

                            await _navigationservice.PushAsync(new CandidateEducationDetailsViewPage(_objSearchDetails.candidateID));
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(500);
                            isClicked = true;
                        });
                    }
                    else
                    {
                        UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                    }
                    break;
                #region OnSelect
                case "OnSelect":
                    if (isClicked)
                    {
                        isClicked = false;
                        var result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.ShortListConfirmationAlert,"", "Yes", "No");
                        if(result == true)
                        {
                            SelectedCandidateListInsertRequestData data = new SelectedCandidateListInsertRequestData();
                            data.Token = AppSessionData.ActiveToken.Token;
                            data.HiremeeID = AppSessionData.ActiveToken.HireMeID;
                            data.CandidateHiremeeID = _objSearchDetails.candidateID;
                            data.SearchId = SearchID.ToString();
                            data.SearchName = SearchName;
                            data.IsSelected = "y";
                            UserDialogs.Instance.ShowLoading();
                            var response = await _commonservice.PostAsync<SelectedCandidateListInsertResponseData, SelectedCandidateListInsertRequestData>(APIData.API_BASE_URL + APIMethods.SelectCandidate, data);
                            if (response != null)
                            {
                                UserDialogs.Instance.HideLoading();
                                if (response.code == "200")
                                {
                                  
                                    if (!RemoveItemFromList(_objSearchDetails.candidateID))
                                    {
                                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                                    }
                                    else
                                    {
                                        await _navigationservice.PopAsync();
                                    }
                                }
                                else
                                {
                                    UserDialogs.Instance.HideLoading();
                                    await UserDialogs.Instance.AlertAsync(response.message);
                                }
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                            }
                        }
                      
                       
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                #endregion

                #region OnReject
                case "OnReject":
                    if (isClicked)
                    {
                        isClicked = false;
                        var result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.RejectConfirmationAlert,"", "Yes", "No");
                        if (result == true)
                        {
                            SelectedCandidateListInsertRequestData data = new SelectedCandidateListInsertRequestData();
                            data.Token = AppSessionData.ActiveToken.Token;
                            data.HiremeeID = AppSessionData.ActiveToken.HireMeID;
                            data.CandidateHiremeeID = _objSearchDetails.candidateID;
                            data.SearchId = SearchID.ToString();
                            data.SearchName = SearchName;
                            UserDialogs.Instance.ShowLoading();
                            var response = await _commonservice.PostAsync<SelectedCandidateListInsertResponseData, SelectedCandidateListInsertRequestData>(APIData.API_BASE_URL + APIMethods.RejectCandidate, data);
                            if (response != null)
                            {
                                if (response.code == "200")
                                {
                                    UserDialogs.Instance.HideLoading();
                                if (!RemoveItemFromList(_objSearchDetails.candidateID))
                                {
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                                }
                                else
                                {
                                    await _navigationservice.PopAsync();
                                }
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(response.message);
                            }

                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                        }
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                #endregion

                case "OnLeftArrowTapped":
                    IsFirstGrid = true;
                    IsSecondGrid = false;
                    IsLeftArrowEnable = false;
                    LeftArrowColor = Color.Gray;
                    IsRightArrowEnable = true;
                    RightArrowColor = Color.Black;
                    break;

                case "OnRightArrowTapped":
                    IsFirstGrid = false;
                    IsSecondGrid = true;
                    IsLeftArrowEnable = true;
                    LeftArrowColor = Color.Black;
                    IsRightArrowEnable = false;
                    RightArrowColor = Color.Gray;
                    break;
            }
        }
        #region OnHireMee Clicked
        async void OnHireMeeClicked()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                var requestdata = new HiredCandidateRequestData()
                {
                    HiremeeID = AppSessionData.ActiveToken.HireMeID,
                    Token = AppSessionData.ActiveToken.Token,
                    CandidateID = _objSearchDetails.candidateID,
                    SearchId = SearchID.ToString(),

                };
                var responseobj = await _commonservice.PostAsync<CommentsResponseText, HiredCandidateRequestData>(APIData.API_BASE_URL + APIMethods.CandidateHired, requestdata);
                if (responseobj != null)
                {
                    if (responseobj.code == "200")
                    {
                   
                        IslblHired = true;
                        IsbtnHireMe = false;
                        var obj = _candidateslist.FirstOrDefault(o => o.candidateID == _objSearchDetails.candidateID);
                        UserDialogs.Instance.HideLoading();

                        // _candidateslist..IsHired = 1;
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(responseobj.message);
                    }
                }

                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "CandidateDetailsViewModel.OnHireMeeClicked");

            }
        }
        #endregion

        private ObservableCollection<CertificationsData> _certificationItemSource;
        public ObservableCollection<CertificationsData> CertificationItemSource
        {
            get { return _certificationItemSource; }
            set { _certificationItemSource = value; OnPropertyChanged(); }
        }


        private bool _isVisibleCertifications;

        public bool IsVisibleCertifications
        {
            get { return _isVisibleCertifications; }
            set { _isVisibleCertifications = value; OnPropertyChanged(); }
        }


        private bool _isVisibleEmptyCertifications;

        public bool IsVisibleEmptyCertifications
        {
            get { return _isVisibleEmptyCertifications; }
            set { _isVisibleEmptyCertifications = value; OnPropertyChanged(); }
        }
        

        #region RemoveItemFromList
        private bool RemoveItemFromList(string hiremeeid)
        {
            bool isremoved = false;
            if (_candidateslist != null && _candidateslist.Count > 0)
            {
                var selectedCandidate = _candidateslist.FirstOrDefault(o => o.candidateID == hiremeeid);
                if (selectedCandidate != null)
                {
                    _candidateslist.Remove(selectedCandidate);
                    isremoved = true;
                }
            }
            return isremoved;
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
