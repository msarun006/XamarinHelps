﻿using Acr.UserDialogs;
using HireMe.Models.Recruiter;
using HireMe.UI;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Collections.ObjectModel;
using System.Windows.Input;
using Xamarin.Forms;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using HireMe.Helpers;
using System.Diagnostics;

namespace HireMe.ViewModels.Recruiter
{
    public class SelectedCandidateListViewModel: BaseViewModel
    {
        public bool isClicked = true;
        private HttpCommonService _commonservice { get; set; }
        private SelectedCandidatelistResponse SelectedCandidatelistResponse { get; set; }
        private RecruitersearchBO RecruitersearchBO { get; set; }
        private FilterRequest RequestData { get; set; }


        private ObservableCollection<RecruitersearchBO> _ItemSource;
        public ObservableCollection<RecruitersearchBO> ItemSource
        {
            get { return _ItemSource; }
            set { _ItemSource = value; OnPropertyChanged(); }
        }


        private ObservableCollection<RecruitersearchBO> _TempItemSource;
        public ObservableCollection<RecruitersearchBO> TempItemSource
        {
            get { return _TempItemSource; }
            set { _TempItemSource = value; OnPropertyChanged(); }
        }


        INavigation navigation;
        public string _SelectedSearchID;
        public  SelectedCandidateListViewModel(INavigation _navigation,string SearchID)
        {
            _SelectedSearchID = SearchID;
            navigation = _navigation;
            IsLableViewVisible = false;
            SearchPlaceHolderText = "Search Selected Candidate";
            _commonservice = new HttpCommonService();
            SelectedCandidatelistResponse = new SelectedCandidatelistResponse();
            RecruitersearchBO = new RecruitersearchBO();
            RequestData = new FilterRequest();
            isEnabledSearchBar = true;
            RequestData.HiremeeID = AppSessionData.ActiveToken.HireMeID;
            RequestData.Token = AppSessionData.ActiveToken.Token;
            RequestData.SearchID = _SelectedSearchID;


            //BindSelectedCandidateList();
        }
        #region Searchbar Controls
        private bool _isVisibleSearchbarCancel;
        public bool IsVisibleSearchbarCancelButton
        {
            get { return _isVisibleSearchbarCancel; }
            set { _isVisibleSearchbarCancel = value; OnPropertyChanged(); }
        }

        public string _SearchText;
        public string SearchText
        {
            set
            {
                _SearchText = value;
                SearchText_TextChanged();
                OnPropertyChanged();
            }
            get { return _SearchText; }
        }
        public bool _isEnabledSearchBar;

        public bool isEnabledSearchBar
        {
            set { _isEnabledSearchBar = value; OnPropertyChanged(); }
            get { return _isEnabledSearchBar; }
        }
        public Command OnSearchClearCommand => new Command(() =>
        {
            IsVisibleSearchbarCancelButton = false;
            SearchText = string.Empty;
            SearchPlaceHolderText = "Search Selected Candidate";

        });
        private string _searchPlaceHolder;
        public string SearchPlaceHolderText
        {
            get { return _searchPlaceHolder; }
            set { _searchPlaceHolder = value; OnPropertyChanged(); }
        }


        public async void SearchText_TextChanged()
        {
            var searchtext = SearchText;
            if (string.IsNullOrEmpty(searchtext))
            {
                SearchPlaceHolderText = "Search Selected Candidate";
                IsVisibleSearchbarCancelButton = false;
                BindSelectedCandidateList();
                return;
            }

            if (TempItemSource != null)
            {

                ItemSource = TempItemSource;
                List<RecruitersearchBO> Suggetions = ItemSource.Where(c =>
               c.profileDetails.FullName.ToLower().Contains(searchtext.ToLower())
               || c.educationalDetails.CourseName.ToLower().Contains(searchtext.ToLower())
               || c.educationalDetails.CourseType.ToLower().Contains(searchtext.ToLower())).ToList();
                ItemSource = new ObservableCollection<RecruitersearchBO>(Suggetions);
                IsVisibleSearchbarCancelButton = true;
            }

        }

        #endregion
        public async void BindSelectedCandidateList()
        {
            //await Task.Run(async () =>
            //{
                try
                {
                    UserDialogs.Instance.ShowLoading();
                    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {

                    var result = await _commonservice.PostAsync<SelectedCandidatelistResponse, FilterRequest>(APIData.API_BASE_URL + APIMethods.Selectedcandidatetohire, RequestData);
                    if (result != null)
                    {
                        if (result.code == "200")
                        {
                            UserDialogs.Instance.HideLoading();
                            ItemSource = new ObservableCollection<RecruitersearchBO>(result.ResponseText.Data);
                            TempItemSource = ItemSource;
                            //isEnabledSearchBar = true;
                            if (ItemSource.Count > 0)
                            {
                                IsLableViewVisible = false;
                                IsListViewVisible = true;
                            }
                            else
                            {
                                IsListViewVisible = false;
                                IsLableViewVisible = true;
                            }
                        }
                        else
                        {

                            UserDialogs.Instance.HideLoading();
                            //isEnabledSearchBar = false;
                            await UserDialogs.Instance.AlertAsync(result.message);

                        }
                    }
                    else
                    {
                        // isEnabledSearchBar = false;
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                else
                {
                    // isEnabledSearchBar = false;
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection, "HirMee", "OK");
                }
                }
                catch (Exception ex)
                {
                    UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "SelectedCandidateListViewModel.BindSelectedCandidateList");
                //await UserDialogs.Instance.AlertAsync(ex.Message, "HirMee", "OK");
            }

            //});
        }

        private bool _IsListViewVisible;
        public bool IsListViewVisible
        {
            get { return _IsListViewVisible; }
            set { _IsListViewVisible = value; OnPropertyChanged(); }
        }

        private bool _IsLableViewVisible;
        public bool IsLableViewVisible
        {
            get { return _IsLableViewVisible; }
            set { _IsLableViewVisible = value; OnPropertyChanged(); }
        }


        private RecruitersearchBO _SelectedItem;
        public RecruitersearchBO SelectedItem
        {
            get { return _SelectedItem; }
            set { _SelectedItem = value; OnPropertyChanged(); }
        }
     
        public ICommand SelectedCommand => new Command(async () =>
        {
            if (isClicked)
            {
                isClicked = false;
                await navigation.PushAsync(new CandidateDetailsPage(SelectedItem, _ItemSource, "HireMee"));///
              
               
            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });
        });

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
