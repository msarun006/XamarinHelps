﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using HireMe.Helpers;
using HireMe.Models.Recruiter;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.Recruiter
{
    public class RecruiterProfileViewModel : BaseViewModel
    {
        private HttpCommonService _commonservice { get; set; }
        public RecruiterProfileDetailsRetrivalRequestData RecruiterProfileDetailsRetrivalRequestData { get; set; }
        public RecruiterProfileDetailsRetrivalResponseData RecruiterProfileDetailsRetrivalResponseData { get; set; }
        public UpdateRecruiterProfileRequestData UpdateRecruiterProfileRequestData { get; set; }
        public UpdateRecruiterProfileResponseData UpdateRecruiterProfileResponseData { get; set; }
        public bool isClicked = true;
        public ICommand OnRecruiterProfile { get; set; }

        INavigation navigation;
        public RecruiterProfileViewModel(INavigation _navigation)
        {

            navigation = _navigation;
       
            _commonservice = new HttpCommonService();
            RecruiterProfileDetailsRetrivalRequestData = new RecruiterProfileDetailsRetrivalRequestData();
            RecruiterProfileDetailsRetrivalResponseData = new RecruiterProfileDetailsRetrivalResponseData();


            RecruiterProfileDetailsRetrivalRequestData.HiremeeID = AppSessionData.ActiveToken.HireMeID;
            RecruiterProfileDetailsRetrivalRequestData.Token = AppSessionData.ActiveToken.Token;
            BindRecruitersProfileDetails();



            UpdateRecruiterProfileResponseData = new UpdateRecruiterProfileResponseData();

            OnRecruiterProfile = new RelayCommand<string>(OnClick);

            MessagingCenter.Subscribe<DynamicListPageViewModel, CommonListItemSource>(this, "RecruiterProfile", (sender, arg) =>
            {
                SetFieldValue(arg.fieldType, arg);
            });

            if (AppPreferences.ProfilePicture != string.Empty)
            {
                ProfileImage = AppPreferences.ProfilePicture;
            }
           
        }

        private string _profileImage;
        public string ProfileImage
        {
            get { return _profileImage; }
            set
            {
                _profileImage = value;
                OnPropertyChanged();

            }
        }

        public void SetFieldValue(string fieldtype, object fieldvalue)
        {
            if (fieldtype == Constants.FieldType.State)
            {
               
                SelectedCity = "Select District";
                RecruiterProfileDetails.State.Title = ((CommonListItemSource)fieldvalue).Title;
                RecruiterProfileDetails.State = new State { ID = ((CommonListItemSource)fieldvalue).ID, Title = ((CommonListItemSource)fieldvalue).Title };
                SelectedState = RecruiterProfileDetails.State.Title;
            }
            else if (fieldtype == Constants.FieldType.City)
            {
                RecruiterProfileDetails.City.Title = ((CommonListItemSource)fieldvalue).Title;
                RecruiterProfileDetails.City = new District { ID = ((CommonListItemSource)fieldvalue).ID, Title = ((CommonListItemSource)fieldvalue).Title };
                SelectedCity = RecruiterProfileDetails.City.Title;
            }
        }
        private async void OnClick(string sender)
        {
            switch (sender)
            {
                case "OnStateItemTapped":
                    #region OpenCompany
                    if (isClicked)
                    {
                        isClicked = false;
                        NavigateToDynamicListPage(Constants.FieldType.State, "");
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    #endregion
                    break;

                case "OnCityItemTapped":
                    #region OpenCompany
                    if (isClicked)
                    {
                        isClicked = false;
                        if (RecruiterProfileDetails != null && RecruiterProfileDetails.State != null && RecruiterProfileDetails.State.ID != null)
                        {
                            NavigateToDynamicListPage(Constants.FieldType.City, RecruiterProfileDetails.State.ID);
                         }
                        else
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectHomeState);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    #endregion
                    break;


                case "OnSaveRecruiterPersonalDetails":
                    #region OpenCompany
                    if (isClicked)
                    {
                        isClicked = false;
                        if (IsValidatePersonalDetails())
                        {
                            try
                            {
                                UserDialogs.Instance.ShowLoading();
                                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                                if (isNetworkAvailable)
                                {
                                    UpdateRecruiterProfileRequestData = new UpdateRecruiterProfileRequestData();

                                    UpdateRecruiterProfileRequestData.HiremeeID = AppSessionData.ActiveToken.HireMeID;
                                    UpdateRecruiterProfileRequestData.Token = AppSessionData.ActiveToken.Token;
                                    UpdateRecruiterProfileRequestData.FullName = RecruiterProfileDetails.FullName;
                                    UpdateRecruiterProfileRequestData.EmailAddress = RecruiterProfileDetails.EmailAddress;
                                    UpdateRecruiterProfileRequestData.CompanyName = RecruiterProfileDetails.CompanyName;
                                    UpdateRecruiterProfileRequestData.MobileNumber = RecruiterProfileDetails.MobileNumber;
                                    UpdateRecruiterProfileRequestData.StateID = RecruiterProfileDetails.State.ID;
                                    UpdateRecruiterProfileRequestData.CityID = RecruiterProfileDetails.City.ID;

                                    var result = await _commonservice.PostAsync<UpdateRecruiterProfileResponseData, UpdateRecruiterProfileRequestData>(APIData.API_BASE_URL + APIMethods.Recruiterprofiledetails, UpdateRecruiterProfileRequestData);

                                    if (result != null && result.code == "200")
                                    {
                                        UserDialogs.Instance.HideLoading();
                                        await UserDialogs.Instance.AlertAsync(result.message);
                                    }
                                    else
                                    {
                                        UserDialogs.Instance.HideLoading();
                                        await UserDialogs.Instance.AlertAsync(result.message);
                                    }
                                }
                                else
                                {
                                    UserDialogs.Instance.HideLoading();
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                                }
                            }
                            catch (Exception ex)
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(ex.Message);
                                SendErrorMessageToServer(ex, "RecruiterProfileViewModel.OnClick");
                            }


                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    #endregion
                    break;
            }
        }


        #region IsValidatePersonalDetails
        bool IsValidatePersonalDetails()
        {
            if (RecruiterProfileDetails != null)
            {
                if (SelectedState == "Select State" || RecruiterProfileDetails.State == null)
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectHomeState);

                    });
                  
                    return false;
                }
                if (SelectedCity == "Select District" || RecruiterProfileDetails.City == null)
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectHomeDistrict);

                    });
               
                    return false;
                }
                return true;
            }
            else
            {
                return false;
            }
        }

        #endregion


        public async void NavigateToDynamicListPage(string _fieldType, string _fieldValue)
        {
            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
            if (isNetworkAvailable)
            {
                //_SeekerPersonalPage = new SeekerPersonalAndEducationPage();

                await navigation.PushAsync(new DynamicListPage("RecruiterProfile", _fieldType, _fieldValue));
            }
            else
            {
                UserDialogs.Instance.Toast("Check Internet Connection");
            }
        }

        private async void BindRecruitersProfileDetails()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {

                    var result = await _commonservice.PostAsync<RecruiterProfileDetailsRetrivalResponseData, RecruiterProfileDetailsRetrivalRequestData>(APIData.API_BASE_URL + APIMethods.Recruiterprofiledetailsretrival, RecruiterProfileDetailsRetrivalRequestData);
                    if (result != null)
                    {
                        if (result.code == "200")
                        {
                            UserDialogs.Instance.HideLoading();
                            RecruiterProfileDetails = result.Response;
                            HiremeeID = AppSessionData.ActiveToken.HireMeID;
                            if (string.IsNullOrEmpty(RecruiterProfileDetails.State.Title))
                            {
                                SelectedState = "Select State";
                            }
                            else
                            {
                                RecruiterProfileDetails.State = RecruiterProfileDetails.State;
                                SelectedState = RecruiterProfileDetails.State.Title;
                            }
                            if (string.IsNullOrEmpty(RecruiterProfileDetails.City.Title))
                            {
                                SelectedCity = "Select District";
                            }
                            else
                            {
                                RecruiterProfileDetails.City = RecruiterProfileDetails.City;
                                SelectedCity = RecruiterProfileDetails.City.Title;
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(result.message);
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                SendErrorMessageToServer(ex, "RecruiterProfileViewModel.BindRecruitersProfileDetails");
            }
        }


        #region RecruiterProfileDetails Properties
        private RecruiterProfileDetails recruiterProfileDetails;
        public RecruiterProfileDetails RecruiterProfileDetails
        {
            get { return recruiterProfileDetails; }
            set { recruiterProfileDetails = value; OnPropertyChanged(); }
        }
        #endregion

        private string _hiremeeID;
        public string HiremeeID
        {
            get { return _hiremeeID; }
            set
            {
                _hiremeeID = value;
                OnPropertyChanged();
            }
        }


        private string _selectedState;
        public string SelectedState
        {
            get { return _selectedState; }
            set
            {
                _selectedState = value;
                OnPropertyChanged();
            }
        }

        private string _selectedCity;
        public string SelectedCity
        {
            get { return _selectedCity; }
            set
            {
                _selectedCity = value;
                OnPropertyChanged();
            }
        }

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
