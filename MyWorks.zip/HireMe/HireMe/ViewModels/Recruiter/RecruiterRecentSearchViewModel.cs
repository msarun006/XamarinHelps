﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.Models;
using HireMe.Models.Recruiter;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.Recruiter
{
    public class RecruiterRecentSearchViewModel : BaseViewModel
    {
        public bool isClicked = true;
        private HttpCommonService _commonservice { get; set; }
        public BaseRequestDTO BaseRequestDTO { get; set; }
       


        private ObservableCollection<SearchHistoryData> _ItemSource;
        public ObservableCollection<SearchHistoryData> ItemSource
        {
            get { return _ItemSource; }
            set { _ItemSource = value; OnPropertyChanged(); }
        }
        INavigation navigation;
        public RecruiterRecentSearchViewModel(INavigation _navigation)
        {

            navigation = _navigation;

            IsLableViewVisible = false;

            _commonservice = new HttpCommonService();
            BaseRequestDTO = new BaseRequestDTO();
           


            BaseRequestDTO.HiremeeID = AppSessionData.ActiveToken.HireMeID;
            BaseRequestDTO.Token = AppSessionData.ActiveToken.Token;
            BindSearchHistoryList();
        }

        private async void BindSearchHistoryList()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {

                    var result = await _commonservice.PostAsync<SearchHistoryResponseData, BaseRequestDTO>(APIData.API_BASE_URL + APIMethods.Recruitersearchhistory, BaseRequestDTO);

                    if (result != null && result.code == "200")
                    {
                        UserDialogs.Instance.HideLoading();
                        ItemSource = new ObservableCollection<SearchHistoryData>(result.responseText.Data);
                        if (ItemSource.Count > 0)
                        {
                            IsLableViewVisible = false;
                            IsListViewVisible = true;
                        }
                        else
                        {
                            IsListViewVisible = false;
                            IsLableViewVisible = true;
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(result.message);
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                await UserDialogs.Instance.AlertAsync(ex.Message);
                SendErrorMessageToServer(ex, "RecruiterRecentSearchViewModel.BindSearchHistoryList");
            }
        }

        private bool _IsListViewVisible;
        public bool IsListViewVisible
        {
            get { return _IsListViewVisible; }
            set { _IsListViewVisible = value; OnPropertyChanged(); }
        }

        private bool _IsLableViewVisible;
        public bool IsLableViewVisible
        {
            get { return _IsLableViewVisible; }
            set { _IsLableViewVisible = value; OnPropertyChanged(); }
        }

        private SearchHistoryData _SelectedItem;
        public SearchHistoryData SelectedItem
        {
            get { return _SelectedItem; }
            set { _SelectedItem = value; OnPropertyChanged(); }
        }


        public ICommand SelectedCommand => new Command(async () =>
        {
            if (isClicked)
            {
                isClicked = false;
                var data = SelectedItem as SearchHistoryData;
                await navigation.PushAsync(new RecruiterSearchResult(data.SearchID.ToString()));
            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });
        });

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

    }
}
