﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using HireMe.Models;
using HireMe.Models.Recruiter;
using HireMe.Services;
using MvvmHelpers;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.Recruiter
{
    public class RecruiterPlayVideoViewModel : BaseViewModel
    {
        public ICommand OnRecruiterPlayCommand { get; set; }
        bool isVideoviewed = false;
        public bool isClicked = true;
        bool IsCandidateAfterSelected;
        string strAboutmeURL, strSkillURL, strInterestURL, CandidateID, SearchID, strAboutMeThumbnailURL, strSkillThumbnailURL;
        INavigation navigationService;

        private HttpCommonService _commonservice { get; set; }
        private ProfileViewerResponseData ProfileViewerResponseData { get; set; }
        private ProfileViewerRequestData ProfileViewerRequestData { get; set; }

        #region Binding Properties
        private ImageSource _imageYourself;
        public ImageSource ImageYourself
        {
            get
            { return this._imageYourself; }
            set
            {
                if (Equals(value, this._imageYourself))
                { return; }
                this._imageYourself = value;
                OnPropertyChanged();
            }
        }
        private ImageSource _imageAboutmyskills;
        public ImageSource ImageAboutMyskills
        {
            get
            { return this._imageAboutmyskills; }
            set
            {
                if (Equals(value, this._imageAboutmyskills))
                { return; }
                this._imageAboutmyskills = value;
                OnPropertyChanged();
            }
        }
        private ImageSource _imageAreaofinterest;
        public ImageSource ImageAreaofinterest
        {
            get
            { return this._imageAreaofinterest; }
            set
            {
                if (Equals(value, this._imageAreaofinterest))
                { return; }
                this._imageAreaofinterest = value;
                OnPropertyChanged();
            }
        }
        private string _pgtitle;
        public string CurrentPageTitle
        {
            get { return _pgtitle; }
            set { _pgtitle = value; OnPropertyChanged(); }
        }
        #endregion

        #region Constructor 1
        public RecruiterPlayVideoViewModel(string title, AboutMeVideo aboutme, SkillVideo skill, AmbitionVideo ambition, string strCandidateID, string strSearchID, INavigation objNav)
        {
            OnRecruiterPlayCommand = new RelayCommand<string>(OnPlayCommand);
            navigationService = objNav;
            IsCandidateAfterSelected = false;
            UserDialogs.Instance.ShowLoading();
            if (!string.IsNullOrEmpty(title))
            {
                CurrentPageTitle = title;
                if (aboutme != null)
                {
                    string strThumbimage = Path.GetFileNameWithoutExtension(aboutme.S3ID);
                    strThumbimage = strThumbimage + ".png";
                    strAboutmeURL = S3Manager.GeneratePreSignedURL(AmazonS3BucketDetails.VideoBucket, aboutme.S3ID, 20);
                    ImageYourself = S3Manager.GeneratePreSignedURL(AmazonS3BucketDetails.PhotoBucket, strThumbimage, 20);
                    //strAboutmeURL = aboutme.ResourceURL;
                    //ImageYourself = aboutme.ThumbnailURL;
                }
                if (skill != null)
                {
                    string strThumbimage = Path.GetFileNameWithoutExtension(skill.S3ID);
                    strThumbimage = strThumbimage + ".png";
                    strSkillURL = S3Manager.GeneratePreSignedURL(AmazonS3BucketDetails.VideoBucket, skill.S3ID, 20);
                    ImageAboutMyskills = S3Manager.GeneratePreSignedURL(AmazonS3BucketDetails.PhotoBucket, strThumbimage, 20);
                    //strSkillURL = skill.ResourceURL;
                    //ImageAboutMyskills = skill.ThumbnailURL;
                }
                if (ambition != null)
                {
                    string strThumbimage = Path.GetFileNameWithoutExtension(ambition.S3ID);
                    strThumbimage = strThumbimage + ".png";
                    strInterestURL = S3Manager.GeneratePreSignedURL(AmazonS3BucketDetails.VideoBucket, ambition.S3ID, 20);
                    ImageAreaofinterest = S3Manager.GeneratePreSignedURL(AmazonS3BucketDetails.PhotoBucket, strThumbimage, 20);
                    //strInterestURL = ambition.ResourceURL;
                    //ImageAreaofinterest = ambition.ThumbnailURL;
                }
                CandidateID = strCandidateID;
                SearchID = strSearchID;
            }
            else
            {
                CurrentPageTitle = "Vidoes";
            }
            UserDialogs.Instance.HideLoading();

            _commonservice = new HttpCommonService();
            ProfileViewerRequestData = new ProfileViewerRequestData();
            ProfileViewerResponseData = new ProfileViewerResponseData();


        }
        #endregion

       // #region Constructor 2
        //public RecruiterPlayVideoViewModel(string title, AboutMeVideo aboutme, SkillVideo skill, AmbitionVideo ambition, string strCandidateID, INavigation objNav)
        //{
        //    OnRecruiterPlayCommand = new RelayCommand<string>(OnPlayCommand);
        //    navigationService = objNav;
        //    IsCandidateAfterSelected = true;
        //    UserDialogs.Instance.ShowLoading("Loading Candidate Profile");
        //    if (!string.IsNullOrEmpty(title))
        //    {
        //        CurrentPageTitle = title;
        //        if (aboutme != null)
        //        {
        //            strAboutmeURL = aboutme.ResourceURL;
        //            ImageYourself = aboutme.ThumbnailURL;
        //        }
        //        if (skill != null)
        //        {
        //            strSkillURL = skill.ResourceURL;
        //            ImageAboutMyskills = skill.ThumbnailURL;
        //        }
        //        if (ambition != null)
        //        {
        //            strInterestURL = ambition.ResourceURL;
        //            ImageAreaofinterest = ambition.ThumbnailURL;
        //        }
        //    }
        //    else
        //    {
        //        CurrentPageTitle = "Vidoes";
        //    }
        //    CandidateID = strCandidateID;
        //    UserDialogs.Instance.HideLoading();

        //    _commonservice = new HttpCommonService();
        //    ProfileViewerRequestData = new ProfileViewerRequestData();
        //    ProfileViewerResponseData = new ProfileViewerResponseData();
        //}
       // #endregion

        private async void OnPlayCommand(string sender)
        {
            switch (sender)
            {
                case "AboutUsPlay":
                    #region OpenCompany
                    if (isClicked)
                    {
                        isClicked = false;
                        //PlayInitialAPICall();
                        if (!string.IsNullOrEmpty(strAboutmeURL))
                        {
                            await navigationService.PushAsync(new PlayVideo(strAboutmeURL, CandidateID, (int)ResourceType.AboutMe));
                        }
                        else
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.AboutMeVideoNotAvailable);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    #endregion
                    break;

                case "MySkillsPlay":
                    #region OpenCompany
                    if (isClicked)
                    {
                        isClicked = false;
                        //PlayInitialAPICall();
                        if (!string.IsNullOrEmpty(strSkillURL))
                        {
                            await navigationService.PushAsync(new PlayVideo(strSkillURL, CandidateID, (int)ResourceType.Skill));
                        }
                        else
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.SkillVideoNotAvailable);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    #endregion
                    break;

                case "InterestsPlay":
                    #region OpenCompany
                    if (isClicked)
                    {
                      //  PlayInitialAPICall();
                        if (!string.IsNullOrEmpty(strInterestURL))
                            await navigationService.PushAsync(new PlayVideo(strInterestURL, CandidateID, (int)ResourceType.Interest));
                        else
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.InterestVideoNotAvailable);
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    #endregion
                    break;
            }
        }
        //#region IsViewed
        //private bool IsViewed(string strCandidateID, string strSearchID)
        //{
        //    bool IsReturnedValue = false;
        //    //ProfileViewerCountHelper objProfileHelper = new ProfileViewerCountHelper();
        //    //ProfileViewerCountBO objProfileViewer = AppPreferences.ProfileViewerCount(CandidateID, SearchID);
        //    if (AppPreferences.ProfileViewerCount.CandidateID == null && (AppPreferences.ProfileViewerCount.SearchID == null))
        //    {
        //        var objLocalBO = new ProfileViewerCountBO();
        //        objLocalBO.CreatedOn = DateTime.Now;
        //        objLocalBO.IsViewed = false;
        //        objLocalBO.CandidateID = strCandidateID;
        //        objLocalBO.SearchID = strSearchID;
        //        AppPreferences.ProfileViewerCount = objLocalBO;
        //        //var IsAdded = objProfileHelper.AddData(objLocalBO);
        //        //if (IsAdded == 1)
        //        //    IsReturnedValue = false;
        //    }
        //    else if (AppPreferences.ProfileViewerCount.IsViewed)
        //    {
        //        IsReturnedValue = true;
        //    }
        //    return IsReturnedValue;
        //}

        //#endregion

        //public async void PlayInitialAPICall()
        //{
        //    try
        //    {
        //        ProfileViewerRequestData.HiremeeID = AppSessionData.ActiveToken.HireMeID;
        //        ProfileViewerRequestData.Token = AppSessionData.ActiveToken.Token;
        //        ProfileViewerRequestData.HiremeeSeekerID = CandidateID;

        //        bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
        //        if (isNetworkAvailable)
        //        {
        //            var result = await _commonservice.PostAsync<ProfileViewerResponseData, ProfileViewerRequestData>(APIData.PHP_REST_API_BASE_URL + APIMethods.RecruiterProfileviewer, ProfileViewerRequestData);
        //            if (result != null)
        //            {
        //                if (result.Code == "200")
        //                {
        //                    IsViewed(AppSessionData.ProfileViewerCount.CandidateID, AppSessionData.ProfileViewerCount.SearchID);
        //                }
        //                else
        //                {
        //                    await UserDialogs.Instance.AlertAsync(result.Message);
        //                }
        //            }
        //            else
        //            {
        //                UserDialogs.Instance.HideLoading();
        //                await UserDialogs.Instance.AlertAsync("Please try-again...");
        //            }
        //        }
        //        else
        //        {
        //            await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        System.Diagnostics.Debug.WriteLine(ex.Message);
        //    }
        //}
    }
}

