﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.Models.Recruiter;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.Recruiter
{
    public class RejectedCandidateViewModel : BaseViewModel
    {
        #region Initialization
        private HttpCommonService _commonservice { get; set; }
        public RejectedCandidateEntireResponse RejectedCandidateEntireResponse { get; set; }
        public RejectedCandidateRequestData RejectedCandidateRequestData { get; set; }

        private ObservableCollection<Searchdetail> _ItemSource;
        public ObservableCollection<Searchdetail> ItemSource
        {
            get { return _ItemSource; }
            set { _ItemSource = value; OnPropertyChanged(); }
        }


        private ObservableCollection<Searchdetail> _TempItemSource;
        public ObservableCollection<Searchdetail> TempItemSource
        {
            get { return _TempItemSource; }
            set { _TempItemSource = value; OnPropertyChanged(); }
        }
        //public ObservableCollection<Searchdetail> TempItemSource;
        INavigation navigation;
        #endregion

        #region Constructor
        public RejectedCandidateViewModel(INavigation _navigation, string searchid)
        {

            navigation = _navigation;
            _commonservice = new HttpCommonService();
            RejectedCandidateRequestData = new RejectedCandidateRequestData();
            RejectedCandidateEntireResponse = new RejectedCandidateEntireResponse();


            RejectedCandidateRequestData.HiremeeID = AppSessionData.ActiveToken.HireMeID;
            RejectedCandidateRequestData.Token = AppSessionData.ActiveToken.Token;
            RejectedCandidateRequestData.search_id = searchid;
            SearchPlaceHolderText = "Search Rejected Candidate";
            IsLableViewVisible = false;
			 SearchPlaceHolderText = "Search Rejected Candidate";

            BindList();
        }
        #endregion

        #region Bind List Item source form API
        private async void BindList()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {

                    var result = await _commonservice.PostAsync<RejectedCandidateEntireResponse, RejectedCandidateRequestData>(APIData.API_BASE_URL + APIMethods.GetSearchRejectedLists, RejectedCandidateRequestData);
                    if (result !=null)
                    {
                        if (result.code == "200")
                        {
                            if (result.responseText.SearchDetails != null)
                            {
                                UserDialogs.Instance.HideLoading();
                                ItemSource = new ObservableCollection<Searchdetail>(result.responseText.SearchDetails);
                                TempItemSource = ItemSource;
                                //TempItemSource = new ObservableCollection<Searchdetail>(result.responseText.SearchDetails);
                                isEnabledSearchBar = true;
                                if (ItemSource.Count > 0)
                                {
                                    IsLableViewVisible = false;
                                    IsListViewVisible = true;
                                }
                                else
                                {
                                    IsListViewVisible = false;
                                    IsLableViewVisible = true;
                                    isEnabledSearchBar = false;
                                }
                                UserDialogs.Instance.HideLoading();
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.NoRecordsFound);
                            }
                        }
                      

                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);

                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);

                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "RejectedCandidateViewModel.BindList");
            }
        }
        #endregion

        #region Propeties
        private Searchdetail _SelectedItem;
        public Searchdetail SelectedItem
        {
            get { return _SelectedItem; }
            set { _SelectedItem = value; OnPropertyChanged(); }
        }

        private bool _IsListViewVisible;
        public bool IsListViewVisible
        {
            get { return _IsListViewVisible; }
            set { _IsListViewVisible = value; OnPropertyChanged(); }
        }

        private bool _IsLableViewVisible;
        public bool IsLableViewVisible
        {
            get { return _IsLableViewVisible; }
            set { _IsLableViewVisible = value; OnPropertyChanged(); }
        }

        public ICommand SelectedCommand => new Command(() =>
        {
            //avigation.PushAsync(new SeekerNotificationDetailPage(SelectedItem));
        });
        
        private bool _isVisibleSearchbarCancel;
        public bool IsVisibleSearchbarCancelButton
        {
            get { return _isVisibleSearchbarCancel; }
            set { _isVisibleSearchbarCancel = value; OnPropertyChanged(); }
        }

        public string _SearchText;
        public string SearchText
        {
            set
            {
                _SearchText = value;
                SearchText_TextChanged();
                OnPropertyChanged();
            }
            get { return _SearchText; }
        }
        public bool _isEnabledSearchBar;

        public bool isEnabledSearchBar
        {
            set { _isEnabledSearchBar = value; OnPropertyChanged(); }
            get { return _isEnabledSearchBar; }
        }
        public Command OnSearchClearCommand => new Command(() =>
        {
            IsVisibleSearchbarCancelButton = false;
            SearchText = string.Empty;
            SearchPlaceHolderText = "Search Rejected Candidate";

        });
        private string _searchPlaceHolder;
        public string SearchPlaceHolderText
        {
            get { return _searchPlaceHolder; }
            set { _searchPlaceHolder = value; OnPropertyChanged(); }
        }
        #endregion

        #region Searchbar TextChanged event
        public void SearchText_TextChanged()
        {
            try
            {
                var searchtext = SearchText;
                if (string.IsNullOrEmpty(searchtext))
                {
                    SearchPlaceHolderText = "Search Rejected Candidate";
                    IsVisibleSearchbarCancelButton = false;
                    ItemSource = TempItemSource;
                    return;
                }

                if (TempItemSource != null)
                {

                    var Suggetions = TempItemSource.Where
                    (c => c.profiledetails.fullname.ToLower().Contains(searchtext.ToLower())
                    || c.edcuactionaldetails.cousetype.ToLower().Contains(searchtext.ToLower())
                    || c.edcuactionaldetails.coursename.ToLower().Contains(searchtext.ToLower()));

                    ItemSource = new ObservableCollection<Searchdetail>(Suggetions);
                    IsVisibleSearchbarCancelButton = true;
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "RejectedCandidateViewModel.SearchText_TextChanged");
            }
            #endregion

        }

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}


