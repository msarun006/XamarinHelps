﻿using Acr.UserDialogs;
using HireMe.Models;
using HireMe.Models.Recruiter;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Windows.Input;
using Xamarin.Forms;
using System.Collections.Generic;
using System.Threading.Tasks;
using HireMe.Helpers;

namespace HireMe.ViewModels.Recruiter
{
    public class RecruiterShortlistedCandidateViewModel : BaseViewModel
    {
        public bool isClicked = true;
        private INavigation navigation;
        private string searchid;
        public Command OnMenuItemClicked
        {
            get;
            set;
        }
        public List<RecruitersearchBO> TempItemSource;
        private HttpCommonService _commonservice { get; set; }
        public SelectedListRetrivalRequestData SelectedListRetrivalRequestData { get; set; }
        public SelectedCandidatelistResponse SelectedCandidatelistResponse { get; set; }

        private List<RecruitersearchBO> _ItemSource;
        public List<RecruitersearchBO> ItemSource
        {
            get { return _ItemSource; }
            set { _ItemSource = value; OnPropertyChanged(); }
        }

        public RecruiterShortlistedCandidateViewModel(INavigation navigation, string searchid)
        {
            this.navigation = navigation;
            this.searchid = searchid;
            _commonservice = new HttpCommonService();
            SelectedListRetrivalRequestData = new SelectedListRetrivalRequestData();
            SelectedCandidatelistResponse = new SelectedCandidatelistResponse();
            SelectedListRetrivalRequestData.HiremeeID = AppSessionData.ActiveToken.HireMeID;
            SelectedListRetrivalRequestData.Token = AppSessionData.ActiveToken.Token;
            SelectedListRetrivalRequestData.SearchID = searchid;
            BindShortListedCandidateList();
            OnMenuItemClicked = new Command(CommonFunction);
            MarkAllText = "Mark All";
            SearchPlaceHolderText = "Search Candidate";
            LoadingText = false;
        }

        void CommonFunction(object obj)
        {
            if (obj.ToString() == "markall")
            {
                if (MarkAllText == "Mark All")
                {
                    SelectAll();
                    MarkAllText = "Un Mark All";
                }
                else if (MarkAllText == "Un Mark All")
                {
                    SelectNone();
                    MarkAllText = "Mark All";
                }

            }
            else if (obj.ToString() == "sendmail")
            {
                SendMail();

            }
        }


        public List<RecruitersearchBO> GetSelection()
        {
            List<RecruitersearchBO> selecteditemslist = null;
            if (ItemSource != null && ItemSource.Count > 0)
            {
                selecteditemslist = ItemSource.FindAll(item => item.IsSelected);
            }
            return selecteditemslist;
        }

        async void SendMail()
        {
            string selectedCandidatelist = string.Empty;
            List<RecruitersearchBO> selecteditemslist = GetSelection();

            if (selecteditemslist != null)
            {
                foreach (var item in selecteditemslist)
                {
                    selectedCandidatelist = (selectedCandidatelist == "" ? item.candidateID : selectedCandidatelist + "," + item.candidateID);
                }
                if (selectedCandidatelist != "")
                {
                    await navigation.PushAsync(new RecruiterDraftEmailPage(selectedCandidatelist, searchid));
                }
                else
                {
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectCandidate);

                }
            }
            else
            {
                await UserDialogs.Instance.AlertAsync("Please select One of The Candidate.");
            }
        }


        void SelectNone()
        {
            if (ItemSource != null && ItemSource.Count > 0)
            {
                foreach (var item in ItemSource)
                {
                    item.IsSelected = false;
                }
            }
        }


        void SelectAll()
        {
            if (ItemSource != null && ItemSource.Count > 0)
            {
                foreach (var item in ItemSource)
                {
                    item.IsSelected = true;
                }
            }
        }

        private string markAllText;
        public string MarkAllText
        {
            get { return markAllText; }
            set { markAllText = value; OnPropertyChanged(); }
        }



        private bool loadingText;
        public bool LoadingText
        {
            get { return loadingText; }
            set
            {
                loadingText = value; OnPropertyChanged();
            }
        }


        private bool _IsListViewVisible;
        public bool IsListViewVisible
        {
            get { return _IsListViewVisible; }
            set
            {
                _IsListViewVisible = value; OnPropertyChanged();
            }
        }


        #region Switch_Toggled
        public void Switch_Toggled(object sender, ToggledEventArgs e)
        {
            if (e.Value)
            {
                if (ItemSource.Count == 1)
                {

                    MarkAllText = "Un Mark All";
                }
            }
            else
            {
                if (ItemSource.Count == 1)
                {
                    MarkAllText = "Mark All";
                }
            }

        }
        #endregion


        #region Searchbar Controls
        private bool _isVisibleSearchbarCancel;
        public bool IsVisibleSearchbarCancelButton
        {
            get { return _isVisibleSearchbarCancel; }
            set { _isVisibleSearchbarCancel = value; OnPropertyChanged(); }
        }

        public string _SearchText;
        public string SearchText
        {
            set
            {
                _SearchText = value;
                SearchText_TextChanged();
                OnPropertyChanged();
            }
            get { return _SearchText; }
        }
        public bool _isEnabledSearchBar;

        public bool isEnabledSearchBar
        {
            set { _isEnabledSearchBar = value; OnPropertyChanged(); }
            get { return _isEnabledSearchBar; }
        }
        public Command OnSearchClearCommand => new Command(() =>
        {
            IsVisibleSearchbarCancelButton = false;
            SearchText = string.Empty;
            SearchPlaceHolderText = "Search Candidate";

        });
        private string _searchPlaceHolder;
        public string SearchPlaceHolderText
        {
            get { return _searchPlaceHolder; }
            set { _searchPlaceHolder = value; OnPropertyChanged(); }
        }


        public void SearchText_TextChanged()
        {
            var searchtext = SearchText;
            if (string.IsNullOrEmpty(searchtext))
            {
                SearchPlaceHolderText = "Search Candidate";
                IsVisibleSearchbarCancelButton = false;
                BindShortListedCandidateList();
                return;
            }

            if (TempItemSource != null)
            {

                ItemSource = TempItemSource;
                var Suggetions = ItemSource.FindAll
                (c => c.profileDetails.FullName.ToLower().Contains(searchtext.ToLower())
                || c.educationalDetails.CourseName.ToLower().Contains(searchtext.ToLower())
                || c.educationalDetails.CourseType.ToLower().Contains(searchtext.ToLower()));

                ItemSource = new List<RecruitersearchBO>(Suggetions);
                IsVisibleSearchbarCancelButton = true;
            }

        }

        #endregion

        private async void BindShortListedCandidateList()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {

					var result = await _commonservice.PostAsync<SelectedCandidatelistResponse, SelectedListRetrivalRequestData>(APIData.API_BASE_URL + APIMethods.GetSearchSelectedLists, SelectedListRetrivalRequestData);
                    if (result !=null)
                    {
                        if (result.code == "200")
                        {

                            UserDialogs.Instance.HideLoading();
                            ItemSource = new List<RecruitersearchBO>(result.ResponseText.Data);
                            TempItemSource = new List<RecruitersearchBO>(result.ResponseText.Data);
                            isEnabledSearchBar = true;
                            if (ItemSource.Count > 0)
                            {
                                LoadingText = false;
                                IsListViewVisible = true;
                            }
                            else
                            {
                                isEnabledSearchBar = false;
                                IsListViewVisible = false;
                                LoadingText = true;
                            }
                        }
                        else
                        {

                            UserDialogs.Instance.HideLoading();
                            isEnabledSearchBar = false;
                            await UserDialogs.Instance.AlertAsync(result.message);

                        }
                    }
                }
                else
                {

                    UserDialogs.Instance.HideLoading();
                    isEnabledSearchBar = false;
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);

                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                await UserDialogs.Instance.AlertAsync(ex.Message);
                SendErrorMessageToServer(ex, "RecruiterShortlistedCandidateViewModel.BindShortListedCandidateList");

            }
        }

        private RecruitersearchBO _SelectedItem;
        public RecruitersearchBO SelectedItem
        {
            get { return _SelectedItem; }
            set { _SelectedItem = value; OnPropertyChanged(); }
        }

        public ICommand SelectedCommand => new Command(async () =>
        {
            if (isClicked)
            {
                isClicked = false;

                var data = SelectedItem as RecruitersearchBO;
            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });
        });

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
