﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using HireMe.Helpers;
using HireMe.UI;
using MvvmHelpers;
using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.Recruiter
{
    public class PreviousCommentViewModel : BaseViewModel
    {
        private ObservableCollection<Recruitercommentsdetail> _ItemSource;
        public ObservableCollection<Recruitercommentsdetail> ItemSource
        {
            get { return _ItemSource; }
            set { _ItemSource = value; OnPropertyChanged(); }
        }
        INavigation navigation;
        private string candidateid;
        private HttpCommonService _commonservice { get; set; }
        ObservableCollection<Recruitercommentsdetail> _CandidateComments { get; set; }
        public ICommand PreviousCommentCommand { get; set; }
        INavigation Navigation;
        public bool isClicked = true;
        public PreviousCommentViewModel(string objcandidateid,INavigation _navigation)
        {
            candidateid = objcandidateid;
            Navigation = _navigation;
            _commonservice = new HttpCommonService();
            PreviousCommentCommand = new RelayCommand<string>(DoOperation);
            LoadComments();
        }

        

        private bool _islblError=false;

        public bool IslblError
        {
            get { return _islblError; }
            set { _islblError = value; OnPropertyChanged(); }
        }

        #region LoadComments
        private async void LoadComments()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                var requestdata = new MasterTableRequestData()
                {
                    HiremeeID = AppSessionData.ActiveToken.HireMeID,
                    Token = AppSessionData.ActiveToken.Token,
                    CandidateID = candidateid,
                };
                var responseobj = await _commonservice.PostAsync<CommentsListResponseData, MasterTableRequestData>(APIData.API_BASE_URL + APIMethods.ViewComment, requestdata);
                if (responseobj != null)
                {
                    if (responseobj.code == "200" && responseobj.responseText.RecruiterCommentsDetails != null)
                    {
                        UserDialogs.Instance.HideLoading();
                        if (responseobj.responseText.RecruiterCommentsDetails.Count > 0)
                        {
                            _CandidateComments = new ObservableCollection<Recruitercommentsdetail>(responseobj.responseText.RecruiterCommentsDetails);
                           ItemSource = _CandidateComments;
                        }
                        else
                        {
                            _CandidateComments = new ObservableCollection<Recruitercommentsdetail>(responseobj.responseText.RecruiterCommentsDetails);
                            ItemSource = _CandidateComments;
                            IslblError = true;
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        _CandidateComments = new ObservableCollection<Recruitercommentsdetail>(responseobj.responseText.RecruiterCommentsDetails);
                        ItemSource = _CandidateComments;
                        IslblError = true;
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                   await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "PreviousCommentViewModel.LoadComments");
            }
        }
        #endregion

        private async void DoOperation(string sender)
        {
            switch (sender)
            {
                case "OnCommentClicked":
                    if (isClicked)
                    {
                        isClicked = false;
                        IslblError = false;
                        var page = new CommentPopupPage(candidateid, _CandidateComments);
                        Navigation.PushAsync(page);
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
            }
        }

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
