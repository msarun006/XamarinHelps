﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.Models;
using HireMe.Models.Recruiter;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.Recruiter
{
    public class SelectionSearchNameViewModel : BaseViewModel
    {
        #region Initialization
        public bool isClicked = true;
        private HttpCommonService _commonservice { get; set; }
        public BaseRequestDTO BaseRequestDTO { get; set; }
        public SelectionSearchListResponse _selectionSearchListResponse { get; set; }

        public ObservableCollection<SearchData> TempItemSource;
        private ObservableCollection<SearchData> _ItemSource;
        public ObservableCollection<SearchData> ItemSource
        {
            get { return _ItemSource; }
            set { _ItemSource = value; OnPropertyChanged(); }
        }
        INavigation navigation;
        #endregion

        #region Constructor
        public SelectionSearchNameViewModel(INavigation _navigation)
        {
            navigation = _navigation;

            IsLableViewVisible = false;

            _commonservice = new HttpCommonService();
            BaseRequestDTO = new BaseRequestDTO();
            _selectionSearchListResponse = new SelectionSearchListResponse();
            SearchPlaceHolderText = "Search SearchCriteria";

            BaseRequestDTO.HiremeeID = AppSessionData.ActiveToken.HireMeID;
            BaseRequestDTO.Token = AppSessionData.ActiveToken.Token;
            BindSearchHistoryList();
        }
        #endregion

        #region Searchbar Controls
        private bool _isVisibleSearchbarCancel;
        public bool IsVisibleSearchbarCancelButton
        {
            get { return _isVisibleSearchbarCancel; }
            set { _isVisibleSearchbarCancel = value; OnPropertyChanged(); }
        }

        public string _SearchText;
        public string SearchText
        {
            set
            {
                _SearchText = value;
                SearchText_TextChanged();
                OnPropertyChanged();
            }
            get { return _SearchText; }
        }
        public bool _isEnabledSearchBar;

        public bool isEnabledSearchBar
        {
            set { _isEnabledSearchBar = value; OnPropertyChanged(); }
            get { return _isEnabledSearchBar; }
        }
        public Command OnSearchClearCommand => new Command(() =>
        {
            IsVisibleSearchbarCancelButton = false;
            SearchText = string.Empty;
            SearchPlaceHolderText = "Search SearchCriteria";

        });
        private string _searchPlaceHolder;
        public string SearchPlaceHolderText
        {
            get { return _searchPlaceHolder; }
            set { _searchPlaceHolder = value; OnPropertyChanged(); }
        }


        public void SearchText_TextChanged()
        {
            try
            {
                var searchtext = SearchText;
                if (string.IsNullOrEmpty(searchtext))
                {
                    SearchPlaceHolderText = "Search SearchCriteria";
                    IsVisibleSearchbarCancelButton = false;
                    ItemSource = TempItemSource;
                    return;
                }

                if (TempItemSource != null)
                {

                    var Suggetions = TempItemSource.Where
                    (c => c.Search_critria.ToLower().Contains(searchtext.ToLower()));

                    ItemSource = new ObservableCollection<SearchData>(Suggetions);
                    IsVisibleSearchbarCancelButton = true;
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
            }
        }

        private async void BindSearchHistoryList()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {

                    var result = await _commonservice.PostAsync<SelectionSearchListResponse, BaseRequestDTO>(APIData.API_BASE_URL + APIMethods.Selectionlist, BaseRequestDTO);
                    if (result != null)
                    {
                        if (result.code == "200")
                        {
                            if (result.responseText != null)
                            {
                                UserDialogs.Instance.HideLoading();
                                ItemSource = new ObservableCollection<SearchData>(result.responseText.Data);
                                TempItemSource = new ObservableCollection<SearchData>(result.responseText.Data);
                                isEnabledSearchBar = true;
                                if (ItemSource.Count > 0)
                                {
                                    IsLableViewVisible = false;
                                    IsListViewVisible = true;
                                }
                                else
                                {
                                    IsListViewVisible = false;
                                    IsLableViewVisible = true;
                                    isEnabledSearchBar = false;
                                }
                            }
                            else
                            {
                                IsListViewVisible = false;
                                IsLableViewVisible = true;
                                isEnabledSearchBar = false;
                            }

                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            isEnabledSearchBar = false;
                            await UserDialogs.Instance.AlertAsync(result.message);
                        }
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "SelectionSearchNameViewModel.BindSearchHistoryList");
                //await UserDialogs.Instance.AlertAsync(ex.Message);
            }
        }
        #endregion

        private bool _IsListViewVisible;
        public bool IsListViewVisible
        {
            get { return _IsListViewVisible; }
            set { _IsListViewVisible = value; OnPropertyChanged(); }
        }

        private bool _IsLableViewVisible;
        public bool IsLableViewVisible
        {
            get { return _IsLableViewVisible; }
            set { _IsLableViewVisible = value; OnPropertyChanged(); }
        }


        private SearchData _SelectedItem;
        public SearchData SelectedItem
        {
            get { return _SelectedItem; }
            set { _SelectedItem = value; OnPropertyChanged(); }
        }

        #region Selected Command
        public ICommand SelectedCommand => new Command(async () =>
        {
            if (isClicked)
            {
                isClicked = false;

                var data = SelectedItem as SearchData;
                if (string.IsNullOrEmpty(data.search_id))
                {
                    UserDialogs.Instance.Alert("Search Name is Invalid. Please select other Search Name");
                }
                else
                {
                    await navigation.PushAsync(new SelectedCandidateList(data.search_id.ToString()));
                }
                
            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });
        });
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
