﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using Acr.UserDialogs;
using HireMe.DataLayer.Models;
using MvvmHelpers;
using Xamarin.Forms;
using System.Threading.Tasks;
using HireMe.Helpers;

namespace HireMe
{
    public class MultipleYearSelectionPageViewModel : BaseViewModel
    {
        ObservableCollection<Year> _yearList;
        public bool isClicked = true;
        private HttpCommonService _commonservice { get; set; }
        private string SearchName = "";
        private List<Year> SelectionSkills;
        List<Year> yearlist;
        INavigation Navigation;
        string PageName;

        public MultipleYearSelectionPageViewModel(INavigation navigation, string pageName, List<Year> skills)
        {
            Navigation = navigation;
            PageName = pageName;
            SelectionSkills = skills;
            _commonservice = new HttpCommonService();
            yearlist = new List<Year>();
            BindCompletionYearData();

            DoneClicked = new Command(onDoneClicked);
            btnSendIsDestructive = false;
        }

        public Boolean _btnSendIsDestructive;
        public Boolean btnSendIsDestructive
        {
            get { return _btnSendIsDestructive; }
            set { _btnSendIsDestructive = value; OnPropertyChanged(); }
        }

        public Command DoneClicked
        {
            get;
            set;
        }

        public List<Year> _YearListItemSource;
        public List<Year> YearListItemSource
        {
            get { return _YearListItemSource; }
            set { _YearListItemSource = value; OnPropertyChanged(); }
        }

        #region Searchbar Controls
        private bool _isVisibleSearchbarCancel;
        public bool IsVisibleSearchbarCancelButton
        {
            get { return _isVisibleSearchbarCancel; }
            set { _isVisibleSearchbarCancel = value; OnPropertyChanged(); }
        }
        public bool _isEnabledSearchBar;

        public bool isEnabledSearchBar
        {
            set { _isEnabledSearchBar = value; OnPropertyChanged(); }
            get { return _isEnabledSearchBar; }
        }
        public string _SearchText;
        public string SearchText
        {
            set
            {
                _SearchText = value;
                SearchText_TextChanged();
                OnPropertyChanged();
            }
            get { return _SearchText; }
        }
        public Command OnSearchClearCommand => new Command(() =>
        {

            SearchText = string.Empty;


        });
        private string _searchPlaceHolder;
        public string SearchPlaceHolderText
        {
            get { return _searchPlaceHolder; }
            set { _searchPlaceHolder = value; OnPropertyChanged(); }
        }
        private void DynamicSearchPlaceholder()
        {
            SearchPlaceHolderText = "Search Year";

        }

        public void SearchText_TextChanged()
        {
            var searchtext = SearchText;
            if (string.IsNullOrEmpty(searchtext))
            {


                if(yearlist.Count>0)
                {
                    YearListItemSource = yearlist;
                    IsVisibleSearchbarCancelButton = false;
                }
                else
                {
                    IsVisibleSearchbarCancelButton = false;
                    BindCompletionYearData();

                }

                return;
            }
                IsVisibleSearchbarCancelButton = true;
                var searchresults = yearlist.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
                YearListItemSource = searchresults;
            


        }

        #endregion
        async void BindCompletionYearData()
        {
            Debug.WriteLine("@ DynamicListPage.BindCompletionYearData");
            int currentYear = DateTime.Now.Year;
            yearlist = new List<Year>();

            if (_yearList == null)
            {
                try
                {
                    UserDialogs.Instance.ShowLoading();
                    var requestdata = new MasterTableRequestData()
                    {
                        HiremeeID = AppSessionData.ActiveToken.HireMeID,
                        Token = AppSessionData.ActiveToken.Token,
                        TableName = "yearofcompletion"
                    };

                    var responseobj = await _commonservice.PostAsync<YearOfCompletionResponse, MasterTableRequestData>(APIData.API_BASE_URL + APIMethods.MasterTables, requestdata);
                    if (responseobj != null)
                    {
                        if (responseobj.code == "200" && responseobj.responseText.yearofcompletion != null)
                        {
                            foreach (var item in responseobj.responseText.yearofcompletion)
                            {
                                yearlist.Add(new Year { ID = item.id.ToString(), Title = item.name });
                            }
                            isEnabledSearchBar = true;
                            _yearList = new ObservableCollection<Year>(yearlist);
                            UserDialogs.Instance.HideLoading();
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            isEnabledSearchBar = false;
                            await UserDialogs.Instance.AlertAsync(responseobj.message);
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        isEnabledSearchBar = false;
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                    UserDialogs.Instance.HideLoading();
                    SendErrorMessageToServer(ex, "MultipleYearSelectionPageViewModel.BindCompletionYearData");
                }


            }


            //MultipleYearSelectionHelper objSelectionHelper = new MultipleYearSelectionHelper();
          //  List<MultipleYearSelectionBO> selectedSkills = objSelectionHelper.GetData(SearchName);
            if (SelectionSkills != null && SelectionSkills.Count > 0)
            {

                if (_yearList.Count > 0 && SelectionSkills.Count > 0)
                {
                    foreach (var skills in _yearList)
                    {
                        skills.IsSelected = false;
                        foreach (var selectionSkill in SelectionSkills)
                        {
                            if (skills.ID == selectionSkill.ID)
                            {
                                skills.IsSelected = selectionSkill.IsSelected;
                            }
                        }
                    }
                }
            }

            YearListItemSource = yearlist;
        }

        public async void onDoneClicked()
        {
            if (isClicked)
            {
                isClicked = false;
                btnSendIsDestructive = true;

                //MultipleYearSelectionHelper objSelectionHelper = new MultipleYearSelectionHelper();
                //List<MultipleYearSelectionBO> lstMultipleSkillSelection = objSelectionHelper.GetData(SearchName);

                //if (lstMultipleSkillSelection.Count > 0)
                //{
                //    objSelectionHelper.DeleteData();
                //}


                MultipleSelectionBO objSelectionBO = new MultipleSelectionBO();
                List<Year> selectedYears = new List<Year>();

                if (_yearList != null)
                {
                    foreach (var year in _yearList)
                    {
                        objSelectionBO.SearchName = SearchName;
                        objSelectionBO.SelectedItemID = year.ID;
                        objSelectionBO.Title = year.Title;
                        objSelectionBO.IsSelected = year.IsSelected;
                        objSelectionBO.CreatedOn = DateTime.Now;
                        //objSelectionHelper.AddData(objSelectionBO);
                        if (year.IsSelected)
                        {
                            selectedYears.Add(year);
                        }
                    }
                }


                if (PageName == "RecruiterSearchVideoProfile")
                {
                    MessagingCenter.Send<MultipleYearSelectionPageViewModel, List<Year>>(this, "RecruiterSearchVideoProfile", selectedYears);
                }

                Navigation.PopAsync();
            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });
        }


        public async void OnSkill_Toggled(object sender, ToggledEventArgs e)
        {
            //var selectedYear = ((Switch)sender).BindingContext as CompletionYear;
            var selectedYear = ((Switch)sender).BindingContext as Year;

            var skillscount = 0;
            foreach (var year in _yearList)
            {
                if (year.IsSelected)
                    skillscount++;
            }

            if (skillscount > 3)
            {
                selectedYear.IsSelected = false;
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectedMaximumyears);
            }
        }

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
