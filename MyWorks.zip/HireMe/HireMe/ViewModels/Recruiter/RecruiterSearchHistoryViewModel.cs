﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.Models;
using HireMe.Models.Recruiter;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;


namespace HireMe.ViewModels.Recruiter
{
    public class RecruiterSearchHistoryViewModel : BaseViewModel
    {
        public bool isClicked = true;
        private HttpCommonService _commonservice { get; set; }
        public BaseRequestDTO BaseRequestDTO { get; set; }
        public SelectionListResponse SelectionListResponse { get; set; }

        public ObservableCollection<SearchDetailBO> TempItemSource;
        private ObservableCollection<SearchDetailBO> _ItemSource;
        public ObservableCollection<SearchDetailBO> ItemSource
        {
            get { return _ItemSource; }
            set { _ItemSource = value; OnPropertyChanged(); }
        }
        INavigation navigation;
        public RecruiterSearchHistoryViewModel(INavigation _navigation)
        {

            navigation = _navigation;

            IsLableViewVisible = false;

            _commonservice = new HttpCommonService();
            BaseRequestDTO = new BaseRequestDTO();
            SelectionListResponse = new SelectionListResponse();
            SearchPlaceHolderText = "Enter Search Criteria";

            BaseRequestDTO.HiremeeID = AppSessionData.ActiveToken.HireMeID;
            BaseRequestDTO.Token = AppSessionData.ActiveToken.Token;
            BindSearchHistoryList();
        }


        #region Searchbar Controls
        private bool _isVisibleSearchbarCancel;
        public bool IsVisibleSearchbarCancelButton
        {
            get { return _isVisibleSearchbarCancel; }
            set { _isVisibleSearchbarCancel = value; OnPropertyChanged(); }
        }

        public string _SearchText;
        public string SearchText
        {
            set
            {
                _SearchText = value;
                SearchText_TextChanged();
                OnPropertyChanged();
            }
            get { return _SearchText; }
        }
        public bool _isEnabledSearchBar;

        public bool isEnabledSearchBar
        {
            set { _isEnabledSearchBar = value; OnPropertyChanged(); }
            get { return _isEnabledSearchBar; }
        }
        public Command OnSearchClearCommand => new Command(() =>
        {
            IsVisibleSearchbarCancelButton = false;
            SearchText = string.Empty;
            SearchPlaceHolderText = "Search SearchCritria";

        });
        private string _searchPlaceHolder;
        public string SearchPlaceHolderText
        {
            get { return _searchPlaceHolder; }
            set { _searchPlaceHolder = value; OnPropertyChanged(); }
        }


        public void SearchText_TextChanged()
        {
            var searchtext = SearchText;
            if (string.IsNullOrEmpty(searchtext))
            {
                SearchPlaceHolderText = "Search SearchCritria";
                IsVisibleSearchbarCancelButton = false;
                BindSearchHistoryList();
                return;
            }

            if (TempItemSource != null)
            {

                ItemSource = TempItemSource;
                var Suggetions = ItemSource.Where
                (c => c.SearchCritria.ToLower().Contains(searchtext.ToLower()));

                ItemSource = new ObservableCollection<SearchDetailBO>(Suggetions);
                IsVisibleSearchbarCancelButton = true;
            }

        }

        #endregion

        private async void BindSearchHistoryList()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {

                    var result = await _commonservice.PostAsync<SelectionListResponse, BaseRequestDTO>(APIData.API_BASE_URL + APIMethods.Selectionshortlist, BaseRequestDTO);
                    if (result != null)
                    {
                        if (result.code == "200")
                        {
                            UserDialogs.Instance.HideLoading();
                            ItemSource = new ObservableCollection<SearchDetailBO>(result.responseText.data);
                            TempItemSource = new ObservableCollection<SearchDetailBO>(result.responseText.data);
                            isEnabledSearchBar = true;
                            if (ItemSource.Count > 0)
                            {
                                IsLableViewVisible = false;
                                IsListViewVisible = true;
                            }
                            else
                            {
                                IsListViewVisible = false;
                                IsLableViewVisible = true;
                                isEnabledSearchBar = false;
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            isEnabledSearchBar = false;
                            await UserDialogs.Instance.AlertAsync(result.message);
                        }
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "RecruiterSearchHistoryViewModel.BindSearchHistoryList");
                //await UserDialogs.Instance.AlertAsync(ex.Message);
            }
        }

        private bool _IsListViewVisible;
        public bool IsListViewVisible
        {
            get { return _IsListViewVisible; }
            set { _IsListViewVisible = value; OnPropertyChanged(); }
        }

        private bool _IsLableViewVisible;
        public bool IsLableViewVisible
        {
            get { return _IsLableViewVisible; }
            set { _IsLableViewVisible = value; OnPropertyChanged(); }
        }


        private SearchDetailBO _SelectedItem;
        public SearchDetailBO SelectedItem
        {
            get { return _SelectedItem; }
            set { _SelectedItem = value; OnPropertyChanged(); }
        }


        public ICommand SelectedCommand => new Command(async () =>
        {
            if (isClicked)
            {
                isClicked = false;

                var data = SelectedItem as SearchDetailBO;
                await navigation.PushAsync(new RecruiterShortlistedCandidatePage(data.SearchID.ToString()));
            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });
        });

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

    }
}
