﻿using System;
using MvvmHelpers;
using System.Collections.Generic;
using Xamarin.Forms;

using System.Threading.Tasks;
using Acr.UserDialogs;
using System.Diagnostics;
using System.Windows.Input;
using HireMe.Models;
using HireMe.Models.JobSeeker;
using HireMe.Helpers;

namespace HireMe
{
    public class DynamicListPageViewModel : BaseViewModel
    {
        #region ClassVariables
        string _fieldType;
        string _fieldValue;
        private HttpCommonService _commonservice { get; set; }

        IValueGetter _valueGetterInterface;
        List<CommonListItemSource> _cityList;
        List<CommonListItemSource> GlobalCommonListItemSource;
        INavigation Navigation;
        string PageName;
        #endregion


        #region Intiate Constructor
        public DynamicListPageViewModel(INavigation nav, string pagename, string fieldtype, string fieldvalue = null)
        {

            Debug.WriteLine("@ DynamicListPage.DynamicListPage");
            _fieldType = fieldtype;
            _fieldValue = fieldvalue;
            PageName = pagename;

            _commonservice = new HttpCommonService();
            isEnabledSearchBar = true;
            Navigation = nav;
            stackSearchAddNewItem = false;
            AddButtonclickedCommand = new Command(AddButtonclicked);
            GlobalCommonListItemSource = new List<CommonListItemSource>();
            GlobalCommonListItemSource = null;
            IsVisibleSearchbarCancelButton = false;
            IsLableViewVisible = false;
            IsListView = true;
            DynamicSearchPlaceholder();
            BindData();
        }
        #endregion


        public CommonListItemSource testItemSource { get; set; }

        public bool _isVisibleMessage;
        public bool isVisibleMessage
        {
            set { _isVisibleMessage = value; OnPropertyChanged(); }
            get { return _isVisibleMessage; }
        }

        public string _SearchText;
        public string SearchText
        {
            set
            {
                _SearchText = value;
                SearchText_TextChanged();
                OnPropertyChanged();
            }
            get { return _SearchText; }
        }

        public string _NotFoundEditText;
        public string NotFoundEditText
        {
            set { _NotFoundEditText = value; OnPropertyChanged(); }
            get { return _NotFoundEditText; }
        }

        public bool _stackSearchAddNewItem;

        public bool stackSearchAddNewItem
        {
            set { _stackSearchAddNewItem = value; OnPropertyChanged(); }
            get { return _stackSearchAddNewItem; }
        }

        public List<CommonListItemSource> _ListViewItemSource;
        public List<CommonListItemSource> ListViewItemSource
        {
            get { return _ListViewItemSource; }
            set
            {
                _ListViewItemSource = value;
                OnPropertyChanged();
            }
        }


        public CommonListItemSource _ListViewSelectedItem;
        public CommonListItemSource ListViewSelectedItem
        {
            get { return _ListViewSelectedItem; }
            set
            {
                _ListViewSelectedItem = value;
                OnPropertyChanged();
            }
        }


        #region Searchbar Controls
        private bool _isVisibleSearchbarCancel;
        public bool IsVisibleSearchbarCancelButton
        {
            get { return _isVisibleSearchbarCancel; }
            set { _isVisibleSearchbarCancel = value; OnPropertyChanged(); }
        }
        private bool _IsLableViewVisible;

        public bool IsLableViewVisible
        {
            get { return _IsLableViewVisible; }
            set { _IsLableViewVisible = value; OnPropertyChanged(); }
        }
        private bool _IsListView;

        public bool IsListView
        {
            get { return _IsListView; }
            set { _IsListView = value; OnPropertyChanged(); }
        }
        


        public bool _isEnabledSearchBar;

        public bool isEnabledSearchBar
        {
            set { _isEnabledSearchBar = value; OnPropertyChanged(); }
            get { return _isEnabledSearchBar; }
        }
        public Command OnSearchClearCommand => new Command(() =>
        {
            IsVisibleSearchbarCancelButton = false;
            SearchText = string.Empty;
            DynamicSearchPlaceholder();

        });
        private string _searchPlaceHolder;
        public string SearchPlaceHolderText
        {
            get { return _searchPlaceHolder; }
            set { _searchPlaceHolder = value; OnPropertyChanged(); }
        }
        private void DynamicSearchPlaceholder()
        {

            if (_fieldType == Constants.FieldType.CollegeName)
            {
                SearchPlaceHolderText = "Search CollegeName";
            }
            if (_fieldType == Constants.FieldType.Nationality)
            {
                SearchPlaceHolderText = "Search Nationality";
            }
            if (_fieldType == Constants.FieldType.BoardName)
            {
                SearchPlaceHolderText = "Search Board";
            }
            if (_fieldType == Constants.FieldType.State)
            {
                SearchPlaceHolderText = "Search State";
            }
            if (_fieldType == Constants.FieldType.City)
            {
                SearchPlaceHolderText = "Search District";
            }
            if (_fieldType == Constants.FieldType.University)
            {
                SearchPlaceHolderText = "Search University";
            }

            if (_fieldType == Constants.FieldType.College)
            {
                SearchPlaceHolderText = "Search College";
            }

            if (_fieldType == Constants.FieldType.CourseType)
            {
                SearchPlaceHolderText = "Search CourseType";
            }

            if (_fieldType == Constants.FieldType.Course)
            {
                SearchPlaceHolderText = "Search Course";
            }

            if (_fieldType == Constants.FieldType.Specialization)
            {
                SearchPlaceHolderText = "Search Specialization";
            }

            if (_fieldType == Constants.FieldType.Skill)
            {
                SearchPlaceHolderText = "Search Skill";
            }

            if (_fieldType == Constants.FieldType.YearOfCompletion)
            {
                SearchPlaceHolderText = "Search Year Of Completion";
            }
            if (_fieldType == Constants.FieldType.PreferredJobLocation)
            {
                SearchPlaceHolderText = "Search Job Location";
            }
            if (_fieldType == Constants.FieldType.SavedSearch)
            {
                SearchPlaceHolderText = "Search Name";
            }
            if (_fieldType == Constants.FieldType.WorkType)
            {
                SearchPlaceHolderText = "Work Type Name";
            }
        }

        public void SearchText_TextChanged()
        {
            var searchtext = SearchText;
            if (string.IsNullOrEmpty(searchtext))
            {
                IsVisibleSearchbarCancelButton = false;
                BindData();
                return;
            }

            if (_fieldType == Constants.FieldType.Nationality)
            {
                IsVisibleSearchbarCancelButton = true;
                var searchresults = GlobalCommonListItemSource.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
                ListViewItemSource = searchresults;
            }

            if (_fieldType == Constants.FieldType.CollegeName)
            {
                IsVisibleSearchbarCancelButton = true;
                var searchresults = GlobalCommonListItemSource.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
                ListViewItemSource = searchresults;
            }

            if (_fieldType == Constants.FieldType.State)
            {
                IsVisibleSearchbarCancelButton = true;
                var searchresults = GlobalCommonListItemSource.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
                ListViewItemSource = searchresults;
            }
            if (_fieldType == Constants.FieldType.City)
            {
                IsVisibleSearchbarCancelButton = true;
                var searchresults = GlobalCommonListItemSource.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
                ListViewItemSource = searchresults;
            }
            if (_fieldType == Constants.FieldType.University)
            {
                IsVisibleSearchbarCancelButton = true;
                var searchresults = GlobalCommonListItemSource.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
                ListViewItemSource = searchresults;
            }

            if (_fieldType == Constants.FieldType.College)
            {
                IsVisibleSearchbarCancelButton = true;
                var searchresults = GlobalCommonListItemSource.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
                ListViewItemSource = searchresults;
            }

            if (_fieldType == Constants.FieldType.CourseType)
            {
                IsVisibleSearchbarCancelButton = true;
                var searchresults = GlobalCommonListItemSource.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
                ListViewItemSource = searchresults;
            }

            if (_fieldType == Constants.FieldType.Course)
            {
                IsVisibleSearchbarCancelButton = true;
                var searchresults = GlobalCommonListItemSource.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
                ListViewItemSource = searchresults;
            }

            if (_fieldType == Constants.FieldType.Specialization)
            {
                IsVisibleSearchbarCancelButton = true;
                var searchresults = GlobalCommonListItemSource.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
                ListViewItemSource = searchresults;
            }

            if (_fieldType == Constants.FieldType.Skill)
            {
                IsVisibleSearchbarCancelButton = true;
                var searchresults = GlobalCommonListItemSource.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
                ListViewItemSource = searchresults;
            }
            if (_fieldType == Constants.FieldType.PreferredJobLocation)
            {
                IsVisibleSearchbarCancelButton = true;
                var searchresults = GlobalCommonListItemSource.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
                ListViewItemSource = searchresults;
            }
            if (_fieldType == Constants.FieldType.YearOfCompletion)
            {
                IsVisibleSearchbarCancelButton = true;
                var searchresults = GlobalCommonListItemSource.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
                ListViewItemSource = searchresults;
            }
            if (_fieldType == Constants.FieldType.BoardName)
            {
                IsVisibleSearchbarCancelButton = true;
                var searchresults = GlobalCommonListItemSource.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
                ListViewItemSource = searchresults;
            }
            if (_fieldType == Constants.FieldType.SavedSearch)
            {
                IsVisibleSearchbarCancelButton = true;
                var searchresults = GlobalCommonListItemSource.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
                ListViewItemSource = searchresults;
            }
            if (_fieldType == Constants.FieldType.WorkType)
            {
                IsVisibleSearchbarCancelButton = true;
                var searchresults = GlobalCommonListItemSource.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
                ListViewItemSource = searchresults;
            }
        }

        #endregion

        #region private methods
        /// <summary>
        /// Binds the data.
        /// </summary>
        public async void BindData()
        {
            try
            {
                Debug.WriteLine("@ DynamicListPage.BindData");
                this.Title = _fieldType;

                if (_fieldType == Constants.FieldType.CollegeName)
                {

                    UserDialogs.Instance.ShowLoading();
                    await BindCollegeNameData();
                    UserDialogs.Instance.HideLoading();
                }


                if (_fieldType == Constants.FieldType.State)
                {

                    UserDialogs.Instance.ShowLoading();
                    await BindStateData();
                    UserDialogs.Instance.HideLoading();
                }

                if (_fieldType == Constants.FieldType.City)
                {

                    UserDialogs.Instance.ShowLoading();
                    await BindDistrictData();
                    UserDialogs.Instance.HideLoading();
                }

                if (_fieldType == Constants.FieldType.University)
                {

                    UserDialogs.Instance.ShowLoading();
                    await BindUniversityData();
                    UserDialogs.Instance.HideLoading();
                }

                if (_fieldType == Constants.FieldType.College)
                {

                    UserDialogs.Instance.ShowLoading();
                    await BindCollegeData();
                    UserDialogs.Instance.HideLoading();
                }

                if (_fieldType == Constants.FieldType.CourseType)
                {

                    UserDialogs.Instance.ShowLoading();
                    await BindCourseTypeData();
                    UserDialogs.Instance.HideLoading();
                }


                if (_fieldType == Constants.FieldType.Course)
                {

                    UserDialogs.Instance.ShowLoading();
                    await BindCourseData();
                    UserDialogs.Instance.HideLoading();
                }

                if (_fieldType == Constants.FieldType.Specialization)
                {

                    UserDialogs.Instance.ShowLoading();
                    await BindSpecializationData();
                    UserDialogs.Instance.HideLoading();
                }

                if (_fieldType == Constants.FieldType.Skill || _fieldType == Constants.FieldType.PrimarySkill || _fieldType == Constants.FieldType.SecondarySkill)
                {

                    UserDialogs.Instance.ShowLoading();
                    await BindSkillData();
                    UserDialogs.Instance.HideLoading();
                }
                if (_fieldType == Constants.FieldType.PreferredJobLocation)
                {

                    UserDialogs.Instance.ShowLoading();
                    await BindPreferredJobLocation();
                    UserDialogs.Instance.HideLoading();
                }
                if (_fieldType == Constants.FieldType.BoardName)
                {

                    UserDialogs.Instance.ShowLoading();
                    await BindBoardName();
                    UserDialogs.Instance.HideLoading();
                }
                if (_fieldType == Constants.FieldType.BackLogs)
                {
                    UserDialogs.Instance.ShowLoading();
                    await BindBacklogsData();
                    UserDialogs.Instance.HideLoading();
                }

                if (_fieldType == Constants.FieldType.YearOfCompletion)
                {
                    UserDialogs.Instance.ShowLoading();
                    await BindCompletionYearData();
                    UserDialogs.Instance.HideLoading();

                }

                if (_fieldType == Constants.FieldType.Nationality)
                {

                    UserDialogs.Instance.ShowLoading();
                    await BindNationalityData();
                    UserDialogs.Instance.HideLoading();
                }

                if (_fieldType == Constants.FieldType.SavedSearch)
                {

                    UserDialogs.Instance.ShowLoading();
                    await BindSavedSearchData();
                    UserDialogs.Instance.HideLoading();
                }
                if (_fieldType == Constants.FieldType.WorkType)
                {

                    UserDialogs.Instance.ShowLoading();
                    await BindWorkTypeData();
                    UserDialogs.Instance.HideLoading();
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "DynamicListPageViewModel.BindData");
            }

        }

        private async Task BindWorkTypeData()
        {
            try
            {
                List<CommonListItemSource> objCommonListItemSource = new List<CommonListItemSource>();
                if (GlobalCommonListItemSource == null)
                {
                    WorkTypeRequest objWorkTypeRequest = new WorkTypeRequest();
                    var responseobj = await _commonservice.PostAsync<WorkTypeResponse, WorkTypeRequest>(APIData.API_BASE_URL + APIMethods.GetWorkType, objWorkTypeRequest);
                    stackSearchAddNewItem = false;
                    if (responseobj != null)
                    {
                        if (responseobj.Code == "200" && responseobj.EmployeeWorkTypeList != null)
                        {
                            foreach (var x in responseobj.EmployeeWorkTypeList)
                            {
                                CommonListItemSource testItemSource = new CommonListItemSource();
                                testItemSource.ID = x.id.ToString();
                                x.type_name.Trim();
                                testItemSource.Title = x.type_name;
                                objCommonListItemSource.Add(testItemSource);
                            }
                            GlobalCommonListItemSource = objCommonListItemSource;
                        }
                        UserDialogs.Instance.HideLoading();
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                isVisibleMessage = false;
                ListViewItemSource = GlobalCommonListItemSource;
                if ( GlobalCommonListItemSource!=null&& GlobalCommonListItemSource.Count > 0)
                {
                    isEnabledSearchBar = true;
                    IsLableViewVisible = false;
                    IsListView = true;
                }
                else
                {
                    IsLableViewVisible = true;
                    IsListView = false;
                    isEnabledSearchBar = false;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "DynamicListPageViewModel.BindWorkTypeData");
            }
        }

        private async Task BindSavedSearchData()
        {
            try
            {
                List<CommonListItemSource> objCommonListItemSource = new List<CommonListItemSource>();
                if (GlobalCommonListItemSource == null)
                {
                    SavedSearchRequest objSavedSearchRequest = new SavedSearchRequest();
                    objSavedSearchRequest.CandidateHiremeeID = AppSessionData.ActiveToken.HireMeID;
                    var responseobj = await _commonservice.PostAsync<SavedSearchJobResponse, SavedSearchRequest>(APIData.API_BASE_URL + APIMethods.GetSavedSearchjobs, objSavedSearchRequest);
                    stackSearchAddNewItem = false;
                    if (responseobj != null)
                    {
                        UserDialogs.Instance.HideLoading();
                        if (responseobj.Code == "200" && responseobj.SavedSearchJobs != null)
                        {
                            foreach (var x in responseobj.SavedSearchJobs)
                            {
                                CommonListItemSource testItemSource = new CommonListItemSource();
                                testItemSource.ID = x.id.ToString();
                                x.search_name.Trim();
                                testItemSource.Title = x.search_name;
                                objCommonListItemSource.Add(testItemSource);
                            }
                            GlobalCommonListItemSource = objCommonListItemSource;
                        }
                       
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }

                    isVisibleMessage = false;
                ListViewItemSource = GlobalCommonListItemSource;
                if ( GlobalCommonListItemSource!=null&& GlobalCommonListItemSource.Count > 0)
                {
                    isEnabledSearchBar = true;
                    IsLableViewVisible = false;
                    IsListView = true;
                }
                else
                {
                    IsLableViewVisible = true;
                    IsListView = false;
                    isEnabledSearchBar = false;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "DynamicListPageViewModel.BindSavedSearchData");
            }
        }



        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion



        private async Task BindBoardName()
        {
            try
            {
                Debug.WriteLine("@ DynamicListPage.BindBoardName");
                List<CommonListItemSource> objCommonListItemSource = new List<CommonListItemSource>();
                if (GlobalCommonListItemSource == null)
                {
                    var objRequestData = new BaseRequestDTO();
                    var responseobj = await _commonservice.PostAsync<BoardNameResponse, BaseRequestDTO>(APIData.API_BASE_URL + APIMethods.BoardNameList, objRequestData);
                    stackSearchAddNewItem = false;
                    if (responseobj != null)
                    {
                        if (responseobj.code == "200" && responseobj.response != null)
                        {
                            foreach (var x in responseobj.response)
                            {
                                CommonListItemSource testItemSource = new CommonListItemSource();
                                testItemSource.ID = x.id;
                                x.board_name.Trim();
                                testItemSource.Title = x.board_name;
                                objCommonListItemSource.Add(testItemSource);
                            }
                            GlobalCommonListItemSource = objCommonListItemSource;
                        }
                        UserDialogs.Instance.HideLoading();
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                isVisibleMessage = false;
                ListViewItemSource = GlobalCommonListItemSource;
                if ( GlobalCommonListItemSource!=null&& GlobalCommonListItemSource.Count > 0)
                {
                    isEnabledSearchBar = true;
                    IsLableViewVisible = false;
                    IsListView = true;
                }
                else
                {
                    IsLableViewVisible = true;
                    IsListView = false;
                    isEnabledSearchBar = false;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "DynamicListPageViewModel.BindBoardName");
            }
        }

        private async Task BindPreferredJobLocation()
        {
            try
            {
                Debug.WriteLine("@ DynamicListPage.BindPreferredLocation");
                List<CommonListItemSource> objCommonListItemSource = new List<CommonListItemSource>();
                if (GlobalCommonListItemSource == null)
                {
                    var objRequestData = new BaseRequestDTO();
                    var responseobj = await _commonservice.PostAsync<PreferredJobLocationResponse, BaseRequestDTO>(APIData.API_BASE_URL + APIMethods.PreferredJobLocation, objRequestData);
                    stackSearchAddNewItem = false;
                    if (responseobj != null)
                    {
                        if (responseobj.code == "200" && responseobj.response != null)
                        {
                            foreach (var x in responseobj.response)
                            {
                                CommonListItemSource testItemSource = new CommonListItemSource();
                                testItemSource.ID = x.id;
                                x.PreferredJobLocation.Trim();
                                testItemSource.Title = x.PreferredJobLocation;
                                objCommonListItemSource.Add(testItemSource);
                            }
                            GlobalCommonListItemSource = objCommonListItemSource;
                        }
                        UserDialogs.Instance.HideLoading();
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                isVisibleMessage = false;
                ListViewItemSource = GlobalCommonListItemSource;
                if ( GlobalCommonListItemSource!=null&& GlobalCommonListItemSource.Count > 0)
                {
                    isEnabledSearchBar = true;
                    IsLableViewVisible = false;
                    IsListView = true;
                }
                else
                {
                    IsLableViewVisible = true;
                    IsListView = false;
                    isEnabledSearchBar = false;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "DynamicListPageViewModel.BindPreferredJobLocation");
            }
        }

        private async Task BindNationalityData()
        {
            try
            {
                Debug.WriteLine("@ DynamicListPage.BindNationalityData");
                List<CommonListItemSource> objCommonListItemSource = new List<CommonListItemSource>();
                if (GlobalCommonListItemSource == null)
                {
                    var objRequestData = new BaseRequestDTO();
                    var responseobj = await _commonservice.PostAsync<NatioinalityResponse, BaseRequestDTO>(APIData.API_BASE_URL + APIMethods.BindCountryList, objRequestData);
                    stackSearchAddNewItem = false;
                    if (responseobj != null)
                    {
                        if (responseobj.code == "200" && responseobj.responseText != null)
                        {
                            foreach (var x in responseobj.responseText)
                            {
                                CommonListItemSource testItemSource = new CommonListItemSource();
                                testItemSource.ID = x.id;
                                x.country_name.Trim();
                                testItemSource.Title = x.country_name;
                                objCommonListItemSource.Add(testItemSource);
                            }
                            GlobalCommonListItemSource = objCommonListItemSource;
                        }
                        UserDialogs.Instance.HideLoading();
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                isVisibleMessage = false;
                ListViewItemSource = GlobalCommonListItemSource;
                if ( GlobalCommonListItemSource!=null&& GlobalCommonListItemSource.Count > 0)
                {
                    isEnabledSearchBar = true;
                    IsLableViewVisible = false;
                    IsListView = true;
                }
                else
                {
                    IsLableViewVisible = true;
                    IsListView = false;
                    isEnabledSearchBar = false;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "DynamicListPageViewModel.BindNationalityData");
            }
        }


        /// <summary>
        /// Binds the college name data.
        /// </summary>
        public async Task BindCollegeNameData()
        {
            try
            {
                Debug.WriteLine("@ DynamicListPage.BindCollegeNameData");
                List<CommonListItemSource> objCommonListItemSource = new List<CommonListItemSource>();
                if (GlobalCommonListItemSource == null)
                {
                    var objRequestData = new BaseRequestDTO();
                    var responseobj = await _commonservice.PostAsync<CollegeNameListFullResponseData, BaseRequestDTO>(APIData.API_BASE_URL + APIMethods.BindCollegeName, objRequestData);
                    stackSearchAddNewItem = false;
                    if (responseobj != null)
                    {
                        if (responseobj.code == "200" && responseobj.ResponseText != null)
                        {
                            foreach (var x in responseobj.ResponseText.ResponseData)
                            {
                                CommonListItemSource testItemSource = new CommonListItemSource();
                                testItemSource.ID = x.ID;
                                x.Title.Trim();
                                testItemSource.Title = x.Title;
                                objCommonListItemSource.Add(testItemSource);
                            }
                            GlobalCommonListItemSource = objCommonListItemSource;
                        }
                        UserDialogs.Instance.HideLoading();
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                isVisibleMessage = false;
                ListViewItemSource = GlobalCommonListItemSource;
                if ( GlobalCommonListItemSource!=null&& GlobalCommonListItemSource.Count > 0)
                {
                    isEnabledSearchBar = true;
                    IsListView = true;
                    IsLableViewVisible = false;
                }
                else
                {
                    IsLableViewVisible = true;
                    IsListView = false;
                    isEnabledSearchBar = false;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "DynamicListPageViewModel.BindCollegeNameData");
            }
        }

        /// <summary>
        /// Binds the university data.
        /// </summary>
        public async Task BindUniversityData()
        {
            try
            {
                System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindUniversityData");
                List<CommonListItemSource> objCommonListItemSource = new List<CommonListItemSource>();
                if (GlobalCommonListItemSource == null)
                {
                    isVisibleMessage = true;
                    MasterTableRequestData MasterTableRequestData = new MasterTableRequestData()
                    {
                        HiremeeID = AppSessionData.ActiveToken.HireMeID,
                        Token = AppSessionData.ActiveToken.Token,
                        TableName = "university"
                    };
                    var universities = await _commonservice.PostAsync<UniversityResponseData, MasterTableRequestData>(APIData.API_BASE_URL + APIMethods.MasterTables, MasterTableRequestData);
                    if (universities != null)
                    {
                        if (universities.code == "200" && universities.Response != null)
                        {
                            foreach (var x in universities.Response.Response)
                            {
                                testItemSource = new CommonListItemSource();
                                testItemSource.ID = x.ID;
                                testItemSource.Title = x.UniversityName;
                                objCommonListItemSource.Add(testItemSource);
                            }
                            GlobalCommonListItemSource = objCommonListItemSource;
                        }
                        UserDialogs.Instance.HideLoading();
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                isVisibleMessage = false;
                ListViewItemSource = GlobalCommonListItemSource;
                if ( GlobalCommonListItemSource!=null&& GlobalCommonListItemSource.Count > 0)
                {
                    isEnabledSearchBar = true;
                    IsLableViewVisible = false;
                    IsListView = true;
                }
                else
                {
                    IsLableViewVisible = true;
                    IsListView = false;
                    isEnabledSearchBar = false;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "DynamicListPageViewModel.BindUniversityData");
            }
        }

        /// <summary>
        /// Binds the college data.
        /// </summary>
        /// <returns>The college data.</returns>
        async Task BindCollegeData()
        {
            try
            {
                System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindCollegeData");
                List<CommonListItemSource> objCommonListItemSource = new List<CommonListItemSource>();
                if (GlobalCommonListItemSource == null)
                {
                    isVisibleMessage = true;
                    CollegeTableRequestData CollegeTableRequestData = new CollegeTableRequestData()
                    {
                        HiremeeID = AppSessionData.ActiveToken.HireMeID,
                        Token = AppSessionData.ActiveToken.Token,
                        UniversityID = _fieldValue
                    };
                    var colleges = await _commonservice.PostAsync<CollegeResponseData, CollegeTableRequestData>(APIData.API_BASE_URL + APIMethods.GetCollege, CollegeTableRequestData);
                    if (colleges != null)
                    {
                        if (colleges.code == "200" && colleges.Response != null)
                        {
                            foreach (var x in colleges.Response.Response)
                            {
                                testItemSource = new CommonListItemSource();
                                testItemSource.ID = x.ID;
                                testItemSource.Title = x.Title.Replace("\r\n", string.Empty);
                                objCommonListItemSource.Add(testItemSource);
                            }

                            GlobalCommonListItemSource = objCommonListItemSource;
                        }
                        UserDialogs.Instance.HideLoading();
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }


                }
                isVisibleMessage = false;
                ListViewItemSource = GlobalCommonListItemSource;
                if ( GlobalCommonListItemSource!=null&& GlobalCommonListItemSource.Count > 0)
                {
                    isEnabledSearchBar = true;
                    IsLableViewVisible = false;
                    IsListView = true;
                }
                else
                {
                    IsLableViewVisible = true;
                    IsListView = false;
                    isEnabledSearchBar = false;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "DynamicListPageViewModel.BindCollegeData");
            }
        }

        /// <summary>
        /// Binds the course type data.
        /// </summary>
        /// <returns>The course type data.</returns>
        async Task BindCourseTypeData()
        {
            try
            {
                System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindCourseTypeData");
                List<CommonListItemSource> objCommonListItemSource = new List<CommonListItemSource>();
                if (GlobalCommonListItemSource == null)
                {
                    isVisibleMessage = true;
                    MasterTableRequestData MasterTableRequestData = new MasterTableRequestData()
                    {
                        HiremeeID = AppSessionData.ActiveToken.HireMeID,
                        Token = AppSessionData.ActiveToken.Token,
                        TableName = "coursetype"
                    };
                    var coursetypes = await _commonservice.PostAsync<CourseTypeResponseData, MasterTableRequestData>(APIData.API_BASE_URL + APIMethods.MasterTables, MasterTableRequestData);
                    if (coursetypes != null)
                    {
                        if (coursetypes.code == "200" && coursetypes.Response != null)
                        {
                            foreach (var x in coursetypes.Response.Response)
                            {
                                testItemSource = new CommonListItemSource();
                                testItemSource.ID = x.ID;
                                testItemSource.Title = x.Title;
                                objCommonListItemSource.Add(testItemSource);
                            }
                            GlobalCommonListItemSource = objCommonListItemSource;
                        }
                        UserDialogs.Instance.HideLoading();
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }

                }
                isVisibleMessage = false;
                ListViewItemSource = GlobalCommonListItemSource;
                if ( GlobalCommonListItemSource!=null&& GlobalCommonListItemSource.Count > 0)
                {
                    isEnabledSearchBar = true;
                    IsLableViewVisible = false;
                    IsListView = true;
                }
                else
                {
                    IsLableViewVisible = true;
                    IsListView = false;
                    isEnabledSearchBar = false;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "DynamicListPageViewModel.BindCourseTypeData");
            }


        }

        /// <summary>
        /// Binds the course data.
        /// </summary>
        /// <returns>The course data.</returns>
        async Task BindCourseData()
        {
            try
            {
                System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindCourseData");

                List<CommonListItemSource> objCommonListItemSource = new List<CommonListItemSource>();
                if (GlobalCommonListItemSource == null)
                {
                    isVisibleMessage = true;
                    CourseRequestData CourseRequestData = new CourseRequestData()
                    {
                        HiremeeID = AppSessionData.ActiveToken.HireMeID,
                        Token = AppSessionData.ActiveToken.Token,
                        CourseTypeID = _fieldValue
                    };
                    var courses = await _commonservice.PostAsync<CourseResponseData, CourseRequestData>(APIData.API_BASE_URL + APIMethods.BindCourse, CourseRequestData);
                    if (courses != null)
                    {
                        if (courses.code == "200" && courses.Response != null)
                        {
                            foreach (var x in courses.Response.Response)
                            {
                                testItemSource = new CommonListItemSource();
                                testItemSource.ID = x.ID;
                                testItemSource.Title = x.Title;
                                objCommonListItemSource.Add(testItemSource);
                            }

                            GlobalCommonListItemSource = objCommonListItemSource;
                        }
                        UserDialogs.Instance.HideLoading();
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                isVisibleMessage = false;
                ListViewItemSource = GlobalCommonListItemSource;
                if ( GlobalCommonListItemSource!=null&& GlobalCommonListItemSource.Count > 0)
                {
                    isEnabledSearchBar = true;
                    IsLableViewVisible = false;
                    IsListView = true;
                }
                else
                {
                    IsLableViewVisible = true;
                    IsListView = false;
                    isEnabledSearchBar = false;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "DynamicListPageViewModel.BindCourseData");
            }


        }

        /// <summary>
        /// Binds the specialization data.
        /// </summary>
        /// <returns>The specialization data.</returns>
        async Task BindSpecializationData()
        {
            try
            {
                System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindSpecializationData");

                List<CommonListItemSource> objCommonListItemSource = new List<CommonListItemSource>();
                if (GlobalCommonListItemSource == null)
                {
                    isVisibleMessage = true;
                    SpecializationRequestData SpecializationRequestData = new SpecializationRequestData()
                    {
                        HiremeeID = AppSessionData.ActiveToken.HireMeID,
                        Token = AppSessionData.ActiveToken.Token,
                        CourseID = _fieldValue
                    };
                    var specializations = await _commonservice.PostAsync<SpecializationResponseData, SpecializationRequestData>(APIData.API_BASE_URL + APIMethods.Specialization, SpecializationRequestData);

                    if (specializations != null)
                    {
                        if (specializations.code == "200" && specializations.Response != null)
                        {
                            foreach (var x in specializations.Response.Response)
                            {
                                testItemSource = new CommonListItemSource();
                                testItemSource.ID = x.ID;
                                testItemSource.Title = x.Title;
                                objCommonListItemSource.Add(testItemSource);
                            }
                            GlobalCommonListItemSource = objCommonListItemSource;
                        }
                        UserDialogs.Instance.HideLoading();
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                isVisibleMessage = false;
                ListViewItemSource = GlobalCommonListItemSource;
                if ( GlobalCommonListItemSource!=null&& GlobalCommonListItemSource.Count > 0)
                {
                    isEnabledSearchBar = true;
                    IsLableViewVisible = false;
                    IsListView = true;
                }
                else
                {
                    IsLableViewVisible = true;
                    IsListView = false;
                    isEnabledSearchBar = false;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "DynamicListPageViewModel.BindSpecializationData");
            }

        }


        async Task BindSkillData()
        {
            try
            {
                System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindSkillData");

                List<CommonListItemSource> objCommonListItemSource = new List<CommonListItemSource>();
                if (GlobalCommonListItemSource == null)
                {
                    isVisibleMessage = true;
                    MasterTableRequestData MasterTableRequestData = new MasterTableRequestData()
                    {
                        HiremeeID = AppSessionData.ActiveToken.HireMeID,
                        Token = AppSessionData.ActiveToken.Token,
                        TableName = "skill"
                    };

                    var skills = await _commonservice.PostAsync<SkillResponseData, MasterTableRequestData>(APIData.API_BASE_URL + APIMethods.MasterTables, MasterTableRequestData);
                    if (skills != null)
                    {
                        if (skills.code == "200" && skills.Response != null)
                        {
                            IsLableViewVisible = false;
                            foreach (var x in skills.Response.Response)
                            {
                                testItemSource = new CommonListItemSource();
                                testItemSource.ID = x.ID;
                                testItemSource.Title = x.SkillName;
                                objCommonListItemSource.Add(testItemSource);
                            }

                            GlobalCommonListItemSource = objCommonListItemSource;
                        }
                        UserDialogs.Instance.HideLoading();
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }

                }
                isVisibleMessage = false;
                ListViewItemSource = GlobalCommonListItemSource;


                if ( GlobalCommonListItemSource!=null&& GlobalCommonListItemSource.Count > 0)
                {
                    isEnabledSearchBar = true;
                    IsLableViewVisible = false;
                    IsListView = true;
                }
                else
                {
                    IsLableViewVisible = true;
                    IsListView = false;
                    isEnabledSearchBar = false;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "DynamicListPageViewModel.BindSkillData");
            }
        }

        /// <summary>
        /// Binds the district data.
        /// </summary>
        /// <returns>The district data.</returns>
        async Task BindDistrictData()
        {
            try
            {
                System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindDistrictData");

                List<CommonListItemSource> objCommonListItemSource = new List<CommonListItemSource>();
                if (GlobalCommonListItemSource == null)
                {
                    isVisibleMessage = true;
                    DistrictRequestData DistrictRequestData = new DistrictRequestData()
                    {
                        HiremeeID = AppSessionData.ActiveToken.HireMeID,
                        Token = AppSessionData.ActiveToken.Token,
                        StateID = _fieldValue
                    };
                    var districts = await _commonservice.PostAsync<DistrictResponseData, DistrictRequestData>(APIData.API_BASE_URL + APIMethods.BindDistrict, DistrictRequestData);
                    if (districts != null)
                    {
                        if (districts.code == "200" && districts.Response != null)
                        {
                            foreach (var x in districts.Response.Response)
                            {
                                testItemSource = new CommonListItemSource();
                                testItemSource.ID = x.ID;
                                testItemSource.Title = x.Title;
                                objCommonListItemSource.Add(testItemSource);
                            }

                            GlobalCommonListItemSource = objCommonListItemSource;
                        }
                        UserDialogs.Instance.HideLoading();
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }

                }
                isVisibleMessage = false;
                ListViewItemSource = GlobalCommonListItemSource;
                _cityList = objCommonListItemSource;

                if ( GlobalCommonListItemSource!=null&& GlobalCommonListItemSource.Count > 0)
                {
                    isEnabledSearchBar = true;
                    IsLableViewVisible = false;
                    IsListView = true;
                }
                else
                {
                    IsLableViewVisible = true;
                    IsListView = false;
                    isEnabledSearchBar = false;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "DynamicListPageViewModel.BindDistrictData");
            }

        }

        /// <summary>
        /// Binds the state data.
        /// </summary>
        /// <returns>The state data.</returns>
        async Task BindStateData()
        {
            try
            {
                List<CommonListItemSource> objCommonListItemSource = new List<CommonListItemSource>();
                if (GlobalCommonListItemSource == null)
                {
                    isVisibleMessage = true;
                    System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindStateData");
                    MasterTableRequestData MasterTableRequestData = new MasterTableRequestData()
                    {
                        HiremeeID = AppSessionData.ActiveToken.HireMeID,
                        Token = AppSessionData.ActiveToken.Token,
                        TableName = "state"
                    };
                    var states = await _commonservice.PostAsync<StateResponseData, MasterTableRequestData>(APIData.API_BASE_URL + APIMethods.MasterTables, MasterTableRequestData);
                    if (states != null)
                    {
                        if (states.code == "200" && states.Response != null)
                            foreach (var x in states.Response.Response)
                            {
                                testItemSource = new CommonListItemSource();
                                testItemSource.ID = x.ID;
                                testItemSource.Title = x.Title;
                                objCommonListItemSource.Add(testItemSource);
                            }

                        GlobalCommonListItemSource = objCommonListItemSource;
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                isVisibleMessage = false;
                ListViewItemSource = GlobalCommonListItemSource;

                if ( GlobalCommonListItemSource!=null&& GlobalCommonListItemSource.Count > 0)
                {
                    isEnabledSearchBar = true;
                    IsLableViewVisible = false;
                    IsListView = true;
                }
                else
                {
                    IsLableViewVisible = true;
                    IsListView = false;
                    isEnabledSearchBar = false;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "DynamicListPageViewModel.BindStateData");
            }
        }

        /// <summary>
        /// Binds the backlogs data.
        /// </summary>
        private async Task BindBacklogsData()
        {
            try
            {
                System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindBacklogsData");
                List<CommonListItemSource> objCommonListItemSource = new List<CommonListItemSource>();

                if (GlobalCommonListItemSource == null)
                {
                    List<Backlog> backlogs = new List<Backlog>();
                    isVisibleMessage = true;
                    for (int a = 0; a < 10; a++)
                    {
                        backlogs.Add(new Backlog { BacklogID = a.ToString(), Title = a.ToString() });
                        testItemSource = new CommonListItemSource();
                        testItemSource.ID = a.ToString();
                        testItemSource.Title = a.ToString();
                        objCommonListItemSource.Add(testItemSource);
                    }
                    GlobalCommonListItemSource = objCommonListItemSource;

                }

                isVisibleMessage = false;
                ListViewItemSource = GlobalCommonListItemSource;
                if ( GlobalCommonListItemSource!=null&& GlobalCommonListItemSource.Count > 0)
                {
                    isEnabledSearchBar = true;
                    IsLableViewVisible = false;
                    IsListView = true;
                }
                else
                {
                    IsLableViewVisible = true;
                    IsListView = false;
                    isEnabledSearchBar = false;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "DynamicListPageViewModel.BindBacklogsData");
            }
        }

        /// <summary>
        /// Binds the completion year data.
        /// </summary>
        private async Task BindCompletionYearData()
        {
            System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindCompletionYearData");
            isEnabledSearchBar = true;

            List<CommonListItemSource> objCommonListItemSource = new List<CommonListItemSource>();


            if (GlobalCommonListItemSource == null)
            {

                int currentYear = DateTime.Now.Year;

                List<Year> yearlist = new List<Year>();
                isVisibleMessage = true;

                {
                    try
                    {
                        //   UserDialogs.Instance.ShowLoading("Loading Year of Completion...");
                        UserDialogs.Instance.ShowLoading();
                        var requestdata = new MasterTableRequestData()
                        {
                            HiremeeID = AppSessionData.ActiveToken.HireMeID,
                            Token = AppSessionData.ActiveToken.Token,
                            TableName = "yearofcompletion"
                        };
                        var responseobj = await _commonservice.PostAsync<YearOfCompletionResponse, MasterTableRequestData>(APIData.API_BASE_URL + APIMethods.MasterTables, requestdata);
                        if (responseobj != null)
                        {
                            if (responseobj.code == "200" && responseobj.responseText.yearofcompletion != null)
                            {
                                foreach (var item in responseobj.responseText.yearofcompletion)
                                {
                                    testItemSource = new CommonListItemSource();
                                    testItemSource.ID = item.id.ToString();
                                    testItemSource.Title = item.name;
                                    objCommonListItemSource.Add(testItemSource);
                                }
                                GlobalCommonListItemSource = objCommonListItemSource;
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(responseobj.message);
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine(ex.Message);
                        UserDialogs.Instance.HideLoading();
                        SendErrorMessageToServer(ex, "DynamicListPageViewModel.BindCompletionYearData");
                    }
                    UserDialogs.Instance.HideLoading();
                    //_yearList = new ObservableCollection<Year>(yearlist);
                    isVisibleMessage = false;
                    GlobalCommonListItemSource = objCommonListItemSource;
                    if ( GlobalCommonListItemSource!=null&& GlobalCommonListItemSource.Count > 0)
                    {
                        isEnabledSearchBar = true;
                        IsLableViewVisible = false;
                        IsListView = true;
                    }
                    else
                    {
                        IsLableViewVisible = true;
                        IsListView = false;
                        isEnabledSearchBar = false;
                    }
                }
            }
            ListViewItemSource = GlobalCommonListItemSource;
        }
        #endregion




        #region event handlers
        /// <summary>
        /// Dynamics the list view item tapped.
        /// </summary>
        /// <param name="sender">Sender.</param>
        /// <param name="e">E.</param>



        public ICommand SelectedCommand => new Command(() =>
        {

            try
            {
                System.Diagnostics.Debug.WriteLine("@ DynamicListPage.DynamicListView_ItemTapped");
                //if (_valueGetterInterface != null)
                //{
                //	_valueGetterInterface.SetFieldValue(_fieldType, ListViewSelectedItem);

                //}
                if (PageName == "SeekerPersonalandEducational")
                {
                    ListViewSelectedItem.fieldType = _fieldType;
                    MessagingCenter.Send<DynamicListPageViewModel, CommonListItemSource>(this, "SeekerPersonalandEducational", ListViewSelectedItem);

                }
                else if (PageName == "RecruiterSearchVideoProfile")
                {
                    ListViewSelectedItem.fieldType = _fieldType;
                    MessagingCenter.Send<DynamicListPageViewModel, CommonListItemSource>(this, "RecruiterSearchVideoProfile", ListViewSelectedItem);
                }
                else if (PageName == "RecruiterProfile")
                {
                    ListViewSelectedItem.fieldType = _fieldType;
                    MessagingCenter.Send<DynamicListPageViewModel, CommonListItemSource>(this, "RecruiterProfile", ListViewSelectedItem);
                }
                else if (PageName == "SearchJobsViewModel")
                {
                    if (_fieldType == Constants.FieldType.PreferredJobLocation)
                    {
                        ListViewSelectedItem.fieldType = _fieldType;
                        MessagingCenter.Send<DynamicListPageViewModel, CommonListItemSource>(this, "LocationForFilterJobs", ListViewSelectedItem);
                    }
                    if (_fieldType == Constants.FieldType.SavedSearch)
                    {
                        ListViewSelectedItem.fieldType = _fieldType;
                        MessagingCenter.Send<DynamicListPageViewModel, CommonListItemSource>(this, "SavedSearchJobs", ListViewSelectedItem);
                    }
                    if (_fieldType == Constants.FieldType.WorkType)
                    {
                        ListViewSelectedItem.fieldType = _fieldType;
                        MessagingCenter.Send<DynamicListPageViewModel, CommonListItemSource>(this, "Worktype", ListViewSelectedItem);
                    }
                    if (_fieldType == Constants.FieldType.Skill)
                    {
                        ListViewSelectedItem.fieldType = _fieldType;
                        MessagingCenter.Send<DynamicListPageViewModel, CommonListItemSource>(this, "SkillForFilterJobs", ListViewSelectedItem);
                    }
                }

                Navigation.PopAsync();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "DynamicListPageViewModel.SelectedCommand");
            }
        });

        #endregion


        public Command AddButtonclickedCommand
        {
            get;
            set;
        }

        #region AddButtonclicked
        async public void AddButtonclicked()
        {

        }
        #endregion



        //Binding State,City,University,YearofCompletion,Colleges list using following Same Class 

    }

}

