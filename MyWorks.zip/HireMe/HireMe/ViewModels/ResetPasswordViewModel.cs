﻿using GalaSoft.MvvmLight.Command;
using System;
using System.Windows.Input;
using Plugin.Connectivity;
using Acr.UserDialogs;
using Xamarin.Forms;
using MvvmHelpers;
using HireMe.Models;
using System.Threading.Tasks;
using System.Diagnostics;
using HireMe.Helpers;

namespace HireMe.ViewModels
{
    public class ResetPasswordViewModel : BaseViewModel
    {
        private HttpCommonService _commonservice { get; set; }
        public ICommand ResetServiceCommand { get; set; }
        public ResetPasswordRequestData ResetPasswordRequestData { get; set; }
        public ResetPasswordResponseData ResetPasswordResponseData { get; set; }
        public string ErrorMessage { get; set; }
        INavigation Navigation;
        public ResetPasswordViewModel(INavigation nav)
        {
            AppPreferences.Is_HireMee_PRO_User = false;
            _commonservice = new HttpCommonService();
            Navigation = nav;
            ResetServiceCommand = new RelayCommand<string>(DoReset);
            ResetPasswordRequestData = new ResetPasswordRequestData();
            ResetPasswordResponseData = new ResetPasswordResponseData();

            #region FontAwesomeFont Initial Binding
            IsPasswordvisible = true;
            IsConfirmPasswordvisible = true;
            IsPassword = true;
            IsConfirmPassword = true;
            PasswordVisibility = (string)Application.Current.Resources["HidePassword"]; ;
            ConfirmPasswordVisibility = (string)Application.Current.Resources["HidePassword"];
            #endregion

        }

        #region private property


        private string _rightsign;
        public string RightSign
        {
            get { return _rightsign; }
            set { _rightsign = value; OnPropertyChanged(); }
        }
        private string _password;
        public string Password
        {
            get { return _password; }
            set { _password = value; OnPropertyChanged(); }
        }
        private string _confirmpassword;
        public string ConfirmPassword
        {
            get { return _confirmpassword; }
            set { _confirmpassword = value; OnPropertyChanged(); }
        }
        private string _passwordvisibility;
        public string PasswordVisibility
        {
            get { return _passwordvisibility; }
            set { _passwordvisibility = value; OnPropertyChanged(); }
        }


        private string _confirmPasswordVisibility;
        public string ConfirmPasswordVisibility
        {
            get { return _confirmPasswordVisibility; }
            set { _confirmPasswordVisibility = value; OnPropertyChanged(); }
        }


        private bool _ispasswordvisible;
        public bool IsPasswordvisible
        {
            get { return _ispasswordvisible; }
            set { _ispasswordvisible = value; OnPropertyChanged(); }
        }

        private bool _isconfirmpasswrodvisible;
        public bool IsConfirmPasswordvisible
        {
            get { return _isconfirmpasswrodvisible; }
            set { _isconfirmpasswrodvisible = value; OnPropertyChanged(); }
        }


        private bool _ispasswordhelptext;
        public bool ISPasswordHelpText
        {
            get { return _ispasswordhelptext; }
            set { _ispasswordhelptext = value; OnPropertyChanged(); }
        }

        private bool _ispassword;
        public bool IsPassword
        {
            get { return _ispassword; }
            set { _ispassword = value; OnPropertyChanged(); }
        }
        private bool _isconfirmpassword;
        public bool IsConfirmPassword
        {
            get { return _isconfirmpassword; }
            set { _isconfirmpassword = value; OnPropertyChanged(); }
        }
        #region Signtext Color properites

        private Color _passwordtextcolor;
        public Color PasswordTextcolor
        {
            get { return _passwordtextcolor; }
            set { _passwordtextcolor = value; OnPropertyChanged(); }
        }
        private Color _confirmpasswrodtextcolor;
        public Color ConfirmPasswordTextcolor
        {
            get { return _confirmpasswrodtextcolor; }
            set { _confirmpasswrodtextcolor = value; OnPropertyChanged(); }
        }


        #endregion




        #endregion

        private Command<string> tapCommand;
        public Command<string> TapCommand
        {
            get { return tapCommand ?? (tapCommand = new Command<string>(async arg => await OnTappedCommand(arg))); }
        }

        private async Task OnTappedCommand(string sender)
        {
            switch (sender)
            {

                case "PasswordSign":
                    var textPasswordSign = ResetPasswordRequestData.NewPassword;
                    if (textPasswordSign != null) textPasswordSign = textPasswordSign.Trim();
                    if (string.IsNullOrEmpty(textPasswordSign))
                    {
                        Password = (string)Application.Current.Resources["WrongSign"];
                        IsPasswordvisible = true;
                        PasswordTextcolor = Color.Red;
                    }
                    else
                    {
                      //  if (!FieldsValidation.IsValidPassword(textPasswordSign))
                        //{
                        //    Password = (string)Application.Current.Resources["WrongSign"];
                        //    IsPasswordvisible = true;
                        //    PasswordTextcolor = Color.Red;
                        //    ISPasswordHelpText = true;
                        //}
                        //else 
                        if (!string.IsNullOrEmpty(ResetPasswordRequestData.ConfirmPassword))
                        {
                            if (ResetPasswordRequestData.NewPassword != ResetPasswordRequestData.ConfirmPassword)
                            {
                                Password = (string)Application.Current.Resources["WrongSign"];
                                IsPasswordvisible = true;
                                PasswordTextcolor = Color.Red;
                                ISPasswordHelpText = false;
                            }
                            else
                            {
                                Password = (string)Application.Current.Resources["RightSign"];
                                ConfirmPassword = (string)Application.Current.Resources["RightSign"];
                                ConfirmPasswordTextcolor = Color.Green;
                                IsPasswordvisible = true;
                                PasswordTextcolor = Color.Green;
                                ISPasswordHelpText = false;
                            }
                        }
                        else
                        {
                            Password = (string)Application.Current.Resources["RightSign"];
                            IsPasswordvisible = true;
                            PasswordTextcolor = Color.Green;
                            ISPasswordHelpText = false;
                        }
                    }
                    break;

                case "ConfirmPasswordSign":
                    var textConfirmPasswordSign = ResetPasswordRequestData.ConfirmPassword;
                    if (textConfirmPasswordSign != null) textConfirmPasswordSign = textConfirmPasswordSign.Trim();
                    if (string.IsNullOrEmpty(textConfirmPasswordSign))
                    {
                        ConfirmPassword = (string)Application.Current.Resources["WrongSign"];
                        IsConfirmPasswordvisible = true;
                        ConfirmPasswordTextcolor = Color.Red;
                    }
                    else
                    {
                        //if (!FieldsValidation.IsValidPassword(textConfirmPasswordSign))
                        //{
                        //    ConfirmPassword = (string)Application.Current.Resources["WrongSign"];
                        //    IsConfirmPasswordvisible = true;
                        //    ConfirmPasswordTextcolor = Color.Red;
                        //    ISPasswordHelpText = true;
                        //}
                      //  else
                        if (ResetPasswordRequestData.NewPassword != ResetPasswordRequestData.ConfirmPassword)
                        {
                            ConfirmPassword = (string)Application.Current.Resources["WrongSign"];
                            IsConfirmPasswordvisible = true;
                            ConfirmPasswordTextcolor = Color.Red;
                            ISPasswordHelpText = false;
                        }
                        else
                        {
                            ConfirmPassword = (string)Application.Current.Resources["RightSign"];
                            Password = (string)Application.Current.Resources["RightSign"];
                            PasswordTextcolor = Color.Green;
                            IsConfirmPasswordvisible = true;
                            ConfirmPasswordTextcolor = Color.Green;
                            ISPasswordHelpText = false;
                        }
                    }
                    break;

            }
        }

        #region VladidateFields
        private bool IsValidData()
        {
            ErrorMessage = string.Empty;
            bool isvalid = false;
            if (String.IsNullOrEmpty(ResetPasswordRequestData.NewPassword))
            {
                ErrorMessage = MessageStringConstants.WeakPassword;
                return isvalid;
            }
            if (String.IsNullOrEmpty(ResetPasswordRequestData.ConfirmPassword))
            {
                ErrorMessage = MessageStringConstants.WeakPassword;
                return isvalid;
            }
            if(ResetPasswordRequestData.NewPassword.Length < 6)
            {
                ErrorMessage = MessageStringConstants.WeakPassword;
                return isvalid;
            }

            //if (!FieldsValidation.IsValidPassword(ResetPasswordRequestData.password))
            //{
            //    ErrorMessage = MessageStringConstants.WeakPassword;
            //    return isvalid;
            //}
            if (ResetPasswordRequestData.NewPassword != ResetPasswordRequestData.ConfirmPassword)
            {
                ErrorMessage = MessageStringConstants.PasswordMismatched;
                return isvalid;
            }

           
            isvalid = true;
            if (string.IsNullOrEmpty(AppPreferences.ForgotPasswordNewValues.register_id))
            {
                ResetPasswordRequestData.register_id = "0";
            }
            else
            {
                ResetPasswordRequestData.register_id = AppPreferences.ForgotPasswordNewValues.register_id;
            }
            //if (isvalid)
            //{
            //    ResetPasswordRequestData.password = ResetPasswordRequestData.password;
            //    //if (!string.IsNullOrEmpty(AppSessionData.ActiveToken.EmailID))
            //    //    ResetPasswordRequestData.email_address = AppSessionData.ActiveToken.EmailID;
            //    //if (AppSessionData.ActiveToken.EmailID == null)
            //    ResetPasswordRequestData.email_address = AppPreferences.EmailAddress;

            //}
            return isvalid;
        }
        #endregion


        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion


        public async void DoReset(string sender)
        {
            switch (sender)
            {

                case "reset":

                    if (!IsValidData())
                    {
                        if (!string.IsNullOrEmpty(ErrorMessage))
                        {
                            await UserDialogs.Instance.AlertAsync(ErrorMessage);
                            return;
                        }
                    }
                    else
                    {
                        try
                        {
                            UserDialogs.Instance.ShowLoading();
                            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                            if (isNetworkAvailable)
                            {
                                ResetPasswordRequestData.email_address = AppPreferences.ForgotPasswordEmailAddress;
                                var result = await _commonservice.PostAsync<ResetPasswordResponseData, ResetPasswordRequestData>(APIData.API_BASE_URL + APIMethods.ResetPassword, ResetPasswordRequestData);
                                if (result != null)
                                {
                                    if (result.Code == "200")
                                    {
                                        UserDialogs.Instance.HideLoading();
                                        await UserDialogs.Instance.AlertAsync(result.Message);
                                        AppPreferences.IsPasswordReset = false;
                                        Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                                        return;
                                    }
                                    else
                                    {
                                        UserDialogs.Instance.HideLoading();
                                        await UserDialogs.Instance.AlertAsync(result.Message);
                                    }
                                }
                                else
                                {
                                    UserDialogs.Instance.HideLoading();
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                                    Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                                    return;
                                }
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);

                            }
                        }
                        catch (Exception ex)
                        {
                            Debug.WriteLine(ex.Message);
                            SendErrorMessageToServer(ex, "ResetPasswordViewModel.DoReset.reset");
                        }
                    }
                    break;
                case "tappassword":
                    if (IsPassword == true)
                    {
                        PasswordVisibility = (string)Application.Current.Resources["ShowPassword"];
                        IsPassword = false;
                    }
                    else
                    {
                        PasswordVisibility = (string)Application.Current.Resources["HidePassword"];
                        IsPassword = true;
                    }
                    break;
                case "tapconfirmpassword":
                    if (IsConfirmPassword == true)
                    {
                        ConfirmPasswordVisibility = (string)Application.Current.Resources["ShowPassword"];
                        IsConfirmPassword = false;
                    }
                    else
                    {
                        ConfirmPasswordVisibility = (string)Application.Current.Resources["HidePassword"];
                        IsConfirmPassword = true;
                    }
                    break;
                case "login":
                    AppPreferences.IsPasswordReset = false;
                    Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                    // await Navigation.PushAsync(new LoginPageNew());
                    break;

            }
        }


    }
}
