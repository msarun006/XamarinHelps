﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using HireMe.Helpers;
using HireMe.Models;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels
{
    public class SettingsPageViewModel : BaseViewModel
    {
        #region Initial Declaration
        public FirebaseMessagingRequestData fireBaseRequest { get; set; }
        public FirebaseMessagingUnRegisterRequestData firebaseUnRegisterRequest { get; set; }
        public HttpCommonService _commonservice { get; set; }
        public ICommand OnSettingsCommand { get; set; }
        INavigation NavigationService;
        public bool _isLocked = true;
        public bool _initial = true;
        public bool isToggled = false;
        public bool isClicked = true;
        private bool _isNotification = false;

        public FCMHelper _FCMHelper { get; set; }
        #endregion

        #region Main Contructor
        public SettingsPageViewModel(INavigation objNav)
        {
            #region Initialization
            NavigationService = objNav;
            _FCMHelper = new FCMHelper();
            fireBaseRequest = new FirebaseMessagingRequestData();
            firebaseUnRegisterRequest = new FirebaseMessagingUnRegisterRequestData();
            _commonservice = new HttpCommonService();
            #endregion
            OnSettingsCommand = new RelayCommand<string>(OnSettings);
			_isNotification = !AppPreferences.IsNotificationEnabled;
            #region Initialize Toggle Event
            IsToggleSwitchNotification = AppPreferences.IsNotificationEnabled;
            #endregion
        }
        #endregion

        #region Toggle Event
        private Command<string> tapCommand;
        public Command<string> TapCommand
        {
            get { return tapCommand ?? (tapCommand = new Command<string>(async arg => await OnTappedCommand(arg))); }
        }

        public async Task OnTappedCommand(string sender)
        {
            switch (sender)
            {
                #region Toggle Event
                case "ToggleSwitchNotification":
                    try
                    {
                        bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                        if (isNetworkAvailable)
                        {

                            #region Manually Toggle The Switch
                            if (_isNotification)
                            {
                                if (IsToggleSwitchNotification == true)
                                {
                                    UserDialogs.Instance.ShowLoading();
                                    await _FCMHelper.RegisterFirebaseToken();
                                    UserDialogs.Instance.HideLoading();
                                }
                                else if (IsToggleSwitchNotification == false)
                                {
                                    UserDialogs.Instance.ShowLoading();
                                    await _FCMHelper.UnRegisterFirebaseToken();
                                    UserDialogs.Instance.HideLoading();
                                }
                            }
                            else
                            { _isNotification = true; }
                            #endregion
                        }
                        else
                        {
                            if (AppPreferences.IsNotificationEnabled == true)
                            {
                                IsToggleSwitchNotification = true;
                                UserDialogs.Instance.Toast("Check Internet Connection");
                            }
                            else
                            {
                                IsToggleSwitchNotification = false;
                                UserDialogs.Instance.Toast("Check Internet Connection");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        UserDialogs.Instance.HideLoading();
                        Debug.WriteLine(ex.Message);
                        SendErrorMessageToServer(ex, "SettingPageViewModel.OnTappedCommand.ToggleSwitchNotification");
                    }
                    break;
                case "ToggleSwitchPasscode":
                    //if (IsToggleSwitchPasscode == false || AppPreferences.IsPasscodeValue == string.Empty)
                    //{

                    //    await NavigationService.PushModalAsync(new AppLock("Set Passcode"));
                    //    IsVisibleChangePaascode = false;
                    //}
                    //else
                    //{
                    //    await NavigationService.PushModalAsync(new AppLock("Remove Passcode"));
                    //    IsVisibleChangePaascode = true;
                    //}


                    if (!_initial)
                    {
                        isToggled = !isToggled;
                        if (_isLocked)
                        {
                            _isLocked = false;

                            if (isToggled || AppPreferences.IsPasscodeValue == string.Empty)
                            {
                                // switchPasscode.IsToggled = e.Value;
                                await NavigationService.PushModalAsync(new AppLock("Set Passcode"));
                                //PopupNavigation.PushAsync(new LockScreen("Set Passcode"));
                            }
                            else if (AppPreferences.IsPasscodeValue != string.Empty)
                            {
                                // switchPasscode.IsToggled = e.Value;
                                await NavigationService.PushModalAsync(new AppLock("Remove Passcode"));
                                // PopupNavigation.PushAsync(new LockScreen("Remove Passcode"));
                            }
                        }
                    }
                    else
                    {
                        _initial = false;
                        IsToggleSwitchPasscode = AppPreferences.IsPasscode;
                    }
                    break;
            }
            #endregion
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        #region OnSettingsPage Command
        private async void OnSettings(string sender)
        {
            switch (sender)
            {

                case "OnTapChangePassword":
                    #region Tap the ChangePassword

                    if (isClicked)
                    {
                        isClicked = false;
                        await NavigationService.PushAsync(new SeekerChangePassword());
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    #endregion
                    break;

                case "OnTapChangePassCode":
                    #region Tap the ChangePassCode
                    if (isClicked)
                    {
                        isClicked = false;
                        if (AppPreferences.IsPasscode)
                        {
                            isClicked = false;
                            await NavigationService.PushModalAsync(new AppLock("Change Passcode"));
                        }
                        else
                        {
                            isClicked = false;
                            await NavigationService.PushModalAsync(new AppLock("Set Passcode"));
                        }

                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    #endregion
                    break;

            }
        }
        #endregion

        #region Binding Properties

        private bool _isEnableSwitchNotification;
        public bool IsEnableSwitchNotification
        {
            get { return _isEnableSwitchNotification; }
            set { _isEnableSwitchNotification = value; OnPropertyChanged(); }
        }
        private bool _isToggleSwitchNotification;
        public bool IsToggleSwitchNotification
        {
            get { return _isToggleSwitchNotification; }
            set { _isToggleSwitchNotification = value; OnPropertyChanged(); }
        }
        private bool _isToggleSwitchPasscode;
        public bool IsToggleSwitchPasscode
        {
            get { return _isToggleSwitchPasscode; }
            set { _isToggleSwitchPasscode = value; OnPropertyChanged(); }
        }
        private bool _isVisibleChangePaascode;
        public bool IsVisibleChangePaascode
        {
            get { return _isVisibleChangePaascode; }
            set { _isVisibleChangePaascode = value; OnPropertyChanged("IsVisibleChangePaascode"); }
        }

        #endregion
    }
}
