﻿using HireMe.ViewModels.JobSeeker;
using Plugin.Media.Abstractions;
using Rg.Plugins.Popup.Services;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels
{
    public class ActionSheetPageViewModel
    {
        ChangeProfilePictrurePageViewModel _ChangeProfileVm { get; set; }

        SeekerPersonalAndEducationViewModel _seekerPersonal { get; set; }

        MediaFile UpdatablePicture = null;

        INavigation NavigationService;
        public ICommand OnCommand { get; set; }


        public ActionSheetPageViewModel(INavigation OBJnav, string pageName)
        {
            _ChangeProfileVm = new ChangeProfilePictrurePageViewModel(OBJnav);


            //Need to change some other ideas
            StackLayout dynamicButtonGrid = new StackLayout();

            _seekerPersonal = new SeekerPersonalAndEducationViewModel(OBJnav, dynamicButtonGrid, null, null, null, null,null,null);
            NavigationService = OBJnav;
            if (pageName == MessageStringConstants.SeekerPersonalPageName)
            {
                OnCommand = new Command(DoSelect);
            }
            else if (pageName == MessageStringConstants.ChangeProfilePageName)
            {
                OnCommand = new Command(DoAction);
            }


        }


        public string _actionstring;
        private async void DoSelect(object sender)
        {
            if (sender.ToString() == "tpgGallery")
            {
                _actionstring = "Pick from Gallery";
                _seekerPersonal.UploadProfilePicture(_actionstring);
                await PopupNavigation.PopAsync();
            }
            else if (sender.ToString() == "tpgCamera")
            {
                _actionstring = "Camera";
                _ChangeProfileVm.UploadProfilePicture(_actionstring);
                await PopupNavigation.PopAsync();
            }
            else if (sender.ToString() == "tpgCancel")
            {
                await PopupNavigation.PopAsync();
            }


        }



        public string _action;
        private async void DoAction(object sender)
        {
            if (sender.ToString() == "tpgGallery")
            {
                _action = "Pick from Gallery";
                _ChangeProfileVm.UploadProfilePicture(_action);
                await PopupNavigation.PopAsync();
            }
            else if (sender.ToString() == "tpgCamera")
            {
                _action = "Camera";
                _ChangeProfileVm.UploadProfilePicture(_action);
                await PopupNavigation.PopAsync();
            }
            else if (sender.ToString() == "tpgCancel")
            {
                await PopupNavigation.PopAsync();
            }


        }
    }
}
