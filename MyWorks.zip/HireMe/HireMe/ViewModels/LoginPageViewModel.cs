﻿using Acr.UserDialogs;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Threading.Tasks;
using Xamarin.Forms;
using System.Windows.Input;
using HireMe.Helpers;
using HireMe.Models;
using System.Diagnostics;
using HireMe.Views;
using HireMe.LocalDataBase;
using HireMe.Views.Assessment;
using HireMe.Services.SocialAuthentication;
using HireMe.Views.PRO_Assessment;
using HireMe.Interface;

namespace HireMe.ViewModels
{
    public class LoginPageViewModel : BaseViewModel
    {
        #region Initial Declarations
        INavigation _navigation;

        private HttpCommonService _commonservice { get; set; }
        public LoginRequestData LoginRequestData { get; set; }
        public ICommand OnLoginPageCommand { get; set; }
        bool isNetworkAvailable = false;

        public bool isClicked = true;
        #endregion

        #region Main Constructor
        public LoginPageViewModel(INavigation objNav)
        {
            AppPreferences.Is_HireMee_PRO_User = false;
            _navigation = objNav;
            LoginRequestData = new LoginRequestData();
            _commonservice = new HttpCommonService();
            OnLoginPageCommand = new GalaSoft.MvvmLight.Command.RelayCommand<string>(OnLogin);
            #region FontAwesomeFont Initial Binding
            LabelHidePassword = (string)Application.Current.Resources["HidePassword"];
            EmailFontAwesomeFont = (string)Application.Current.Resources["EmailSign"];
            PasswordFontAwesomeFont = (string)Application.Current.Resources["PasswordSign"];
            #endregion
            IsPassword = true;

            getFireBaseToken();


            var _VersionName = DependencyService.Get<IPackageInfo>().VersionName;
            VersionNumber = "version " + _VersionName;

        }

        private async void getFireBaseToken()
        {
            try
            {
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {
                    LoginRequestData.FirebaseToken = await DependencyService.Get<IPushNotificationRegister>().ExtractTokenAndRegister();
                }
            }
            catch (Exception) {

            }
        }
        #endregion


        private bool CheckServerReachble()
        {
            bool isHostReachable = DependencyService.Get<IMyDevice>().IsHostReachable();
            return isHostReachable;
        }

        private async Task LoginButtonClicked()
        {
            #region Login Button Click Event

            if (string.IsNullOrEmpty(Input))
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterInputField);
            }
            else if (!Utilities.ValidateEmailAddress(Input.Trim()) && !Utilities.ValidateMobileNumber(Input.Trim()))
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.InvalidEmailMobile);
            }
            else if (string.IsNullOrEmpty(Password))
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterPassword);
            }
            else
            {
                try
                {

                    UserDialogs.Instance.ShowLoading();
                    AppPreferences.ProfilePicture = String.Empty;
                    LoginRequestData.UserName = Input;
                    LoginRequestData.Password = Password;
                    LoginRequestData.DeviceID = Utilities.GetDeviceID();
                    LoginRequestData.DeviceModel = Utilities.GetDeviceModel();
                    LoginRequestData.DeviceOS = Device.RuntimePlatform;
                    LoginRequestData.SecretKey = "40709fe7-6790-4056-8b75-a65f54239fbc";

                    if (string.IsNullOrEmpty(LoginRequestData.FirebaseToken))
                        LoginRequestData.FirebaseToken = await DependencyService.Get<IPushNotificationRegister>().ExtractTokenAndRegister();

                    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                    if (isNetworkAvailable)
                    {
                        var result = await _commonservice.PostAsync<LoginResponseData, LoginRequestData>(APIData.API_BASE_URL + APIMethods.Login_v7, LoginRequestData);
                        if (result != null)
                        {
                            if (result.code == "200")
                            {
                                UserDialogs.Instance.HideLoading();
                                CommonLoginResponse _commonLoginResponse = new CommonLoginResponse();
                                _commonLoginResponse.NavigateToNextPage(result);
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(result.message);
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                            Password = string.Empty;
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                    }
                }
                catch (Exception ex)
                {
                    UserDialogs.Instance.HideLoading();
                    Debug.WriteLine(ex.Message);
                }
            }
            #endregion
        }

        #region OnLoginPageCommands
        private async void OnLogin(string sender)
        {
            var runtimePlatform = Device.RuntimePlatform;
            switch (sender)
            {
                case "ShowPasswordTapped":
                    #region ShowPasswordTapped

                    if (IsPassword == true)
                    {
                        LabelHidePassword = (string)Application.Current.Resources["ShowPassword"];
                        IsPassword = false;
                    }
                    else
                    {
                        LabelHidePassword = (string)Application.Current.Resources["HidePassword"];
                        IsPassword = true;
                    }
                    #endregion
                    break; ;
                case "DoLogin":
                    if (isClicked)
                    {
                        isClicked = false;
                        await LoginButtonClicked();
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });


                    break;
                case "ForgotPassword":
                    if (isClicked)
                    {
                        isClicked = false;
                        await _navigation.PushAsync(new ForgotPasswordPage());
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                case "DoRegister":
                    if (isClicked)
                    {
                        isClicked = false;
                        await _navigation.PushAsync(new UserRegistration_mobile());
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;

                case "GotoTestPin":
                    if (isClicked)
                    {
                        isClicked = false;
                        await _navigation.PushAsync(new PRO_TestPinPage());
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;

                case "DoGoogleLogin":
                    if (isClicked)
                    {
                        isClicked = false;
                        isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                        if (isNetworkAvailable == true)
                        {
                            UserDialogs.Instance.ShowLoading();
                            var IsReachable = CheckServerReachble();
                            if (IsReachable)
                            {
                                UserDialogs.Instance.HideLoading();
                                AppPreferences.IsGoogleLoggedIn = true;
                                DependencyService.Get<IGoogleManager>().Login();
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerNotReachable);
                            }
                        }
                        else
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                        }

                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });

                    break;


                case "DoFacebookLogin":

                    if (isClicked)
                    {
                        isClicked = false;
                        isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                        if (isNetworkAvailable == true)
                        {
                            UserDialogs.Instance.ShowLoading();
                            var IsReachable = CheckServerReachble();
                            if (IsReachable)
                            {
                                UserDialogs.Instance.HideLoading();
                                AppPreferences.IsFBLoggeedIn = true;
                                DependencyService.Get<IFacebookManager>().Login();
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerNotReachable);
                            }
                           
                        }
                        else
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });

                    break;

                case "DoLinkedInLogin":

                    if (isClicked)
                    {
                        isClicked = false;
                        isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                        if (isNetworkAvailable == true)
                        {
                            UserDialogs.Instance.ShowLoading();
                            await Task.Delay(50);
                            var IsReachable = CheckServerReachble();
                            if (IsReachable)
                            {
                                AppPreferences.IsLinkedInLoggedIn = true;
                                if (runtimePlatform.Equals("Android"))
                                {

                                    DependencyService.Get<ILinkedInManager>().doAuthLogin();

                                    //double _networkspeedTiming = DependencyService.Get<INetworkFast>()._CheckInternetSpeed();
                                    //await UserDialogs.Instance.AlertAsync (_networkspeedTiming.ToString() + " Seconds");
                                    //if (_networkspeedTiming < 50.000)
                                    //{
                                    //    DependencyService.Get<ILinkedInManager>().doAuthLogin();
                                    //}
                                    //else
                                    //{
                                    //    UserDialogs.Instance.HideLoading();
                                    //    await UserDialogs.Instance.AlertAsync(MessageStringConstants.LowNetworkSpeedAlert);
                                    //}

                                    //bool isFastnetwork = DependencyService.Get<INetworkFast>().IsConnectionFast();
                                    //if (isFastnetwork == true)
                                    //{


                                    //}

                                    //UserDialogs.Instance.HideLoading();




                                    //  DependencyService.Get<IGenerateHashKey>().computePakageHash();
                                    //var Instalation_Status = DependencyService.Get<ICheckInstallation>().IsAppInstalled("com.linkedin.android");
                                    //if (Instalation_Status == true)
                                    //{
                                    //    DependencyService.Get<ILinkedInManager>().doNativeLogin();
                                    //}
                                    //else
                                    //{
                                    //    DependencyService.Get<ILinkedInManager>().doAuthLogin();
                                    //}
                                }
                                else
                                {
                                    UserDialogs.Instance.HideLoading();
                                    await _navigation.PushAsync(new NavigationPage(new LinkedInIOSPage()));
                                }
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerNotReachable);
                            }
                           
                        }
                        else
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
            }
        }
        #endregion

        #region Binding Properties

        private bool _isPassword;
        public bool IsPassword
        {
            get { return _isPassword; }
            set { _isPassword = value; OnPropertyChanged(); }
        }



        private string _emailFontAwesomeFont;
        public string EmailFontAwesomeFont
        {
            get { return _emailFontAwesomeFont; }
            set
            {
                if (value == _emailFontAwesomeFont) return;
                _emailFontAwesomeFont = value;
                OnPropertyChanged();
            }
        }
        private string _passwordFontAwesomeFont;
        public string PasswordFontAwesomeFont
        {
            get { return _passwordFontAwesomeFont; }
            set
            {
                if (value == _passwordFontAwesomeFont) return;
                _passwordFontAwesomeFont = value;
                OnPropertyChanged();
            }
        }

        private string _input;
        public string Input
        {
            get { return _input; }
            set
            {
                if (value == _input) return;
                _input = value;
                OnPropertyChanged();
            }
        }


        private string _versionNumber;
        public string VersionNumber
        {
            get { return _versionNumber; }
            set
            {
                if (value == _versionNumber) return;
                _versionNumber = value;
                OnPropertyChanged();
            }
        }

        private string _password;
        public string Password
        {
            get { return _password; }
            set
            {
                if (value == _password) return;
                _password = value;
                OnPropertyChanged();
            }
        }

        private string _labelHidePassword;
        public string LabelHidePassword
        {
            get { return _labelHidePassword; }
            set
            {
                if (value == _labelHidePassword) return;
                _labelHidePassword = value;
                OnPropertyChanged();
            }
        }
        #endregion
    }
}


