﻿using MvvmHelpers;
using Plugin.Media;
using Plugin.Media.Abstractions;
using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using System;
using System.Threading.Tasks;
using Xamarin.Forms;
using Acr.UserDialogs;
using System.Windows.Input;
using HireMe.Models;
using Plugin.Connectivity;
using HireMe.Helpers;
using HireMe.Services;
using System.IO;
using HireMe.Renderers;


namespace HireMe.ViewModels
{
    public class ChangeProfilePictrurePageViewModel : BaseViewModel
    {
        public ICommand OnProfilePicturePageCommand { get; set; }
        INavigation NavigationService;
        MediaFile UpdatablePicture = null;
        public bool isClicked = true;

        public string UploadUserType { get; set; }


        #region Binding Properties
        private string _changeProfilePicture;
        public string ChangeProfilePicture
        {
            get { return _changeProfilePicture; }
            set { _changeProfilePicture = value; OnPropertyChanged(); }
        }

        private bool _isEnableChangeProfilePicture;
        public bool IsEnableChangeProfilePicture
        {
            get { return _isEnableChangeProfilePicture; }
            set { _isEnableChangeProfilePicture = value; OnPropertyChanged(); }
        }

        private ImageSource _userProfilePicture;
      

        public ImageSource UserProfilePicture
        {
            get
            { return this._userProfilePicture; }
            set
            {
                if (Equals(value, this._userProfilePicture))
                { return; }
                this._userProfilePicture = value;
                OnPropertyChanged();
            }
        }
        #endregion


        #region Main Constructor
        public ChangeProfilePictrurePageViewModel(INavigation objNav)
        {
            NavigationService = objNav;
            UserProfilePicture = "user.png";
            ChangeProfilePicture = "Edit";

            if (AppPreferences.ProfilePicture != string.Empty)
            {
                UserProfilePicture = AppPreferences.ProfilePicture;
                ChangeProfilePicture = "Upload";
            }
            else
            {
                UserProfilePicture = (string)Application.Current.Resources["IconUser"];
                ChangeProfilePicture = "Edit";
            }

            OnProfilePicturePageCommand = new Command(SetProfilePicture);
            MessagingCenter.Subscribe<ChangeProfilePictrurePageViewModel, string>(this, "ChangeProfilePicture", (sender, arg) =>
            {
                UserProfilePicture = arg ?? (string)Application.Current.Resources["IconUser"];
            });
        }

      
        #endregion

        private async void SetProfilePicture(object obj)
        {
            if (isClicked)
            {
                isClicked = false;
                await TakeAction();
               
            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });
        }




        #region Only Ios platform
        public async void TakeProfilePicture()
        {


            try
            {
                var status = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Camera);
                if (status != PermissionStatus.Granted)
                {
                    if (await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Camera))
                    {
                        await UserDialogs.Instance.AlertAsync("Need Camera Permission", "Access Camera", "OK");
                    }

                    var results = await CrossPermissions.Current.RequestPermissionsAsync(new[] { Permission.Camera });
                    status = results[Permission.Camera];
                }

                if (status == PermissionStatus.Granted)
                {
                    var objAboutMeVideoRecorder = new CustomProfilePictureRecorder();
                    objAboutMeVideoRecorder.VideoRecordCompleted += ObjAboutMeVideoRecorder_VideoRecordCompletedAsync;
                    await NavigationService.PushModalAsync(objAboutMeVideoRecorder);

                }
                else if (status != PermissionStatus.Unknown)
                {
                    await UserDialogs.Instance.AlertAsync("Can not continue, try again.", "Camera Permission Denied", "OK");
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "ChangeProfilePicturePageViewModel.TakeProfilePicture");
            }
        }
        #endregion

        private void ObjAboutMeVideoRecorder_VideoRecordCompletedAsync(VideoRecordEventArgs eventargs)
        {
            UploadS3_ProfilePicture(eventargs.RecordedVideoFilePath);
        }

        public async void UploadS3_ProfilePicture(String CapturedFilePath)
        {

            bool isNetworkAvailable1 = CrossConnectivity.Current.IsConnected;
            if (isNetworkAvailable1)
            {

                UserDialogs.Instance.ShowLoading();
                IsEnableChangeProfilePicture = false;
                string filename = AppSessionData.ActiveToken.HireMeID + "_" + "ProfilePic" + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".png";
                string filePath = DependencyService.Get<IImageManager>().CopyFile(CapturedFilePath, filename);
                UserProfilePicture = filePath;


                var UserProfileimageLegnth = DependencyService.Get<IImageManager>().ReadImageFile(filePath);

                var s3fileurl = await S3Manager.UploadFile(filePath, filename, AmazonS3BucketDetails.PhotoBucket);
                if (!string.IsNullOrEmpty(s3fileurl))
                {
                      UploadCaptureImageDetailsInToServer(filename, s3fileurl, filePath);
                 

                    //var data = new UserResourceInsertRequestData();

                    //data.ResourceTypeId = Convert.ToInt32(ResourceType.ProfilePic).ToString();
                    //data.s3Id = filename;
                    //data.ResourceUrl = s3fileurl;
                    //data.ThumbnailUrl = s3fileurl;

                    //HttpCommonService _commonservice = new HttpCommonService();
                    //var statusResult = await _commonservice.PostAsync<UserResourceInsertResponseData, UserResourceInsertRequestData>(APIData.API_BASE_URL + APIMethods.UserResourceInsert, data);

                    //if (statusResult != null)
                    //{

                    //    IsEnableChangeProfilePicture = true;
                    //    ChangeProfilePicture = "Edit";
                    //    AppPreferences.ProfilePicture = filePath;
                    //    MessagingCenter.Send(this, "ChangeProfilePicture", filePath);
                    //    UserDialogs.Instance.HideLoading();
                    //    await UserDialogs.Instance.AlertAsync(statusResult.Message);
                    //    AppPreferences.IsSeekerDashboardDataDownloaded = false;
                    //    //   await NavigationService.PopAsync();

                    //}
                    //else
                    //{
                    //    IsEnableChangeProfilePicture = true;
                    //    ChangeProfilePicture = "Edit";
                    //    UserDialogs.Instance.HideLoading();
                    //    await UserDialogs.Instance.AlertAsync(MessageStringConstants.UnableToUpdateProfilePicture);
                    //}
                }
                else
                {

                    UserDialogs.Instance.HideLoading();
                }

            }

            else
            {
                UserDialogs.Instance.HideLoading();
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);

            }
        }






        #region UploadProfilePicture
        async public Task TakeAction()
        {
            if (string.IsNullOrEmpty(AppPreferences.S3AccessKeyID))
            {
                var obj = new S3Utils();
                await obj.GetS3Credentials();
            }

            MediaFile UpdatablePicture = null;
            #region UserDialogs.ActionSheet Configurations

            ActionSheetConfig ActionSheetConfigurations = new ActionSheetConfig();
            ActionSheetConfigurations.SetTitle("Profile Photo");
            ActionSheetConfigurations.Add("Pick from Gallery", () =>
           {
              
                    UploadProfilePicture("Pick from Gallery");
         
                     });
            ActionSheetConfigurations.Add("Camera", () =>
            { 
                 
                UploadProfilePicture("Camera");

            });
            ActionSheetConfigurations.Add("Cancel", () => { });
            UserDialogs.Instance.ActionSheet(ActionSheetConfigurations);
            #endregion
        }











        public async void UploadProfilePicture(string action)
        {
            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
            if (isNetworkAvailable)
            {
                try
                {
                    await CrossMedia.Current.Initialize();

                    #region Pick from Gallery
                    if (action == "Pick from Gallery")
                    {

                        try
                        {
                            var status = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Storage);
                            if (status != PermissionStatus.Granted)
                            {
                                if (await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Storage))
                                {
                                    await UserDialogs.Instance.AlertAsync("Need Storage Permission", "Access Storage","OK");
                                }

                                var results = await CrossPermissions.Current.RequestPermissionsAsync(new[] { Permission.Storage });
                                if (results != null)
                                {
                                    status = results[Permission.Storage];
                                }
                               
                            }

                            if (status == PermissionStatus.Granted)
                            {
                                await Task.Delay(1000);
                                UpdatablePicture = await CrossMedia.Current.PickPhotoAsync(new PickMediaOptions { PhotoSize = PhotoSize.Medium, });


                                if (UpdatablePicture !=null)
                                {
                                    var memoryStream = new MemoryStream();
                                   
                                    UpdatablePicture.GetStream().CopyToAsync(memoryStream).Wait();
                                    byte[] imageAsByte = memoryStream.ToArray();
                                    await NavigationService.PushModalAsync(new CropView(imageAsByte, Refresh));
                                }
                                


                            }
                            else if (status != PermissionStatus.Unknown)
                            {
                                 UserDialogs.Instance.Toast(MessageStringConstants.PermissionMessage);
                            }
                        }
                        catch (Exception ex)
                        {
                            System.Diagnostics.Debug.WriteLine(ex.Message);
                            SendErrorMessageToServer(ex, "ChangeProfilePicturePageViewModel.Pick from Gallery");
                        }
                    }
                    #endregion

                    #region Camera
                    else if (action == "Camera")
                    {
                        try
                        {
                            var status = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Camera);
                            var storage = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Storage);
                            if (status != PermissionStatus.Granted || storage != PermissionStatus.Granted)
                            {
                                if (await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Camera))
                                {
                                    await UserDialogs.Instance.AlertAsync("Need Camera Permission", "Access Camera", "OK");
                                    //await UserDialogs.Instance.AlertAsync(MessageStringConstants.CameraMessage, MessageStringConstants.PermissionMessage, "OK");
                                }
                                if (await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Storage))
                                {
                                    await UserDialogs.Instance.AlertAsync("Need Storage Permission", "Access Storage", "OK");
                                }
                                var results = await CrossPermissions.Current.RequestPermissionsAsync(new[] { Permission.Camera, Permission.Storage });
                               if(results !=null)
                                {
                                    status = results[Permission.Camera];
                                    storage = results[Permission.Storage];
                                }
                           
                            }

                            if (status == PermissionStatus.Granted)
                            {
                                await Task.Delay(1000);
                                UpdatablePicture = await CrossMedia.Current.TakePhotoAsync(new StoreCameraMediaOptions
                                {
                                    CompressionQuality = 80,
                                    AllowCropping = false,
                                    PhotoSize = PhotoSize.Medium,
                                    Directory = "HireMee",
                                    Name = "HireMeeProfilePic.jpg",
                                    RotateImage = true,
                                   
                                });

                                if (UpdatablePicture != null)
                                {
                                    var memoryStream = new MemoryStream();
                                    await UpdatablePicture.GetStream().CopyToAsync(memoryStream);
                                    byte[] imageAsByte = memoryStream.ToArray();
                                    await NavigationService.PushModalAsync(new CropView(imageAsByte, Refresh));
                                }



                            }
                            else if (status != PermissionStatus.Unknown)
                            {
                                //await UserDialogs.Instance.AlertAsync("Can not continue, try again.", "Camera Permission Denied", "OK");
                                 UserDialogs.Instance.Toast(MessageStringConstants.PermissionMessage);
                            }
                        }
                        catch (Exception ex)
                        {
                            System.Diagnostics.Debug.WriteLine(ex.Message);
                            SendErrorMessageToServer(ex, "ChangeProfilePicturePageViewModel.UploadProfilePicture.Camera");
                        }
                    }
                    #endregion

                    else
                    {
                        UpdatablePicture = null;
                    }
                    #region Null Check

                    if (UpdatablePicture == null)
                    {
                        return;
                    }
                    #endregion

                   
                }
                catch (Exception ex)
                {
                    UserDialogs.Instance.HideLoading();
                    System.Diagnostics.Debug.WriteLine("EXCEPTION {0}:  {1}", DateTime.Now, ex.StackTrace);

                    SendErrorMessageToServer(ex, "ChangeProfilePicturePageViewModel.UploadProfilePicture");

                }
                finally
                {
                   
                    if (UpdatablePicture != null)
                    {
                        UpdatablePicture.Dispose();
                    }
                }

            }
            else
            {
                UserDialogs.Instance.HideLoading();
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
            }
        }

        private async void UploadCaptureImageDetailsInToServer(string filename, string s3fileurl, string filePath)
        {
            try
            {
                var data = new UserResourceInsertRequestData();
                if (AppPreferences.IsAdmin_CompanyProfile =="1")
                {
                    data.ResourceTypeId = Convert.ToInt32(ResourceType.CompanyPic).ToString();
                }
                else
                {
                    data.ResourceTypeId = Convert.ToInt32(ResourceType.ProfilePic).ToString();
                }
                data.s3Id = filename;
                data.ResourceUrl = s3fileurl;
                data.ThumbnailUrl = s3fileurl;

                HttpCommonService _commonservice = new HttpCommonService();
                var statusResult = await _commonservice.PostAsync<UserResourceInsertResponseData, UserResourceInsertRequestData>(APIData.API_BASE_URL + APIMethods.UserResourceInsert, data);

                if (statusResult != null)
                {
                    if (statusResult.code == "200")
                    {
                        IsEnableChangeProfilePicture = true;
                        ChangeProfilePicture = "Edit";
                        AppPreferences.ProfilePicture = filePath;
                        MessagingCenter.Send(this, "ChangeProfilePicture", filePath);
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(statusResult.message);
                        AppPreferences.IsSeekerDashboardDataDownloaded = false;
                    }
                    else
                    {
                        IsEnableChangeProfilePicture = true;
                        ChangeProfilePicture = "Edit";
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.UnableToUpdateProfilePicture);
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "ChangeProfilePicturePageViewModel.UploadCaptureImageDetailsInToServer");
            }
        }

        #endregion


        #region SetImageSource
        private async void Refresh()
        {
            try
            {
                if (App.CroppedImage != null && App.CroppedImageFilePath != null)
                {


                    Stream stream = new MemoryStream(App.CroppedImage);
                    UserProfilePicture = ImageSource.FromStream(() => stream);


                    #region S3   Image
                    bool isNetworkAvailable1 = CrossConnectivity.Current.IsConnected;
                    if (isNetworkAvailable1)
                    {

                        UserDialogs.Instance.ShowLoading();
                        IsEnableChangeProfilePicture = false;
                        string filename = AppSessionData.ActiveToken.HireMeID + "_" + "ProfilePic" + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".png";
                        string filePath = DependencyService.Get<IImageManager>().CopyFile(App.CroppedImageFilePath, filename);
                        UserProfilePicture = filePath;
                        var UserProfileimageLegnth = DependencyService.Get<IImageManager>().ReadImageFile(filePath);
                        string s3fileurl = string.Empty;

                        if (AppPreferences.IsAdmin_CompanyProfile =="1")
                        {
                           s3fileurl = await S3Manager.UploadFile(filePath, filename, AmazonS3BucketDetails.CompanyLogoBucket);
                        }
                        else
                        {
                            s3fileurl = await S3Manager.UploadFile(filePath, filename, AmazonS3BucketDetails.PhotoBucket);
                        }
                       
                        if (!string.IsNullOrEmpty(s3fileurl))
                        {
                            UploadCaptureImageDetailsInToServer(filename, s3fileurl, filePath);
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                        }

                    }

                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);

                    }
                    #endregion




                }
            }
            catch(Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "ChangeProfilePicturePageViewModel.Refresh");
            }
        }
        #endregion



        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

    }

}