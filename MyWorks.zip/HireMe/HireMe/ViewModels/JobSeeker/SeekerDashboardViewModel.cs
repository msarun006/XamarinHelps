﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using HireMe.Helpers;
using HireMe.Helpers.Assessment;
using HireMe.Models;
using HireMe.ViewModels;
using HireMe.ViewModels.JobSeeker;
using HireMe.Views.JobSeeker;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe
{
    public class SeekerDashboardViewModel : BaseViewModel
    {
        #region Variable declaration
        private HttpCommonService _commonservice { get; set; }
        public SeekerDashboardModel SeekerDashboardModel { get; set; }
        public ICommand SeekerCommand { get; set; }
        GetAssessmentDetails GetAssessmentDetails;
        public INavigation _navigationservice;
        private bool _isLocked = true;

        #endregion

        #region Constructor
        public SeekerDashboardViewModel(INavigation nav)
        {
            _commonservice = new HttpCommonService();
            SeekerDashboardModel = new SeekerDashboardModel();
            GetAssessmentDetails = new GetAssessmentDetails();
            SeekerCommand = new RelayCommand<string>(TapEventCommand);
            _navigationservice = nav;

            //Track Page 
            if (Device.RuntimePlatform.Equals("Android"))
            {
                GoogleAnalyticService.Track_App_Page("Android SeekerDashboardPage");
            }
            else
            {   //Track Page 
                GoogleAnalyticService.Track_App_Page("iOS  SeekerDashboardPage");
            }

            IsFirstGrid = true;
            IsSecondGrid = false;
            IsLeftEnable = false;
            LeftTextColor = Color.Gray;
            IsRightEnable = true;
            RightTextColor = Color.Black;
            IsGridTakeAssessment = true;
            IsGridAssessmentScore = false;


            #region load default content
            try
            {
                if (_isLocked)
                {
                    _isLocked = false;

                    if (string.IsNullOrEmpty(AppPreferences.ProfilePicture))
                    {
                        ProfileImage = (string)Application.Current.Resources["IconUser"];
                        AppPreferences.ProfilePicture = ProfileImage;
                    }
                    else
                    {
                        ProfileImage = AppPreferences.ProfilePicture;
                    }



                    if (AppPreferences.IsSeekerDashboardDataDownloaded == true)
                    {
                        BindData();
                    }
                    else
                    {
                        Task.Run(async () =>
                        {
                            await GetJobSeekerDetails();
                        });
                    }
                }
                Task.Run(async () =>
                {
                    await Task.Delay(500);
                    _isLocked = true;
                });
            }
            catch (Exception ex)
            {
                SendErrorMessageToServer(ex, "SeekerDashboardViewModel.SeekerDashboardViewModel");
            }
            #endregion

            #region all message subscritions
            MessagingCenter.Subscribe<ChangeProfilePictrurePageViewModel, string>(this, "ChangeProfilePicture", ChangeProfilePicture);


            MessagingCenter.Subscribe<EditBasicDetailsViewModel, string[]>(this, "UpdateBasicDetails", (sender, arg) =>
            {
                FirstName = arg[0];
                LastName = arg[1];
                MobileNo = arg[2];
                //EmailID = arg[3];
                UserName = FirstName.ToUpper() + " " + LastName.ToUpper();
            });

            MessagingCenter.Subscribe<OTPVerifyViewModel, string>(this, "UpdateEmail", (sender, arg) =>
            {
                EmailID = arg;
            });
            MessagingCenter.Subscribe<OTPVerifyViewModel, string>(this, "UpdateMobileNumber", (sender, arg) =>
            {
                MobileNo = arg;
            });
            #endregion
            if (Constant.IsSideMenuDashboard)
            {
                GetJobSeekerDetails();
            }

        }
        #endregion

        #region BindData
        private void BindData()
        {
            try
            {
                var objSeekerDashboardResponseModel = AppPreferences.LoadSeekerDashboardData;

                //CheckVersion(objSeekerDashboardResponseModel.apiVersionCheck);

                CheckVersionUpdates _CheckVersionUpdates = new CheckVersionUpdates();
                _CheckVersionUpdates.CheckVersion(objSeekerDashboardResponseModel.apiVersionCheck);
                if (AppPreferences.OldVersion == true)
                {
                    Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                    return;
                }
                else if (AppPreferences.OldVersion == false)
                {
                    if (string.IsNullOrEmpty(AppPreferences.S3AccessKeyID))
                    {
                        var obj = new S3Utils();
                        Task.Run(async () =>
                        {
                            await obj.GetS3Credentials();
                        });
                    }


                    if (objSeekerDashboardResponseModel.ProfileImage != null)
                    {
                        if (!string.IsNullOrEmpty(objSeekerDashboardResponseModel.ProfileImage.S3_ID))
                        {
                            BindProfilePic(objSeekerDashboardResponseModel.ProfileImage.S3_ID);
                        }
                    }
                    else
                    {
                        AppPreferences.ProfilePicture = (string)Application.Current.Resources["IconUser"];
                    }

                    BindProfileDetails(objSeekerDashboardResponseModel.ProfileDetails);

                    BindProfileCompletePercentage(objSeekerDashboardResponseModel.ProfileWeightage);

                    BindAssessmentScore(objSeekerDashboardResponseModel.AssessmentScore);

                    //Check profile completed percentage and give alert to user
                    //CheckProfileCompletedStatus(objSeekerDashboardResponseModel.ProfileWeightage);

                    if (objSeekerDashboardResponseModel.AssessmentScore != null)
                    {
                        IsGridAssessmentScore = true;
                        IsGridTakeAssessment = false;
                    }
                    else
                    {
                        IsGridAssessmentScore = false;
                        IsGridTakeAssessment = true;
                    }

                    ProfileImage = AppPreferences.ProfilePicture ?? (string)Application.Current.Resources["IconUser"];
                    UserDialogs.Instance.HideLoading();
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerDashboardViewModel.BindData");
            }
        }

        //private async void CheckVersion(Appversioncheck apiVersionCheck)
        //{
        //    try
        //    {
        //        if (apiVersionCheck != null)
        //        {
        //            if (Device.RuntimePlatform == Device.Android)
        //            {
        //                var installedAndroidVersionCode = Convert.ToDouble(DependencyService.Get<IPackageInfo>().VersionCode);
        //                var LatestVersionCode = Convert.ToDouble(apiVersionCheck.android_VersionCode);
        //                //android mean check with version code
        //                if (installedAndroidVersionCode < LatestVersionCode)
        //                {
        //                    String message = MessageStringConstants.UpdateLatestVersion;
        //                    await UserDialogs.Instance.AlertAsync(message);
        //                    DependencyService.Get<IMyDevice>().OpnePlayStore();
        //                }
        //            }
        //            else if (Device.RuntimePlatform == Device.iOS)
        //            {
        //                var installedIOSVersionName = Convert.ToDouble(DependencyService.Get<IPackageInfo>().VersionName);
        //                var LatestIOSName = Convert.ToDouble(apiVersionCheck.ioS_VersionCode);
        //                //if iOS mean check with version name
        //                if (installedIOSVersionName < LatestIOSName)
        //                {
        //                    String message = MessageStringConstants.UpdateLatestVersion;
        //                    await UserDialogs.Instance.AlertAsync(message);
        //                    DependencyService.Get<IMyDevice>().OpnePlayStore();
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        UserDialogs.Instance.HideLoading();
        //        System.Diagnostics.Debug.WriteLine(ex.Message);
        //        SendErrorMessageToServer(ex, "SeekerDashboardViewModel.CheckVersion");
        //    }
        //}
        #endregion

        #region ChangeProfilePicture
        private void ChangeProfilePicture(ChangeProfilePictrurePageViewModel sender, string path)
        {
            ProfileImage = path ?? (string)Application.Current.Resources["IconUser"];
        }
        #endregion

        #region GetJobSeekerDetails 
        /// <summary>
        /// Webserivce call for JobSeekerDetails
        /// </summary>
        public async Task GetJobSeekerDetails()
        {

            try
            {
                Device.BeginInvokeOnMainThread(async () =>
                {
                    UserDialogs.Instance.ShowLoading();
                    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                    if (isNetworkAvailable)
                    {
                        BaseRequestDTO objRequestData = new BaseRequestDTO();
                        var statusResult = await _commonservice.PostAsync<SeekerDashboardResponseModel, BaseRequestDTO>(APIData.API_BASE_URL + APIMethods.GetPersonalDetails, objRequestData);
                        if (statusResult != null)
                        {
                            if (statusResult.Code == "200")
                            {
                                UserDialogs.Instance.HideLoading();
                                AppPreferences.LoadSeekerDashboardData = statusResult;
                                AppPreferences.IsSeekerDashboardDataDownloaded = true;
                                Constant.IsSideMenuDashboard = false;
                                BindData();
                                //  CheckProfileCompletedStatus(statusResult.ProfileWeightage);
                            }
                            else if (statusResult.Code == "199")
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.SessionExpiered);
                                Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                                return;
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                            }
                        }
                    }
                    else
                    {
                        BindData();
                    }

                });
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerDashboardViewModel.GetJobSeekerDetails");
            }
        }
        #endregion

        #region CheckProfileCompletedStatus
        private async void CheckProfileCompletedStatus(JobSeekerProfileweightage profileWeightage)
        {
            try
            {
                if (profileWeightage != null)
                {
                    if (string.IsNullOrEmpty(profileWeightage.Video))
                    {
                        await UserDialogs.Instance.AlertAsync("Please Update Video Profile", MessageStringConstants.ProfileCompletence, "OK");

                        //  UserDialogs.Instance.Toast(MessageStringConstants.UpdateVideoProfile);
                    }
                    else if (int.Parse(profileWeightage.Video) < 35)
                    {
                        await UserDialogs.Instance.AlertAsync("Please Update Video Profile", MessageStringConstants.ProfileCompletence, "OK");
                    }
                    else if (string.IsNullOrEmpty(profileWeightage.ProfilePic))
                    {
                        UserDialogs.Instance.Toast(MessageStringConstants.UpdateProfilePic);
                    }
                    else if (string.IsNullOrEmpty(profileWeightage.EducationalDetails))
                    {
                        UserDialogs.Instance.Toast(MessageStringConstants.UpdateEducationalDetails);
                    }
                    else if (int.Parse(profileWeightage.EducationalDetails) < 35)
                    {
                        UserDialogs.Instance.Toast(MessageStringConstants.UpdateEducationalDetails);
                    }
                    else if (string.IsNullOrEmpty(profileWeightage.PersonalDetails))
                    {
                        UserDialogs.Instance.Toast(MessageStringConstants.UpdatePersonalDetails);
                    }
                    else if (int.Parse(profileWeightage.PersonalDetails) < 20)
                    {
                        UserDialogs.Instance.Toast(MessageStringConstants.UpdatePersonalDetails);
                    }
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "SeekerDashboardViewModel.CheckProfileCompletedStatus");
            }
        }
        #endregion

        #region ForceUpdateCheck
        //public async void ForceUpdateCheck()
        //{
        //    var isLatest = await CrossLatestVersion.Current.IsUsingLatestVersion();

        //    if (!isLatest)
        //    {
        //        var update = await UserDialogs.Instance.ConfirmAsync("There is a new version of this app available.Update HireMee App", "Update Your App", "Update", "");

        //        if (update)
        //        {
        //            await CrossLatestVersion.Current.OpenAppInStore();
        //        }
        //    }
        //}
        #endregion

        #region BindProfilePic
        private void BindProfilePic(string s3_id)
        {
            try
            {
                if (!string.IsNullOrEmpty(s3_id))
                {
                    var Imagedownloader = new S3ImageDownloder();
                    Imagedownloader.DownloadProfilePicture(s3_id);
                }
                else
                {
                    AppPreferences.ProfilePicture = (string)Application.Current.Resources["IconUser"];
                }
                ProfileImage = AppPreferences.ProfilePicture;
                MessagingCenter.Send(this, "ChangeProfilePicture", ProfileImage);
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "SeekerDashboardViewModel.BindProfilePic");

            }
        }

        #endregion

        #region BindAssessmentScore
        private async void BindAssessmentScore(JobSeekerAssessmentDetails assessmentScore)
        {
            try
            {

                if (assessmentScore != null)
                {


                    if (assessmentScore.Status == "Rejected")
                    {
                        VerbalAptitude = "R";
                        QuantitativeAptitude = "R";
                        LogicalResoning = "R";
                        TechnicalComputerFundamental = "R";
                        Communication = "R";
                        TechnicalCoreDomain = "R";
                        PersonalCompetencies = "R";
                        EmotionalCompetencies = "R";
                        IntellectualOrientation = "R";
                        InterPersonalCompetencies = "R";
                        MotivationalCompetencies = "R";
                        PercentileScore = "0";
                    }
                    else if (assessmentScore.Status == "Not Verified" || assessmentScore.Status == "Verified")
                    {
                        VerbalAptitude = assessmentScore.VerbalAptitude ?? "0";
                        QuantitativeAptitude = assessmentScore.QuantitativeAptitude ?? "0";
                        LogicalResoning = assessmentScore.LogicalResoning ?? "0";
                        TechnicalComputerFundamental = assessmentScore.TechnicalComputerFundamental ?? "0";
                        Communication = assessmentScore.Communication ?? "0";
                        TechnicalCoreDomain = assessmentScore.TechnicalCoreDomain ?? "0";

                        PersonalCompetencies = assessmentScore.PersonalCompetencies ?? "0";
                        EmotionalCompetencies = assessmentScore.EmotionalCompetencies ?? "0";
                        IntellectualOrientation = assessmentScore.IntellectualOrientation ?? "0";
                        InterPersonalCompetencies = assessmentScore.InterPersonalCompetencies ?? "0";
                        MotivationalCompetencies = assessmentScore.MotivationalCompetencies ?? "0";
                        PercentileScore = assessmentScore.PercenTile ?? "0";
                    }
                    else
                    {
                        VerbalAptitude = "0";
                        QuantitativeAptitude = "0";
                        LogicalResoning = "0";
                        TechnicalComputerFundamental = "0";
                        Communication = "0";
                        TechnicalCoreDomain = "0";
                        PersonalCompetencies = "0";
                        EmotionalCompetencies = "0";
                        IntellectualOrientation = "0";
                        InterPersonalCompetencies = "0";
                        MotivationalCompetencies = "0";
                        PercentileScore = "0";
                    }

                }
                else
                {
                    VerbalAptitude = "0";
                    QuantitativeAptitude = "0";
                    LogicalResoning = "0";
                    TechnicalComputerFundamental = "0";
                    Communication = "0";
                    TechnicalCoreDomain = "0";
                    PersonalCompetencies = "0";
                    EmotionalCompetencies = "0";
                    IntellectualOrientation = "0";
                    InterPersonalCompetencies = "0";
                    MotivationalCompetencies = "0";
                    PercentileScore = "0";
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "SeekerDashboardViewModel.BindAssessmentScore");
            }
        }
        #endregion

        #region BindProfileCompletePercentage
        private async void BindProfileCompletePercentage(JobSeekerProfileweightage profileWeightage)
        {
            try
            {
                System.Diagnostics.Debug.WriteLine("@ SeekerDashboardPage.SetProfileCompletePercentage");

                var scorecard = profileWeightage;
                if (scorecard != null)
                {
                    int intPersonal;
                    int intEducation;
                    int intVideo;
                    int intProfilePic;

                    if (!int.TryParse(scorecard.PersonalDetails, out intPersonal))
                    {
                        intPersonal = 0;
                    }

                    if (!int.TryParse(scorecard.EducationalDetails, out intEducation))
                    {
                        intEducation = 0;
                    }

                    if (!int.TryParse(scorecard.Video, out intVideo))
                    {
                        intVideo = 0;
                    }

                    if (!int.TryParse(scorecard.ProfilePic, out intProfilePic))
                    {
                        intProfilePic = 0;
                    }

                    CurrentProgress = (intPersonal + intEducation + intVideo + intProfilePic) / 100.0;
                    // AppPreferences.CurrentProgress = Convert.ToString(CurrentProgress);
                    int total = intPersonal + intEducation + intVideo + intProfilePic;
                    ProfileScore = total + "%";
                    //AppPreferences.ProfileScore = ProfileScore;

                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "SeekerDashboardViewModel.BindProfileCompletePercentage");
                //await UserDialogs.Instance.AlertAsync(ex.Message);
                //throw new NotImplementedException();

            }
        }

        #endregion

        #region BindProfileDetails
        private async void BindProfileDetails(JobSeekerProfileDetails profileDetails)
        {
            try
            {
                if (profileDetails != null)
                {
                    FirstName = profileDetails.FirstName;
                    LastName = profileDetails.LastName;
                    UserName = FirstName.ToUpper() + " " + LastName.ToUpper();
                    HiremeeID = "HireMee ID : " + profileDetails.HireMeeID;
                    EmailID = profileDetails.EmailAddress;
                    MobileNo = profileDetails.MobileNumber;
                    string[] values = { UserName, profileDetails.EmailAddress, "HireMee ID : " + profileDetails.HireMeeID, profileDetails.FirstName, profileDetails.LastName };
                    MessagingCenter.Send(this, "UserDetails", values);
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "SeekerDashboardViewModel.BindProfileDetails");
            }
        }

        #endregion

        #region Click Event Command 
        /// <summary>
        /// Click Event Method
        /// </summary>
        private async void TapEventCommand(string sender)
        {
            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
            switch (sender)
            {
                case "Education":

                    if (_isLocked)
                    {
                        _isLocked = false;
                        await _navigationservice.PushAsync(new SeekerPersonalAndEducationPage(true));
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        _isLocked = true;
                    });
                    break;

                case "Video":
                    if (isNetworkAvailable)
                    {
                        if (_isLocked)
                        {
                            _isLocked = false;
                            await _navigationservice.PushAsync(new VideoProfilePage());
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(500);
                            _isLocked = true;
                        });
                    }
                    else
                    {
                        UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                    }
                    break;

                case "Assessment":
                    if (_isLocked)
                    {
                        _isLocked = false;

                        if (AppPreferences.LoadSeekerDashboardData != null)
                        {
                            if (AppPreferences.LoadSeekerDashboardData.AssessmentScore != null)
                            {
                                if (AppPreferences.LoadSeekerDashboardData.AssessmentScore.Status == "Rejected")
                                {
                                    var RejectReason = AppPreferences.LoadSeekerDashboardData.AssessmentScore.Reason;
                                    if (!string.IsNullOrEmpty(RejectReason))
                                    {
                                        await UserDialogs.Instance.AlertAsync(RejectReason);
                                    }
                                    else
                                    {
                                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                                    }
                                }
                                else if (AppPreferences.LoadSeekerDashboardData.AssessmentScore.Status == "Verified" || AppPreferences.LoadSeekerDashboardData.AssessmentScore.Status == "Not Verified")
                                {
                                    await _navigationservice.PushAsync(new SeekerAssessmentPage());
                                }
                            }
                        }

                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        _isLocked = true;
                    });
                    break;
                case "TakeAssessment":
                    if (_isLocked)
                    {
                        _isLocked = false;
                        GetAssessmentDetails.AssessmentLoginAPI();
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(1500);
                        _isLocked = true;
                    });
                    break;



                case "LeftArrow":
                    IsFirstGrid = true;
                    IsSecondGrid = false;
                    IsLeftEnable = false;
                    LeftTextColor = Color.Gray;
                    IsRightEnable = true;
                    RightTextColor = Color.Black;
                    break;

                case "RightArrow":
                    IsFirstGrid = false;
                    IsSecondGrid = true;
                    IsLeftEnable = true;
                    LeftTextColor = Color.Black;
                    IsRightEnable = false;
                    RightTextColor = Color.Gray;
                    break;

                case "Edit":
                    if (_isLocked)
                    {
                        _isLocked = false;
                        await _navigationservice.PushAsync(new SeekerPersonalAndEducationPage(false));
                    }
                    await Task.Run(async () =>
                      {
                          await Task.Delay(500);
                          _isLocked = true;
                      });
                    break;

                case "Refresh":
                    if (isNetworkAvailable)
                    {
                        if (_isLocked)
                        {
                            _isLocked = false;

                            await GetJobSeekerDetails();
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(500);
                            _isLocked = true;
                        });
                        break;
                    }
                    else
                    {
                        UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                    }
                    break;


                case "ProfileImage":
                    await _navigationservice.PushAsync(new ChangeProfilePicturePage());
                    break;
                case "BasicDetailsEdit":
                    if (_isLocked)
                    {
                        _isLocked = false;
                        await _navigationservice.PushAsync(new EditBasicDetailsPage());
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        _isLocked = true;
                    });
                    break;
            }
        }
        #endregion

        #region private property


        //private bool _emailVisibility;
        //public bool emailVisibility
        //{
        //    get { return _emailVisibility; }
        //    set { _emailVisibility = value; OnPropertyChanged(); }
        //}

        private string _userName;
        public string UserName
        {
            get { return _userName; }
            set
            {
                _userName = value;
                OnPropertyChanged();
            }
        }
        private string _firstName;
        public string FirstName
        {
            get { return _firstName; }
            set
            {
                _firstName = value;
                OnPropertyChanged();
            }
        }
        private string _lastName;
        public string LastName
        {
            get { return _lastName; }
            set
            {
                _lastName = value;
                OnPropertyChanged();
            }
        }

        private string _emailID;
        public string EmailID
        {
            get { return _emailID; }
            set
            {
                _emailID = value;
                OnPropertyChanged();
            }
        }

        private string _mobileNo;
        public string MobileNo
        {
            get { return _mobileNo; }
            set
            {
                _mobileNo = value;
                OnPropertyChanged();
            }
        }

        private string _hiremeeID;
        public string HiremeeID
        {
            get { return _hiremeeID; }
            set
            {
                _hiremeeID = value;
                OnPropertyChanged();
            }
        }

        private string _profileScore;
        public string ProfileScore
        {
            get { return _profileScore; }
            set
            {
                _profileScore = value;
                OnPropertyChanged();
            }
        }


        private string _verbalAptitude;
        public string VerbalAptitude
        {
            get { return _verbalAptitude; }
            set
            {
                _verbalAptitude = value;
                OnPropertyChanged();
            }
        }

        private string _quantitativeAptitude;
        public string QuantitativeAptitude
        {
            get { return _quantitativeAptitude; }
            set
            {
                _quantitativeAptitude = value;
                OnPropertyChanged();
            }
        }

        private string _logicalResoning;
        public string LogicalResoning
        {
            get { return _logicalResoning; }
            set
            {
                _logicalResoning = value;
                OnPropertyChanged();
            }
        }

        private string _technicalComputerFundamental;
        public string TechnicalComputerFundamental
        {
            get { return _technicalComputerFundamental; }
            set
            {
                _technicalComputerFundamental = value;
                OnPropertyChanged();
            }
        }

        private string _communication;
        public string Communication
        {
            get { return _communication; }
            set
            {
                _communication = value;
                OnPropertyChanged();
            }
        }

        private string _technicalCoreDomain;
        public string TechnicalCoreDomain
        {
            get { return _technicalCoreDomain; }
            set
            {
                _technicalCoreDomain = value;
                OnPropertyChanged();
            }
        }

        private string _personalCompetencies;
        public string PersonalCompetencies
        {
            get { return _personalCompetencies; }
            set
            {
                _personalCompetencies = value;
                OnPropertyChanged();
            }
        }

        private string _emotionalCompetencies;
        public string EmotionalCompetencies
        {
            get { return _emotionalCompetencies; }
            set
            {
                _emotionalCompetencies = value;
                OnPropertyChanged();
            }
        }

        private string _intellectualOrientation;
        public string IntellectualOrientation
        {
            get { return _intellectualOrientation; }
            set
            {
                _intellectualOrientation = value;
                OnPropertyChanged();
            }
        }

        private string _interPersonalCompetencies;
        public string InterPersonalCompetencies
        {
            get { return _interPersonalCompetencies; }
            set
            {
                _interPersonalCompetencies = value;
                OnPropertyChanged();
            }
        }

        private string _motivationalCompetencies;
        public string MotivationalCompetencies
        {
            get { return _motivationalCompetencies; }
            set
            {
                _motivationalCompetencies = value;
                OnPropertyChanged();
            }
        }

        private string _PercentileScore;
        public string PercentileScore
        {
            get { return _PercentileScore; }
            set
            {
                _PercentileScore = value;
                OnPropertyChanged();
            }
        }

        private bool _IsGridTakeAssessment;
        public bool IsGridTakeAssessment
        {
            get { return _IsGridTakeAssessment; }
            set { _IsGridTakeAssessment = value; OnPropertyChanged(); }
        }
        private bool _IsGridAssessmentScore;
        public bool IsGridAssessmentScore
        {
            get { return _IsGridAssessmentScore; }
            set { _IsGridAssessmentScore = value; OnPropertyChanged(); }
        }


        private string _profileImage;
        public string ProfileImage
        {
            get { return _profileImage; }
            set
            {
                _profileImage = value;
                OnPropertyChanged();

            }
        }


        private bool _isFirstGrid;
        public bool IsFirstGrid
        {
            get { return _isFirstGrid; }
            set
            {
                _isFirstGrid = value;
                OnPropertyChanged();

            }
        }

        private bool _isSecondGrid;
        public bool IsSecondGrid
        {
            get { return _isSecondGrid; }
            set
            {
                _isSecondGrid = value;
                OnPropertyChanged();

            }
        }


        private bool _isLeftEnable;
        public bool IsLeftEnable
        {
            get { return _isLeftEnable; }
            set
            {
                _isLeftEnable = value;
                OnPropertyChanged();

            }
        }

        private bool _isRightEnable;
        public bool IsRightEnable
        {
            get { return _isRightEnable; }
            set
            {
                _isRightEnable = value;
                OnPropertyChanged();

            }
        }

        private Color _rightTextColor;
        public Color RightTextColor
        {
            get { return _rightTextColor; }
            set
            {
                _rightTextColor = value;
                OnPropertyChanged();

            }
        }

        private Color _leftTextColor;
        public Color LeftTextColor
        {
            get { return _leftTextColor; }
            set
            {
                _leftTextColor = value;
                OnPropertyChanged();

            }
        }


        private double _currentProgress = 0;
        public double CurrentProgress
        {
            get { return _currentProgress; }
            set
            {
                _currentProgress = value;
                OnPropertyChanged();
            }
        }

        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

    }
}