﻿using HireMe.Models.JobSeeker;
using HireMe.Views.JobSeeker;
using MvvmHelpers;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;
using Acr.UserDialogs;
using System.Diagnostics;
using HireMe.Helpers;
using HireMe.Models.Recruiter;
using System.Text.RegularExpressions;
using Plugin.Connectivity;

namespace HireMe.ViewModels.JobSeeker
{
    public class SearchJobsViewModel : BaseViewModel
    {
        INavigation Navigation;
        public bool isClicked = true;
        ObservableCollection<CurrentOpeningsResponseData> _tempCurrentOpeningsResponse;
        ObservableCollection<SearchJobsResponseData> _tempSearchJobsResponseData;
        ObservableCollection<RecommendedJobResponseData> _tempRecommendedJobResponseData;
        public ICommand OnCommand { get; set; }

        private HttpCommonService _commonservice { get; set; }
        string PageName;
        public SearchJobsViewModel(INavigation nav, string _pageName)
        {
            Navigation = nav;
            PageName = _pageName;
            OnCommand = new Command<string>(DoOperation);
            _commonservice = new HttpCommonService();
            ProfilePicture = (string)Application.Current.Resources["IconUser"];
            IconFilter = (string)Application.Current.Resources["IconFilter"];
            IsFilterSearchJobs = false;
            IsListview = true;
            FilterCommandParameter = "OnFilter";
            IsSearchJobsStackLayout = true;
            SearchPlaceHolderText = "Search Company";
            SavedSearch = "Select Search";
            Location = "Select Location";
            Skills = "Select Skill";
            WorkType = "Select WorkType";
            if (_pageName == "Current Opennings")
            {
                CurrentOpeningsAPICall();
            }
            else if (_pageName == "Search Jobs")
            {
                SearchJobsAPICall();
            }
            else if (_pageName == "Recommended Jobs")
            {
                RecommendedJobsAPICall();
            }
            MessagingCenter.Subscribe<DynamicListPageViewModel, CommonListItemSource>(this, "SkillForFilterJobs", (sender, arg) =>
            {
                SetFieldValue(arg.fieldType, arg);
            });
            MessagingCenter.Subscribe<DynamicListPageViewModel, CommonListItemSource>(this, "LocationForFilterJobs", (sender, arg) =>
            {
                SetFieldValue(arg.fieldType, arg);
            });
            MessagingCenter.Subscribe<DynamicListPageViewModel, CommonListItemSource>(this, "SavedSearchJobs", (sender, arg) =>
            {
                SetFieldValue(arg.fieldType, arg);
                SearchJobsAPICall();
            });
            MessagingCenter.Subscribe<DynamicListPageViewModel, CommonListItemSource>(this, "Worktype", (sender, arg) =>
            {
                SetFieldValue(arg.fieldType, arg);
            });

        }

        #region SetFieldValue
        public void SetFieldValue(string fieldtype, object fieldvalue)
        {
            try
            {
                #region Skils
                if (fieldtype == Constants.FieldType.Skill)
                {
                    if (MessageStringConstants.IsCurrentCity)
                    {
                        Skills = ((CommonListItemSource)fieldvalue).Title;
                        SkillID = ((CommonListItemSource)fieldvalue).ID;
                    }

                }
                #endregion

                #region Loaction
                else if (fieldtype == Constants.FieldType.PreferredJobLocation)
                {
                    if (MessageStringConstants.IsCurrentCity)
                    {
                        Location = ((CommonListItemSource)fieldvalue).Title;
                        LocationID = ((CommonListItemSource)fieldvalue).ID;
                    }

                }
                #endregion

                #region SavedSearch
                else if (fieldtype == Constants.FieldType.SavedSearch)
                {
                    if (MessageStringConstants.IsCurrentCity)
                    {
                        SavedSearch = ((CommonListItemSource)fieldvalue).Title;
                        SavedSearchID = ((CommonListItemSource)fieldvalue).ID;
                    }

                }
                #endregion

                #region WorkType
                else if (fieldtype == Constants.FieldType.WorkType)
                {
                    if (MessageStringConstants.IsCurrentCity)
                    {
                        WorkType = ((CommonListItemSource)fieldvalue).Title;
                        WorkTypeID = ((CommonListItemSource)fieldvalue).ID;
                    }

                }
                #endregion
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SearchJobsViewModel.SetFieldValue");
            }
        }
        #endregion

        #region DoOperation
        private async void DoOperation(string obj)
        {
            try
            {
                if (obj.Equals("OnFilter"))
                {
                    SavedSearch = "Select Search";
                    Location = "Select Location";
                    Skills = "Select Skill";
                    WorkType = "Select WorkType";
                    SavedSearchID = string.Empty;
                    LocationID = string.Empty;
                    SkillID = string.Empty;
                    WorkTypeID = string.Empty;
                    if (!IsFilterSearchJobs)
                    {
                        IsFilterSearchJobs = true;
                        IsLableViewVisible = false;
                        IsSearchJobsStackLayout = false;
                        IconFilter = (string)Application.Current.Resources["IconClose"];
                    }
                    else
                    {
                        IconFilter = (string)Application.Current.Resources["IconFilter"];
                        IsFilterSearchJobs = false;
                        IsSearchJobsStackLayout = true;
                        IsLableViewVisible = false;
                        IsListview = true;
                        //if (_tempSearchJobsResponseData.Count > 0)
                        //{
                        //    SearchjobsItemSource = _tempSearchJobsResponseData;
                        //}
                        //else
                        //{
                        if (isClicked)
                        {
                            isClicked = false;
                            SearchJobsAPICall();
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                        //}
                    }
                }
                else if (obj.Equals("Clear"))
                {
                    SavedSearch = "Select Search";
                    Location = "Select Location";
                    Skills = "Select Skill";
                    WorkType = "Select WorkType";
                    SavedSearchID = string.Empty;
                    LocationID = string.Empty;
                    SkillID = string.Empty;
                    WorkTypeID = string.Empty;
                    IsLableViewVisible = false;
                }
                else if (obj.Equals("OnFilterApplybtn"))
                {
                    if (isClicked)
                    {
                        isClicked = false;
                        if (SavedSearch.Equals("Select Search") && Location.Equals("Select Location") && Skills.Equals("Select Skill") && WorkType.Equals("Select WorkType"))
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.FilterSearch);
                        }
                        else
                        {
                            SearchJobsAPICall();
                        }

                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                }
                else if (obj.Equals("OnSavedSearch"))
                {
                    if (isClicked)
                    {
                        isClicked = false;
                        bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                        if (isNetworkAvailable)
                        {
                            await Navigation.PushAsync(new DynamicListPage("SearchJobsViewModel", Constants.FieldType.SavedSearch, ""));
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                }
                else if (obj.Equals("OnLocation"))
                {
                    if (isClicked)
                    {
                        isClicked = false;
                        bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                        if (isNetworkAvailable)
                        {
                            await Navigation.PushAsync(new DynamicListPage("SearchJobsViewModel", Constants.FieldType.PreferredJobLocation, ""));
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                }
                else if (obj.Equals("OnSkills"))
                {
                    if (isClicked)
                    {
                        isClicked = false;
                        bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                        if (isNetworkAvailable)
                        {
                            await Navigation.PushAsync(new DynamicListPage("SearchJobsViewModel", Constants.FieldType.Skill, ""));
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                }
                else if (obj.Equals("OnWorkType"))
                {
                    if (isClicked)
                    {
                        isClicked = false;
                        bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                        if (isNetworkAvailable)
                        {
                            await Navigation.PushAsync(new DynamicListPage("SearchJobsViewModel", Constants.FieldType.WorkType, ""));
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                }
            }
            catch (Exception ex)
            {
                SendErrorMessageToServer(ex, "SearchJobsViewModel.DoOperation");
            }
        }
        #endregion


        #region SelectedCommand
        public ICommand SelectedCommand => new Command(async () =>
       {
           if (isClicked)
           {
               bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
               if (isNetworkAvailable)
               {
                   isClicked = false;
                   if (PageName == "Current Opennings")
                   {
                       await Navigation.PushAsync(new JobDetailsViewPage("Current Opennings", SelectedItem.JobPostingId, ItemSource, null, null, null));
                   }
                   else if (PageName == "Search Jobs")
                   {
                       await Navigation.PushAsync(new JobDetailsViewPage("SearchJobs", SearchJobsSelectedItem.JobPostingId, null, SearchjobsItemSource, null, null));
                   }
                   else if (PageName == "Recommended Jobs")
                   {
                       await Navigation.PushAsync(new JobDetailsViewPage("Recommended Jobs", RecommendedJobsSelectedItem.JobPostingId, null, null, RecommendedJobsItemSource, null));
                   }
               }
               else
               {
                   UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
               }
           }
           await Task.Run(async () =>
           {
               await Task.Delay(500);
               isClicked = true;
           });
       });
        #endregion

        #region Private properties 

        private bool _IsListview;
        public bool IsListview
        {
            get { return _IsListview; }
            set { _IsListview = value; OnPropertyChanged(); }
        }
        private string _IconFilter;

        public string IconFilter
        {
            get { return _IconFilter; }
            set { _IconFilter = value; OnPropertyChanged(); }
        }

        private bool _IsFliterSearchJobs;
        public bool IsFilterSearchJobs
        {
            get { return _IsFliterSearchJobs; }
            set { _IsFliterSearchJobs = value; OnPropertyChanged(); }
        }
        private bool _IsSearchJobsStackLayout;
        public bool IsSearchJobsStackLayout
        {
            get { return _IsSearchJobsStackLayout; }
            set { _IsSearchJobsStackLayout = value; OnPropertyChanged(); }
        }
        private string _jobDescription;

        public string JobDescription
        {
            get { return _jobDescription; }
            set { _jobDescription = value; OnPropertyChanged(); }
        }
        private string _FilterCommandParameter;
        public string FilterCommandParameter
        {
            get { return _FilterCommandParameter; }
            set { _FilterCommandParameter = value; OnPropertyChanged(); }
        }

        private string _SavedSearch;
        public string SavedSearch
        {
            get { return _SavedSearch; }
            set { _SavedSearch = value; OnPropertyChanged(); }
        }
        private string _SavedSearchID;
        public string SavedSearchID
        {
            get { return _SavedSearchID; }
            set { _SavedSearchID = value; OnPropertyChanged(); }
        }
        private string _Location;
        public string Location
        {
            get { return _Location; }
            set { _Location = value; OnPropertyChanged(); }
        }
        private string _LocationID;
        public string LocationID
        {
            get { return _LocationID; }
            set { _LocationID = value; OnPropertyChanged(); }
        }

        private string _Skills;
        public string Skills
        {
            get { return _Skills; }
            set { _Skills = value; OnPropertyChanged(); }
        }
        private string _SkillID;
        public string SkillID
        {
            get { return _SkillID; }
            set { _SkillID = value; OnPropertyChanged(); }
        }
        private string _WorkType;
        public string WorkType
        {
            get { return _WorkType; }
            set { _WorkType = value; OnPropertyChanged(); }
        }
        private string _WorkTypeID;
        public string WorkTypeID
        {
            get { return _WorkTypeID; }
            set { _WorkTypeID = value; OnPropertyChanged(); }
        }
        private string _ProfilePicture;

        public string ProfilePicture
        {
            get { return _ProfilePicture; }
            set { _ProfilePicture = value; OnPropertyChanged(); }
        }
        private ObservableCollection<RecommendedJobResponseData> _RecommendedJobsItemSource;
        public ObservableCollection<RecommendedJobResponseData> RecommendedJobsItemSource
        {
            get { return _RecommendedJobsItemSource; }
            set { _RecommendedJobsItemSource = value; OnPropertyChanged(); }
        }

        private ObservableCollection<CurrentOpeningsResponseData> _ItemSource;
        public ObservableCollection<CurrentOpeningsResponseData> ItemSource
        {
            get { return _ItemSource; }
            set { _ItemSource = value; OnPropertyChanged(); }
        }

        private ObservableCollection<SearchJobsResponseData> _SearchjobsItemSource;
        public ObservableCollection<SearchJobsResponseData> SearchjobsItemSource
        {
            get { return _SearchjobsItemSource; }
            set { _SearchjobsItemSource = value; OnPropertyChanged(); }
        }

        private CurrentOpeningsResponseData _SelectedItem;
        public CurrentOpeningsResponseData SelectedItem
        {
            get { return _SelectedItem; }
            set { _SelectedItem = value; OnPropertyChanged(); }
        }

        private RecommendedJobResponseData _RecommendedJobsSelectedItem;
        public RecommendedJobResponseData RecommendedJobsSelectedItem
        {
            get { return _RecommendedJobsSelectedItem; }
            set { _RecommendedJobsSelectedItem = value; OnPropertyChanged(); }
        }
        private SearchJobsResponseData _SearchJobsSelectedItem;
        public SearchJobsResponseData SearchJobsSelectedItem
        {
            get { return _SearchJobsSelectedItem; }
            set { _SearchJobsSelectedItem = value; OnPropertyChanged(); }
        }


        #endregion

        #region Searchbar Controls
        private bool _isVisibleSearchbarCancel;
        public bool IsVisibleSearchbarCancelButton
        {
            get { return _isVisibleSearchbarCancel; }
            set { _isVisibleSearchbarCancel = value; OnPropertyChanged(); }
        }

        private bool _IsLableViewVisible;

        public bool IsLableViewVisible
        {
            get { return _IsLableViewVisible; }
            set { _IsLableViewVisible = value; OnPropertyChanged(); }
        }


        public bool _isEnabledSearchBar;

        public bool isEnabledSearchBar
        {
            set { _isEnabledSearchBar = value; OnPropertyChanged(); }
            get { return _isEnabledSearchBar; }
        }
        public string _SearchText;
        public string SearchText
        {
            set
            {
                _SearchText = value;
                SearchText_TextChanged();
                OnPropertyChanged();
            }
            get { return _SearchText; }
        }
        public Command OnSearchClearCommand => new Command(() =>
        {

            SearchText = string.Empty;


        });
        private string _searchPlaceHolder;
        public string SearchPlaceHolderText
        {
            get { return _searchPlaceHolder; }
            set { _searchPlaceHolder = value; OnPropertyChanged(); }
        }
        private void DynamicSearchPlaceholder()
        {
            SearchPlaceHolderText = "Search Jobs";

        }

        public void SearchText_TextChanged()
        {
            var searchtext = SearchText;
            if (string.IsNullOrEmpty(searchtext))
            {
                SearchPlaceHolderText = "Search Company";
                if (PageName == "Current Opennings")
                {
                    ItemSource = new ObservableCollection<CurrentOpeningsResponseData>(_tempCurrentOpeningsResponse);
                    IsVisibleSearchbarCancelButton = false;

                }
                else if (PageName == "Search Jobs")
                {
                    SearchjobsItemSource = new ObservableCollection<SearchJobsResponseData>(_tempSearchJobsResponseData);
                    IsVisibleSearchbarCancelButton = false;
                }
                else if (PageName == "Recommended Jobs")
                {
                    RecommendedJobsItemSource = new ObservableCollection<RecommendedJobResponseData>(_tempRecommendedJobResponseData);
                    IsVisibleSearchbarCancelButton = false;
                }

                return;
            }

            if (PageName == "Current Opennings")
            {
                IsVisibleSearchbarCancelButton = true;
                var searchresults = _tempCurrentOpeningsResponse.Where((obj) => obj.companyname.ToLower().Contains(searchtext.ToLower()));
                ItemSource = new ObservableCollection<CurrentOpeningsResponseData>(searchresults);

            }
            else if (PageName == "Search Jobs")
            {
                IsVisibleSearchbarCancelButton = true;
                var searchresults = _tempSearchJobsResponseData.Where((obj) => obj.companyname.ToLower().Contains(searchtext.ToLower()));
                SearchjobsItemSource = new ObservableCollection<SearchJobsResponseData>(searchresults);
            }
            else if (PageName == "Recommended Jobs")
            {
                IsVisibleSearchbarCancelButton = true;
                var searchresults = _tempRecommendedJobResponseData.Where((obj) => obj.companyname.ToLower().Contains(searchtext.ToLower()));
                RecommendedJobsItemSource = new ObservableCollection<RecommendedJobResponseData>(searchresults);
            }



        }

        #endregion

        #region Recommended Jobs API call
        private async void RecommendedJobsAPICall()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                #region GenereateSkill Id 
                string Secondaryskillsid = string.Empty;
                if (AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.Secondaryskills != null)
                {
                    int Secondaryskillscount = AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.Secondaryskills.Count;
                    int counter = 0;
                    foreach (var skill in AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.Secondaryskills)
                    {
                        counter++;
                        Secondaryskillsid += skill.ID;
                        if (counter < Secondaryskillscount)
                        {
                            Secondaryskillsid += ",";
                        }
                    }
                }
                #endregion
                ObservableCollection<RecommendedJobResponseData> objCurrentOpeningsResponseData = new ObservableCollection<RecommendedJobResponseData>();
                RecommendedJobsRequest objRecommendedJobsRequestt = new RecommendedJobsRequest();
                objRecommendedJobsRequestt.CandidateHiremeeId = AppPreferences.ActiveToken.HireMeID;
                if (!string.IsNullOrEmpty(Secondaryskillsid))
                {
                    objRecommendedJobsRequestt.CommaSeperatedSecondarySkillId = Secondaryskillsid;
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    objRecommendedJobsRequestt.CommaSeperatedSecondarySkillId = null;
                    isEnabledSearchBar = false;
                    IsLableViewVisible = true;
                    IsListview = false;
                    return;
                }
                objRecommendedJobsRequestt.CompanyName = null;
                
                var statusResult = await _commonservice.PostAsync<RecommendedJobResponse, RecommendedJobsRequest>(APIData.API_BASE_URL + APIMethods.GetRecommendedJobs, objRecommendedJobsRequestt);
                if (statusResult != null)
                {
                    UserDialogs.Instance.HideLoading();
                    if (statusResult.Code == "200")
                    {
                        if (statusResult.RecommendedJobs != null && statusResult.RecommendedJobs.Count > 0)
                        {

                            isEnabledSearchBar = true;
                            IsLableViewVisible = false;
                            IsListview = true;
                            _tempRecommendedJobResponseData = new ObservableCollection<RecommendedJobResponseData>(statusResult.RecommendedJobs);
                            foreach (var item in statusResult.RecommendedJobs)
                            {
                                RecommendedJobResponseData obj = item;
                                obj.description = Regex.Replace(Regex.Replace(item.description.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty); ;
                                if (item.AppliedStatus == "1")
                                {
                                    obj.txtJobApply = "Job applied";
                                }
                                else
                                {
                                    obj.txtJobApply = "Apply";
                                }
                                objCurrentOpeningsResponseData.Add(obj);
                            }
                            RecommendedJobsItemSource = objCurrentOpeningsResponseData;
                        }
                        else
                        {
                            isEnabledSearchBar = false;
                            IsLableViewVisible = true;
                            IsListview = false;
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        IsLableViewVisible = true;
                        IsListview = false;
                        await UserDialogs.Instance.AlertAsync(statusResult.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SearchJobsViewModel.RecommendedJobsAPICall");
            }
        }
        #endregion

        #region Current Openings API call
        private async void CurrentOpeningsAPICall()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                #region GenereateSkill Id 
                string Primaryskillsid = string.Empty;
                if (AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.Primaryskills != null)
                {
                    int Primaryskillscount = AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.Primaryskills.Count;
                    int Primaryskillscountcounter = 0;
                    foreach (var skill in AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.Primaryskills)
                    {
                        Primaryskillscountcounter++;
                        Primaryskillsid += skill.ID;
                        if (Primaryskillscountcounter < Primaryskillscount)
                        {
                            Primaryskillsid += ",";
                        }
                    }
                }
                string Secondaryskillsid = string.Empty;
                if (AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.Secondaryskills != null)
                {
                    int Secondaryskillscount = AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.Secondaryskills.Count;
                    int counter = 0;
                    foreach (var skill in AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.Secondaryskills)
                    {
                        counter++;
                        Secondaryskillsid += skill.ID;
                        if (counter < Secondaryskillscount)
                        {
                            Secondaryskillsid += ",";
                        }
                    }
                }
                #endregion
                ObservableCollection<CurrentOpeningsResponseData> objCurrentOpeningsResponseData = new ObservableCollection<CurrentOpeningsResponseData>();
                CurrentOpeningsRequest objCurrentOpeningsRequest = new CurrentOpeningsRequest();
                objCurrentOpeningsRequest.candidateHiremeeId = AppPreferences.ActiveToken.HireMeID;
                if (!string.IsNullOrEmpty(Primaryskillsid) && !string.IsNullOrEmpty(Secondaryskillsid))
                {
                    objCurrentOpeningsRequest.commaSeperatedSkillId = Primaryskillsid + "," + Secondaryskillsid;
                }
                else if (!string.IsNullOrEmpty(Primaryskillsid))
                {
                    objCurrentOpeningsRequest.commaSeperatedSkillId = Primaryskillsid;
                }
                else if (!string.IsNullOrEmpty(Secondaryskillsid))
                {
                    objCurrentOpeningsRequest.commaSeperatedSkillId = Secondaryskillsid;
                }
                else
                {
                    objCurrentOpeningsRequest.commaSeperatedSkillId = null;
                }
                objCurrentOpeningsRequest.companyName = null;

                var statusResult = await _commonservice.PostAsync<CurrentOpeningsResponse, CurrentOpeningsRequest>(APIData.API_BASE_URL + APIMethods.CurrentOpenings, objCurrentOpeningsRequest);
                if (statusResult != null)
                {
                    UserDialogs.Instance.HideLoading();
                    if (statusResult.code == "200")
                    {
                        if (statusResult.currentOpenings != null && statusResult.currentOpenings.Count > 0)
                        {

                            isEnabledSearchBar = true;
                            IsLableViewVisible = false;
                            IsListview = true;
                            _tempCurrentOpeningsResponse = new ObservableCollection<CurrentOpeningsResponseData>(statusResult.currentOpenings);
                            foreach (var item in statusResult.currentOpenings)
                            {
                                CurrentOpeningsResponseData obj = item;
                                obj.description = Regex.Replace(Regex.Replace(item.description.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty); ;
                                if (item.AppliedStatus == "1")
                                {
                                    obj.txtJobApply = "Job applied";
                                }
                                else
                                {
                                    obj.txtJobApply = "Apply";
                                }
                                objCurrentOpeningsResponseData.Add(obj);
                            }
                            ItemSource = objCurrentOpeningsResponseData;
                        }
                        else
                        {
                            isEnabledSearchBar = false;
                            IsLableViewVisible = true;
                            IsListview = false;
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        IsLableViewVisible = true;
                        IsListview = false;
                        await UserDialogs.Instance.AlertAsync(statusResult.message);
                    }
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SearchJobsViewModel.CurrentOpeningsAPICall");
            }
        }
        #endregion

        #region Search Jobs API call
        private async void SearchJobsAPICall()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();

                ObservableCollection<SearchJobsResponseData> objCurrentOpeningsResponseData = new ObservableCollection<SearchJobsResponseData>();
                SearchJobsRequest objSearchJobsRequest = new SearchJobsRequest();
                objSearchJobsRequest.CandidateHiremeeID = AppSessionData.ActiveToken.HireMeID;
                if (IsFilterSearchJobs)
                {
                    if (!string.IsNullOrEmpty(SavedSearchID))
                    {
                        objSearchJobsRequest.SearchJobHistoryID = SavedSearchID;
                        objSearchJobsRequest.WorkType = string.Empty;
                        objSearchJobsRequest.SkillId = string.Empty;
                        objSearchJobsRequest.Location = string.Empty;
                    }
                    else
                    {
                        objSearchJobsRequest.SearchJobHistoryID = string.Empty;
                        objSearchJobsRequest.SkillId = SkillID;
                        objSearchJobsRequest.Location = LocationID;
                        objSearchJobsRequest.WorkType = WorkTypeID;
                    }
                }
                var statusResult = await _commonservice.PostAsync<SearchJobsResponse, SearchJobsRequest>(APIData.API_BASE_URL + APIMethods.GetSearchJobsList, objSearchJobsRequest);
                if (statusResult != null)
                {
                    UserDialogs.Instance.HideLoading();
                    if (statusResult.Code == "200")
                    {
                        if (statusResult.SearchJobs != null && statusResult.SearchJobs.Count > 0)
                        {
                            if (IsFilterSearchJobs)
                            {
                                IconFilter = (string)Application.Current.Resources["IconFilter"];
                                if (statusResult.SearchJobs != null && statusResult.SearchJobs.Count > 0)
                                {
                                    IsFilterSearchJobs = false;
                                    IsSearchJobsStackLayout = true;
                                    SavedSearchID = string.Empty;
                                    LocationID = string.Empty;
                                    SkillID = string.Empty;
                                    WorkTypeID = string.Empty;
                                }
                                else
                                {
                                    SearchjobsItemSource.Clear();
                                    IsFilterSearchJobs = false;
                                    IsSearchJobsStackLayout = true;
                                    isEnabledSearchBar = false;
                                    IsListview = false;
                                    IsLableViewVisible = true;
                                }
                            }

                            isEnabledSearchBar = true;
                            IsListview = true;
                            IsLableViewVisible = false;
                            _tempSearchJobsResponseData = new ObservableCollection<SearchJobsResponseData>(statusResult.SearchJobs);
                            foreach (var item in statusResult.SearchJobs)
                            {
                                SearchJobsResponseData obj = item;
                                obj.description = Regex.Replace(Regex.Replace(item.description.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty); ;
                                if (item.AppliedStatus == "1")
                                {
                                    obj.txtJobApply = "Job applied";
                                }
                                else
                                {
                                    obj.txtJobApply = "Apply";
                                }
                                objCurrentOpeningsResponseData.Add(obj);
                            }
                            SearchjobsItemSource = objCurrentOpeningsResponseData;
                        }
                        else
                        {
                            isEnabledSearchBar = false;
                            IsLableViewVisible = true;
                            IsListview = false;
                        }
                    }
                    else
                    {

                        UserDialogs.Instance.HideLoading();
                        IsFilterSearchJobs = false;
                        IconFilter = (string)Application.Current.Resources["IconFilter"];
                        IsSearchJobsStackLayout = true;
                        isEnabledSearchBar = false;
                        IsLableViewVisible = true;
                        IsListview = false;
                        //await UserDialogs.Instance.AlertAsync(statusResult.Message);
                    }
                }
                else
                {
                    isEnabledSearchBar = false;
                    IsLableViewVisible = true;
                    IsListview = false;
                }
            }

            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SearchJobsViewModel.SearchJobsAPICall");
            }
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, string ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

    }
}
