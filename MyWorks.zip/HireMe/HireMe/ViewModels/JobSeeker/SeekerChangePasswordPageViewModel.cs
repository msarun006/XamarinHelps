﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using HireMe.Helpers;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;
using static HireMe.Models.JobSeeker.ChangePasswordModel;

namespace HireMe.ViewModels.JobSeeker
{
    public class SeekerChangePasswordPageViewModel : BaseViewModel
    {
        #region Initial Declaration
        public ChangePasswordRequestData changePasswordRequest { get; set; }
        public ICommand ChangePasswordPageCommand { get; set; }
        private HttpCommonService _commonservice { get; set; }
        #endregion

        #region Main Constructor
        public SeekerChangePasswordPageViewModel()
        {
            ChangePasswordPageCommand = new RelayCommand<string>(OnChangePasswordPage);
            OldPasswordLogo = (string)Application.Current.Resources["PasswordSign"];
            NewPasswordLogo = (string)Application.Current.Resources["PasswordSign"];
            ConfirmPasswordLogo = (string)Application.Current.Resources["PasswordSign"];
            OldPasswordVisibleSign = (string)Application.Current.Resources["HidePassword"];
            NewPasswordVisibleSign = (string)Application.Current.Resources["HidePassword"];
            ConfirmPasswordVisibleSign = (string)Application.Current.Resources["HidePassword"];
            isCheckSocialPassword = AppSessionData.ActiveToken.SocialLoginPasswordStatus;
            if (AppSessionData.ActiveToken.UserType == UserType.JobSeeker)
            {
                PasswordTypeHint = "Password must be minimum 6 - 15 characters long";
            }
            else if (AppSessionData.ActiveToken.UserType == UserType.Recruiter)
            {
                PasswordTypeHint = "Password must be combination of upper case, lower case, numbers and special characters";
            }

            IsPasswordOldPassword = true;
            IsPasswordNewPassword = true;
            IsPasswordConfirmPassword = true;
            IsVisibleNewPassword = true;
            IsVisibleOldPassword = true;
            IsVisibleConfirmPassword = true;
            IsVisibleInvalidNotification = false;
            IsVisibleOldInvalidNotification = false;
            IsVisibleMismatchNotification = false;
            changePasswordRequest = new ChangePasswordRequestData();
            _commonservice = new HttpCommonService();
            //  
        }
        #endregion

        #region OnChangePasswordPage Commands
        private async void OnChangePasswordPage(string sender)
        {
            switch (sender)
            {
                case "IsVisibleOldPassword":
                    if (IsPasswordOldPassword == true)
                    {
                        OldPasswordVisibleSign = (string)Application.Current.Resources["ShowPassword"];
                        IsPasswordOldPassword = false;
                    }
                    else
                    {
                        OldPasswordVisibleSign = (string)Application.Current.Resources["HidePassword"];
                        IsPasswordOldPassword = true;
                    }
                    break;
                case "IsVisibleNewPassword":
                    if (IsPasswordNewPassword == true)
                    {
                        NewPasswordVisibleSign = (string)Application.Current.Resources["ShowPassword"];
                        IsPasswordNewPassword = false;
                    }
                    else
                    {

                        NewPasswordVisibleSign = (string)Application.Current.Resources["HidePassword"];
                        IsPasswordNewPassword = true;
                    }
                    break;
                case "IsVisibleConfirmPassword":
                    if (IsPasswordConfirmPassword == true)
                    {
                        ConfirmPasswordVisibleSign = (string)Application.Current.Resources["ShowPassword"];
                        IsPasswordConfirmPassword = false;
                    }
                    else
                    {

                        ConfirmPasswordVisibleSign = (string)Application.Current.Resources["HidePassword"];
                        IsPasswordConfirmPassword = true;
                    }

                    break;
                case "ChangePassword":
                    #region ChangePassword Button Click Event
                    if (AppSessionData.ActiveToken.UserType == UserType.Recruiter)
                    {
                        if (string.IsNullOrEmpty(OldPassword))
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterOldPassword);
                        }
                        else if (!Utilities.IsValidPassword(OldPassword))
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.RecruiterPasswordOLDCriteria);
                        }
                        else if (string.IsNullOrEmpty(NewPassword))
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterNewPassword);
                        }
                        else if (!Utilities.IsValidPassword(NewPassword))
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.RecruiterPasswordNewCriteria);
                        }
                        else if (string.IsNullOrEmpty(ConfirmPassword))
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterConfirmPassword);
                        }
                        else if (!Utilities.IsValidPassword(ConfirmPassword))
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.RecruiterPasswordConfirmCriteria);
                        }
                        else if (NewPassword != ConfirmPassword)
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.PasswordMismatched);
                        }
                        else
                        {
                            PasswordUpdate();
                        }

                    }
                    else if (AppSessionData.ActiveToken.UserType == UserType.JobSeeker)
                    {
                        if (string.IsNullOrEmpty(OldPassword))
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterPassword);
                        }
                        else if (!Utilities.ValidatePassword(OldPassword))
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidLengthPassword);
                        }
                        else if (string.IsNullOrEmpty(NewPassword))
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterPassword);

                        }
                        else if (!Utilities.ValidatePassword(NewPassword))
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidLengthPassword);

                        }

                        else if (string.IsNullOrEmpty(ConfirmPassword))
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterConfirmPassword);

                        }

                        else if (!Utilities.ValidatePassword(ConfirmPassword))
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidLengthPassword);

                        }
                        else if (NewPassword != ConfirmPassword)
                        {

                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.PasswordMismatched);
                        }
                        else
                        {
                            PasswordUpdate();
                        }
                    }



                    #endregion
                    break;



            }
        }
        #endregion

        private async void PasswordUpdate()
        {
            if (isCheckSocialPassword == false)
            {
                try
                {

                    UserDialogs.Instance.ShowLoading();
                    changePasswordRequest.password = isCheckSocialPassword.ToString().ToLower();
                    changePasswordRequest.CurrentPassword = NewPassword;
                    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                    if (isNetworkAvailable)
                    {
                        var result = await _commonservice.PostAsync<ChangePasswordsResponseData, ChangePasswordRequestData>(APIData.API_BASE_URL + APIMethods.ChangePassword, changePasswordRequest);
                        if (result != null)
                        {
                            if (result.code == "200")
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(result.message);
                                //AppPreferences.IsLogout = true;
                                AppPreferences.IsLoggeedIn = false;
                                Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                                return;
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(result.message);
                            }
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                    }
                }
                catch (Exception ex)
                {
                    UserDialogs.Instance.HideLoading();
                    SendErrorMessageToServer(ex, "SeekerChangePasswordPageViewModel.OnChangePasswordPage");
                }
            }

            else
            {
                try
                {
                    UserDialogs.Instance.ShowLoading();
                    changePasswordRequest.OldPassword = OldPassword;
                    changePasswordRequest.password = isCheckSocialPassword.ToString().ToLower();
                    changePasswordRequest.CurrentPassword = NewPassword;

                    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                    if (isNetworkAvailable)
                    {
                        var result = await _commonservice.PostAsync<ChangePasswordsResponseData, ChangePasswordRequestData>(APIData.API_BASE_URL + APIMethods.ChangePassword, changePasswordRequest);
                        if (result != null)
                        {
                            if (result.code == "200")
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(result.message);
                                //AppPreferences.IsLogout = true;
                                AppPreferences.IsLoggeedIn = false;
                                Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                                return;
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(result.message);
                            }
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                    }

                }
                catch (Exception ex)
                {
                    UserDialogs.Instance.HideLoading();
                    SendErrorMessageToServer(ex, "SeekerChangePasswordPageViewModel.OnChangePasswordPage");

                }
            }
        }

        #region UnFocuse  Validation
        private Command<string> tapCommand;
        public Command<string> TapCommand
        {
            get { return tapCommand ?? (tapCommand = new Command<string>(async arg => await OnTappedCommand(arg))); }
        }

        public async Task OnTappedCommand(string sender)
        {
            switch (sender)
            {
                #region  UnFocuse FontAwsome Validation
                case "OldPasswordUnFocused":
                    var oldpassword = OldPassword;
                    if (string.IsNullOrEmpty(oldpassword) || oldpassword.Contains(" "))
                    {
                        OldPasswordRightSign = (string)Application.Current.Resources["WrongSign"];
                        IsVisibleOldPassword = true;
                        TextColorOldPassword = Color.Red;
                        IsVisibleOldInvalidNotification = false;
                    }
                    else if (!Utilities.ValidatePassword(OldPassword))
                    {
                        OldPasswordRightSign = (string)Application.Current.Resources["WrongSign"];
                        IsVisibleOldPassword = true;
                        TextColorOldPassword = Color.Red;
                        IsVisibleOldInvalidNotification = true;
                    }
                    else
                    {
                        OldPasswordRightSign = (string)Application.Current.Resources["RightSign"];
                        IsVisibleOldPassword = true;
                        TextColorOldPassword = Color.Green;
                        IsVisibleOldInvalidNotification = false;
                    }
                    break;
                case "NewPasswordUnFocused":
                    var newpassword = NewPassword;
                    if (string.IsNullOrEmpty(newpassword) || newpassword.Contains(" "))
                    {
                        NewPasswordRightSign = (string)Application.Current.Resources["WrongSign"];
                        IsVisibleNewPassword = true;
                        TextColorNewPassword = Color.Red;
                        IsVisibleInvalidNotification = false;
                    }
                    else
                    {
                        if (!Utilities.ValidatePassword(NewPassword))
                        {
                            NewPasswordRightSign = (string)Application.Current.Resources["WrongSign"];
                            IsVisibleNewPassword = true;
                            TextColorNewPassword = Color.Red;
                            IsVisibleInvalidNotification = true;
                        }
                        else
                        {
                            NewPasswordRightSign = (string)Application.Current.Resources["RightSign"];
                            IsVisibleNewPassword = true;
                            TextColorNewPassword = Color.Green;
                            IsVisibleInvalidNotification = false;
                        }
                    }
                    break;
                case "ConfirmPasswordUnFocused":
                    var password = ConfirmPassword;
                    if (string.IsNullOrEmpty(password) || password.Contains(" "))
                    {
                        ConfirmPasswordRightSign = (string)Application.Current.Resources["WrongSign"];
                        IsVisibleConfirmPassword = true;
                        TextColorConfirmPassword = Color.Red;
                        IsVisibleMismatchNotification = false;
                    }
                    else
                    {
                        if (!NewPassword.Equals(password))
                        {
                            ConfirmPasswordRightSign = (string)Application.Current.Resources["WrongSign"];
                            IsVisibleConfirmPassword = true;
                            TextColorConfirmPassword = Color.Red;
                            IsVisibleMismatchNotification = true;
                        }
                        else
                        {
                            ConfirmPasswordRightSign = (string)Application.Current.Resources["RightSign"];
                            IsVisibleConfirmPassword = true;
                            TextColorConfirmPassword = Color.Green;
                            IsVisibleMismatchNotification = false;
                        }
                    }
                    break;


            }
            #endregion
        }
        #endregion

        #region Binding Properties

        #region Old Password Binding
        private string _oldPasswordlogo;
        public string OldPasswordLogo
        {
            get { return _oldPasswordlogo; }
            set { if (value == _oldPasswordlogo) return; _oldPasswordlogo = value; OnPropertyChanged(); }
        }
        private string _oldPassword;
        public string OldPassword
        {
            get { return _oldPassword; }
            set { if (value == _oldPassword) return; _oldPassword = value; OnPropertyChanged(); }
        }
        private string _oldPasswordRightSign;
        public string OldPasswordRightSign
        {
            get { return _oldPasswordRightSign; }
            set { if (value == _oldPasswordRightSign) return; _oldPasswordRightSign = value; OnPropertyChanged(); }
        }
        private string _oldPasswordVisibleSign;
        public string OldPasswordVisibleSign
        {
            get { return _oldPasswordVisibleSign; }
            set { if (value == _oldPasswordVisibleSign) return; _oldPasswordVisibleSign = value; OnPropertyChanged(); }
        }
        #endregion

        #region New Password Binding
        private string _newPasswordlogo;
        public string NewPasswordLogo
        {
            get { return _newPasswordlogo; }
            set { if (value == _newPasswordlogo) return; _newPasswordlogo = value; OnPropertyChanged(); }
        }
        private string _newPassword;
        public string NewPassword
        {
            get { return _newPassword; }
            set { if (value == _newPassword) return; _newPassword = value; OnPropertyChanged(); }
        }
        private string _newPasswordRightSign;
        public string NewPasswordRightSign
        {
            get { return _newPasswordRightSign; }
            set { if (value == _newPasswordRightSign) return; _newPasswordRightSign = value; OnPropertyChanged(); }
        }
        private string _newPasswordVisibleSign;
        public string NewPasswordVisibleSign
        {
            get { return _newPasswordVisibleSign; }
            set { if (value == _newPasswordVisibleSign) return; _newPasswordVisibleSign = value; OnPropertyChanged(); }
        }

        #endregion

        #region Confirm Password Binding
        private string _confirmPasswordlogo;
        public string ConfirmPasswordLogo
        {
            get { return _confirmPasswordlogo; }
            set { if (value == _confirmPasswordlogo) return; _confirmPasswordlogo = value; OnPropertyChanged(); }
        }
        private string _confirmPassword;
        public string ConfirmPassword
        {
            get { return _confirmPassword; }
            set { if (value == _confirmPassword) return; _confirmPassword = value; OnPropertyChanged(); }
        }
        private string _confirmPasswordRightSign;
        public string ConfirmPasswordRightSign
        {
            get { return _confirmPasswordRightSign; }
            set { if (value == _confirmPasswordRightSign) return; _confirmPasswordRightSign = value; OnPropertyChanged(); }
        }
        private string _confirmPasswordVisibleSign;
        public string ConfirmPasswordVisibleSign
        {
            get { return _confirmPasswordVisibleSign; }
            set { if (value == _confirmPasswordVisibleSign) return; _confirmPasswordVisibleSign = value; OnPropertyChanged(); }
        }

        #endregion

        private bool _isCheckSocialPassword;

        public bool isCheckSocialPassword
        {
            get { return _isCheckSocialPassword; }
            set { _isCheckSocialPassword = value; OnPropertyChanged(); }
        }



        private string _newPasswordHelpText;
        public string NewPasswordHelpText
        {
            get { return _newPasswordHelpText; }
            set { if (value == _newPasswordHelpText) return; _newPasswordHelpText = value; OnPropertyChanged(); }
        }
        private bool _isVisibleInvalidNotification;
        public bool IsVisibleInvalidNotification
        {
            get { return _isVisibleInvalidNotification; }
            set { if (value == _isVisibleInvalidNotification) return; _isVisibleInvalidNotification = value; OnPropertyChanged(); }
        }
        private bool _isVisibleOldInvalidNotification;
        public bool IsVisibleOldInvalidNotification
        {
            get { return _isVisibleOldInvalidNotification; }
            set { if (value == _isVisibleOldInvalidNotification) return; _isVisibleOldInvalidNotification = value; OnPropertyChanged(); }
        }

        private bool _isVisibleMismatchNotification;
        public bool IsVisibleMismatchNotification
        {
            get { return _isVisibleMismatchNotification; }
            set { if (value == _isVisibleMismatchNotification) return; _isVisibleMismatchNotification = value; OnPropertyChanged(); }
        }
        private bool _isPasswordOldPassword;
        public bool IsPasswordOldPassword
        {
            get
            {
                return _isPasswordOldPassword;
            }
            set
            {
                _isPasswordOldPassword = value;
                OnPropertyChanged();
            }
        }
        private bool _isPasswordNewPassword;
        public bool IsPasswordNewPassword
        {
            get
            {
                return _isPasswordNewPassword;
            }
            set
            {
                _isPasswordNewPassword = value;
                OnPropertyChanged();
            }
        }
        private bool _isPasswordConfirmPassword;
        public bool IsPasswordConfirmPassword
        {
            get
            {
                return _isPasswordConfirmPassword;
            }
            set
            {
                _isPasswordConfirmPassword = value;
                OnPropertyChanged();
            }
        }

        private bool _isVisibleOldPassword;
        public bool IsVisibleOldPassword
        {
            get
            {
                return _isVisibleOldPassword;
            }
            set
            {
                _isVisibleOldPassword = value;
                OnPropertyChanged();
            }
        }
        private Color _textColorOldPassword;
        public Color TextColorOldPassword
        {
            get { return _textColorOldPassword; }
            set
            {
                if (value == _textColorOldPassword) return;
                _textColorOldPassword = value;
                OnPropertyChanged();
            }
        }

        private bool _isVisibleNewPassword;
        public bool IsVisibleNewPassword
        {
            get
            {
                return _isVisibleNewPassword;
            }
            set
            {
                _isVisibleNewPassword = value;
                OnPropertyChanged();
            }
        }

        private Color _textColorNewPassword;
        public Color TextColorNewPassword
        {
            get { return _textColorNewPassword; }
            set
            {
                if (value == _textColorNewPassword) return;
                _textColorNewPassword = value;
                OnPropertyChanged();
            }
        }


        private string _passwordTypeHint;

        public string PasswordTypeHint
        {
            get { return _passwordTypeHint; }
            set { _passwordTypeHint = value; OnPropertyChanged(); }
        }


        private bool _isVisibleConfirmPassword;
        public bool IsVisibleConfirmPassword
        {
            get
            {
                return _isVisibleConfirmPassword;
            }
            set
            {
                _isVisibleConfirmPassword = value;
                OnPropertyChanged();
            }
        }

        private Color _textColorConfirmPassword;
        public Color TextColorConfirmPassword
        {
            get { return _textColorConfirmPassword; }
            set
            {
                if (value == _textColorConfirmPassword) return;
                _textColorConfirmPassword = value;
                OnPropertyChanged();
            }
        }

        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
