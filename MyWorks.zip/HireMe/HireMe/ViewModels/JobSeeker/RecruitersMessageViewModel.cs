﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.Models.JobSeeker;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Collections.ObjectModel;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.JobSeeker
{
    public class RecruitersMessageViewModel : BaseViewModel
    {
        private HttpCommonService _commonservice { get; set; }
        public NotificationRequestData NotificationRequestData { get; set; }
        public NotificationResponseData NotificationResponse { get; set; }


        private ObservableCollection<Notification> _ItemSource;
        public ObservableCollection<Notification> ItemSource
        {
            get { return _ItemSource; }
            set { _ItemSource = value; OnPropertyChanged(); }
        }
        INavigation navigation;
        public RecruitersMessageViewModel(INavigation _navigation)
        {

            navigation = _navigation;
            _commonservice = new HttpCommonService();
            NotificationRequestData = new NotificationRequestData();
            NotificationResponse = new NotificationResponseData();

            IsNorecord = false;
            IsListView = true;
            NotificationRequestData.HiremeeID = AppSessionData.ActiveToken.HireMeID;
            NotificationRequestData.Token = AppSessionData.ActiveToken.Token;
            BindRecruitersMessageList();



        }

        private async void BindRecruitersMessageList()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {
                    var result = await _commonservice.PostAsync<NotificationResponseData, NotificationRequestData>(APIData.API_BASE_URL + APIMethods.Profileviewer, NotificationRequestData);
                    if (result != null)
                    {
                        if (result.code == "200")
                        {

                            ProfileViewCount = result.ProfileCount;
                            if (result.notification.Count != 0)
                            {
                                IsNorecord = false;
                                IsListView = true;
                                ItemSource = new ObservableCollection<Notification>(result.notification);
                            }
                            else
                            {
                                IsNorecord = true;
                                IsListView = false;
                            }
                            UserDialogs.Instance.HideLoading();
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            IsNorecord = true;
                            IsListView = false;
                            await UserDialogs.Instance.AlertAsync(result.message);
                        }
                    }
                }
                else
                {
                    IsNorecord = true;
                    IsListView = false;
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "RecruitersMessageViewModel.BindRecruitersMessageList");
            }
        }


        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        private string _ProfileViewCount;
        public string ProfileViewCount
        {
            get { return _ProfileViewCount; }
            set { _ProfileViewCount = value; OnPropertyChanged(); }
        }




        private Notification _SelectedItem;
        public Notification SelectedItem
        {
            get { return _SelectedItem; }
            set { _SelectedItem = value; OnPropertyChanged(); }
        }
        private bool _IsNorecord;

        public bool IsNorecord
        {
            get { return _IsNorecord; }
            set { _IsNorecord = value; OnPropertyChanged(); }
        }
        private bool _IsListView;
        public bool IsListView
        {
            get { return _IsListView; }
            set { _IsListView = value; OnPropertyChanged(); }
        }



        public ICommand SelectedCommand => new Command(() =>
        {
            navigation.PushAsync(new SeekerNotificationDetailPage(SelectedItem));
        });


    }
}
