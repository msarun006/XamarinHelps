﻿using MvvmHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.JobSeeker
{
    public class FilterViewModel : BaseViewModel
    {
        INavigation Navigation;
        public bool isClicked = true;
        public ICommand FocusDatePickerCommand { get; set; }
        public ICommand OnCommand { get; set; }
        string PageName;
        public FilterViewModel(INavigation nav, string pageName)
        {
            Navigation = nav;
            FocusDatePickerCommand = new Command<object>(Onfocus);
            PageName = pageName;
            OnCommand = new Command<string>(DoOperation);
            DatepickerToValue = DateTime.Now.ToString("yyyy-MM-dd");
            DatepickerFromValue = DateTime.Now.ToString("yyyy-MM-dd");
            if (pageName == "CurrentWalkins")
            {
                IsFliterCurrentWalkins = true;
                IsFliterSearchJobs = false;
            }
            else if (pageName == "SearchJobs")
            {
                IsFliterSearchJobs = true;
                IsFliterCurrentWalkins = false;
            }

        }


        private async void DoOperation(string obj)
        {
            try
            {
                if (obj.Equals("Clear"))
                {
                    if (isClicked)
                    {
                        isClicked = false;
                        if (PageName == "CurrentWalkins")
                        {
                            DatepickerToValue = DateTime.Now.ToString("yyyy-MM-dd");
                            DatepickerFromValue = DateTime.Now.ToString("yyyy-MM-dd");
                        }
                        else if (PageName == "SearchJobs")
                        {
                            SavedSearch = "Select Search";
                            Location = "Select Location";
                            Skills = "Select Skill";
                            WorkType = "Select WorkType";
                        }

                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                }
                else if (obj.Equals("OnFilter"))
                {

                }
            }
            catch (Exception ex)
            {

            }
        }

        #region Private Properties
        private bool _IsFliterSearchJobs;
        public bool IsFliterSearchJobs
        {
            get { return _IsFliterSearchJobs; }
            set { _IsFliterSearchJobs = value; OnPropertyChanged(); }
        }
        private bool _IsFliterCurrentWalkins;
        public bool IsFliterCurrentWalkins
        {
            get { return _IsFliterCurrentWalkins; }
            set { _IsFliterCurrentWalkins = value; OnPropertyChanged(); }
        }
        private string _SavedSearch;

        public string SavedSearch
        {
            get { return _SavedSearch; }
            set { _SavedSearch = value; OnPropertyChanged(); }
        }
        private string _Location;

        public string Location
        {
            get { return _Location; }
            set { _Location = value; OnPropertyChanged(); }
        }
        private string _Skills;

        public string Skills
        {
            get { return _Skills; }
            set { _Skills = value; OnPropertyChanged(); }
        }
        private string _WorkType;

        public string WorkType
        {
            get { return _WorkType; }
            set { _WorkType = value; OnPropertyChanged(); }
        }
        #endregion

        #region Date Picker
        private string _datepickerFromValue;
        public string DatepickerFromValue
        {
            get { return _datepickerFromValue; }
            set
            {
                _datepickerFromValue = value;
                OnPropertyChanged();
            }
        }
        private string _datepickerToValue;
        public string DatepickerToValue
        {
            get { return _datepickerToValue; }
            set
            {
                _datepickerToValue = value;

                OnPropertyChanged();
            }
        }
        private void Onfocus(object obj)
        {
            var datepicker = (DatePicker)obj;
            datepicker.Focus();
        }
        private Command<object> todatechagedcommand;
        public Command<object> ToDateChangedCommand
        {
            get { return todatechagedcommand ?? (todatechagedcommand = new Command<object>(async arg => await OnToDateChangedCommand(arg))); }
        }

        private Command<object> fromdatechagedcommand;
        public Command<object> FromDateChangedCommand
        {
            get { return fromdatechagedcommand ?? (fromdatechagedcommand = new Command<object>(async arg => await OnFromDateChangedCommand(arg))); }
        }
        private async Task OnToDateChangedCommand(object sender)
        {

            var datepicker = (DatePicker)sender;
            DatepickerToValue = datepicker.Date.ToString("yyyy-MM-dd");


        }
        private async Task OnFromDateChangedCommand(object sender)
        {

            var datepicker = (DatePicker)sender;
            DatepickerFromValue = datepicker.Date.ToString("yyyy-MM-dd");
        }
        #endregion
    }
}
