﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using HireMe.Models.JobSeeker;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Windows.Input;
using Xamarin.Forms;
using HireMe.Models.Recruiter;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using HireMe.Helpers;

namespace HireMe.ViewModels.JobSeeker
{
    public class SchoolEducationDetailsViewModel : BaseViewModel
    {
        #region Initialization
        public bool isClicked = true;
        public ICommand OnCommand { get; set; }
        SchoolEducationRequest objSchoolEducationRequest;
        private HttpCommonService _commonservice { get; set; }
        INavigation Navigation;
        Educational_Details objBindSchoolEducationDetails;
        ObservableCollection<Educational_Details> SchoolEducationListItemSourse;

        bool isEditMode = false;
        #endregion

        #region Constructor
        #region Constructor from Add New Education Details
        public SchoolEducationDetailsViewModel(INavigation nav, ObservableCollection<Educational_Details> itemsource, string courseid)
        {
            MessageStringConstants.IsSchoolOrCollegeDetailsUpdated = false;
            Navigation = nav;
            objSchoolEducationRequest = new SchoolEducationRequest();
            _commonservice = new HttpCommonService();
            OnCommand = new RelayCommand<string>(DoOpration);
            BindEducationalDetailsToView();
            CourseTypeID = courseid;
            MessagingCenter.Subscribe<DynamicListPageViewModel, CommonListItemSource>(this, "SeekerPersonalandEducational", (sender, arg) =>
            {
                SetFieldValue(arg.fieldType, arg);
            });
            if (itemsource == null)
            {
                SchoolEducationListItemSourse = new ObservableCollection<Educational_Details>();
            }
            else
            {
                SchoolEducationListItemSourse = itemsource;
            }
        }
        #endregion

        #region Constructor from Item Tapped to Edit Screen
        public SchoolEducationDetailsViewModel(INavigation nav, ObservableCollection<Educational_Details> itemsource, Educational_Details selectedItem)
        {
            MessageStringConstants.IsSchoolOrCollegeDetailsUpdated = false;
            Navigation = nav;
            objSchoolEducationRequest = new SchoolEducationRequest();
            objBindSchoolEducationDetails = selectedItem;
            CourseType = objBindSchoolEducationDetails.course_type_name;
            CourseTypeID = objBindSchoolEducationDetails.coursetype_id;
            OnCommand = new RelayCommand<string>(DoOpration);
            BindEducationalDetailsToView();
            _commonservice = new HttpCommonService();
            MessagingCenter.Subscribe<DynamicListPageViewModel, CommonListItemSource>(this, "SeekerPersonalandEducational", (sender, arg) =>
            {
                SetFieldValue(arg.fieldType, arg);
            });
            if (itemsource == null)
            {
                isEditMode = false;
                SchoolEducationListItemSourse = new ObservableCollection<Educational_Details>();
            }
            else
            {
                isEditMode = true;
                SchoolEducationListItemSourse = itemsource;
            }
        }
        #endregion
        #endregion

        #region  Command operations
        private async void DoOpration(string obj)
        {
            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
            switch (obj)
            {
                #region School Education Details
                case "OnYearOfCompletionItemTapped":
                    if (isClicked)
                    {
                        isClicked = false;
                        if (isNetworkAvailable)
                        {
                            if (!string.IsNullOrEmpty(SchoolYearOfPassing))
                            {
                                await Navigation.PushAsync(new DynamicListPage("SeekerPersonalandEducational", Constants.FieldType.YearOfCompletion, ""));
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                case "OnSchoolBoardType":
                    if (isClicked)
                    {
                        isClicked = false;

                        if (isNetworkAvailable)
                        {
                            if (!string.IsNullOrEmpty(BoardTypeName))
                            {
                                await Navigation.PushAsync(new DynamicListPage("SeekerPersonalandEducational", Constants.FieldType.BoardName, ""));
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                case "OnPermanentStateItemTapped":
                    if (isClicked)
                    {
                        isClicked = false;

                        if (isNetworkAvailable)
                        {
                            NavigateToDynamicListPage(Constants.FieldType.State, "");
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                case "OnPermanentCityItemTapped":
                    if (isClicked)
                    {
                        isClicked = false;
                        if (isNetworkAvailable)
                        {
                            if (string.IsNullOrEmpty(StateID))
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectState);
                            }

                            else
                            {
                                NavigateToDynamicListPage(Constants.FieldType.City, StateID);
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                #region Save API Call
                case "SaveSchoolEducationalDetails":
                    if (isClicked)
                    {
                        isClicked = false;
                        if (isNetworkAvailable)
                        {
                            if (!ValidateSchoolEducationalDetails())
                            {
                                return;
                            }
                            else
                            {
                                try
                                {

                                    if (string.IsNullOrEmpty(RegisterNumber))
                                    {
                                        SaveDetailsAPI();
                                    }
                                    if (!string.IsNullOrEmpty(RegisterNumber))
                                    {
                                        int nameLength = RegisterNumber.Trim().Length;
                                        if (nameLength < 6 || !Utilities.ValidateRegisterNumber(RegisterNumber))
                                        {
                                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidRegisterNumber);  
                                        }
                                        else
                                        {
                                            SaveDetailsAPI();
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    System.Diagnostics.Debug.WriteLine(ex.Message);
                                    SendErrorMessageToServer(ex, "SchoolEducationDetailsViewModel.DoOpration");
                                }
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                    #endregion
                    #endregion
            }

        }
        #endregion



        private async void SaveDetailsAPI()
        {
            try
            {

                UserDialogs.Instance.ShowLoading();
                var response = await _commonservice.PostAsync<EducaionalDetailsResponseData, SchoolEducationRequest>(APIData.API_BASE_URL + APIMethods.AddSchoolEducationDetails, objSchoolEducationRequest);
                if (response != null)
                {
                    if (response.code == "200")
                    {
                        UserDialogs.Instance.HideLoading();
                        MessageStringConstants.IsSchoolOrCollegeDetailsUpdated = true;
                        await UserDialogs.Instance.AlertAsync(response.message);
                        int stacklength = Navigation.NavigationStack.Count;
                        if (!isEditMode)
                            Navigation.RemovePage(Navigation.NavigationStack[stacklength - 1]);
                        await Navigation.PopAsync();
                    }
                    else if (response.code == "199")
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.SessionExpiered);
                        Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                        return;
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(response.message);
                    }
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SchoolEducationDetailsViewModel.SaveDetailsAPI");
            }
        }

        #region Set Field Values
        public void SetFieldValue(string fieldtype, object fieldvalue)
        {
            if (fieldtype == Constants.FieldType.YearOfCompletion)
            {
                //_educationdetails.YearOfCompletion = ((CommonListItemSource)fieldvalue).Title;
                SchoolYearOfPassing = ((CommonListItemSource)fieldvalue).Title;
                objSchoolEducationRequest.schoolYearOfPassing = ((CommonListItemSource)fieldvalue).Title;
                SchoolYearOfPassing = ((CommonListItemSource)fieldvalue).Title;
            }
            if (fieldtype == Constants.FieldType.BoardName)
            {
                //_educationdetails.YearOfCompletion = ((CommonListItemSource)fieldvalue).Title;
                BoardTypeName = ((CommonListItemSource)fieldvalue).Title;
                BoardTypeID = ((CommonListItemSource)fieldvalue).ID;
            }
            else if (fieldtype == Constants.FieldType.State)
            {
                if (State != ((CommonListItemSource)fieldvalue).Title)
                {
                    City = "Select City";
                }
                State = ((CommonListItemSource)fieldvalue).Title;
                StateID = ((CommonListItemSource)fieldvalue).ID;

            }
            else if (fieldtype == Constants.FieldType.City)
            {
                City = ((CommonListItemSource)fieldvalue).Title;
                CityID = ((CommonListItemSource)fieldvalue).ID;

            }
        }
        #endregion

        #region NavigateToDynamicListPage
        public async void NavigateToDynamicListPage(string _fieldType, string _fieldValue)
        {
            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
            if (isNetworkAvailable)
            {
                await Navigation.PushAsync(new DynamicListPage("SeekerPersonalandEducational", _fieldType, _fieldValue));
            }
            else
            {
                UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
            }
        } 
        #endregion

        #region Bind Schoool EducationalDetailsToView
        public void BindEducationalDetailsToView()
        {
            #region BindEducation Details
            if (objBindSchoolEducationDetails != null)
            {
                BoardTypeName = objBindSchoolEducationDetails.board_name;
                SchoolName = objBindSchoolEducationDetails.school_name;
                SchoolZipcode = objBindSchoolEducationDetails.zip_code;
                SchoolEntryPercentage = objBindSchoolEducationDetails.percentage;
                SchoolYearOfPassing = objBindSchoolEducationDetails.year_of_completion;
                CourseTypeID = objBindSchoolEducationDetails.coursetype_id;
                BoardTypeID = objBindSchoolEducationDetails.board_id;
                RegisterNumber = objBindSchoolEducationDetails.registerNo;
            }
            else
            {
                BoardTypeName = MessageStringConstants.SelectBoardType;
                SchoolName = string.Empty;
                SchoolZipcode = string.Empty;
                SchoolEntryPercentage = string.Empty;
                RegisterNumber = string.Empty;
                SchoolYearOfPassing = MessageStringConstants.SelectYearOfCompletion;
                State = MessageStringConstants.SelectState;
                City = MessageStringConstants.SelectCity;
            }
            #endregion
        }

        #endregion

        #region ValidateSchoolEducationalDetails
        bool ValidateSchoolEducationalDetails()
        {
            bool isvalid = false;
            if (BoardTypeName == MessageStringConstants.SelectBoardType || string.IsNullOrEmpty(BoardTypeName))
            {
                Device.BeginInvokeOnMainThread(async () =>
                {
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectBoardType);
                }); return isvalid;
            }
            if (SchoolName == MessageStringConstants.SelectSchoolName || string.IsNullOrEmpty(SchoolName))
            {
                Device.BeginInvokeOnMainThread(async () =>
                {
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectSchoolName);
                }); return isvalid;
            }
           
            if (string.IsNullOrEmpty(SchoolZipcode) || !Utilities.ValidatePincode(SchoolZipcode))
            {
                Device.BeginInvokeOnMainThread(async () =>
                {
                    await UserDialogs.Instance.AlertAsync("Enter Valid Pincode");
                    SchoolZipcode = string.Empty;
                }); return isvalid;
            }

            if ((string.IsNullOrEmpty(SchoolEntryCGPA) || SchoolEntryCGPA == "0.00") && (string.IsNullOrEmpty(SchoolEntryPercentage) || SchoolEntryPercentage == "0.00") || (SchoolEntryCGPA == "0" || SchoolEntryCGPA == "00.00" || SchoolEntryCGPA == "0.0" || SchoolEntryCGPA == "00.0" || SchoolEntryCGPA == "00" || SchoolEntryPercentage == "0" || SchoolEntryPercentage == "00" || SchoolEntryPercentage == "00.0" || SchoolEntryPercentage == "0.0" || SchoolEntryPercentage == "00.00"))

            {
                Device.BeginInvokeOnMainThread(async () =>
                {
                    await UserDialogs.Instance.AlertAsync("Enter valid Percentage");
                });
                return isvalid;
            }
            if (SchoolYearOfPassing == MessageStringConstants.SelectYearOfCompletion || string.IsNullOrEmpty(SchoolYearOfPassing) || objSchoolEducationRequest.schoolYearOfPassing == "0000")
            {
                Device.BeginInvokeOnMainThread(async () =>
                {
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectYearOfCompletion);
                }); return isvalid;
            }

            isvalid = true;
            if (isvalid)
            {
                //objSchoolEducationRequest.Token = AppPreferences.ActiveToken.Token;
                //objSchoolEducationRequest.HiremeeID = AppPreferences.HireMeeID;
                objSchoolEducationRequest.SchoolCourseTypeID = CourseTypeID;
                objSchoolEducationRequest.SchoolBoardTypeID = BoardTypeID;
                objSchoolEducationRequest.SchoolName = SchoolName;
                objSchoolEducationRequest.SchoolZipCode = SchoolZipcode;
                objSchoolEducationRequest.SchoolPercentage = SchoolEntryPercentage;
                objSchoolEducationRequest.schoolYearOfPassing = SchoolYearOfPassing;
                objSchoolEducationRequest.registerNo = RegisterNumber;
            }
            return isvalid;

        }
        #endregion

        #region School Private Properties

        private string _RegisterNumber;
        public string RegisterNumber
        {
            get { return _RegisterNumber; }
            set
            {
                _RegisterNumber = value;
                OnPropertyChanged();
            }
        }

        private string _courseType;
        public string CourseType
        {
            get { return _courseType; }
            set
            {
                _courseType = value;
                OnPropertyChanged();
            }
        }
        private string _courseTypeid;
        public string CourseTypeID
        {
            get { return _courseTypeid; }
            set
            {
                _courseTypeid = value;
                OnPropertyChanged();
            }
        }
        private string _boardtypeID;
        public string BoardTypeID
        {
            get { return _boardtypeID; }
            set
            {
                _boardtypeID = value;
                OnPropertyChanged();
            }
        }

        private string _state;
        public string State
        {
            get { return _state; }
            set
            {
                _state = value;
                OnPropertyChanged();
            }
        }
        private string _stateID;
        public string StateID
        {
            get { return _stateID; }
            set
            {
                _stateID = value;
                OnPropertyChanged();
            }
        }
        private string _city;
        public string City
        {
            get { return _city; }
            set
            {
                _city = value;
                OnPropertyChanged();
            }
        }
        private string _cityID;
        public string CityID
        {
            get { return _cityID; }
            set
            {
                _cityID = value;
                OnPropertyChanged();
            }
        }
        private string _boardTypeName;
        public string BoardTypeName
        {
            get { return _boardTypeName; }
            set { _boardTypeName = value; OnPropertyChanged(); }
        }
        private string _schoolName;
        public string SchoolName
        {
            get { return _schoolName; }
            set { _schoolName = value; OnPropertyChanged(); }
        }

        private string _schoolZipcode;
        public string SchoolZipcode
        {
            get { return _schoolZipcode; }
            set { _schoolZipcode = value; OnPropertyChanged(); }
        }
        private string _schoolEntryCGPA;
        public string SchoolEntryCGPA
        {
            get { return _schoolEntryCGPA; }
            set { _schoolEntryCGPA = value; OnPropertyChanged(); }
        }
        private string _schoolEntryPercentage;
        public string SchoolEntryPercentage
        {
            get { return _schoolEntryPercentage; }
            set { _schoolEntryPercentage = value; OnPropertyChanged(); }
        }
        private string _SchoolYearOfPassing;
        private Educational_Details selectedItem;

        public string SchoolYearOfPassing
        {
            get { return _SchoolYearOfPassing; }
            set { _SchoolYearOfPassing = value; OnPropertyChanged(); }
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
