﻿
using MvvmHelpers;
using System;

using Xamarin.Forms;
using Acr.UserDialogs;


namespace HireMe
{
    public class LanguageOptionViewModel : BaseViewModel
	{
		int isReadChecked = 0;
		int isWriteChecked = 0;
		int isSpeakChecked = 0;
		private Languageknown _strLanguage;
		INavigation Navigation;
		public LanguageOptionViewModel(INavigation navigation, Languageknown language)
		{
			_strLanguage = language;
			Navigation = navigation;
			OnButtonClicked = new Command(Btn_apply_Clicked);

			isReadChecked = 0;
			isWriteChecked = 0;
			isSpeakChecked = 0;
			ReadCheckBoxText = (string)Application.Current.Resources["CheckBoxUnSelected"];
			WriteCheckBoxText = (string)Application.Current.Resources["CheckBoxUnSelected"];
			SpeakCheckBoxText = (string)Application.Current.Resources["CheckBoxUnSelected"];

			OnCheckBoxClicked = new Command(CommonFunction);
		}

		void CommonFunction(object obj)
		{




			if (obj.ToString() == "1")
			{


				if (isReadChecked == 0)
				{
					ReadCheckBoxText = (string)Application.Current.Resources["CheckBoxSelected"];
					isReadChecked = 1;

				}
				else if (isReadChecked == 1)
				{
					ReadCheckBoxText = (string)Application.Current.Resources["CheckBoxUnSelected"];
					isReadChecked = 0;

				}



			}
			else if (obj.ToString() == "2")
			{

				if (isWriteChecked == 0)
				{
					WriteCheckBoxText = (string)Application.Current.Resources["CheckBoxSelected"];
					isWriteChecked = 1;

				}
				else if (isWriteChecked == 1)
				{
					WriteCheckBoxText = (string)Application.Current.Resources["CheckBoxUnSelected"];
					isWriteChecked = 0;

				}

			}
			else if (obj.ToString() == "3")
			{
				if (isSpeakChecked == 0)
				{
					SpeakCheckBoxText = (string)Application.Current.Resources["CheckBoxSelected"];
					isSpeakChecked = 1;

				}
				else if (isSpeakChecked == 1)
				{
					SpeakCheckBoxText = (string)Application.Current.Resources["CheckBoxUnSelected"];
					isSpeakChecked = 0;

				}


			}



		}

		public Command OnCheckBoxClicked
		{
			get;
			set;
		}


		public string readCheckBoxText;
		public string ReadCheckBoxText
		{
			get { return readCheckBoxText; }
			set { readCheckBoxText = value; OnPropertyChanged(); }
		}


		public string writeCheckBoxText;
		public string WriteCheckBoxText
		{
			get { return writeCheckBoxText; }
			set { writeCheckBoxText = value; OnPropertyChanged(); }
		}


		public string speakCheckBoxText;
		public string SpeakCheckBoxText
		{
			get { return speakCheckBoxText; }
			set { speakCheckBoxText = value; OnPropertyChanged(); }
		}




		public Boolean _ReadCheckBox;
		public Boolean ReadCheckBox
		{
			get { return _ReadCheckBox; }
			set { _ReadCheckBox = value; OnPropertyChanged(); }
		}


		public Boolean _WriteCheckBox;
		public Boolean WriteCheckBox
		{
			get { return _WriteCheckBox; }
			set { _WriteCheckBox = value; OnPropertyChanged(); }
		}


		public Boolean _SpeakheckBox;
		public Boolean SpeakheckBox
		{
			get { return _SpeakheckBox; }
			set { _SpeakheckBox = value; OnPropertyChanged(); }
		}


		public Command OnButtonClicked
		{
			get;
			set;
		}

		private async void Btn_apply_Clicked(object arg)
		{
			if (arg.ToString() == "cancel")
			{
				//if (isReadChecked == 0 && isSpeakChecked == 0 && isWriteChecked == 0)
				//{
					
				//}
				_strLanguage.IsRead = 0;
					_strLanguage.IsSpeak = 0;
					_strLanguage.IsWrite = 0;
					_strLanguage.IsSelected = false;
				await Navigation.PopAsync();
			}
			else if (arg.ToString() == "save")
			{
				if (isReadChecked == 0 && isSpeakChecked == 0 && isWriteChecked == 0)
				{
					await UserDialogs.Instance.AlertAsync("Atleast Select One Language Skill","HireMee", "OK");
                    //await DisplayAlert("Info", "Atleast Select One Language Skill","");
                }
				else
				#region  Language Selection
				{
					string strLanguageTitle = _strLanguage.Title;
					bool isSelected = _strLanguage.IsSelected;

					_strLanguage.IsRead = isReadChecked;
					_strLanguage.IsWrite = isWriteChecked;
					_strLanguage.IsSpeak = isSpeakChecked;

                    _strLanguage.LanguageID = _strLanguage.ID;
					await Navigation.PopAsync();
				}
			}
			#endregion
		}
	}
}
