﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using HireMe.DataLayer.Models;
using HireMe.Helpers;
using HireMe.Models;
using HireMe.Models.JobSeeker;
using HireMe.Models.Recruiter;
using HireMe.Renderers;
using HireMe.Services;
using HireMe.Views;
using HireMe.Views.JobSeeker;
using HireMe.Views.Recruiter;
using MvvmHelpers;
using Plugin.Connectivity;
using Plugin.Media;
using Plugin.Media.Abstractions;
using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.JobSeeker
{
    #region IValueGetter
    public interface IValueGetter
    {
        void SetFieldValue(string fieldtype, object fieldvalue);
    }
    #endregion
    public class SeekerPersonalAndEducationViewModel : BaseViewModel, IValueGetter
    {
        #region variable declaration

        public Command OnGenderClicked { get; set; }
        public Command OnHandicappedClicked { get; set; }
        public ICommand FocusDatePickerCommand { get; set; }
        public ICommand OnSaveCommand { get; set; }
        private HttpCommonService _commonservice { get; set; }

        public INavigation _navigationservice;

        bool _isPersonalDetailsUpdated, _isEducationDetailsUpdated;
        public bool isClicked = true;


        private List<string> _courseTypeID;
        List<Languageknown> _selectionLanguages;
        List<JobLocation> _selectionJobLocation;
        List<Skill> _selectedPrimarySkills;
        List<Skill> _selectedSecondarySkills;
        ObservableCollection<CertificationDetails> certifications;

        #endregion

        #region constrotor
        public SeekerPersonalAndEducationViewModel(INavigation nav, StackLayout dynamic_StackLayout_SchoolorCollege, ScrollView PrimarySkillsCustomScrollView, StackLayout PrimarySkillsStackLayout, ScrollView SecondarySkillsCustomScrollView, StackLayout SecondarySkillsStackLayout, ScrollView CertificateCustomScrollView, StackLayout CertificateStackLayout)
        {
            _navigationservice = nav;

            ItemSource = new ObservableCollection<Educational_Details>();
            _selectedPrimarySkills = new List<Skill>();
            _selectedSecondarySkills = new List<Skill>();
            certifications = new ObservableCollection<CertificationDetails>();

            StackLayout_SchoolorCollege = dynamic_StackLayout_SchoolorCollege;
            DisplayPrimarySkillsCustomScrollView = PrimarySkillsCustomScrollView;
            DisplayPrimarySkillsStackLayout = PrimarySkillsStackLayout;
            DisplaySecondarySkillsCustomScrollView = SecondarySkillsCustomScrollView;
            DisplaySecondarySkillsStackLayout = SecondarySkillsStackLayout;
            DisplayCertificateCustomScrollView = CertificateCustomScrollView;
            DisplayCertificateStackLayout = CertificateStackLayout;

            OnGenderClicked = new Command(GenderClicked);
            OnHandicappedClicked = new Command(HandicappedClicked);
            OnSaveCommand = new RelayCommand<string>(OnsaveDetails);
            FocusDatePickerCommand = new RelayCommand<object>(Onfocus);
            _commonservice = new HttpCommonService();

            IsvisibleEmptyCertificateMessage = true;
            IsPersonalGrid = true;
            IsEducationGrid = false;
            ISChecAadharStatus = false;
            ISCheckPassportStatus = false;
            IsEnableToggleSameAddress = true;
            IsdobFocus = false;
            DatepickerValue = "Date of Birth";

            CheckBoxMale = (string)Application.Current.Resources["RadioButtonUnchecked"];
            CheckBoxFeMale = (string)Application.Current.Resources["RadioButtonUnchecked"];
            IsEntryPercentage = true;
            IsEntryCGPA = true;

            HandicappedData = string.Empty;
            HandicappedYes = (string)Application.Current.Resources["CircleUnSelected"];
            HandicappedNo = (string)Application.Current.Resources["CircleUnSelected"];

            Gender = string.Empty;
            BindingFeMaleText = (string)Application.Current.Resources["CircleUnSelected"];
            BindingMaleText = (string)Application.Current.Resources["CircleUnSelected"];

            if (AppPreferences.IsProfileCompleted)
            {
                IsCameraVisible = false;
            }

            MessagingCenter.Subscribe<DynamicListPageViewModel, CommonListItemSource>(this, "SeekerPersonalandEducational", (sender, arg) =>
{
    SetFieldValue(arg.fieldType, arg);
});

            MessagingCenter.Subscribe<MultipleLanguageSelectionPageViewModel, List<Languageknown>>(this, "Language", (sender, arg) =>
            {
                SetFieldValue(Constants.FieldType.Languages, arg);
            });

            MessagingCenter.Subscribe<MultipleSkillsSelectionViewModel, List<Skill>>(this, "UpdatePrimarySkill", (sender, arg) =>
            {
                SetFieldValue(Constants.FieldType.PrimarySkill, arg);
            });

            MessagingCenter.Subscribe<MultipleSkillsSelectionViewModel, List<Skill>>(this, "UpdateSecondarySkill", (sender, arg) =>
            {
                SetFieldValue(Constants.FieldType.SecondarySkill, arg);
            });

            MessagingCenter.Subscribe<MultipleJobLocationSelectionViewModel, List<JobLocation>>(this, "SeekerPersonalandEducational_PreferredJobLocation", (sender, arg) =>
            {
                SetFieldValue(Constants.FieldType.PreferredJobLocation, arg);
            });
            MessagingCenter.Subscribe<ChangeProfilePictrurePageViewModel, string>(this, "ChangeProfilePicture", (sender, arg) =>
            {
                profilepic = arg ?? (string)Application.Current.Resources["IconUser"];
            });
            MessagingCenter.Subscribe<EditBasicDetailsViewModel, string[]>(this, "UpdateBasicDetails", (sender, arg) =>
            {
                FullName = arg[0].ToUpper() + " " + arg[1].ToUpper();
                MobileNo = arg[2];
                SeekerDashboardResponseModel.ProfileDetails.FirstName = arg[0];
                SeekerDashboardResponseModel.ProfileDetails.LastName = arg[1];
                SeekerDashboardResponseModel.ProfileDetails.MobileNumber = arg[2];
            });
        }
        #endregion

        #region GeneratePrimarySkills
        public void GeneratePrimarySkills(List<Skill> _selectedPrimarySkills)
        {
            try
            {
                DisplayPrimarySkillsStackLayout.Children.Clear();

                if (_selectedPrimarySkills.Count != 0)
                {
                    PrimarySkills = string.Empty;
                    PrimarySkillsID = string.Empty;

                    // int childrenCount = DynamicLabelStack.Children.Count;

                    Grid grid = new Grid();
                    grid.VerticalOptions = LayoutOptions.Start;
                    grid.HorizontalOptions = LayoutOptions.Fill;
                    //grid.Padding = new Thickness(5,5,5,5);
                    //grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                    grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                    //grid.RowDefinitions.Add(new RowDefinition { Height = 40 });

                    //This below stacklayout used for padding space and background color
                    StackLayout stackLayoutBackground = new StackLayout();

                    //This below label used for display a each skill
                    //Label lblSkillText = new Label();

                    //int count = 0;
                    //for (int r = 0; r < 1; r++)
                    //{
                    for (int c = 0; c < _selectedPrimarySkills.Count; c++)
                    {
                        //if (NoOfRows > count)
                        //{

                        if (Device.Idiom == TargetIdiom.Phone)
                        {
                            stackLayoutBackground = new StackLayout
                            {
                                BackgroundColor = Color.FromHex("#c2c99c"),
                                Padding = 8,
                                Margin = 3,
                                HorizontalOptions = LayoutOptions.Fill,
                                VerticalOptions = LayoutOptions.Fill,
                            };

                            Label lblSkillText = new Label
                            {
                                Text = _selectedPrimarySkills[c].SkillName,
                                TextColor = Color.Black,
                                ClassId = c.ToString(),
                                FontSize = 13,
                                HorizontalTextAlignment = TextAlignment.Center,
                                VerticalTextAlignment = TextAlignment.Center,
                                HorizontalOptions = LayoutOptions.CenterAndExpand,
                                VerticalOptions = LayoutOptions.CenterAndExpand,
                                WidthRequest = 120,
                            };
                            stackLayoutBackground.Children.Add(lblSkillText);

                            PrimarySkills = (PrimarySkills == "" ? _selectedPrimarySkills[c].SkillName : PrimarySkills + ',' + _selectedPrimarySkills[c].SkillName);
                            PrimarySkillsID = (PrimarySkillsID == "" ? _selectedPrimarySkills[c].ID : PrimarySkillsID + ',' + _selectedPrimarySkills[c].ID);

                        }

                        //gridbutton.SetBinding(Button.BackgroundColorProperty, "ButtonColor" + gridbutton.Text);
                        //gridbutton.Clicked += Button_Clicked;
                        grid.Children.Add(stackLayoutBackground);
                        Grid.SetRow(stackLayoutBackground, 0);//r
                        Grid.SetColumn(stackLayoutBackground, c);

                        DisplayPrimarySkillsStackLayout.Children.Add(grid);
                        Device.BeginInvokeOnMainThread(async () =>
                        {
                            await DisplayPrimarySkillsCustomScrollView.ScrollToAsync(0, 0, true);
                        });
                    }
                }
                else
                {
                    PrimarySkills = string.Empty;
                    PrimarySkillsID = string.Empty;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.GeneratePrimarySkills");
            }
        }
        #endregion

        #region GenerateSecondarySkills
        public void GenerateSecondarySkills(List<Skill> _selectedSecondarySkills)
        {
            try
            {
                DisplaySecondarySkillsStackLayout.Children.Clear();

                if (_selectedSecondarySkills.Count != 0)
                {
                    SecondarySkills = string.Empty;
                    SecondarySkillsID = string.Empty;
                    // int childrenCount = DynamicLabelStack.Children.Count;


                    Grid grid = new Grid();
                    grid.VerticalOptions = LayoutOptions.Start;
                    grid.HorizontalOptions = LayoutOptions.Fill;
                    //grid.Padding = new Thickness(5,5,5,5);
                    //grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                    grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
                    //grid.RowDefinitions.Add(new RowDefinition { Height = 40 });

                    //This below stacklayout used for padding space and background color
                    StackLayout stackLayoutBackground = new StackLayout();

                    //This below label used for display a each skill
                    //Label lblSkillText = new Label();

                    //int count = 0;
                    //for (int r = 0; r < 1; r++)
                    //{

                    DisplaySecondarySkillsStackLayout.Children.Clear();
                    for (int c = 0; c < _selectedSecondarySkills.Count; c++)
                    {
                        //if (NoOfRows > count)
                        //{

                        if (Device.Idiom == TargetIdiom.Phone)
                        {
                            stackLayoutBackground = new StackLayout
                            {
                                BackgroundColor = Color.FromHex("#c2c99c"),
                                Padding = 8,
                                Margin = 3,
                                HorizontalOptions = LayoutOptions.Fill,
                                VerticalOptions = LayoutOptions.Fill,
                            };

                            Label lblSkillText = new Label
                            {
                                Text = _selectedSecondarySkills[c].SkillName,
                                TextColor = Color.Black,
                                ClassId = c.ToString(),
                                FontSize = 13,
                                HorizontalTextAlignment = TextAlignment.Center,
                                VerticalTextAlignment = TextAlignment.Center,
                                HorizontalOptions = LayoutOptions.CenterAndExpand,
                                VerticalOptions = LayoutOptions.CenterAndExpand,
                                WidthRequest = 120,
                            };
                            stackLayoutBackground.Children.Add(lblSkillText);

                            SecondarySkills = (SecondarySkills == "" ? _selectedSecondarySkills[c].SkillName : SecondarySkills + ',' + _selectedSecondarySkills[c].SkillName);
                            SecondarySkillsID = (SecondarySkillsID == "" ? _selectedSecondarySkills[c].ID : SecondarySkillsID + ',' + _selectedSecondarySkills[c].ID);
                        }

                        //gridbutton.SetBinding(Button.BackgroundColorProperty, "ButtonColor" + gridbutton.Text);
                        //gridbutton.Clicked += Button_Clicked;
                        grid.Children.Add(stackLayoutBackground);
                        Grid.SetRow(stackLayoutBackground, 0);//r
                        Grid.SetColumn(stackLayoutBackground, c);

                        DisplaySecondarySkillsStackLayout.Children.Add(grid);
                        Device.BeginInvokeOnMainThread(async () =>
                        {
                            await DisplaySecondarySkillsCustomScrollView.ScrollToAsync(0, 0, true);
                        });
                    }
                }
                else
                {
                    SecondarySkills = string.Empty;
                    SecondarySkillsID = string.Empty;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.GenerateSecondarySkills");
            }
        }
        #endregion

        #region click event
        private async void OnsaveDetails(string sender)
        {
            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
            switch (sender)
            {
                case "OnpersonalClick":
                    await ShowPersonalTab();
                    break;
                case "OnEducationClick":
                    await ShowEducationalTab();
                    break;

                #region Personal Details
                case "OnDobClick":
                    IsdobFocus = true;
                    break;
                case "OncheckboxMale":
                    Gender = "male";
                    break;
                case "Oncheckboxfemale":
                    Gender = "female";
                    break;
                case "OnLanguageItemTapped":
                    if (isClicked)
                    {
                        isClicked = false;
                        if (isNetworkAvailable)
                        {
                            await _navigationservice.PushAsync(new MultipleLanguageSelectionPage(_selectionLanguages, null));
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    }); break;
                case "OnNationalityTapped":
                    if (isClicked)
                    {
                        isClicked = false;
                        if (isNetworkAvailable)
                        {
                            NavigateToDynamicListPage(Constants.FieldType.Nationality, "");
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                case "OnCurrentStateItemTapped":
                    if (isClicked)
                    {
                        isClicked = false;
                        if (isNetworkAvailable)
                        {
                            MessageStringConstants.IsCurrentState = true;
                            NavigateToDynamicListPage(Constants.FieldType.State, "");
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                case "OnCurrentCityItemTapped":
                    if (isClicked)
                    {
                        isClicked = false;

                        if (isNetworkAvailable)
                        {
                            if (string.IsNullOrEmpty(_SeekerDashboardResponseModel.ProfileDetails.CurrentStateId) || _SeekerDashboardResponseModel.ProfileDetails.CurrentStateId == null || CurrentState == MessageStringConstants.SelectCurrentState)
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectCurrentState);
                            }
                            else
                            {
                                MessageStringConstants.IsCurrentCity = true;
                                NavigateToDynamicListPage(Constants.FieldType.City, _SeekerDashboardResponseModel.ProfileDetails.CurrentStateId);
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                case "OnPermanentStateItemTapped":
                    if (isClicked)
                    {
                        isClicked = false;

                        if (isNetworkAvailable)
                        {
                            MessageStringConstants.IsCurrentState = false;
                            if (IsEnableToggleSameAddress == true)
                                NavigateToDynamicListPage(Constants.FieldType.State, "");
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                case "OnPermanentCityItemTapped":
                    if (isClicked)
                    {
                        isClicked = false;



                        if (isNetworkAvailable)
                        {
                            if (string.IsNullOrEmpty(_SeekerDashboardResponseModel.ProfileDetails.PermanentStateID) || _SeekerDashboardResponseModel.ProfileDetails.PermanentStateID == null || PermanentState == MessageStringConstants.SelectPermanentState)
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectPermanentState);
                            }

                            else
                            {
                                MessageStringConstants.IsCurrentCity = false;
                                if (IsEnableToggleSameAddress == true)
                                    NavigateToDynamicListPage(Constants.FieldType.City, _SeekerDashboardResponseModel.ProfileDetails.PermanentStateID);
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                case "OnPreferredJobLocationItemTapped":
                    if (isClicked)
                    {
                        isClicked = false;

                        if (isNetworkAvailable)
                        {
                            if (!string.IsNullOrEmpty(PreferredJobLocation))
                            {
                                await _navigationservice.PushAsync(new MultipleJobLocationSelectionPage("SeekerPersonalandEducational", _selectionJobLocation));
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                case "SavePersonalDetails":
                    if (isClicked)
                    {
                        isClicked = false;
                        if (isNetworkAvailable)
                        {
                            await SavePersonalDetails();
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;

                #endregion

                #region Education Details
                case "OnPrimarySkillItemTapped":
                    //if (!string.IsNullOrEmpty(PrimarySkills))
                    //{
                    if (isClicked)
                    {
                        isClicked = false;
                        if (isNetworkAvailable)
                        {
                            await _navigationservice.PushAsync(new MultipleSkillsSelectionPage("SeekerPersonalandEducational", _selectedPrimarySkills, "1"));
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    // }
                    break;

                case "OnSecondarySkillItemTapped":
                    //if (!string.IsNullOrEmpty(SecondarySkills))
                    //{
                    if (isClicked)
                    {
                        isClicked = false;
                        if (isNetworkAvailable)
                        {
                            await _navigationservice.PushAsync(new MultipleSkillsSelectionPage("SeekerPersonalandEducational", _selectedSecondarySkills, "2"));
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    //}
                    break;

                case "EducationNextButtonClicked":
                    if (isClicked)
                    {
                        isClicked = false;
                        if (isNetworkAvailable)
                        {
                            EducationNextButtonClicked();
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                #endregion

                case "OnCameraClick":
                    if (isNetworkAvailable)
                    {
                        await UploadProfilePicture();
                    }
                    else
                    {
                        UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                    }
                    break;
                case "Add":
                    if (isNetworkAvailable)
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            await BindCourseTypeData();
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(500);
                            isClicked = true;
                        });
                    }
                    else
                    {
                        UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                    }
                    break;

                case "AddCertificate":
                    if (isNetworkAvailable)
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            await _navigationservice.PushAsync(new CertificationPage(certifications));
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(500);
                            isClicked = true;
                        });
                    }
                    else
                    {
                        UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                    }
                    break;


                case "OnEditBasicDetails":
                    if (isClicked)
                    {
                        isClicked = false;
                        await _navigationservice.PushAsync(new EditBasicDetailsPage());
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
            }

        }
        #endregion

        #region EducationNextButtonClicked
        public async void EducationNextButtonClicked()
        {
            try
            {
                if (PrimarySkills.Length == 0)
                {
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectPrimarySkills);
                }
                else if (_courseTypeID == null || _courseTypeID.Count <= 0)
                {
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterEducationalDetails);
                }
                else if (!_courseTypeID.Contains("1") && !_courseTypeID.Contains("2"))
                {
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.UpdateYourSchoolDetails);
                }
                else if (!_courseTypeID.Contains("3") && !_courseTypeID.Contains("4") && !_courseTypeID.Contains("5"))
                {
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.UpdateYourCollegeDetails);
                }
                else
                {
                    AppPreferences.IsEducationCompleted = true;
                    AppPreferences.IsFirstRun = false;
                    _isEducationDetailsUpdated = true;
                    NavigateToNextPageIfNeeded();
                    await ShowPersonalTab();
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.UpdateSkillAndJobLocation");
            }
        }
        #endregion

        #region Toggle Event
        private Command<string> tapCommand;
        public Command<string> TapCommand
        {
            get { return tapCommand ?? (tapCommand = new Command<string>(async arg => await OnTappedCommand(arg))); }
        }
        public async Task OnTappedCommand(string sender)
        {
            try
            {
                switch (sender)
                {
                    #region Toggle Event
                    case "ToggleSameAddress":
                        if (IsToggleSameAddress == true)
                        {
                            IsEnableToggleSameAddress = false;
                            IsCopy = 1;
                            PermanentAddress = CurrentAddress ?? string.Empty;
                            _SeekerDashboardResponseModel.ProfileDetails.PermanentAddress = CurrentAddress ?? string.Empty;
                            PermanentZipcode = CurrentZipcode ?? string.Empty;
                            _SeekerDashboardResponseModel.ProfileDetails.PermanentZipcode = CurrentZipcode ?? string.Empty;

                            if (string.IsNullOrEmpty(_SeekerDashboardResponseModel.ProfileDetails.CurrentStateId) || _SeekerDashboardResponseModel.ProfileDetails.CurrentStateName == MessageStringConstants.SelectCurrentState)
                            {
                                _SeekerDashboardResponseModel.ProfileDetails.PermanentStateID = string.Empty;
                                _SeekerDashboardResponseModel.ProfileDetails.PermanentStateName = MessageStringConstants.SelectPermanentState;
                                PermanentState = MessageStringConstants.SelectPermanentState;
                            }
                            else
                            {
                                _SeekerDashboardResponseModel.ProfileDetails.PermanentStateID = _SeekerDashboardResponseModel.ProfileDetails.CurrentStateId;
                                _SeekerDashboardResponseModel.ProfileDetails.PermanentStateName = CurrentState ?? _SeekerDashboardResponseModel.ProfileDetails.CurrentStateName ?? MessageStringConstants.SelectPermanentState;
                                PermanentState = _SeekerDashboardResponseModel.ProfileDetails.CurrentStateName ?? MessageStringConstants.SelectPermanentState;
                            }

                            if (string.IsNullOrEmpty(_SeekerDashboardResponseModel.ProfileDetails.CurrentCityId) || _SeekerDashboardResponseModel.ProfileDetails.CurrentCityName == MessageStringConstants.SelectCurrentDistrict)
                            {
                                _SeekerDashboardResponseModel.ProfileDetails.PermanentCityID = string.Empty;
                                _SeekerDashboardResponseModel.ProfileDetails.PermanentCityName = MessageStringConstants.SelectPermanentDistrict;
                                PermanentDistrict = MessageStringConstants.SelectPermanentDistrict;
                            }
                            else
                            {
                                _SeekerDashboardResponseModel.ProfileDetails.PermanentCityID = _SeekerDashboardResponseModel.ProfileDetails.CurrentCityId ?? string.Empty;
                                _SeekerDashboardResponseModel.ProfileDetails.PermanentCityName = CurrentDistrict ?? _SeekerDashboardResponseModel.ProfileDetails.CurrentCityName ?? MessageStringConstants.SelectPermanentDistrict;
                                PermanentDistrict = _SeekerDashboardResponseModel.ProfileDetails.CurrentCityName ?? MessageStringConstants.SelectPermanentDistrict;
                            }
                        }
                        else
                        {
                            IsCopy = 0;
                            IsEnableToggleSameAddress = true;
                            PermanentAddress = string.Empty;
                            PermanentState = MessageStringConstants.SelectPermanentState;
                            PermanentDistrict = MessageStringConstants.SelectPermanentDistrict;
                            PermanentZipcode = string.Empty;

                            _SeekerDashboardResponseModel.ProfileDetails.PermanentAddress = string.Empty;
                            _SeekerDashboardResponseModel.ProfileDetails.PermanentStateID = string.Empty;
                            _SeekerDashboardResponseModel.ProfileDetails.PermanentStateName = MessageStringConstants.SelectPermanentState;
                            _SeekerDashboardResponseModel.ProfileDetails.PermanentCityID = string.Empty;
                            _SeekerDashboardResponseModel.ProfileDetails.PermanentCityName = MessageStringConstants.SelectPermanentDistrict;
                            _SeekerDashboardResponseModel.ProfileDetails.PermanentZipcode = string.Empty;
                        }
                        break;
                    case "AadharUnfocused":
                        if (!string.IsNullOrEmpty(AadhaarNumber))
                        {
                            if (!Utilities.ValidateAadhaarNumber(AadhaarNumber))
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidAadhaarNumber);
                            }
                            else
                            {
                                var mailstatus = await CheckAadharNumber(AadhaarNumber);
                                if (mailstatus)
                                {
                                    ISChecAadharStatus = true;
                                }
                                else
                                {
                                    ISChecAadharStatus = false;
                                }
                            }
                        }
                        break;
                    case "PassportUnFocused":
                        if (!string.IsNullOrEmpty(PassPortNumber))
                        {
                            if (!Utilities.ValidatePassportNumber(PassPortNumber))
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidPassportNumber);
                            }
                            else
                            {
                                var _passportNumberStatus = await CheckPassportNumber(PassPortNumber);
                                if (_passportNumberStatus)
                                {
                                    ISCheckPassportStatus = true;
                                }
                                else
                                {
                                    ISCheckPassportStatus = false;
                                }
                            }
                        }
                        break;
                    case "PANNumberUnFocused":
                        if (!string.IsNullOrEmpty(PANNumber))
                        {
                            if (!Utilities.ValidatePANNumber(PANNumber))
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidPANNumber);
                            }
                            else
                            {
                                var _PANNumberStatus = await CheckPANNumber(PANNumber);
                                if (_PANNumberStatus)
                                {
                                    ISCheckPANStatus = true;
                                }
                                else
                                {
                                    ISCheckPANStatus = false;
                                }
                            }
                        }
                        break;
                    case "PermanentAddresId":

                        if (!string.IsNullOrEmpty(PermanentAddress))
                        {
                            if (!Utilities.Address(PermanentAddress))
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterPermanentAddress);
                            }
                            else if (PermanentAddress.Length < 15)
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterPermanentAddressLength);
                            }
                        }
                        break;
                    case "CurrentAddresId":

                        if (!string.IsNullOrEmpty(CurrentAddress))
                        {
                            if (!Utilities.Address(CurrentAddress))
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterCurrentAddress);
                            }
                            else if (CurrentAddress.Length < 15)
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterCurrentAddressLength);
                            }
                        }
                        break;

                    case "PresendPincodeUnfocused":

                        if (string.IsNullOrEmpty(CurrentZipcode) || Int32.Parse(CurrentZipcode) == 0)
                        {
                            CurrentZipcode = string.Empty;
                        }
                        else
                        {
                            BindStateAndCity("Presend", CurrentZipcode);
                        }
                        break;
                    case "PermanentPincodeUnfocused":
                        if (string.IsNullOrEmpty(PermanentZipcode) || Int32.Parse(PermanentZipcode) == 0)
                        {
                            PermanentZipcode = string.Empty;
                        }
                        else
                        {
                            BindStateAndCity("Permanent", PermanentZipcode);
                        }
                        break;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
            #endregion
        }

        private Command<string> textchagedcommand;
        public Command<string> TextChangedCommand
        {
            get { return textchagedcommand ?? (textchagedcommand = new Command<string>(async arg => await OnTextChangedCommand(arg))); }
        }

        private Command<object> datechagedcommand;
        public Command<object> DateChangedCommand
        {
            get { return datechagedcommand ?? (datechagedcommand = new Command<object>(async arg => await OnDateChangedCommand(arg))); }
        }
        private async Task OnTextChangedCommand(string sender)
        {
            switch (sender)
            {
                case "CGPA":
                    if (EntryCGPA != "" && EntryCGPA != "0.00")
                    {
                        IsEntryPercentage = false;
                        IsEntryCGPA = true;
                    }
                    else
                    {
                        IsEntryPercentage = true;
                        EntryCGPA = string.Empty;
                    }
                    break;
                case "Percentage":
                    if (EntryPercentage != "0.00" && EntryPercentage != "")
                    {
                        IsEntryCGPA = false;
                        IsEntryPercentage = true;
                    }

                    else if (EntryCGPA == "0.00" && EntryPercentage == "00.0" || EntryCGPA == "0.00" && EntryPercentage == "0.00")
                    {
                        IsEntryCGPA = true;
                        IsEntryPercentage = true;
                    }
                    else
                    {
                        IsEntryCGPA = true;
                        EntryPercentage = string.Empty;
                    }
                    break;
            }
        }


        private void Onfocus(object obj)
        {
            var datepicker = (DatePicker)obj;
            if (DatepickerValue == "0000-00-00")
            {
                datepicker.Date = DateTime.Now.AddYears(-17).AddDays(-1);
                DatepickerValue = "0000-00-00";
            }
            datepicker.Focus();
            // datepicker.MaximumDate = DateTime.Now.AddYears(-17).AddDays(-1);
        }

        private async Task OnDateChangedCommand(object sender)
        {
            var datepicker = (DatePicker)sender;
            DatepickerValue = datepicker.Date.ToString("yyyy-MM-dd");

            DateTime Dob = DateTime.Parse(DatepickerValue);
            DateTime now = DateTime.Today;
            int age = now.Year - Dob.Year;
            if (Dob.AddYears(age) > now)
                age--;

            Age = age.ToString();
        }

        void HandicappedClicked(object obj)
        {
            if (obj.ToString() == "Yes")
            {
                HandicappedYes = (string)Application.Current.Resources["CircleSelected"];
                HandicappedNo = (string)Application.Current.Resources["CircleUnSelected"];
                HandicappedData = "1";
            }
            else if (obj.ToString() == "No")
            {
                HandicappedNo = (string)Application.Current.Resources["CircleSelected"];
                HandicappedYes = (string)Application.Current.Resources["CircleUnSelected"];
                HandicappedData = "0";
            }
        }

        void GenderClicked(object obj)
        {
            if (obj.ToString() == "male")
            {
                BindingMaleText = (string)Application.Current.Resources["CircleSelected"];
                BindingFeMaleText = (string)Application.Current.Resources["CircleUnSelected"];
                Gender = "male";
            }
            else if (obj.ToString() == "female")
            {
                BindingFeMaleText = (string)Application.Current.Resources["CircleSelected"];
                BindingMaleText = (string)Application.Current.Resources["CircleUnSelected"];
                Gender = "female";
            }
        }

        #endregion

        #region BindStateAndCity
        public void BindStateAndCity(string _isPincode, string pincodeNumber)
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                try
                {
                    if (!string.IsNullOrEmpty(pincodeNumber))
                    {
                        bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                        if (isNetworkAvailable)
                        {
                            UserDialogs.Instance.ShowLoading();

                            BindStateAndCityRequestModel objRequestData = new BindStateAndCityRequestModel();
                            objRequestData.pinCode = pincodeNumber;
                            var resultdata = await _commonservice.PostAsync<BindStateAndCityResponseModel, BindStateAndCityRequestModel>(APIData.API_BASE_URL + APIMethods.GetPinCodeDetails, objRequestData);
                            if (resultdata != null)
                            {
                                UserDialogs.Instance.HideLoading();
                                if (resultdata.Code == "200" && resultdata.responseText != null)
                                {
                                    if (_isPincode.Equals("Presend"))
                                    {
                                        CurrentState = resultdata.responseText[0].StateName ?? MessageStringConstants.SelectState;
                                        CurrentDistrict = resultdata.responseText[0].DistrictName ?? MessageStringConstants.SelectCity;

                                        _SeekerDashboardResponseModel.ProfileDetails.CurrentStateId = resultdata.responseText[0].StateId;
                                        _SeekerDashboardResponseModel.ProfileDetails.CurrentStateName = resultdata.responseText[0].StateName ?? MessageStringConstants.SelectState;
                                        _SeekerDashboardResponseModel.ProfileDetails.CurrentCityId = resultdata.responseText[0].DistrictId;
                                        _SeekerDashboardResponseModel.ProfileDetails.CurrentCityName = resultdata.responseText[0].DistrictName ?? MessageStringConstants.SelectCity;
                                    }
                                    else if (_isPincode.Equals("Permanent"))
                                    {
                                        PermanentState = resultdata.responseText[0].StateName ?? MessageStringConstants.SelectState;
                                        PermanentDistrict = resultdata.responseText[0].DistrictName ?? MessageStringConstants.SelectCity;

                                        _SeekerDashboardResponseModel.ProfileDetails.PermanentStateID = resultdata.responseText[0].StateId;
                                        _SeekerDashboardResponseModel.ProfileDetails.PermanentStateName = resultdata.responseText[0].StateName ?? MessageStringConstants.SelectState;
                                        _SeekerDashboardResponseModel.ProfileDetails.PermanentCityID = resultdata.responseText[0].DistrictId;
                                        _SeekerDashboardResponseModel.ProfileDetails.PermanentCityName = resultdata.responseText[0].DistrictName ?? MessageStringConstants.SelectCity;
                                    }
                                }
                                else if (resultdata.Code == "199")
                                {
                                    UserDialogs.Instance.HideLoading();
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.SessionExpiered);
                                    Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                                    return;
                                }
                                else
                                {

                                    if (_isPincode.Equals("Presend"))
                                    {
                                        //await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidCurrentPincode);
                                        CurrentState = MessageStringConstants.SelectState;
                                        CurrentDistrict = MessageStringConstants.SelectCity;

                                        _SeekerDashboardResponseModel.ProfileDetails.CurrentStateId = null;
                                        _SeekerDashboardResponseModel.ProfileDetails.CurrentCityId = null;
                                        _SeekerDashboardResponseModel.ProfileDetails.CurrentStateName = MessageStringConstants.SelectState;
                                        _SeekerDashboardResponseModel.ProfileDetails.CurrentCityName = MessageStringConstants.SelectCity;
                                    }
                                    else if (_isPincode.Equals("Permanent"))
                                    {
                                        // await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidPermanentPincode);
                                        PermanentState = MessageStringConstants.SelectState;
                                        PermanentDistrict = MessageStringConstants.SelectCity;

                                        _SeekerDashboardResponseModel.ProfileDetails.PermanentStateID = null;
                                        _SeekerDashboardResponseModel.ProfileDetails.PermanentCityID = null;
                                        _SeekerDashboardResponseModel.ProfileDetails.PermanentStateName = MessageStringConstants.SelectState;
                                        _SeekerDashboardResponseModel.ProfileDetails.PermanentCityName = MessageStringConstants.SelectCity;
                                    }
                                }
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                }
                catch (Exception ex)
                {
                    UserDialogs.Instance.HideLoading();
                    System.Diagnostics.Debug.WriteLine(ex.Message);
                    SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.BindStateAndCity");
                }
            });
        }
        #endregion

        #region Private Properties

        private bool _IsToggleSameAddress;
        public bool IsToggleSameAddress
        {
            get { return _IsToggleSameAddress; }
            set { _IsToggleSameAddress = value; OnPropertyChanged(); }
        }

        private bool _IsEnableToggleSameAddress;
        public bool IsEnableToggleSameAddress
        {
            get { return _IsEnableToggleSameAddress; }
            set { _IsEnableToggleSameAddress = value; OnPropertyChanged(); }
        }

        private StackLayout _StackLayout_SchoolorCollege;
        public StackLayout StackLayout_SchoolorCollege
        {
            get { return _StackLayout_SchoolorCollege; }
            set { _StackLayout_SchoolorCollege = value; OnPropertyChanged(); }
        }


        private StackLayout _DisplayPrimarySkillsStackLayout;
        public StackLayout DisplayPrimarySkillsStackLayout
        {
            get { return _DisplayPrimarySkillsStackLayout; }
            set { _DisplayPrimarySkillsStackLayout = value; }
        }

        private ScrollView _DisplayPrimarySkillsCustomScrollView;
        public ScrollView DisplayPrimarySkillsCustomScrollView
        {
            get { return _DisplayPrimarySkillsCustomScrollView; }
            set { _DisplayPrimarySkillsCustomScrollView = value; }
        }

        private StackLayout _DisplaySecondarySkillsStackLayout;
        public StackLayout DisplaySecondarySkillsStackLayout
        {
            get { return _DisplaySecondarySkillsStackLayout; }
            set { _DisplaySecondarySkillsStackLayout = value; }
        }

        private ScrollView _DisplaySecondarySkillsCustomScrollView;
        public ScrollView DisplaySecondarySkillsCustomScrollView
        {
            get { return _DisplaySecondarySkillsCustomScrollView; }
            set { _DisplaySecondarySkillsCustomScrollView = value; }
        }

        private StackLayout _DisplayCertificateStackLayout;
        public StackLayout DisplayCertificateStackLayout
        {
            get { return _DisplayCertificateStackLayout; }
            set { _DisplayCertificateStackLayout = value; }
        }

        //private Grid _DisplayCertificateStackLayout;
        //public Grid DisplayCertificateStackLayout
        //{
        //    get { return _DisplayCertificateStackLayout; }
        //    set { _DisplayCertificateStackLayout = value; }
        //}

        private ScrollView _DisplayCertificateCustomScrollView;
        public ScrollView DisplayCertificateCustomScrollView
        {
            get { return _DisplayCertificateCustomScrollView; }
            set { _DisplayCertificateCustomScrollView = value; }
        }


        private bool _iSChecAadharStatus;
        public bool ISChecAadharStatus
        {
            get { return _iSChecAadharStatus; }
            set { _iSChecAadharStatus = value; OnPropertyChanged(); }
        }
        private bool _iSCheckPassportStatus;
        public bool ISCheckPassportStatus
        {
            get { return _iSCheckPassportStatus; }
            set { _iSCheckPassportStatus = value; OnPropertyChanged(); }
        }
        private bool _iSCheckPANStatus;
        public bool ISCheckPANStatus
        {
            get { return _iSCheckPANStatus; }
            set { _iSCheckPANStatus = value; OnPropertyChanged(); }
        }

        private string _Age;
        public string Age
        {
            get { return _Age; }
            set { _Age = value; OnPropertyChanged(); }
        }

        private SeekerDashboardResponseModel _SeekerDashboardResponseModel;
        public SeekerDashboardResponseModel SeekerDashboardResponseModel
        {
            get { return _SeekerDashboardResponseModel; }
            set { _SeekerDashboardResponseModel = value; OnPropertyChanged(); }
        }

        private bool _ispersonalgrid;
        public bool IsPersonalGrid
        {
            get { return _ispersonalgrid; }
            set { _ispersonalgrid = value; OnPropertyChanged(); }
        }

        private bool _iseducationgrid;
        public bool IsEducationGrid
        {
            get { return _iseducationgrid; }
            set { _iseducationgrid = value; OnPropertyChanged(); }
        }
        private bool _isdob;
        public bool IsDob
        {
            get { return _isdob; }
            set { _isdob = value; OnPropertyChanged(); }
        }
        private bool _isdobfocus;
        public bool IsdobFocus
        {
            get { return _isdobfocus; }
            set { _isdobfocus = value; OnPropertyChanged(); }
        }

        private string _datepickerValue;
        public string DatepickerValue
        {
            get { return _datepickerValue; }
            set
            {
                if (value == "0000-00-00")
                {
                    Age = string.Empty;
                }

                _datepickerValue = value;
                OnPropertyChanged();
            }
        }
        private DateTime _maximumdate = DateTime.Now.AddYears(-17).AddDays(-1);
        public DateTime MaximumDate
        {
            get { return _maximumdate; }
            set { _maximumdate = value; OnPropertyChanged(); }
        }
        private string _checkboxMale;

        public string CheckBoxMale
        {
            get { return _checkboxMale; }
            set { _checkboxMale = value; OnPropertyChanged(); }
        }
        private string _checkboxFemale;

        public string CheckBoxFeMale
        {
            get { return _checkboxFemale; }
            set { _checkboxFemale = value; OnPropertyChanged(); }
        }

        private bool _isentryPercentage;

        public bool IsEntryPercentage
        {
            get { return _isentryPercentage; }
            set { _isentryPercentage = value; OnPropertyChanged(); }
        }

        private bool _isentryCGPA;

        public bool IsEntryCGPA
        {
            get { return _isentryCGPA; }
            set { _isentryCGPA = value; OnPropertyChanged(); }
        }
        private string _entrycgpa = "0.00";

        public string EntryCGPA
        {
            get { return _entrycgpa; }
            set { _entrycgpa = value; OnPropertyChanged(); }
        }
        private string _entrypercentage = "0.00";

        public string EntryPercentage
        {
            get { return _entrypercentage; }
            set { _entrypercentage = value; OnPropertyChanged(); }
        }

        private bool _iscameracisible = true;
        public bool IsCameraVisible
        {
            get { return _iscameracisible; }
            set { _iscameracisible = value; OnPropertyChanged(); }
        }
        private string _languages = "Select Language";
        public string Languages
        {
            get { return _languages; }
            set { _languages = value; OnPropertyChanged(); }
        }


        private string _yearOfcompletion;

        private Color _personalbackbtncolor;
        public Color PersonalBackbtnColor
        {
            get { return _personalbackbtncolor; }
            set { _personalbackbtncolor = value; OnPropertyChanged(); }
        }
        private Color _educationbackbtncolor;
        public Color EducationBackbtnColor
        {
            get { return _educationbackbtncolor; }
            set { _educationbackbtncolor = value; OnPropertyChanged(); }
        }

        private string _profilepic = (string)Application.Current.Resources["IconUser"];

        public string profilepic
        {
            get { return _profilepic; }
            set { _profilepic = value; OnPropertyChanged(); }
        }


        private string bindingFeMaleText;
        public string BindingFeMaleText
        {
            get { return bindingFeMaleText; }
            set
            {
                bindingFeMaleText = value;
                OnPropertyChanged();
            }
        }


        private string bindingMaleText;
        public string BindingMaleText
        {
            get { return bindingMaleText; }
            set
            {
                bindingMaleText = value;
                OnPropertyChanged();
            }
        }


        private string _handicappedYes;
        public string HandicappedYes
        {
            get { return _handicappedYes; }
            set
            {
                _handicappedYes = value;
                OnPropertyChanged();
            }
        }
        private string _handicappedNo;
        public string HandicappedNo
        {
            get { return _handicappedNo; }
            set
            {
                _handicappedNo = value;
                OnPropertyChanged();
            }
        }

        private string _fullname;
        public string FullName
        {
            get { return _fullname; }
            set
            {
                _fullname = value;
                OnPropertyChanged();
            }
        }

        private string _PassPortNumber;
        public string PassPortNumber
        {
            get { return _PassPortNumber; }
            set { _PassPortNumber = value; OnPropertyChanged(); }
        }

        private string _PANNumber;
        public string PANNumber
        {
            get { return _PANNumber; }
            set { _PANNumber = value; OnPropertyChanged(); }
        }

        private string _AadhaarNumber;
        public string AadhaarNumber
        {
            get { return _AadhaarNumber; }
            set { _AadhaarNumber = value; OnPropertyChanged(); }
        }


        private string _EmailID;
        public string EmailID
        {
            get { return _EmailID; }
            set
            {
                _EmailID = value;
                OnPropertyChanged();
            }
        }

        private string _MobileNo;
        public string MobileNo
        {
            get { return _MobileNo; }
            set
            {
                _MobileNo = value;
                OnPropertyChanged();
            }
        }
        private string _HiremeeID;
        public string HiremeeID
        {
            get { return _HiremeeID; }
            set
            {
                _HiremeeID = value;
                OnPropertyChanged();
            }
        }

        #endregion

        #region HandicappedData
        string _handicappedData;
        public string HandicappedData
        {
            get
            {
                return _handicappedData;
            }
            set
            {
                if (value != null)
                {
                    if (value.ToLower() == "1")
                    {
                        _handicappedData = "1";
                        HandicappedYes = (string)Application.Current.Resources["CircleSelected"];
                        HandicappedNo = (string)Application.Current.Resources["CircleUnSelected"];

                    }
                    else if (value.ToLower() == "0")
                    {
                        HandicappedNo = (string)Application.Current.Resources["CircleSelected"];
                        HandicappedYes = (string)Application.Current.Resources["CircleUnSelected"];
                        _handicappedData = "0";

                    }
                }
                OnPropertyChanged();
            }
        }
        #endregion

        #region Gender
        string _gender;
        public string Gender
        {
            get
            {
                return _gender;
            }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    if (value.ToLower() == "male")
                    {
                        _gender = "male";
                        BindingMaleText = (string)Application.Current.Resources["CircleSelected"];
                        BindingFeMaleText = (string)Application.Current.Resources["CircleUnSelected"];

                    }
                    else if (value.ToLower() == "female")
                    {
                        BindingFeMaleText = (string)Application.Current.Resources["CircleSelected"];
                        BindingMaleText = (string)Application.Current.Resources["CircleUnSelected"];
                        _gender = "female";

                    }
                }
                else
                {
                    BindingFeMaleText = (string)Application.Current.Resources["CircleUnSelected"];
                    BindingMaleText = (string)Application.Current.Resources["CircleUnSelected"];
                }
                OnPropertyChanged();
            }
        }
        #endregion

        #region NavigateToDynamicListPage
        public async void NavigateToDynamicListPage(string _fieldType, string _fieldValue)
        {
            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
            if (isNetworkAvailable)
            {
                await _navigationservice.PushAsync(new DynamicListPage("SeekerPersonalandEducational", _fieldType, _fieldValue));
            }
            else
            {
                UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
            }
        }
        #endregion

        #region SetFieldValue
        public void SetFieldValue(string fieldtype, object fieldvalue)
        {
            try
            {
                #region State
                if (fieldtype == Constants.FieldType.State)
                {
                    if (MessageStringConstants.IsCurrentState)
                    {

                        CurrentDistrict = MessageStringConstants.SelectCurrentDistrict;
                        _SeekerDashboardResponseModel.ProfileDetails.CurrentCityId = string.Empty;
                        _SeekerDashboardResponseModel.ProfileDetails.CurrentCityName = MessageStringConstants.SelectCurrentDistrict;

                        CurrentState = ((CommonListItemSource)fieldvalue).Title;
                        _SeekerDashboardResponseModel.ProfileDetails.CurrentStateId = ((CommonListItemSource)fieldvalue).ID;
                        _SeekerDashboardResponseModel.ProfileDetails.CurrentStateName = ((CommonListItemSource)fieldvalue).Title;
                    }
                    else
                    {
                        PermanentDistrict = MessageStringConstants.SelectPermanentDistrict;
                        _SeekerDashboardResponseModel.ProfileDetails.PermanentCityID = string.Empty;
                        _SeekerDashboardResponseModel.ProfileDetails.PermanentCityName = MessageStringConstants.SelectPermanentDistrict;

                        PermanentState = ((CommonListItemSource)fieldvalue).Title;
                        _SeekerDashboardResponseModel.ProfileDetails.PermanentStateID = ((CommonListItemSource)fieldvalue).ID;
                        _SeekerDashboardResponseModel.ProfileDetails.PermanentStateName = ((CommonListItemSource)fieldvalue).Title;
                    }
                }
                #endregion

                #region City
                else if (fieldtype == Constants.FieldType.City)
                {
                    if (MessageStringConstants.IsCurrentCity)
                    {
                        CurrentDistrict = ((CommonListItemSource)fieldvalue).Title;
                        _SeekerDashboardResponseModel.ProfileDetails.CurrentCityId = ((CommonListItemSource)fieldvalue).ID;
                        _SeekerDashboardResponseModel.ProfileDetails.CurrentCityName = ((CommonListItemSource)fieldvalue).Title;
                    }
                    else
                    {
                        PermanentDistrict = ((CommonListItemSource)fieldvalue).Title;
                        _SeekerDashboardResponseModel.ProfileDetails.PermanentCityID = ((CommonListItemSource)fieldvalue).ID;
                        _SeekerDashboardResponseModel.ProfileDetails.PermanentCityName = ((CommonListItemSource)fieldvalue).Title;
                    }
                }
                #endregion

                #region Nationality
                else if (fieldtype == Constants.FieldType.Nationality)
                {
                    if (Nationality != ((CommonListItemSource)fieldvalue).Title.ToString())
                    {
                        Nationality = "Select Nationality";
                    }

                    Nationality = ((CommonListItemSource)fieldvalue).Title;
                    _SeekerDashboardResponseModel.ProfileDetails.NationalityID = ((CommonListItemSource)fieldvalue).ID;
                    _SeekerDashboardResponseModel.ProfileDetails.NationalityName = ((CommonListItemSource)fieldvalue).Title;
                }
                #endregion

                #region PreferredJobLocation
                else if (fieldtype == Constants.FieldType.PreferredJobLocation)
                {
                    _selectionJobLocation = ((List<JobLocation>)fieldvalue);

                    string title = string.Empty;
                    string id = string.Empty;
                    int length = _selectionJobLocation.Count;
                    int counter = 0;
                    foreach (var skill in _selectionJobLocation)
                    {
                        counter++;
                        id += skill.ID;
                        title += skill.Title;
                        if (counter < length)
                        {
                            id += ",";
                            title += ", ";
                        }
                    }
                    if (counter == 0)
                    {
                        PreferredJobLocation = MessageStringConstants.SelectPreferredJobLocation;
                    }
                    else
                    {
                        PreferredJobLocation = title;
                        PreferredJobLocationID = id;
                        _SeekerDashboardResponseModel.ProfileDetails.prefer_location_id = id;
                        _SeekerDashboardResponseModel.ProfileDetails.prefer_location_name = title;
                    }
                }
                #endregion

                #region Multiple PrimarySkill Selection
                else if (fieldtype == Constants.FieldType.PrimarySkill)
                {
                    _selectedPrimarySkills = ((List<Skill>)fieldvalue);
                    GeneratePrimarySkills(_selectedPrimarySkills);
                }
                #endregion

                #region Multiple SecondarySkill Selection
                else if (fieldtype == Constants.FieldType.SecondarySkill)
                {
                    _selectedSecondarySkills = ((List<Skill>)fieldvalue);
                    GenerateSecondarySkills(_selectedSecondarySkills);
                }
                #endregion

                #region Language Selection
                else if (fieldtype == Constants.FieldType.Languages)
                {
                    _selectionLanguages = ((List<Languageknown>)fieldvalue);

                    string languagestext = string.Empty;
                    string languageparams = string.Empty;
                    int languagescount = _selectionLanguages.Count;
                    int counter = 0;
                    foreach (var language in _selectionLanguages)
                    {
                        counter++;
                        languagestext += language.Title;
                        languageparams += language.LanguageID;
                        if (counter < languagescount)
                        {
                            languagestext += ", ";
                            languageparams += ",";
                        }
                    }
                    if (counter == 0)
                    {
                        Languages = "Select Language";

                    }
                    else
                    {
                        Languages = languagestext;

                    }

                }
                #endregion
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.SetFieldValue");
            }
        }
        #endregion

        #region GetJobSeekerDetails
        public async Task GetJobSeekerDetails()
        {
            try
            {
                BaseRequestDTO objRequestData = new BaseRequestDTO();
                var responsedata = await _commonservice.PostAsync<SeekerDashboardResponseModel, BaseRequestDTO>(APIData.API_BASE_URL + APIMethods.GetPersonalDetails, objRequestData);
                if (responsedata != null)
                {
                    if (responsedata.Code == "200")
                    {
                        AppPreferences.LoadSeekerDashboardData = responsedata;
                        BindFromPreference_PersonalDetails();
                        BindFromPreference_EducationDetails();

                        if (responsedata.ProfileImage != null && responsedata.ProfileImage.S3_ID != null)
                        {
                            await GetUserPic(responsedata.ProfileImage.S3_ID);
                        }
                    }
                    else if (responsedata.Code == "199")
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.SessionExpiered);
                        Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                        return;
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(responsedata.Message);
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.BindPersonalDetailsToView");
            }
        }
        #endregion

        #region BindJobLocation
        private void BindJobLocation(Prefer_Job_Location[] prefer_job_location)
        {
            try
            {
                _selectionJobLocation = new List<JobLocation>();
                JobLocation objJobLocation = new JobLocation();
                PreferredJobLocationID = string.Empty;
                PreferredJobLocation = string.Empty;
                if (prefer_job_location.Length > 0)
                {
                    foreach (var item in prefer_job_location)
                    {
                        objJobLocation.ID = item.joblocation.id;
                        objJobLocation.Title = item.joblocation.district;
                        objJobLocation.IsSelected = true;
                        PreferredJobLocation = (PreferredJobLocation == "" ? item.joblocation.district : PreferredJobLocation + ',' + item.joblocation.district);
                        PreferredJobLocationID = (PreferredJobLocationID == "" ? item.joblocation.id : PreferredJobLocationID + ',' + item.joblocation.id);
                        _SeekerDashboardResponseModel.ProfileDetails.prefer_location_id = PreferredJobLocationID;
                        _SeekerDashboardResponseModel.ProfileDetails.prefer_location_name = PreferredJobLocation;

                        JobLocation obj = new JobLocation();
                        obj.ID = item.joblocation.id;
                        obj.Title = item.joblocation.district;
                        obj.IsSelected = true;
                        if (!_selectionJobLocation.Contains(obj))
                        {
                            _selectionJobLocation.Add(obj);
                        }
                    }
                }
                else
                {
                    PreferredJobLocation = MessageStringConstants.SelectPreferredJobLocation;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                PreferredJobLocation = MessageStringConstants.SelectPreferredJobLocation;
                SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.BindJobLocation");
            }
        }
        #endregion

        #region BindLanguage
        private void BindLanguage(Languageknown[] language)
        {

            try
            {
                Languages = string.Empty;
                _selectionLanguages = new List<Languageknown>();
                MultipleLanguageSelectionBO objSelectionBO = new MultipleLanguageSelectionBO();
                var lan = language;
                if (_selectionLanguages == null)
                    _selectionLanguages = new List<Languageknown>();
                if (lan.Length != 0)
                {
                    foreach (var languageItem in lan)
                    {
                        objSelectionBO.SearchName = "";
                        objSelectionBO.LanguageID = languageItem.Languages.ID;
                        objSelectionBO.LanguageTitle = languageItem.Languages.LanguageName;
                        objSelectionBO.IsSelected = true;
                        objSelectionBO.IsRead = languageItem.IsRead;
                        objSelectionBO.IsSpeak = languageItem.IsSpeak;
                        objSelectionBO.IsWrite = languageItem.IsWrite;
                        objSelectionBO.CreatedOn = DateTime.Now;
                        _selectionLanguages.Add(languageItem);
                        Languages = (Languages == "" ? languageItem.Languages.LanguageName : Languages + ',' + languageItem.Languages.LanguageName);
                    }
                }
                else
                {
                    Languages = "Select Language";
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                Languages = "Select Language";
                SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.BindLanguage");
            }

        }
        #endregion

        #region Private Properties 

        private string _pagetitle;
        public string PageTitle
        {
            get { return _pagetitle; }
            set { _pagetitle = value; OnPropertyChanged(); }
        }


        private bool _isvisibleEmptyCertificateMessage;

        public bool IsvisibleEmptyCertificateMessage
        {
            get { return _isvisibleEmptyCertificateMessage; }
            set { _isvisibleEmptyCertificateMessage = value; OnPropertyChanged(); }
        }

        private string _CurrentAddress;
        public string CurrentAddress
        {
            get { return _CurrentAddress; }
            set { _CurrentAddress = value; OnPropertyChanged(); }
        }

        private string _AboutMe;
        public string AboutMe
        {
            get { return _AboutMe; }
            set { _AboutMe = value; OnPropertyChanged(); }
        }
        private string _FaceBookLink;
        public string FaceBookLink
        {
            get { return _FaceBookLink; }
            set { _FaceBookLink = value; OnPropertyChanged(); }
        }
        private string _GooglePlusLink;
        public string GooglePlusLink
        {
            get { return _GooglePlusLink; }
            set { _GooglePlusLink = value; OnPropertyChanged(); }
        }
        private string _TwitterLink;
        public string TwitterLink
        {
            get { return _TwitterLink; }
            set { _TwitterLink = value; OnPropertyChanged(); }
        }
        private string _LinkedInLink;
        public string LinkedInLink
        {
            get { return _LinkedInLink; }
            set { _LinkedInLink = value; OnPropertyChanged(); }
        }


        private string _CurrentState;
        public string CurrentState
        {
            get { return _CurrentState; }
            set { _CurrentState = value; OnPropertyChanged(); }
        }
        private string _CurrentDistrict;
        public string CurrentDistrict
        {
            get { return _CurrentDistrict; }
            set { _CurrentDistrict = value; OnPropertyChanged(); }
        }

        private string _CurrentZipcode;
        public string CurrentZipcode
        {
            get { return _CurrentZipcode; }
            set { _CurrentZipcode = value; OnPropertyChanged(); }
        }

        private int _isCopy;

        public int IsCopy
        {
            get { return _isCopy; }
            set { _isCopy = value; OnPropertyChanged(); }
        }

        private string _PermanentAddress;
        public string PermanentAddress
        {
            get { return _PermanentAddress; }
            set { _PermanentAddress = value; OnPropertyChanged(); }
        }

        private string _PermanentState;
        public string PermanentState
        {
            get { return _PermanentState; }
            set { _PermanentState = value; OnPropertyChanged(); }
        }

        private string _PermanentDistrict;
        public string PermanentDistrict
        {
            get { return _PermanentDistrict; }
            set { _PermanentDistrict = value; OnPropertyChanged(); }
        }
        private string _PermanentZipcode;
        public string PermanentZipcode
        {
            get { return _PermanentZipcode; }
            set { _PermanentZipcode = value; OnPropertyChanged(); }
        }

        private ObservableCollection<Educational_Details> _ItemSource;
        public ObservableCollection<Educational_Details> ItemSource
        {
            get { return _ItemSource; }
            set { _ItemSource = value; OnPropertyChanged(); }
        }

        private Educational_Details _SelectedItem;
        public Educational_Details SelectedItem
        {
            get { return _SelectedItem; }
            set { _SelectedItem = value; OnPropertyChanged(); }
        }

        private string _Nationality;
        public string Nationality
        {
            get { return _Nationality; }
            set { _Nationality = value; OnPropertyChanged(); }
        }

        private string _PrimarySkills;
        public string PrimarySkills
        {
            get { return _PrimarySkills; }
            set { _PrimarySkills = value; OnPropertyChanged(); }
        }
        private string _PrimarySkillsID;
        public string PrimarySkillsID
        {
            get { return _PrimarySkillsID; }
            set { _PrimarySkillsID = value; OnPropertyChanged(); }
        }

        private string _Secondaryskills;
        public string SecondarySkills
        {
            get { return _Secondaryskills; }
            set { _Secondaryskills = value; OnPropertyChanged(); }
        }
        private string _SecondaryskillsID;
        public string SecondarySkillsID
        {
            get { return _SecondaryskillsID; }
            set { _SecondaryskillsID = value; OnPropertyChanged(); }
        }

        private string _preferredJobLocation;
        public string PreferredJobLocation
        {
            get { return _preferredJobLocation; }
            set { _preferredJobLocation = value; OnPropertyChanged(); }
        }

        private string _preferredJobLocationID;
        public string PreferredJobLocationID
        {
            get { return _preferredJobLocationID; }
            set { _preferredJobLocationID = value; OnPropertyChanged(); }

        }

        #endregion

        #region SavePersonalDetails
        async Task SavePersonalDetails()
        {
            System.Diagnostics.Debug.WriteLine("@ SeekerPersonalAndEducationPage.SavePersonalDetails");
            try
            {
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {
                    if (IsValidatePersonalDetails())
                    {
                        var personaldetailsrequest = new ProfileDetailsRequestData();

                        personaldetailsrequest.FirstName = _SeekerDashboardResponseModel.ProfileDetails.FirstName;
                        personaldetailsrequest.LastName = _SeekerDashboardResponseModel.ProfileDetails.LastName;
                        personaldetailsrequest.EmailAddress = EmailID;
                        personaldetailsrequest.MobileNumber = _SeekerDashboardResponseModel.ProfileDetails.MobileNumber;
                        personaldetailsrequest.DateOfBirth = DatepickerValue;
                        personaldetailsrequest.Gender = Gender;
                        personaldetailsrequest.Disablity = HandicappedData;
                        personaldetailsrequest.Nationality = _SeekerDashboardResponseModel.ProfileDetails.NationalityID;
                        personaldetailsrequest.AadharNumber = AadhaarNumber ?? string.Empty;
                        personaldetailsrequest.PassportNumber = PassPortNumber ?? string.Empty;
                        personaldetailsrequest.panNo = PANNumber ?? string.Empty;
                        personaldetailsrequest.CurrentAddress = CurrentAddress;
                        personaldetailsrequest.CurrentStateID = _SeekerDashboardResponseModel.ProfileDetails.CurrentStateId;
                        personaldetailsrequest.CurrentCityID = _SeekerDashboardResponseModel.ProfileDetails.CurrentCityId;
                        personaldetailsrequest.CurrentPinCode = CurrentZipcode;
                        personaldetailsrequest.PermanentAddress = PermanentAddress;
                        personaldetailsrequest.PermanentStateID = _SeekerDashboardResponseModel.ProfileDetails.PermanentStateID;
                        personaldetailsrequest.PermanentCityID = _SeekerDashboardResponseModel.ProfileDetails.PermanentCityID;
                        personaldetailsrequest.PermanentPinCode = PermanentZipcode;
                        personaldetailsrequest.JobLocationId = _SeekerDashboardResponseModel.ProfileDetails.prefer_location_id;
                        personaldetailsrequest.aboutMe = AboutMe;
                        personaldetailsrequest.faceBookLink = FaceBookLink;
                        personaldetailsrequest.twitterLink = TwitterLink;
                        personaldetailsrequest.googlePlusLink = GooglePlusLink;
                        personaldetailsrequest.linkedinLink = LinkedInLink;
                        personaldetailsrequest.Languages = _selectionLanguages.ToArray();
                        personaldetailsrequest.is_copy = IsCopy.ToString();

                        UserDialogs.Instance.ShowLoading();
                        var response = await _commonservice.PostAsync<ProfileDetailsResponseData, ProfileDetailsRequestData>(APIData.API_BASE_URL + APIMethods.PersonalDetailsUpdate_V8, personaldetailsrequest);
                        if (response != null)
                        {
                            if (response.code == "200")
                            {
                                //Update AssessmentData with IsSynched=true
                                //await UserDialogs.Instance.AlertAsync(response.Message);
                                UserDialogs.Instance.HideLoading();
                                _isPersonalDetailsUpdated = true;
                                AppPreferences.IsProfileCompleted = true;
                                AppPreferences.IsFirstRun = false;
                                NavigateToNextPageIfNeeded();
                                await ShowEducationalTab();
                            }
                            else if (response.code == "402" || response.code == "199")
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.SessionExpiered);
                                Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                                return;
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(response.message);
                            }
                        }
                        //BtnSavePersonal.IsEnabled = true;
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
            {
                //await UserDialogs.Instance.AlertAsync(ex.Message);
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.SavePersonalDetails");
            }
        }
        #endregion

        #region BindCourseTypeData
        async Task BindCourseTypeData()
        {
            System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindCourseTypeData");
            try
            {
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {
                    MasterTableRequestData MasterTableRequestData = new MasterTableRequestData()
                    {
                        HiremeeID = AppSessionData.ActiveToken.HireMeID,
                        Token = AppSessionData.ActiveToken.Token,
                        TableName = "coursetype"
                    };
                    UserDialogs.Instance.ShowLoading();
                    var coursetypes = await _commonservice.PostAsync<CourseTypeResponseData, MasterTableRequestData>(APIData.API_BASE_URL + APIMethods.MasterTables, MasterTableRequestData);

                    if (coursetypes != null)
                    {
                        if (coursetypes.code == "200")
                        {
                            //GlobalCommonListItemSource = coursetypes.Response.Response;
                            UserDialogs.Instance.HideLoading();
                            if (_courseTypeID == null)
                            {
                                _courseTypeID = new List<string>();
                                _courseTypeID.Clear();
                            }

                            var page = new AddEducationPopupPage(_courseTypeID, coursetypes.Response.Response, ItemSource);
                            await _navigationservice.PushAsync(page);

                        }
                        else if (coursetypes.code == "199")
                        {
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.SessionExpiered);
                            Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                            return;
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(coursetypes.message);
                        }
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerNotificationViewModel.BindCourseTypeData");
            }
        }
        #endregion

        #region ShowPersonalTab
        public async Task ShowPersonalTab()
        {
            try
            {
                UserDialogs.Instance.HideLoading();
                if (AppPreferences.LoadSeekerDashboardData != null)
                {
                    BindFromPreference_PersonalDetails();
                }

                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {
                    await GetJobSeekerDetails();
                }
                PersonalBackbtnColor = Color.FromHex("#F7CC59");
                EducationBackbtnColor = Color.Transparent;
                IsPersonalGrid = true;
                IsEducationGrid = false;
                PageTitle = "Personal";
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.ShowPersonalTab");
            }
        }
        #endregion

        #region ShowEducationalTab
        public async Task ShowEducationalTab()
        {
            UserDialogs.Instance.HideLoading();
            if (AppPreferences.LoadSeekerDashboardData != null)
            {
                BindFromPreference_EducationDetails();
            }
            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
            if (isNetworkAvailable)
            {
                await GetJobSeekerDetails();
            }
            EducationBackbtnColor = Color.FromHex("#F7CC59");
            PersonalBackbtnColor = Color.Transparent;
            IsEducationGrid = true;
            IsPersonalGrid = false;
            PageTitle = "Education";
        }
        #endregion

        #region BindFromPreference_PersonalDetails
        public void BindFromPreference_PersonalDetails()
        {
            try
            {
                if (AppPreferences.LoadSeekerDashboardData.ProfileDetails == null)
                {
                    UserDialogs.Instance.HideLoading();
                    return;
                }

                SeekerDashboardResponseModel = AppPreferences.LoadSeekerDashboardData;
                if (SeekerDashboardResponseModel != null)
                {

                    LoadBasicDetails(SeekerDashboardResponseModel);

                    DatepickerValue = SeekerDashboardResponseModel.ProfileDetails.Dateofbirth;
                    if (DatepickerValue != null && DatepickerValue != "Date of Birth" && DatepickerValue != "0000-00-00")
                    {
                        DateTime Dob = DateTime.Parse(DatepickerValue);
                        DateTime now = DateTime.Today;
                        int age = now.Year - Dob.Year;
                        if (Dob.AddYears(age) > now)
                            age--;

                        Age = age.ToString();
                    }
                    Gender = SeekerDashboardResponseModel.ProfileDetails.Gender ?? string.Empty;
                    HandicappedData = SeekerDashboardResponseModel.ProfileDetails.Disablity ?? string.Empty;
                    AadhaarNumber = SeekerDashboardResponseModel.ProfileDetails.AadharNumber;
                    PassPortNumber = SeekerDashboardResponseModel.ProfileDetails.PassportNumber;
                    PANNumber = SeekerDashboardResponseModel.ProfileDetails.panNo;
                    AboutMe = SeekerDashboardResponseModel.ProfileDetails.aboutMe;
                    FaceBookLink = SeekerDashboardResponseModel.ProfileDetails.faceBookLink;
                    TwitterLink = SeekerDashboardResponseModel.ProfileDetails.twitterLink;
                    GooglePlusLink = SeekerDashboardResponseModel.ProfileDetails.googlePlusLink;
                    LinkedInLink = SeekerDashboardResponseModel.ProfileDetails.linkedinLink;

                    if (SeekerDashboardResponseModel.ProfileDetails.is_copy == "1")
                    {
                        IsToggleSameAddress = true;
                    }
                    else
                    {
                        IsToggleSameAddress = false;
                    }


                    if (string.IsNullOrEmpty(SeekerDashboardResponseModel.ProfileDetails.NationalityID) || SeekerDashboardResponseModel.ProfileDetails.NationalityName == null)
                        Nationality = "Select Nationality";
                    else
                        Nationality = SeekerDashboardResponseModel.ProfileDetails.NationalityName;


                    CurrentAddress = SeekerDashboardResponseModel.ProfileDetails.CurrentAddress ?? string.Empty;

                    if (string.IsNullOrEmpty(SeekerDashboardResponseModel.ProfileDetails.CurrentZipcode) || Int32.Parse(SeekerDashboardResponseModel.ProfileDetails.CurrentZipcode) == 0)
                    {
                        CurrentZipcode = string.Empty;
                    }
                    else
                    {
                        CurrentZipcode = SeekerDashboardResponseModel.ProfileDetails.CurrentZipcode;
                    }

                    if (string.IsNullOrEmpty(SeekerDashboardResponseModel.ProfileDetails.CurrentStateId) || SeekerDashboardResponseModel.ProfileDetails.CurrentStateId == "0")
                    {
                        SeekerDashboardResponseModel.ProfileDetails.CurrentStateId = string.Empty;
                        SeekerDashboardResponseModel.ProfileDetails.CurrentStateName = MessageStringConstants.SelectCurrentState;
                        CurrentState = MessageStringConstants.SelectCurrentState;
                    }
                    else
                    {
                        SeekerDashboardResponseModel.ProfileDetails.CurrentStateId = SeekerDashboardResponseModel.ProfileDetails.CurrentStateId ?? string.Empty;
                        SeekerDashboardResponseModel.ProfileDetails.CurrentStateName = SeekerDashboardResponseModel.ProfileDetails.CurrentStateName ?? MessageStringConstants.SelectCurrentState;
                        CurrentState = SeekerDashboardResponseModel.ProfileDetails.CurrentStateName ?? MessageStringConstants.SelectCurrentState;
                    }

                    if (string.IsNullOrEmpty(SeekerDashboardResponseModel.ProfileDetails.CurrentCityId) || SeekerDashboardResponseModel.ProfileDetails.CurrentCityId == "0")
                    {

                        SeekerDashboardResponseModel.ProfileDetails.CurrentCityId = string.Empty;
                        SeekerDashboardResponseModel.ProfileDetails.CurrentCityName = MessageStringConstants.SelectCurrentDistrict;
                        CurrentDistrict = MessageStringConstants.SelectCurrentDistrict;
                    }
                    else
                    {
                        SeekerDashboardResponseModel.ProfileDetails.CurrentCityId = SeekerDashboardResponseModel.ProfileDetails.CurrentCityId ?? string.Empty;
                        SeekerDashboardResponseModel.ProfileDetails.CurrentCityName = SeekerDashboardResponseModel.ProfileDetails.CurrentCityName ?? MessageStringConstants.SelectCurrentDistrict;
                        CurrentDistrict = SeekerDashboardResponseModel.ProfileDetails.CurrentCityName ?? MessageStringConstants.SelectCurrentDistrict;
                    }

                    SeekerDashboardResponseModel.ProfileDetails.PermanentAddress = SeekerDashboardResponseModel.ProfileDetails.PermanentAddress;
                    PermanentAddress = SeekerDashboardResponseModel.ProfileDetails.PermanentAddress;
                    if (string.IsNullOrEmpty(SeekerDashboardResponseModel.ProfileDetails.PermanentZipcode) || Int32.Parse(SeekerDashboardResponseModel.ProfileDetails.PermanentZipcode) == 0)
                    {
                        SeekerDashboardResponseModel.ProfileDetails.PermanentZipcode = string.Empty;
                        PermanentZipcode = string.Empty;
                    }
                    else
                    {
                        SeekerDashboardResponseModel.ProfileDetails.PermanentZipcode = SeekerDashboardResponseModel.ProfileDetails.PermanentZipcode;
                        PermanentZipcode = SeekerDashboardResponseModel.ProfileDetails.PermanentZipcode;
                    }

                    if (string.IsNullOrEmpty(SeekerDashboardResponseModel.ProfileDetails.PermanentStateID) || SeekerDashboardResponseModel.ProfileDetails.PermanentStateID == "0")
                    {
                        SeekerDashboardResponseModel.ProfileDetails.PermanentStateID = string.Empty;
                        SeekerDashboardResponseModel.ProfileDetails.PermanentStateName = MessageStringConstants.SelectPermanentState;
                        PermanentState = MessageStringConstants.SelectPermanentState;
                    }
                    else
                    {
                        SeekerDashboardResponseModel.ProfileDetails.PermanentStateID = SeekerDashboardResponseModel.ProfileDetails.PermanentStateID ?? string.Empty;
                        SeekerDashboardResponseModel.ProfileDetails.PermanentStateName = SeekerDashboardResponseModel.ProfileDetails.PermanentStateName ?? MessageStringConstants.SelectPermanentState;
                        PermanentState = SeekerDashboardResponseModel.ProfileDetails.PermanentStateName ?? MessageStringConstants.SelectPermanentState;
                    }

                    if (string.IsNullOrEmpty(SeekerDashboardResponseModel.ProfileDetails.PermanentCityID) || SeekerDashboardResponseModel.ProfileDetails.PermanentCityID == "0")
                    {
                        SeekerDashboardResponseModel.ProfileDetails.PermanentCityID = string.Empty;
                        SeekerDashboardResponseModel.ProfileDetails.PermanentCityName = MessageStringConstants.SelectPermanentDistrict;
                        PermanentDistrict = MessageStringConstants.SelectPermanentDistrict;
                    }
                    else
                    {
                        SeekerDashboardResponseModel.ProfileDetails.PermanentCityID = SeekerDashboardResponseModel.ProfileDetails.PermanentCityID ?? string.Empty;
                        SeekerDashboardResponseModel.ProfileDetails.PermanentCityName = SeekerDashboardResponseModel.ProfileDetails.PermanentCityName ?? MessageStringConstants.SelectPermanentDistrict;
                        PermanentDistrict = SeekerDashboardResponseModel.ProfileDetails.PermanentCityName ?? MessageStringConstants.SelectPermanentDistrict;
                    }

                }

                if (SeekerDashboardResponseModel.Languages != null)
                {
                    BindLanguage(SeekerDashboardResponseModel.Languages);
                }
                else
                {
                    Languages = "Select Language";
                }

                if (SeekerDashboardResponseModel.prefer_job_location != null)
                {
                    BindJobLocation(SeekerDashboardResponseModel.prefer_job_location);
                }
                else
                {
                    PreferredJobLocation = MessageStringConstants.SelectPreferredJobLocation;
                }

                UserDialogs.Instance.HideLoading();
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.BindFromPreference_PersonalDetails");
            }
        }
        #endregion

        #region BindFromPreference_EducationDetails
        public async void BindFromPreference_EducationDetails()
        {
            try
            {
                var result = AppPreferences.LoadSeekerDashboardData;

                LoadBasicDetails(result);

                #region primaryskills
                try
                {
                    //compare selected primary skill with seeker dashboard primary skill, if both are similar no need to bind again
                    if (result.EducationalDetailsResponseData.Primaryskills == null)
                    {
                        _selectedPrimarySkills = new List<Skill>();
                        GeneratePrimarySkills(_selectedPrimarySkills);
                    }
                    else
                    {
                        var query = _selectedPrimarySkills.Where(item => !result.EducationalDetailsResponseData.Primaryskills.Equals(item.ID));
                        if (query.Count() == 0)
                        {
                            _selectedPrimarySkills = new List<Skill>();

                            if (result.EducationalDetailsResponseData.Primaryskills != null && result.EducationalDetailsResponseData.Primaryskills.Count != 0)
                            {
                                foreach (var item in result.EducationalDetailsResponseData.Primaryskills)
                                {
                                    Skill obj = new Skill();
                                    obj.ID = item.ID;
                                    obj.SkillName = item.SkillName;
                                    obj.IsSelected = true;
                                    _selectedPrimarySkills.Add(obj);
                                }
                            }
                            GeneratePrimarySkills(_selectedPrimarySkills);
                        }
                    }
                }
                catch (Exception ex)
                {
                    SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.PrimarySkills");
                }
                #endregion

                #region  SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.BindFromPreference_EducationDetails");
                try
                {
                    if (result.EducationalDetailsResponseData.Secondaryskills == null)
                    {
                        _selectedSecondarySkills = new List<Skill>();
                        GenerateSecondarySkills(_selectedSecondarySkills);
                    }
                    else
                    {
                        var query = _selectedSecondarySkills.Where(item => !result.EducationalDetailsResponseData.Secondaryskills.Equals(item.ID));
                        if (query.Count() == 0)
                        {
                            _selectedSecondarySkills = new List<Skill>();
                            if (result.EducationalDetailsResponseData.Secondaryskills != null && result.EducationalDetailsResponseData.Secondaryskills.Count != 0)
                            {
                                foreach (var item in result.EducationalDetailsResponseData.Secondaryskills)
                                {
                                    Skill obj = new Skill();
                                    obj.ID = item.ID;
                                    obj.SkillName = item.SkillName;
                                    obj.IsSelected = true;
                                    _selectedSecondarySkills.Add(obj);
                                }
                            }
                            GenerateSecondarySkills(_selectedSecondarySkills);
                        }
                    }
                }
                catch (Exception ex)
                {
                    SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.SecondarySkills");
                }
                #endregion
                if (result.EducationalDetailsResponseData.certifications != null)
                    await BindCertificateData(result.EducationalDetailsResponseData.certifications);

                #region Load educational details
                if (result.EducationalDetailsResponseData.educational_details != null)
                {
                    ItemSource.Clear();
                    StackLayout_SchoolorCollege.Children.Clear();

                    for (int i = 0; i < result.EducationalDetailsResponseData.educational_details.Length; i++)
                    {
                        Educational_Details obj = new Educational_Details();
                        obj.hiremee_id = result.EducationalDetailsResponseData.educational_details[i].hiremee_id;
                        obj.coursetype_id = result.EducationalDetailsResponseData.educational_details[i].coursetype_id;
                        obj.course_type_name = result.EducationalDetailsResponseData.educational_details[i].course_type_name;
                        obj.course_id = result.EducationalDetailsResponseData.educational_details[i].course_id;
                        obj.course_name = result.EducationalDetailsResponseData.educational_details[i].course_name;
                        obj.specialization_id = result.EducationalDetailsResponseData.educational_details[i].specialization_id;
                        obj.specialization_name = result.EducationalDetailsResponseData.educational_details[i].specialization_name;
                        obj.educational_level = result.EducationalDetailsResponseData.educational_details[i].educational_level;
                        obj.board_id = result.EducationalDetailsResponseData.educational_details[i].board_id;
                        obj.board_name = result.EducationalDetailsResponseData.educational_details[i].board_name;
                        obj.school_name = result.EducationalDetailsResponseData.educational_details[i].school_name;
                        obj.college_id = result.EducationalDetailsResponseData.educational_details[i].college_id;
                        obj.college_name = result.EducationalDetailsResponseData.educational_details[i].college_name;
                        obj.university_id = result.EducationalDetailsResponseData.educational_details[i].university_id;
                        obj.university_name = result.EducationalDetailsResponseData.educational_details[i].university_name;
                        obj.year_of_completion = result.EducationalDetailsResponseData.educational_details[i].year_of_completion;
                        obj.cgpa = result.EducationalDetailsResponseData.educational_details[i].cgpa;
                        obj.percentage = result.EducationalDetailsResponseData.educational_details[i].percentage;
                        obj.backlog = result.EducationalDetailsResponseData.educational_details[i].backlog;
                        obj.zip_code = result.EducationalDetailsResponseData.educational_details[i].zip_code;
                        obj.registerNo = result.EducationalDetailsResponseData.educational_details[i].registerNo;
                        obj.DisplayCourseTypeName = result.EducationalDetailsResponseData.educational_details[i].course_type_name;

                        if (string.IsNullOrEmpty(result.EducationalDetailsResponseData.educational_details[i].board_name))
                        {
                            obj.DisplayBoardNameOrUniversityName = result.EducationalDetailsResponseData.educational_details[i].university_name;
                        }
                        else
                        {
                            obj.DisplayBoardNameOrUniversityName = result.EducationalDetailsResponseData.educational_details[i].board_name;
                        }

                        if (string.IsNullOrEmpty(result.EducationalDetailsResponseData.educational_details[i].school_name))
                        {
                            obj.DisplaySchoolNameOrCollegeName = result.EducationalDetailsResponseData.educational_details[i].college_name.Replace("\r\n", string.Empty);
                        }
                        else
                        {
                            obj.DisplaySchoolNameOrCollegeName = result.EducationalDetailsResponseData.educational_details[i].school_name.Replace("\r\n", string.Empty);
                        }

                        if (string.IsNullOrEmpty(result.EducationalDetailsResponseData.educational_details[i].cgpa) || result.EducationalDetailsResponseData.educational_details[i].cgpa == "0" || result.EducationalDetailsResponseData.educational_details[i].cgpa == "0.0" || result.EducationalDetailsResponseData.educational_details[i].cgpa == "0.00")
                        {
                            obj.DisplayCGPAOrPercentage = result.EducationalDetailsResponseData.educational_details[i].percentage + " % - ";
                        }
                        else
                        {
                            obj.DisplayCGPAOrPercentage = result.EducationalDetailsResponseData.educational_details[i].cgpa + " CGPA - ";
                        }

                        obj.DisplayYearOfPassing = result.EducationalDetailsResponseData.educational_details[i].year_of_completion;

                        ItemSource.Add(obj);




                        var CourseTypeName = new Label { Text = obj.DisplayCourseTypeName, TextColor = Color.Black, FontAttributes = FontAttributes.Bold, LineBreakMode = LineBreakMode.TailTruncation };
                        var BoardNameOrUniversityName = new Label { Text = obj.DisplayBoardNameOrUniversityName, TextColor = Color.Black, VerticalOptions = LayoutOptions.FillAndExpand, LineBreakMode = LineBreakMode.TailTruncation };
                        var SchoolNameOrCollegeName = new Label { Text = obj.DisplaySchoolNameOrCollegeName, TextColor = Color.Black, LineBreakMode = LineBreakMode.TailTruncation };
                        var CGPAOrPercentage = new Label { Text = obj.DisplayCGPAOrPercentage + obj.DisplayYearOfPassing, TextColor = Color.Black };
                        //    var YearOfPassing = new Label { Text = obj.DisplayYearOfPassing, TextColor = Color.Black };
                        var index = new Label { Text = i.ToString(), IsVisible = false };

                        var underline = new BoxView { HeightRequest = 0.5, Margin = new Thickness(0, 2, 0, 0), BackgroundColor = Color.Gray };
                        var dynamicStackItme = new StackLayout
                        {
                            Margin = 2,
                            VerticalOptions = LayoutOptions.Fill,
                            BackgroundColor = Color.Transparent,
                            HorizontalOptions = LayoutOptions.FillAndExpand,
                            Orientation = StackOrientation.Vertical
                        };



                        var _tapGesture = new TapGestureRecognizer();
                        _tapGesture.Tapped += (s, e) =>
                        {
                            StackLayout stackLayout = (StackLayout)s;
                            Label selectedIndex = (Label)stackLayout.Children[4];
                            SelectedItem = ItemSource[int.Parse(selectedIndex.Text.ToString())];

                            if (isClicked)
                            {
                                isClicked = false;
                                if (SelectedItem.educational_level == "1" || SelectedItem.educational_level == "2")
                                {
                                    _navigationservice.PushAsync(new SchoolingEducationDetailsPage(Constants.FieldType.EditEducation, ItemSource, SelectedItem));
                                }
                                else if (SelectedItem.educational_level == "3" || SelectedItem.educational_level == "4" || SelectedItem.educational_level == "5")
                                {
                                    //if (string.IsNullOrEmpty(AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.AssessFlag) || !AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.AssessFlag.Equals("1"))//here 1 means user completed assessment, so cannot able to change their assessment details{
                                    //{
                                    _navigationservice.PushAsync(new CollegeEducationDetailsPage(Constants.FieldType.EditEducation, ItemSource, SelectedItem));
                                    //}
                                    //else
                                    //{
                                    //    UserDialogs.Instance.AlertAsync(MessageStringConstants.AlreadyCompletedAssessment);
                                    //}
                                }
                            }
                            Task.Run(async () =>
                            {
                                await Task.Delay(500);
                                isClicked = true;
                            });

                        };
                        dynamicStackItme.GestureRecognizers.Add(_tapGesture);


                        dynamicStackItme.Children.Add(CourseTypeName);
                        dynamicStackItme.Children.Add(BoardNameOrUniversityName);
                        dynamicStackItme.Children.Add(SchoolNameOrCollegeName);
                        dynamicStackItme.Children.Add(CGPAOrPercentage);
                        //   firstStack.Children.Add(YearOfPassing);
                        dynamicStackItme.Children.Add(index);
                        dynamicStackItme.Children.Add(underline);
                        StackLayout_SchoolorCollege.Children.Add(dynamicStackItme);
                    }
                    _courseTypeID = new List<string>();
                    _courseTypeID.Clear();

                    //_educationalLevel = new List<string>();
                    //_educationalLevel.Clear();
                    for (int i = 0; i < result.EducationalDetailsResponseData.educational_details.Length; i++)
                    {
                        _courseTypeID.Add(result.EducationalDetailsResponseData.educational_details[i].educational_level);
                    }
                }
                else
                {
                    _courseTypeID = new List<string>();
                    _courseTypeID.Clear();
                    ItemSource.Clear();
                    StackLayout_SchoolorCollege.Children.Clear();
                }
                #endregion
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.BindFromPreference_EducationDetails");
            }
        }

        public async Task BindCertificateData(ObservableCollection<CertificationDetails> _certifications)
        {
            try
            {
                if (_certifications != null)
                {
                    //var IsCertificatesModified = _certifications.Where(a => !certifications.Any(a1 => a1.certification_name == a.certification_name));
                    //if (certifications.Count()!=_certifications.Count()||  IsCertificatesModified.Count() > 0)
                    //{
                    DisplayCertificateStackLayout.Children.Clear();
                    certifications = _certifications;
                    Grid grid = new Grid();
                    DisplayCertificateStackLayout.VerticalOptions = LayoutOptions.Start;
                    DisplayCertificateStackLayout.HorizontalOptions = LayoutOptions.Fill;
                    //DisplayCertificateStackLayout.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

                    //This below stacklayout used for padding space and background color
                    StackLayout stackLayoutBackground = new StackLayout();

                    for (int c = 0; c < certifications.Count; c++)
                    {
                        if (Device.Idiom == TargetIdiom.Phone)
                        {
                            stackLayoutBackground = new StackLayout
                            {
                                BackgroundColor = Color.FromHex("#c2c99c"),
                                Padding = 8,
                                Margin = 3,
                                Orientation = StackOrientation.Vertical,
                                HorizontalOptions = LayoutOptions.Fill,
                                // VerticalOptions = LayoutOptions.Fill,
                                WidthRequest = 120,
                            };

                            Label _certification_name = new Label
                            {
                                Text = certifications[c].certification_name,
                                TextColor = Color.Black,
                                ClassId = c.ToString(),
                                FontSize = 13,
                                HorizontalTextAlignment = TextAlignment.Center,
                                VerticalTextAlignment = TextAlignment.Center,
                                HorizontalOptions = LayoutOptions.CenterAndExpand,
                                VerticalOptions = LayoutOptions.CenterAndExpand,
                                WidthRequest = 120,
                            };
                            Label _certification_year = new Label
                            {
                                Text = certifications[c].certification_year,
                                TextColor = Color.Black,
                                ClassId = c.ToString(),
                                FontSize = 13,
                                HorizontalTextAlignment = TextAlignment.Center,
                                VerticalTextAlignment = TextAlignment.Center,
                                HorizontalOptions = LayoutOptions.CenterAndExpand,
                                VerticalOptions = LayoutOptions.CenterAndExpand,
                                WidthRequest = 120,
                            };
                            stackLayoutBackground.Children.Add(_certification_name);
                            stackLayoutBackground.Children.Add(_certification_year);

                        }

                        DisplayCertificateStackLayout.Children.Add(stackLayoutBackground);
                        Grid.SetRow(stackLayoutBackground, 0);//r
                        Grid.SetColumn(stackLayoutBackground, c);

                        DisplayCertificateStackLayout.Children.Add(grid);
                        //  DisplayCertificateCustomScrollView.Children.Add(grid);
                        Device.BeginInvokeOnMainThread(async () =>
                        {
                            await DisplayCertificateCustomScrollView.ScrollToAsync(0, 0, true);
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.GeneratePrimarySkills");
            }
        }
        #endregion

        #region LoadBasicDetails
        private void LoadBasicDetails(SeekerDashboardResponseModel result)
        {
            try
            {
                //LastName = result.ProfileDetails.LastName;
                // FirstName = result.ProfileDetails.FirstName;
                FullName = result.ProfileDetails.FirstName.ToUpper() + " " + result.ProfileDetails.LastName.ToUpper();
                EmailID = result.ProfileDetails.EmailAddress;
                MobileNo = result.ProfileDetails.MobileNumber;
                HiremeeID = "HireMee ID : " + result.ProfileDetails.HireMeeID;
                profilepic = (string)Application.Current.Resources["IconUser"];

                if (AppPreferences.ProfilePicture != string.Empty)
                    profilepic = AppPreferences.ProfilePicture;
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.LoadBasicDetails");
            }
        }
        #endregion

        #region IsValidatePersonalDetails
        bool IsValidatePersonalDetails()
        {
            try
            {
                if (DatepickerValue == "0000-00-00")
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync("Select Date of birth");
                    });
                    return false;
                }

                if (string.IsNullOrEmpty(Gender))
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync("Select Gender");
                    });
                    return false;
                }
                if (string.IsNullOrEmpty(HandicappedData))
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync("Select Disablity");
                    });
                    return false;
                }

                if (!string.IsNullOrEmpty(AadhaarNumber) && !Utilities.ValidateAadhaarNumber(AadhaarNumber))
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidAadhaarNumber);
                    });
                    return false;
                }
                if (!string.IsNullOrEmpty(PassPortNumber) && !Utilities.ValidatePassportNumber(PassPortNumber))
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidPassportNumber);
                    });
                    return false;
                }
                if (string.IsNullOrEmpty(Languages) || Languages == "Select Language")
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync("Select Language");
                    });
                    return false;
                }
                if (string.IsNullOrEmpty(_SeekerDashboardResponseModel.ProfileDetails.NationalityID) || Nationality.Contains("Select Nationality"))
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync("Select Nationality");
                    });
                    return false;
                }

                if (string.IsNullOrEmpty(CurrentAddress) || !Utilities.Address(CurrentAddress))
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterCurrentAddress);
                    });
                    return false;
                }
                else if (CurrentAddress.Length < 15)
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterCurrentAddressLength);
                    });
                    return false;
                }

                if (string.IsNullOrEmpty(CurrentZipcode) || !Utilities.ValidatePincode(CurrentZipcode))
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidCurrentPincode);
                        CurrentZipcode = string.Empty;

                    });
                    return false;
                }

                if (CurrentZipcode == "000000")
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidCurrentPincode);
                        CurrentZipcode = string.Empty;

                    });
                    return false;
                }


                if (string.IsNullOrEmpty(_SeekerDashboardResponseModel.ProfileDetails.CurrentStateId) || _SeekerDashboardResponseModel.ProfileDetails.CurrentStateName == MessageStringConstants.SelectCurrentState)
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectCurrentState);
                    }); return false;
                }
                if (string.IsNullOrEmpty(_SeekerDashboardResponseModel.ProfileDetails.CurrentCityId) || _SeekerDashboardResponseModel.ProfileDetails.CurrentCityName == MessageStringConstants.SelectCurrentDistrict)
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectCurrentDistrict);
                    }); return false;
                }


                if (string.IsNullOrEmpty(PermanentAddress) || !Utilities.Address(PermanentAddress))
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterPermanentAddress);
                    });
                    return false;
                }
                else if (PermanentAddress.Length < 15)
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterPermanentAddressLength);
                    });
                    return false;
                }

                if (string.IsNullOrEmpty(PermanentZipcode) || !Utilities.ValidatePincode(PermanentZipcode))
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidPermanentPincode);
                        PermanentZipcode = string.Empty;
                    });
                    return false;
                }
                if (PermanentZipcode == "000000")
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidCurrentPincode);
                        CurrentZipcode = string.Empty;

                    });
                    return false;
                }

                if (string.IsNullOrEmpty(_SeekerDashboardResponseModel.ProfileDetails.PermanentStateID) || PermanentState == MessageStringConstants.SelectPermanentState)
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectPermanentState);
                    }); return false;
                }
                if (string.IsNullOrEmpty(_SeekerDashboardResponseModel.ProfileDetails.PermanentCityID) || PermanentDistrict == MessageStringConstants.SelectPermanentDistrict)
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectPermanentDistrict);
                    }); return false;
                }


                if (string.IsNullOrEmpty(_SeekerDashboardResponseModel.ProfileDetails.prefer_location_id) || PreferredJobLocation == MessageStringConstants.SelectPreferredJobLocation)
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectPreferredJobLocation);
                    });
                    return false;
                }


                //if (string.IsNullOrEmpty(AboutMe))
                //{
                //    Device.BeginInvokeOnMainThread(async () =>
                //    {
                //        await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterAboutMe);
                //    });
                //    return false;
                //}

                //if (!Utilities.AboutMe(AboutMe))
                //{
                //    Device.BeginInvokeOnMainThread(async () =>
                //    {
                //        await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidAboutMe);
                //    });
                //    return false;
                //}
            }
            catch (Exception)
            {
                return true;
            }
            return true;
        }
        #endregion

        #region NavigateToNextPageIfNeeded
        private void NavigateToNextPageIfNeeded()
        {
            System.Diagnostics.Debug.WriteLine("@ SeekerPersonalAndEducationPage.NavigateToNextPageIfNeeded");
            if (!Convert.ToBoolean(AppPreferences.IsDashboard))
            {
                if (AppPreferences.IsProfileCompleted == true && AppPreferences.IsEducationCompleted == true)
                {
                    AppPreferences.IsDashboard = true;
                    Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                    return;
                }
                else if (_isPersonalDetailsUpdated && _isEducationDetailsUpdated)
                {
                    AppPreferences.IsDashboard = true;
                    AppPreferences.IsProfileCompleted = true;
                    AppPreferences.IsEducationCompleted = true;
                    Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                    return;
                }
            }
        }
        #endregion

        #region GetUserPicDetail
        public async Task GetUserPic(string GetUserPicDetail)
        {
            try
            {
                if (string.IsNullOrEmpty(GetUserPicDetail) || GetUserPicDetail == null)
                {
                    profilepic = (string)Application.Current.Resources["IconUser"];
                }
                else
                {
                    var Imagedownloader = new S3ImageDownloder();
                    Imagedownloader.DownloadProfilePicture(GetUserPicDetail);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                profilepic = (string)Application.Current.Resources["IconUser"];
                SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.GetUserPicDetail");
            }
        }
        #endregion

        #region UploadProfilePicture
        async public Task UploadProfilePicture()
        {
            #region UserDialogs.ActionSheet Configurations

            //var page = new PopupActionSheetPage(MessageStringConstants.SeekerPersonalPageName);
            //await PopupNavigation.PushAsync(page);

            ActionSheetConfig ActionSheetConfigurations = new ActionSheetConfig();
            ActionSheetConfigurations.SetTitle("Profile Photo");
            ActionSheetConfigurations.Add("Pick from Gallery", () =>
            {
                UploadProfilePicture("Pick from Gallery");
            });
            ActionSheetConfigurations.Add("Camera", () =>
            {
                UploadProfilePicture("Camera");
            });
            ActionSheetConfigurations.Add("Cancel", () => { });
            UserDialogs.Instance.ActionSheet(ActionSheetConfigurations);
            #endregion
        }

        public async void UploadProfilePicture(string action)
        {
            MediaFile file = null;
            try
            {
                #region Pick from Gallery
                if (action == "Pick from Gallery")
                {

                    try
                    {
                        var status = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Storage);
                        if (status != PermissionStatus.Granted)
                        {
                            if (await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Storage))
                            {
                                await UserDialogs.Instance.AlertAsync("Access Storage", "Need Storage Permission", "OK");

                            }

                            var results = await CrossPermissions.Current.RequestPermissionsAsync(new[] { Permission.Storage });
                            status = results[Permission.Storage];
                        }

                        if (status == PermissionStatus.Granted)
                        {
                            await Task.Delay(1000);
                            file = await CrossMedia.Current.PickPhotoAsync(new PickMediaOptions { PhotoSize = PhotoSize.Medium, });
                            if (file != null)
                            {
                                var memoryStream = new MemoryStream();
                                await file.GetStream().CopyToAsync(memoryStream);
                                byte[] imageAsByte = memoryStream.ToArray();
                                await _navigationservice.PushModalAsync(new CropView(imageAsByte, Refresh));
                            }
                        }
                        else if (status != PermissionStatus.Unknown)
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.PermissionMessage);

                        }
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.WriteLine(ex.Message);
                        SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.UploadProfilePicture");
                    }
                }
                #endregion

                #region Camera
                else if (action == "Camera")
                {
                    try
                    {
                        var status = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Camera);
                        if (status != PermissionStatus.Granted)
                        {
                            if (await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Camera))
                            {
                                await UserDialogs.Instance.AlertAsync("Access Camera", "Need Camera Permission", "OK");
                            }

                            var results = await CrossPermissions.Current.RequestPermissionsAsync(new[] { Permission.Camera });
                            status = results[Permission.Camera];
                        }

                        if (status == PermissionStatus.Granted)
                        {
                            await Task.Delay(1000);
                            file = await CrossMedia.Current.TakePhotoAsync(new StoreCameraMediaOptions
                            {
                                CompressionQuality = 90,
                                AllowCropping = true,
                                PhotoSize = PhotoSize.Medium,
                                Directory = "HireMee",
                                Name = "HireMeeProfilePic.jpg"
                            });

                            if (file != null)
                            {
                                var memoryStream = new MemoryStream();
                                await file.GetStream().CopyToAsync(memoryStream);
                                byte[] imageAsByte = memoryStream.ToArray();
                                await _navigationservice.PushModalAsync(new CropView(imageAsByte, Refresh));
                            }

                        }
                        else if (status != PermissionStatus.Unknown)
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.PermissionMessage);
                        }
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.WriteLine(ex.Message);
                        SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.UploadProfilePicture");

                    }

                }
                #endregion

                #region Null Check
                else
                {
                    file = null;
                }

                if (file == null)
                {
                    return;
                }

                #endregion

                //#region S3 ImageUpload
                //IsprofilepicEnable = false;
                //string filename = AppSessionData.ActiveToken.HireMeID + "_" + "ProfilePic" + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".png";
                //var filePath = DependencyService.Get<IImageManager>().CopyFile(file.Path, filename);
                //profilepic = filePath;
                //var UserProfileimageLegnth = DependencyService.Get<IImageManager>().ReadImageFile(filePath);
                //var s3fileurl = await S3Manager.UploadFile(filePath, filename, AmazonS3BucketDetails.PhotoBucket);
                //if (!string.IsNullOrEmpty(s3fileurl))
                //{

                //    var data = new UserResourceInsertRequestData();

                //    data.ResourceTypeId = Convert.ToInt32(Models.ResourceType.ProfilePic).ToString();
                //    data.s3Id = filename;
                //    data.ResourceUrl = s3fileurl;
                //    data.ThumbnailUrl = s3fileurl;

                //    var statusResult = await _commonservice.PostAsync<UserResourceInsertResponseData, UserResourceInsertRequestData>(APIData.API_BASE_URL + APIMethods.UserResourceInsert, data);
                //    if (statusResult != null)
                //    {
                //        //var storagedir = DependencyService.Get<IImageManager>().GetStorageDirectory(ResourceTypeEnums.Photos);
                //        //var imagepath = Path.Combine(storagedir, filename);
                //        //profilepic.Source = filePath;
                //        IsprofilepicEnable = true;
                //        AppPreferences.ProfilePicture = filePath;
                //        MessagingCenter.Send(this, "ChangeProfilePicture", filePath);
                //    }
                //    else
                //    {
                //        IsprofilepicEnable = true;
                //        await UserDialogs.Instance.AlertAsync(MessageStringConstants.UnableToUpdateProfilePicture);
                //    }
                //    #endregion

                //}
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("EXCEPTION {0}:  {1}", DateTime.Now, ex.StackTrace);
                SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.UploadProfilePicture");
            }
            finally
            {
                if (file != null)
                {
                    file.Dispose();
                }
            }
        }

        #region SetImageSource
        private async void Refresh()
        {
            try
            {

                if (App.CroppedImage != null && App.CroppedImageFilePath != null)
                {
                    //Stream stream = new MemoryStream(App.CroppedImage);
                    //= ImageSource.FromStream(() => stream);

                    #region Uploading ID Card To S3
                    IsprofilepicEnable = false;
                    string filename = AppSessionData.ActiveToken.HireMeID + "_" + "ProfilePic" + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".png";
                    var filePath = DependencyService.Get<IImageManager>().CopyFile(App.CroppedImageFilePath, filename);
                    profilepic = filePath;
                    var UserProfileimageLegnth = DependencyService.Get<IImageManager>().ReadImageFile(filePath);
                    var s3fileurl = await S3Manager.UploadFile(filePath, filename, AmazonS3BucketDetails.PhotoBucket);
                    if (!string.IsNullOrEmpty(s3fileurl))
                    {
                        UserDialogs.Instance.ShowLoading();
                        var data = new UserResourceInsertRequestData();
                        data.ResourceTypeId = Convert.ToInt32(Models.ResourceType.ProfilePic).ToString();
                        data.s3Id = filename;
                        data.ResourceUrl = s3fileurl;
                        data.ThumbnailUrl = s3fileurl;
                        var result = await _commonservice.PostAsync<UserResourceInsertResponseData, UserResourceInsertRequestData>(APIData.API_BASE_URL + APIMethods.UserResourceInsert, data);

                        if (result != null)
                        {
                            UserDialogs.Instance.HideLoading();
                            if (result.code == "200")
                            {
                                IsprofilepicEnable = true;
                                AppPreferences.ProfilePicture = filePath;
                                MessagingCenter.Send(this, "ChangeProfilePicture", filePath);
                            }
                            else if (result.code == "199")
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.SessionExpiered);
                                Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                                return;
                            }
                            else
                            {
                                IsprofilepicEnable = true;
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.UnableToUpdateProfilePicture);
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                        }
                    }
                }
            }
            #endregion




            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.Refresh");
            }
        }
        #endregion


        private bool _isprofilepicEnable;
        public bool IsprofilepicEnable
        {
            get { return _isprofilepicEnable; }
            set { _isprofilepicEnable = value; OnPropertyChanged(); }
        }
        #endregion

        #region Check Aadhar Number 
        public async Task<bool> CheckAadharNumber(string _AadhaarNumber)
        {

            bool _aadharnumberExist = false;
            try
            {
                var request = new CheckMobileNumberRequest
                {
                    //HiremeeID = AppPreferences.HireMeeID,
                    //Token = AppPreferences.ActiveToken.Token,
                    AadharNumber = _AadhaarNumber
                };
                bool isNetworkConnection = CrossConnectivity.Current.IsConnected;
                if (isNetworkConnection)
                {
                    UserDialogs.Instance.ShowLoading();
                    var statusResult = await _commonservice.PostAsync<CheckMobileNumberResponse, CheckMobileNumberRequest>(APIData.API_BASE_URL + APIMethods.CheckAadharNumber, request);
                    UserDialogs.Instance.HideLoading();
                    if (statusResult != null)
                    {
                        if (statusResult.code == "203")
                        {
                            _aadharnumberExist = true;
                        }
                    }
                }
                else
                {
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.CheckAadharNumber");
            }

            return _aadharnumberExist;
        }
        #endregion

        #region Check Passport Number 
        public async Task<bool> CheckPassportNumber(string _PassPortNumber)
        {

            bool _passportnumberExist = false;
            try
            {
                var request = new CheckMobileNumberRequest
                {
                    // HiremeeID = AppPreferences.HireMeeID,
                    // Token = AppPreferences.ActiveToken.Token,
                    PassportNumber = _PassPortNumber
                };
                var statusResult = await _commonservice.PostAsync<CheckMobileNumberResponse, CheckMobileNumberRequest>(APIData.API_BASE_URL + APIMethods.CheckPassportNumber, request);
                if (statusResult != null)
                {
                    if (statusResult.code == "203")
                    {
                        _passportnumberExist = true;
                    }
                }
                UserDialogs.Instance.HideLoading();
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.CheckPassportNumber");
            }
            return _passportnumberExist;

        }
        #endregion

        #region Check PAN Number 
        public async Task<bool> CheckPANNumber(string PanNumber)
        {

            bool _pannumberExist = false;
            try
            {
                var request = new CheckMobileNumberRequest
                {
                    //  HiremeeID = AppPreferences.HireMeeID,
                    //  Token = AppPreferences.ActiveToken.Token,
                    PANNumber = PanNumber
                };
                var statusResult = await _commonservice.PostAsync<CheckMobileNumberResponse, CheckMobileNumberRequest>(APIData.API_BASE_URL + APIMethods.CheckPanNumber, request);
                if (statusResult != null)
                {
                    if (statusResult.responseText == "1")
                    {
                        _pannumberExist = true;
                    }
                    else if (statusResult.responseText == "0")
                    {
                        _pannumberExist = false;
                    }
                }
                UserDialogs.Instance.HideLoading();
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.CheckPANNumber");
            }
            return _pannumberExist;

        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}

