﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows.Input;
using Acr.UserDialogs;
using MvvmHelpers;
using Xamarin.Forms;
using Plugin.Connectivity;
using HireMe.Helpers;

namespace HireMe
{
    public class CompanyDetailsViewModel : BaseViewModel
	{
		private HttpCommonService _commonservice { get; set; }
		string _idCard = string.Empty;
		public bool isClicked = true;
		INavigation navigation;

        #region Constructor
        public CompanyDetailsViewModel(INavigation _navigation)
		{

			navigation = _navigation;
		
            isEnabledSearchBar = true;
            IsSearchBarVisible = false;
            SearchPlaceHolderText = "Search Company";
            _commonservice = new HttpCommonService();
			isClicked = true;
			ShowCompanyList();
		}
        #endregion


        public List<Companylist> _tempCompanyListItemSource;
        public List<Companylist> TempCompanyListItemSource
        {
            get { return _tempCompanyListItemSource; }
            set { _tempCompanyListItemSource = value; OnPropertyChanged(); }
        }

        public List<Companylist> _CompanyListItemSource;
		public List<Companylist> CompanyListItemSource
		{
			get { return _CompanyListItemSource; }
			set { _CompanyListItemSource = value; OnPropertyChanged(); }
		}


        #region Searchbar Controls
        private bool _isVisibleSearchbarCancel;
        public bool IsVisibleSearchbarCancelButton
        {
            get { return _isVisibleSearchbarCancel; }
            set { _isVisibleSearchbarCancel = value; OnPropertyChanged(); }
        }

        public string _SearchText;
        public string SearchText
        {
            set
            {
                _SearchText = value;
                SearchText_TextChanged();
                OnPropertyChanged();
            }
            get { return _SearchText; }
        }
        public bool _isEnabledSearchBar;

        public bool isEnabledSearchBar
        {
            set { _isEnabledSearchBar = value; OnPropertyChanged(); }
            get { return _isEnabledSearchBar; }
        }
        public Command OnSearchClearCommand => new Command(() =>
        {
            IsVisibleSearchbarCancelButton = false;
            SearchText = string.Empty;
            SearchPlaceHolderText = "Search Company";

        });
        private string _searchPlaceHolder;
        public string SearchPlaceHolderText
        {
            get { return _searchPlaceHolder; }
            set { _searchPlaceHolder = value; OnPropertyChanged(); }
        }
        
        public void SearchText_TextChanged()    {
            var searchtext = SearchText;
            if (string.IsNullOrEmpty(searchtext))
            {
                SearchPlaceHolderText = "Search Company";
                IsVisibleSearchbarCancelButton = false;
                ShowCompanyList();
                return;
            }

            if (TempCompanyListItemSource != null)
            {

                CompanyListItemSource = TempCompanyListItemSource;
                var searchresults = CompanyListItemSource.FindAll((obj) => 
                obj.name.ToLower().Contains(searchtext.ToLower()) || obj.address.ToLower().Contains(searchtext.ToLower()));
                CompanyListItemSource = searchresults;
             
                IsVisibleSearchbarCancelButton = true;
            }

        }

        #endregion
        public ICommand SelectedCommand => new Command(() =>
		{

			// App.dialog.ShowAlert(CompanylistSelectedItem.name.ToString());

			Debug.WriteLine("@ SeekerNotificationPage.NotificationListView_ItemTapped");

			if (isClicked)
			{
				isClicked = false;
                if (CrossConnectivity.Current.IsConnected)
                {
                    navigation.PushAsync(new CompanyFullDetails(CompanylistSelectedItem.id.ToString(), CompanylistSelectedItem.name.ToString()));
                }
                else
                {
                    UserDialogs.Instance.Alert(MessageStringConstants.CheckInternetConnection); 
                }
            }
			Task.Run(async () =>
			{
				await Task.Delay(500);
				isClicked = true;
			});

		});


		private Companylist _CompanylistSelectedItem;
		public Companylist CompanylistSelectedItem
		{
			get { return _CompanylistSelectedItem; }
			set
			{
				_CompanylistSelectedItem = value; OnPropertyChanged();

			}
		}


		#region ShowCompanyList
		public async void ShowCompanyList()
		{
            try
            {
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {

                    var MasterTableRequestData = new MasterTableRequestData()
                    {
                        TableName = "companylist"
                    };
                    UserDialogs.Instance.ShowLoading();
                    var statusResult = await _commonservice.PostAsync<CompanydetailsResponseData, MasterTableRequestData>(APIData.API_BASE_URL + APIMethods.MasterTables, MasterTableRequestData);
                    
                    if (statusResult != null)
                    {
                        if (statusResult.code == "200" && statusResult.ResponseText != null)
                        {
                            if (statusResult.ResponseText.companylist.Count > 0)
                            {
                                IsSearchBarVisible = true;
                                isEnabledSearchBar = true;
                                listCompanyDetails = true;
                                CompanyListItemSource = statusResult.ResponseText.companylist;
                                foreach (var item in CompanyListItemSource)
                                {
                                    item.CombineAddress = item.city + ", " + item.state;
                                }
                                TempCompanyListItemSource = CompanyListItemSource;
                                lblNoRecords = false;
                            }
                            else
                            {
                                IsSearchBarVisible = false;
                                listCompanyDetails = false;
                                lblNoRecords = true;
                            }

                        }
                        else
                        {
                            IsSearchBarVisible = false;
                            listCompanyDetails = false;
                            lblNoRecords = true;
                        }

                      
                    }
                    else
                    {
                        IsSearchBarVisible = false;
                        lblNoRecords = true;
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }

                    UserDialogs.Instance.HideLoading();
                }
                else
                {
                    IsSearchBarVisible = false;
                    lblNoRecords = true;
                    UserDialogs.Instance.HideLoading();
                    UserDialogs.Instance.Alert(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "CompanyDetailsViewModel.ShowCompanyList");
            }
		}
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        private Boolean _listCompanyDetails;
		public Boolean listCompanyDetails
		{
			get { return _listCompanyDetails; }
			set { _listCompanyDetails = value; OnPropertyChanged(); }
		}

		private Boolean _lblNoRecords;
		public Boolean lblNoRecords
		{
			get { return _lblNoRecords; }
			set { _lblNoRecords = value; OnPropertyChanged(); }
		}

        private bool _IsSearchBarVisible;
        public bool IsSearchBarVisible
        {
            get { return _IsSearchBarVisible; }
            set { _IsSearchBarVisible = value; OnPropertyChanged(); }
        }
    }


    
}
