﻿//using Acr.UserDialogs;
//using GalaSoft.MvvmLight.Command;
//using HireMe.DataLayer.Models;
//using HireMe.Helpers;
//using HireMe.Models;
//using HireMe.Models.JobSeeker;
//using HireMe.Models.Recruiter;
//using HireMe.Renderers;
//using HireMe.Services;
//using HireMe.Views;
//using HireMe.Views.JobSeeker;
//using HireMe.Views.Recruiter;
//using MvvmHelpers;
//using Plugin.Connectivity;
//using Plugin.Media;
//using Plugin.Media.Abstractions;
//using Plugin.Permissions;
//using Plugin.Permissions.Abstractions;
//using System;
//using System.Collections.Generic;
//using System.Collections.ObjectModel;
//using System.IO;
//using System.Threading.Tasks;
//using System.Windows.Input;
//using Xamarin.Forms;

//namespace HireMe.ViewModels.JobSeeker
//{
//    public class FloatingLabelEntryViewModel : BaseViewModel, IValueGetter
//    {
//        //public ICommand FocusDatePickerCommand { get; set; }
//        //public ICommand OnSaveCommand { get; set; }
//        //private HttpCommonService _commonservice { get; set; }
//        //public string ErrorMessage { get; set; }
//        //public INavigation _navigationservice;
//        //List<Skill> _selectionSkills;
//        //List<JobLocation> _selectionJobLocation;
//        //List<CourseType> GlobalCommonListItemSource;
//        //public CommonListItemSource temptItemSource { get; set; }
//        //public UserEmailUpdateModel _UserEmailUpdateModel { get; set; }
//        //public UserEmailUpdateResponse _UserEmailUpdateResponse { get; set; }


//        //private List<string> _courseTypeID;
//        //private List<string> _educationalLevel;

//        //Educational_Details _modifiEducationalDetails;
//        //List<Languageknown> _selectionLanguages;
//        //bool _isPersonalDetailsUpdated, _isEducationDetailsUpdated;
//        //public SeekerDashboardModel _JobSeekerDashboardRequestData;
//        //public CollegeEducationDetailsRequest _EducaionalDetailsRequestData;
//        //public SeekerPersonalAndEducationPage _SeekerPersonalPage;
//        //public EducationTokenRequestData BaseRequest;
//        //public bool isClicked = true;

//        //private StackLayout myVar;

//        //public StackLayout StackLayout_SchoolorCollege
//        //{
//        //    get { return myVar; }
//        //    set { myVar = value; OnPropertyChanged(); }
//        //}
//        //private StackLayout _dynamicLabelStack;

//        //public StackLayout DynamicLabelStack
//        //{
//        //    get { return _dynamicLabelStack; }
//        //    set { _dynamicLabelStack = value; }
//        //}
//        //private ScrollView _dynamicLabelScrollView;
//        //public ScrollView DynamicLabelScrollView
//        //{
//        //    get
//        //    {
//        //        return _dynamicLabelScrollView;
//        //    }
//        //    set
//        //    {
//        //        _dynamicLabelScrollView = value;
//        //    }
//        //}
//        //public FloatingLabelEntryViewModel(INavigation nav, StackLayout dynamic_StackLayout_SchoolorCollege, ScrollView dynamicSkillScroll, StackLayout dynamicLabelGrid)
//        //{

//        //    _navigationservice = nav;
//        //    ItemSource = new ObservableCollection<Educational_Details>();
//        //    OnGenderClicked = new Command(GenderClicked);
//        //    DynamicLabelScrollView = dynamicSkillScroll;
//        //    DynamicLabelStack = dynamicLabelGrid;
//        //    OnHandicappedClicked = new Command(HandicappedClicked);
//        //    OnSaveCommand = new RelayCommand<string>(OnsaveDetails);
//        //    FocusDatePickerCommand = new RelayCommand<object>(Onfocus);
//        //    _educationdetails = new EducationalDetailsResponseData();
//        //    EducationalListItemSource = new List<Educational_Details>();
//        //    _commonservice = new HttpCommonService();
//        //    StackLayout_SchoolorCollege = dynamic_StackLayout_SchoolorCollege;
//        //    _UserEmailUpdateModel = new UserEmailUpdateModel();
//        //    _UserEmailUpdateResponse = new UserEmailUpdateResponse();
//        //    IsvisibleEmptyCertificateMessage = true;

//        //    _JobSeekerDashboardRequestData = new SeekerDashboardModel();
//        //    _EducaionalDetailsRequestData = new CollegeEducationDetailsRequest();
//        //    _modifiEducationalDetails = new Educational_Details();
//        //    BaseRequest = new EducationTokenRequestData();
//        //    GlobalCommonListItemSource = new List<CourseType>();
//        //    GlobalCommonListItemSource = null;
//        //    IsPersonalGrid = true;
//        //    IsEducationGrid = false;
//        //    ISChecAadharStatus = false;
//        //    ISCheckPassportStatus = false;
//        //    IsEnableToggleSameAddress = true;
//        //    IsdobFocus = false;
//        //    DatepickerValue = "Date of Birth";



//        //    CheckBoxMale = (string)Application.Current.Resources["RadioButtonUnchecked"];
//        //    CheckBoxFeMale = (string)Application.Current.Resources["RadioButtonUnchecked"];
//        //    IsEntryPercentage = true;
//        //    IsEntryCGPA = true;

//        //    HandicappedData = string.Empty;
//        //    HandicappedYes = (string)Application.Current.Resources["CircleUnSelected"];
//        //    HandicappedNo = (string)Application.Current.Resources["CircleUnSelected"];

//        //    Gender = string.Empty;
//        //    BindingFeMaleText = (string)Application.Current.Resources["CircleUnSelected"];
//        //    BindingMaleText = (string)Application.Current.Resources["CircleUnSelected"];

//        //    if (AppPreferences.IsProfileCompleted)
//        //    {
//        //        IsCameraVisible = false;
//        //    }

//        //    LoadUserBasicDetailsAsync();


//        //    MessagingCenter.Subscribe<DynamicListPageViewModel, CommonListItemSource>(this, "SeekerPersonalandEducational", (sender, arg) =>
//        //    {
//        //        SetFieldValue(arg.fieldType, arg);
//        //    });




//        //    MessagingCenter.Subscribe<MultipleLanguageSelectionPageViewModel, List<Languageknown>>(this, "Language", (sender, arg) =>
//        //    {
//        //        SetFieldValue(Constants.FieldType.Languages, arg);
//        //    });

//        //    MessagingCenter.Subscribe<MultipleSkillsSelectionViewModel, List<Skill>>(this, "SeekerPersonalandEducationalSkill", (sender, arg) =>
//        //    {
//        //        SetFieldValue(Constants.FieldType.PrimarySkill, arg);
//        //        GenerateSkills();
//        //    });


//        //    MessagingCenter.Subscribe<MultipleJobLocationSelectionViewModel, List<JobLocation>>(this, "SeekerPersonalandEducational_PreferredJobLocation", (sender, arg) =>
//        //    {
//        //        SetFieldValue(Constants.FieldType.PreferredJobLocation, arg);
//        //    });
//        //    MessagingCenter.Subscribe<ChangeProfilePictrurePageViewModel, string>(this, "ChangeProfilePicture", (sender, arg) =>
//        //    {
//        //        profilepic = arg ?? (string)Application.Current.Resources["IconUser"];
//        //    });
//        //    MessagingCenter.Subscribe<EditBasicDetailsViewModel, string[]>(this, "UpdateBasicDetails", (sender, arg) =>
//        //    {
//        //        FirstName = arg[0];
//        //        LastName = arg[1];
//        //        MobileNo = arg[2];
//        //        //EmailID = arg[3];
//        //        FullName = FirstName.ToUpper() + " " + LastName.ToUpper();
//        //    });
//        //    MessagingCenter.Subscribe<AddEducationPopupViewModel, string[]>(this, "CourseType", CourseTypeValue);


//        //    //Check Version Updates
//        //    CheckVersionUpdates _checkVersionUpdates = new CheckVersionUpdates();
//        //    _checkVersionUpdates.UpdateApplication();
//        //}


//        //private async void CourseTypeValue(AddEducationPopupViewModel arg1, string[] Values)
//        //{
//        //    var educational_level = Values[2];
//        //    if (isClicked)
//        //    {
//        //        isClicked = false;
//        //        if (educational_level == "1" || educational_level == "2")
//        //        {
//        //            await _navigationservice.PushAsync(new SchoolingEducationDetailsPage(Constants.FieldType.AddEducation, ItemSource, Values[1]));
//        //        }
//        //        else if (educational_level == "3" || educational_level == "4" || educational_level == "5")
//        //        {
//        //            await _navigationservice.PushAsync(new CollegeEducationDetailsPage(Constants.FieldType.AddEducation, ItemSource, Values[1]));
//        //        }

//        //    }
//        //    await Task.Run(async () =>
//        //    {
//        //        await Task.Delay(500);
//        //        isClicked = true;
//        //    });
//        //}

//        //private void Onfocus(object obj)
//        //{
//        //    var datepicker = (DatePicker)obj;
//        //    if (DatepickerValue == "0000-00-00")
//        //    {
//        //        datepicker.Date = DateTime.Now.AddYears(-17).AddDays(-1);
//        //        DatepickerValue = "0000-00-00";
//        //    }
//        //    datepicker.Focus();
//        //    // datepicker.MaximumDate = DateTime.Now.AddYears(-17).AddDays(-1);
//        //}


//        //#region GenerateSkills
//        //private int _lastindex;
//        //public int lastindex
//        //{
//        //    get { return _lastindex; }
//        //    set { _lastindex = value; OnPropertyChanged(); }
//        //}
//        //public void GenerateSkills()
//        //{
//        //    string[] skillSplit;
//        //    skillSplit = Skill.Split(',');
//        //    lastindex = skillSplit.Length;
//        //    if (lastindex != 0)
//        //    {
//        //        int NoOfRows = lastindex;
//        //        Label gridbutton = new Label();
//        //        StackLayout cf = new StackLayout();
//        //        Grid grid = new Grid();
//        //        int childrenCount = DynamicLabelStack.Children.Count;
//        //        DynamicLabelStack.Children.Clear();
//        //        grid.VerticalOptions = LayoutOptions.Start;
//        //        grid.HorizontalOptions = LayoutOptions.Fill;
//        //        //grid.Padding = new Thickness(5,5,5,5);
//        //        //grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
//        //        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Star });
//        //        //grid.RowDefinitions.Add(new RowDefinition { Height = 40 });
//        //        int count = 0;

//        //        for (int r = 0; r < 1; r++)
//        //        {
//        //            for (int c = 0; c < NoOfRows; c++)
//        //            {
//        //                if (NoOfRows > count)
//        //                {

//        //                    if (Device.Idiom == TargetIdiom.Phone)
//        //                    {
//        //                        cf = new StackLayout
//        //                        {
//        //                            BackgroundColor = Color.FromHex("#a5b06c"),
//        //                            Padding = 8,
//        //                            Margin=3,

//        //                        };

//        //                        gridbutton = new Label
//        //                        {
//        //                            Text = skillSplit[count],
//        //                            TextColor = Color.Black,
//        //                            ClassId = count.ToString(),
//        //                            FontSize = 13,
//        //                            HorizontalTextAlignment=TextAlignment.Center,
//        //                            VerticalTextAlignment=TextAlignment.Center,
//        //                            HorizontalOptions = LayoutOptions.FillAndExpand,
//        //                            VerticalOptions = LayoutOptions.CenterAndExpand,
//        //                            WidthRequest = 120,
//        //                        };
//        //                        cf.Children.Add(gridbutton);

//        //                    }
//        //                    //else if (Device.Idiom == TargetIdiom.Tablet)
//        //                    //{
//        //                    //    gridbutton = new CustomLabel
//        //                    //    {
//        //                    //        Text = skillSplit[count],
//        //                    //        TextColor = Color.Black,
//        //                    //        ClassId = count.ToString(),
//        //                    //        FontSize = 18,
//        //                    //        BackgroundColor = Color.White,
//        //                    //    };
//        //                    //}
//        //                    //gridbutton.SetBinding(Button.BackgroundColorProperty, "ButtonColor" + gridbutton.Text);
//        //                    //gridbutton.Clicked += Button_Clicked;
//        //                    grid.Children.Add(cf);

//        //                    DynamicLabelStack.Children.Add(grid);
//        //                    Grid.SetRow(cf, r);
//        //                    Grid.SetColumn(cf, c);
//        //                    Device.BeginInvokeOnMainThread(async () =>
//        //                    {
//        //                        await DynamicLabelScrollView.ScrollToAsync(0, 0, true);
//        //                    });
//        //                    count++;
//        //                }
//        //            }
//        //        }
//        //    }

//        //}
//        //#endregion

//        //private async void OnsaveDetails(string sender)
//        //{
//        //    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
//        //    switch (sender)
//        //    {
//        //        case "OnpersonalClick":
//        //            //if (isNetworkAvailable)
//        //            //{
//        //            await ShowPersonalTab();
//        //            //}
//        //            //else
//        //            //{
//        //            //    UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
//        //            //}
//        //            break;
//        //        case "OnEducationClick":
//        //            //if (isNetworkAvailable)
//        //            //{
//        //            await ShowEducationalTab();
//        //            //}
//        //            //else
//        //            //{
//        //            //    UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
//        //            //}

//        //            break;

//        //        #region Personal Details
//        //        case "OnDobClick":
//        //            IsdobFocus = true;
//        //            break;
//        //        case "OncheckboxMale":
//        //            Gender = "male";
//        //            break;
//        //        case "Oncheckboxfemale":
//        //            Gender = "female";
//        //            break;

//        //        case "DoVerify":
//        //            if (isClicked)
//        //            {
//        //                isClicked = false;
//        //                //VerifyUserNewEmailAddress();
//        //                //await PopupNavigation.PushAsync(new OTPVerifyPage("SeekerPersonalAndEducationalDetails"));
//        //            }
//        //            await Task.Run(async () =>
//        //            {
//        //                await Task.Delay(500);
//        //                isClicked = true;
//        //            });
//        //            break;

//        //        case "OnLanguageItemTapped":
//        //            if (isClicked)
//        //            {
//        //                isClicked = false;
//        //                if (isNetworkAvailable)
//        //                {
//        //                    await _navigationservice.PushAsync(new MultipleLanguageSelectionPage(_selectionLanguages, null));
//        //                }
//        //                else
//        //                {
//        //                    UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
//        //                }

//        //            }
//        //            await Task.Run(async () =>
//        //            {
//        //                await Task.Delay(500);
//        //                isClicked = true;
//        //            }); break;
//        //        case "OnNationalityTapped":
//        //            if (isClicked)
//        //            {

//        //                isClicked = false;

//        //                if (isNetworkAvailable)
//        //                {
//        //                    NavigateToDynamicListPage(Constants.FieldType.Nationality, "");
//        //                }
//        //                else
//        //                {
//        //                    UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
//        //                }

//        //            }
//        //            await Task.Run(async () =>
//        //            {
//        //                await Task.Delay(500);
//        //                isClicked = true;
//        //            });
//        //            break;
//        //        case "OnCurrentStateItemTapped":
//        //            if (isClicked)
//        //            {
//        //                isClicked = false;
//        //                if (isNetworkAvailable)
//        //                {
//        //                    MessageStringConstants.IsCurrentState = true;
//        //                    NavigateToDynamicListPage(Constants.FieldType.State, "");
//        //                }
//        //                else
//        //                {
//        //                    UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
//        //                }

//        //            }
//        //            await Task.Run(async () =>
//        //            {
//        //                await Task.Delay(500);
//        //                isClicked = true;
//        //            });
//        //            break;
//        //        case "OnCurrentCityItemTapped":
//        //            if (isClicked)
//        //            {
//        //                isClicked = false;

//        //                if (isNetworkAvailable)
//        //                {
//        //                    if (string.IsNullOrEmpty(_PersonalDetails.CurrentStateId) || _PersonalDetails.CurrentStateId == null || CurrentState == MessageStringConstants.SelectCurrentState)
//        //                    {
//        //                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectCurrentState);
//        //                    }
//        //                    else
//        //                    {
//        //                        MessageStringConstants.IsCurrentCity = true;
//        //                        NavigateToDynamicListPage(Constants.FieldType.City, _PersonalDetails.CurrentStateId);
//        //                    }
//        //                }
//        //                else
//        //                {
//        //                    UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
//        //                }
//        //            }
//        //            await Task.Run(async () =>
//        //            {
//        //                await Task.Delay(500);
//        //                isClicked = true;
//        //            });
//        //            break;
//        //        case "OnPermanentStateItemTapped":
//        //            if (isClicked)
//        //            {
//        //                isClicked = false;

//        //                if (isNetworkAvailable)
//        //                {
//        //                    MessageStringConstants.IsCurrentState = false;
//        //                    if (IsEnableToggleSameAddress == true)
//        //                        NavigateToDynamicListPage(Constants.FieldType.State, "");
//        //                }
//        //                else
//        //                {
//        //                    UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
//        //                }
//        //            }
//        //            await Task.Run(async () =>
//        //            {
//        //                await Task.Delay(500);
//        //                isClicked = true;
//        //            });
//        //            break;
//        //        case "OnPermanentCityItemTapped":
//        //            if (isClicked)
//        //            {
//        //                isClicked = false;



//        //                if (isNetworkAvailable)
//        //                {
//        //                    if (string.IsNullOrEmpty(_PersonalDetails.PermanentStateID) || _PersonalDetails.PermanentStateID == null || PermanentState == MessageStringConstants.SelectPermanentState)
//        //                    {
//        //                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectPermanentState);
//        //                    }

//        //                    else
//        //                    {
//        //                        MessageStringConstants.IsCurrentCity = false;
//        //                        if (IsEnableToggleSameAddress == true)
//        //                            NavigateToDynamicListPage(Constants.FieldType.City, _PersonalDetails.PermanentStateID);
//        //                    }
//        //                }
//        //                else
//        //                {
//        //                    UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
//        //                }
//        //            }
//        //            await Task.Run(async () =>
//        //            {
//        //                await Task.Delay(500);
//        //                isClicked = true;
//        //            });
//        //            break;
//        //        case "OnPreferredJobLocationItemTapped":

//        //            if (isClicked)
//        //            {
//        //                isClicked = false;

//        //                if (isNetworkAvailable)
//        //                {
//        //                    if (!string.IsNullOrEmpty(PreferredJobLocation))
//        //                    {
//        //                        await _navigationservice.PushAsync(new MultipleJobLocationSelectionPage("SeekerPersonalandEducational", _selectionJobLocation));
//        //                    }
//        //                }
//        //                else
//        //                {
//        //                    UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
//        //                }






//        //            }
//        //            await Task.Run(async () =>
//        //            {
//        //                await Task.Delay(500);
//        //                isClicked = true;
//        //            });
//        //            break;
//        //        case "SavePersonalDetails":
//        //            if (isClicked)
//        //            {
//        //                isClicked = false;
//        //                if (isNetworkAvailable)
//        //                {
//        //                    await SavePersonalDetails();
//        //                }
//        //                else
//        //                {
//        //                    UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
//        //                }

//        //            }
//        //            await Task.Run(async () =>
//        //            {
//        //                await Task.Delay(500);
//        //                isClicked = true;
//        //            });
//        //            break;

//        //        #endregion

//        //        #region Education Details
//        //        case "OnSkillItemTapped":
//        //            if (!string.IsNullOrEmpty(Skill))
//        //            {
//        //                if (isClicked)
//        //                {
//        //                    isClicked = false;
//        //                    if (isNetworkAvailable)
//        //                    {
//        //                        await _navigationservice.PushAsync(new MultipleSkillsSelectionPage("SeekerPersonalandEducational", _selectionSkills, "1"));
//        //                    }
//        //                    else
//        //                    {
//        //                        UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
//        //                    }
//        //                }
//        //                await Task.Run(async () =>
//        //                {
//        //                    await Task.Delay(500);
//        //                    isClicked = true;
//        //                });
//        //            }
//        //            break;



//        //        case "SkillUpdateAndJobLocation":
//        //            if (isClicked)
//        //            {
//        //                isClicked = false;


//        //                if (isNetworkAvailable)
//        //                {
//        //                    UpdateSkillAndJobLocation();
//        //                }
//        //                else
//        //                {
//        //                    UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
//        //                }


//        //            }
//        //            await Task.Run(async () =>
//        //            {
//        //                await Task.Delay(500);
//        //                isClicked = true;
//        //            });
//        //            break;
//        //        #endregion
//        //        case "OnCameraClick":

//        //            await UploadProfilePicture();
//        //            break;
//        //        case "Add":
//        //            if (isNetworkAvailable)
//        //            {
//        //                if (isClicked)
//        //                {
//        //                    isClicked = false;
//        //                    await BindCourseTypeData();
//        //                }
//        //                await Task.Run(async () =>
//        //                {
//        //                    await Task.Delay(500);
//        //                    isClicked = true;
//        //                });
//        //            }
//        //            else
//        //            {
//        //                UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
//        //            }
//        //            break;

//        //        case "AddCertificate":
//        //            if (isNetworkAvailable)
//        //            {
//        //                if (isClicked)
//        //                {
//        //                    isClicked = false;
//        //                    await _navigationservice.PushAsync(new CertificationPage());
//        //                }
//        //                await Task.Run(async () =>
//        //                {
//        //                    await Task.Delay(500);
//        //                    isClicked = true;
//        //                });
//        //            }
//        //            else
//        //            {
//        //                UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
//        //            }
//        //            break;


//        //        case "OnEditBasicDetails":
//        //            if (isClicked)
//        //            {
//        //                isClicked = false;
//        //                await _navigationservice.PushAsync(new EditBasicDetailsPage());
//        //            }
//        //            await Task.Run(async () =>
//        //            {
//        //                await Task.Delay(500);
//        //                isClicked = true;
//        //            });
//        //            break;
//        //    }

//        //}


//        //public async void UpdateSkillAndJobLocation()
//        //{
//        //    try
//        //    {
//        //        if (Skill == "Select Skill")
//        //        {
//        //            await UserDialogs.Instance.AlertAsync("Select Skill");
//        //        }
//        //        else if (_courseTypeID.Count <= 0)
//        //        {
//        //            await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterEducationalDetails);
//        //        }
//        //        else if (!_courseTypeID.Contains("1") && !_courseTypeID.Contains("2"))
//        //        {
//        //            await UserDialogs.Instance.AlertAsync(MessageStringConstants.UpdateYourSchoolDetails);
//        //        }
//        //        else if (!_courseTypeID.Contains("3") && !_courseTypeID.Contains("4") && !_courseTypeID.Contains("5"))
//        //        {
//        //            await UserDialogs.Instance.AlertAsync(MessageStringConstants.UpdateYourCollegeDetails);
//        //        }
//        //        else
//        //        {
//        //            AppPreferences.IsEducationCompleted = true;
//        //            AppPreferences.IsFirstRun = false;
//        //            _isEducationDetailsUpdated = true;
//        //            NavigateToNextPageIfNeeded();
//        //            await ShowPersonalTab();
//        //        }
//        //    }
//        //    catch (Exception ex)
//        //    {
//        //        System.Diagnostics.Debug.WriteLine(ex.Message);
//        //        SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.UpdateSkillAndJobLocation");
//        //    }
//        //}

//        //#region Toggle Event
//        //private Command<string> tapCommand;
//        //public Command<string> TapCommand
//        //{
//        //    get { return tapCommand ?? (tapCommand = new Command<string>(async arg => await OnTappedCommand(arg))); }
//        //}
//        //public async Task OnTappedCommand(string sender)
//        //{
//        //    try
//        //    {


//        //        switch (sender)
//        //        {
//        //            #region Toggle Event
//        //            case "ToggleSameAddress":
//        //                if (IsToggleSameAddress == true)
//        //                {
//        //                    IsEnableToggleSameAddress = false;
//        //                    IsCopy = 1;
//        //                    PermanentAddress = CurrentAddress ?? string.Empty;
//        //                    _PersonalDetails.PermanentAddress = CurrentAddress ?? string.Empty;
//        //                    PermanentZipcode = CurrentZipcode ?? string.Empty;
//        //                    _PersonalDetails.PermanentZipcode = CurrentZipcode ?? string.Empty;

//        //                    if (string.IsNullOrEmpty(_PersonalDetails.CurrentStateId) || _PersonalDetails.CurrentStateName == MessageStringConstants.SelectCurrentState)
//        //                    {
//        //                        _PersonalDetails.PermanentStateID = string.Empty;
//        //                        _PersonalDetails.PermanentStateName = MessageStringConstants.SelectPermanentState;
//        //                        PermanentState = MessageStringConstants.SelectPermanentState;
//        //                    }
//        //                    else
//        //                    {
//        //                        _PersonalDetails.PermanentStateID = _PersonalDetails.CurrentStateId;
//        //                        _PersonalDetails.PermanentStateName = CurrentState ?? _PersonalDetails.CurrentStateName ?? MessageStringConstants.SelectPermanentState;
//        //                        PermanentState = _PersonalDetails.CurrentStateName ?? MessageStringConstants.SelectPermanentState;
//        //                    }

//        //                    if (string.IsNullOrEmpty(_PersonalDetails.CurrentCityId) || _PersonalDetails.CurrentCityName == MessageStringConstants.SelectCurrentDistrict)
//        //                    {
//        //                        _PersonalDetails.PermanentCityID = string.Empty;
//        //                        _PersonalDetails.PermanentCityName = MessageStringConstants.SelectPermanentDistrict;
//        //                        PermanentDistrict = MessageStringConstants.SelectPermanentDistrict;
//        //                    }
//        //                    else
//        //                    {
//        //                        _PersonalDetails.PermanentCityID = _PersonalDetails.CurrentCityId ?? string.Empty;
//        //                        _PersonalDetails.PermanentCityName = CurrentDistrict ?? _PersonalDetails.CurrentCityName ?? MessageStringConstants.SelectPermanentDistrict;
//        //                        PermanentDistrict = _PersonalDetails.CurrentCityName ?? MessageStringConstants.SelectPermanentDistrict;
//        //                    }
//        //                }
//        //                else
//        //                {
//        //                    IsCopy = 0;
//        //                    IsEnableToggleSameAddress = true;
//        //                    PermanentAddress = string.Empty;
//        //                    PermanentState = MessageStringConstants.SelectPermanentState;
//        //                    PermanentDistrict = MessageStringConstants.SelectPermanentDistrict;
//        //                    PermanentZipcode = string.Empty;

//        //                    _PersonalDetails.PermanentAddress = string.Empty;
//        //                    _PersonalDetails.PermanentStateID = string.Empty;
//        //                    _PersonalDetails.PermanentStateName = MessageStringConstants.SelectPermanentState;
//        //                    _PersonalDetails.PermanentCityID = string.Empty;
//        //                    _PersonalDetails.PermanentCityName = MessageStringConstants.SelectPermanentDistrict;
//        //                    _PersonalDetails.PermanentZipcode = string.Empty;
//        //                }
//        //                break;
//        //            case "AadharUnfocused":
//        //                if (!string.IsNullOrEmpty(AadhaarNumber))
//        //                {
//        //                    if (!Utilities.ValidateAadhaarNumber(AadhaarNumber))
//        //                    {
//        //                        await UserDialogs.Instance.AlertAsync("Enter Valid Aadhaar Number");
//        //                    }
//        //                    else
//        //                    {
//        //                        var mailstatus = await CheckAadharNumber(AadhaarNumber);
//        //                        if (mailstatus)
//        //                        {
//        //                            ISChecAadharStatus = true;
//        //                        }
//        //                        else
//        //                        {
//        //                            ISChecAadharStatus = false;
//        //                        }
//        //                    }
//        //                }
//        //                break;
//        //            case "PassportUnFocused":

//        //                if (!string.IsNullOrEmpty(PassPortNumber))
//        //                {
//        //                    if (!Utilities.ValidatePassportNumber(PassPortNumber))
//        //                    {
//        //                        await UserDialogs.Instance.AlertAsync("Enter Valid Passport Number");
//        //                    }
//        //                    else
//        //                    {
//        //                        var _passportNumberStatus = await CheckPassportNumber(PassPortNumber);
//        //                        if (_passportNumberStatus)
//        //                        {
//        //                            ISCheckPassportStatus = true;
//        //                        }
//        //                        else
//        //                        {
//        //                            ISCheckPassportStatus = false;
//        //                        }
//        //                    }
//        //                }
//        //                break;
//        //            case "PermanentAddresId":

//        //                if (!string.IsNullOrEmpty(PermanentAddress))
//        //                {
//        //                    if (!Utilities.Address(PermanentAddress))
//        //                    {
//        //                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterPermanentAddress);
//        //                    }
//        //                }
//        //                break;
//        //            case "CurrentAddresId":

//        //                if (!string.IsNullOrEmpty(CurrentAddress))
//        //                {
//        //                    if (!Utilities.Address(CurrentAddress))
//        //                    {
//        //                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterCurrentAddress);
//        //                    }
//        //                }
//        //                break;

//        //            case "EntryEmailUnFocused":
//        //                System.Diagnostics.Debug.WriteLine("** START ** @ LoginPageNew.onLogin()");
//        //                var text = EmailAddress;
//        //                if (string.IsNullOrEmpty(text))
//        //                {
//        //                    FontAwesomeRightSign = (string)Application.Current.Resources["WrongSign"];
//        //                    IsVisibleRightSign = true;
//        //                    TextColor = Color.Red;
//        //                }
//        //                else
//        //                {
//        //                    if (!Utilities.ValidateEmailAddress(text))
//        //                    {
//        //                        FontAwesomeRightSign = (string)Application.Current.Resources["WrongSign"];
//        //                        IsVisibleRightSign = true;
//        //                        TextColor = Color.Red;
//        //                    }
//        //                    else
//        //                    {
//        //                        FontAwesomeRightSign = (string)Application.Current.Resources["RightSign"];
//        //                        IsVisibleRightSign = true;
//        //                        TextColor = Color.Green;
//        //                        //VerifyUserNewEmailAddress(); //With the request of thennavan sir, verification in this screen removed
//        //                        //await PopupNavigation.PushAsync(new OTPVerifyPage());
//        //                    }
//        //                }
//        //                System.Diagnostics.Debug.WriteLine("** END ** @ LoginPageNew.onLogin()");
//        //                break;

//        //            #region BindStateAndCity
//        //            case "PresendPincodeUnfocused":
//        //                BindStateAndCity();
//        //                break;

//        //                #endregion

//        //        }
//        //    }
//        //    catch (Exception ex)
//        //    {
//        //        System.Diagnostics.Debug.WriteLine(ex.Message);
//        //    }
//        //    #endregion


//        //}

//        //public void BindStateAndCity()
//        //{
//        //    //
//        //    Device.BeginInvokeOnMainThread(async () =>
//        //    {
//        //        try
//        //        {
//        //            if (!string.IsNullOrEmpty(CurrentZipcode))
//        //            {
//        //                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
//        //                if (isNetworkAvailable)
//        //                {
//        //                    UserDialogs.Instance.ShowLoading();
//        //                    var resultdata = await _commonservice.GetAsync<StateDistrictFromPincodeResponse>(APIMethods.GetStateDistrictFromPicode + CurrentZipcode);
//        //                    UserDialogs.Instance.HideLoading();
//        //                    if (resultdata != null)
//        //                    {
//        //                        if (resultdata.Status == "Success")
//        //                        {
//        //                            CurrentState = resultdata.PostOffice[0].State;
//        //                            CurrentDistrict = resultdata.PostOffice[0].District;

//        //                            _PersonalDetails.CurrentStateId = "1";
//        //                            _PersonalDetails.CurrentStateName = resultdata.PostOffice[0].State;
//        //                            _PersonalDetails.CurrentCityId = "5";
//        //                            _PersonalDetails.CurrentCityName = resultdata.PostOffice[0].District;
//        //                        }
//        //                        else
//        //                        {
//        //                            CurrentState = MessageStringConstants.SelectCurrentState;
//        //                            CurrentDistrict = MessageStringConstants.SelectCurrentDistrict;
//        //                        }
//        //                    }
//        //                }
//        //                else
//        //                {
//        //                    UserDialogs.Instance.HideLoading();
//        //                    UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
//        //                }
//        //            }
//        //        }
//        //        catch (Exception ex)
//        //        {
//        //            //await UserDialogs.Instance.AlertAsync(ex.Message);
//        //            UserDialogs.Instance.HideLoading();
//        //            System.Diagnostics.Debug.WriteLine(ex.Message);
//        //            SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.BindStateAndCity");
//        //        }
//        //    });
//        //}

//        //private bool _IsToggleSameAddress;
//        //public bool IsToggleSameAddress
//        //{
//        //    get { return _IsToggleSameAddress; }
//        //    set { _IsToggleSameAddress = value; OnPropertyChanged(); }
//        //}

//        //private bool _IsEnableToggleSameAddress;
//        //public bool IsEnableToggleSameAddress
//        //{
//        //    get { return _IsEnableToggleSameAddress; }
//        //    set { _IsEnableToggleSameAddress = value; OnPropertyChanged(); }
//        //}
//        //#endregion

//        //private Command<string> textchagedcommand;
//        //public Command<string> TextChangedCommand
//        //{
//        //    get { return textchagedcommand ?? (textchagedcommand = new Command<string>(async arg => await OnTextChangedCommand(arg))); }
//        //}

//        //private Command<object> datechagedcommand;
//        //public Command<object> DateChangedCommand
//        //{
//        //    get { return datechagedcommand ?? (datechagedcommand = new Command<object>(async arg => await OnDateChangedCommand(arg))); }
//        //}
//        //private async Task OnTextChangedCommand(string sender)
//        //{
//        //    switch (sender)
//        //    {
//        //        case "CGPA":
//        //            if (EntryCGPA != "" && EntryCGPA != "0.00")
//        //            {
//        //                IsEntryPercentage = false;
//        //                IsEntryCGPA = true;
//        //            }

//        //            else
//        //            {
//        //                IsEntryPercentage = true;
//        //                EntryCGPA = string.Empty;
//        //            }
//        //            break;
//        //        case "Percentage":
//        //            if (EntryPercentage != "0.00" && EntryPercentage != "")
//        //            {
//        //                IsEntryCGPA = false;
//        //                IsEntryPercentage = true;
//        //            }

//        //            else if (EntryCGPA == "0.00" && EntryPercentage == "00.0" || EntryCGPA == "0.00" && EntryPercentage == "0.00")
//        //            {
//        //                IsEntryCGPA = true;
//        //                IsEntryPercentage = true;
//        //            }
//        //            else
//        //            {
//        //                IsEntryCGPA = true;
//        //                EntryPercentage = string.Empty;
//        //            }
//        //            break;


//        //    }
//        //}

//        ///// <summary>
//        ///// 
//        ///// </summary>
//        ///// <param name="sender"></param>
//        ///// <returns></returns>
//        //private async Task OnDateChangedCommand(object sender)
//        //{
//        //    var datepicker = (DatePicker)sender;
//        //    DatepickerValue = datepicker.Date.ToString("yyyy-MM-dd");

//        //    DateTime Dob = DateTime.Parse(DatepickerValue);
//        //    DateTime now = DateTime.Today;
//        //    int age = now.Year - Dob.Year;
//        //    if (Dob.AddYears(age) > now)
//        //        age--;
//        //    Age = age.ToString();
//        //}

//        //#region Private Properties
//        //private bool _iSChecAadharStatus;
//        //public bool ISChecAadharStatus
//        //{
//        //    get { return _iSChecAadharStatus; }
//        //    set { _iSChecAadharStatus = value; OnPropertyChanged(); }
//        //}
//        //private bool _iSCheckPassportStatus;
//        //public bool ISCheckPassportStatus
//        //{
//        //    get { return _iSCheckPassportStatus; }
//        //    set { _iSCheckPassportStatus = value; OnPropertyChanged(); }
//        //}

//        //private string _Age;
//        //public string Age
//        //{
//        //    get { return _Age; }
//        //    set { _Age = value; OnPropertyChanged(); }
//        //}

//        //private JobSeekerProfileDetails personalDetails;
//        //public JobSeekerProfileDetails _PersonalDetails
//        //{
//        //    get { return personalDetails; }
//        //    set { personalDetails = value; OnPropertyChanged(); }
//        //}
//        //private EducationalDetailsResponseData educationdetails;
//        //public EducationalDetailsResponseData _educationdetails
//        //{
//        //    get { return educationdetails; }
//        //    set { educationdetails = value; OnPropertyChanged(); }
//        //}
//        //#region ListView Property
//        //public List<Educational_Details> _EducationalListItemSource;
//        //public List<Educational_Details> EducationalListItemSource
//        //{
//        //    get { return _EducationalListItemSource; }
//        //    set { _EducationalListItemSource = value; OnPropertyChanged(); }
//        //}
//        //private Educational_Details _EducationlistSelectedItem;
//        //public Educational_Details EducationlistSelectedItem
//        //{
//        //    get { return _EducationlistSelectedItem; }
//        //    set
//        //    {
//        //        _EducationlistSelectedItem = value; OnPropertyChanged();

//        //    }
//        //}

//        ////public ICommand SelectedCertificateCommand => new Command(async () =>
//        ////{

//        ////    if (isClicked)
//        ////    {
//        ////        isClicked = false;
//        ////        var page = new AddCertificatePage(Constants.FieldType.EditCertification, SelectedCertificateItem,CertificationItemSource);
//        ////        await PopupNavigation.PushAsync(page);


//        ////    }
//        ////    await Task.Run(async () =>
//        ////     {
//        ////         await Task.Delay(500);
//        ////         isClicked = true;
//        ////     });

//        ////});
//        //public ICommand SelectedCommand => new Command(() =>
//        //{

//        //    if (isClicked)
//        //    {
//        //        isClicked = false;
//        //        if (SelectedItem.educational_level == "1" || SelectedItem.educational_level == "2")
//        //        {
//        //            _navigationservice.PushAsync(new SchoolingEducationDetailsPage(Constants.FieldType.EditEducation, ItemSource, SelectedItem));
//        //        }
//        //        else if (SelectedItem.educational_level == "3" || SelectedItem.educational_level == "4" || SelectedItem.educational_level == "5")
//        //        {
//        //            _navigationservice.PushAsync(new CollegeEducationDetailsPage(Constants.FieldType.EditEducation, ItemSource, SelectedItem));
//        //        }

//        //    }
//        //    Task.Run(async () =>
//        //    {
//        //        await Task.Delay(500);
//        //        isClicked = true;
//        //    });

//        //});
//        //#endregion
//        //private bool _ispersonalgrid;
//        //public bool IsPersonalGrid
//        //{
//        //    get { return _ispersonalgrid; }
//        //    set { _ispersonalgrid = value; OnPropertyChanged(); }
//        //}

//        //private bool _iseducationgrid;
//        //public bool IsEducationGrid
//        //{
//        //    get { return _iseducationgrid; }
//        //    set { _iseducationgrid = value; OnPropertyChanged(); }
//        //}
//        //private bool _isdob;
//        //public bool IsDob
//        //{
//        //    get { return _isdob; }
//        //    set { _isdob = value; OnPropertyChanged(); }
//        //}
//        //private bool _isdobfocus;
//        //public bool IsdobFocus
//        //{
//        //    get { return _isdobfocus; }
//        //    set { _isdobfocus = value; OnPropertyChanged(); }
//        //}

//        //private string _datepickerValue;
//        //public string DatepickerValue
//        //{
//        //    get { return _datepickerValue; }
//        //    set
//        //    {
//        //        if (value == "0000-00-00")
//        //        {
//        //            Age = string.Empty;
//        //        }
//        //        _datepickerValue = value; OnPropertyChanged();
//        //    }
//        //}
//        //private DateTime _maximumdate = DateTime.Now.AddYears(-17).AddDays(-1);
//        //public DateTime MaximumDate
//        //{
//        //    get { return _maximumdate; }
//        //    set { _maximumdate = value; OnPropertyChanged(); }
//        //}
//        //private string _checkboxMale;

//        //public string CheckBoxMale
//        //{
//        //    get { return _checkboxMale; }
//        //    set { _checkboxMale = value; OnPropertyChanged(); }
//        //}
//        //private string _checkboxFemale;

//        //public string CheckBoxFeMale
//        //{
//        //    get { return _checkboxFemale; }
//        //    set { _checkboxFemale = value; OnPropertyChanged(); }
//        //}

//        //private bool _isentryPercentage;

//        //public bool IsEntryPercentage
//        //{
//        //    get { return _isentryPercentage; }
//        //    set { _isentryPercentage = value; OnPropertyChanged(); }
//        //}

//        //private bool _isentryCGPA;

//        //public bool IsEntryCGPA
//        //{
//        //    get { return _isentryCGPA; }
//        //    set { _isentryCGPA = value; OnPropertyChanged(); }
//        //}
//        //private string _entrycgpa = "0.00";

//        //public string EntryCGPA
//        //{
//        //    get { return _entrycgpa; }
//        //    set { _entrycgpa = value; OnPropertyChanged(); }
//        //}
//        //private string _entrypercentage = "0.00";

//        //public string EntryPercentage
//        //{
//        //    get { return _entrypercentage; }
//        //    set { _entrypercentage = value; OnPropertyChanged(); }
//        //}

//        //private bool _iscameracisible = true;
//        //public bool IsCameraVisible
//        //{
//        //    get { return _iscameracisible; }
//        //    set { _iscameracisible = value; OnPropertyChanged(); }
//        //}
//        //private string _languages = "Select Language";
//        //public string Languages
//        //{
//        //    get { return _languages; }
//        //    set { _languages = value; OnPropertyChanged(); }
//        //}

//        //private string _BindingState;

//        //public string BindingState
//        //{
//        //    get { return _BindingState; }
//        //    set
//        //    {
//        //        _BindingState = value;
//        //        OnPropertyChanged();
//        //    }
//        //}

//        //private bool _isbacklogtoggled;

//        //public bool IsBackLogToggled
//        //{
//        //    get { return _isbacklogtoggled; }
//        //    set { _isbacklogtoggled = value; OnPropertyChanged(); }
//        //}

//        //private string _yearOfcompletion;

//        //private Color _personalbackbtncolor;
//        //public Color PersonalBackbtnColor
//        //{
//        //    get { return _personalbackbtncolor; }
//        //    set { _personalbackbtncolor = value; OnPropertyChanged(); }
//        //}
//        //private Color _educationbackbtncolor;
//        //public Color EducationBackbtnColor
//        //{
//        //    get { return _educationbackbtncolor; }
//        //    set { _educationbackbtncolor = value; OnPropertyChanged(); }
//        //}

//        //private string _profilepic = (string)Application.Current.Resources["IconUser"];

//        //public string profilepic
//        //{
//        //    get { return _profilepic; }
//        //    set { _profilepic = value; OnPropertyChanged(); }
//        //}


//        //private string bindingFeMaleText;
//        //public string BindingFeMaleText
//        //{
//        //    get { return bindingFeMaleText; }
//        //    set
//        //    {
//        //        bindingFeMaleText = value;
//        //        OnPropertyChanged();
//        //    }
//        //}



//        //private string bindingMaleText;
//        //public string BindingMaleText
//        //{
//        //    get { return bindingMaleText; }
//        //    set
//        //    {
//        //        bindingMaleText = value;
//        //        OnPropertyChanged();
//        //    }
//        //}


//        //private string _handicappedYes;
//        //public string HandicappedYes
//        //{
//        //    get { return _handicappedYes; }
//        //    set
//        //    {
//        //        _handicappedYes = value;
//        //        OnPropertyChanged();
//        //    }
//        //}
//        //private string _handicappedNo;
//        //public string HandicappedNo
//        //{
//        //    get { return _handicappedNo; }
//        //    set
//        //    {
//        //        _handicappedNo = value;
//        //        OnPropertyChanged();
//        //    }
//        //}

//        //private string _fullname;
//        //public string FullName
//        //{
//        //    get { return _fullname; }
//        //    set
//        //    {
//        //        _fullname = value;
//        //        OnPropertyChanged();
//        //    }
//        //}
//        //private string _firsname;
//        //public string FirstName
//        //{
//        //    get { return _firsname; }
//        //    set
//        //    {
//        //        _firsname = value;
//        //        OnPropertyChanged();
//        //    }
//        //}
//        //private string _PassPortNumber;
//        //public string PassPortNumber
//        //{
//        //    get { return _PassPortNumber; }
//        //    set { _PassPortNumber = value; OnPropertyChanged(); }
//        //}

//        //private string _AadhaarNumber;
//        //public string AadhaarNumber
//        //{
//        //    get { return _AadhaarNumber; }
//        //    set { _AadhaarNumber = value; OnPropertyChanged(); }
//        //}

//        //private string _lastname;
//        //public string LastName
//        //{
//        //    get { return _lastname; }
//        //    set
//        //    {
//        //        _lastname = value;
//        //        OnPropertyChanged();
//        //    }
//        //}
//        //private string _EmailID;
//        //public string EmailID
//        //{
//        //    get { return _EmailID; }
//        //    set
//        //    {
//        //        _EmailID = value;
//        //        OnPropertyChanged();
//        //    }
//        //}

//        //private string _emailAddress;
//        //public string EmailAddress
//        //{
//        //    get { return _emailAddress; }
//        //    set
//        //    {
//        //        _emailAddress = value;
//        //        OnPropertyChanged();
//        //    }
//        //}

//        //private string _MobileNo;
//        //public string MobileNo
//        //{
//        //    get { return _MobileNo; }
//        //    set
//        //    {
//        //        _MobileNo = value;
//        //        OnPropertyChanged();
//        //    }
//        //}
//        //private string _HiremeeID;
//        //public string HiremeeID
//        //{
//        //    get { return _HiremeeID; }
//        //    set
//        //    {
//        //        _HiremeeID = value;
//        //        OnPropertyChanged();
//        //    }
//        //}

//        //private string _fontAwesomeRightSign;
//        //public string FontAwesomeRightSign
//        //{
//        //    get { return _fontAwesomeRightSign; }
//        //    set
//        //    {
//        //        if (value == _fontAwesomeRightSign) return;
//        //        _fontAwesomeRightSign = value;
//        //        OnPropertyChanged();
//        //    }
//        //}

//        //private bool _isVisibleRightSign;
//        //public bool IsVisibleRightSign
//        //{
//        //    get
//        //    {
//        //        return _isVisibleRightSign;
//        //    }
//        //    set
//        //    {
//        //        _isVisibleRightSign = value;
//        //        OnPropertyChanged();
//        //    }
//        //}

//        //private Color _textColor;
//        //public Color TextColor
//        //{
//        //    get { return _textColor; }
//        //    set
//        //    {
//        //        if (value == _textColor) return;
//        //        _textColor = value;
//        //        OnPropertyChanged();
//        //    }
//        //}

//        //public Command OnGenderClicked
//        //{
//        //    get;
//        //    set;
//        //}
//        //public Command OnHandicappedClicked
//        //{
//        //    get;
//        //    set;
//        //}

//        //#endregion

//        //#region HandicappedData
//        //string _handicappedData;
//        //public string HandicappedData
//        //{
//        //    get
//        //    {
//        //        return _handicappedData;
//        //    }
//        //    set
//        //    {
//        //        if (value != null)
//        //        {
//        //            if (value.ToLower() == "1")
//        //            {
//        //                _handicappedData = "1";
//        //                HandicappedYes = (string)Application.Current.Resources["CircleSelected"];
//        //                HandicappedNo = (string)Application.Current.Resources["CircleUnSelected"];

//        //            }
//        //            else if (value.ToLower() == "0")
//        //            {
//        //                HandicappedNo = (string)Application.Current.Resources["CircleSelected"];
//        //                HandicappedYes = (string)Application.Current.Resources["CircleUnSelected"];
//        //                _handicappedData = "0";

//        //            }
//        //        }
//        //        OnPropertyChanged();
//        //    }
//        //}
//        //#endregion
//        //void HandicappedClicked(object obj)
//        //{
//        //    if (obj.ToString() == "Yes")
//        //    {
//        //        HandicappedYes = (string)Application.Current.Resources["CircleSelected"];
//        //        HandicappedNo = (string)Application.Current.Resources["CircleUnSelected"];
//        //        HandicappedData = "1";
//        //    }
//        //    else if (obj.ToString() == "No")
//        //    {
//        //        HandicappedNo = (string)Application.Current.Resources["CircleSelected"];
//        //        HandicappedYes = (string)Application.Current.Resources["CircleUnSelected"];
//        //        HandicappedData = "0";
//        //    }
//        //}





//        //void GenderClicked(object obj)
//        //{
//        //    if (obj.ToString() == "male")
//        //    {
//        //        BindingMaleText = (string)Application.Current.Resources["CircleSelected"];
//        //        BindingFeMaleText = (string)Application.Current.Resources["CircleUnSelected"];
//        //        Gender = "male";
//        //    }
//        //    else if (obj.ToString() == "female")
//        //    {
//        //        BindingFeMaleText = (string)Application.Current.Resources["CircleSelected"];
//        //        BindingMaleText = (string)Application.Current.Resources["CircleUnSelected"];
//        //        Gender = "female";
//        //    }
//        //}

//        //#region Gender
//        //string _gender;
//        //public string Gender
//        //{
//        //    get
//        //    {
//        //        return _gender;
//        //    }
//        //    set
//        //    {
//        //        if (!string.IsNullOrEmpty(value))
//        //        {
//        //            if (value.ToLower() == "male")
//        //            {
//        //                _gender = "male";
//        //                BindingMaleText = (string)Application.Current.Resources["CircleSelected"];
//        //                BindingFeMaleText = (string)Application.Current.Resources["CircleUnSelected"];

//        //            }
//        //            else if (value.ToLower() == "female")
//        //            {
//        //                BindingFeMaleText = (string)Application.Current.Resources["CircleSelected"];
//        //                BindingMaleText = (string)Application.Current.Resources["CircleUnSelected"];
//        //                _gender = "female";

//        //            }
//        //        }
//        //        else
//        //        {
//        //            BindingFeMaleText = (string)Application.Current.Resources["CircleUnSelected"];
//        //            BindingMaleText = (string)Application.Current.Resources["CircleUnSelected"];
//        //        }
//        //        OnPropertyChanged();
//        //    }
//        //}
//        //#endregion









//        //public async void NavigateToDynamicListPage(string _fieldType, string _fieldValue)
//        //{
//        //    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
//        //    if (isNetworkAvailable)
//        //    {
//        //        await _navigationservice.PushAsync(new DynamicListPage("SeekerPersonalandEducational", _fieldType, _fieldValue));
//        //    }
//        //    else
//        //    {
//        //        UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
//        //    }
//        //}

//        //#region SetFieldValue
//        //public void SetFieldValue(string fieldtype, object fieldvalue)
//        //{
//        //    //_PersonalDetails = new JobSeekerProfileDetails();

//        //    try
//        //    {


//        //        if (fieldtype == Constants.FieldType.State)
//        //        {
//        //            if (MessageStringConstants.IsCurrentState)
//        //            {

//        //                CurrentDistrict = MessageStringConstants.SelectCurrentDistrict;
//        //                _PersonalDetails.CurrentCityId = string.Empty;
//        //                _PersonalDetails.CurrentCityName = MessageStringConstants.SelectCurrentDistrict;

//        //                CurrentState = ((CommonListItemSource)fieldvalue).Title;
//        //                _PersonalDetails.CurrentStateId = ((CommonListItemSource)fieldvalue).ID;
//        //                _PersonalDetails.CurrentStateName = ((CommonListItemSource)fieldvalue).Title;
//        //            }
//        //            else
//        //            {
//        //                PermanentDistrict = MessageStringConstants.SelectPermanentDistrict;
//        //                _PersonalDetails.PermanentCityID = string.Empty;
//        //                _PersonalDetails.PermanentCityName = MessageStringConstants.SelectPermanentDistrict;

//        //                PermanentState = ((CommonListItemSource)fieldvalue).Title;
//        //                _PersonalDetails.PermanentStateID = ((CommonListItemSource)fieldvalue).ID;
//        //                _PersonalDetails.PermanentStateName = ((CommonListItemSource)fieldvalue).Title;
//        //            }
//        //        }
//        //        else if (fieldtype == Constants.FieldType.City)
//        //        {
//        //            if (MessageStringConstants.IsCurrentCity)
//        //            {
//        //                CurrentDistrict = ((CommonListItemSource)fieldvalue).Title;
//        //                _PersonalDetails.CurrentCityId = ((CommonListItemSource)fieldvalue).ID;
//        //                _PersonalDetails.CurrentCityName = ((CommonListItemSource)fieldvalue).Title;
//        //            }
//        //            else
//        //            {
//        //                PermanentDistrict = ((CommonListItemSource)fieldvalue).Title;
//        //                _PersonalDetails.PermanentCityID = ((CommonListItemSource)fieldvalue).ID;
//        //                _PersonalDetails.PermanentCityName = ((CommonListItemSource)fieldvalue).Title;
//        //            }
//        //        }
//        //        else if (fieldtype == Constants.FieldType.Nationality)
//        //        {
//        //            if (Nationality != ((CommonListItemSource)fieldvalue).Title.ToString())
//        //            {
//        //                Nationality = "Select Nationality";
//        //            }

//        //            Nationality = ((CommonListItemSource)fieldvalue).Title;
//        //            _PersonalDetails.NationalityID = ((CommonListItemSource)fieldvalue).ID;
//        //            _PersonalDetails.NationalityName = ((CommonListItemSource)fieldvalue).Title;
//        //        }


//        //        else if (fieldtype == Constants.FieldType.PreferredJobLocation)
//        //        {


//        //            _selectionJobLocation = ((List<JobLocation>)fieldvalue);

//        //            string title = string.Empty;
//        //            string id = string.Empty;
//        //            int length = _selectionJobLocation.Count;
//        //            int counter = 0;
//        //            foreach (var skill in _selectionJobLocation)
//        //            {
//        //                counter++;
//        //                id += skill.ID;
//        //                title += skill.Title;
//        //                if (counter < length)
//        //                {
//        //                    id += ",";
//        //                    title += ", ";
//        //                }
//        //            }
//        //            if (counter == 0)
//        //            {
//        //                PreferredJobLocation = MessageStringConstants.SelectPreferredJobLocation;
//        //            }
//        //            else
//        //            {
//        //                PreferredJobLocation = title;
//        //                PreferredJobLocationID = id;
//        //                _PersonalDetails.prefer_location_id = id;
//        //                _PersonalDetails.prefer_location_name = title;
//        //            }

//        //        }
//        //        #region Multiple Skill Selection
//        //        else if (fieldtype == Constants.FieldType.PrimarySkill)
//        //        {
//        //            _selectionSkills = ((List<Skill>)fieldvalue);

//        //            string skilltext = string.Empty;
//        //            string skillparams = string.Empty;
//        //            int skillscount = _selectionSkills.Count;
//        //            int counter = 0;
//        //            foreach (var skill in _selectionSkills)
//        //            {
//        //                counter++;
//        //                if (skill.SkillName == "Others")
//        //                {
//        //                    skilltext += AppSessionData.OthersSkill.skill_name;
//        //                    AppPreferences.IsVisibleOthersSkill = "true";
//        //                }
//        //                else
//        //                {
//        //                    skilltext += skill.SkillName;
//        //                    AppPreferences.IsVisibleOthersSkill = "false";
//        //                }


//        //                skillparams += skill.ID;
//        //                if (counter < skillscount)
//        //                {

//        //                    skilltext += ", ";
//        //                    skillparams += ",";
//        //                }
//        //            }
//        //            if (counter == 0)
//        //            {
//        //                Skill = "Select Skill";
//        //            }
//        //            else
//        //            {
//        //                Skill = skilltext;
//        //                SkillID = skillparams;
//        //            }
//        //        }
//        //        #endregion

//        //        #region Language Selection
//        //        else if (fieldtype == Constants.FieldType.Languages)
//        //        {
//        //            _selectionLanguages = ((List<Languageknown>)fieldvalue);

//        //            string languagestext = string.Empty;
//        //            string languageparams = string.Empty;
//        //            int languagescount = _selectionLanguages.Count;
//        //            int counter = 0;
//        //            foreach (var language in _selectionLanguages)
//        //            {
//        //                counter++;
//        //                languagestext += language.Title;
//        //                languageparams += language.LanguageID;
//        //                if (counter < languagescount)
//        //                {
//        //                    languagestext += ", ";
//        //                    languageparams += ",";
//        //                }
//        //            }
//        //            if (counter == 0)
//        //            {
//        //                Languages = "Select Language";

//        //            }
//        //            else
//        //            {
//        //                Languages = languagestext;

//        //            }

//        //        }
//        //        #endregion

//        //        //else if (fieldtype == Constants.FieldType.YearOfCompletion)
//        //        //{
//        //        //    _educationdetails.YearOfCompletion = ((CommonListItemSource)fieldvalue).Title;
//        //        //    YearOfCompletion = ((CommonListItemSource)fieldvalue).Title;
//        //        //}
//        //    }
//        //    catch (Exception ex)
//        //    {
//        //        System.Diagnostics.Debug.WriteLine(ex.Message);
//        //    }
//        //}
//        //#endregion





//        //async Task BindPersonalDetailsToView()
//        //{
//        //    Device.BeginInvokeOnMainThread(async () =>
//        //    {
//        //        try
//        //        {
//        //            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
//        //            _selectionLanguages = new List<Languageknown>();
//        //            if (isNetworkAvailable)
//        //            {
//        //                UserDialogs.Instance.ShowLoading();
//        //                var responsedata = await _commonservice.PostAsync<SeekerDashboardResponseModel, SeekerDashboardModel>(APIData.API_BASE_URL + APIMethods.GetPersonalDetails, _JobSeekerDashboardRequestData);

//        //                if (responsedata != null)
//        //                {
//        //                    if (responsedata.Code == "200")
//        //                    {
//        //                        AppPreferences.LoadSeekerDashboardData = responsedata;
//        //                        var statusResult = AppPreferences.LoadSeekerDashboardData;
//        //                        await BindFromPreference_PersonalDetails(statusResult);
//        //                        UserDialogs.Instance.HideLoading();
//        //                    }
//        //                    else
//        //                    {
//        //                        UserDialogs.Instance.HideLoading();
//        //                        await UserDialogs.Instance.AlertAsync(responsedata.Message);

//        //                    }
//        //                }
//        //                else
//        //                {
//        //                    UserDialogs.Instance.HideLoading();
//        //                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
//        //                }


//        //            }
//        //            else
//        //            {
//        //                UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
//        //            }
//        //        }
//        //        catch (Exception ex)
//        //        {
//        //            UserDialogs.Instance.HideLoading();
//        //            System.Diagnostics.Debug.WriteLine(ex.Message);
//        //            SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.BindPersonalDetailsToView");
//        //        }
//        //    });
//        //}

//        //private void BindJobLocation(Prefer_Job_Location[] prefer_job_location)
//        //{
//        //    try
//        //    {
//        //        _selectionJobLocation = new List<JobLocation>();
//        //        JobLocation objJobLocation = new JobLocation();
//        //        PreferredJobLocationID = string.Empty;
//        //        PreferredJobLocation = string.Empty;
//        //        if (prefer_job_location.Length > 0)
//        //        {
//        //            foreach (var item in prefer_job_location)
//        //            {
//        //                objJobLocation.ID = item.joblocation.id;
//        //                objJobLocation.Title = item.joblocation.district;
//        //                objJobLocation.IsSelected = true;
//        //                PreferredJobLocation = (PreferredJobLocation == "" ? item.joblocation.district : PreferredJobLocation + ',' + item.joblocation.district);
//        //                PreferredJobLocationID = (PreferredJobLocationID == "" ? item.joblocation.id : PreferredJobLocationID + ',' + item.joblocation.id);
//        //                _PersonalDetails.prefer_location_id = PreferredJobLocationID;
//        //                _PersonalDetails.prefer_location_name = PreferredJobLocation;

//        //                JobLocation obj = new JobLocation();
//        //                obj.ID = item.joblocation.id;
//        //                obj.Title = item.joblocation.district;
//        //                obj.IsSelected = true;
//        //                if (!_selectionJobLocation.Contains(obj))
//        //                {
//        //                    _selectionJobLocation.Add(obj);
//        //                }

//        //            }

//        //        }
//        //        else
//        //        {
//        //            PreferredJobLocation = MessageStringConstants.SelectPreferredJobLocation;
//        //        }
//        //    }
//        //    catch (Exception ex)
//        //    {
//        //        System.Diagnostics.Debug.WriteLine(ex.Message);
//        //        PreferredJobLocation = MessageStringConstants.SelectPreferredJobLocation;
//        //        SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.BindJobLocation");
//        //    }
//        //}

//        //private void BindLanguage(Languageknown[] language)
//        //{

//        //    try
//        //    {
//        //        MultipleLanguageSelectionBO objSelectionBO = new MultipleLanguageSelectionBO();
//        //        var lan = language;
//        //        if (_selectionLanguages == null)
//        //            _selectionLanguages = new List<Languageknown>();
//        //        if (lan.Length != 0)
//        //        {
//        //            foreach (var languageItem in lan)
//        //            {
//        //                objSelectionBO.SearchName = "";
//        //                objSelectionBO.LanguageID = languageItem.Languages.ID;
//        //                objSelectionBO.LanguageTitle = languageItem.Languages.LanguageName;
//        //                objSelectionBO.IsSelected = true;
//        //                objSelectionBO.IsRead = languageItem.IsRead;
//        //                objSelectionBO.IsSpeak = languageItem.IsSpeak;
//        //                objSelectionBO.IsWrite = languageItem.IsWrite;
//        //                objSelectionBO.CreatedOn = DateTime.Now;
//        //                _selectionLanguages.Add(languageItem);
//        //                Languages = (Languages == "" ? languageItem.Languages.LanguageName : Languages + ',' + languageItem.Languages.LanguageName);
//        //            }
//        //        }
//        //        else
//        //        {
//        //            Languages = "Select Language";
//        //        }
//        //    }
//        //    catch (Exception ex)
//        //    {
//        //        System.Diagnostics.Debug.WriteLine(ex.Message);
//        //        Languages = "Select Language";
//        //        SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.BindLanguage");
//        //    }

//        //}

//        //#region Private Properties for PersonalDetails


//        //private bool _emailLabel;
//        //public bool emailLabel
//        //{
//        //    get { return _emailLabel; }
//        //    set { _emailLabel = value; OnPropertyChanged(); }
//        //}



//        //private bool _emailEntry;
//        //public bool EmailEntry
//        //{
//        //    get { return _emailEntry; }
//        //    set { _emailEntry = value; OnPropertyChanged(); }
//        //}


//        //private string _CurrentAddress;
//        //public string CurrentAddress
//        //{
//        //    get { return _CurrentAddress; }
//        //    set { _CurrentAddress = value; OnPropertyChanged(); }
//        //}

//        //private string _CurrentState;
//        //public string CurrentState
//        //{
//        //    get { return _CurrentState; }
//        //    set { _CurrentState = value; OnPropertyChanged(); }
//        //}
//        //private string _CurrentDistrict;
//        //public string CurrentDistrict
//        //{
//        //    get { return _CurrentDistrict; }
//        //    set { _CurrentDistrict = value; OnPropertyChanged(); }
//        //}

//        //private string _CurrentZipcode;
//        //public string CurrentZipcode
//        //{
//        //    get { return _CurrentZipcode; }
//        //    set { _CurrentZipcode = value; OnPropertyChanged(); }
//        //}

//        //private int _isCopy;

//        //public int IsCopy
//        //{
//        //    get { return _isCopy; }
//        //    set { _isCopy = value; OnPropertyChanged(); }
//        //}

//        //private string _PermanentAddress;
//        //public string PermanentAddress
//        //{
//        //    get { return _PermanentAddress; }
//        //    set { _PermanentAddress = value; OnPropertyChanged(); }
//        //}

//        //private string _PermanentState;
//        //public string PermanentState
//        //{
//        //    get { return _PermanentState; }
//        //    set { _PermanentState = value; OnPropertyChanged(); }
//        //}

//        //private string _PermanentDistrict;
//        //public string PermanentDistrict
//        //{
//        //    get { return _PermanentDistrict; }
//        //    set { _PermanentDistrict = value; OnPropertyChanged(); }
//        //}
//        //private string _PermanentZipcode;
//        //public string PermanentZipcode
//        //{
//        //    get { return _PermanentZipcode; }
//        //    set { _PermanentZipcode = value; OnPropertyChanged(); }
//        //}
//        //#endregion



//        //private ObservableCollection<Educational_Details> _ItemSource;
//        //public ObservableCollection<Educational_Details> ItemSource
//        //{
//        //    get { return _ItemSource; }
//        //    set { _ItemSource = value; OnPropertyChanged(); }
//        //}


//        //private Educational_Details _SelectedItem;
//        //public Educational_Details SelectedItem
//        //{
//        //    get { return _SelectedItem; }
//        //    set { _SelectedItem = value; OnPropertyChanged(); }
//        //}


//        //public void BindFromPreference_EducationDetails(EducationalDetailsEntrieResponse statusResult)
//        //{

//        //    try
//        //    {

//        //        if (statusResult.responseText.Primaryskills == null)
//        //        {


//        //            Skill = "Select Skill";

//        //        }
//        //        else
//        //        {
//        //            _selectionSkills = new List<Skill>();
//        //            Skill objSkill = new Skill();
//        //            Skill = string.Empty;


//        //            if (statusResult.responseText.Primaryskills != null && statusResult.responseText.Primaryskills.Count != 0)
//        //            {

//        //                foreach (var item in statusResult.responseText.Primaryskills)
//        //                {

//        //                    objSkill.ID = item.id;
//        //                    objSkill.SkillName = item.name;
//        //                    objSkill.IsSelected = true;
//        //                    Skill = (Skill == "" ? item.name : Skill + ',' + item.name);
//        //                    Skill obj = new Skill();
//        //                    obj.ID = item.id;
//        //                    obj.SkillName = item.name;
//        //                    obj.IsSelected = true;
//        //                    _selectionSkills.Add(obj);
//        //                }
//        //                SkillID = objSkill.ID;
//        //                if (statusResult.responseText.skill_others != null)
//        //                    AppSessionData.OthersSkill = statusResult.responseText.skill_others;
//        //                if (!string.IsNullOrEmpty(statusResult.responseText.Others))
//        //                {
//        //                    AppPreferences.IsVisibleOthersSkill = statusResult.responseText.Others;
//        //                    if (AppPreferences.IsVisibleOthersSkill == "true")
//        //                    {

//        //                        if (Skill.Contains("Others"))
//        //                        {
//        //                            Skill = Skill.Replace("Others", statusResult.responseText.skill_others.skill_name);
//        //                        }
//        //                        else
//        //                        {
//        //                            Skill = Skill + "," + statusResult.responseText.skill_others.skill_name;
//        //                        }
//        //                        SkillID = SkillID + "," + statusResult.responseText.skill_others.temp_skill_id;
//        //                    }
//        //                }
//        //                GenerateSkills();
//        //            }
//        //            else
//        //            {
//        //                Skill = "Select Skill";
//        //            }
//        //        }




//        //        if (statusResult.responseText.educational_details != null)
//        //        {
//        //            ItemSource.Clear();
//        //            StackLayout_SchoolorCollege.Children.Clear();

//        //            for (int i = 0; i < statusResult.responseText.educational_details.Length; i++)
//        //            {
//        //                Educational_Details obj = new Educational_Details();
//        //                obj.hiremee_id = statusResult.responseText.educational_details[i].hiremee_id;
//        //                obj.coursetype_id = statusResult.responseText.educational_details[i].coursetype_id;
//        //                obj.course_type_name = statusResult.responseText.educational_details[i].course_type_name;
//        //                obj.course_id = statusResult.responseText.educational_details[i].course_id;
//        //                obj.course_name = statusResult.responseText.educational_details[i].course_name;
//        //                obj.specialization_id = statusResult.responseText.educational_details[i].specialization_id;
//        //                obj.specialization_name = statusResult.responseText.educational_details[i].specialization_name;
//        //                obj.educational_level = statusResult.responseText.educational_details[i].educational_level;
//        //                obj.board_id = statusResult.responseText.educational_details[i].board_id;
//        //                obj.board_name = statusResult.responseText.educational_details[i].board_name;
//        //                obj.school_name = statusResult.responseText.educational_details[i].school_name;
//        //                obj.college_id = statusResult.responseText.educational_details[i].college_id;
//        //                obj.college_name = statusResult.responseText.educational_details[i].college_name;
//        //                obj.university_id = statusResult.responseText.educational_details[i].university_id;
//        //                obj.university_name = statusResult.responseText.educational_details[i].university_name;
//        //                obj.year_of_completion = statusResult.responseText.educational_details[i].year_of_completion;
//        //                obj.cgpa = statusResult.responseText.educational_details[i].cgpa;
//        //                obj.percentage = statusResult.responseText.educational_details[i].percentage;
//        //                obj.backlog = statusResult.responseText.educational_details[i].backlog;
//        //                obj.zip_code = statusResult.responseText.educational_details[i].zip_code;


//        //                obj.DisplayCourseTypeName = statusResult.responseText.educational_details[i].course_type_name;
//        //                if (string.IsNullOrEmpty(statusResult.responseText.educational_details[i].board_name))
//        //                {
//        //                    obj.DisplayBoardNameOrUniversityName = statusResult.responseText.educational_details[i].university_name;
//        //                }
//        //                else
//        //                {
//        //                    obj.DisplayBoardNameOrUniversityName = statusResult.responseText.educational_details[i].board_name;
//        //                }

//        //                if (string.IsNullOrEmpty(statusResult.responseText.educational_details[i].school_name))
//        //                {
//        //                    obj.DisplaySchoolNameOrCollegeName = statusResult.responseText.educational_details[i].college_name.Replace("\r\n", string.Empty);
//        //                }
//        //                else
//        //                {
//        //                    obj.DisplaySchoolNameOrCollegeName = statusResult.responseText.educational_details[i].school_name.Replace("\r\n", string.Empty);

//        //                }



//        //                if (string.IsNullOrEmpty(statusResult.responseText.educational_details[i].cgpa) || statusResult.responseText.educational_details[i].cgpa == "0" || statusResult.responseText.educational_details[i].cgpa == "0.0" || statusResult.responseText.educational_details[i].cgpa == "0.00")
//        //                {
//        //                    obj.DisplayCGPAOrPercentage = statusResult.responseText.educational_details[i].percentage + " % - ";
//        //                }
//        //                else
//        //                {
//        //                    obj.DisplayCGPAOrPercentage = statusResult.responseText.educational_details[i].cgpa + " CGPA - ";
//        //                }

//        //                obj.DisplayYearOfPassing = statusResult.responseText.educational_details[i].year_of_completion;



//        //                ItemSource.Add(obj);

//        //                var CourseTypeName = new Label { Text = obj.DisplayCourseTypeName, TextColor = Color.Black, FontAttributes = FontAttributes.Bold, FontSize = 14 };
//        //                var BoardNameOrUniversityName = new Label { Text = obj.DisplayBoardNameOrUniversityName, TextColor = Color.Black, VerticalOptions = LayoutOptions.FillAndExpand };
//        //                var SchoolNameOrCollegeName = new Label { Text = obj.DisplaySchoolNameOrCollegeName, TextColor = Color.Black };
//        //                var CGPAOrPercentage = new Label { Text = obj.DisplayCGPAOrPercentage + obj.DisplayYearOfPassing, TextColor = Color.Black };
//        //                //    var YearOfPassing = new Label { Text = obj.DisplayYearOfPassing, TextColor = Color.Black };
//        //                var index = new Label { Text = i.ToString(), IsVisible = false };

//        //                var underline = new BoxView { HeightRequest = 0.5, Margin = new Thickness(0, 2, 0, 0), BackgroundColor = Color.Gray };
//        //                var dynamicStackItme = new StackLayout
//        //                {
//        //                    Margin = 2,
//        //                    VerticalOptions = LayoutOptions.Fill,
//        //                    BackgroundColor = Color.Transparent,
//        //                    HorizontalOptions = LayoutOptions.FillAndExpand,
//        //                    Orientation = StackOrientation.Vertical
//        //                };

//        //                var forgetPassword_tap = new TapGestureRecognizer();
//        //                forgetPassword_tap.Tapped += (s, e) =>
//        //                {
//        //                    StackLayout stackLayout = (StackLayout)s;
//        //                    Label selectedIndex = (Label)stackLayout.Children[4];
//        //                    SelectedItem = ItemSource[int.Parse(selectedIndex.Text.ToString())];

//        //                    isClicked = true;
//        //                    if (isClicked)
//        //                    {
//        //                        isClicked = false;
//        //                        if (SelectedItem.educational_level == "1" || SelectedItem.educational_level == "2")
//        //                        {
//        //                            _navigationservice.PushAsync(new SchoolingEducationDetailsPage(Constants.FieldType.EditEducation, ItemSource, SelectedItem));
//        //                        }
//        //                        else if (SelectedItem.educational_level == "3" || SelectedItem.educational_level == "4" || SelectedItem.educational_level == "5")
//        //                        {
//        //                            _navigationservice.PushAsync(new CollegeEducationDetailsPage(Constants.FieldType.EditEducation, ItemSource, SelectedItem));
//        //                        }

//        //                    }
//        //                    Task.Run(async () =>
//        //                    {
//        //                        await Task.Delay(500);
//        //                        isClicked = true;
//        //                    });


//        //                    //foreach(var item in stackLayout.Children)
//        //                    //{
//        //                    //    if(item.Equals(new Label()))
//        //                    //    {
//        //                    //        Label label = (Label)item;
//        //                    //       // var test = label.Text;
//        //                    //    }

//        //                    //}

//        //                    //    List<View> x = (List<View>)stackLayout.Children;


//        //                };
//        //                dynamicStackItme.GestureRecognizers.Add(forgetPassword_tap);

//        //                dynamicStackItme.Children.Add(CourseTypeName);
//        //                dynamicStackItme.Children.Add(BoardNameOrUniversityName);
//        //                dynamicStackItme.Children.Add(SchoolNameOrCollegeName);
//        //                dynamicStackItme.Children.Add(CGPAOrPercentage);
//        //                //   firstStack.Children.Add(YearOfPassing);
//        //                dynamicStackItme.Children.Add(index);
//        //                dynamicStackItme.Children.Add(underline);
//        //                StackLayout_SchoolorCollege.Children.Add(dynamicStackItme);
//        //            }


//        //            _courseTypeID = new List<string>();
//        //            _courseTypeID.Clear();


//        //            _educationalLevel = new List<string>();
//        //            _educationalLevel.Clear();
//        //            for (int i = 0; i < statusResult.responseText.educational_details.Length; i++)
//        //            {
//        //                _courseTypeID.Add(statusResult.responseText.educational_details[i].educational_level);

//        //            }

//        //        }
//        //        else
//        //        {

//        //            _courseTypeID = new List<string>();
//        //            _courseTypeID.Clear();
//        //            ItemSource.Clear();
//        //            StackLayout_SchoolorCollege.Children.Clear();

//        //        }
//        //    }
//        //    catch (Exception ex)
//        //    {
//        //        //await UserDialogs.Instance.AlertAsync(ex.Message);
//        //        UserDialogs.Instance.HideLoading();
//        //        System.Diagnostics.Debug.WriteLine(ex.Message);
//        //        SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.BindFromPreference_EducationDetails");
//        //    }

//        //}

//        //private void StackEvent(object obj)
//        //{
//        //    // throw new NotImplementedException();
//        //}



//        //public async Task GetEducationDetails()
//        //{
//        //    Device.BeginInvokeOnMainThread(async () =>
//        //    {
//        //        try
//        //        {
//        //            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
//        //            if (isNetworkAvailable)
//        //            {
//        //                UserDialogs.Instance.ShowLoading();
//        //                var resultdata = await _commonservice.PostAsync<EducationalDetailsEntrieResponse, EducationTokenRequestData>(APIData.API_BASE_URL + APIMethods.GetEducationDetails, BaseRequest);
//        //                UserDialogs.Instance.HideLoading();
//        //                if (resultdata != null)
//        //                {
//        //                    if (resultdata.code == "200")
//        //                    {
//        //                        AppPreferences.LoadEducationDetails = resultdata;
//        //                        var statusResult = AppPreferences.LoadEducationDetails;
//        //                        BindFromPreference_EducationDetails(statusResult);
//        //                        if (string.IsNullOrEmpty(AppPreferences.FirstName) && string.IsNullOrEmpty(AppPreferences.LastName))
//        //                        {
//        //                            await BindPersonalDetailsToView();
//        //                        }
//        //                    }
//        //                }

//        //            }
//        //            else
//        //            {
//        //                UserDialogs.Instance.HideLoading();
//        //                UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);

//        //            }
//        //        }
//        //        catch (Exception ex)
//        //        {
//        //            //await UserDialogs.Instance.AlertAsync(ex.Message);
//        //            UserDialogs.Instance.HideLoading();
//        //            System.Diagnostics.Debug.WriteLine(ex.Message);
//        //            SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.GetEducationDetails");
//        //        }
//        //    });
//        //}

//        //#region Private Properties for EducationDetails

//        //private string _Nationality;
//        //public string Nationality
//        //{
//        //    get { return _Nationality; }
//        //    set
//        //    {
//        //        _Nationality = value;
//        //        OnPropertyChanged();
//        //    }
//        //}

//        //private string _university;
//        //public string University
//        //{
//        //    get { return _university; }
//        //    set
//        //    {
//        //        _university = value;
//        //        OnPropertyChanged();
//        //    }
//        //}

//        //private string _collegeName;
//        //public string CollegeName
//        //{
//        //    get { return _collegeName; }
//        //    set
//        //    {
//        //        _collegeName = value;
//        //        OnPropertyChanged();
//        //    }
//        //}
//        ////private string _CurrentZipCode;
//        ////public string CurrentZipCode
//        ////{
//        ////    get { return _CurrentZipCode; }
//        ////    set
//        ////    {
//        ////        _CurrentZipCode = value;
//        ////        OnPropertyChanged();
//        ////    }
//        ////}
//        ////private string _PermanentZipCode;
//        ////public string PermanentZipCode
//        ////{
//        ////    get { return _PermanentZipCode; }
//        ////    set
//        ////    {
//        ////        _PermanentZipCode = value;
//        ////        OnPropertyChanged();
//        ////    }
//        ////}
//        //private string _courseType;
//        //public string CourseType
//        //{
//        //    get { return _courseType; }
//        //    set
//        //    {
//        //        _courseType = value;
//        //        OnPropertyChanged();
//        //    }
//        //}



//        //private string _email;
//        //public string Email
//        //{
//        //    get { return _email; }
//        //    set
//        //    {
//        //        _email = value;
//        //        OnPropertyChanged();
//        //    }
//        //}

//        //private string _courseName;
//        //public string CourseName
//        //{
//        //    get { return _courseName; }
//        //    set
//        //    {
//        //        _courseName = value;
//        //        OnPropertyChanged();
//        //    }
//        //}
//        //private string _specialization;
//        //public string Specialization
//        //{
//        //    get { return _specialization; }
//        //    set
//        //    {
//        //        _specialization = value;
//        //        OnPropertyChanged();
//        //    }
//        //}
//        //private string _skill;
//        //public string Skill
//        //{
//        //    get { return _skill; }
//        //    set
//        //    {
//        //        _skill = value;
//        //        OnPropertyChanged();
//        //    }
//        //}
//        //private string _skillID;
//        //public string SkillID
//        //{
//        //    get { return _skillID; }
//        //    set
//        //    {
//        //        _skillID = value;
//        //        OnPropertyChanged();

//        //    }
//        //}
//        ////private string _yearOfCompletion;
//        ////public string YearOfCompletion
//        ////{
//        ////	get { return _yearOfCompletion; }
//        ////	set
//        ////	{
//        ////		_yearOfCompletion = value;
//        ////		OnPropertyChanged();
//        ////	}
//        ////}
//        //private string _preferredJobLocation;

//        //public string PreferredJobLocation
//        //{
//        //    get { return _preferredJobLocation; }
//        //    set { _preferredJobLocation = value; OnPropertyChanged(); }
//        //}
//        //private string _preferredJobLocationID;

//        //public string PreferredJobLocationID
//        //{
//        //    get { return _preferredJobLocationID; }
//        //    set
//        //    {
//        //        _preferredJobLocationID = value; OnPropertyChanged();
//        //    }

//        //}
//        ////private string _pincode;
//        ////public string PinCode
//        ////{
//        ////	get { return _pincode; }
//        ////	set
//        ////	{
//        ////		_pincode = value;
//        ////		OnPropertyChanged();
//        ////	}
//        ////}
//        //#endregion

//        //#region SavePersonalDetails
//        //async Task SavePersonalDetails()
//        //{
//        //    System.Diagnostics.Debug.WriteLine("@ SeekerPersonalAndEducationPage.SavePersonalDetails");
//        //    try
//        //    {
//        //        bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
//        //        if (isNetworkAvailable)
//        //        {
//        //            if (IsValidatePersonalDetails())
//        //            {


//        //                var personaldetailsrequest = new ProfileDetailsRequestData();

//        //                personaldetailsrequest.FirstName = _PersonalDetails.FirstName;
//        //                personaldetailsrequest.LastName = _PersonalDetails.LastName;
//        //                personaldetailsrequest.EmailAddress = EmailAddress;
//        //                personaldetailsrequest.MobileNumber = _PersonalDetails.MobileNumber;
//        //                personaldetailsrequest.DateOfBirth = DatepickerValue;
//        //                personaldetailsrequest.Gender = Gender;
//        //                personaldetailsrequest.Disablity = HandicappedData;
//        //                personaldetailsrequest.Nationality = _PersonalDetails.NationalityID;
//        //                personaldetailsrequest.AadharNumber = AadhaarNumber ?? string.Empty;
//        //                personaldetailsrequest.PassportNumber = PassPortNumber ?? string.Empty;
//        //                personaldetailsrequest.CurrentAddress = CurrentAddress;
//        //                personaldetailsrequest.CurrentStateID = _PersonalDetails.CurrentStateId;
//        //                personaldetailsrequest.CurrentCityID = _PersonalDetails.CurrentCityId;
//        //                personaldetailsrequest.CurrentPinCode = CurrentZipcode;
//        //                personaldetailsrequest.PermanentAddress = PermanentAddress;
//        //                personaldetailsrequest.PermanentStateID = _PersonalDetails.PermanentStateID;
//        //                personaldetailsrequest.PermanentCityID = _PersonalDetails.PermanentCityID;
//        //                personaldetailsrequest.PermanentPinCode = PermanentZipcode;


//        //                personaldetailsrequest.JobLocationId = _PersonalDetails.prefer_location_id;



//        //                personaldetailsrequest.Languages = _selectionLanguages.ToArray();
//        //                personaldetailsrequest.is_copy = IsCopy.ToString();
//        //                _PersonalDetails.Languages = _selectionLanguages.ToArray();
//        //                /*update personal details into Preference for Local Usage Purpose*/
//        //                AppSessionData.ProfileDetailsRequestData = _PersonalDetails;
//        //                AppSessionData.Language = _selectionLanguages.ToArray();
//        //                /*update personal details into server via API Call*/
//        //                UserDialogs.Instance.ShowLoading();
//        //                var response = await _commonservice.PostAsync<ProfileDetailsResponseData, ProfileDetailsRequestData>(APIData.API_BASE_URL + APIMethods.PersonalDetailsUpdate_V8, personaldetailsrequest);
//        //                // var response = await _commonservice.PostAsync<ProfileDetailsResponseData, ProfileDetailsRequestData>("http://172.18.1.89:92/api/" + APIMethods.PersonalDetailsUpdate_V7, personaldetailsrequest);
//        //                UserDialogs.Instance.HideLoading();
//        //                if (response != null)
//        //                {
//        //                    if (response.code == "200")
//        //                    {
//        //                        //Update AssessmentData with IsSynched=true
//        //                        //await UserDialogs.Instance.AlertAsync(response.Message);
//        //                        _isPersonalDetailsUpdated = true;
//        //                        AppPreferences.IsProfileCompleted = true;
//        //                        AppPreferences.IsFirstRun = false;
//        //                        NavigateToNextPageIfNeeded();
//        //                        await ShowEducationalTab();
//        //                    }
//        //                    else if (response.code == "402")
//        //                    {
//        //                        UserDialogs.Instance.HideLoading();
//        //                        await UserDialogs.Instance.AlertAsync("Your Token has  been expired, Please Login Again");

//        //                        Application.Current.MainPage = new NavigationPage(new LoginPageNew());
//        //                    }
//        //                    else
//        //                    {
//        //                        UserDialogs.Instance.HideLoading();
//        //                        await UserDialogs.Instance.AlertAsync(response.message);
//        //                    }
//        //                }
//        //                //BtnSavePersonal.IsEnabled = true;
//        //            }
//        //        }
//        //        else
//        //        {
//        //            UserDialogs.Instance.HideLoading();
//        //            await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
//        //        }
//        //    }
//        //    catch (Exception ex)
//        //    {
//        //        //await UserDialogs.Instance.AlertAsync(ex.Message);
//        //        UserDialogs.Instance.HideLoading();
//        //        System.Diagnostics.Debug.WriteLine(ex.Message);
//        //        SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.SavePersonalDetails");
//        //    }
//        //}
//        //#endregion

//        //#region BindCourseTypeData
//        //async Task BindCourseTypeData()
//        //{
//        //    System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindCourseTypeData");
//        //    // List<CommonListItemSource> objCommonListItemSource = new List<CommonListItemSource>();
//        //    // if (GlobalCommonListItemSource == null)
//        //    // {

//        //    try
//        //    {
//        //        bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
//        //        if (isNetworkAvailable)
//        //        {

//        //            MasterTableRequestData MasterTableRequestData = new MasterTableRequestData()
//        //            {
//        //                HiremeeID = AppSessionData.ActiveToken.HireMeID,
//        //                Token = AppSessionData.ActiveToken.Token,
//        //                TableName = "coursetype"
//        //            };
//        //            UserDialogs.Instance.ShowLoading();
//        //            var coursetypes = await _commonservice.PostAsync<CourseTypeResponseData, MasterTableRequestData>(APIData.API_BASE_URL + APIMethods.MasterTables, MasterTableRequestData);
//        //            UserDialogs.Instance.HideLoading();
//        //            if (coursetypes != null)
//        //            {
//        //                if (coursetypes.code == "200")
//        //                {
//        //                    //GlobalCommonListItemSource = coursetypes.Response.Response;

//        //                    if (_courseTypeID == null)
//        //                    {
//        //                        _courseTypeID = new List<string>();
//        //                        _courseTypeID.Clear();
//        //                    }


//        //                    var page = new AddEducationPopupPage(_courseTypeID, coursetypes.Response.Response, ItemSource);
//        //                    await _navigationservice.PushAsync(page);

//        //                }
//        //                else
//        //                {
//        //                    await UserDialogs.Instance.AlertAsync(coursetypes.message);
//        //                }
//        //            }
//        //        }
//        //        else
//        //        {
//        //            UserDialogs.Instance.HideLoading();
//        //            await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
//        //        }
//        //    }
//        //    catch (Exception ex)
//        //    {
//        //        //await UserDialogs.Instance.AlertAsync(ex.Message);
//        //        UserDialogs.Instance.HideLoading();
//        //        System.Diagnostics.Debug.WriteLine(ex.Message);
//        //        SendErrorMessageToServer(ex, "SeekerNotificationViewModel.BindCourseTypeData");
//        //    }
//        //    //}

//        //}

//        //#endregion

//        //#region Show Educational and Personal
//        //public async Task ShowEducationalTab()
//        //{
//        //    if (AppPreferences.LoadEducationDetails != null)
//        //    {
//        //        if (AppPreferences.LoadEducationDetails.code == "200")
//        //        {
//        //            BindFromPreference_EducationDetails(AppPreferences.LoadEducationDetails);
//        //        }
//        //    }
//        //    await GetEducationDetails();

//        //    EducationBackbtnColor = Color.FromHex("#F7CC59");
//        //    PersonalBackbtnColor = Color.Transparent;
//        //    IsEducationGrid = true;
//        //    IsPersonalGrid = false;
//        //    PageTitle = "Education";
//        //}


//        //public async Task BindFromPreference_PersonalDetails(SeekerDashboardResponseModel statusResult)
//        //{
//        //    try
//        //    {
//        //        if (statusResult == null)
//        //        {
//        //            UserDialogs.Instance.HideLoading();
//        //            return;
//        //        }
//        //        AppSessionData.ProfileDetailsRequestData = statusResult.ProfileDetails;
//        //        _PersonalDetails = statusResult.ProfileDetails;

//        //        if (_PersonalDetails != null)
//        //        {
//        //            Languages = string.Empty;
//        //            LastName = _PersonalDetails.LastName;
//        //            FirstName = _PersonalDetails.FirstName;
//        //            AppPreferences.FirstName = _PersonalDetails.FirstName;
//        //            AppPreferences.LastName = _PersonalDetails.LastName;

//        //            FullName = FirstName.ToUpper() + " " + LastName.ToUpper();
//        //            EmailID = _PersonalDetails.EmailAddress;

//        //            AppPreferences.EmailAddress = _PersonalDetails.EmailAddress;
//        //            MobileNo = _PersonalDetails.MobileNumber;
//        //            AppPreferences.MobileNumber = _PersonalDetails.MobileNumber;
//        //            HiremeeID = "HireMee ID : " + _PersonalDetails.HireMeeID;
//        //            AppPreferences.HireMeeID = _PersonalDetails.HireMeeID;
//        //            AppPreferences.userName = FullName;

//        //            DatepickerValue = _PersonalDetails.Dateofbirth;
//        //            if (DatepickerValue != null && DatepickerValue != "Date of Birth" && DatepickerValue != "0000-00-00")
//        //            {
//        //                DateTime Dob = DateTime.Parse(DatepickerValue);
//        //                DateTime now = DateTime.Today;
//        //                int age = now.Year - Dob.Year;
//        //                if (Dob.AddYears(age) > now)
//        //                    age--;
//        //                Age = age.ToString();
//        //            }
//        //            Gender = _PersonalDetails.Gender ?? string.Empty;
//        //            HandicappedData = _PersonalDetails.Disablity ?? string.Empty;
//        //            _PersonalDetails.AadharNumber = _PersonalDetails.AadharNumber;
//        //            AadhaarNumber = _PersonalDetails.AadharNumber;
//        //            PassPortNumber = _PersonalDetails.PassportNumber;



//        //            if (statusResult.ProfileDetails.is_copy == "1")
//        //            {
//        //                IsToggleSameAddress = true;
//        //            }
//        //            else
//        //            {
//        //                IsToggleSameAddress = false;
//        //            }


//        //            if (string.IsNullOrEmpty(statusResult.ProfileDetails.NationalityID) || statusResult.ProfileDetails.NationalityName == null)
//        //                Nationality = "Select Nationality";
//        //            else
//        //                Nationality = statusResult.ProfileDetails.NationalityName;
//        //            _PersonalDetails.CurrentAddress = statusResult.ProfileDetails.CurrentAddress ?? string.Empty;
//        //            CurrentAddress = statusResult.ProfileDetails.CurrentAddress ?? string.Empty;

//        //            if (string.IsNullOrEmpty(statusResult.ProfileDetails.CurrentZipcode) || Int32.Parse(statusResult.ProfileDetails.CurrentZipcode) == 0)
//        //            {
//        //                _PersonalDetails.CurrentZipcode = string.Empty;
//        //                CurrentZipcode = string.Empty;
//        //            }
//        //            else
//        //            {
//        //                _PersonalDetails.CurrentZipcode = statusResult.ProfileDetails.CurrentZipcode;
//        //                CurrentZipcode = statusResult.ProfileDetails.CurrentZipcode;
//        //            }

//        //            if (string.IsNullOrEmpty(statusResult.ProfileDetails.CurrentStateId) || statusResult.ProfileDetails.CurrentStateId == "0")
//        //            {
//        //                _PersonalDetails.CurrentStateId = string.Empty;
//        //                _PersonalDetails.CurrentStateName = MessageStringConstants.SelectCurrentState;
//        //                CurrentState = MessageStringConstants.SelectCurrentState;
//        //            }
//        //            else
//        //            {
//        //                _PersonalDetails.CurrentStateId = statusResult.ProfileDetails.CurrentStateId ?? string.Empty;
//        //                _PersonalDetails.CurrentStateName = statusResult.ProfileDetails.CurrentStateName ?? MessageStringConstants.SelectCurrentState;
//        //                CurrentState = statusResult.ProfileDetails.CurrentStateName ?? MessageStringConstants.SelectCurrentState;
//        //            }

//        //            if (string.IsNullOrEmpty(statusResult.ProfileDetails.CurrentCityId) || statusResult.ProfileDetails.CurrentCityId == "0")
//        //            {

//        //                _PersonalDetails.CurrentCityId = string.Empty;
//        //                _PersonalDetails.CurrentCityName = MessageStringConstants.SelectCurrentDistrict;
//        //                CurrentDistrict = MessageStringConstants.SelectCurrentDistrict;
//        //            }
//        //            else
//        //            {
//        //                _PersonalDetails.CurrentCityId = statusResult.ProfileDetails.CurrentCityId ?? string.Empty;
//        //                _PersonalDetails.CurrentCityName = statusResult.ProfileDetails.CurrentCityName ?? MessageStringConstants.SelectCurrentDistrict;
//        //                CurrentDistrict = statusResult.ProfileDetails.CurrentCityName ?? MessageStringConstants.SelectCurrentDistrict;
//        //            }

//        //            _PersonalDetails.PermanentAddress = statusResult.ProfileDetails.PermanentAddress;
//        //            PermanentAddress = statusResult.ProfileDetails.PermanentAddress;
//        //            if (string.IsNullOrEmpty(statusResult.ProfileDetails.PermanentZipcode) || Int32.Parse(statusResult.ProfileDetails.PermanentZipcode) == 0)
//        //            {
//        //                _PersonalDetails.PermanentZipcode = string.Empty;
//        //                PermanentZipcode = string.Empty;
//        //            }
//        //            else
//        //            {
//        //                _PersonalDetails.PermanentZipcode = statusResult.ProfileDetails.PermanentZipcode;
//        //                PermanentZipcode = statusResult.ProfileDetails.PermanentZipcode;
//        //            }

//        //            if (string.IsNullOrEmpty(statusResult.ProfileDetails.PermanentStateID) || statusResult.ProfileDetails.PermanentStateID == "0")
//        //            {
//        //                _PersonalDetails.PermanentStateID = string.Empty;
//        //                _PersonalDetails.PermanentStateName = MessageStringConstants.SelectPermanentState;
//        //                PermanentState = MessageStringConstants.SelectPermanentState;
//        //            }
//        //            else
//        //            {
//        //                _PersonalDetails.PermanentStateID = statusResult.ProfileDetails.PermanentStateID ?? string.Empty;
//        //                _PersonalDetails.PermanentStateName = statusResult.ProfileDetails.PermanentStateName ?? MessageStringConstants.SelectPermanentState;
//        //                PermanentState = statusResult.ProfileDetails.PermanentStateName ?? MessageStringConstants.SelectPermanentState;
//        //            }

//        //            if (string.IsNullOrEmpty(statusResult.ProfileDetails.PermanentCityID) || statusResult.ProfileDetails.PermanentCityID == "0")
//        //            {
//        //                _PersonalDetails.PermanentCityID = string.Empty;
//        //                _PersonalDetails.PermanentCityName = MessageStringConstants.SelectPermanentDistrict;
//        //                PermanentDistrict = MessageStringConstants.SelectPermanentDistrict;
//        //            }
//        //            else
//        //            {
//        //                _PersonalDetails.PermanentCityID = statusResult.ProfileDetails.PermanentCityID ?? string.Empty;
//        //                _PersonalDetails.PermanentCityName = statusResult.ProfileDetails.PermanentCityName ?? MessageStringConstants.SelectPermanentDistrict;
//        //                PermanentDistrict = statusResult.ProfileDetails.PermanentCityName ?? MessageStringConstants.SelectPermanentDistrict;
//        //            }

//        //        }
//        //        AppSessionData.Language = statusResult.Languages;
//        //        if (statusResult.Languages != null)
//        //        {
//        //            BindLanguage(statusResult.Languages);
//        //        }
//        //        else
//        //        {
//        //            Languages = "Select Language";
//        //        }
//        //        if (statusResult.prefer_job_location == null)
//        //        {
//        //            PreferredJobLocation = MessageStringConstants.SelectPreferredJobLocation;
//        //        }
//        //        else
//        //        {
//        //            BindJobLocation(statusResult.prefer_job_location);
//        //        }
//        //        if (statusResult.ProfileImage != null && statusResult.ProfileImage.S3_ID != null)
//        //        {
//        //            await GetUserPic(statusResult.ProfileImage.S3_ID);
//        //        }

//        //        UserDialogs.Instance.HideLoading();
//        //    }
//        //    catch (Exception ex)
//        //    {

//        //        UserDialogs.Instance.HideLoading();
//        //        System.Diagnostics.Debug.WriteLine(ex.Message);
//        //        //SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.BindFromPreference_PersonalDetails");
//        //    }
//        //}

//        //public async Task ShowPersonalTab()
//        //{

//        //    try
//        //    {
//        //        if (AppPreferences.LoadSeekerDashboardData != null)
//        //        {
//        //            if (AppPreferences.LoadSeekerDashboardData.Code == "200")
//        //            {
//        //                await BindFromPreference_PersonalDetails(AppPreferences.LoadSeekerDashboardData);
//        //            }
//        //        }

//        //        await BindPersonalDetailsToView();
//        //        PersonalBackbtnColor = Color.FromHex("#F7CC59");
//        //        EducationBackbtnColor = Color.Transparent;
//        //        IsPersonalGrid = true;
//        //        IsEducationGrid = false;
//        //        PageTitle = "Personal";
//        //    }
//        //    catch (Exception ex)
//        //    {

//        //        UserDialogs.Instance.HideLoading();
//        //        System.Diagnostics.Debug.WriteLine(ex.Message);
//        //        SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.ShowPersonalTab");
//        //    }
//        //}
//        //private string _pagetitle;
//        //public string PageTitle
//        //{
//        //    get { return _pagetitle; }
//        //    set { _pagetitle = value; OnPropertyChanged(); }
//        //}

//        //private async Task LoadUserBasicDetailsAsync()
//        //{
//        //    try
//        //    {

//        //        FullName = AppPreferences.userName;
//        //        EmailID = AppPreferences.EmailAddress;
//        //        MobileNo = AppPreferences.MobileNumber;
//        //        HiremeeID = "HireMee ID : " + AppPreferences.HireMeeID;
//        //        profilepic = (string)Application.Current.Resources["IconUser"];

//        //        if (AppPreferences.ProfilePicture != string.Empty)
//        //            profilepic = AppPreferences.ProfilePicture;


//        //    }
//        //    catch (Exception ex)
//        //    {
//        //        System.Diagnostics.Debug.WriteLine(ex.Message);
//        //        SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.LoadUserBasicDetailsAsync");

//        //    }
//        //}

//        //#endregion

//        //#region IsValidatePersonalDetails
//        //bool IsValidatePersonalDetails()
//        //{

//        //    if (EmailEntry == true)
//        //    {


//        //        if (string.IsNullOrEmpty(EmailAddress))
//        //        {
//        //            Device.BeginInvokeOnMainThread(async () =>
//        //            {
//        //                await UserDialogs.Instance.AlertAsync("Enter Email");
//        //            });
//        //            return false;
//        //        }


//        //        if (!Utilities.ValidateEmailAddress(EmailAddress.Trim()))
//        //        {
//        //            Device.BeginInvokeOnMainThread(async () =>
//        //            {
//        //                await UserDialogs.Instance.AlertAsync("Enter Valid Email Id");
//        //            });
//        //            return false;
//        //        }

//        //        //if (!AppPreferences.IsVerifyEmail)
//        //        //{

//        //        //    Device.BeginInvokeOnMainThread(async () =>
//        //        //    {
//        //        //        await UserDialogs.Instance.AlertAsync(MessageStringConstants.VerifyEmail);
//        //        //    });
//        //        //    return false;

//        //        //}

//        //    }
//        //    else
//        //    {

//        //        EmailAddress = AppSessionData.ProfileDetailsRequestData.EmailAddress;
//        //    }



//        //    if (DatepickerValue == "0000-00-00")
//        //    {
//        //        Device.BeginInvokeOnMainThread(async () =>
//        //        {
//        //            await UserDialogs.Instance.AlertAsync("Select Date of birth");
//        //        });
//        //        return false;
//        //    }
//        //    //if (_PersonalDetails.Dateofbirth == "0000-00-00" || string.IsNullOrEmpty(DatepickerValue))
//        //    //{
//        //    //    await UserDialogs.Instance.AlertAsync("Select Date of birth");
//        //    //    return false;
//        //    //}







//        //    if (string.IsNullOrEmpty(Gender))
//        //    {
//        //        Device.BeginInvokeOnMainThread(async () =>
//        //        {
//        //            await UserDialogs.Instance.AlertAsync("Select Gender");
//        //        });
//        //        return false;
//        //    }
//        //    if (string.IsNullOrEmpty(HandicappedData))
//        //    {
//        //        Device.BeginInvokeOnMainThread(async () =>
//        //        {
//        //            await UserDialogs.Instance.AlertAsync("Select Disablity");
//        //        });
//        //        return false;
//        //    }

//        //    if (!string.IsNullOrEmpty(AadhaarNumber) && !Utilities.ValidateAadhaarNumber(AadhaarNumber))
//        //    {
//        //        Device.BeginInvokeOnMainThread(async () =>
//        //        {
//        //            await UserDialogs.Instance.AlertAsync("Enter Valid Aadhaar Number");
//        //        });
//        //        return false;
//        //    }
//        //    if (!string.IsNullOrEmpty(PassPortNumber) && !Utilities.ValidatePassportNumber(PassPortNumber))
//        //    {
//        //        Device.BeginInvokeOnMainThread(async () =>
//        //        {
//        //            await UserDialogs.Instance.AlertAsync("Enter Valid Passport Number");
//        //        });
//        //        return false;
//        //    }
//        //    if (string.IsNullOrEmpty(Languages) || Languages == "Select Language")
//        //    {
//        //        Device.BeginInvokeOnMainThread(async () =>
//        //        {
//        //            await UserDialogs.Instance.AlertAsync("Select Language");
//        //        });
//        //        return false;
//        //    }
//        //    if (string.IsNullOrEmpty(_PersonalDetails.NationalityID) || Nationality.Contains("Select Nationality"))
//        //    {
//        //        Device.BeginInvokeOnMainThread(async () =>
//        //        {
//        //            await UserDialogs.Instance.AlertAsync("Select Nationality");
//        //        });
//        //        return false;
//        //    }

//        //    if (string.IsNullOrEmpty(CurrentAddress) || !Utilities.Address(CurrentAddress))
//        //    {
//        //        Device.BeginInvokeOnMainThread(async () =>
//        //        {
//        //            await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterCurrentAddress);
//        //        });
//        //        return false;
//        //    }



//        //    if (string.IsNullOrEmpty(_PersonalDetails.CurrentStateId) || _PersonalDetails.CurrentStateName == MessageStringConstants.SelectCurrentState)
//        //    {
//        //        Device.BeginInvokeOnMainThread(async () =>
//        //        {
//        //            await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectCurrentState);
//        //        }); return false;
//        //    }
//        //    if (string.IsNullOrEmpty(_PersonalDetails.CurrentCityId) || _PersonalDetails.CurrentCityName == MessageStringConstants.SelectCurrentDistrict)
//        //    {
//        //        Device.BeginInvokeOnMainThread(async () =>
//        //        {
//        //            await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectCurrentDistrict);
//        //        }); return false;
//        //    }

//        //    if (string.IsNullOrEmpty(CurrentZipcode) || !Utilities.ValidatePincode(CurrentZipcode))
//        //    {
//        //        Device.BeginInvokeOnMainThread(async () =>
//        //        {
//        //            await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidCurrentPincode);
//        //            CurrentZipcode = string.Empty;

//        //        });
//        //        return false;
//        //    }

//        //    if (CurrentZipcode == "000000")
//        //    {
//        //        Device.BeginInvokeOnMainThread(async () =>
//        //        {
//        //            await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidCurrentPincode);
//        //            CurrentZipcode = string.Empty;

//        //        });
//        //        return false;
//        //    }

//        //    if (string.IsNullOrEmpty(PermanentAddress) || !Utilities.Address(PermanentAddress))
//        //    {
//        //        Device.BeginInvokeOnMainThread(async () =>
//        //        {
//        //            await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterPermanentAddress);
//        //        });
//        //        return false;
//        //    }



//        //    if (string.IsNullOrEmpty(_PersonalDetails.PermanentStateID) || PermanentState == MessageStringConstants.SelectPermanentState)
//        //    {
//        //        Device.BeginInvokeOnMainThread(async () =>
//        //        {
//        //            await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectPermanentState);
//        //        }); return false;
//        //    }
//        //    if (string.IsNullOrEmpty(_PersonalDetails.PermanentCityID) || PermanentDistrict == MessageStringConstants.SelectPermanentDistrict)
//        //    {
//        //        Device.BeginInvokeOnMainThread(async () =>
//        //        {
//        //            await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectPermanentDistrict);
//        //        }); return false;
//        //    }

//        //    if (string.IsNullOrEmpty(PermanentZipcode) || !Utilities.ValidatePincode(PermanentZipcode))
//        //    {
//        //        Device.BeginInvokeOnMainThread(async () =>
//        //        {
//        //            await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidPermanentPincode);
//        //            PermanentZipcode = string.Empty;
//        //        });
//        //        return false;
//        //    }
//        //    if (PermanentZipcode == "000000")
//        //    {
//        //        Device.BeginInvokeOnMainThread(async () =>
//        //        {
//        //            await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidCurrentPincode);
//        //            CurrentZipcode = string.Empty;

//        //        });
//        //        return false;
//        //    }
//        //    if (string.IsNullOrEmpty(_PersonalDetails.prefer_location_id) || PreferredJobLocation == MessageStringConstants.SelectPreferredJobLocation)
//        //    {
//        //        Device.BeginInvokeOnMainThread(async () =>
//        //        {
//        //            await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectPreferredJobLocation);
//        //        });
//        //        return false;
//        //    }


//        //    return true;

//        //}
//        //#endregion


//        //private void NavigateToNextPageIfNeeded()
//        //{
//        //    System.Diagnostics.Debug.WriteLine("@ SeekerPersonalAndEducationPage.NavigateToNextPageIfNeeded");
//        //    if (!Convert.ToBoolean(AppPreferences.IsDashboard))
//        //    {
//        //        if (AppPreferences.IsProfileCompleted == true && AppPreferences.IsEducationCompleted == true)
//        //        {
//        //            AppPreferences.IsDashboard = true;
//        //            Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
//        //        }
//        //        else if (_isPersonalDetailsUpdated && _isEducationDetailsUpdated)
//        //        {
//        //            AppPreferences.IsDashboard = true;
//        //            SetProfileCompletedFlag();
//        //            Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
//        //        }
//        //    }
//        //}


//        //private bool _isvisibleEmptyCertificateMessage;

//        //public bool IsvisibleEmptyCertificateMessage
//        //{
//        //    get { return _isvisibleEmptyCertificateMessage; }
//        //    set { _isvisibleEmptyCertificateMessage = value; OnPropertyChanged(); }
//        //}


//        //public void SetProfileCompletedFlag()
//        //{
//        //    AppPreferences.IsProfileCompleted = true;
//        //    AppPreferences.IsEducationCompleted = true;
//        //}

//        //#region GetUserPicDetail
//        //public async Task GetUserPic(string GetUserPicDetail)
//        //{
//        //    try
//        //    {

//        //        if (string.IsNullOrEmpty(GetUserPicDetail) || GetUserPicDetail == null)
//        //        {
//        //            profilepic = (string)Application.Current.Resources["IconUser"];
//        //        }
//        //        else
//        //        {
//        //            var Imagedownloader = new S3ImageDownloder();
//        //            Imagedownloader.DownloadProfilePicture(GetUserPicDetail);
//        //        }
//        //    }
//        //    catch (Exception ex)
//        //    {
//        //        System.Diagnostics.Debug.WriteLine(ex.Message);
//        //        profilepic = (string)Application.Current.Resources["IconUser"];
//        //        SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.GetUserPicDetail");
//        //    }




//        //    //System.Diagnostics.Debug.WriteLine("@ SeekerPersonalAndEducationPage.GetUserPicDetail");
//        //    //try
//        //    //{

//        //    //    var data = new UserResourceRetrivalRequestData();

//        //    //    data.ResourceTypeId = Convert.ToInt32(Models.ResourceType.ProfilePic).ToString();
//        //    //    var statusResult = await _commonservice.PostAsync<VideoResourceRetrivalResponseData, UserResourceRetrivalRequestData>(APIData.API_BASE_URL + APIMethods.Userresourceretrival, data);
//        //    //    if (statusResult != null)
//        //    //    {
//        //    //        if (statusResult.Code == "200")
//        //    //        {

//        //    //            if (string.IsNullOrEmpty(statusResult.ProfilePicture.S3ID) || statusResult.ProfilePicture.S3ID ==null)
//        //    //            {
//        //    //                profilepic = (string)Application.Current.Resources["IconUser"];
//        //    //            }
//        //    //            else
//        //    //            {
//        //    //                var Imagedownloader = new S3ImageDownloder();
//        //    //                Imagedownloader.DownloadProfilePicture(statusResult.ProfilePicture.S3ID);


//        //    //            }
//        //    //        }
//        //    //    }
//        //    //    else
//        //    //    {
//        //    //        profilepic = (string)Application.Current.Resources["IconUser"];
//        //    //    }






//        //}
//        //#endregion



//        //#region UploadProfilePicture
//        //async public Task UploadProfilePicture()
//        //{
//        //    #region UserDialogs.ActionSheet Configurations

//        //    //var page = new PopupActionSheetPage(MessageStringConstants.SeekerPersonalPageName);
//        //    //await PopupNavigation.PushAsync(page);

//        //    ActionSheetConfig ActionSheetConfigurations = new ActionSheetConfig();
//        //    ActionSheetConfigurations.SetTitle("Profile Photo");
//        //    ActionSheetConfigurations.Add("Pick from Gallery", () =>
//        //    {
//        //        UploadProfilePicture("Pick from Gallery");
//        //    });
//        //    ActionSheetConfigurations.Add("Camera", () =>
//        //    {
//        //        UploadProfilePicture("Camera");
//        //    });
//        //    ActionSheetConfigurations.Add("Cancel", () => { });
//        //    UserDialogs.Instance.ActionSheet(ActionSheetConfigurations);
//        //    #endregion
//        //}

//        //public async void UploadProfilePicture(string action)
//        //{
//        //    MediaFile file = null;
//        //    try
//        //    {
//        //        #region Pick from Gallery
//        //        if (action == "Pick from Gallery")
//        //        {

//        //            try
//        //            {
//        //                var status = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Storage);
//        //                if (status != PermissionStatus.Granted)
//        //                {
//        //                    if (await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Storage))
//        //                    {
//        //                        await UserDialogs.Instance.AlertAsync("Access Storage", "Need Storage Permission", "OK");

//        //                    }

//        //                    var results = await CrossPermissions.Current.RequestPermissionsAsync(new[] { Permission.Storage });
//        //                    status = results[Permission.Storage];
//        //                }

//        //                if (status == PermissionStatus.Granted)
//        //                {
//        //                    await Task.Delay(1000);
//        //                    file = await CrossMedia.Current.PickPhotoAsync(new PickMediaOptions { PhotoSize = PhotoSize.Medium, });

//        //                    var memoryStream = new MemoryStream();
//        //                    await file.GetStream().CopyToAsync(memoryStream);
//        //                    byte[] imageAsByte = memoryStream.ToArray();
//        //                    await _navigationservice.PushModalAsync(new CropView(imageAsByte, Refresh));
//        //                }
//        //                else if (status != PermissionStatus.Unknown)
//        //                {
//        //                    UserDialogs.Instance.Toast(MessageStringConstants.PermissionMessage);

//        //                }
//        //            }
//        //            catch (Exception ex)
//        //            {
//        //                System.Diagnostics.Debug.WriteLine(ex.Message);
//        //                SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.UploadProfilePicture");
//        //            }
//        //        }
//        //        #endregion

//        //        #region Camera
//        //        else if (action == "Camera")
//        //        {
//        //            try
//        //            {
//        //                var status = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Camera);
//        //                if (status != PermissionStatus.Granted)
//        //                {
//        //                    if (await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Camera))
//        //                    {
//        //                        await UserDialogs.Instance.AlertAsync("Access Camera", "Need Camera Permission", "OK");
//        //                    }

//        //                    var results = await CrossPermissions.Current.RequestPermissionsAsync(new[] { Permission.Camera });
//        //                    status = results[Permission.Camera];
//        //                }

//        //                if (status == PermissionStatus.Granted)
//        //                {
//        //                    await Task.Delay(1000);
//        //                    file = await CrossMedia.Current.TakePhotoAsync(new StoreCameraMediaOptions
//        //                    {
//        //                        CompressionQuality = 90,
//        //                        AllowCropping = true,
//        //                        PhotoSize = PhotoSize.Medium,
//        //                        Directory = "HireMee",
//        //                        Name = "HireMeeProfilePic.jpg"
//        //                    });

//        //                    var memoryStream = new MemoryStream();
//        //                    await file.GetStream().CopyToAsync(memoryStream);
//        //                    byte[] imageAsByte = memoryStream.ToArray();
//        //                    await _navigationservice.PushModalAsync(new CropView(imageAsByte, Refresh));
//        //                }
//        //                else if (status != PermissionStatus.Unknown)
//        //                {
//        //                    UserDialogs.Instance.Toast(MessageStringConstants.PermissionMessage);
//        //                }
//        //            }
//        //            catch (Exception ex)
//        //            {
//        //                System.Diagnostics.Debug.WriteLine(ex.Message);
//        //                SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.UploadProfilePicture");

//        //            }

//        //        }
//        //        #endregion

//        //        #region Null Check
//        //        else
//        //        {
//        //            file = null;
//        //        }

//        //        if (file == null)
//        //        {
//        //            return;
//        //        }

//        //        #endregion

//        //        //#region S3 ImageUpload
//        //        //IsprofilepicEnable = false;
//        //        //string filename = AppSessionData.ActiveToken.HireMeID + "_" + "ProfilePic" + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".png";
//        //        //var filePath = DependencyService.Get<IImageManager>().CopyFile(file.Path, filename);
//        //        //profilepic = filePath;
//        //        //var UserProfileimageLegnth = DependencyService.Get<IImageManager>().ReadImageFile(filePath);
//        //        //var s3fileurl = await S3Manager.UploadFile(filePath, filename, AmazonS3BucketDetails.PhotoBucket);
//        //        //if (!string.IsNullOrEmpty(s3fileurl))
//        //        //{

//        //        //    var data = new UserResourceInsertRequestData();

//        //        //    data.ResourceTypeId = Convert.ToInt32(Models.ResourceType.ProfilePic).ToString();
//        //        //    data.s3Id = filename;
//        //        //    data.ResourceUrl = s3fileurl;
//        //        //    data.ThumbnailUrl = s3fileurl;

//        //        //    var statusResult = await _commonservice.PostAsync<UserResourceInsertResponseData, UserResourceInsertRequestData>(APIData.API_BASE_URL + APIMethods.UserResourceInsert, data);
//        //        //    if (statusResult != null)
//        //        //    {
//        //        //        //var storagedir = DependencyService.Get<IImageManager>().GetStorageDirectory(ResourceTypeEnums.Photos);
//        //        //        //var imagepath = Path.Combine(storagedir, filename);
//        //        //        //profilepic.Source = filePath;
//        //        //        IsprofilepicEnable = true;
//        //        //        AppPreferences.ProfilePicture = filePath;
//        //        //        MessagingCenter.Send(this, "ChangeProfilePicture", filePath);
//        //        //    }
//        //        //    else
//        //        //    {
//        //        //        IsprofilepicEnable = true;
//        //        //        await UserDialogs.Instance.AlertAsync(MessageStringConstants.UnableToUpdateProfilePicture);
//        //        //    }
//        //        //    #endregion

//        //        //}
//        //    }
//        //    catch (Exception ex)
//        //    {
//        //        System.Diagnostics.Debug.WriteLine("EXCEPTION {0}:  {1}", DateTime.Now, ex.StackTrace);
//        //        SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.UploadProfilePicture");
//        //    }
//        //    finally
//        //    {
//        //        if (file != null)
//        //        {
//        //            file.Dispose();
//        //        }
//        //    }
//        //}

//        //#region SetImageSource
//        //private async void Refresh()
//        //{
//        //    try
//        //    {

//        //        if (App.CroppedImage != null && App.CroppedImageFilePath != null)
//        //        {
//        //            //Stream stream = new MemoryStream(App.CroppedImage);
//        //            //= ImageSource.FromStream(() => stream);

//        //            #region Uploading ID Card To S3
//        //            IsprofilepicEnable = false;
//        //            string filename = AppSessionData.ActiveToken.HireMeID + "_" + "ProfilePic" + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".png";
//        //            var filePath = DependencyService.Get<IImageManager>().CopyFile(App.CroppedImageFilePath, filename);
//        //            profilepic = filePath;
//        //            var UserProfileimageLegnth = DependencyService.Get<IImageManager>().ReadImageFile(filePath);
//        //            var s3fileurl = await S3Manager.UploadFile(filePath, filename, AmazonS3BucketDetails.PhotoBucket);
//        //            if (!string.IsNullOrEmpty(s3fileurl))
//        //            {
//        //                var data = new UserResourceInsertRequestData();
//        //                data.ResourceTypeId = Convert.ToInt32(Models.ResourceType.ProfilePic).ToString();
//        //                data.s3Id = filename;
//        //                data.ResourceUrl = s3fileurl;
//        //                data.ThumbnailUrl = s3fileurl;
//        //                var result = await _commonservice.PostAsync<UserResourceInsertResponseData, UserResourceInsertRequestData>(APIData.API_BASE_URL + APIMethods.UserResourceInsert, data);

//        //                if (result != null)
//        //                {
//        //                    if (result.code == "200")
//        //                    {
//        //                        IsprofilepicEnable = true;
//        //                        AppPreferences.ProfilePicture = filePath;
//        //                        MessagingCenter.Send(this, "ChangeProfilePicture", filePath);
//        //                    }
//        //                    else
//        //                    {
//        //                        IsprofilepicEnable = true;
//        //                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.UnableToUpdateProfilePicture);
//        //                    }
//        //                }
//        //                else
//        //                {
//        //                    UserDialogs.Instance.HideLoading();
//        //                }
//        //            }
//        //        }
//        //    }
//        //    #endregion




//        //    catch (Exception ex)
//        //    {
//        //        UserDialogs.Instance.HideLoading();
//        //        SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.Refresh");
//        //    }
//        //}
//        //#endregion


//        //private bool _isprofilepicEnable;
//        //public bool IsprofilepicEnable
//        //{
//        //    get { return _isprofilepicEnable; }
//        //    set { _isprofilepicEnable = value; OnPropertyChanged(); }
//        //}
//        //#endregion

//        //#region Check Aadhar Number 
//        //public async Task<bool> CheckAadharNumber(string _AadhaarNumber)
//        //{

//        //    bool _aadharnumberExist = false;
//        //    try
//        //    {
//        //        var request = new CheckMobileNumberRequest
//        //        {
//        //            HiremeeID = AppPreferences.HireMeeID,
//        //            Token = AppPreferences.ActiveToken.Token,
//        //            AadharNumber = _AadhaarNumber
//        //        };
//        //        bool isNetworkConnection = CrossConnectivity.Current.IsConnected;
//        //        if (isNetworkConnection)
//        //        {
//        //            UserDialogs.Instance.ShowLoading();
//        //            var statusResult = await _commonservice.PostAsync<CheckMobileNumberResponse, CheckMobileNumberRequest>(APIData.API_BASE_URL + APIMethods.CheckAadharNumber, request);
//        //            UserDialogs.Instance.HideLoading();
//        //            if (statusResult != null)
//        //            {
//        //                if (statusResult.code == "203")
//        //                {
//        //                    _aadharnumberExist = true;
//        //                }
//        //            }
//        //        }
//        //        else
//        //        {
//        //            await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
//        //        }
//        //    }
//        //    catch (Exception ex)
//        //    {
//        //        UserDialogs.Instance.HideLoading();
//        //        System.Diagnostics.Debug.WriteLine(ex.Message);
//        //        SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.CheckAadharNumber");
//        //    }

//        //    return _aadharnumberExist;
//        //}
//        //#endregion

//        //#region Check Passport Number 
//        //public async Task<bool> CheckPassportNumber(string _PassPortNumber)
//        //{

//        //    bool _passportnumberExist = false;
//        //    try
//        //    {
//        //        var request = new CheckMobileNumberRequest
//        //        {
//        //            HiremeeID = AppPreferences.HireMeeID,
//        //            Token = AppPreferences.ActiveToken.Token,
//        //            PassportNumber = _PassPortNumber
//        //        };
//        //        var statusResult = await _commonservice.PostAsync<CheckMobileNumberResponse, CheckMobileNumberRequest>(APIData.API_BASE_URL + APIMethods.CheckPassportNumber, request);
//        //        if (statusResult != null)
//        //        {
//        //            if (statusResult.code == "203")
//        //            {
//        //                _passportnumberExist = true;
//        //            }
//        //        }
//        //        UserDialogs.Instance.HideLoading();
//        //    }
//        //    catch (Exception ex)
//        //    {
//        //        UserDialogs.Instance.HideLoading();
//        //        System.Diagnostics.Debug.WriteLine(ex.Message);
//        //        SendErrorMessageToServer(ex, "SeekerPersonalAndEducationViewModel.CheckPassportNumber");
//        //    }
//        //    return _passportnumberExist;

//        //}
//        //#endregion


//        //#region SendErrorMessageToServer
//        //public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
//        //{
//        //    CommonException _commonexception = new CommonException();
//        //    _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
//        //}
//        //#endregion

//    }
//}

