﻿using HireMe.Services;
using MvvmHelpers;
using ZXing.Net.Mobile.Forms;

namespace HireMe.ViewModels.JobSeeker
{
    public class QRCodeGeneratorViewModel :BaseViewModel
    {
        ZXingBarcodeImageView barcode;
        public QRCodeGeneratorViewModel()
        {
            //barcode = new ZXingBarcodeImageView
            //{
            //    HorizontalOptions = LayoutOptions.FillAndExpand,
            //    VerticalOptions = LayoutOptions.FillAndExpand,
            //    AutomationId = "zxingBarcodeImageView",
            //};
            //barcode.BarcodeFormat = ZXing.BarcodeFormat.QR_CODE;
         
            string PhotoURL = S3Manager.GeneratePreSignedURL(AmazonS3BucketDetails.PhotoBucket, AppPreferences.ProfilePicture, 10);
            BarCodeValue = AppSessionData.ActiveToken.HireMeID;// +"@@@@"+ AppPreferences.CurrentUser.FullName+"@@@@"+ PhotoURL;

        }
        private string _barCodeValue;
        public string BarCodeValue
        {
            get { return _barCodeValue; }
            set { _barCodeValue = value; OnPropertyChanged(); }
        }
       

    }
}
