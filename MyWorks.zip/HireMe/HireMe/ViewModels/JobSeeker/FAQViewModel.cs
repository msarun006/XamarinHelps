﻿using HireMe.Interface;
using MvvmHelpers;
using Acr.UserDialogs;
using Xamarin.Forms;

namespace HireMe.ViewModels.JobSeeker
{
    public class FAQViewModel:BaseViewModel
    {
        public FAQViewModel()
        {
            BindHTMLSource();
        }
        private string _SourceURL;

        public string SourceURL
        {
            get { return _SourceURL; }
            set { _SourceURL = value; OnPropertyChanged(); }
        }
        
        private void BindHTMLSource()
        {
            UserDialogs.Instance.ShowLoading();
            var source = new HtmlWebViewSource();
            source.BaseUrl = DependencyService.Get<IBaseUrl>().GetFAQ();
            SourceURL = source.BaseUrl;
            UserDialogs.Instance.HideLoading();
        }
    }
}
