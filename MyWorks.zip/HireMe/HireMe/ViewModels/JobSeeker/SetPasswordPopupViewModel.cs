﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.Models.JobSeeker;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Diagnostics;
using Xamarin.Forms;

namespace HireMe.ViewModels.JobSeeker
{
    public class SetPasswordPopupViewModel : BaseViewModel
    {
        private SetPasswordResponseData _passwordresponseData { get; set; }
        private SetPasswordRequestData _passowrdrequestData { get; set; }
        private HttpCommonService _commonservice { get; set; }

        public Command OnCommand { get; set; }
        INavigation _navigation;
        public SetPasswordPopupViewModel(INavigation nav)
        {

            _navigation = nav;
            OnCommand = new Command(DoCommand);
            _passowrdrequestData = new SetPasswordRequestData();
            _passwordresponseData = new SetPasswordResponseData();

            _commonservice = new HttpCommonService();


            IsPassword = true;
            LabelHidePassword = (string)Application.Current.Resources["HidePassword"];
            PasswordFontAwesomeFont = (string)Application.Current.Resources["PasswordSign"];
        }

        private async void DoCommand(object obj)
        {
            if (obj.ToString() == "ShowPasswordTapped")
            {
                #region ShowPasswordTapped
                if (IsPassword == true)
                {
                    LabelHidePassword = (string)Application.Current.Resources["ShowPassword"];
                    IsPassword = false;
                }
                else
                {
                    LabelHidePassword = (string)Application.Current.Resources["HidePassword"];
                    IsPassword = true;
                }
                #endregion
            }
            else if (obj.ToString() == "OnCancel")
            {
                var OnCancel = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.CancelSetPassword, null, "OK", "Cancel");
                if (OnCancel)
                {
                    await _navigation.PopAsync();
                }
            }
            else if (obj.ToString() == "OnSubmit")
            {

                DoSetPassword();
            }
        }







        private async void DoSetPassword()
        {
            #region Submit Button Click Event

            if (string.IsNullOrEmpty(InputPassword))
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterPassword);
            }
            else if (InputPassword.Length < 6)
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidLengthPassword);
            }
            else
            {
                try
                {
                    UserDialogs.Instance.ShowLoading();
                    //     bool isHostReachable = await CrossConnectivity.Current.IsRemoteReachable(APIData.HOST_REACHABLE);
                    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                    if (isNetworkAvailable)
                    {

                        //   if (isHostReachable)
                        //    {
                        string DeviceID, DeviceModel, DeviceOS;
                        DeviceID = Utilities.GetDeviceID();
                        DeviceModel = Utilities.GetDeviceModel();
                        DeviceOS = Xamarin.Forms.Device.RuntimePlatform;
                        if (!(string.IsNullOrEmpty(DeviceID)) && !(string.IsNullOrEmpty(DeviceModel)) && !(string.IsNullOrEmpty(DeviceOS) && !(string.IsNullOrEmpty(AppPreferences.UserValues.register_id.ToString()))))
                        {
                            _passowrdrequestData.udid = DeviceID;
                            _passowrdrequestData.devmodel = DeviceModel;
                            _passowrdrequestData.devos = DeviceOS;
                            _passowrdrequestData.register_id = AppPreferences.UserValues.register_id.ToString();     // Apppreference Value to be add
                        }

                        _passowrdrequestData.password = InputPassword;
                        var result = await _commonservice.PostAsync<SetPasswordResponseData, SetPasswordRequestData>(APIData.API_BASE_URL + APIMethods.SetPassword_v7, _passowrdrequestData);

                        if (result != null)
                        {
                            if (result.code == "200")
                            {
                                UserDialogs.Instance.HideLoading();
                                //await _navigation.PopAsync();
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.RegistrationSuccessMessage);
                                Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                                return;
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(result.message);
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnectionSlow);
                    }
                    //   }
                    //  else
                    //  {
                    //      UserDialogs.Instance.HideLoading();
                    //      await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                    //  }
                }
                catch (Exception ex)
                {
                    UserDialogs.Instance.HideLoading();
                    Debug.WriteLine(ex.Message);
                    SendErrorMessageToServer(ex, "SetPasswordPopupViewModel.DoSetPassword");
                }
            }
            #endregion
        }

        private string _inputPassword;

        public string InputPassword
        {
            get { return _inputPassword; }
            set { _inputPassword = value; OnPropertyChanged(); }
        }


        private string _passwordFontAwesomeFont;
        public string PasswordFontAwesomeFont
        {
            get { return _passwordFontAwesomeFont; }
            set
            {
                if (value == _passwordFontAwesomeFont) return;
                _passwordFontAwesomeFont = value;
                OnPropertyChanged();
            }
        }


        private bool _isPassword;
        public bool IsPassword
        {
            get
            {
                return _isPassword;
            }
            set
            {
                _isPassword = value;
                OnPropertyChanged();
            }
        }



        private string _labelHidePassword;
        public string LabelHidePassword
        {
            get { return _labelHidePassword; }
            set
            {
                if (value == _labelHidePassword) return;
                _labelHidePassword = value;
                OnPropertyChanged();
            }
        }

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

    }
}
