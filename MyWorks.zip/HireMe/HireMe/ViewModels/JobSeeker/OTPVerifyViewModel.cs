﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows.Input;
using Acr.UserDialogs;
using HireMe.Views.JobSeeker;
using MvvmHelpers;
using Plugin.Connectivity;
using Xamarin.Forms;
using HireMe.Models.JobSeeker;
using HireMe.Views;
using HireMe.Helpers;
using HireMe.Models;
using HireMe.UI;
using HireMe.LocalDataBase;
using HireMe.Interface;
using HireMe.Views.Assessment;

namespace HireMe.ViewModels
{
    public class OTPVerifyViewModel : BaseViewModel
    {
        INavigation nav;
     
        private HttpCommonService _httpCommonsevice { get; set; }
        public OTPVerifyRequest _OTPVerifyRequest { get; set; }

        public bool isClicked = true;

        public LocalDB _localDB { get; set; }
        public FCMHelper _FCMHelper { get; set; }
        public AddUserMobile_OTP_model _AddUserMobile_OTP_model { get; set; }
        public AddUserMobile_OTP_Response _AddUserMobile_OTP_Response { get; set; }

        public ForgotPasswordVerifyModel _ForgotPasswordVerifyModel { get; set; }
        public ForgotPasswordVerifyResponse _ForgotPasswordVerifyResponse { get; set; }
        SocialLoginRequest _socialLoginRequest { get; set; }

        public AddUserEmail_OTP_model _AddUserEmail_OTP_model { get; set; }
        public AddUserEmail_OTP_Response _AddUserEmail_OTP_Response { get; set; }


        public OTPVerifyResponse _OTPVerifyResponse { get; set; }
        public ICommand OnCommand { get; set; }

        public string passingVerification;
        public string CancelVerify;


        public OTPVerifyViewModel(INavigation objNav, string verificationClass)
        {
            //string page = Application.Current.Properties["page"].ToString();

            //if (page == "EditBasicDetails")
            //{
            //    OTP = Application.Current.Properties["mobileno"].ToString();
            //}
            //else if(AppPreferences.UserValues.otp != string.Empty)
            //{
            //    OTP = AppPreferences.UserValues.otp;
            //}

            nav = objNav;
            OnCommand = new GalaSoft.MvvmLight.Command.RelayCommand<string>(Oncheck);
            _OTPVerifyRequest = new OTPVerifyRequest();
            _OTPVerifyResponse = new OTPVerifyResponse();

            OnTextChangeValue = "Submit";
            _localDB = new LocalDB();
            _FCMHelper = new FCMHelper();
            IsPassword = true;
            StartTimer();

            _AddUserMobile_OTP_Response = new AddUserMobile_OTP_Response();
            _AddUserMobile_OTP_model = new AddUserMobile_OTP_model();

            _AddUserEmail_OTP_Response = new AddUserEmail_OTP_Response();
            _AddUserEmail_OTP_model = new AddUserEmail_OTP_model();

            _ForgotPasswordVerifyModel = new ForgotPasswordVerifyModel();
            _ForgotPasswordVerifyResponse = new ForgotPasswordVerifyResponse();
            _httpCommonsevice = new HttpCommonService();
            passingVerification = verificationClass;
            LabelHidePassword = (string)Application.Current.Resources["HidePassword"];
            PasswordFontAwesomeFont = (string)Application.Current.Resources["PasswordSign"];

            if (passingVerification.Equals("UserRegistration"))
            {
                isCheckPassword = false;
                //OTP = AppPreferences.UserValues.otp;
            }
            else if (passingVerification.Equals("ForgotMobileOTP"))
            {
                isCheckPassword = false;
                //  OTP = AppPreferences.ForgotPasswordValues.otp;
            }
            else if (passingVerification.Equals("SeekerPersonalAndEducationalDetails"))
            {
                isCheckPassword = false;
                //  OTP = AppPreferences.EmailUpdateValues.otp;

            }
            else if (passingVerification.Equals("EditBasicDetailsEmail"))
            {
                isCheckPassword = false;
                //    OTP = AppPreferences.EmailUpdateValues.otp;

            }
            else if (passingVerification.Equals("EditBasicDetailsMobileNo"))
            {
                isCheckPassword = false;
                //    OTP = AppPreferences.MobileNoUpdateValues.otp;

            }
            else if (passingVerification.Equals("SocialMedia_UserRegistration"))
            {
                isCheckPassword = false;
            }

            MessagingCenter.Subscribe<IAutoOTPReceiver, string>(this, "AutoDetectOTPValue", (sender, arg) =>
            {
                Device.BeginInvokeOnMainThread(() => { OTP = arg; });
            });

        }

        #region OnLoginPageCommands
        private async void Oncheck(string sender)
        {
            switch (sender)
            {
                #region Submit Case
                case "Submit":

                    switch (passingVerification)
                    {
                        case "UserRegistration":

                            if (isClicked)
                            {
                                isClicked = false;
                                userRegistrationMethod();
                            }
                            await Task.Run(async () =>
                            {
                                await Task.Delay(500);
                                isClicked = true;
                            });
                            break;

                        case "SocialMedia_UserRegistration":
                            if (isClicked)
                            {
                                isClicked = false;
                                SocialMedia_userRegistrationMethod();
                            }
                            await Task.Run(async () =>
                            {
                                await Task.Delay(500);
                                isClicked = true;
                            });
                            break;

                        case "ForgotMobileOTP":

                            if (isClicked)
                            {
                                isClicked = false;
                                ForgotPasswordMobile();
                            }
                            await Task.Run(async () =>
                            {
                                await Task.Delay(500);
                                isClicked = true;
                            });


                            break;

                        case "SeekerPersonalAndEducationalDetails":
                            if (isClicked)
                            {
                                isClicked = false;
                                AddUserEmail();
                            }
                            await Task.Run(async () =>
                            {
                                await Task.Delay(500);
                                isClicked = true;
                            });

                            break;

                        case "EditBasicDetailsEmail":
                            if (isClicked)
                            {
                                isClicked = false;
                                AddUserEmail();
                            }
                            await Task.Run(async () =>
                            {
                                await Task.Delay(500);
                                isClicked = true;
                            });

                            break;

                        case "EditBasicDetailsMobileNo":
                            if (isClicked)
                            {
                                isClicked = false;
                                AddUserMobileNo();
                            }
                            await Task.Run(async () =>
                            {
                                await Task.Delay(500);
                                isClicked = true;
                            });

                            break;

                    }

                    break;
                #endregion

                #region Resend Case
                case "Resend":
                    switch (passingVerification)
                    {
                        case "UserRegistration":

                            if (isClicked)
                            {
                                isClicked = false;

                                NormalRegistrationResendOTP();

                            }
                            await Task.Run(async () =>
                            {
                                await Task.Delay(500);
                                isClicked = true;
                            });

                            break;
                        case "SocialMedia_UserRegistration":
                            if (isClicked)
                            {
                                isClicked = false;
                                if (AppPreferences.IsFBLoggeedIn == true)
                                {
                                    if (AppPreferences.FacebookUserDetails != null)
                                    {
                                        FBResendOTP();
                                    }
                                }
                                else if (AppPreferences.IsGoogleLoggedIn == true)
                                {

                                    if (AppPreferences.GoogleUserDetails != null)
                                    {
                                        GoogleResendOTP();
                                    }
                                }
                            }
                            else
                            {

                            }
                            await Task.Run(async () =>
                            {
                                await Task.Delay(500);
                                isClicked = true;
                            });
                            break;

                        case "ForgotMobileOTP":

                            if (isClicked)
                            {
                                isClicked = false;
                                FrogotMobileNumberResendOTP();
                            }
                            await Task.Run(async () =>
                            {
                                await Task.Delay(500);
                                isClicked = true;
                            });
                            break;

                        case "SeekerPersonalAndEducationalDetails":
                            if (isClicked)
                            {
                                isClicked = false;

                            }
                            await Task.Run(async () =>
                            {
                                await Task.Delay(500);
                                isClicked = true;
                            });

                            break;

                        case "EditBasicDetailsEmail":
                            if (isClicked)
                            {
                                isClicked = false;
                                ResendOTPForBasicDetailsEmailID();

                            }
                            await Task.Run(async () =>
                            {
                                await Task.Delay(500);
                                isClicked = true;
                            });

                            break;

                        case "EditBasicDetailsMobileNo":
                            if (isClicked)
                            {
                                isClicked = false;
                                MobileNumberResendOTPForEditBasicDetails();
                            }
                            await Task.Run(async () =>
                            {
                                await Task.Delay(500);
                                isClicked = true;
                            });
                            break;

                    }
                    break;
                #endregion

                case "ShowPasswordTapped":

                    #region ShowPasswordTapped
                    if (IsPassword == true)
                    {
                        LabelHidePassword = (string)Application.Current.Resources["ShowPassword"];
                        IsPassword = false;
                    }
                    else
                    {
                        LabelHidePassword = (string)Application.Current.Resources["HidePassword"];
                        IsPassword = true;
                    }
                    #endregion

                    break;

                case "DoCancel":
                    switch (passingVerification)
                    {
                        case "UserRegistration":

                            var res = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.CancelOTP, null, "OK", "Cancel");
                            if (res)
                            {
                                StopTimer();
                                await nav.PopAsync();
                            }

                            break;

                        case "SocialMedia_UserRegistration":

                            var result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.CancelOTP, null, "OK", "Cancel");
                            if (result)
                            {
                                StopTimer();
                                await nav.PopAsync();
                            }

                            break;
                        case "ForgotMobileOTP":

                            var resForgotMobileOTP = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.CancelOTP, null, "OK", "Cancel");
                            if (resForgotMobileOTP)
                            {
                                StopTimer();
                                await nav.PopAsync();
                            }
                            break;

                        case "SeekerPersonalAndEducationalDetails":

                            var SeekerPersonalAndEducationalDetails = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.CancelOTP, null, "OK", "Cancel");
                            if (SeekerPersonalAndEducationalDetails)
                            {
                                StopTimer();
                                AppPreferences.IsVerifyEmail = false;
                                MessagingCenter.Send(this, "UpdateBasicDetails", "EmailNotVerified");
                                await nav.PopAsync();
                            }

                            break;

                        case "EditBasicDetailsEmail":

                            var EditBasicDetailsEmail = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.CancelOTP, null, "OK", "Cancel");
                            if (EditBasicDetailsEmail)
                            {
                                StopTimer();
                                await nav.PopAsync();
                            }
                            break;

                        case "EditBasicDetailsMobileNo":

                            var EditBasicDetailsMobileNo = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.CancelOTP, null, "OK", "Cancel");
                            if (EditBasicDetailsMobileNo)
                            {
                                StopTimer();
                                AppPreferences.IsVerifyMobileNo = false;
                                MessagingCenter.Send(this, "UpdateBasicDetails", "MobileNumberNotVerified");
                                await nav.PopAsync();
                            }

                            break;
                    }

                    IsEmailVerified = false;
                    IsMobileNoVerified = false;

                    break;

            }

        }

        private async void SocialMedia_userRegistrationMethod()
        {
            if (string.IsNullOrEmpty(OTP))
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.NullOTP);
            }
            else if (OTP.Length < 9) //&& (OTP != AppPreferences.UserValues.otp)
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.InvalidOTP);
            }
            else
            {
                try
                {
                    UserDialogs.Instance.ShowLoading();
                    //  bool isHostReachable = await CrossConnectivity.Current.IsRemoteReachable(APIData.HOST_REACHABLE);
                    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                    if (isNetworkAvailable)
                    {
                        string DeviceID, DeviceModel, DeviceOS;
                        DeviceID = Utilities.GetDeviceID();
                        DeviceModel = Utilities.GetDeviceModel();
                        DeviceOS = Xamarin.Forms.Device.RuntimePlatform;
                        if (!(string.IsNullOrEmpty(DeviceID)) && !(string.IsNullOrEmpty(DeviceModel)) && !(string.IsNullOrEmpty(DeviceOS) && !(string.IsNullOrEmpty(AppPreferences.UserValues.register_id.ToString()))))
                        {
                            if (AppPreferences.IsFBLoggeedIn == true && (AppPreferences.UserValues) != null)
                            {
                                _OTPVerifyRequest.register_id = AppPreferences.UserValues.register_id.ToString(); // Apppreference Value to be add
                                _OTPVerifyRequest.otp = OTP;
                                _OTPVerifyRequest.social = "true";
                                _OTPVerifyRequest.udid = DeviceID;
                                _OTPVerifyRequest.devos = DeviceOS;
                                _OTPVerifyRequest.devmodel = DeviceModel;
                                _OTPVerifyRequest.password = AppPreferences.FacebookUserDetails.id;
                            }
                            else if (AppPreferences.IsGoogleLoggedIn == true && (AppPreferences.UserValues) != null)
                            {
                                _OTPVerifyRequest.register_id = AppPreferences.UserValues.register_id.ToString(); // Apppreference Value to be add
                                _OTPVerifyRequest.otp = OTP;
                                _OTPVerifyRequest.social = "true";
                                _OTPVerifyRequest.udid = DeviceID;
                                _OTPVerifyRequest.devos = DeviceOS;
                                _OTPVerifyRequest.devmodel = DeviceModel;
                                _OTPVerifyRequest.password = AppPreferences.GoogleUserDetails.ID;
                            }
                            else if (AppPreferences.IsLinkedInLoggedIn == true && (AppPreferences.UserValues) != null)
                            {
                                _OTPVerifyRequest.register_id = AppPreferences.UserValues.register_id.ToString(); // Apppreference Value to be add
                                _OTPVerifyRequest.otp = OTP;
                                _OTPVerifyRequest.social = "true";
                                _OTPVerifyRequest.udid = DeviceID;
                                _OTPVerifyRequest.devos = DeviceOS;
                                _OTPVerifyRequest.devmodel = DeviceModel;
                                _OTPVerifyRequest.password = AppPreferences.LinkedInUserDetails.id;
                            }
                        }
                        var statusResult = await _httpCommonsevice.PostAsync<OTPVerifyResponse, OTPVerifyRequest>(APIData.API_BASE_URL + APIMethods.SocialOTPVerify_V9, _OTPVerifyRequest);

                        if (statusResult != null)
                        {
                            if (statusResult.code == "200")
                            {
                                Xamarin.Forms.Device.BeginInvokeOnMainThread(() =>
                                {
                                    StopTimer();
                                    Task.Delay(1000);
                                });
                                if (AppPreferences.IsFBLoggeedIn == true)
                                {
                                    if (AppPreferences.FacebookUserDetails != null)
                                    {
                                        UserDialogs.Instance.HideLoading();
                                        SocialFBLoginAPI();

                                    }
                                }
                                else if (AppPreferences.IsGoogleLoggedIn == true)
                                {
                                    if (AppPreferences.GoogleUserDetails != null)
                                    {
                                        UserDialogs.Instance.HideLoading();
                                        SocialGoogleLoginAPI();


                                    }
                                }
                                else if (AppPreferences.IsLinkedInLoggedIn == true)
                                {
                                    if (AppPreferences.LinkedInUserDetails != null)
                                    {
                                        UserDialogs.Instance.HideLoading();
                                        SocialLinkedInLoginAPI();
                                    }
                                }
                            }
                            else
                            {
                                //StopTimer();
                                //AppPreferences.IsFBLoggeedIn = false;
                                //AppPreferences.IsGoogleLoggedIn = false;
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(statusResult.message);
                            }
                        }
                    }
                    else
                    {
                        //StopTimer();
                        AppPreferences.IsFBLoggeedIn = false;
                        AppPreferences.IsGoogleLoggedIn = false;
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                    }
                }
                catch (Exception ex)
                {
                    StopTimer();
                    AppPreferences.IsFBLoggeedIn = false;
                    AppPreferences.IsGoogleLoggedIn = false;
                    UserDialogs.Instance.HideLoading();
                    Debug.WriteLine(ex.Message);
                    SendErrorMessageToServer(ex, "OTPVerifyViewModel.Social_userRegistrationMethod");
                }
            }
        }

        #region Resend OTP From Forgot Mobile Number
        private async void FrogotMobileNumberResendOTP()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                //     bool isHostReachable = await CrossConnectivity.Current.IsRemoteReachable(APIData.HOST_REACHABLE);
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {
                    //      if (isHostReachable)
                    //     {
                    ForgotPasswordRequestData ForgotPasswordRequestData = new ForgotPasswordRequestData()
                    {
                        key_param = AppPreferences.MobileNumber,
                        type = 7
                    };
                    var result = await _httpCommonsevice.PostAsync<ForgotPasswordFullResponse, ForgotPasswordRequestData>(APIData.API_BASE_URL + APIMethods.ForgotPassword_V7, ForgotPasswordRequestData);
                    if (result != null)
                    {

                        if (result.code == "200")
                        {
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(result.message);
                            OnTextChangeValue = "Submit";
                            StartTimer();
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(result.message);
                        }
                        //    }
                        //   else
                        //  {
                        //      UserDialogs.Instance.HideLoading();
                        //     await UserDialogs.Instance.AlertAsync("Internet Connection Slow");

                        //   }
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync("Check Internet Connection");

                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "OTPVerifyViewModel.FrogotMobileNumberResendOTP");
                //await UserDialogs.Instance.AlertAsync(ex.Message);

            }
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        #region Google OTP Resend
        private async void GoogleResendOTP()
        {

            try
            {
                UserDialogs.Instance.ShowLoading();
                SocialRegisterRequestData _socialRegisterRequesData = new SocialRegisterRequestData();

                _socialRegisterRequesData.social_id = AppPreferences.GoogleUserDetails.ID;
                _socialRegisterRequesData.social_type = "Google";
                _socialRegisterRequesData.email_address = AppPreferences.GoogleUserDetails.Email;
                if (!string.IsNullOrEmpty(AppPreferences.GoogleUserDetails.Name))
                {
                    _socialRegisterRequesData.name = AppPreferences.GoogleUserDetails.Name;
                }
                else
                {
                    _socialRegisterRequesData.name = AppPreferences.userName;
                }
                _socialRegisterRequesData.mobile_number = AppPreferences.MobileNumber;

                var statusResult = await _httpCommonsevice.PostAsync<UserResponse, SocialRegisterRequestData>(APIData.API_BASE_URL + APIMethods.SocialRegister_v7, _socialRegisterRequesData);
                if (statusResult != null)
                {
                    if (statusResult.code == "200")
                    {
                        UserDialogs.Instance.HideLoading();
                        AppPreferences.IsGoogleLoggedIn = false;
                        AppPreferences.UserValues = statusResult.responseText;
                        OnTextChangeValue = "Submit";
                        StartTimer();
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(statusResult.message);
                    }
                }
                else
                {

                    UserDialogs.Instance.HideLoading();
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "OTPVerifyViewModel.GoogleResendOTP");
            }
        }
        #endregion

        #region FB OTP Resend
        private async void FBResendOTP()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                SocialRegisterRequestData _socialRegisterRequesData = new SocialRegisterRequestData()
                {
                    social_id = AppPreferences.FacebookUserDetails.id,
                    social_type = "Facebook",
                    email_address = AppPreferences.FacebookUserDetails.email,
                    name = AppPreferences.userName,
                    mobile_number = AppPreferences.MobileNumber
                };
                var statusResult = await _httpCommonsevice.PostAsync<UserResponse, SocialRegisterRequestData>(APIData.API_BASE_URL + APIMethods.SocialRegister_v7, _socialRegisterRequesData);
                if (statusResult != null)
                {

                    if (statusResult.code == "200")
                    {
                        UserDialogs.Instance.HideLoading();
                        AppPreferences.UserValues = statusResult.responseText;
                        OnTextChangeValue = "Submit";
                        StartTimer();
                    }
                    else
                    {
                        AppPreferences.IsFBLoggeedIn = false;
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(statusResult.message);
                    }
                }
                else
                {
                    AppPreferences.IsFBLoggeedIn = false;
                    UserDialogs.Instance.HideLoading();
                }
            }
            catch (Exception ex)
            {
                AppPreferences.IsFBLoggeedIn = false;
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "OTPVerifyViewModel.FBResendOTP");
            }
        }
        #endregion

        #region Normal Registration OTP Resend
        private async void NormalRegistrationResendOTP()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                UserRegistration_mobile_Model _RegistrationMobileRequestData = new UserRegistration_mobile_Model()
                {
                    name = AppPreferences.userName,
                    email_address = AppPreferences.UserValues.email_address,
                    mobile_number = AppPreferences.UserValues.mobile_number
                };
                var statusResult = await _httpCommonsevice.PostAsync<UserResponse, UserRegistration_mobile_Model>(APIData.API_BASE_URL + APIMethods.RegisterNewUser, _RegistrationMobileRequestData);
                if (statusResult != null)
                {
                    UserDialogs.Instance.HideLoading();
                    if (statusResult.code == "200")
                    {
                        UserDialogs.Instance.HideLoading();
                        AppPreferences.UserValues = statusResult.responseText;
                        OnTextChangeValue = "Submit";
                        StartTimer();
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(statusResult.message);
                    }
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                await UserDialogs.Instance.AlertAsync(ex.Message);
                SendErrorMessageToServer(ex, "OTPVerifyViewModel.NormalRegistrationResendOTP");
            }
        }
        #endregion

        #region Mobile Number OTP Resend From Basic Info Edit Details
        private async void MobileNumberResendOTPForEditBasicDetails()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                // bool isHostReachable = await CrossConnectivity.Current.IsRemoteReachable(APIData.HOST_REACHABLE);
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {
                    //  if (isHostReachable)
                    //   {
                    UserMobileNoUpdateModel _UserMobileNoUpdateModel = new UserMobileNoUpdateModel()
                    {
                        mobile_number = AppPreferences.MobileNumber,
                        hiremee_id = AppSessionData.ActiveToken.HireMeID,
                        token = AppSessionData.ActiveToken.Token
                    };
                    var result = await _httpCommonsevice.PostAsync<UserMobileNoUpdateResponse, UserMobileNoUpdateModel>(APIData.API_BASE_URL + APIMethods.Email_Mobile_Change_OTP_v7, _UserMobileNoUpdateModel);
                    if (result != null)
                    {
                        if (result.code == "200")
                        {
                            UserDialogs.Instance.HideLoading();
                            AppPreferences.MobileNoUpdateValues = result.responseText;
                            OnTextChangeValue = "Submit";
                            StartTimer();
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(result.message);
                        }

                    }
                    //}

                    //else
                    //{
                    //    UserDialogs.Instance.HideLoading();
                    //    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnectionSlow);
                    //}
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "OTPVerifyViewModel.MobileNumberResendOTPForEditBasicDetails");
            }
        }
        #endregion

        #region Email Address Resend OTP from Basic info Edit Details
        private async void ResendOTPForBasicDetailsEmailID()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                //    bool isHostReachable = await CrossConnectivity.Current.IsRemoteReachable(APIData.HOST_REACHABLE);
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {
                    // if (isHostReachable)
                    // {
                    UserEmailUpdateModel _UserEmailUpdateModel = new UserEmailUpdateModel()
                    {
                        email_address = AppPreferences.EmailAddress,
                        hiremee_id = AppSessionData.ActiveToken.HireMeID,
                        token = AppSessionData.ActiveToken.Token
                    };
                    var result = await _httpCommonsevice.PostAsync<UserEmailUpdateResponse, UserEmailUpdateModel>(APIData.API_BASE_URL + APIMethods.Email_Mobile_Change_OTP_v7, _UserEmailUpdateModel);
                    if (result != null)
                    {
                        if (result.code == "200")
                        {
                            UserDialogs.Instance.HideLoading();
                            AppPreferences.EmailUpdateValues = result.responseText;
                            OnTextChangeValue = "Submit";
                            StartTimer();
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(result.message);
                        }
                    }
                    //}
                    //else
                    //{
                    //    UserDialogs.Instance.HideLoading();
                    //    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnectionSlow);
                    //}
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "OTPVerifyViewModel.ResendOTPForBasicDetailsEmailID");

            }
        }
        #endregion

        private async void AddUserMobileNo()
        {
            if (string.IsNullOrEmpty(OTP))
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.NullOTP);
            }
            else if (OTP.Length < 9) //&& (OTP != AppPreferences.MobileNoUpdateValues.otp)
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.InvalidOTP);
            }
            else
            {
                try
                {

                    UserDialogs.Instance.ShowLoading();
                    //  bool isHostReachable = await CrossConnectivity.Current.IsRemoteReachable(APIData.HOST_REACHABLE);
                    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                    if (isNetworkAvailable)
                    {
                        //  if (isHostReachable)
                        //  {
                        if (AppPreferences.MobileNoUpdateValues != null && AppSessionData.ActiveToken != null)
                        {
                            _AddUserMobile_OTP_model.otp = OTP;
                            _AddUserMobile_OTP_model.register_id = AppPreferences.MobileNoUpdateValues.register_id.ToString();
                            _AddUserMobile_OTP_model.hiremee_id = AppSessionData.ActiveToken.HireMeID;
                            _AddUserMobile_OTP_model.token = AppSessionData.ActiveToken.Token;
                            if (AppPreferences.MobileNoUpdateValues.mobile_number == null)
                            {
                                _AddUserMobile_OTP_model.mobile_number = string.Empty;
                            }
                            else
                            {
                                _AddUserMobile_OTP_model.mobile_number = AppPreferences.MobileNoUpdateValues.mobile_number;
                            }
                            _AddUserMobile_OTP_model.email_address = string.Empty;
                            //_AddUserEmail_OTP_model.type = 0;
                        }


                        //Todo BaseURL Change
                        var statusResult = await _httpCommonsevice.PostAsync<AddUserMobile_OTP_Response, AddUserMobile_OTP_model>(APIData.API_BASE_URL + APIMethods.UpdateEmail_OTP_V7, _AddUserMobile_OTP_model);

                        if (statusResult != null)
                        {
                            if (statusResult.code == "200")
                            {
                                MessagingCenter.Send(this, "UpdateBasicDetails", "MobileNumberVerified");

                                Xamarin.Forms.Device.BeginInvokeOnMainThread(() =>
                                {
                                    StopTimer();
                                    Task.Delay(1000);
                                });
                                UserDialogs.Instance.HideLoading();
                             //   await UserDialogs.Instance.AlertAsync(statusResult.message);
                                
                                string values = AppPreferences.MobileNoUpdateValues.mobile_number;
                                MessagingCenter.Send(this, "UpdateMobileNumber", values);
                                AppPreferences.IsVerifyMobileNo = true;
                                await nav.PopAsync();
                            }
                            else
                            {
                                //StopTimer();
                                UserDialogs.Instance.HideLoading();
                                MessagingCenter.Send(this, "UpdateBasicDetails", "MobileNumberNotVerified");
                                await UserDialogs.Instance.AlertAsync(statusResult.message);
                            }
                        }
                        //}
                        //else
                        //{
                        //    //StopTimer();
                        //    UserDialogs.Instance.HideLoading();
                        //    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnectionSlow);
                        //}
                    }
                    else
                    {
                        //StopTimer();
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                    }
                }
                catch (Exception ex)
                {
                    StopTimer();
                    UserDialogs.Instance.HideLoading();
                    Debug.WriteLine(ex.Message);
                    SendErrorMessageToServer(ex, "OTPVerifyViewModel.AddUserMobileNo");
                }

            }
        }

        public string SocialName { get; set; }

        public async void SocialFBLoginAPI()
        {
            try
            {

                UserDialogs.Instance.ShowLoading();
                _socialLoginRequest = new SocialLoginRequest();
                SocialName = string.Empty;
                #region  Social Account Login
                string DeviceID, DeviceModel, DeviceOS;
                DeviceID = Utilities.GetDeviceID();
                DeviceModel = Utilities.GetDeviceModel();
                DeviceOS = Xamarin.Forms.Device.RuntimePlatform;
                if (!(string.IsNullOrEmpty(DeviceID)) && !(string.IsNullOrEmpty(DeviceModel)) && !(string.IsNullOrEmpty(DeviceOS) && !(string.IsNullOrEmpty(AppPreferences.UserValues.register_id.ToString()))))
                {
                    _socialLoginRequest.DeviceID = DeviceID;
                    _socialLoginRequest.DeviceModel = DeviceModel;
                    _socialLoginRequest.DeviceOS = DeviceOS;
                }
                string FacebookFullName = AppPreferences.FacebookUserDetails.first_name + " " + AppPreferences.FacebookUserDetails.last_name;
                SocialName = FacebookFullName;
                _socialLoginRequest.SocialID = AppPreferences.FacebookUserDetails.id;
                _socialLoginRequest.emailAddress = AppPreferences.FacebookUserDetails.email;
                _socialLoginRequest.ProviderType = "Facebook";

                var result = await _httpCommonsevice.PostAsync<LoginResponseData, SocialLoginRequest>(APIData.API_BASE_URL + APIMethods.SocialLogin_v7, _socialLoginRequest);
                if (result != null)
                {
                    if (result.code == "200")
                    {
                        AppPreferences.IsFBLoggeedIn = false;
                        NavigateToPage(result);
                        //if (SocialName == null && string.IsNullOrEmpty(SocialName))
                        //{
                        //    SocialName = "";
                        //}

                        //var token = new ApplicationToken()
                        //{
                        //    Token = result.Token,
                        //    HireMeID = result.HireMeID,
                        //    Expire = DateTime.Now.AddSeconds(Convert.ToDouble(result.Expire)),
                        //    RefreshToken = result.Refreshtoken,
                        //    UserType = result.UserType,
                        //    EmailID = result.EmailAddress,
                        //    MobileNo = result.MobileNo,
                        //    SocialLoginPasswordStatus = result.SocialLoginPasswordStatus,
                        //    UserName = SocialName.ToLower()
                        //};


                        //if (AppSessionData.ActiveToken != null || AppPreferences.IsFirstRun == false)
                        //{
                        //    if (_localDB.TableExists("AssignedExamModel"))
                        //    {
                        //        SqliteOperations sqliteOperations = new SqliteOperations();
                        //        var res = _localDB.GetAllAssignedExamData();
                        //        var dataIsSyncup = sqliteOperations.CheckIfAnySyncupDataIsAvailable();
                        //        //User already login, User is Proctored Candidate
                        //        if (res != null)
                        //        {
                        //            if (res.Status == "C" && dataIsSyncup == true)
                        //            {
                        //                UserDialogs.Instance.HideLoading();
                        //                Application.Current.MainPage = new NavigationPage(new ManualDataSyncupPage());
                        //                return;
                        //            }
                        //            else if (AppSessionData.ActiveToken.HireMeID != token.HireMeID)
                        //            {


                        //                //Need to check is all record sync with server
                        //                if (dataIsSyncup)
                        //                {
                        //                    UserDialogs.Instance.HideLoading();
                        //                    Application.Current.MainPage = new NavigationPage(new ManualDataSyncupPage());
                        //                    return;
                        //                }
                        //            }
                        //        }
                        //    }

                        //    if (AppSessionData.ActiveToken.HireMeID != token.HireMeID)
                        //    {
                        //        ClearAppPreferences();
                        //    }
                        //}
                        //AppSessionData.ActiveToken = token;
                        //await _FCMHelper.RegisterFirebaseToken();
                        //UserDialogs.Instance.HideLoading();
                        //AppPreferences.IsLoggeedIn = true;
                        //AppPreferences.IsvalidURI = APIData.API_BASE_URL;
                        //if (AppSessionData.ActiveToken.UserType == UserType.Recruiter)
                        //{
                        //    AppPreferences.IsFirstRun = false;
                        //    AppPreferences.IsCollege = false;
                        //    Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                        //}
                        //else if (AppSessionData.ActiveToken.UserType == UserType.College)
                        //{
                        //    AppPreferences.IsFirstRun = false;
                        //    AppPreferences.IsCollege = true;
                        //    Application.Current.MainPage = new NavigationPage(new CollegeDashboardPage());
                        //}
                        //else
                        //{
                        //    AppPreferences.IsProfileCompleted = false;
                        //    AppPreferences.IsVideosUploaded = false;
                        //    AppPreferences.IsEducationCompleted = false;
                        //    AppPreferences.IsCollege = false;
                        //    //if (result.ProfileWeightage.PersonalDetails == null && result.ProfileWeightage.EducationalDetails == null && result.ProfileWeightage.Video == null && result.ProfileWeightage.ProfilePicture == null)
                        //    //{
                        //    if (result.ProfileWeightage == null)
                        //    {
                        //        Application.Current.MainPage = new NavigationPage(new SeekerInstructionPage());
                        //    }
                        //    else
                        //    {
                        //        if (result.ProfileWeightage.PersonalDetails == null)
                        //        {

                        //            AppPreferences.IsProfileCompleted = false;
                        //            AppPreferences.IsVideosUploaded = false;
                        //            AppPreferences.IsEducationCompleted = false;
                        //            AppPreferences.IsFirstRun = false;

                        //            Application.Current.MainPage = new NavigationPage(new SeekerPersonalAndEducationPage(false));
                        //        }
                        //        else if (result.ProfileWeightage.EducationalDetails == null)
                        //        {
                        //            AppPreferences.IsEducationCompleted = false;
                        //            AppPreferences.IsProfileCompleted = true;
                        //            AppPreferences.IsVideosUploaded = false;
                        //            AppPreferences.IsFirstRun = false;
                        //            Application.Current.MainPage = new NavigationPage(new SeekerPersonalAndEducationPage(true));
                        //        }
                        //        else if (result.ProfileWeightage.Video == null)
                        //        {
                        //            AppPreferences.IsEducationCompleted = true;
                        //            AppPreferences.IsProfileCompleted = true;
                        //            AppPreferences.IsVideosUploaded = false;
                        //            AppPreferences.IsFirstRun = false;
                        //            //Application.Current.MainPage = new NavigationPage(new VideoProfilePage(true));
                        //            Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                        //        }
                        //        else
                        //        {
                        //            AppPreferences.IsEducationCompleted = true;
                        //            AppPreferences.IsVideosUploaded = true;
                        //            AppPreferences.IsProfileCompleted = true;
                        //            AppPreferences.IsDashboard = true;
                        //            AppPreferences.IsFirstRun = false;
                        //            Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);

                        //        }
                        //    }
                        //}
                    }
                    else
                    {
                        AppPreferences.IsFBLoggeedIn = true;
                        UserDialogs.Instance.HideLoading();
                        Application.Current.MainPage = new UserRegistration_mobile();
                        return;
                    }
                }
                else
                {

                    UserDialogs.Instance.Alert(MessageStringConstants.ServerBusyMessage);
                    AppPreferences.IsFBLoggeedIn = false;
                    UserDialogs.Instance.HideLoading();
                }


                #endregion
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.Alert(MessageStringConstants.ServerBusyMessage);
                AppPreferences.IsFBLoggeedIn = false;
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
            }
        }

        #region NavigateToPage
        public void NavigateToPage(LoginResponseData result)
        {
            CommonLoginResponse _commonLoginResponse = new CommonLoginResponse();
            _commonLoginResponse.NavigateToNextPage(result);
        }
        #endregion

        public async void SocialGoogleLoginAPI()
        {
            try
            {

                _socialLoginRequest = new SocialLoginRequest();
                UserDialogs.Instance.ShowLoading();
                #region  Google Login
                string DeviceID, DeviceModel, DeviceOS;
                DeviceID = Utilities.GetDeviceID();
                DeviceModel = Utilities.GetDeviceModel();
                DeviceOS = Xamarin.Forms.Device.RuntimePlatform;
                if (!(string.IsNullOrEmpty(DeviceID)) && !(string.IsNullOrEmpty(DeviceModel)) && !(string.IsNullOrEmpty(DeviceOS) && !(string.IsNullOrEmpty(AppPreferences.UserValues.register_id.ToString()))))
                {
                    _socialLoginRequest.DeviceID = DeviceID;
                    _socialLoginRequest.DeviceModel = DeviceModel;
                    _socialLoginRequest.DeviceOS = DeviceOS;
                }
                SocialName = AppPreferences.GoogleUserDetails.Name;
                _socialLoginRequest.SocialID = AppPreferences.GoogleUserDetails.ID;
                _socialLoginRequest.ProviderType = "Google";
                _socialLoginRequest.emailAddress = AppPreferences.GoogleUserDetails.Email;



                var result = await _httpCommonsevice.PostAsync<LoginResponseData, SocialLoginRequest>(APIData.API_BASE_URL + APIMethods.SocialLogin_v7, _socialLoginRequest);
                if (result != null)
                {
                    if (result.code == "200")
                    {
                        AppPreferences.IsGoogleLoggedIn = false;
                        NavigateToPage(result);
                        //if (SocialName == null && string.IsNullOrEmpty(SocialName))
                        //{
                        //    SocialName = "";
                        //}

                        //var token = new ApplicationToken()
                        //{
                        //    Token = result.Token,
                        //    HireMeID = result.HireMeID,
                        //    Expire = DateTime.Now.AddSeconds(Convert.ToDouble(result.Expire)),
                        //    RefreshToken = result.Refreshtoken,
                        //    UserType = result.UserType,
                        //    EmailID = result.EmailAddress,
                        //    MobileNo = result.MobileNo,
                        //    SocialLoginPasswordStatus = result.SocialLoginPasswordStatus,
                        //    UserName = SocialName.ToLower()
                        //};


                        //if (AppSessionData.ActiveToken != null || AppPreferences.IsFirstRun == false)
                        //{
                        //    if (_localDB.TableExists("AssignedExamModel"))
                        //    {
                        //        SqliteOperations sqliteOperations = new SqliteOperations();
                        //        var res = _localDB.GetAllAssignedExamData();
                        //        var dataIsSyncup = sqliteOperations.CheckIfAnySyncupDataIsAvailable();
                        //        //User already login, User is Proctored Candidate
                        //        if (res != null)
                        //        {
                        //            if (res.Status == "C" && dataIsSyncup == true)
                        //            {
                        //                UserDialogs.Instance.HideLoading();
                        //                Application.Current.MainPage = new NavigationPage(new ManualDataSyncupPage());
                        //                return;
                        //            }
                        //            else if (AppSessionData.ActiveToken.HireMeID != token.HireMeID)
                        //            {


                        //                //Need to check is all record sync with server
                        //                if (dataIsSyncup)
                        //                {
                        //                    UserDialogs.Instance.HideLoading();
                        //                    Application.Current.MainPage = new NavigationPage(new ManualDataSyncupPage());
                        //                    return;
                        //                }
                        //            }
                        //        }
                        //    }

                        //    if (AppSessionData.ActiveToken.HireMeID != token.HireMeID)
                        //    {
                        //        ClearAppPreferences();
                        //    }
                        //}

                        ////AppSessionData.ActiveToken.HireMeID = result.HireMeID;
                        ////AppSessionData.ActiveToken.Token = result.Token;
                        ////AppSessionData.ActiveToken.EmailID = result.EmailAddress;


                        //AppSessionData.ActiveToken = token;
                        //await _FCMHelper.RegisterFirebaseToken();
                        //UserDialogs.Instance.HideLoading();
                        //AppPreferences.IsLoggeedIn = true;
                        //AppPreferences.IsvalidURI = APIData.API_BASE_URL;
                        //if (AppSessionData.ActiveToken.UserType == UserType.Recruiter)
                        //{
                        //    AppPreferences.IsFirstRun = false;
                        //    AppPreferences.IsCollege = false;
                        //    Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                        //}
                        //else if (AppSessionData.ActiveToken.UserType == UserType.College)
                        //{
                        //    AppPreferences.IsFirstRun = false;
                        //    AppPreferences.IsCollege = true;
                        //    Application.Current.MainPage = new NavigationPage(new CollegeDashboardPage());
                        //}
                        //else
                        //{
                        //    AppPreferences.IsProfileCompleted = false;
                        //    AppPreferences.IsVideosUploaded = false;
                        //    AppPreferences.IsEducationCompleted = false;
                        //    AppPreferences.IsCollege = false;
                        //    //if (result.ProfileWeightage.PersonalDetails == null && result.ProfileWeightage.EducationalDetails == null && result.ProfileWeightage.Video == null && result.ProfileWeightage.ProfilePicture == null)
                        //    //{
                        //    if (result.ProfileWeightage == null)
                        //    {
                        //        Application.Current.MainPage = new NavigationPage(new SeekerInstructionPage());
                        //    }
                        //    else
                        //    {
                        //        if (result.ProfileWeightage.PersonalDetails == null)
                        //        {

                        //            AppPreferences.IsProfileCompleted = false;
                        //            AppPreferences.IsVideosUploaded = false;
                        //            AppPreferences.IsEducationCompleted = false;
                        //            AppPreferences.IsFirstRun = false;

                        //            Application.Current.MainPage = new NavigationPage(new SeekerPersonalAndEducationPage(false));
                        //        }
                        //        else if (result.ProfileWeightage.EducationalDetails == null)
                        //        {
                        //            AppPreferences.IsEducationCompleted = false;
                        //            AppPreferences.IsProfileCompleted = true;
                        //            AppPreferences.IsVideosUploaded = false;
                        //            AppPreferences.IsFirstRun = false;
                        //            Application.Current.MainPage = new NavigationPage(new SeekerPersonalAndEducationPage(true));
                        //        }
                        //        else if (result.ProfileWeightage.Video == null)
                        //        {
                        //            AppPreferences.IsEducationCompleted = true;
                        //            AppPreferences.IsProfileCompleted = true;
                        //            AppPreferences.IsVideosUploaded = false;
                        //            AppPreferences.IsFirstRun = false;
                        //            //Application.Current.MainPage = new NavigationPage(new VideoProfilePage(true));
                        //            Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                        //        }
                        //        else
                        //        {
                        //            AppPreferences.IsEducationCompleted = true;
                        //            AppPreferences.IsVideosUploaded = true;
                        //            AppPreferences.IsProfileCompleted = true;
                        //            AppPreferences.IsDashboard = true;
                        //            AppPreferences.IsFirstRun = false;
                        //            Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);

                        //        }
                        //    }
                        //}
                    }
                    else
                    {
                        AppPreferences.IsGoogleLoggedIn = true;
                        UserDialogs.Instance.HideLoading();
                        Application.Current.MainPage = new UserRegistration_mobile();
                        return;
                    }
                }
                else
                {
                    UserDialogs.Instance.Alert(MessageStringConstants.ServerBusyMessage);
                    UserDialogs.Instance.HideLoading();
                    AppPreferences.IsGoogleLoggedIn = false;
                }


                #endregion
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.Alert(MessageStringConstants.ServerBusyMessage);
                AppPreferences.IsGoogleLoggedIn = false;
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
            }
        }

        public async void SocialLinkedInLoginAPI()
        {
            try
            {

                UserDialogs.Instance.ShowLoading();
                _socialLoginRequest = new SocialLoginRequest();
                SocialName = string.Empty;
                #region  Social Account Login
                string DeviceID, DeviceModel, DeviceOS;
                DeviceID = Utilities.GetDeviceID();
                DeviceModel = Utilities.GetDeviceModel();
                DeviceOS = Xamarin.Forms.Device.RuntimePlatform;
                if (!(string.IsNullOrEmpty(DeviceID)) && !(string.IsNullOrEmpty(DeviceModel)) && !(string.IsNullOrEmpty(DeviceOS) && !(string.IsNullOrEmpty(AppPreferences.UserValues.register_id.ToString()))))
                {
                    _socialLoginRequest.DeviceID = DeviceID;
                    _socialLoginRequest.DeviceModel = DeviceModel;
                    _socialLoginRequest.DeviceOS = DeviceOS;
                }
                string SocialFullName = AppPreferences.LinkedInUserDetails.firstname + " " + AppPreferences.LinkedInUserDetails.lastname;
                SocialName = SocialFullName;
                _socialLoginRequest.SocialID = AppPreferences.LinkedInUserDetails.id;
                _socialLoginRequest.emailAddress = AppPreferences.LinkedInUserDetails.emailaddress;
                _socialLoginRequest.ProviderType = "LinkedIn";

                var result = await _httpCommonsevice.PostAsync<LoginResponseData, SocialLoginRequest>(APIData.API_BASE_URL + APIMethods.SocialLogin_v7, _socialLoginRequest);
                if (result != null)
                {
                    if (result.code == "200")
                    {
                        AppPreferences.IsLinkedInLoggedIn = false;
                        NavigateToPage(result);
                       
                    }
                    else
                    {
                        AppPreferences.IsLinkedInLoggedIn = true;
                        UserDialogs.Instance.HideLoading();
                        Application.Current.MainPage = new UserRegistration_mobile();
                        return;
                    }
                }
                else
                {

                    UserDialogs.Instance.Alert(MessageStringConstants.ServerBusyMessage);
                    AppPreferences.IsLinkedInLoggedIn = false;
                    UserDialogs.Instance.HideLoading();
                }


                #endregion
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.Alert(MessageStringConstants.ServerBusyMessage);
                AppPreferences.IsLinkedInLoggedIn = false;
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
            }
        }

        #region ClearAppPreferences
        private void ClearAppPreferences()
        {
            AppPreferences.IsVisibleOthersSkill = "false";
            AppPreferences.IsPasswordReset = false;
           // AppPreferences.IsLogout = false;
            AppPreferences.IsFirstRun = true;
            AppPreferences.IsLoggeedIn = false;
            AppPreferences.IsDashboard = false;
            AppPreferences.IsResumeUploaded = false;
            AppPreferences.IsVideosUploaded = false;
            AppPreferences.IsProfileCompleted = false;
            AppPreferences.ActiveToken = null;
            AppPreferences.SkillVideo = null;
            AppPreferences.AboutMeVideo = null;
            AppPreferences.IsPasscode = false;
            AppPreferences.IsPasscodeValue = String.Empty;
            AppPreferences.InterestVideo = null;
            AppPreferences.ProfilePicture = null;//string.Empty;
            AppPreferences.userName = String.Empty;
            AppPreferences.CanUploadSkillVideo = false;
            AppPreferences.CanUploadAboutMeVideo = false;
            AppPreferences.CanUploadSkillVideo = false;
            AppPreferences.IdCard = string.Empty;
            AppPreferences.IsNavigateNotification = false;
            //AppPreferences.CurrentUser = new JobSeekerProfileDetails();
            //AppSessionData.ProfileDetailsRequestData = null;
            //AppSessionData.Language = null;
            //AppSessionData.AssessmentScores = null;
            AppPreferences.EmailAddress = String.Empty;
            AppPreferences.MobileNumber = String.Empty;
            AppPreferences.HireMeeID = String.Empty;
            //AppPreferences.ProfileScore = String.Empty;
            //AppPreferences.CurrentProgress = String.Empty;
            //AppPreferences.FirstName = string.Empty;
            //AppPreferences.LastName = string.Empty;
            AppPreferences.IsCollege = false;
            //AppPreferences.TempToken = string.Empty;
            AppPreferences.LoadSeekerDashboardData = null;
            AppPreferences.IsSeekerDashboardDataDownloaded = false;
            AppPreferences.LoadSeekerDashboardData = null;

        }
        #endregion

        private async void AddUserEmail()
        {
            if (string.IsNullOrEmpty(OTP))
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.NullOTP);
            }
            else if (OTP.Length < 9) //&& (OTP != AppPreferences.EmailUpdateValues.otp)
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.InvalidOTP);
            }
            else
            {
                try
                {

                    UserDialogs.Instance.ShowLoading();
                    //   bool isHostReachable = await CrossConnectivity.Current.IsRemoteReachable(APIData.HOST_REACHABLE);
                    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                    if (isNetworkAvailable)
                    {
                        //  if (isHostReachable)
                        //  {
                        if (AppPreferences.EmailUpdateValues != null && AppSessionData.ActiveToken != null)
                        {
                            _AddUserEmail_OTP_model.otp = OTP;
                            _AddUserEmail_OTP_model.register_id = AppPreferences.EmailUpdateValues.register_id.ToString();
                            _AddUserEmail_OTP_model.hiremee_id = AppSessionData.ActiveToken.HireMeID;
                            _AddUserEmail_OTP_model.token = AppSessionData.ActiveToken.Token;
                            _AddUserEmail_OTP_model.email_address = AppPreferences.EmailAddress;
                            _AddUserEmail_OTP_model.mobile_number = string.Empty;

                            // _AddUserEmail_OTP_model.type = 0;

                        }

                        //Todo BaseURL Change
                        var statusResult = await _httpCommonsevice.PostAsync<AddUserEmail_OTP_Response, AddUserEmail_OTP_model>(APIData.API_BASE_URL + APIMethods.UpdateEmail_OTP_V7, _AddUserEmail_OTP_model);

                        if (statusResult != null)
                        {
                            if (statusResult.code == "200")
                            {
                                Xamarin.Forms.Device.BeginInvokeOnMainThread(() =>
                                {
                                    StopTimer();
                                    Task.Delay(1000);
                                });
                                IsEmailVerified = true;
                                UserDialogs.Instance.HideLoading();

                                MessagingCenter.Send(this, "UpdateBasicDetails", "EmailVerified");

                                string values = AppPreferences.EmailUpdateValues.email_address;
                                MessagingCenter.Send(this, "UpdateEmail", values);

                                await UserDialogs.Instance.AlertAsync(statusResult.message);
                                AppPreferences.IsVerifyEmail = true;
                                await nav.PopAsync();

                            }
                            else
                            {
                                //StopTimer();
                                UserDialogs.Instance.HideLoading();
                                MessagingCenter.Send(this, "UpdateBasicDetails", "EmailNotVerified");
                                await UserDialogs.Instance.AlertAsync(statusResult.message);
                            }
                        }
                        // }
                        //else
                        //{
                        //    //StopTimer();
                        //    UserDialogs.Instance.HideLoading();
                        //    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnectionSlow);
                        //}
                    }
                    else
                    {
                        //StopTimer();
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                    }
                }
                catch (Exception ex)
                {
                    StopTimer();
                    UserDialogs.Instance.HideLoading();
                    Debug.WriteLine(ex.Message);
                    SendErrorMessageToServer(ex, "OTPVerifyViewModel.AddUserEmail");
                }

            }
        }


        private async void ForgotPasswordMobile()
        {

            if (string.IsNullOrEmpty(OTP))
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.NullOTP);
            }
            else if ((OTP.Length < 9)) // && (OTP != AppPreferences.ForgotPasswordValues.otp)
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.InvalidOTP);
            }
            else
            {
                try
                {

                    UserDialogs.Instance.ShowLoading();
                    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                    if (isNetworkAvailable)
                    {
                        if ((AppPreferences.ForgotPasswordNewValues) != null)
                        {
                            _ForgotPasswordVerifyModel.register_id = AppPreferences.ForgotPasswordNewValues.register_id.ToString(); // Apppreference Value to be add
                            _ForgotPasswordVerifyModel.otp = OTP;
                            _ForgotPasswordVerifyModel.password = InputPassword;
                            //_ForgotPasswordVerifyModel.type = 0;
                        }

                        //Todo BaseURL Change
                        var statusResult = await _httpCommonsevice.PostAsync<ForgotPasswordVerifyResponse, ForgotPasswordVerifyModel>(APIData.API_BASE_URL + APIMethods.OTPVerify_forgot_V7, _ForgotPasswordVerifyModel);

                        if (statusResult != null)
                        {
                            if (statusResult.code == "200")
                            {
                                Xamarin.Forms.Device.BeginInvokeOnMainThread(() =>
                                {
                                    StopTimer();
                                    Task.Delay(1000);
                                });
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(statusResult.message);
                                await nav.PopAsync();
                                Application.Current.MainPage = new NavigationPage(new ResetPasswordPage());
                                return;
                            }
                            else
                            {
                                //StopTimer();
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(statusResult.message);
                            }
                        }
                    }
                    else
                    {
                        // StopTimer();
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                    }
                }
                catch (Exception ex)
                {
                    StopTimer();
                    UserDialogs.Instance.HideLoading();
                    Debug.WriteLine(ex.Message);
                    SendErrorMessageToServer(ex, "OTPVerifyViewModel.ForgotPasswordMobile");
                }

            }

        }

        private async void userRegistrationMethod()
        {
            if (string.IsNullOrEmpty(OTP))
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.NullOTP);
            }
            else if ((OTP.Length < 9))
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.InvalidOTP);
            }
            else
            {
                try
                {

                    UserDialogs.Instance.ShowLoading();
                    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                    if (isNetworkAvailable)
                    {
                        string DeviceID, DeviceModel, DeviceOS;
                        DeviceID = Utilities.GetDeviceID();
                        DeviceModel = Utilities.GetDeviceModel();
                        DeviceOS = Xamarin.Forms.Device.RuntimePlatform;
                        if (!(string.IsNullOrEmpty(DeviceID)) && !(string.IsNullOrEmpty(DeviceModel)) && !(string.IsNullOrEmpty(DeviceOS) && !(string.IsNullOrEmpty(AppPreferences.UserValues.register_id.ToString()))))
                        {
                            if ((AppPreferences.UserValues) != null)
                            {
                                _OTPVerifyRequest.register_id = AppPreferences.UserValues.register_id.ToString(); // Apppreference Value to be add
                                _OTPVerifyRequest.otp = OTP;
                                _OTPVerifyRequest.udid = DeviceID;
                                _OTPVerifyRequest.devos = DeviceOS;
                                _OTPVerifyRequest.devmodel = DeviceModel;
                            }
                        }
                        var statusResult = await _httpCommonsevice.PostAsync<OTPVerifyResponse, OTPVerifyRequest>(APIData.API_BASE_URL + APIMethods.OTPVerify_v7, _OTPVerifyRequest);

                        if (statusResult != null)
                        {

                            if (statusResult.code == "200")
                            {
                                Xamarin.Forms.Device.BeginInvokeOnMainThread(() =>
                                {
                                    StopTimer();
                                    Task.Delay(1000);
                                });
                                AppPreferences.IsFBLoggeedIn = false;
                                AppPreferences.IsGoogleLoggedIn = false;
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(statusResult.message);
                                await nav.PushAsync(new SetPasswordPopupPage());
                            }
                            else
                            {
                                //StopTimer();
                                AppPreferences.IsFBLoggeedIn = false;
                                AppPreferences.IsGoogleLoggedIn = false;
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(statusResult.message);
                            }
                        }
                    }
                    else
                    {
                        //StopTimer();
                        AppPreferences.IsFBLoggeedIn = false;
                        AppPreferences.IsGoogleLoggedIn = false;
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                    }
                }
                catch (Exception ex)
                {
                    StopTimer();
                    AppPreferences.IsFBLoggeedIn = false;
                    AppPreferences.IsGoogleLoggedIn = false;
                    UserDialogs.Instance.HideLoading();
                    Debug.WriteLine(ex.Message);
                    SendErrorMessageToServer(ex, "OTPVerifyViewModel.userRegistrationMethod");
                }
            }
        }
        #endregion



        private string _labelHidePassword;
        public string LabelHidePassword
        {
            get { return _labelHidePassword; }
            set
            {
                if (value == _labelHidePassword) return;
                _labelHidePassword = value;
                OnPropertyChanged();
            }
        }

        private bool _isCheckPassword;

        public bool isCheckPassword
        {
            get { return _isCheckPassword; }
            set { _isCheckPassword = value; OnPropertyChanged(); }
        }


        private string _inputPassword;

        public string InputPassword
        {
            get { return _inputPassword; }
            set { _inputPassword = value; OnPropertyChanged(); }
        }

        private bool _isPassword;
        public bool IsPassword
        {
            get
            {
                return _isPassword;
            }
            set
            {
                _isPassword = value;
                OnPropertyChanged();
            }
        }

        private string _oTP;
        public string OTP
        {
            get { return _oTP; }
            set
            {
                if (value == _oTP) return;
                _oTP = value;
                OnPropertyChanged();
            }
        }


        private string _passwordFontAwesomeFont;
        public string PasswordFontAwesomeFont
        {
            get { return _passwordFontAwesomeFont; }
            set
            {
                if (value == _passwordFontAwesomeFont) return;
                _passwordFontAwesomeFont = value;
                OnPropertyChanged();
            }
        }

        private bool _isMobileNoVerified;
        public bool IsMobileNoVerified
        {
            get { return _isMobileNoVerified; }
            set { _isMobileNoVerified = value; OnPropertyChanged(); }
        }

        private bool _isEmailVerified;
        public bool IsEmailVerified
        {
            get { return _isEmailVerified; }
            set { _isEmailVerified = value; OnPropertyChanged(); }
        }


        private string _timeCount;

        public string TimeCount
        {
            get { return _timeCount; }
            set { _timeCount = value; OnPropertyChanged(); }
        }

        private string _OnTextChangeValue;

        public string OnTextChangeValue
        {
            get { return _OnTextChangeValue; }
            set { _OnTextChangeValue = value;  OnPropertyChanged(); }
        }

        #region Timer Functionality
        public bool _isRunning;
        private TimeSpan TotalTime;
        private TimeSpan MakeTheTimeZero = TimeSpan.Zero;
        TimeSpan SetTime = new TimeSpan(0, 3, 0);
        private void StartTimer()
        {
            TotalTime = MakeTheTimeZero;
            _isRunning = true;
            RunTimer();
        }
        public void StopTimer()
        {
            try
            { 
                _isRunning = false;
                TimeCount = string.Format("{0:mm\\:ss}", TotalTime);
            }
            catch (Exception ex)
            {
                SendErrorMessageToServer(ex, "OTPVerifyViewModel.StopTimer");
            }
        }
        public void RunTimer()
        {

            TimeSpan TimeElement = new TimeSpan();
            Device.StartTimer(new TimeSpan(0, 0, 1), () =>
            {

                if (_isRunning)
                {
                    TotalTime = TotalTime + TimeElement.Add(new TimeSpan(0, 0, 1));
                    TimeCount = string.Format("{0:mm\\:ss}", TotalTime);          //Print the Timer
                    if (TotalTime == SetTime)
                    {
                        _isRunning = false;
                        OnTextChangeValue = "Resend";
                        UserDialogs.Instance.AlertAsync(MessageStringConstants.OTPLimitExpired);
                        OTP = string.Empty;
                        //nav.PopAsync();
                    }
                }
                return _isRunning;
            });
        }
        #endregion

    }
}
