﻿using GalaSoft.MvvmLight.Command;
using HireMe.Helpers;
using HireMe.Models.Recruiter;
using HireMe.Views.JobSeeker;
using MvvmHelpers;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.JobSeeker
{
    public class AddEducationPopupViewModel : BaseViewModel
    {
        #region Initializaiton
        public ICommand OnCommand { get; set; }
        INavigation Navigation;
        private bool isClicked = true;
        List<CommonListItemSource> GlobalCommonListItemSource;
        public CommonListItemSource temptItemSource { get; set; }
        private HttpCommonService _commonservice { get; set; }
        List<CourseType> ListCourseType;
        private List<string> _courseTypeID;

        ObservableCollection<Educational_Details> ItemSource;
        #endregion

        #region Constructor
        public AddEducationPopupViewModel(INavigation navigation, List<string> _courseTypeID, List<CourseType> _CourseTypeItemSource, ObservableCollection<Educational_Details> _ItemSource)
        {
            Navigation = navigation;
            this._courseTypeID = _courseTypeID;
            _commonservice = new HttpCommonService();
            GlobalCommonListItemSource = new List<CommonListItemSource>();
            OnCommand = new RelayCommand<string>(DoOperation);
            ListViewSelectedItem = new CommonListItemSource();
            ListCourseType = _CourseTypeItemSource;
            //GlobalCommonListItemSource = null;
            IsLableViewVisible = false;
            ItemSource = _ItemSource;
            BindCourseTypeData();
        }

        #endregion

        #region Command Operation
        private void DoOperation(string obj)
        {
            switch (obj)
            {
                case "Cancel":
                    Navigation.PopAsync();
                    break;
            }
        }
        #endregion

        #region BindCourseTypeData
        async Task BindCourseTypeData()
        {

            try
            {

                System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindCourseTypeData");
                List<CommonListItemSource> objCommonListItemSource = new List<CommonListItemSource>();
                //if (GlobalCommonListItemSource == null)
                //{
                //    MasterTableRequestData MasterTableRequestData = new MasterTableRequestData()
                //    {
                //        HiremeeID = AppSessionData.ActiveToken.HireMeID,
                //        Token = AppSessionData.ActiveToken.Token,
                //        TableName = "coursetype"
                //    };
                //    var coursetypes = await _commonservice.PostAsync<CourseTypeResponseData, MasterTableRequestData>(APIData.PHP_REST_API_BASE_URL + APIMethods.MasterTables, MasterTableRequestData);
                foreach (var x in ListCourseType)
                {
                    temptItemSource = new CommonListItemSource();
                    temptItemSource.ID = x.ID;
                    temptItemSource.Title = x.Title;
                    temptItemSource.educational_level = x.educational_level;

                    if (!_courseTypeID.Contains(x.educational_level))
                    {
                        objCommonListItemSource.Add(temptItemSource);
                    }
                }
                GlobalCommonListItemSource = objCommonListItemSource;
                //}

                ListViewItemSource = GlobalCommonListItemSource;

                if (ListViewItemSource.Count > 0)
                {
                    IsLableViewVisible = false;
                    IsListViewVisible = true;
                }
                else
                {
                    IsListViewVisible = false;
                    IsLableViewVisible = true;
                }

            }
            catch (Exception ex)
            {
                SendErrorMessageToServer(ex, "AddEducationPopupViewModel.BindCourseTypeData");
            }

        }
        #endregion

        #region Private Properties
        private bool _IsListViewVisible;
        public bool IsListViewVisible
        {
            get { return _IsListViewVisible; }
            set { _IsListViewVisible = value; OnPropertyChanged(); }
        }

        private bool _IsLableViewVisible;
        public bool IsLableViewVisible
        {
            get { return _IsLableViewVisible; }
            set { _IsLableViewVisible = value; OnPropertyChanged(); }
        }

        #endregion

        #region ListView Property
        public List<CommonListItemSource> _ListViewItemSource;
        public List<CommonListItemSource> ListViewItemSource
        {
            get { return _ListViewItemSource; }
            set
            {
                _ListViewItemSource = value;
                OnPropertyChanged();
            }
        }

        public CommonListItemSource _ListViewSelectedItem;


        public CommonListItemSource ListViewSelectedItem
        {
            get { return _ListViewSelectedItem; }
            set
            {
                _ListViewSelectedItem = value;
                OnPropertyChanged();
            }
        }
        public ICommand SelectedCommand => new Command(async () =>
        {

            try
            {
                if (isClicked)
                {
                    isClicked = false;
                    string[] course = { ListViewSelectedItem.Title, ListViewSelectedItem.ID, ListViewSelectedItem.educational_level };
                    //await Navigation.PopAsync();
                    //MessagingCenter.Send(this, "CourseType", course);
                    var educational_level = ListViewSelectedItem.educational_level;

                    isClicked = false;
                    if (educational_level == "1" || educational_level == "2")
                    {
                        await Navigation.PushAsync(new SchoolingEducationDetailsPage(Constants.FieldType.AddEducation, ItemSource, ListViewSelectedItem.ID));
                    }
                    else if (educational_level == "3" || educational_level == "4" || educational_level == "5")
                    {
                        await Navigation.PushAsync(new CollegeEducationDetailsPage(Constants.FieldType.AddEducation, ItemSource, ListViewSelectedItem.ID));
                    }

                    //await Navigation.PopAsync();
                    await Task.Run(async () =>
                     {
                         await Task.Delay(500);
                         isClicked = true;
                     });

                }
            }
            catch (Exception ex)
            {
                SendErrorMessageToServer(ex, "AddEducationPopupViewModel.SelectedCommand");
            }

        });
        #endregion


        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
