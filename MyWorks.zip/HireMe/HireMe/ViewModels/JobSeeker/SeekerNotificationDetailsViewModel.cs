﻿using GalaSoft.MvvmLight.Command;
using HireMe.Models.JobSeeker;
using MvvmHelpers;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.JobSeeker
{
	class SeekerNotificationDetailsViewModel : BaseViewModel
	{
		private Notification selectedItem;
		public bool isClicked = true;

		public ICommand OnCompanyNameTapped { get; set; }
		INavigation navigation;

		public SeekerNotificationDetailsViewModel(INavigation navigation, Notification selectedItem)
		{

			this.navigation = navigation;
			this.selectedItem = selectedItem;
			CompanyName = selectedItem.CompanyName;
			LabelCaption = "Company Name :";
			IsBoxViewVisible = true;
			MailContent = selectedItem.MailContent;
			OnCompanyNameTapped = new RelayCommand<string>(OnClick);
		}

		public SeekerNotificationDetailsViewModel(INavigation navigation, string title, string mailContent)
		{
			this.navigation = navigation;
			CompanyName = title;
			LabelCaption = "Title :";
			IsBoxViewVisible = false;

			MailContent = mailContent;
		}

		private async void OnClick(string sender)
		{
			switch (sender)
			{
				case "OpenCompany":
					#region OpenCompany
					if (isClicked)
					{
						isClicked = false;
						if (!string.IsNullOrEmpty(selectedItem.CompanyID))
							await navigation.PushAsync(new CompanyFullDetails(selectedItem.CompanyID, selectedItem.CompanyName));
					}
					await Task.Run(async () =>
					{
						await Task.Delay(500);
						isClicked = true;
					});
					#endregion
					break;
			}
		}
		private bool _isBoxViewVisible;

		public bool IsBoxViewVisible
		{
			get { return _isBoxViewVisible; }
			set
			{
				_isBoxViewVisible = value; OnPropertyChanged();
			}

		}
		private string _CompanyName;

		public string CompanyName
		{
			get { return _CompanyName; }
			set { _CompanyName = value; OnPropertyChanged(); }
		}


		private string _MailContent;

		public string MailContent
		{
			get { return _MailContent; }
			set { _MailContent = value; OnPropertyChanged(); }
		}


		private string _LabelCaption;

		public string LabelCaption
		{
			get { return _LabelCaption; }
			set { _LabelCaption = value; OnPropertyChanged(); }
		}
	}
}
