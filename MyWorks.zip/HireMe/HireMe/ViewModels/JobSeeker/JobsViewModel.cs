﻿using HireMe.Views.JobSeeker;
using MvvmHelpers;
using Prism.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.JobSeeker
{
    public class JobsViewModel : BaseViewModel
    {
        INavigation Navigation;
        public ICommand OnCommand { get; set; }
        public bool isClicked = true;
        List<Color> ColorCodeList;
        Random randomColorPicker;
        public JobsViewModel(INavigation nav)
        {
            Navigation = nav;
            OnCommand = new DelegateCommand<LoadCustomGridItems>(DoOperation);
            randomColorPicker = new Random();
            LoadGridValue();
        }

        #region OnCommand Operation

        private async void DoOperation(LoadCustomGridItems obj)
        {
            try
            {
                if (obj.Title.Equals("Search Jobs"))
                {
                    if (isClicked)
                    {
                        isClicked = false;
                        await Navigation.PushAsync(new SearchJobsView());
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                }
                else if (obj.Title.Equals("Appiled Jobs"))
                {
                    if (isClicked)
                    {
                        isClicked = false;
                        await Navigation.PushAsync(new AppliedJobsViewPage());
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                }
                else if (obj.Title.Equals("Recommended Jobs"))
                {
                    if (isClicked)
                    {
                        isClicked = false;
                        await Navigation.PushAsync(new RecommendedJobsViewPage());
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                }
                else if (obj.Title.Equals("Current Opennings"))
                {
                    if (isClicked)
                    {
                        isClicked = false;
                        await Navigation.PushAsync(new CurrentOpningsViewPage());
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                }
                else if (obj.Title.Equals("Current Walkins"))
                {
                    if (isClicked)
                    {
                        isClicked = false;
                        await Navigation.PushAsync(new CurrentWalkinsViewPage());
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                }
            }
            catch (Exception ex)
            {

            }
        }
        #endregion

        #region LoadGridValue
        private void LoadGridValue()
        {
            try
            {
                GridItems = new List<LoadCustomGridItems>();
                ColorCodeList = new List<Color>();
                loadColorCode();
                LoadCustomGridItems loadCustomGridItems;

                for (int i = 0; i < 5; i++)
                {
                    loadCustomGridItems = new LoadCustomGridItems();
                    int r = randomColorPicker.Next(ColorCodeList.Count);

                    if (i == 0)
                    {

                        loadCustomGridItems.Title = "Search Jobs";
                        loadCustomGridItems.CustomImage = (string)Application.Current.Resources["StudentUploadIcon"]; ;
                        loadCustomGridItems.GridItemBackColor = ColorCodeList[i];

                    }
                    if (i == 1)
                    {
                        loadCustomGridItems.Title = "Appiled Jobs";
                        loadCustomGridItems.CustomImage = (string)Application.Current.Resources["TotalRegisterIcon"]; ;
                        loadCustomGridItems.GridItemBackColor = ColorCodeList[i];
                    }
                    if (i == 2)
                    {
                        loadCustomGridItems.Title = "Recommended Jobs";
                        loadCustomGridItems.CustomImage = (string)Application.Current.Resources["TotalRegisterIcon"]; ;
                        loadCustomGridItems.GridItemBackColor = ColorCodeList[i];
                    }
                    if (i == 3)
                    {
                        loadCustomGridItems.Title = "Current Opennings";
                        loadCustomGridItems.CustomImage = (string)Application.Current.Resources["TotalRegisterIcon"]; ;
                        loadCustomGridItems.GridItemBackColor = ColorCodeList[i];
                    }
                    if (i == 4)
                    {
                        loadCustomGridItems.Title = "Current Walkins";
                        loadCustomGridItems.CustomImage = (string)Application.Current.Resources["TotalRegisterIcon"]; ;
                        loadCustomGridItems.GridItemBackColor = ColorCodeList[i];
                    }
                    GridItems.Add(loadCustomGridItems);

                }
            }
            catch (Exception ex)
            {

            }
        }
        #endregion

        #region Private Properties



        protected List<LoadCustomGridItems> gridItems;
        public List<LoadCustomGridItems> GridItems
        {
            get { return gridItems; }
            set { gridItems = value; OnPropertyChanged(); }
        }
        public void loadColorCode()
        {
            ColorCodeList.Add(Color.FromHex("#FF5733"));
            ColorCodeList.Add(Color.FromHex("#46B503"));
            ColorCodeList.Add(Color.FromHex("#01E3A9"));
            ColorCodeList.Add(Color.FromHex("#025AB3"));
            ColorCodeList.Add(Color.FromHex("#8B02B3"));
            ColorCodeList.Add(Color.FromHex("#26a69a"));
            ColorCodeList.Add(Color.FromHex("#26c6da"));
            ColorCodeList.Add(Color.FromHex("#29b6f6"));
            ColorCodeList.Add(Color.FromHex("#42A5F5"));

        }
        #endregion
    }
}
