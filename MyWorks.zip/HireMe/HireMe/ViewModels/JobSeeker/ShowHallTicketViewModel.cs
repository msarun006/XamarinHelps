﻿using Acr.UserDialogs;
using MvvmHelpers;
using System.Threading.Tasks;
using Xamarin.Forms;
using System;

namespace HireMe.ViewModels.JobSeeker
{
    public class ShowHallTicketViewModel : BaseViewModel
    {
        private INavigation navigation;
        private string _FileName;

        public ShowHallTicketViewModel(INavigation navigation, string _FileName)
        {
            this.navigation = navigation;
            this._FileName = _FileName;

            LoadHallTicket(_FileName);

        }

        private async void LoadHallTicket(String _FileName)
        {
            UserDialogs.Instance.ShowLoading();
            var HallTicketPath = Task.Run(async () => { return await DependencyService.Get<IS3ImageManager>().DownloadFile(_FileName, AmazonS3BucketDetails.HallTicketBucket); }).Result;

           // var HallTicketPath = await DependencyService.Get<IS3ImageManager>().DownloadFile(_FileName, Constants.HallTicketBucket);
            MailContent = HallTicketPath;
            UserDialogs.Instance.HideLoading();
        }

      
        private string _MailContent;
        public string MailContent
        {
            get { return _MailContent; }
            set { _MailContent = value; OnPropertyChanged(); }
        }

    }
}
