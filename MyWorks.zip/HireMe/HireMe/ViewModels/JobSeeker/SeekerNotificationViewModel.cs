﻿using Acr.UserDialogs;
using HireMe.Models.JobSeeker;
using HireMe.UI;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;
using System.Diagnostics;
using HireMe.Helpers;

namespace HireMe.ViewModels.JobSeeker
{
    public class SeekerNotificationViewModel : BaseViewModel
    {
        public bool isClicked = true;
        private HttpCommonService _commonservice { get; set; }
        public NotificationRequestData NotificationRequestData { get; set; }
        public NotificationResponse NotificationResponse { get; set; }


        private ObservableCollection<NotificationResponsetext> _ItemSource;

        public ObservableCollection<NotificationResponsetext> ItemSource
        {
            get { return _ItemSource; }
            set { _ItemSource = value; OnPropertyChanged(); }
        }


        private ObservableCollection<NotificationResponsetext> _tempsource;

        public ObservableCollection<NotificationResponsetext> TempItemSource
        {
            get { return _tempsource; }
            set { _tempsource = value; OnPropertyChanged(); }
        }

        INavigation navigation;
        public SeekerNotificationViewModel(INavigation _navigation)
        {

            navigation = _navigation;
            SearchPlaceHolderText = "Search Notifications";
            IsLableViewVisible = false;
            isEnabledSearchBar = true;
            IsSearchBarVisible = false;
            _commonservice = new HttpCommonService();
            NotificationRequestData = new NotificationRequestData();
            NotificationResponse = new NotificationResponse();


            NotificationRequestData.HiremeeID = AppSessionData.ActiveToken.HireMeID;
            NotificationRequestData.Token = AppSessionData.ActiveToken.Token;
            BindNotificationList();


        }



        #region Searchbar Controls
        private bool _isVisibleSearchbarCancel;
        public bool IsVisibleSearchbarCancelButton
        {
            get { return _isVisibleSearchbarCancel; }
            set { _isVisibleSearchbarCancel = value; OnPropertyChanged(); }
        }

        public string _SearchText;
        public string SearchText
        {
            set
            {
                _SearchText = value;
                SearchText_TextChanged();
                OnPropertyChanged();
            }
            get { return _SearchText; }
        }
        public bool _isEnabledSearchBar;

        public bool isEnabledSearchBar
        {
            set { _isEnabledSearchBar = value; OnPropertyChanged(); }
            get { return _isEnabledSearchBar; }
        }
        public Command OnSearchClearCommand => new Command(() =>
        {
            IsVisibleSearchbarCancelButton = false;
            SearchText = string.Empty;
            SearchPlaceHolderText = "Search Notifications";

        });
        private string _searchPlaceHolder;
        public string SearchPlaceHolderText
        {
            get { return _searchPlaceHolder; }
            set { _searchPlaceHolder = value; OnPropertyChanged(); }
        }


        public void SearchText_TextChanged()
        {
            var searchtext = SearchText;
            if (string.IsNullOrEmpty(searchtext))
            {
                SearchPlaceHolderText = "Search Notifications";
                IsVisibleSearchbarCancelButton = false;
                BindNotificationList();
                return;
            }

            if (TempItemSource != null)
            {

                ItemSource = TempItemSource;
                List<NotificationResponsetext> Suggetions = ItemSource.Where
               (c => c.NotificationTitle.ToLower().Contains(searchtext.ToLower())
                //|| c.MailContent.ToLower().Contains(searchtext.ToLower())
                //|| c.NotificationBody.ToLower().Contains(searchtext.ToLower())
                //|| c.NotifiedDate.ToLower().Contains(searchtext.ToLower())
                //|| c.NotificationType.ToLower().Contains(searchtext.ToLower())
                || c.MailContent.ToLower().Contains(searchtext.ToLower())).ToList();


                ItemSource = new ObservableCollection<NotificationResponsetext>(Suggetions);
                IsVisibleSearchbarCancelButton = true;
            }

        }

        #endregion




        private async void BindNotificationList()
        {

            try
            {
                UserDialogs.Instance.ShowLoading();

                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {

                    var result = await _commonservice.PostAsync<NotificationResponse, NotificationRequestData>(APIData.API_BASE_URL + APIMethods.Getfirebasenotification, NotificationRequestData);

                    if (result != null)
                    {
                        if (result.code == "200")
                        {
                            //isEnabledSearchBar = true;
                         
                            ItemSource = new ObservableCollection<NotificationResponsetext>(result.responseText);
                            TempItemSource = new ObservableCollection<NotificationResponsetext>(ItemSource);
                            if (ItemSource.Count > 0)
                            {
                                IsLableViewVisible = false;
                                IsListViewVisible = true;
                                IsSearchBarVisible = true;
                                isEnabledSearchBar = true;  
                            }
                            else
                            {
                                IsListViewVisible = false;
                                IsSearchBarVisible = false;
                                IsLableViewVisible = true;
                            }


                            UserDialogs.Instance.HideLoading();

                        }
                        else
                        {
                            IsSearchBarVisible = false;
                            IsLableViewVisible = true;
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(result.message);
                        }
                    }
                }
                else
                {
                    IsSearchBarVisible = false;
                    IsLableViewVisible = true;
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerNotificationViewModel.BindNotificationList");
            }
        }


        private bool _IsListViewVisible;
        public bool IsListViewVisible
        {
            get { return _IsListViewVisible; }
            set { _IsListViewVisible = value; OnPropertyChanged(); }
        }

        private bool _IsLableViewVisible;
        public bool IsLableViewVisible
        {
            get { return _IsLableViewVisible; }
            set { _IsLableViewVisible = value; OnPropertyChanged(); }
        }

        private bool _IsSearchBarVisible;
        public bool IsSearchBarVisible
        {
            get { return _IsSearchBarVisible; }
            set { _IsSearchBarVisible = value; OnPropertyChanged(); }
        }
        

        private NotificationResponsetext _SelectedItem;
        public NotificationResponsetext SelectedItem
        {
            get { return _SelectedItem; }
            set { _SelectedItem = value; OnPropertyChanged(); }
        }

        public ICommand SelectedCommand => new Command(async () =>
        {

            var data = SelectedItem as NotificationResponsetext;

            if (isClicked)
            {
                isClicked = false;

                if (data.NotificationType != "Hallticket")
                    await navigation.PushAsync(new SeekerNotificationDetailPage(data.NotificationTitle, data.MailContent));
                else
                {
                    String FileName = data.FileName;
                    await navigation.PushAsync(new ShowHallTicket(FileName));

                }

            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });


        });

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }



}
