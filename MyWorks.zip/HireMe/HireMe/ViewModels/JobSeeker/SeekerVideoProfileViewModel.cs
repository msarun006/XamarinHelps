﻿
using Acr.UserDialogs;
using Amazon.S3;
using Amazon.S3.Model;
using HireMe.Helpers;
using HireMe.Models;
using HireMe.Models.JobSeeker;
using HireMe.Services;
using MvvmHelpers;
using Plugin.Connectivity;
using Plugin.Media;
using Plugin.Media.Abstractions;
using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.JobSeeker
{
    class SeekerVideoProfileViewModel : BaseViewModel
    {
        #region ClassVariable        
        INavigation navigation;
        public bool isClicked = true;
        ResourceConfig objAboutMyselfData = new ResourceConfig();
        ResourceConfig objSkillData = new ResourceConfig();
        ResourceConfig objAmbitionData = new ResourceConfig();
        List<UserResourceType> ltUserResourceType = new List<UserResourceType>();
        string absolutePath = string.Empty;
        bool canUploadAboutMeVideo;
        bool canUploadSkillVideo;
        bool canUploadInterestsVideo;
        private HttpCommonService _commonservice { get; set; }
        string _aboutMeVideoBlockedReason, _skillVideoBlockedReason, _interestVideoBlockedReason = string.Empty;

        private bool _isVisibleGridHelp;
        public bool IsVisibleGridHelp
        {
            get { return _isVisibleGridHelp; }
            set
            {
                _isVisibleGridHelp = value;
                OnPropertyChanged();
            }
        }

        private bool _showNextButton;
        public bool IsVisibleNextButton
        {
            get { return _showNextButton; }
            set { _showNextButton = value; OnPropertyChanged(); }
        }

        private string _imageSourceYourself;
        public string ImageSourceYourSelf
        {
            get { return _imageSourceYourself; }
            set { _imageSourceYourself = value; OnPropertyChanged(); }
        }
        private string _skillVideoProgress;
        public string SkillVideoProgress
        {
            get { return _skillVideoProgress; }
            set { _skillVideoProgress = value; OnPropertyChanged(); }
        }
        private string _aboutmeVideoProgress;
        public string AboutmeVideoProgress
        {
            get { return _aboutmeVideoProgress; }
            set { _aboutmeVideoProgress = value; OnPropertyChanged(); }
        }
        private string _interestvideoProgress;
        public string InterestvideoProgress
        {
            get { return _interestvideoProgress; }
            set { _interestvideoProgress = value; OnPropertyChanged(); }
        }
        private string _imageSourceSkill;
        public string ImageSourceSkill
        {
            get { return _imageSourceSkill; }
            set { _imageSourceSkill = value; OnPropertyChanged(); }
        }

        private string _imageSourceInterest;
        public string ImageSourceInterest
        {
            get { return _imageSourceInterest; }
            set { _imageSourceInterest = value; OnPropertyChanged(); }
        }

        private string _introductionSign;
        public string IntroductionSign
        {
            get { return _introductionSign; }
            set { _introductionSign = value; OnPropertyChanged(); }
        }

        private Color _introductionSignColor;
        public Color IntroductionSignColor
        {
            get { return _introductionSignColor; }
            set { _introductionSignColor = value; OnPropertyChanged(); }
        }

        private bool _introductionSignIsVisible;
        public bool IntroductionSignIsVisible
        {
            get { return _introductionSignIsVisible; }
            set { _introductionSignIsVisible = value; OnPropertyChanged(); }
        }



        private string _skillSign;
        public string SkillSign
        {
            get { return _skillSign; }
            set { _skillSign = value; OnPropertyChanged(); }
        }

        private Color _skillSignColor;
        public Color SkillSignColor
        {
            get { return _skillSignColor; }
            set { _skillSignColor = value; OnPropertyChanged(); }
        }

        private bool _skillSignIsVisible;
        public bool SkillSignIsVisible
        {
            get { return _skillSignIsVisible; }
            set { _skillSignIsVisible = value; OnPropertyChanged(); }
        }


        private string _interestSign;
        public string InterestSign
        {
            get { return _interestSign; }
            set { _interestSign = value; OnPropertyChanged(); }
        }

        private Color _interestSignColor;
        public Color InterestSignColor
        {
            get { return _interestSignColor; }
            set { _interestSignColor = value; OnPropertyChanged(); }
        }

        private bool _interestSignIsVisible;
        public bool InterestSignIsVisible
        {
            get { return _interestSignIsVisible; }
            set { _interestSignIsVisible = value; OnPropertyChanged(); }
        }

        private bool _isGridVisible;
        public bool IsGridVisible
        {
            get { return _isGridVisible; }
            set { _isGridVisible = value; OnPropertyChanged(); }
        }
        #endregion

        #region Construtor
        public SeekerVideoProfileViewModel(INavigation _navigation, bool showNextButton)
        {
            if (Device.RuntimePlatform.Equals("Android"))
            {
                //Track Page 
                GoogleAnalyticService.Track_App_Page("Android VideoProfilePage");
            }
            //or iOS 
            else
            { //Track Page 
                GoogleAnalyticService.Track_App_Page("iOS  VideoProfilePage");
            }
            navigation = _navigation;
            _commonservice = new HttpCommonService();
            isClicked = true;
            AppSessionData.AboutMeVideo = null;
            AppSessionData.SkillVideo = null;
            AppSessionData.InterestsVideo = null;
            AppSessionData.AboutMeVideoStatus = "0";
            AppSessionData.SkillVideoStatus = "0";
            AppSessionData.InterestMeVideoStatus = "0";


            IntroductionSign = (string)Application.Current.Resources["AwaitingSign"];
            IntroductionSignColor = Color.Orange;
            IntroductionSignIsVisible = false;
            SkillSign = (string)Application.Current.Resources["AwaitingSign"];
            SkillSignColor = Color.Orange;
            SkillSignIsVisible = false;
            InterestSign = (string)Application.Current.Resources["AwaitingSign"];
            InterestSignColor = Color.Orange;
            InterestSignIsVisible = false;
            LoadResource();
            IsVisibleNextButton = showNextButton;
            absolutePath = DependencyService.Get<IImageManager>().GetStorageDirectory(ResourceTypeEnums.Videos);

            //openVideoProfile();
            canUploadAboutMeVideo = AppPreferences.CanUploadAboutMeVideo;
            canUploadInterestsVideo = AppPreferences.CanUploadInterestsVideo;
            canUploadSkillVideo = AppPreferences.CanUploadSkillVideo;
            if (AppPreferences.HelpScreen == "ShowHelpScreen")
            {
                IsVisibleGridHelp = true;
                AppPreferences.HelpScreen = "finish";
            }
        }
        #endregion

        #region Command Declaration
        public ICommand GridHelpCommand => new Command(async () =>
        {

            //await UserDialogs.Instance.AlertAsync(CompanylistSelectedItem.name.ToString());

            Debug.WriteLine("@ SeekerNotificationPage.NotificationListView_ItemTapped");

            if (isClicked)
            {
                isClicked = false;
                IsGridVisible = false;
                AppPreferences.HelpScreen = "finish";

            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });

        });
        public ICommand OnNextButtonCommand => new Command(async () =>
        {

            //await UserDialogs.Instance.AlertAsync(CompanylistSelectedItem.name.ToString());

            Debug.WriteLine("@ SeekerNotificationPage.NotificationListView_ItemTapped");

            if (isClicked)
            {
                isClicked = false;
                Debug.WriteLine("@ VideoProfilePage.OnNextButton_Click");
                if (AppSessionData.AboutMeVideo != null && AppSessionData.SkillVideo != null)
                {

                    if (AppSessionData.AboutMeVideo.IsUploaded && AppSessionData.SkillVideo.IsUploaded)
                    {
                        AppPreferences.IsVideosUploaded = true;
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ThankyouForUploadMandotoryVideos);
                        //AppPreferences.isNextButtonClicked = true;
                        Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                        return;
                        //if (string.IsNullOrEmpty(AppPreferences.S3AccessKeyID))
                        //{
                        //    //UserDialogs.Instance.HideLoading();
                        //    var obj = new S3Utils();
                        //    await obj.GetS3Credentials();
                        //}
                    }
                    else
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.UploadMandatoryVideos);
                    }

                }
                else
                {
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.UploadMandatoryVideos);
                }


            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });

        });
        public ICommand RecordVideoCommand => new Command<string>(async (sender) =>
        {

            //await UserDialogs.Instance.AlertAsync(CompanylistSelectedItem.name.ToString());

            Debug.WriteLine("@ SeekerNotificationPage.NotificationListView_ItemTapped");

            if (isClicked)
            {
                await RecordRecognizer_Tapped(sender);
                isClicked = false;

            }
            await Task.Run(async () =>
              {
                  await Task.Delay(500);
                  isClicked = true;
              });

        });
        public ICommand UploadVideoCommand => new Command<string>(async (sender) =>
        {

            //await UserDialogs.Instance.AlertAsync(CompanylistSelectedItem.name.ToString());

            Debug.WriteLine("@ SeekerNotificationPage.NotificationListView_ItemTapped");

            if (isClicked)
            {
                await UploadRecognizer_Tapped(sender);
                isClicked = false;

            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });

        });
        public ICommand PlayVideoCommand => new Command<string>(async (sender) =>
        {

            //await UserDialogs.Instance.AlertAsync(CompanylistSelectedItem.name.ToString());

            Debug.WriteLine("@ SeekerNotificationPage.NotificationListView_ItemTapped");

            if (isClicked)
            {
                PlayTapGestureRecognizer(sender);
                isClicked = false;

            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });

        });
        #endregion

        #region LoadResource
        public async void LoadResource()
        {
            System.Diagnostics.Debug.WriteLine("@ VideoProfilePage.LoadResource");
            if (string.IsNullOrEmpty(AppPreferences.S3AccessKeyID))
            {
                var obj = new S3Utils();
                await obj.GetS3Credentials();
            }


            UserDialogs.Instance.ShowLoading();

            Device.BeginInvokeOnMainThread(async () =>
            {
                await GetUserResourceRetrivalData();
            });
            await Task.Delay(1000);

            UserDialogs.Instance.HideLoading();

        }

        #endregion

        #region Get User Resource Data From API
        public async Task GetUserResourceRetrivalData()
        {

            Debug.WriteLine("@ VideoProfilePage.GetUserResourceRetrivalData");

            try
            {

                //var serializedData = AppPreferences.SeekerDashboardData;
                //SeekerDashboardResponseModel objSeekerDashboardResponseModel = new SeekerDashboardResponseModel();
                //objSeekerDashboardResponseModel = JsonConvert.DeserializeObject<SeekerDashboardResponseModel>(serializedData);
                //Load Video Profile from server
                BaseRequestDTO objRequestData = new BaseRequestDTO();
                //var objResponseData = await _commonservice.PostAsync<VideoResourceRetrivalResponseData, BaseRequestDTO>(APIData.API_BASE_URL + APIMethods.Userresourceretrival, objRequestData);
                var res = await _commonservice.PostAsync<SeekerDashboardResponseModel, BaseRequestDTO>(APIData.API_BASE_URL + APIMethods.GetPersonalDetails, objRequestData);
                if (res != null)
                {
                    if (res.Code == "199")
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.SessionExpiered);
                        Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                        return;
                    }
                    else
                    {
                        AppPreferences.LoadSeekerDashboardData = res;
                        LoadVideoDetails(res.UserResource);
                    }
                }
                //var objSeekerDashboardResponseModel = AppPreferences.LoadSeekerDashboardData;
                //if (objSeekerDashboardResponseModel.UserResource != null)
                //{
                //    //Load Video Profile from local
                //    LoadVideoDetails(objSeekerDashboardResponseModel.UserResource);
                //}
                //else
                //{
                //    APICalForLoadResource();
                //}

            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerVideoProfileViewModel.GetUserResourceRetrivalData");
            }
        }
        private void LoadVideoDetails(VideoResourceRetrivalResponseData objResponseData)
        {
            try
            {
                //BaseRequestDTO objRequestData = new BaseRequestDTO();
                //var objResponseData = await _commonservice.PostAsync<VideoResourceRetrivalResponseData, BaseRequestDTO>(APIData.API_BASE_URL + APIMethods.Userresourceretrival, objRequestData);
                //if (objResponseData != null)
                //{
                if (objResponseData.UserResourceType != null)
                {
                    ltUserResourceType = objResponseData.UserResourceType;
                }
                if (objResponseData.UserResourceConfig != null)
                {
                    objAboutMyselfData = objResponseData.UserResourceConfig.AboutMeConfig;
                    objSkillData = objResponseData.UserResourceConfig.SkillConfig;
                    objAmbitionData = objResponseData.UserResourceConfig.AmbitionConfig;
                }
                if (objResponseData.AboutMeVideo != null)
                {
                    ResourceInformation obj = objResponseData.AboutMeVideo;
                    if (obj != null)
                    {
                        if (obj.ResourceTypeID == Convert.ToInt16(Models.ResourceType.AboutMe).ToString())
                        {
                            string filepath = Path.Combine(absolutePath, obj.S3ID);
                            string thumbnailsource = string.Empty;
                            var thumbimage = obj.S3ID.Replace("mp4", "png");
                            var status = obj.Status;
                            if (DependencyService.Get<IThumbnailManager>().CheckFileExist(Path.Combine(absolutePath, thumbimage)))
                                thumbnailsource = Path.Combine(absolutePath, thumbimage);
                            string S3thumbnailsource = Services.S3Manager.GeneratePreSignedURL(AmazonS3BucketDetails.PhotoBucket, thumbimage, 60);
                            VideoFileDetails objVideoFileDetails = new VideoFileDetails();
                            objVideoFileDetails.FilePath = filepath;
                            objVideoFileDetails.S3URLPath = obj.ResourceURL;
                            objVideoFileDetails.FileName = obj.S3ID;
                            objVideoFileDetails.ReasonForBlocked = obj.ReasonForBlock;
                            _aboutMeVideoBlockedReason = obj.ReasonForBlock;
                            objVideoFileDetails.S3ThumbnailImage = S3thumbnailsource;
                            objVideoFileDetails.ThumbnailImage = thumbnailsource;
                            objVideoFileDetails.FileType = Constants.VideoType.AboutMeVideo;
                            objVideoFileDetails.IsUploaded = true;
                            SetStatus("Introduction", status);
                            AppSessionData.AboutMeVideoStatus = status;
                            AppSessionData.AboutMeVideo = objVideoFileDetails;
                            if (status != "-1")
                            {
                                ImageSourceYourSelf = S3thumbnailsource;
                            }
                            //else
                            //{
                            //    AppSessionData.AboutMeVideo = null;
                            //}
                        }
                        obj = objResponseData.SkillVideo;
                        if (obj.ResourceTypeID == Convert.ToInt16(Models.ResourceType.Skill).ToString())
                        {
                            string filepath = Path.Combine(absolutePath, obj.S3ID);

                            string thumbnailsource = string.Empty;
                            var thumbimage = obj.S3ID.Replace("mp4", "png");
                            var status = obj.Status;
                            if (DependencyService.Get<IThumbnailManager>().CheckFileExist(Path.Combine(absolutePath, thumbimage)))
                                thumbnailsource = Path.Combine(absolutePath, thumbimage);
                            string S3thumbnailsource = Services.S3Manager.GeneratePreSignedURL(AmazonS3BucketDetails.PhotoBucket, thumbimage, 60);
                            VideoFileDetails objVideoFileDetails = new VideoFileDetails();
                            objVideoFileDetails.FilePath = filepath;
                            objVideoFileDetails.S3URLPath = obj.ResourceURL;
                            objVideoFileDetails.FileName = obj.S3ID;
                            objVideoFileDetails.S3ThumbnailImage = S3thumbnailsource;
                            objVideoFileDetails.ReasonForBlocked = obj.ReasonForBlock;
                            _skillVideoBlockedReason = obj.ReasonForBlock;
                            objVideoFileDetails.FileType = Constants.VideoType.MySkillsVideo;
                            objVideoFileDetails.IsUploaded = true;
                            SetStatus("MySkills", status);
                            AppSessionData.SkillVideoStatus = status;
                            AppSessionData.SkillVideo = objVideoFileDetails;
                            if (status != "-1")
                            {
                                ImageSourceSkill = S3thumbnailsource;
                            }
                            //else
                            //{
                            //    AppSessionData.SkillVideo = null;
                            //}
                            objVideoFileDetails.ThumbnailImage = thumbnailsource;
                        }
                        obj = objResponseData.AreaOfInterestVideo;
                        if (obj.ResourceTypeID == Convert.ToInt16(Models.ResourceType.Interest).ToString())
                        {
                            string filepath = Path.Combine(absolutePath, obj.S3ID);
                            string thumbnailsource = string.Empty;
                            var thumbimage = obj.S3ID.Replace("mp4", "png");
                            var status = obj.Status;
                            if (DependencyService.Get<IThumbnailManager>().CheckFileExist(Path.Combine(absolutePath, thumbimage)))
                                thumbnailsource = Path.Combine(absolutePath, thumbimage);
                            string S3thumbnailsource = Services.S3Manager.GeneratePreSignedURL(AmazonS3BucketDetails.PhotoBucket, thumbimage, 60);
                            VideoFileDetails objVideoFileDetails = new VideoFileDetails();
                            objVideoFileDetails.FilePath = filepath;
                            objVideoFileDetails.S3URLPath = obj.ResourceURL;
                            objVideoFileDetails.FileName = obj.S3ID;
                            objVideoFileDetails.S3ThumbnailImage = S3thumbnailsource;
                            objVideoFileDetails.ReasonForBlocked = obj.ReasonForBlock;
                            _interestVideoBlockedReason = obj.ReasonForBlock;
                            objVideoFileDetails.FileType = Constants.VideoType.MyInterestsVideo;
                            objVideoFileDetails.IsUploaded = true;
                            SetStatus("AreaofInterest", status);
                            AppSessionData.InterestMeVideoStatus = status;
                            if (status != "-1")
                            {
                                ImageSourceInterest = S3thumbnailsource;

                            }
                            AppSessionData.InterestsVideo = objVideoFileDetails;
                            objVideoFileDetails.ThumbnailImage = thumbnailsource;
                            // SetThumbnaiImage(Constants.VideoType.MyInterestsVideo);
                        }
                    }
                }
                else
                {
                    AppSessionData.AboutMeVideo = null;
                    AppSessionData.SkillVideo = null;
                    AppSessionData.InterestsVideo = null;
                }
                // }
            }
            catch (Exception)
            {

                throw;
            }
        }


        #endregion

        #region Progress Events
        private double _aboutMeprogress;
        public double AboutMeProgress
        {
            get { return _aboutMeprogress; }
            set
            {
                if (this._aboutMeprogress != value)
                {
                    this._aboutMeprogress = value;
                    OnPropertyChanged();
                }

            }
        }
        private double _interestProgress;
        public double InterestProgress
        {
            get { return _interestProgress; }
            set
            {
                if (this._interestProgress != value)
                {
                    this._interestProgress = value;
                    OnPropertyChanged();
                }

            }
        }
        private double _skillprogress;
        public double SkillProgress
        {
            get { return _skillprogress; }
            set
            {
                if (this._skillprogress != value)
                {
                    this._skillprogress = value;
                    OnPropertyChanged();
                }

            }
        }

        void uploadRequest_UploadAboutmePartProgressEvent(object sender, Amazon.S3.Transfer.UploadProgressArgs e)
        {

            try
            {
                Debug.WriteLine("@ VideoProfilePage.uploadRequest_UploadAboutmePartProgressEvent");
                double percent = e.PercentDone / 100.0;
                var value = e.PercentDone - 1;
                Device.BeginInvokeOnMainThread(() => { AboutmeVideoProgress = value.ToString() + "%"; });
                AboutMeProgress = percent;
                // progressbarAboutmeUpload.ProgressTo(percent, 250, Easing.Linear);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerVideoProfileViewModel.uploadRequest_UploadAboutmePartProgressEvent");
            }

        }
        void uploadRequest_UploadSkillPartProgressEvent(object sender, Amazon.S3.Transfer.UploadProgressArgs e)
        {
            try
            {
                System.Diagnostics.Debug.WriteLine("@ VideoProfilePage.uploadRequest_UploadSkillPartProgressEvent");
                double percent = e.PercentDone / 100.0;
                var value = e.PercentDone - 1;
                Device.BeginInvokeOnMainThread(() => { SkillVideoProgress = value.ToString() + "%"; });
                SkillProgress = percent;
                // ProgressPercent.ProgressTo(percent, 250, Easing.Linear);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerVideoProfileViewModel.uploadRequest_UploadSkillPartProgressEvent");
            }

        }
        void uploadRequest_UploadInterestPartProgressEvent(object sender, Amazon.S3.Transfer.UploadProgressArgs e)
        {
            try
            {
                System.Diagnostics.Debug.WriteLine("@ VideoProfilePage.uploadRequest_UploadInterestPartProgressEvent");
                double percent = e.PercentDone / 100.0;
                var value = e.PercentDone - 1;
                Device.BeginInvokeOnMainThread(() => { InterestvideoProgress = value.ToString() + "%"; });
                InterestProgress = percent;
                // progressbarInterestUpload.ProgressTo(percent, 250, Easing.Linear);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerVideoProfileViewModel.uploadRequest_UploadInterestPartProgressEvent");
            }

        }
        #endregion

        #region Video Status

        public void SetStatus(string videotype, string videostatus)
        {
            if (videotype.Equals("Introduction"))
            {

                if (videostatus == "1")
                {
                    IntroductionSign = (string)Application.Current.Resources["ApprovedSign"];
                    IntroductionSignColor = Color.Green;
                    IntroductionSignIsVisible = true;
                }
                else if (videostatus == "0")
                {
                    IntroductionSign = (string)Application.Current.Resources["AwaitingSign"];
                    IntroductionSignColor = Color.Yellow;
                    IntroductionSignIsVisible = true;
                }
                else if (videostatus == "-1")
                {
                    IntroductionSign = (string)Application.Current.Resources["RejectedSign"];
                    IntroductionSignColor = Color.Red;
                    IntroductionSignIsVisible = true;
                }


            }
            else if (videotype.Equals("MySkills"))
            {

                if (videostatus == "1")
                {

                    SkillSign = (string)Application.Current.Resources["ApprovedSign"];
                    SkillSignColor = Color.Green;
                    SkillSignIsVisible = true;

                }
                else if (videostatus == "0")
                {
                    SkillSign = (string)Application.Current.Resources["AwaitingSign"];
                    SkillSignColor = Color.Yellow;
                    SkillSignIsVisible = true;

                }
                else if (videostatus == "-1")
                {

                    SkillSign = (string)Application.Current.Resources["RejectedSign"];
                    SkillSignColor = Color.Red;
                    SkillSignIsVisible = true;
                }

            }
            else if (videotype.Equals("AreaofInterest"))
            {

                if (videostatus == "1")
                {

                    InterestSign = (string)Application.Current.Resources["ApprovedSign"];
                    InterestSignColor = Color.Green;
                    InterestSignIsVisible = true;
                }
                else if (videostatus == "0")
                {
                    InterestSign = (string)Application.Current.Resources["AwaitingSign"];
                    InterestSignColor = Color.Yellow;
                    InterestSignIsVisible = true;
                }
                else if (videostatus == "-1")
                {

                    InterestSign = (string)Application.Current.Resources["RejectedSign"];
                    InterestSignColor = Color.Red;
                    InterestSignIsVisible = true;
                }
            }
        }
        #endregion

        #region VideoRecordCompleted
        private void ObjInterestsVideoRecorder_VideoRecordCompleted(VideoRecordEventArgs eventargs)
        {
            _introductionSignIsVisible = false;
            var obj = new VideoFileDetails();
            obj.FilePath = eventargs.RecordedVideoFilePath;
            obj.FileName = Path.GetFileName(eventargs.RecordedVideoFilePath);
            obj.FileType = "InterestsVideo";
            AppSessionData.InterestsVideo = obj;
            AppSessionData.InterestMeVideoStatus = "0";
            if (string.IsNullOrEmpty(AppSessionData.InterestsVideo.ThumbnailImage))
                SetThumbnaiImage(Constants.VideoType.MyInterestsVideo);
            else
                ImageSourceInterest = AppSessionData.InterestsVideo.ThumbnailImage;

            canUploadInterestsVideo = true;
            AppPreferences.CanUploadInterestsVideo = canUploadInterestsVideo;


        }

        private void ObjSkillVideoRecorder_VideoRecordCompleted(VideoRecordEventArgs eventargs)
        {

            var obj = new VideoFileDetails();
            _skillSignIsVisible = false;
            obj.FilePath = eventargs.RecordedVideoFilePath;
            obj.FileName = Path.GetFileName(eventargs.RecordedVideoFilePath);
            obj.FileType = "SkillVideo";
            AppSessionData.SkillVideo = obj;
            AppSessionData.SkillVideoStatus = "0";
            if (string.IsNullOrEmpty(AppSessionData.SkillVideo.ThumbnailImage))
                SetThumbnaiImage(Constants.VideoType.MySkillsVideo);
            else
                ImageSourceSkill = AppSessionData.SkillVideo.ThumbnailImage;
            canUploadSkillVideo = true;
            AppPreferences.CanUploadSkillVideo = canUploadSkillVideo;

        }

        private void ObjAboutMeVideoRecorder_VideoRecordCompleted(VideoRecordEventArgs eventargs)
        {
            var obj = new VideoFileDetails();
            _introductionSignIsVisible = false;
            obj.FilePath = eventargs.RecordedVideoFilePath;
            obj.FileName = Path.GetFileName(eventargs.RecordedVideoFilePath);
            obj.FileType = "AboutMeVideo";
            AppSessionData.AboutMeVideo = obj;
            AppSessionData.AboutMeVideoStatus = "0";
            canUploadAboutMeVideo = true;
            AppPreferences.CanUploadAboutMeVideo = canUploadAboutMeVideo;
            if (string.IsNullOrEmpty(AppSessionData.AboutMeVideo.ThumbnailImage))
                SetThumbnaiImage(Constants.VideoType.AboutMeVideo);
            else
                ImageSourceYourSelf = AppSessionData.AboutMeVideo.ThumbnailImage;

        }
        #endregion

        #region Set Thumbnail Image to Image Source
        private void SetThumbnaiImage(string typeofvideo)
        {
            System.Diagnostics.Debug.WriteLine("@ VideoProfilePage.SetThumbnaiImage");
            try
            {
                if (typeofvideo.Equals(Constants.VideoType.AboutMeVideo))
                {
                    //if (AppSessionData.AboutMeVideo.FilePath != null && string.IsNullOrEmpty(AppSessionData.AboutMeVideo.ThumbnailImage))
                    //{
                    var imagebytes = DependencyService.Get<IThumbnailManager>().GetThumbnailImage(AppSessionData.AboutMeVideo.FilePath, 0, 60);
                    if (imagebytes == null)
                    { return; }

                    var thumbmailimagename = AppSessionData.AboutMeVideo.FileName.Replace("mp4", "png");
                    var thumbnailimage = DependencyService.Get<IImageManager>().SaveImageBytes(imagebytes, thumbmailimagename);
                    var AboutMeVideo = AppSessionData.AboutMeVideo;
                    AboutMeVideo.ThumbnailImage = thumbnailimage;
                    AppSessionData.AboutMeVideo = AboutMeVideo;

                    // DependencyService.Get<IImageManager>().CleanUpMediaFiles();

                    //}
                    //if (!string.IsNullOrEmpty(AppSessionData.AboutMeVideo.ThumbnailImage))
                    //{

                    ImageSourceYourSelf = AppSessionData.AboutMeVideo.ThumbnailImage;
                    //}
                }
                else if (typeofvideo.Equals(Constants.VideoType.MySkillsVideo))
                {
                    //if (AppSessionData.SkillVideo.FilePath != null && string.IsNullOrEmpty(AppSessionData.SkillVideo.ThumbnailImage))
                    //{
                    var imagebytes = DependencyService.Get<IThumbnailManager>().GetThumbnailImage(AppSessionData.SkillVideo.FilePath, 0, 60);
                    if (imagebytes == null)
                    { return; }
                    var thumbmailimagename = AppSessionData.SkillVideo.FileName.Replace("mp4", "png");
                    var thumbnailimage = DependencyService.Get<IImageManager>().SaveImageBytes(imagebytes, thumbmailimagename);

                    var skill = AppSessionData.SkillVideo;
                    skill.ThumbnailImage = thumbnailimage;
                    AppSessionData.SkillVideo = skill;
                    // DependencyService.Get<IImageManager>().CleanUpMediaFiles();
                    //}
                    //if (!string.IsNullOrEmpty(AppSessionData.SkillVideo.ThumbnailImage))
                    //{
                    ImageSourceSkill = AppSessionData.SkillVideo.ThumbnailImage;
                    //}
                }
                else if (typeofvideo.Equals(Constants.VideoType.MyInterestsVideo))
                {
                    //if (AppSessionData.InterestsVideo.FilePath != null && string.IsNullOrEmpty(AppSessionData.InterestsVideo.ThumbnailImage))
                    //{
                    var imagebytes = DependencyService.Get<IThumbnailManager>().GetThumbnailImage(AppSessionData.InterestsVideo.FilePath, 0, 60);
                    if (imagebytes == null)
                    { return; }
                    var thumbmailimagename = AppSessionData.InterestsVideo.FileName.Replace("mp4", "png");
                    var thumbnailimage = DependencyService.Get<IImageManager>().SaveImageBytes(imagebytes, thumbmailimagename);

                    var InterestsVideo = AppSessionData.InterestsVideo;
                    InterestsVideo.ThumbnailImage = thumbnailimage;
                    AppSessionData.InterestsVideo = InterestsVideo;
                    //DependencyService.Get<IImageManager>().CleanUpMediaFiles();
                    //}

                    //if (!string.IsNullOrEmpty(AppSessionData.InterestsVideo.ThumbnailImage))
                    //{
                    ImageSourceInterest = AppSessionData.InterestsVideo.ThumbnailImage;
                    //}
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                //SendErrorMessageToServer(ex, "SeekerVideoProfileViewModel.SetThumbnaiImage");
            }
        }
        #endregion

        #region RecordRecognizer_Tapped
        private async Task RecordRecognizer_Tapped(string VideoType)
        {
            if (isClicked)
            {
                isClicked = false;
                if (objAboutMyselfData.MaxRecordTime == null)
                {
                    UserDialogs.Instance.ShowLoading();
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await GetUserResourceRetrivalData();
                    });

                    await Task.Delay(500);
                    UserDialogs.Instance.HideLoading();
                }
                try
                {
                    var camerastatus = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Camera);
                    var microphonestatus = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Microphone);
                    if (camerastatus != PermissionStatus.Granted || microphonestatus != PermissionStatus.Granted)
                    {
                        if (await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Camera))
                        {
                            await UserDialogs.Instance.AlertAsync("Need Camera Permission", "Access Camera", "OK");
                        }

                        if (await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Microphone))
                        {
                            await UserDialogs.Instance.AlertAsync(" Need Microphone Permission", "Access Microphone", "OK");
                        }

                        var results = await CrossPermissions.Current.RequestPermissionsAsync(new[] { Permission.Camera, Permission.Microphone });
                        camerastatus = results[Permission.Camera];
                        microphonestatus = results[Permission.Microphone];
                    }
                    if (camerastatus == PermissionStatus.Granted && microphonestatus == PermissionStatus.Granted)
                    {
                        Debug.WriteLine("@ VideoProfilePage.RecordRecognizer_Tapped");


                        if (VideoType == "AboutMeVideo")
                        {
                            var aboutMeVideoStatus = AppSessionData.AboutMeVideoStatus;
                            if (aboutMeVideoStatus == "1")
                            {

                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.AboutVideoApprovedStatus);
                            }
                            else
                            {
                                var filename = AppSessionData.ActiveToken.HireMeID + "_" + "aboutme" + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".mp4";
                                var filePath = Path.Combine(absolutePath, filename);
                                var OS = Device.RuntimePlatform;
                                #region Ios
                                //if (Device.RuntimePlatform.Equals("iOS"))
                                //{
                                //    var file = await RecordVideoFile(filename, Convert.ToInt32(objAboutMyselfData.MaxRecordTime));
                                //    if (file != null)
                                //    {
                                //        VideoFileDetails obj = new VideoFileDetails();
                                //        obj.FilePath = file.FilePath;
                                //        obj.FileName = file.FileName;
                                //        obj.FileType = "AboutMeVideo";
                                //        obj.ThumbnailImage = file.ThumbnailImage;
                                //        AppSessionData.AboutMeVideo = obj;
                                //        ImageSourceYourSelf = string.IsNullOrEmpty(AppSessionData.AboutMeVideo.ThumbnailImage) ? string.Empty : AppSessionData.AboutMeVideo.ThumbnailImage;
                                //        canUploadAboutMeVideo = true;
                                //        AppPreferences.CanUploadAboutMeVideo = canUploadAboutMeVideo;
                                //        AppSessionData.AboutMeVideoStatus = 0;
                                //    }
                                //}
                                #endregion
                                #region Android
                                //else if (Device.RuntimePlatform.Equals("Android"))
                                //{
                                var objAboutMeVideoRecorder = new CustomRecorder();
                                objAboutMeVideoRecorder.VideoRecordCompleted += ObjAboutMeVideoRecorder_VideoRecordCompleted;
                                objAboutMeVideoRecorder.FileSource = filePath;
                                objAboutMeVideoRecorder.MaxDurationSeconds = Convert.ToInt32(objAboutMyselfData.MaxRecordTime);
                                if (objAboutMeVideoRecorder.MaxDurationSeconds == 0)
                                {
                                    await GetUserResourceRetrivalData();
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                                }
                                else
                                {
                                    await navigation.PushModalAsync(objAboutMeVideoRecorder);
                                }
                                //}
                            }
                        }
                        #endregion


                        else if (VideoType == "SkillVideo")
                        {
                            var skillVideoStatus = AppSessionData.SkillVideoStatus;
                            if (skillVideoStatus == "1")
                            {

                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.SkillVideoApprovedStatus);
                            }
                            else
                            {
                                var ts = DateTime.Now.ToString("yyyyMMddHHmmss");
                                var filename = AppSessionData.ActiveToken.HireMeID + "_" + "skill" + "_" + ts + ".mp4";
                                var filePath = Path.Combine(absolutePath, filename);
                                #region iOS
                                //if (Device.RuntimePlatform.Equals("iOS"))
                                //{
                                //    var file = await RecordVideoFile(filename, Convert.ToInt32(objSkillData.MaxRecordTime));
                                //    if (file != null)
                                //    {
                                //        var obj = new VideoFileDetails();
                                //        obj.FilePath = file.FilePath;
                                //        obj.FileName = file.FileName;
                                //        obj.FileType = "SkillVideo";
                                //        obj.ThumbnailImage = file.ThumbnailImage;
                                //        AppSessionData.SkillVideo = obj;
                                //        ImageSourceSkill = string.IsNullOrEmpty(file.ThumbnailImage) ? string.Empty : file.ThumbnailImage;
                                //        canUploadSkillVideo = true;
                                //        AppPreferences.CanUploadSkillVideo = canUploadSkillVideo;
                                //        AppSessionData.SkillVideoStatus = 0;
                                //    }
                                //}
                                #endregion

                                #region Android
                                //else if (Device.RuntimePlatform.Equals("Android"))
                                //{
                                var objSkillVideoRecorder = new CustomRecorder();
                                objSkillVideoRecorder.VideoRecordCompleted += ObjSkillVideoRecorder_VideoRecordCompleted;
                                objSkillVideoRecorder.FileSource = filePath;
                                objSkillVideoRecorder.MaxDurationSeconds = Convert.ToInt32(objSkillData.MaxRecordTime);
                                if (objSkillVideoRecorder.MaxDurationSeconds == 0)
                                {
                                    //await GetUserResouceConfigDetails();
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                                }
                                else
                                {
                                    await navigation.PushModalAsync(objSkillVideoRecorder);
                                }
                                //}
                            }
                        }
                        #endregion


                        else if (VideoType == "InterestVideo")
                        {
                            var interestVideoStatus = AppSessionData.InterestMeVideoStatus;
                            if (interestVideoStatus == "1")
                            {

                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.AreaOfInterestVideoApprovedStatus);
                            }
                            else
                            {
                                var filename = AppSessionData.ActiveToken.HireMeID + "_" + "interests" + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".mp4";
                                var filePath = System.IO.Path.Combine(absolutePath, filename);
                                #region iOS
                                //if (Device.RuntimePlatform.Equals("iOS"))
                                //{
                                //    var file = await RecordVideoFile(filename, Convert.ToInt32(objAmbitionData.MaxRecordTime));
                                //    if (file != null)
                                //    {
                                //        var obj = new VideoFileDetails();
                                //        obj.FilePath = file.FilePath;
                                //        obj.FileName = file.FileName;
                                //        obj.FileType = "InterestsVideo";
                                //        obj.ThumbnailImage = file.ThumbnailImage;
                                //        AppSessionData.InterestsVideo = obj;
                                //        ImageSourceInterest = string.IsNullOrEmpty(AppSessionData.InterestsVideo.ThumbnailImage) ? string.Empty : AppSessionData.InterestsVideo.ThumbnailImage;
                                //        canUploadInterestsVideo = true;
                                //        AppPreferences.CanUploadInterestsVideo = canUploadInterestsVideo;
                                //        AppSessionData.InterestMeVideoStatus = 0;
                                //    }
                                //}
                                #endregion

                                #region Android
                                //else if (Device.RuntimePlatform.Equals("Android"))
                                //{
                                var objInterestsVideoRecorder = new CustomRecorder();
                                objInterestsVideoRecorder.VideoRecordCompleted += ObjInterestsVideoRecorder_VideoRecordCompleted;
                                objInterestsVideoRecorder.FileSource = filePath;
                                objInterestsVideoRecorder.MaxDurationSeconds = Convert.ToInt32(objAmbitionData.MaxRecordTime);
                                if (objInterestsVideoRecorder.MaxDurationSeconds == 0)
                                {
                                    // await GetUserResouceConfigDetails();
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                                }
                                else
                                {
                                    await navigation.PushModalAsync(objInterestsVideoRecorder);
                                }
                                //}
                            }

                        }
                        #endregion

                    }

                    else if (camerastatus != PermissionStatus.Unknown || microphonestatus != PermissionStatus.Unknown)
                    {
                        UserDialogs.Instance.Toast(MessageStringConstants.PermissionMessage);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                    SendErrorMessageToServer(ex, "SeekerVideoProfileViewModel.RecordRecognizer_Tapped");
                }
            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });
        }


        #endregion

        #region Record Video iOS
        async public Task<VideoFileDetails> RecordVideoFile(string filename, int MaxTime, int compressquality = 80, VideoQuality quality = VideoQuality.Medium)
        {
            System.Diagnostics.Debug.WriteLine("@ VideoProfilePage.RecordVideoFile");
            if (MaxTime == 0)
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                return null;
            }

            MediaFile file = null;
            VideoFileDetails recordedfile = new VideoFileDetails();
            recordedfile.FileName = filename;

            try
            {
                if (!CrossMedia.Current.IsCameraAvailable || !CrossMedia.Current.IsTakeVideoSupported)
                {
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CameraUnavailable);
                    return null;
                }
                TimeSpan DesiredLength = TimeSpan.FromSeconds(MaxTime);
                await Task.Delay(1000);
                file = await CrossMedia.Current.TakeVideoAsync(new StoreVideoOptions
                {
                    CompressionQuality = compressquality,
                    DefaultCamera = CameraDevice.Front,
                    DesiredLength = DesiredLength,
                    Directory = "HireMee",
                    Name = filename,
                    PhotoSize = PhotoSize.Medium,
                    Quality = quality,
                });

                #region Null Check

                if (file == null)
                {
                    return null;
                }

                #endregion
                // Copy to local

                recordedfile.FilePath = DependencyService.Get<IImageManager>().CopyFile(file.Path, filename);
                recordedfile.FileName = filename;
                var imagebytes = DependencyService.Get<IThumbnailManager>().GetThumbnailImage(recordedfile.FilePath, 0, 1);
                var thumbnailpath = recordedfile.FilePath.Replace("mp4", "png");
                recordedfile.ThumbnailImage = DependencyService.Get<IImageManager>().SaveImageBytes(imagebytes, thumbnailpath);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("EXCEPTION {0}:  {1}", DateTime.Now, ex.StackTrace);
                SendErrorMessageToServer(ex, "SeekerVideoProfileViewModel.RecordVideoFile");
            }
            finally
            {
                if (file != null)
                {
                    file.Dispose();
                }
            }

            return recordedfile;
        }
        #endregion

        #region Upload Videos

        public async Task UploadRecognizer_Tapped(string sender)
        {
            if (isClicked)
            {
                isClicked = false;
                var isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (!isNetworkAvailable)
                {
                    UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                    return;
                }

                if (string.IsNullOrEmpty(AppPreferences.S3SecretAccessKey))
                {
                    var s3 = new S3Utils();
                    await s3.GetS3Credentials();
                }
                var ResourceTypeID = string.Empty;
                switch (sender)
                {
                    case "AboutMeVideo":

                        var aboutMeVideoStatus = AppSessionData.AboutMeVideoStatus;
                        if (aboutMeVideoStatus == "1")
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.AboutVideoApprovedStatus);

                        }
                        else
                        {


                            if (AppSessionData.AboutMeVideo != null && AppSessionData.AboutMeVideo.FileName != null)
                            {
                                foreach (var p in ltUserResourceType)
                                {
                                    if (p.Name == "aboutmyself")
                                    {
                                        ResourceTypeID = p.ID;
                                        break;
                                    }
                                }
                                var AboutMeFileName = AppSessionData.AboutMeVideo.FileName;
                                if (AppSessionData.AboutMeVideo.FilePath == null)
                                {
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.RecordNewVideo);
                                }
                                else if (DependencyService.Get<IThumbnailManager>().CheckFileExist(AppSessionData.AboutMeVideo.FilePath))
                                {
                                    if (canUploadAboutMeVideo)
                                    {

                                        if (Device.RuntimePlatform.Equals("Android"))
                                        {
                                            var result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.EnsureVideoQuality, "Alert", "Yes", "No");
                                            if (!result) return;
                                        }
                                        else
                                        {
                                            var result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.EnsureVideoQuality, "Alert", "Yes", "No");
                                            if (!result) return;
                                        }
                                        canUploadAboutMeVideo = false;
                                        AppPreferences.CanUploadAboutMeVideo = canUploadAboutMeVideo;
                                        //await progressbarInterestUpload.ProgressTo(0, 250, Easing.SpringIn);
                                        await UploadVideoFile(AppSessionData.AboutMeVideo.FilePath, AppSessionData.AboutMeVideo.FileName, ResourceTypeID, Constants.VideoType.AboutMeVideo, AppSessionData.AboutMeVideo.ThumbnailImage);

                                    }
                                    else
                                    {
                                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.VideoAlreadyExist);
                                    }

                                }
                                else
                                {
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.AboutVideoApprovedStatus);
                                }
                            }
                            else
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.RecordNewVideo);

                            }
                            //var filename = AppSessionData.AboutMeVideo.FileName;

                            //if (AppSessionData.AboutMeVideo.S3URLPath == null || !AppSessionData.AboutMeVideo.S3URLPath.Contains(filename))
                            //{
                            //    if (canUploadAboutMeVideo)
                            //    {
                            //        if (Device.RuntimePlatform.Equals("Android"))
                            //        {
                            //            var result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.EnsureVideoQuality, "Alert", "Yes", "No");
                            //            if (!result) return;
                            //        }
                            //        else
                            //        {
                            //            var result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.EnsureVideoQuality, "Alert", "Yes", "No");
                            //        }

                            //        if (DependencyService.Get<IThumbnailManager>().CheckFileExist(AppSessionData.AboutMeVideo.FilePath))
                            //        {
                            //            canUploadAboutMeVideo = false;
                            //            AppPreferences.CanUploadAboutMeVideo = canUploadAboutMeVideo;
                            //            //await progressbarAboutmeUpload.ProgressTo(0, 250, Easing.SpringIn);
                            //            await UploadVideoFile(AppSessionData.AboutMeVideo.FilePath, AppSessionData.AboutMeVideo.FileName, ResourceTypeID, Constants.VideoType.AboutMeVideo, AppSessionData.AboutMeVideo.ThumbnailImage);
                            //        }
                            //    }
                            //    else
                            //    {
                            //        await UserDialogs.Instance.AlertAsync(MessageStringConstants.VideoAlreadyExist);

                            //    }
                            //}
                            //else
                            //{

                            //    await UserDialogs.Instance.AlertAsync(MessageStringConstants.RecordNewVideo);

                            //}

                        }
                        break;

                    case "SkillVideo":
                        var skillVideoStatus = AppSessionData.SkillVideoStatus;
                        if (skillVideoStatus == "1")
                        {

                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.SkillVideoApprovedStatus);
                        }
                        else
                        {

                            if (AppSessionData.SkillVideo != null && AppSessionData.SkillVideo.FileName != null)
                            {
                                foreach (var p in ltUserResourceType)
                                {
                                    if (p.Name == "skill")
                                    {
                                        ResourceTypeID = p.ID;
                                        break;
                                    }
                                }
                                var SkillFileName = AppSessionData.SkillVideo.FileName;
                                if (AppSessionData.SkillVideo.FilePath == null)
                                {
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.RecordNewVideo);
                                }
                                else if (DependencyService.Get<IThumbnailManager>().CheckFileExist(AppSessionData.SkillVideo.FilePath))
                                {
                                    if (canUploadSkillVideo)
                                    {

                                        if (Device.RuntimePlatform.Equals("Android"))
                                        {
                                            var result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.EnsureVideoQuality, "Alert", "Yes", "No");
                                            if (!result) return;
                                        }
                                        else
                                        {
                                            var result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.EnsureVideoQuality, "Alert", "Yes", "No");
                                            if (!result) return;
                                        }
                                        canUploadSkillVideo = false;
                                        AppPreferences.CanUploadSkillVideo = canUploadSkillVideo;
                                        //await progressbarInterestUpload.ProgressTo(0, 250, Easing.SpringIn);
                                        await UploadVideoFile(AppSessionData.SkillVideo.FilePath, AppSessionData.SkillVideo.FileName, ResourceTypeID, Constants.VideoType.MySkillsVideo, AppSessionData.SkillVideo.ThumbnailImage);

                                    }
                                    else
                                    {
                                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.VideoAlreadyExist);
                                    }

                                }
                                else
                                {
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.SkillVideoApprovedStatus);
                                }
                            }
                            else
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.RecordNewVideo);

                            }
                            //var filename = AppSessionData.SkillVideo.FileName;
                            //if (AppSessionData.SkillVideo.S3URLPath == null || !AppSessionData.SkillVideo.S3URLPath.Contains(filename))
                            //{
                            //    if (canUploadSkillVideo)
                            //    {
                            //        if (Device.RuntimePlatform.Equals("Android"))
                            //        {
                            //            var result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.EnsureVideoQuality, "Alert", "Yes", "No");
                            //            if (!result) return;
                            //        }
                            //        else
                            //        {
                            //            var result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.EnsureVideoQuality, "Alert", "Yes", "No");
                            //            if (!result) return;
                            //        }
                            //        if (DependencyService.Get<IThumbnailManager>().CheckFileExist(AppSessionData.SkillVideo.FilePath))
                            //        {
                            //            canUploadSkillVideo = false;
                            //            AppPreferences.CanUploadSkillVideo = canUploadSkillVideo;
                            //            // await progressbarSkillUpload.ProgressTo(0, 250, Easing.SpringIn);
                            //            await UploadVideoFile(AppSessionData.SkillVideo.FilePath, AppSessionData.SkillVideo.FileName, ResourceTypeID, Constants.VideoType.MySkillsVideo, AppSessionData.SkillVideo.ThumbnailImage);
                            //        }
                            //    }
                            //    else
                            //    {
                            //        await UserDialogs.Instance.AlertAsync(MessageStringConstants.VideoAlreadyExist);

                            //    }
                            //}
                            //else
                            //{
                            //    await UserDialogs.Instance.AlertAsync(MessageStringConstants.RecordNewVideo);

                            //}

                        }
                        break;
                    case "InterestVideo":
                        var interestVideoStatus = AppSessionData.InterestMeVideoStatus;
                        if (interestVideoStatus == "1")
                        {

                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.AreaOfInterestVideoApprovedStatus);
                        }
                        else
                        {


                            //    if (AppSessionData.InterestsVideo.S3URLPath == null || !AppSessionData.InterestsVideo.S3URLPath.Contains(InterestFileName))
                            //    {
                            //        if (canUploadInterestsVideo)
                            //        {

                            //            if (Device.RuntimePlatform.Equals("Android"))
                            //            {
                            //                var result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.EnsureVideoQuality, "Alert", "Yes", "No");
                            //                if (!result) return;
                            //            }
                            //            else
                            //            {
                            //                var result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.EnsureVideoQuality, "Alert", "Yes", "No");
                            //                if (!result) return;
                            //            }


                            //            if (DependencyService.Get<IThumbnailManager>().CheckFileExist(AppSessionData.InterestsVideo.FilePath))
                            //            {
                            //                canUploadInterestsVideo = false;
                            //                AppPreferences.CanUploadInterestsVideo = canUploadInterestsVideo;
                            //                //await progressbarInterestUpload.ProgressTo(0, 250, Easing.SpringIn);
                            //                await UploadVideoFile(AppSessionData.InterestsVideo.FilePath, AppSessionData.InterestsVideo.FileName, ResourceTypeID, Constants.VideoType.MyInterestsVideo, AppSessionData.InterestsVideo.ThumbnailImage);
                            //            }
                            //            else
                            //            {
                            //                await UserDialogs.Instance.AlertAsync(MessageStringConstants.VideoAlreadyExist);

                            //            }
                            //        }
                            //        else
                            //        {
                            //            await UserDialogs.Instance.AlertAsync(MessageStringConstants.RecordNewVideo);

                            //        }
                            //    }
                            //    else
                            //    {
                            //        await UserDialogs.Instance.AlertAsync(MessageStringConstants.RecordNewVideo);

                            //    }

                            //}
                            //else
                            //{
                            //    await UserDialogs.Instance.AlertAsync(MessageStringConstants.RecordNewVideo);

                            //}
                            if (AppSessionData.InterestsVideo != null && AppSessionData.InterestsVideo.FileName != null)
                            {
                                foreach (var p in ltUserResourceType)
                                {
                                    if (p.Name == "ambition")
                                    {
                                        ResourceTypeID = p.ID;
                                        break;
                                    }
                                }

                                var InterestFileName = AppSessionData.InterestsVideo.FileName;
                                if (AppSessionData.InterestsVideo.FilePath == null)
                                {
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.RecordNewVideo);
                                }
                                else if (DependencyService.Get<IThumbnailManager>().CheckFileExist(AppSessionData.InterestsVideo.FilePath))
                                {
                                    if (canUploadInterestsVideo)
                                    {

                                        if (Device.RuntimePlatform.Equals("Android"))
                                        {
                                            var result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.EnsureVideoQuality, "Alert", "Yes", "No");
                                            if (!result) return;
                                        }
                                        else
                                        {
                                            var result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.EnsureVideoQuality, "Alert", "Yes", "No");
                                            if (!result) return;
                                        }



                                        canUploadInterestsVideo = false;
                                        AppPreferences.CanUploadInterestsVideo = canUploadInterestsVideo;
                                        //await progressbarInterestUpload.ProgressTo(0, 250, Easing.SpringIn);
                                        await UploadVideoFile(AppSessionData.InterestsVideo.FilePath, AppSessionData.InterestsVideo.FileName, ResourceTypeID, Constants.VideoType.MyInterestsVideo, AppSessionData.InterestsVideo.ThumbnailImage);

                                    }
                                    else
                                    {
                                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.VideoAlreadyExist);
                                    }

                                }
                                else
                                {
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.AreaOfInterestVideoApprovedStatus);
                                }
                            }
                            else
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.RecordNewVideo);
                            }
                        }
                        break;
                }
            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });
        }
        #endregion

        #region UploadVideo to S3 Bucket

        public async Task<string> UploadFileAsync(string filepath, string filekey, string bucket, string fileType)
        {
            Debug.WriteLine("@ VideoProfilePage.UploadFileAsync");
            try
            {
                Amazon.S3.Transfer.TransferUtilityUploadRequest _request = new Amazon.S3.Transfer.TransferUtilityUploadRequest();
                _request.BucketName = bucket;
                _request.FilePath = filepath;
                _request.Key = filekey;
                _request.CannedACL = S3CannedACL.AuthenticatedRead;
                _request.ContentType = "video/mp4";
                if (fileType == Constants.VideoType.AboutMeVideo)
                {
                    _request.UploadProgressEvent += uploadRequest_UploadAboutmePartProgressEvent;
                }
                if (fileType == Constants.VideoType.MySkillsVideo)
                {
                    _request.UploadProgressEvent += uploadRequest_UploadSkillPartProgressEvent;
                }
                if (fileType == Constants.VideoType.MyInterestsVideo)
                {
                    _request.UploadProgressEvent += uploadRequest_UploadInterestPartProgressEvent;
                }

                if (string.IsNullOrEmpty(AppPreferences.S3AccessKeyID) || string.IsNullOrEmpty(AppPreferences.S3SecretAccessKey))
                {
                    S3Utils s3 = new S3Utils();
                    await s3.GetS3Credentials();
                }

                using (Amazon.S3.Transfer.TransferUtility _transferUtility = new Amazon.S3.Transfer.TransferUtility(S3Utils.S3Client))
                {
                    await _transferUtility.UploadAsync(_request);
                }
                GetPreSignedUrlRequest request = new GetPreSignedUrlRequest();
                request.BucketName = bucket;
                request.Key = filekey;
                request.Expires = DateTime.Now.AddMilliseconds(60000);
                request.Protocol = Protocol.HTTP;
                string url = S3Utils.S3Client.GetPreSignedURL(request);
                return url;

            }
            catch (Amazon.S3.AmazonS3Exception exception)
            {
                Debug.WriteLine("AMAZON-S3-EXCEPTION: Could not process upload request" + exception.StackTrace);
                SendErrorMessageToServer(exception, "SeekerVideoProfileViewModel.UploadFileAsync");
                return "Error";

            }
        }

        async public Task<VideoFileDetails> UploadVideoFile(string filePath, string filename, string ResourceTypeID, string fileType, string thumnailimagepath)
        {

            VideoFileDetails recordedfile = new VideoFileDetails();
            try
            {
                if (!string.IsNullOrEmpty(filePath) && !string.IsNullOrEmpty(filename) && !string.IsNullOrEmpty(ResourceTypeID) && !string.IsNullOrEmpty(fileType) && !string.IsNullOrEmpty(thumnailimagepath))
                {
                    Debug.WriteLine("@ VideoProfilePage.UploadVideoFile");

                    var responseData = await UploadFileAsync(filePath, filename, AmazonS3BucketDetails.VideoBucket, fileType);

                    var s3thumbnailfileurl = await S3Manager.UploadFile(thumnailimagepath, Path.GetFileName(thumnailimagepath), AmazonS3BucketDetails.PhotoBucket);

                    //  var thumbnail = s3thumbnailfileurl;

                    if (responseData != null && !responseData.Contains("Error"))
                    {
                        UserResourceInsertRequestData data = new UserResourceInsertRequestData();
                        data.ResourceTypeId = ResourceTypeID;
                        data.s3Id = filename;
                        //data.ResourceUrl = Path.Combine(APIData.S3VideoURL, filename);
                        data.ResourceUrl = responseData;
                        data.ThumbnailUrl = s3thumbnailfileurl;
                        HttpCommonService _commonservice = new HttpCommonService();
                        var statusResult = await _commonservice.PostAsync<UserResourceInsertResponseData, UserResourceInsertRequestData>(APIData.API_BASE_URL + APIMethods.UserResourceInsert, data);

                        if (statusResult != null)
                        {
                            if (statusResult.code == "200")
                            {
                                AppPreferences.IsSeekerDashboardDataDownloaded = false;
                                if (fileType == Constants.VideoType.AboutMeVideo)
                                {
                                    if (!AppSessionData.AboutMeVideo.IsUploaded)
                                    {

                                        var AboutMeVideo = AppSessionData.AboutMeVideo;
                                        AboutMeVideo.IsUploaded = true;
                                        AboutMeVideo.FilePath = filePath;
                                        AboutMeVideo.FileName = filename;
                                        AboutMeVideo.ThumbnailImage = thumnailimagepath;
                                        AppSessionData.AboutMeVideo = AboutMeVideo;
                                        canUploadAboutMeVideo = false;
                                        AppPreferences.CanUploadAboutMeVideo = canUploadAboutMeVideo;
                                        AboutmeVideoProgress = "100%";
                                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.IntroductionVideoUploaded);

                                        SetStatus("Introduction", "0");
                                    }

                                }
                                else if (fileType == Constants.VideoType.MySkillsVideo)
                                {
                                    if (!AppSessionData.SkillVideo.IsUploaded)
                                    {

                                        var SkillVideo = AppSessionData.SkillVideo;
                                        SkillVideo.IsUploaded = true;
                                        SkillVideo.FilePath = filePath;
                                        SkillVideo.FileName = filename;
                                        SkillVideo.ThumbnailImage = thumnailimagepath;
                                        AppSessionData.SkillVideo = SkillVideo;
                                        canUploadSkillVideo = false;
                                        AppPreferences.CanUploadSkillVideo = canUploadSkillVideo;

                                        SkillVideoProgress = "100%";
                                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.SkillVideoUploaded);

                                        SetStatus("MySkills", "0");
                                    }
                                }
                                else if (fileType == Constants.VideoType.MyInterestsVideo)
                                {
                                    if (!AppSessionData.InterestsVideo.IsUploaded)
                                    {

                                        var InterestsVideo = AppSessionData.InterestsVideo;
                                        InterestsVideo.IsUploaded = true;
                                        InterestsVideo.FilePath = filePath;
                                        InterestsVideo.FileName = filename;
                                        InterestsVideo.ThumbnailImage = thumnailimagepath;
                                        AppSessionData.InterestsVideo = InterestsVideo;

                                        canUploadInterestsVideo = false;
                                        AppPreferences.CanUploadInterestsVideo = canUploadInterestsVideo;
                                        InterestvideoProgress = "100%";
                                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.InterestsVideoUploaded);

                                        SetStatus("AreaofInterest", "0");
                                    }
                                }
                            }
                            else if (statusResult.code == "199")
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.SessionExpiered);
                                Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                            }
                            else
                            {
                                if (fileType == Constants.VideoType.AboutMeVideo)
                                {
                                    canUploadAboutMeVideo = false;
                                    AppPreferences.CanUploadAboutMeVideo = canUploadAboutMeVideo;
                                }
                                else if (fileType == Constants.VideoType.MySkillsVideo)
                                {
                                    canUploadSkillVideo = false;
                                    AppPreferences.CanUploadSkillVideo = canUploadSkillVideo;
                                }
                                else if (fileType == Constants.VideoType.MyInterestsVideo)
                                {
                                    canUploadInterestsVideo = false;
                                    AppPreferences.CanUploadInterestsVideo = canUploadInterestsVideo;
                                }

                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);

                            }


                        }
                        else
                        {
                            if (fileType == Constants.VideoType.AboutMeVideo)
                            {
                                canUploadAboutMeVideo = false;
                                AppPreferences.CanUploadAboutMeVideo = canUploadAboutMeVideo;
                            }
                            else if (fileType == Constants.VideoType.MySkillsVideo)
                            {
                                canUploadSkillVideo = false;
                                AppPreferences.CanUploadSkillVideo = canUploadSkillVideo;
                            }
                            else if (fileType == Constants.VideoType.MyInterestsVideo)
                            {
                                canUploadInterestsVideo = false;
                                AppPreferences.CanUploadInterestsVideo = canUploadInterestsVideo;
                            }

                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);

                        }
                    }
                }
                else
                {
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.RecordNewVideo);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                if (fileType == Constants.VideoType.AboutMeVideo)
                {
                    canUploadAboutMeVideo = true;
                }
                else if (fileType == Constants.VideoType.MySkillsVideo)
                {
                    canUploadSkillVideo = true;
                }
                else if (fileType == Constants.VideoType.MyInterestsVideo)
                {
                    canUploadInterestsVideo = true;
                }
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                //SendErrorMessageToServer(ex, "SeekerVideoProfileViewModel.UploadVideoFile");
            }
            return recordedfile;

        }


        #endregion

        #region PlayVideo

        async void PlayTapGestureRecognizer(string imageidentifier)
        {
            try
            {

                if (CrossConnectivity.Current.IsConnected)
                {
                    Debug.WriteLine("@ VideoProfilePage.PlayTapGestureRecognizer");


                    if (imageidentifier == "AboutMeVideo" && AppSessionData.AboutMeVideo != null)
                    {
                        if (!string.IsNullOrEmpty(AppSessionData.AboutMeVideo.FileName))
                        {
                            var filepath = string.Empty;
                            if (!DependencyService.Get<IThumbnailManager>().CheckFileExist(AppSessionData.AboutMeVideo.FilePath))
                            {
                                // filepath = AppSessionData.AboutMeVideo.S3URLPath;
                                filepath = Services.S3Manager.GeneratePreSignedURL(AmazonS3BucketDetails.VideoBucket, AppSessionData.AboutMeVideo.FileName, 20);
                            }
                            else
                            {
                                filepath = AppSessionData.AboutMeVideo.FilePath;
                            }

                            if (AppSessionData.AboutMeVideo != null && AppSessionData.AboutMeVideoStatus != null)
                            {
                                if (AppSessionData.AboutMeVideoStatus != "-1")
                                {
                                    var player = new PlayVideo(filepath);
                                    player.Title = "About Me Video";
                                    navigation.PushAsync(player);
                                }
                                else
                                {
                                    await UserDialogs.Instance.AlertAsync(_aboutMeVideoBlockedReason, "Blocked Reason", "OK");
                                }
                            }
                            else
                            {
                                // await UserDialogs.Instance.AlertAsync("", MessageStringConstants.RecordNewVideo, "OK");
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.RecordNewVideo);
                            }
                        }
                    }
                    else if (imageidentifier == "SkillVideo" && AppSessionData.SkillVideo != null)
                    {

                        if (!string.IsNullOrEmpty(AppSessionData.SkillVideo.FileName))
                        {
                            var filepath = string.Empty;
                            if (!DependencyService.Get<IThumbnailManager>().CheckFileExist(AppSessionData.SkillVideo.FilePath))
                            {
                                // filepath = AppSessionData.SkillVideo.S3URLPath;
                                filepath = Services.S3Manager.GeneratePreSignedURL(AmazonS3BucketDetails.VideoBucket, AppSessionData.SkillVideo.FileName, 20);
                            }
                            else
                            {
                                filepath = AppSessionData.SkillVideo.FilePath;
                            }

                            if (AppSessionData.SkillVideo != null && AppSessionData.SkillVideoStatus != null)
                            {
                                if (AppSessionData.SkillVideoStatus != "-1")
                                {
                                    var player = new PlayVideo(filepath);
                                    player.Title = "My Skill Video";
                                    navigation.PushAsync(player);
                                }
                                else
                                {
                                    await UserDialogs.Instance.AlertAsync(_skillVideoBlockedReason, "Blocked Reason", "OK");
                                }
                            }
                            else
                            {
                                // await UserDialogs.Instance.AlertAsync("", MessageStringConstants.RecordNewVideo, "OK");
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.RecordNewVideo);
                            }
                        }
                    }
                    else if (imageidentifier == "InterestVideo")
                    {
                        if (AppSessionData.InterestsVideo != null)
                        {
                            if (!string.IsNullOrEmpty(AppSessionData.InterestsVideo.FileName))
                            {
                                var filepath = string.Empty;
                                if (!DependencyService.Get<IThumbnailManager>().CheckFileExist(AppSessionData.InterestsVideo.FilePath))
                                {
                                    //filepath = AppSessionData.InterestsVideo.S3URLPath;
                                    filepath = Services.S3Manager.GeneratePreSignedURL(AmazonS3BucketDetails.VideoBucket, AppSessionData.InterestsVideo.FileName, 20);
                                }
                                else
                                {
                                    filepath = AppSessionData.InterestsVideo.FilePath;
                                }

                                if (AppSessionData.InterestsVideo != null && AppSessionData.InterestMeVideoStatus != null)
                                {
                                    if (AppSessionData.InterestMeVideoStatus != "-1")
                                    {
                                        var player = new PlayVideo(filepath);
                                        player.Title = "Interests Video";
                                        await navigation.PushAsync(player);
                                    }
                                    else
                                    {
                                        await UserDialogs.Instance.AlertAsync(_interestVideoBlockedReason, "Blocked Reason", "OK");
                                    }
                                }
                                else
                                {
                                    // await UserDialogs.Instance.AlertAsync("", MessageStringConstants.RecordNewVideo, "OK");
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.RecordNewVideo);
                                }

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error" + ex.Message);
                SendErrorMessageToServer(ex, "SeekerVideoProfileViewModel.PlayTapGestureRecognizer");
            }
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
