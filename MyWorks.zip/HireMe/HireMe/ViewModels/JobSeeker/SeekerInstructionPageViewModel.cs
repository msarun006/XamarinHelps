﻿using Plugin.Connectivity;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.JobSeeker
{
    public class SeekerInstructionPageViewModel
    {
        public ICommand SeekerInstructionPageCommand { get; set; }
        public SeekerInstructionPageViewModel()
        {
            SeekerInstructionPageCommand = new Command(DoProceed);
        }

        private void DoProceed(object obj)
        {
            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;

            if (isNetworkAvailable)
            {
                AppPreferences.IsInstructionClicked = false;
                Application.Current.MainPage = new NavigationPage(new SeekerPersonalAndEducationPage(false));
                return;
            }
            else if (!isNetworkAvailable && AppPreferences.IsFirstRun == false)
            {
                Application.Current.MainPage = new NavigationPage(new SeekerPersonalAndEducationPage(false));
                return;
            }
            else
            {
                Application.Current.MainPage = new InternetUnavailable("SeekerPersonalAndEducationPage");
                return;
            }
        }
    }
}
