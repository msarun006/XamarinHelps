﻿using System;
using System.Diagnostics;
using System.Windows.Input;
using Acr.UserDialogs;
using HireMe.Models.JobSeeker;
using MvvmHelpers;
using Xamarin.Forms;
using System.Threading.Tasks;
using HireMe.Views.JobSeeker;
using System.Collections.Generic;
using Rg.Plugins.Popup.Services;
using HireMe.Helpers;

namespace HireMe
{
    public class CompanyFullDetailsViewModel : BaseViewModel
    {

        private HttpCommonService _commonservice { get; set; }
        private string _companyID;
        private string _companyName;
        List<BranchDetail> _brachDetails;
        public bool isClicked = true;
        private string _idCard = string.Empty;
        private string _videoURL = string.Empty;
       // private string _websiteURL = string.Empty;
        private List<string> _Branchaddress;
       
        INavigation Navigation;



        public CompanyFullDetailsViewModel(INavigation navigation, string companyID, string companyName)
        {
            Navigation = navigation;
            Title = companyName;
            _companyName = companyName;

            _companyID = companyID;
         //   _websiteURL = string.Empty;
            _videoURL = string.Empty;
            _commonservice = new HttpCommonService();
            _brachDetails = new List<BranchDetail>();
            LoadcomapanyFullDetails();
        }



        public ICommand SelectedCommand => new Command(async (obj) =>

        {
            if (isClicked)
            {
                isClicked = false;

                if (obj.ToString() == "website")
                {
                    if (!string.IsNullOrEmpty(CompanyFullDetailsModel.CompanyName) && !string.IsNullOrEmpty(WebsiteURL))
                    {
                        await Navigation.PushAsync(new CompanyWebSide(CompanyFullDetailsModel.CompanyName, WebsiteURL));

                    }
                    else
                    {
                        await UserDialogs.Instance.AlertAsync("Website Not Available");


                    }

                }
                else if (obj.ToString() == "video")
                {
                    if (!string.IsNullOrEmpty(_videoURL))
                    {
                        await Navigation.PushAsync(new PlayVideo(_videoURL));
                    }
                    else
                    {
                        await UserDialogs.Instance.AlertAsync("Video Not Available");


                    }
                }
                else if (obj.ToString() == "Branch")
                {
                    var page = new BranchAddressPopupPage(_brachDetails);
                    await PopupNavigation.PushAsync(page);
                }
            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });

        });



        #region LoadcomapanyFullDetails
        public async void LoadcomapanyFullDetails()
        {

            if (string.IsNullOrEmpty(AppPreferences.S3AccessKeyID))
            {
                var obj = new S3Utils();
                await obj.GetS3Credentials();
            }
            ShowCompanyDetails();
        }
        #endregion
        public CompanyFullDetailsRequestData _CompanyFullDetailsRequestData;
        public CompanyFullDetailsRequestData CompanyFullDetailsRequestData
        {
            get { return _CompanyFullDetailsRequestData; }
            set { _CompanyFullDetailsRequestData = value; OnPropertyChanged(); }
        }

        private CompanyFullDetailsModel _CompanyFullDetailsModel;

        public CompanyFullDetailsModel CompanyFullDetailsModel
        {
            get { return _CompanyFullDetailsModel; }
            set { _CompanyFullDetailsModel = value; OnPropertyChanged(); }
        }

        private string _brachAddress;
        public string BranchAddress
        {
            get { return _brachAddress; }
            set { _brachAddress = value; OnPropertyChanged(); }
        }

        private int _BranchAdd;
        public int BranchAdd
        {
            get { return _BranchAdd; }
            set { _BranchAdd = value; }
        }

        private bool _Branch;
        public bool Branch
        {
            get { return _Branch; }
            set { _Branch = value; OnPropertyChanged(); }
        }

        public async void ShowCompanyDetails()
        {
            try
            {
                CompanyFullDetailsModel = new CompanyFullDetailsModel();
                CompanyFullDetailsRequestData = new CompanyFullDetailsRequestData()
                {
                    HiremeeID = AppSessionData.ActiveToken.HireMeID,
                    Token = AppSessionData.ActiveToken.Token,
                    CompanyID = _companyID,
                };

                UserDialogs.Instance.ShowLoading();
                var statusResult = await _commonservice.PostAsync<CompanyFullDetailsResponse, CompanyFullDetailsRequestData>(APIData.API_BASE_URL + APIMethods.CompanyFullDetails, CompanyFullDetailsRequestData);

                if (statusResult != null)
                {
                    if (statusResult.code == "200")
                    {
                        CompanyFullDetailsModel.CompanyLogo = statusResult.responseText.companylogo;

                        //if (_idCard.Contains("png") || _idCard.Contains("jpg"))
                        //{
                        //    CompanyFullDetailsModel.CompanyLogo = _idCard;
                        //}
                        CompanyFullDetailsModel.CompanyName = statusResult.responseText.companyname;
                        CompanyFullDetailsModel.Email = statusResult.responseText.email_address;
                        CompanyFullDetailsModel.Mobile = statusResult.responseText.mobile_number;
                        CompanyFullDetailsModel.Address = statusResult.responseText.address;
                        CompanyFullDetailsModel.City = statusResult.responseText.city;
                        CompanyFullDetailsModel.State = statusResult.responseText.state;
                        CompanyFullDetailsModel.Country = statusResult.responseText.country;

                        string _Corporateaddress = "";
                        if (!string.IsNullOrEmpty(statusResult.responseText.corporate_address))
                        {
                            _Corporateaddress= statusResult.responseText.corporate_address + "," + statusResult.responseText.corporate_state;
                        }
                        else{
                            _Corporateaddress= statusResult.responseText.corporate_state;
                        }
                        CompanyFullDetailsModel.Corporateaddress = _Corporateaddress;
                        CompanyFullDetailsModel.Totalemployees = statusResult.responseText.no_of_employees;
                        CompanyFullDetailsModel.Companytype = statusResult.responseText.company_type;
                        _brachDetails = statusResult.responseText.branch_details;
                        BranchAdd =_brachDetails.Count;
                        if(BranchAdd >= 2)
                        {
                            Branch = true;
                        }
                        else
                        {
                            Branch = false;
                        }

                        foreach (var item in statusResult.responseText.branch_details)
                        {
                            var address = item.address + ","+"\n" + item.city + "," + item.state + ".";
                            BranchAddress = address;
                            break;
                        }
                        CompanyFullDetailsModel.Branchaddress = BranchAddress;

                        if (string.IsNullOrEmpty(CompanyFullDetailsModel.Branchaddress) || string.IsNullOrEmpty(CompanyFullDetailsModel.Companytype) || string.IsNullOrEmpty(CompanyFullDetailsModel.Corporateaddress) || string.IsNullOrEmpty(CompanyFullDetailsModel.Totalemployees))
                        {
                            CompanyFullDetailsModel.Totalemployees = "Not Update";
                            CompanyFullDetailsModel.Companytype = "Not Update";
                            CompanyFullDetailsModel.Corporateaddress = "Not Update";
                            CompanyFullDetailsModel.Branchaddress = "Not Update";
                        }
                        if (!string.IsNullOrEmpty(statusResult.responseText.companyvideo.s3_id))
                        {

                            _videoURL = await DependencyService.Get<IS3ImageManager>().DownloadFile(statusResult.responseText.companyvideo.s3_id, AmazonS3BucketDetails.CompanyvideoBucket);
                        }
                        WebsiteURL = statusResult.responseText.website_address;

                         UserDialogs.Instance.HideLoading();
                    }
                    else
                    {
                        await UserDialogs.Instance.AlertAsync(statusResult.message);

                    }
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "CompanyFullDetailsViewModel.ShowCompanyDetails");
            }
        }
        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion





        private string websiteURL;
        public string WebsiteURL
        {
            get { return websiteURL; }
            set
            {
                websiteURL = value;
                OnPropertyChanged();

            }
        }

    }

}

