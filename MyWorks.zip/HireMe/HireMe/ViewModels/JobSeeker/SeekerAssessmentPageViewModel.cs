﻿using MvvmHelpers;
using System;
using System.Threading;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace HireMe.ViewModels.JobSeeker
{
    public class SeekerAssessmentPageViewModel : BaseViewModel
    {

        #region Main Constructor
        public SeekerAssessmentPageViewModel()
        {
            GetAssessmentScores();
        }
        #endregion

        #region Get Assessment Scores 
        public void GetAssessmentScores()
        {
            #region Binding Value
            //lblAssessmentStatus = "Not Verified";
            lblAssessmentStatus = AppPreferences.LoadSeekerDashboardData.AssessmentScore.Status;
            lblVerbal = AppPreferences.LoadSeekerDashboardData.AssessmentScore.VerbalAptitude ?? "0";
            lblVerbal = AppPreferences.LoadSeekerDashboardData.AssessmentScore.VerbalAptitude ?? "0";
            lblQuantitative = AppPreferences.LoadSeekerDashboardData.AssessmentScore.QuantitativeAptitude ?? "0";
            lblLogical = AppPreferences.LoadSeekerDashboardData.AssessmentScore.LogicalResoning ?? "0";
            lblAptitude = AppPreferences.LoadSeekerDashboardData.AssessmentScore.TechnicalComputerFundamental ?? "0";
            lblCommunication = AppPreferences.LoadSeekerDashboardData.AssessmentScore.Communication ?? "0";
            lblPersonalCompetencies = AppPreferences.LoadSeekerDashboardData.AssessmentScore.PersonalCompetencies ?? "0";
            lblEmotional = AppPreferences.LoadSeekerDashboardData.AssessmentScore.EmotionalCompetencies ?? "0";
            lblMotivational = AppPreferences.LoadSeekerDashboardData.AssessmentScore.MotivationalCompetencies ?? "0";
            lblIntellectual = AppPreferences.LoadSeekerDashboardData.AssessmentScore.IntellectualOrientation ?? "0";
            lblInterpersonal = AppPreferences.LoadSeekerDashboardData.AssessmentScore.InterPersonalCompetencies ?? "0";
            lblTechnical = AppPreferences.LoadSeekerDashboardData.AssessmentScore.TechnicalCoreDomain ?? "0";

            lblPercentileScore = AppPreferences.LoadSeekerDashboardData.AssessmentScore.PercenTile ?? "NA";
            if (string.IsNullOrEmpty(lblPercentileScore) || lblPercentileScore == "0")
            {
                lblPercentileScore = "NA";
            }
            #endregion

            #region Progress Value

            if (lblVerbal == "10")
            {
                lblVerbalProgress = AppPreferences.LoadSeekerDashboardData.AssessmentScore.VerbalAptitude ?? "0";
            }
            else
            {
                lblVerbalProgress = "0." + AppPreferences.LoadSeekerDashboardData.AssessmentScore.VerbalAptitude ?? "0";
            }

            if (lblQuantitative == "10")
            {
                lblQuantitativeProgress = AppPreferences.LoadSeekerDashboardData.AssessmentScore.QuantitativeAptitude ?? "0";
            }
            else
            {
                lblQuantitativeProgress = "0." + AppPreferences.LoadSeekerDashboardData.AssessmentScore.QuantitativeAptitude ?? "0";
            }

            if (lblLogical == "10")
            {
                lblLogicalProgress = AppPreferences.LoadSeekerDashboardData.AssessmentScore.LogicalResoning ?? "0";
            }
            else
            {
                lblLogicalProgress = "0." + AppPreferences.LoadSeekerDashboardData.AssessmentScore.LogicalResoning ?? "0";
            }

            if (lblAptitude == "10")
            {
                lblAptitudeProgress = AppPreferences.LoadSeekerDashboardData.AssessmentScore.TechnicalComputerFundamental ?? "0";
            }
            else
            {
                lblAptitudeProgress = "0." + AppPreferences.LoadSeekerDashboardData.AssessmentScore.TechnicalComputerFundamental ?? "0";
            }

            if (lblCommunication == "10")
            {
                lblCommunicationProgress = AppPreferences.LoadSeekerDashboardData.AssessmentScore.Communication ?? "0";
            }
            else
            {
                lblCommunicationProgress = "0." + AppPreferences.LoadSeekerDashboardData.AssessmentScore.Communication ?? "0";
            }

            if (lblPersonalCompetencies == "10")
            {
                lblPersonalCompetenciesProgress = AppPreferences.LoadSeekerDashboardData.AssessmentScore.PersonalCompetencies ?? "0";
            }
            else
            {
                lblPersonalCompetenciesProgress = "0." + AppPreferences.LoadSeekerDashboardData.AssessmentScore.PersonalCompetencies ?? "0";
            }


            if (lblEmotional == "10")
            {
                lblEmotionalProgress = AppPreferences.LoadSeekerDashboardData.AssessmentScore.EmotionalCompetencies ?? "0";
            }
            else
            {
                lblEmotionalProgress = "0." + AppPreferences.LoadSeekerDashboardData.AssessmentScore.EmotionalCompetencies ?? "0";
            }

            if (lblMotivational == "10")
            {
                lblMotivationalProgress = AppPreferences.LoadSeekerDashboardData.AssessmentScore.MotivationalCompetencies ?? "0";
            }
            else
            {
                lblMotivationalProgress = "0." + AppPreferences.LoadSeekerDashboardData.AssessmentScore.MotivationalCompetencies ?? "0";
            }

            if (lblIntellectual == "10")
            {
                lblIntellectualProgress = AppPreferences.LoadSeekerDashboardData.AssessmentScore.IntellectualOrientation ?? "0";
            }
            else
            {
                lblIntellectualProgress = "0." + AppPreferences.LoadSeekerDashboardData.AssessmentScore.IntellectualOrientation ?? "0";
            }
            if (lblInterpersonal == "10")
            {
                lblInterpersonalProgress = AppPreferences.LoadSeekerDashboardData.AssessmentScore.InterPersonalCompetencies ?? "0";
            }
            else
            {
                lblInterpersonalProgress = "0." + AppPreferences.LoadSeekerDashboardData.AssessmentScore.InterPersonalCompetencies ?? "0";
            }

            if (lblTechnical == "10")
            {
                lblTechnicalProgress = AppPreferences.LoadSeekerDashboardData.AssessmentScore.TechnicalCoreDomain ?? "0";
            }
            else
            {
                lblTechnicalProgress = "0." + AppPreferences.LoadSeekerDashboardData.AssessmentScore.TechnicalCoreDomain ?? "0";
            }

            #endregion
        }
        #endregion

        #region Binding Value


        private string _lblAssessmentStatus;
        public string lblAssessmentStatus
        {
            get { return _lblAssessmentStatus; }
            set { if (value == _lblAssessmentStatus) return; _lblAssessmentStatus = value; OnPropertyChanged(); }
        }



        private string _lblVerbal;
        public string lblVerbal
        {
            get { return _lblVerbal; }
            set { if (value == _lblVerbal) return; _lblVerbal = value; OnPropertyChanged(); }
        }

        private string _lblQuantitative;
        public string lblQuantitative
        {
            get { return _lblQuantitative; }
            set { if (value == _lblQuantitative) return; _lblQuantitative = value; OnPropertyChanged(); }
        }

        private string _lblLogical;
        public string lblLogical
        {
            get { return _lblLogical; }
            set { if (value == _lblLogical) return; _lblLogical = value; OnPropertyChanged(); }
        }

        private string _lblAptitude;
        public string lblAptitude
        {
            get { return _lblAptitude; }
            set { if (value == _lblAptitude) return; _lblAptitude = value; OnPropertyChanged(); }
        }
        private string _lblCommunication;
        public string lblCommunication
        {
            get { return _lblCommunication; }
            set { if (value == _lblCommunication) return; _lblCommunication = value; OnPropertyChanged(); }
        }
        private string _lblPercentileScore;
        public string lblPercentileScore
        {
            get { return _lblPercentileScore; }
            set { if (value == _lblPercentileScore) return; _lblPercentileScore = value; OnPropertyChanged(); }
        }
        private string _lblTechnical;
        public string lblTechnical
        {
            get { return _lblTechnical; }
            set { if (value == _lblTechnical) return; _lblTechnical = value; OnPropertyChanged(); }
        }
        private string _lblInterpersonal;
        public string lblInterpersonal
        {
            get { return _lblInterpersonal; }
            set { if (value == _lblInterpersonal) return; _lblInterpersonal = value; OnPropertyChanged(); }
        }
        private string _lblPersonalCompetencies;
        public string lblPersonalCompetencies
        {
            get { return _lblPersonalCompetencies; }
            set { if (value == _lblPersonalCompetencies) return; _lblPersonalCompetencies = value; OnPropertyChanged(); }
        }
        private string _lblEmotional;
        public string lblEmotional
        {
            get { return _lblEmotional; }
            set { if (value == _lblEmotional) return; _lblEmotional = value; OnPropertyChanged(); }
        }
        private string _lblMotivational;
        public string lblMotivational
        {
            get { return _lblMotivational; }
            set { if (value == _lblMotivational) return; _lblMotivational = value; OnPropertyChanged(); }
        }
        private string _lblIntellectual;
        public string lblIntellectual
        {
            get { return _lblIntellectual; }
            set { if (value == _lblIntellectual) return; _lblIntellectual = value; OnPropertyChanged(); }
        }
        #endregion

        #region Progress
        private string _lblVerbalProgress;
        public string lblVerbalProgress
        {
            get { return _lblVerbalProgress; }
            set { if (value == _lblVerbalProgress) return; _lblVerbalProgress = value; OnPropertyChanged(); }
        }

        private string _lblQuantitativeProgress;
        public string lblQuantitativeProgress
        {
            get { return _lblQuantitativeProgress; }
            set { if (value == _lblQuantitativeProgress) return; _lblQuantitativeProgress = value; OnPropertyChanged(); }
        }

        private string _lblLogicalProgress;
        public string lblLogicalProgress
        {
            get { return _lblLogicalProgress; }
            set { if (value == _lblLogicalProgress) return; _lblLogicalProgress = value; OnPropertyChanged(); }
        }

        private string _lblAptitudeProgress;
        public string lblAptitudeProgress
        {
            get { return _lblAptitudeProgress; }
            set { if (value == _lblAptitudeProgress) return; _lblAptitudeProgress = value; OnPropertyChanged(); }
        }
        private string _lblCommunicationProgress;
        public string lblCommunicationProgress
        {
            get { return _lblCommunicationProgress; }
            set { if (value == _lblCommunicationProgress) return; _lblCommunicationProgress = value; OnPropertyChanged(); }
        }

        private string _lblTechnicalProgress;
        public string lblTechnicalProgress
        {
            get { return _lblTechnicalProgress; }
            set { if (value == _lblTechnicalProgress) return; _lblTechnicalProgress = value; OnPropertyChanged(); }
        }
        private string _lblInterpersonalProgress;
        public string lblInterpersonalProgress
        {
            get { return _lblInterpersonalProgress; }
            set { if (value == _lblInterpersonalProgress) return; _lblInterpersonalProgress = value; OnPropertyChanged(); }
        }
        private string _lblPersonalCompetenciesProgress;
        public string lblPersonalCompetenciesProgress
        {
            get { return _lblPersonalCompetenciesProgress; }
            set { if (value == _lblPersonalCompetenciesProgress) return; _lblPersonalCompetenciesProgress = value; OnPropertyChanged(); }
        }
        private string _lblEmotionalProgress;
        public string lblEmotionalProgress
        {
            get { return _lblEmotionalProgress; }
            set { if (value == _lblEmotionalProgress) return; _lblEmotionalProgress = value; OnPropertyChanged(); }
        }
        private string _lblMotivationalProgress;
        public string lblMotivationalProgress
        {
            get { return _lblMotivationalProgress; }
            set { if (value == _lblMotivationalProgress) return; _lblMotivationalProgress = value; OnPropertyChanged(); }
        }
        private string _lblIntellectualProgress;
        public string lblIntellectualProgress
        {
            get { return _lblIntellectualProgress; }
            set { if (value == _lblIntellectualProgress) return; _lblIntellectualProgress = value; OnPropertyChanged(); }
        }
        #endregion
    }
}
