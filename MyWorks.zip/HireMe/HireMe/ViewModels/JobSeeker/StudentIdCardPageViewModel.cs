﻿using Acr.UserDialogs;
using Amazon.S3.Model;
using HireMe.Helpers;
using HireMe.Models;
using HireMe.Models.JobSeeker;
using HireMe.Renderers;
using HireMe.Services;
using MvvmHelpers;
using Plugin.Connectivity;
using Plugin.Media;
using Plugin.Media.Abstractions;
using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;


namespace HireMe.ViewModels.JobSeeker
{
    public class StudentIdCardPageViewModel : BaseViewModel
    {

        private IMedia _mediaPicker;
        public ICommand OnUploadIDCommand { get; set; }
        public UserResourceRetrivalRequestData objRequestData { get; set; }
        public UserResourceInsertRequestData InsertReqestData { get; set; }
        private HttpCommonService _commonservice { get; set; }
        public bool isClicked = true;
        public INavigation _navigationservice { get; set; }
        public StudentIdCardPageViewModel(INavigation navi)
        {
            _navigationservice = navi;
            OnUploadIDCommand = new Command(OnUploadIDCard);
            objRequestData = new UserResourceRetrivalRequestData();
            InsertReqestData = new UserResourceInsertRequestData();
            _commonservice = new HttpCommonService();
            GetIdCardDetail();
            ButtonTextStudentID = "Upload";
        }

        #region GetIdCardDetail
        public async Task GetIdCardDetail()
        {
            string _idCard = string.Empty;
            if (!string.IsNullOrEmpty(AppPreferences.IdCard))
            {
                _idCard = AppPreferences.IdCard;
                ImageStudentID = _idCard;
                ButtonTextStudentID = "Edit";
            }
            else if (string.IsNullOrEmpty(_idCard))
            {
                try
                {
                    UserDialogs.Instance.ShowLoading();
                    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                    if (isNetworkAvailable)
                    {
                        if (string.IsNullOrEmpty(AppPreferences.S3AccessKeyID))
                        {
                            var obj = new S3Utils();
                            await obj.GetS3Credentials();
                        }
                        objRequestData.ResourceTypeId = Convert.ToInt32(ResourceType.IdCard).ToString();
                        var result = await _commonservice.PostAsync<UserResourceRetrivalResponseData, UserResourceRetrivalRequestData>(APIData.API_BASE_URL + APIMethods.StudentIDCardRetrive, objRequestData);

                        if (result != null)
                        {
                            if (result.code == "200" && result.Response != null)
                            {
                                _idCard = await DependencyService.Get<IS3ImageManager>().DownloadFile(result.Response.s3Id, AmazonS3BucketDetails.StudentIDCard);
                                if (_idCard.Contains("png") || _idCard.Contains("jpg"))
                                {
                                    ImageStudentID = _idCard;
                                    AppPreferences.IdCard = _idCard;
                                    ButtonTextStudentID = "Edit";
                                }
                            }
                            UserDialogs.Instance.HideLoading();
                        }
                        else
                        { UserDialogs.Instance.HideLoading(); }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine(ex.Message);
                    SendErrorMessageToServer(ex, "StudentIdCardPageViewModel.GetIdCardDetail");
                }

            }
        }

        #endregion

        #region Binding Properties
        private ImageSource _imageStudentID;
        public ImageSource ImageStudentID
        {
            get
            { return this._imageStudentID; }
            set
            {
                if (Equals(value, this._imageStudentID))
                { return; }
                this._imageStudentID = value;
                OnPropertyChanged();
            }
        }
        private string _btnstudentID;

        public string ButtonTextStudentID
        {
            get { return _btnstudentID; }
            set { _btnstudentID = value; }
        }
        #endregion


        private async void OnUploadIDCard(object obj)
        {
            if (isClicked)
            {
                isClicked = false;
                GetPicture();
            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });
        }



        #region UploadIdCard


        public void GetPicture()
        {
            #region UserDialogs.ActionSheet Configurations
            ActionSheetConfig ActionSheetConfigurations = new ActionSheetConfig();
            ActionSheetConfigurations.SetTitle("Profile Photo");
            ActionSheetConfigurations.Add("Pick from Gallery", () =>
            {
                UploadIdCard("Pick from Gallery");
            });
            ActionSheetConfigurations.Add("Camera", () =>
            {
                UploadIdCard("Camera");
            });
            ActionSheetConfigurations.Add("Cancel", () => { });
            UserDialogs.Instance.ActionSheet(ActionSheetConfigurations);

            #endregion
        }


        private async void UploadIdCard(string action)
        {
            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
            if (isNetworkAvailable)
            {
                MediaFile file = null;
                try
                {
                    #region Pick from Gallery
                    if (action == "Pick from Gallery")
                    {
                        Setup();

                        try
                        {
                            var status = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Storage);
                            if (status != PermissionStatus.Granted)
                            {
                                if (await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Storage))
                                {
                                    await UserDialogs.Instance.AlertAsync("Need Storage Permission", "Access Storage", "OK");
                                }

                                var results = await CrossPermissions.Current.RequestPermissionsAsync(new[] { Permission.Storage });
                                status = results[Permission.Storage];
                            }

                            if (status == PermissionStatus.Granted)
                            {
                                await Task.Delay(1000);
                                file = await CrossMedia.Current.PickPhotoAsync();

                            }
                            else if (status != PermissionStatus.Unknown)
                            {
                                //await UserDialogs.Instance.AlertAsync("Can not continue, try again.", "Storage Permission Denied", "OK");
                                UserDialogs.Instance.Toast(MessageStringConstants.PermissionMessage);
                            }
                        }
                        catch (Exception ex)
                        {
                            System.Diagnostics.Debug.WriteLine(ex.Message);
                            SendErrorMessageToServer(ex, "StudentIdCardPageViewModel.UploadIdCard");
                        }
                    }
                    #endregion

                    #region Camera
                    else if (action == "Camera")
                    {
                        Setup();
                        try
                        {
                            var status = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Camera);
                            if (status != PermissionStatus.Granted)
                            {
                                if (await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Camera))
                                {
                                    await UserDialogs.Instance.AlertAsync("Need Camera Permission", "Access Camera", "OK");
                                }

                                var results = await CrossPermissions.Current.RequestPermissionsAsync(new[] { Permission.Camera });
                                status = results[Permission.Camera];
                            }

                            if (status == PermissionStatus.Granted)
                            {
                                await Task.Delay(1000);
                                file = await CrossMedia.Current.TakePhotoAsync(new StoreCameraMediaOptions
                                {
                                    CompressionQuality = 90,
                                    AllowCropping = false,
                                    PhotoSize = PhotoSize.Medium,
                                    Directory = "HireMee",
                                    Name = "HireMeeIdCard.jpg"


                                });






                                //var memoryStream = new MemoryStream();
                                //await file.GetStream().CopyToAsync(memoryStream);
                                //byte[] imageAsByte = memoryStream.ToArray();
                                //await _navigationservice.PushModalAsync(new CropView(imageAsByte, Refresh));


                            }
                            else if (status != PermissionStatus.Unknown)
                            {
                                //await UserDialogs.Instance.AlertAsync("Can not continue, try again.", "Camera Permission Denied", "OK");
                                UserDialogs.Instance.Toast(MessageStringConstants.PermissionMessage);
                            }
                        }
                        catch (Exception ex)
                        {
                            System.Diagnostics.Debug.WriteLine(ex.Message);
                            SendErrorMessageToServer(ex, "StudentIdCardPageViewModel.UploadIdCard");
                        }

                    }
                    #endregion


                    else
                    {
                        file = null;
                    }
                    #region Null Check

                    if (file == null)
                    {
                        return;
                    }

                    #endregion



                    #region Uploading ID Card To S3
                    UserDialogs.Instance.ShowLoading();
                    string filename = AppSessionData.ActiveToken.HireMeID + "_" + "Id_card" + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".png";
                    var filePath = DependencyService.Get<IImageManager>().CopyFile(file.Path, filename);
                    ImageStudentID = filePath;
                    var UserProfileimageLegnth = DependencyService.Get<IImageManager>().ReadImageFile(filePath);
                    var s3fileurl = await S3Manager.UploadFile(filePath, filename, AmazonS3BucketDetails.StudentIDCard);
                    if (!string.IsNullOrEmpty(s3fileurl))
                    {
                        InsertReqestData.ResourceTypeId = Convert.ToInt32(Models.ResourceType.IdCard).ToString();
                        InsertReqestData.s3Id = filename;
                        InsertReqestData.ResourceUrl = s3fileurl;
                        InsertReqestData.ThumbnailUrl = s3fileurl;
                        var result = await _commonservice.PostAsync<UserResourceInsertResponseData, UserResourceInsertRequestData>(APIData.API_BASE_URL + APIMethods.StudentIDCardUpdate, InsertReqestData);

                        if (result != null)
                        {
                            if (result.code == "200")
                            {
                                AppPreferences.IdCard = filePath;
                                ButtonTextStudentID = "Edit";
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(result.message);
                            }
                            else
                            {
                                ButtonTextStudentID = "Upload";
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.UnableToUpdateProfilePicture);
                            }
                        }
                        else
                        { UserDialogs.Instance.HideLoading(); }
                    }
                }
                #endregion


                catch (Exception ex)
                {
                    UserDialogs.Instance.HideLoading();
                    System.Diagnostics.Debug.WriteLine("EXCEPTION {0}:  {1}", DateTime.Now, ex.StackTrace);
                    SendErrorMessageToServer(ex, "StudentIdCardPageViewModel.UploadIdCard");
                }
                finally
                {
                    if (file != null)
                    {
                        file.Dispose();
                    }
                }
            }
            else
            {
                UserDialogs.Instance.HideLoading();
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection," HireMee","OK");

            }
        }

        #endregion





        //#region SetImageSource
        //private async void Refresh()
        //{
        //    try
        //    {
            
        //        if (App.CroppedImage != null)
        //        {
        //            Stream  stream = new MemoryStream(App.CroppedImage);




        //            ImageStudentID = ImageSource.FromStream(() => stream);
                    
        //            #region Uploading ID Card To S3
        //            UserDialogs.Instance.ShowLoading();
        //            string filename = AppSessionData.ActiveToken.HireMeID + "_" + "Id_card" + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".png";
        //            //   var filePath = DependencyService.Get<IImageManager>().CopyFile(file.Path, filename);
        //            //    ImageStudentID = filePath;
        //            //     var UserProfileimageLegnth = DependencyService.Get<IImageManager>().ReadImageFile(filePath);

                    
                  

        //            var s3fileurl = await S3Manager.UploadFileStream(stream, filename, AmazonS3BucketDetails.StudentIDCard);
        //            if (!string.IsNullOrEmpty(s3fileurl))
        //            {
        //                InsertReqestData.ResourceTypeId = Convert.ToInt32(Models.ResourceType.IdCard).ToString();
        //                InsertReqestData.s3Id = filename;
        //                InsertReqestData.ResourceUrl = s3fileurl;
        //                InsertReqestData.ThumbnailUrl = s3fileurl;
        //                var result = await _commonservice.PostAsync<UserResourceInsertResponseData, UserResourceInsertRequestData>(APIData.API_BASE_URL + APIMethods.StudentIDCardUpdate, InsertReqestData);

        //                if (result != null)
        //                {
        //                    if (result.Code == "200")
        //                    {
        //                        // AppPreferences.IdCard = filePath;
        //                        ImageStudentID = s3fileurl;
        //                        ButtonTextStudentID = "Edit";
        //                        UserDialogs.Instance.HideLoading();
        //                        await UserDialogs.Instance.AlertAsync(result.Message);
        //                    }
        //                    else
        //                    {
        //                        ButtonTextStudentID = "Upload";
        //                        UserDialogs.Instance.HideLoading();
        //                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.UnableToUpdateProfilePicture);
        //                    }
        //                }
        //                else
        //                { UserDialogs.Instance.HideLoading(); }
        //            }
        //        }
        //    }
        //    #endregion




        //    catch (Exception ex)
        //    {
        //        // Debug.WriteLine(ex.Message);
        //    }
        //}
        //#endregion



        #region MediaPickerInitialize

        private async void Setup()
        {
            if (_mediaPicker != null)
            {
                return;
            }

            ////RM: hack for working on windows phone? 
            await CrossMedia.Current.Initialize();
            _mediaPicker = CrossMedia.Current;
        }

        #endregion
        
        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

    }
}
