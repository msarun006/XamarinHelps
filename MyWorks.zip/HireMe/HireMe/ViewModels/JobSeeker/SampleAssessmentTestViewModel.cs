﻿using Acr.UserDialogs;
using MvvmHelpers;
using System.Windows.Input;
using Xamarin.Forms;
using System;
using Plugin.Connectivity;
using HireMe.Helpers;

namespace HireMe.ViewModels.JobSeeker
{
    public class SampleAssessmentTestViewModel : BaseViewModel
    {
      
        public ICommand ProgressLoadNavigated { get; set; }
        public ICommand ProgressLoadNavigating { get; set; }
        public SampleAssessmentTestViewModel()
        {
          
            LoadDefault();
        }

        private async void LoadDefault()
        {
            try
            {
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {
                    ProgressBarValue = 0.2;
                    IsVisibleProgressBar = true;
                    WebViewAssessmentURL = APIData.SampleAssessmentURL + AppSessionData.ActiveToken.HireMeID;
                    ProgressLoadNavigated = new Command(OnNavigated);
                    ProgressLoadNavigating = new Command(OnNavigating);
                }
                else
                {
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SampleAssessmentTestViewModel.LoadDefault");
                throw;
            }
        }

        private void OnNavigating(object obj)
        {
            IsVisibleProgressBar = true;
            UserDialogs.Instance.ShowLoading();
        }

        private void OnNavigated(object obj)
        {
            IsVisibleProgressBar = false;
            UserDialogs.Instance.HideLoading();
        }
        
        #region Binding properties
        private bool _isVisibleProgressBar;
        public bool IsVisibleProgressBar
        {
            get { return _isVisibleProgressBar; }
            set { _isVisibleProgressBar = value; OnPropertyChanged(); }
        }

        private WebViewSource _webViewAssessmentURL;
        public WebViewSource WebViewAssessmentURL
        {
            get
            { return this._webViewAssessmentURL; }
            set
            {
                if (Equals(value, this._webViewAssessmentURL))
                { return; }
                this._webViewAssessmentURL = value;
                OnPropertyChanged();
            }
        }

        private double _progressBarValue;
        public double ProgressBarValue
        {
            get { return _progressBarValue; }
            set
            {
                if (this._progressBarValue != value)
                {
                    this._progressBarValue = value;
                    OnPropertyChanged();
                }

            }
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
