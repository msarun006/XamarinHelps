﻿using System;
using MvvmHelpers;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xamarin.Forms;
using Acr.UserDialogs;
using System.Linq;
using HireMe.DataLayer.Models;

namespace HireMe
{
    public class MultipleLanguageSelectionPageViewModel : BaseViewModel
	{
		#region Object Creation
		private HttpCommonService _commonservice { get; set; }
		ObservableCollection<Languageknown> _languageList;
        ObservableCollection<Languageknown> _TemplanguageList;
        IValueGetter _valueGetter;
		private string SearchName = "";
		private List<Languageknown> SelectionLanguages;
       // bool isTogggleSelected = true;
		bool isToggleFired = false;
        public bool isClicked = true;
        int count = 0;
		INavigation Navigation;
		#endregion



		public MultipleLanguageSelectionPageViewModel(INavigation navigation, List<Languageknown> languages,IValueGetter valuesgetter = null)
		{

			Navigation = navigation;
			_valueGetter = valuesgetter;
			SelectionLanguages = languages;
			btnSendIsDestructive = false;
			_commonservice = new HttpCommonService();
			BindLanguagesData(languages);
            SearchPlaceHolderText = "Search Language";
            DoneButtonClicked = new Command(onDoneClicked);
            _TemplanguageList = new ObservableCollection<Languageknown>();
            isEnabledSearchBar = true;

        }


        #region Searchbar Controls
        private bool _isVisibleSearchbarCancel;
        public bool IsVisibleSearchbarCancelButton
        {
            get { return _isVisibleSearchbarCancel; }
            set { _isVisibleSearchbarCancel = value; OnPropertyChanged(); }
        }

        public string _SearchText;
        public string SearchText
        {
            set
            {
                _SearchText = value;
                SearchText_TextChanged();
                OnPropertyChanged();
            }
            get { return _SearchText; }
        }
        public bool _isEnabledSearchBar;

        public bool isEnabledSearchBar
        {
            set { _isEnabledSearchBar = value; OnPropertyChanged(); }
            get { return _isEnabledSearchBar; }
        }
        public Command OnSearchClearCommand => new Command(() =>
        {
            IsVisibleSearchbarCancelButton = false;
            SearchText = string.Empty;
            SearchPlaceHolderText = "Search Language";

        });
        private string _searchPlaceHolder;
        public string SearchPlaceHolderText
        {
            get { return _searchPlaceHolder; }
            set { _searchPlaceHolder = value; OnPropertyChanged(); }
        }


        public void SearchText_TextChanged()
        {
            var searchtext = SearchText;
            if (string.IsNullOrEmpty(searchtext))
            {
                //isTogggleSelected = false;
                SearchPlaceHolderText = "Search Language";
                IsVisibleSearchbarCancelButton = false;
                LanguageListItemSource = _TemplanguageList;
                return;
            }

            if (_TemplanguageList != null)
            {

                LanguageListItemSource = _TemplanguageList;

                //isTogggleSelected = false;
                List<Languageknown> Suggetions = LanguageListItemSource.Where(c => c.Title.ToLower().Contains(searchtext.ToLower())).ToList();
                LanguageListItemSource = new ObservableCollection<Languageknown>(Suggetions);
                if(Suggetions.Count > 0)
                {
                    isToggleFired = true;
                    //isTogggleSelected = true;
                }
                IsVisibleSearchbarCancelButton = true;
            }

        }

        #endregion

        public ObservableCollection<Languageknown> _LanguageListItemSource;
		public ObservableCollection<Languageknown> LanguageListItemSource
		{
			get { return _LanguageListItemSource; }
			set { _LanguageListItemSource = value; OnPropertyChanged(); }
		}



		#region BindLanguagesData
		async Task BindLanguagesData(List<Languageknown> SelectionLanguages)
		{
			System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindLanguagesData");
			if (_languageList == null)
			{
				UserDialogs.Instance.ShowLoading();

				MasterTableRequestData MasterTableRequestData = new MasterTableRequestData()
				{
					HiremeeID = AppSessionData.ActiveToken.HireMeID,
					Token = AppSessionData.ActiveToken.Token,
					TableName = "language"
				};


				var languages = await _commonservice.PostAsync<LanguageResponseData, MasterTableRequestData>(APIData.API_BASE_URL + APIMethods.MasterTables, MasterTableRequestData);
                if (languages != null)
                {
                    if (languages.Response.responseText != null)
                    {
                        _languageList = new ObservableCollection<Languageknown>(languages.Response.responseText);
                        isEnabledSearchBar = true;
                        UserDialogs.Instance.HideLoading();
                    }
                }
            }



			#region  MultipleLanguageSelectionHelper
		//	MultipleLanguageSelectionHelper objSelectionHelper = new MultipleLanguageSelectionHelper();
		//	List<MultipleLanguageSelectionBO> selectedSkills = objSelectionHelper.GetData(SearchName);
			if (SelectionLanguages != null && SelectionLanguages.Count > 0)
			{
				if (_languageList.Count > 0 && SelectionLanguages.Count > 0)
                {
                    isEnabledSearchBar = true;
                    foreach (var obj in _languageList)
					{
                        obj.IsSelected = false;
						foreach (var selectionSkill in SelectionLanguages)
						{
                            if (obj.ID == selectionSkill.LanguageID)
                           // if (obj.ID == selectionSkill.Languages.ID)
                            {
								isToggleFired = false;
                                obj.IsSelected = true;
                                obj.LanguageID = selectionSkill.LanguageID;
                                obj.IsRead = selectionSkill.IsRead;
                                obj.IsWrite = selectionSkill.IsWrite;
                                obj.IsSpeak = selectionSkill.IsSpeak;
							}
						}
					}
				}
			}
			#endregion
			else
            {
                    isToggleFired = true;
            }
			LanguageListItemSource = _languageList;
            _TemplanguageList = LanguageListItemSource;


        }
		#endregion

		public Boolean _btnSendIsDestructive;
		public Boolean btnSendIsDestructive
		{
			get { return _btnSendIsDestructive; }
			set { _btnSendIsDestructive = value; OnPropertyChanged(); }
		}


		public Command DoneButtonClicked
		{
			get;
			set;
		}

		#region  onDoneClicked
		public async void onDoneClicked()
		{
            if (isClicked)
            {
                isClicked = false;
                btnSendIsDestructive = true;

                //MultipleLanguageSelectionHelper objSelectionHelper = new MultipleLanguageSelectionHelper();
                //List<MultipleLanguageSelectionBO> lstMultipleLanguageSelection = objSelectionHelper.GetData(SearchName);

                //if (lstMultipleLanguageSelection.Count > 0)
                //{
                //	objSelectionHelper.DeleteData();
                //}

                MultipleLanguageSelectionBO objSelectionBO = new MultipleLanguageSelectionBO();


                List<Languageknown> selectedLanguages = new List<Languageknown>();

                if (_languageList != null)
                {
                    foreach (var language in _languageList)
                    {
                        objSelectionBO.SearchName = SearchName;
                        objSelectionBO.ID = language.LanguageID;
                        objSelectionBO.LanguageID = language.LanguageID;
                        objSelectionBO.LanguageTitle = language.Title;
                        objSelectionBO.IsSelected = language.IsSelected;
                        objSelectionBO.IsRead = language.IsRead;
                        objSelectionBO.IsSpeak = language.IsSpeak;
                        objSelectionBO.IsWrite = language.IsWrite;
                        objSelectionBO.CreatedOn = DateTime.Now;

                        if (language.IsSelected)
                        {
                            //	objSelectionHelper.AddData(objSelectionBO);
                            selectedLanguages.Add(language);
                        }
                    }
                }
                //if(selectedSkills.Count>0)
                if (_valueGetter != null)
                {
                    _valueGetter.SetFieldValue(Constants.FieldType.Languages, selectedLanguages);
                }
                else
                {
                    MessagingCenter.Send<MultipleLanguageSelectionPageViewModel, List<Languageknown>>(this, "Language", selectedLanguages);
                }

                Navigation.PopAsync();
            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });
        }
		#endregion


		#region OnSkill_Toggled
		public async void OnSkill_Toggled(object sender, ToggledEventArgs e)
		{
			if (isToggleFired == true)
			{
				var selectedLanguage = ((Switch)sender).BindingContext as Languageknown;
				if (e.Value)
				{
					var move = new LanguageOption(selectedLanguage);
					await Navigation.PushAsync(move);
				}
				else if (e.Value == false)
				{

				}

				var languageCount = 0;
				foreach (var language in _languageList)
				{
					if (language.IsSelected)
						languageCount++;
				}
			}
			else
			{
				count = count + 1;
				if (!isToggleFired && count == SelectionLanguages.Count) isToggleFired = true;
			}

		}
		#endregion

	}
}
