﻿using System;
using System.Threading.Tasks;
using HireMe.Models;
using System.Windows.Input;
using Xamarin.Forms;
using GalaSoft.MvvmLight.Command;
using Acr.UserDialogs;
using HireMe.Views.JobSeeker;
using System.Diagnostics;
using HireMe.Models.JobSeeker;
using MvvmHelpers;
using HireMe.Helpers;
using Plugin.Permissions;
using Plugin.Permissions.Abstractions;

namespace HireMe.ViewModels.JobSeeker
{
    public class UserRegistration_mobile_ViewModel : BaseViewModel
    {
        private INavigation navigation;
        public ICommand RegistrationCommand { get; set; }
        private HttpCommonService _commonservice { get; set; }
        public UserRegistration_mobile_Model _RegistrationMobileRequestData { get; set; }
        public UserResponse _UserResponse { get; set; }
        public UserResponseValues _UserResponseValues { get; set; }
        SocialRegisterRequestData _socialRegisterRequesData { get; set; }
        public string ErrorMessage { get; set; }
        public INavigation _navigationservice;
        public bool isClicked = true;
        int isConditionAccept = 0;
        public bool IsSocialLogin = false;

        #region UserRegistration_mobile_ViewModel
        public UserRegistration_mobile_ViewModel(INavigation navigation)
        {

            _navigationservice = navigation;
            AppPreferences.Is_HireMee_PRO_User = false;



            IsRegisterButtonEnable = false;
            this.navigation = navigation;
            _RegistrationMobileRequestData = new UserRegistration_mobile_Model();
            _UserResponse = new UserResponse();
            _UserResponseValues = new UserResponseValues();
            _socialRegisterRequesData = new SocialRegisterRequestData();

            RegistrationCommand = new RelayCommand<string>(DoMobileRegistration);

            _commonservice = new HttpCommonService();

            RightSign = (string)Application.Current.Resources["RightSign"];

            MobileNumber = (string)Application.Current.Resources["RightSign"];


            isConditionAccept = 0;
            ReadCheckBoxText = (string)Application.Current.Resources["CheckBoxUnSelected"];

            ISCheckMailStatus = false;
            ISCheckMobileNumber = false;

            IsFirstNamevisible = false;
            IsMobilevisible = false;
            IsEmailvisible = false;
            FirstNameTextcolor = Color.Green;

            MobileTextcolor = Color.Green;

            OnCheckBoxClicked = new Command(CommonFunction);

            #region AutoFill Form Social Account

            if (AppPreferences.IsFBLoggeedIn == true)
            {

                if (AppPreferences.FacebookUserDetails != null)
                {
                    IsSocialLogin = true;
                    UserName = AppPreferences.FacebookUserDetails.first_name + " " + AppPreferences.FacebookUserDetails.last_name;
                    UserEmailAddress = AppPreferences.FacebookUserDetails.email;
                    if (!string.IsNullOrEmpty(UserEmailAddress))
                    {
                        EmailAddressStatusIcon = (string)Application.Current.Resources["RightSign"];
                        IsEmailvisible = true;
                        EmailTextcolor = Color.Green;
                        ISCheckMailStatus = false;
                    }
                   
                }
            }
            else if (AppPreferences.IsGoogleLoggedIn == true)
            {

                if (AppPreferences.GoogleUserDetails != null)
                {
                    IsSocialLogin = true;
                    UserName = AppPreferences.GoogleUserDetails.Name;
                    UserEmailAddress = AppPreferences.GoogleUserDetails.Email;
                    if (!string.IsNullOrEmpty(UserEmailAddress))
                    {
                        EmailAddressStatusIcon = (string)Application.Current.Resources["RightSign"];
                        IsEmailvisible = true;
                        ISCheckMailStatus = false;
                        EmailTextcolor = Color.Green;
                    }
                   
                }
            }
            else if (AppPreferences.IsLinkedInLoggedIn == true)
            {

                if (AppPreferences.LinkedInUserDetails != null)
                {
                    IsSocialLogin = true;
                    UserName = AppPreferences.LinkedInUserDetails.firstname + " " + AppPreferences.LinkedInUserDetails.lastname;
                    UserEmailAddress = AppPreferences.LinkedInUserDetails.emailaddress;
                    if (!string.IsNullOrEmpty(UserEmailAddress))
                    {
                        EmailAddressStatusIcon = (string)Application.Current.Resources["RightSign"];
                        IsEmailvisible = true;
                        EmailTextcolor = Color.Green;
                        ISCheckMailStatus = false;
                    }
                }
            }
            else
            {
                IsSocialLogin = false;
                AppPreferences.IsFBLoggeedIn = false;
                AppPreferences.IsGoogleLoggedIn = false;
                AppPreferences.IsLinkedInLoggedIn = false;
                UserName = string.Empty;
                UserEmailAddress = string.Empty;
                UserMobile = string.Empty;
            }
            #endregion

        }
        #endregion



        //#region AskSMSPermission
        //private async void AskSMSPermission()
        //{
        //    try
        //    {
        //        var status = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Sms);

        //        if (status != PermissionStatus.Granted)
        //        {
        //            var results = await CrossPermissions.Current.RequestPermissionsAsync(new[] { Permission.Sms });
        //            if (results != null)
        //            {
        //                status = results[Permission.Sms];
        //            }
        //        }

        //        if (status == PermissionStatus.Denied)
        //        {
        //            UserDialogs.Instance.Toast(MessageStringConstants.PermissionMessage);
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        System.Diagnostics.Debug.WriteLine(ex.Message);
        //        SendErrorMessageToServer(ex, "UserRegistration_mobile_ViewModel.AskSMSPermission");
        //    }
        //}
        //#endregion


        private async void DoMobileRegistration(string sender)
        {
            switch (sender)
            {
                case "RegisterMobile":
                    if (isClicked)
                    {
                        isClicked = false;
                        UserDialogs.Instance.ShowLoading();
                        if (!IsValidData())
                        {
                            if (!string.IsNullOrEmpty(ErrorMessage))
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(ErrorMessage);
                            }
                        }
                        else if (ISCheckMobileNumber == true)
                        {
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.MobileNoAlreadyExist);
                        }
                        else if (ISCheckMailStatus == true)
                        {
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.EmailAlreadyExist);
                        }
                        else
                        {
                            if (IsSocialLogin == true)
                            {
                                RegisterSocialLogin();
                            }
                            else
                            {
                                NormalRegistration();
                            }
                        }

                        //if (!IsValidData())
                        //{
                        //    if (!string.IsNullOrEmpty(ErrorMessage))
                        //    {
                        //        await UserDialogs.Instance.AlertAsync(ErrorMessage);
                        //    }
                        //}
                        //else if (ISCheckMobileNumber == true)
                        //{
                        //    await UserDialogs.Instance.AlertAsync(MessageStringConstants.MobileNoAlreadyExist);
                        //}
                        //else if (ISCheckMailStatus == true)
                        //{
                        //    await UserDialogs.Instance.AlertAsync(MessageStringConstants.EmailAlreadyExist);
                        //}
                        //else
                        //{
                        //    if (IsSocialLogin == true)
                        //    {
                        //        RegisterSocialLogin();
                        //    }
                        //    else
                        //    {
                        //        NormalRegistration();
                        //    }
                        //}
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;


                case "taplogin":
                    if (isClicked)
                    {
                        isClicked = false;
                        IsSocialLogin = false;
                        AppPreferences.IsFBLoggeedIn = false;
                        AppPreferences.IsGoogleLoggedIn = false;
                        UserName = string.Empty;
                        UserEmailAddress = string.Empty;
                        UserMobile = string.Empty;
                        Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                        return;
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;

                case "taptermsofuse":
                    if (isClicked)
                    {
                        isClicked = false;
                        await _navigationservice.PushAsync(new TermsOfUse());
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;

            }

        }


        public async void RegisterSocialLogin()
        {

            #region  Social Account



            #region FBLoggedIn
            if (AppPreferences.IsFBLoggeedIn == true)
            {

                if (AppPreferences.FacebookUserDetails != null)
                {
                    _socialRegisterRequesData.social_id = AppPreferences.FacebookUserDetails.id;
                    _socialRegisterRequesData.social_type = "Facebook";
                    try
                    {

                        var statusResult = await _commonservice.PostAsync<UserResponse, SocialRegisterRequestData>(APIData.API_BASE_URL + APIMethods.SocialRegister_v7, _socialRegisterRequesData);
                        if (statusResult != null)
                        {
                            IsSocialLogin = false;

                            if (statusResult.code == "200")
                            {
                                UserDialogs.Instance.HideLoading();
                                AppPreferences.UserValues = statusResult.responseText;
                                await navigation.PushAsync(new OTPVerifyPage("SocialMedia_UserRegistration"));
                            }
                            else
                            {
                                IsSocialLogin = false;
                                AppPreferences.IsFBLoggeedIn = false;
                                UserName = string.Empty;
                                UserMobile = string.Empty;
                                UserEmailAddress = string.Empty;
                                IsFirstNamevisible = false;
                                IsMobilevisible = false;
                                IsEmailvisible = false;
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(statusResult.message);
                            }
                        }
                        else
                        {
                            UserName = string.Empty;
                            UserMobile = string.Empty;
                            UserEmailAddress = string.Empty;
                            IsFirstNamevisible = false;
                            IsMobilevisible = false;
                            IsEmailvisible = false;
                            IsSocialLogin = false;
                            AppPreferences.IsFBLoggeedIn = false;
                            UserDialogs.Instance.HideLoading();
                        }
                    }
                    catch (Exception ex)
                    {
                        UserName = string.Empty;
                        UserMobile = string.Empty;
                        UserEmailAddress = string.Empty;
                        IsFirstNamevisible = false;
                        IsMobilevisible = false;
                        IsEmailvisible = false;
                        IsSocialLogin = false;
                        AppPreferences.IsFBLoggeedIn = false;
                        UserDialogs.Instance.HideLoading();
                        Debug.WriteLine(ex.Message);
                        SendErrorMessageToServer(ex, "UserRegistration_mobile_ViewModel.RegisterSocialLogin.FaceBookLoggedIn");
                    }

                }
            }
            #endregion

            #region Google LoggedIn
            else if (AppPreferences.IsGoogleLoggedIn == true)
            {
                if (AppPreferences.GoogleUserDetails != null)
                {
                    _socialRegisterRequesData.social_id = AppPreferences.GoogleUserDetails.ID;
                    _socialRegisterRequesData.social_type = "Google";
                    try
                    {

                        var statusResult = await _commonservice.PostAsync<UserResponse, SocialRegisterRequestData>(APIData.API_BASE_URL + APIMethods.SocialRegister_v7, _socialRegisterRequesData);
                        if (statusResult != null)
                        {
                            IsSocialLogin = false;
                            if (statusResult.code == "200")
                            {
                                UserDialogs.Instance.HideLoading();
                                AppPreferences.UserValues = statusResult.responseText;
                                await navigation.PushAsync(new OTPVerifyPage("SocialMedia_UserRegistration"));
                            }
                            else
                            {
                                UserName = string.Empty;
                                UserMobile = string.Empty;
                                UserEmailAddress = string.Empty;
                                IsFirstNamevisible = false;
                                IsMobilevisible = false;
                                IsEmailvisible = false;
                                IsSocialLogin = false;
                                AppPreferences.IsGoogleLoggedIn = false;
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(statusResult.message);
                            }
                        }
                        else
                        {
                            UserName = string.Empty;
                            UserMobile = string.Empty;
                            UserEmailAddress = string.Empty;
                            IsFirstNamevisible = false;
                            IsMobilevisible = false;
                            IsEmailvisible = false;
                            IsSocialLogin = false;
                            AppPreferences.IsGoogleLoggedIn = false;
                            UserDialogs.Instance.HideLoading();
                        }
                    }
                    catch (Exception ex)
                    {
                        UserName = string.Empty;
                        UserMobile = string.Empty;
                        UserEmailAddress = string.Empty;
                        IsFirstNamevisible = false;
                        IsMobilevisible = false;
                        IsEmailvisible = false;
                        IsSocialLogin = false;
                        AppPreferences.IsGoogleLoggedIn = false;
                        UserDialogs.Instance.HideLoading();
                        Debug.WriteLine(ex.Message);
                        SendErrorMessageToServer(ex, "UserRegistration_mobile_ViewModel.RegisterSocialLogin.GoogleLoggedIn");
                    }
                }
            }
            #endregion

            #region LinkedIn LoggedIn
            else if (AppPreferences.IsLinkedInLoggedIn == true)
            {
                if (AppPreferences.LinkedInUserDetails != null)
                {
                    _socialRegisterRequesData.social_id = AppPreferences.LinkedInUserDetails.id;
                    _socialRegisterRequesData.social_type = "LinkedIn";
                    try
                    {

                        var statusResult = await _commonservice.PostAsync<UserResponse, SocialRegisterRequestData>(APIData.API_BASE_URL + APIMethods.SocialRegister_v7, _socialRegisterRequesData);
                        if (statusResult != null)
                        {
                            IsSocialLogin = false;
                            if (statusResult.code == "200")
                            {
                                UserDialogs.Instance.HideLoading();
                                AppPreferences.UserValues = statusResult.responseText;
                                await navigation.PushAsync(new OTPVerifyPage("SocialMedia_UserRegistration"));
                            }
                            else
                            {
                                UserName = string.Empty;
                                UserMobile = string.Empty;
                                UserEmailAddress = string.Empty;
                                IsFirstNamevisible = false;
                                IsMobilevisible = false;
                                IsEmailvisible = false;
                                IsSocialLogin = false;
                                AppPreferences.IsLinkedInLoggedIn = false;
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(statusResult.message);
                            }
                        }
                        else
                        {
                            UserName = string.Empty;
                            UserMobile = string.Empty;
                            UserEmailAddress = string.Empty;
                            IsFirstNamevisible = false;
                            IsMobilevisible = false;
                            IsEmailvisible = false;
                            IsSocialLogin = false;
                            AppPreferences.IsLinkedInLoggedIn = false;
                            UserDialogs.Instance.HideLoading();
                        }
                    }
                    catch (Exception ex)
                    {
                        UserName = string.Empty;
                        UserMobile = string.Empty;
                        UserEmailAddress = string.Empty;
                        IsFirstNamevisible = false;
                        IsMobilevisible = false;
                        IsEmailvisible = false;
                        IsSocialLogin = false;
                        AppPreferences.IsLinkedInLoggedIn = false;
                        UserDialogs.Instance.HideLoading();
                        Debug.WriteLine(ex.Message);
                        SendErrorMessageToServer(ex, "UserRegistration_mobile_ViewModel.RegisterSocialLogin.LinkedLoggedIn");
                    }
                }
            }
            #endregion




            #endregion
        }

        private async void NormalRegistration()
        {
            try
            {
                IsRegisterButtonEnable = false;

                var statusResult = await _commonservice.PostAsync<UserResponse, UserRegistration_mobile_Model>(APIData.API_BASE_URL + APIMethods.RegisterNewUser, _RegistrationMobileRequestData);


                if(statusResult != null)
                {
                    UserDialogs.Instance.HideLoading();
                    if (statusResult.code == "200")
                    {
                        //try
                        //{
                        //    if(statusResult.responseText.apiVersionCheck != null)
                        //    {
                        //        CheckVersionUpdates _CheckVersionUpdates = new CheckVersionUpdates();
                        //        _CheckVersionUpdates.CheckVersion(statusResult.responseText.apiVersionCheck);
                        //    }
                        //}
                        //catch (Exception ex)
                        //{
                        //    UserDialogs.Instance.HideLoading();
                        //    SendErrorMessageToServer(ex, "UserRegistration_mobile_ViewModel.NormalRegistration.CheckVersionUpdates");
                        //}

                        AppPreferences.UserValues = statusResult.responseText;
                        await navigation.PushAsync(new OTPVerifyPage("UserRegistration"));
                        return;
                    }
                    else
                    {
                        await UserDialogs.Instance.AlertAsync(statusResult.message);
                    }
                } 
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                }

            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "UserRegistration_mobile_ViewModel.NormalRegistration");
            }
            finally
            {

                IsRegisterButtonEnable = true;
            }
        }


        void CommonFunction(object obj)
        {

            if (obj.ToString() == "1")
            {


                if (isConditionAccept == 0)
                {
                    ReadCheckBoxText = (string)Application.Current.Resources["CheckBoxSelected"];
                    isConditionAccept = 1;

                }
                else if (isConditionAccept == 1)
                {
                    ReadCheckBoxText = (string)Application.Current.Resources["CheckBoxUnSelected"];
                    isConditionAccept = 0;

                }
            }
        }

        private bool IsValidData()
        {
            ErrorMessage = string.Empty;
            bool isvalid = false;
            //if (!Utilities.ValidateUserFullName(UserName))
            //{
            //    ErrorMessage = MessageStringConstants.EnterValidFirstName;
            //    return isvalid;
            //}

            if (!Utilities.ValidateUserFirstName(UserName))
            {
                ErrorMessage = MessageStringConstants.EnterValidFirstName;
                return isvalid;
            }
            else if (string.IsNullOrEmpty(UserMobile) || string.IsNullOrWhiteSpace(UserMobile))
            {
                ErrorMessage = MessageStringConstants.EntermobileNo;
                return isvalid;
            }
            else if (!Utilities.ValidateMobileNumber(UserMobile))
            {
                ErrorMessage = MessageStringConstants.EnterValidmobileNo;
                return isvalid;
            }
            else if (string.IsNullOrEmpty(UserEmailAddress) || string.IsNullOrWhiteSpace(UserEmailAddress))
            {
                ErrorMessage = MessageStringConstants.EnterEmailAddress;
                return isvalid;
            }
            else if (!Utilities.ValidateEmailAddress(UserEmailAddress.Trim()))
            {
                ErrorMessage = MessageStringConstants.EnterValidEmailAddress;
                return isvalid;
            }
            //else if (!Utilities.ValidateEmailAddress(UserEmailAddress))
            //{
            //    ErrorMessage = MessageStringConstants.EnterValidEmailAddress;
            //    return isvalid;
            //}
            //else if (!Utilities.ValidateEmailAddress(UserEmailAddress.Trim()) && !Utilities.ValidateMobileNumber(UserEmailAddress.Trim()))
            //{
            //    ErrorMessage = MessageStringConstants.EnterValidEmailAddress;
            //    return isvalid;
            //}
            isvalid = true;
            if (isvalid)
            {
                if (IsSocialLogin == true)
                {
                    if (AppPreferences.IsFBLoggeedIn == true)
                    {
                        if (AppPreferences.FacebookUserDetails != null)
                        {
                            UserEmailAddress = AppPreferences.FacebookUserDetails.email;
                        }
                    }
                    if (AppPreferences.IsLinkedInLoggedIn == true)
                    {
                        if (AppPreferences.LinkedInUserDetails != null)
                        {
                            UserEmailAddress = AppPreferences.LinkedInUserDetails.emailaddress;
                        }
                    }
                    else if (AppPreferences.IsGoogleLoggedIn == true)
                    {
                        if (AppPreferences.GoogleUserDetails != null)
                        {
                            UserEmailAddress = AppPreferences.GoogleUserDetails.Email;
                        }
                    }
                    _socialRegisterRequesData.name = UserName;
                    _socialRegisterRequesData.mobile_number = UserMobile;
                    _socialRegisterRequesData.email_address = UserEmailAddress;

                }
                else
                {
                    _RegistrationMobileRequestData.name = UserName;
                    _RegistrationMobileRequestData.mobile_number = UserMobile;
                    _RegistrationMobileRequestData.email_address = UserEmailAddress;
                }
                AppPreferences.userName = UserName;
            }
            return isvalid;
        }

        #region Private Properties
        public Command OnCheckBoxClicked
        {
            get;
            set;
        }

        private Color _mobilenumtextcolor;
        public Color MobileTextcolor
        {
            get { return _mobilenumtextcolor; }
            set { _mobilenumtextcolor = value; OnPropertyChanged(); }
        }


        private Color _firstnametextcolor;
        public Color FirstNameTextcolor
        {
            get { return _firstnametextcolor; }
            set { _firstnametextcolor = value; OnPropertyChanged(); }
        }

        private bool _ismobilevisible;
        public bool IsMobilevisible
        {
            get { return _ismobilevisible; }
            set { _ismobilevisible = value; OnPropertyChanged(); }
        }

        private bool _isfirstnamevisible;
        public bool IsFirstNamevisible
        {
            get { return _isfirstnamevisible; }
            set { _isfirstnamevisible = value; OnPropertyChanged(); }
        }

        private bool _ISCheckMobileNumber;
        public bool ISCheckMobileNumber
        {
            get { return _ISCheckMobileNumber; }
            set { _ISCheckMobileNumber = value; OnPropertyChanged(); }
        }

        private string _rightsign;
        public string RightSign
        {
            get { return _rightsign; }
            set { _rightsign = value; OnPropertyChanged(); }
        }
        private string _mobilenumber;
        public string MobileNumber
        {
            get { return _mobilenumber; }
            set { _mobilenumber = value; OnPropertyChanged(); }
        }

        private bool _ischeckmailstatus;
        public bool ISCheckMailStatus
        {
            get { return _ischeckmailstatus; }
            set { _ischeckmailstatus = value; OnPropertyChanged(); }
        }
        private string _UserEmailAddress;

        public string UserEmailAddress
        {
            get { return _UserEmailAddress; }
            set { _UserEmailAddress = value; OnPropertyChanged(); }
        }

        private string _userName;

        public string UserName
        {
            get { return _userName; }
            set { _userName = value; OnPropertyChanged(); }
        }
        private bool _ismobilvisible;
        public bool IsEmailvisible
        {
            get { return _ismobilvisible; }
            set { _ismobilvisible = value; OnPropertyChanged(); }
        }
        private Color _emailtextcolor;
        public Color EmailTextcolor
        {
            get { return _emailtextcolor; }
            set { _emailtextcolor = value; OnPropertyChanged(); }
        }

        private bool _IsRegisterButtonEnable;

        public bool IsRegisterButtonEnable
        {
            get { return _IsRegisterButtonEnable; }
            set { _IsRegisterButtonEnable = value; OnPropertyChanged(); }
        }


        private string _emailaddressStatusIcon;
        public string EmailAddressStatusIcon
        {
            get { return _emailaddressStatusIcon; }
            set { _emailaddressStatusIcon = value; OnPropertyChanged(); }
        }
        private string _userMobile;

        public string UserMobile
        {
            get { return _userMobile; }
            set { _userMobile = value; OnPropertyChanged(); }
        }

        public string readCheckBoxText;
        public string ReadCheckBoxText
        {
            get { return readCheckBoxText; }
            set { readCheckBoxText = value; OnPropertyChanged(); }
        }
        #endregion

        #region Checkmail Status 
        public async Task<bool> CheckMailStatus(string mailid)
        {
            UserDialogs.Instance.ShowLoading();
            bool registeredemail = false;
            try
            {
                //if (Utilities.ValidateEmailAddress(UserEmailAddress.Trim()))
                //{
                    var request = new CheckMailRequestData();
                    request.EmailAddress = mailid;
                    var statusResult = await _commonservice.PostAsync<CheckMailResponseData, CheckMailRequestData>(APIData.API_BASE_URL + APIMethods.CheckEmaiID, request);
                    if (statusResult != null)
                    {
                        if (statusResult.Code == "203")
                        {
                            registeredemail = true;
                        }
                    }
                 
                //}
                //else
                //{
                //    registeredemail = false;
                //}
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "SeekerPersonalViewModel.CheckMailStatus");
                return registeredemail;
            }
            UserDialogs.Instance.HideLoading();
            return registeredemail;
        }
        #endregion

        #region Checkmail Mobile Number 
        public async Task<bool> CheckMobileNumber(string mobile)
        {
            UserDialogs.Instance.ShowLoading();
            bool registeredMobilenumber = false;
            try
            {
                var request = new CheckMailRequestData();
                request.MobileNumber = mobile;
                var statusResult = await _commonservice.PostAsync<CheckMobileNumberResponse, CheckMailRequestData>(APIData.API_BASE_URL + APIMethods.CheckMobileNumber, request);
                if (statusResult != null)
                {
                    if (statusResult.code == "203")
                    {
                        registeredMobilenumber = true;
                    }
                }
                UserDialogs.Instance.HideLoading();
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "UserRegistration_mobile_ViewModel.CheckMobileNumber");
            }
            return registeredMobilenumber;
        }
        #endregion

        private Command<string> tapCommand;
        public Command<string> TapCommand
        {
            get { return tapCommand ?? (tapCommand = new Command<string>(async arg => await OnTappedCommand(arg))); }
        }

        #region Unfocused Event
        private async Task OnTappedCommand(string ClassID)
        {
            if (ClassID.Equals("FullNameSign"))
            {
                var text = UserName;
                //if (text != null) //text = text.Trim();
                if (string.IsNullOrEmpty(text))
                {
                    RightSign = (string)Application.Current.Resources["WrongSign"];
                    IsFirstNamevisible = true;
                    FirstNameTextcolor = Color.Red;
                }
                else
                {
                    if (!Utilities.ValidateUserFirstName(text))
                    {
                        RightSign = (string)Application.Current.Resources["WrongSign"];
                        IsFirstNamevisible = true;
                        FirstNameTextcolor = Color.Red;
                    }
                    else
                    {
                        RightSign = (string)Application.Current.Resources["RightSign"];
                        IsFirstNamevisible = true;
                        FirstNameTextcolor = Color.Green;
                    }
                }
            }
            else if (ClassID.Equals("PhoneNumberSign"))
            {
                IsRegisterButtonEnable = false;
                var textPhoneNumberSign = UserMobile;
                if (textPhoneNumberSign != null) textPhoneNumberSign = textPhoneNumberSign.Trim();
                if (string.IsNullOrEmpty(textPhoneNumberSign))
                {
                    MobileNumber = (string)Application.Current.Resources["WrongSign"];
                    IsMobilevisible = true;
                    MobileTextcolor = Color.Red;
                }
                else
                {
                    if (!Utilities.ValidateMobileNumber(textPhoneNumberSign))
                    {
                        MobileNumber = (string)Application.Current.Resources["WrongSign"];
                        IsMobilevisible = true;
                        MobileTextcolor = Color.Red;
                    }
                    else
                    {
                        var moible = await CheckMobileNumber(UserMobile);
                        if (moible)
                        {
                            MobileNumber = (string)Application.Current.Resources["WrongSign"];
                            IsMobilevisible = true;
                            MobileTextcolor = Color.Red;
                            ISCheckMobileNumber = true;
                        }
                        else
                        {
                            MobileNumber = (string)Application.Current.Resources["RightSign"];
                            IsMobilevisible = true;
                            MobileTextcolor = Color.Green;
                            ISCheckMobileNumber = false;
                        }
                    }
                    EnableRegisterButton();
                }
            }

            else if (ClassID.Equals("EmailSign"))
            {
                CheckMailAddressStatus();
            }
        }

        private async void CheckMailAddressStatus()
        {
            IsRegisterButtonEnable = false;
            var textEmailSign = UserEmailAddress;
            if (textEmailSign != null) textEmailSign = textEmailSign.Trim();
            if (string.IsNullOrEmpty(textEmailSign))
            {
                EmailAddressStatusIcon = (string)Application.Current.Resources["WrongSign"];
                IsEmailvisible = true;
                EmailTextcolor = Color.Red;
            }
            else if (!Utilities.ValidateEmailAddress(UserEmailAddress.Trim()))
            {
                EmailAddressStatusIcon = (string)Application.Current.Resources["WrongSign"];
                IsEmailvisible = true;
                EmailTextcolor = Color.Red;
            }
            else
            {
                var mailstatus = await CheckMailStatus(UserEmailAddress);
                if (mailstatus)
                {
                    EmailAddressStatusIcon = (string)Application.Current.Resources["WrongSign"];
                    IsEmailvisible = true;
                    EmailTextcolor = Color.Red;
                    ISCheckMailStatus = true;
                }
                else
                {
                    EmailAddressStatusIcon = (string)Application.Current.Resources["RightSign"];
                    IsEmailvisible = true;
                    EmailTextcolor = Color.Green;
                    ISCheckMailStatus = false;
                }
            }
            EnableRegisterButton();
        }

        private void EnableRegisterButton()
        {
            try
            {
                if (EmailAddressStatusIcon == (string)Application.Current.Resources["RightSign"] && MobileNumber == (string)Application.Current.Resources["RightSign"])
                {
                    IsRegisterButtonEnable = true;
                }
                else
                {
                    IsRegisterButtonEnable = false;
                }

            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "UserRegistration_mobile_ViewModel.EnableRegisterButton");
            }
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}

