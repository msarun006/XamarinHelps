﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using HireMe.Helpers;
using HireMe.Models;
using HireMe.Models.JobSeeker;
using HireMe.Views.JobSeeker;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.JobSeeker
{
    public class EditBasicDetailsViewModel : BaseViewModel
    {
        #region Initialization
        public bool isClicked = true;
        public ICommand OnCommand { get; set; }
        INavigation Navigation;
        public string ErrorMessage { get; set; }
        bool registeredemail;
        bool registeredMobilenumber;
        bool IsMobileNumberVerified;
        bool IsEmailIDVerified;
        string usermobileno;
        string usermail;
        public UserEmailUpdateModel _UserEmailUpdateModel { get; set; }
        public UserEmailUpdateResponse _UserEmailUpdateResponse { get; set; }


        public UserMobileNoUpdateModel _UserMobileNoUpdateModel { get; set; }
        public UserMobileNoUpdateResponseValue _UserMobileNoUpdateResponseValue { get; set; }


        public EditBasicInfoDetailsRequest _basicDetailsUpdateRequestData { get; set; }
        public SendOTPRequest _SendOTPRequest { get; set; }
        private HttpCommonService _commonservice { get; set; }
        #endregion

        //#region Constructor 
        //public EditBasicDetailsViewModel(INavigation nav, string firstname, string lastname, string emailid, string mobile)
        //{
        //    Navigation = nav;
        //    OnCommand = new RelayCommand<string>(OnEditDetails);
        //    _basicDetailsUpdateRequestData = new EditBasicInfoDetailsRequest();
        //    _SendOTPRequest = new SendOTPRequest();
        //    _commonservice = new HttpCommonService();
        //    _UserEmailUpdateModel = new UserEmailUpdateModel();
        //    _UserEmailUpdateResponse = new UserEmailUpdateResponse();
        //    _UserMobileNoUpdateModel = new UserMobileNoUpdateModel();
        //    _UserMobileNoUpdateResponseValue = new UserMobileNoUpdateResponseValue();
        //    FirstName = AppPreferences.FirstName;
        //    LastName = AppPreferences.LastName;
        //    EmailID = AppPreferences.EmailAddress;
        //    HiremeeID = AppPreferences.HireMeeID;
        //    MobileNo = AppPreferences.MobileNumber;
        //    if (!string.IsNullOrEmpty(AppPreferences.ProfilePicture))
        //    {
        //        profilepic = AppPreferences.ProfilePicture;
        //    }
        //    else
        //    {
        //        profilepic = (string)Application.Current.Resources["IconUser"];
        //    }
        //    RightSign = (string)Application.Current.Resources["RightSign"];
        //    LastnameRightSign = (string)Application.Current.Resources["RightSign"];
        //    MobileNumber = (string)Application.Current.Resources["RightSign"];
        //    EmailAddress = (string)Application.Current.Resources["RightSign"];
        //    IsFirstNamevisible = false;
        //    IsLastNamevisible = false;
        //    IsMobilevisible = false;
        //    IsEmailvisible = false;
        //    MessagingCenter.Subscribe<OTPVerifyViewModel, string>(this, "UpdateBasicDetails", (sender, arg) =>
        //    {
        //        if (arg == "EmailVerified")
        //        {
        //            EmailVerificationStatus = "Email Address verified!";
        //            EmailVerificationTextcolor = Color.Green;
        //            registeredemail = false;
        //        }
        //        else if (arg == "EmailNotVerified")
        //        {
        //            EmailVerificationStatus = "Email Address not yet verified!";
        //            EmailVerificationTextcolor = Color.Red;
        //            registeredemail = true;
        //        }

        //        else if (arg == "MobileNumberVerified")
        //        {
        //            MobileVerifiedOrNot = "Mobile Number Verified!";
        //            MobileNumberVerifyOrNotTextColor = Color.Green;
        //            IsMobileNumberVerified = true;
        //            // SaveBasicInfo();
        //        }
        //        else if (arg == "MobileNumberNotVerified")
        //        {
        //            MobileVerifiedOrNot = "Mobile Number Not Yet Verified!";
        //            MobileNumberVerifyOrNotTextColor = Color.Red;
        //            IsMobileNumberVerified = false;
        //        }

        //    });

        //    ISCheckMailStatus = true;
        //    if (!string.IsNullOrEmpty(AppPreferences.ProfilePicture))
        //    {
        //        profilepic = AppPreferences.ProfilePicture;
        //    }
        //    else
        //    {
        //        profilepic = (string)Application.Current.Resources["IconUser"];
        //    }

        //    ISCheckMailStatus = true;
        //    if (AppSessionData.CurrentUser.EmailVerified == "0")
        //    {
        //        EmailVerificationStatus = "Email Address not yet verified!";
        //        EmailVerificationTextcolor = Color.Red;
        //        registeredemail = true;
        //    }
        //    else
        //    {
        //        EmailVerificationStatus = "Email Address verified!";
        //        EmailVerificationTextcolor = Color.Green;
        //        registeredemail = false;
        //    }
        //    ISCheckMobileNumber = true;
        //    if (AppSessionData.CurrentUser.MobileVerified == "0")
        //    {
        //        MobileVerifiedOrNot = "Mobile Number Not Yet Verified!";
        //        MobileNumberVerifyOrNotTextColor = Color.Red;
        //        IsMobileNumberVerified = false;
        //    }
        //    else
        //    {
        //        MobileVerifiedOrNot = "Mobile Number Verified!";
        //        MobileNumberVerifyOrNotTextColor = Color.Green;
        //        IsMobileNumberVerified = true;

        //    }
        //    FirstNameTextcolor = Color.Green;
        //    LastNameTextcolor = Color.Green;
        //    MobileTextcolor = Color.Green;
        //    EmailTextcolor = Color.Green;
        //    MessagingCenter.Subscribe<ChangeProfilePictrurePageViewModel, string>(this, "ChangeProfilePicture", ChangeProfilePicture);
        //}

        #region Default Constructor
        public EditBasicDetailsViewModel(INavigation nav)
        {
            Navigation = nav;
            OnCommand = new RelayCommand<string>(OnEditDetails);
            _basicDetailsUpdateRequestData = new EditBasicInfoDetailsRequest();
            _SendOTPRequest = new SendOTPRequest();
            _commonservice = new HttpCommonService();

            _UserEmailUpdateModel = new UserEmailUpdateModel();
            _UserEmailUpdateResponse = new UserEmailUpdateResponse();

            _UserMobileNoUpdateModel = new UserMobileNoUpdateModel();
            _UserMobileNoUpdateResponseValue = new UserMobileNoUpdateResponseValue();
            _SendOTPRequest = new SendOTPRequest();
            _commonservice = new HttpCommonService();

            //if (AppPreferences.LoadBasicDetails !=null)
            //{
            //    LoadBasicData(AppPreferences.LoadBasicDetails);
            //}
            //getProfileData();
            FirstName = AppPreferences.LoadSeekerDashboardData.ProfileDetails.FirstName;
            LastName = AppPreferences.LoadSeekerDashboardData.ProfileDetails.LastName;
            EmailID = AppPreferences.LoadSeekerDashboardData.ProfileDetails.EmailAddress;
            HiremeeID = AppPreferences.LoadSeekerDashboardData.ProfileDetails.HireMeeID;
            MobileNo = AppPreferences.LoadSeekerDashboardData.ProfileDetails.MobileNumber;
            if (!string.IsNullOrEmpty(AppPreferences.ProfilePicture))
            {
                profilepic = AppPreferences.ProfilePicture;
            }
            else
            {
                profilepic = (string)Application.Current.Resources["IconUser"];
            }
            RightSign = (string)Application.Current.Resources["RightSign"];
            LastnameRightSign = (string)Application.Current.Resources["RightSign"];
            MobileNumber = (string)Application.Current.Resources["RightSign"];
            EmailAddress = (string)Application.Current.Resources["RightSign"];
            IsFirstNamevisible = false;
            IsLastNamevisible = false;
            IsMobilevisible = false;
            IsEmailvisible = false;
            MessagingCenter.Subscribe<OTPVerifyViewModel, string>(this, "UpdateBasicDetails", (sender, arg) =>
            {
                if (arg == "EmailVerified")
                {
                    EmailVerificationStatus = "Email Address verified!";
                    EmailVerificationTextcolor = Color.Green;
                    registeredemail = false;
                }
                else if (arg == "EmailNotVerified")
                {
                    EmailVerificationStatus = "Email Address not yet verified!";
                    EmailVerificationTextcolor = Color.Red;
                    registeredemail = true;
                }

                else if (arg == "MobileNumberVerified")
                {
                    MobileVerifiedOrNot = "Mobile Number Verified!";
                    MobileNumberVerifyOrNotTextColor = Color.Green;


                    if (!IsMobileNumberVerified)
                    {
                        SaveBasicInfo();
                        IsMobileNumberVerified = true;
                    }

                }
                else if (arg == "MobileNumberNotVerified")
                {
                    MobileVerifiedOrNot = "Mobile Number Not Yet Verified!";
                    MobileNumberVerifyOrNotTextColor = Color.Red;
                    IsMobileNumberVerified = false;
                }

            });


            ISCheckMailStatus = true;
            if (AppPreferences.LoadSeekerDashboardData.ProfileDetails.EmailVerified == "0")
            {
                EmailVerificationStatus = "Email Address not yet verified!";
                EmailVerificationTextcolor = Color.Red;
                registeredemail = true;
            }
            else
            {
                EmailVerificationStatus = "Email Address verified!";
                EmailVerificationTextcolor = Color.Green;
                registeredemail = false;
            }
            ISCheckMobileNumber = true;
            if (AppPreferences.LoadSeekerDashboardData.ProfileDetails.MobileVerified == "0")
            {
                MobileVerifiedOrNot = "Mobile Number Not Yet Verified!";
                MobileNumberVerifyOrNotTextColor = Color.Red;
                IsMobileNumberVerified = false;
            }
            else
            {
                MobileVerifiedOrNot = "Mobile Number Verified!";
                MobileNumberVerifyOrNotTextColor = Color.Green;
                IsMobileNumberVerified = true;

            }
            FirstNameTextcolor = Color.Green;
            LastNameTextcolor = Color.Green;
            MobileTextcolor = Color.Green;
            EmailTextcolor = Color.Green;
            MessagingCenter.Subscribe<ChangeProfilePictrurePageViewModel, string>(this, "ChangeProfilePicture", ChangeProfilePicture);
        }




        #endregion

        //private void getProfileData()
        //{
        //    try
        //    {
        //        Device.BeginInvokeOnMainThread(async () =>
        //        {
        //            UserDialogs.Instance.ShowLoading();

        //            SeekerDashboardModel SeekerDashboardModel = new SeekerDashboardModel();
        //            var resultdata = await _commonservice.PostAsync<SeekerDashboardResponseModel, SeekerDashboardModel>(APIData.API_BASE_URL + APIMethods.GetPersonalDetails, SeekerDashboardModel);

        //            if (resultdata != null)
        //            {
        //                if (resultdata.Code == "200")
        //                {
        //                    AppPreferences.LoadBasicDetails = resultdata.ProfileDetails;
        //                    var statusResult = AppPreferences.LoadBasicDetails;
        //                    LoadBasicData(AppPreferences.LoadBasicDetails);
        //                    UserDialogs.Instance.HideLoading();

        //                }
        //            }

        //        });
        //    }
        //    catch (Exception ex)
        //    {
        //        UserDialogs.Instance.HideLoading();
        //        Debug.WriteLine(ex.Message);
        //        SendErrorMessageToServer(ex, "EditBasicDetailsViewModel.getProfileData");
        //    }
        //}


        //public void LoadBasicData(JobSeekerProfileDetails statusResult)
        //{
        //    if (statusResult != null)
        //    {

        //        FirstName = statusResult.FirstName;
        //        LastName = statusResult.LastName;
        //        EmailID = statusResult.EmailAddress;
        //        HiremeeID = statusResult.HireMeeID;
        //        MobileNo = statusResult.MobileNumber;
        //    }
        //    else
        //    {
        //        FirstName = string.Empty;
        //        LastName = string.Empty;
        //        EmailID = string.Empty;
        //        HiremeeID = AppPreferences.HireMeeID;
        //        MobileNo = string.Empty;
        //    }
        //}

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        #region Command Operation
        private async void OnEditDetails(string obj)
        {
            try
            {

                switch (obj)
                {
                    case "OnProfileImage":
                        if (isClicked)
                        {
                            isClicked = false;
                            await Navigation.PushAsync(new ChangeProfilePicturePage());
                        }
                        await Task.Run(async () =>
                         {
                             await Task.Delay(500);
                             isClicked = true;
                         });
                        break;


                    //case "DoVerify":

                    //    if (isClicked)
                    //    {
                    //        //isClicked = false;

                    //        await VerifyUserMobileNo();
                    //    }
                    //    await Task.Run(async () =>
                    //    {
                    //        await Task.Delay(500);
                    //        isClicked = true;
                    //    });
                    //    break;
                    //Application.Current.Properties["mobileno"] = MobileNo;
                    //Application.Current.Properties["page"] = "EditBasicDetails";
                    //await Application.Current.SavePropertiesAsync();





                    #region Save API Call
                    case "Save":
                        if (!IsValidData())
                        {
                            if (!string.IsNullOrEmpty(ErrorMessage))
                            {
                                await UserDialogs.Instance.AlertAsync(ErrorMessage);
                            }
                        }

                        else if (registeredMobilenumber == true)
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.MobileNoAlreadyExist);
                        }
                        else if (IsMobileNumberVerified == false && AppPreferences.IsVerifyMobileNo == false)
                        {
                            var yes = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.mobilenumbernotverify, null, "OK", "Cancel");
                            if (yes)
                            {
                                await VerifyUserMobileNo();
                            }
                            else
                            {
                                await SaveBasicInfo();
                            }
                        }
                        else  /* if (usermobileno == MobileNo)*/
                        {
                            await SaveBasicInfo();
                        }
                        break;
                    #endregion

                    #region Send OTP To Mail API Call
                    case "SendOTP":
                        if (isClicked)
                        {
                            isClicked = false;
                            await CheckMailStatus(EmailID);

                            //await PopupNavigation.PushAsync(new OTPVerifyPage("SeekerPersonalAndEducationalDetails"));
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(500);
                            isClicked = true;
                        });
                        break;
                        #endregion

                }

            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "EditBasicDetailsViewModel.OnEditDetails");
            }
        }

        #endregion

        #region Save BasicInfo API CAll
        private async Task SaveBasicInfo()
        {
            try
            {

                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {
                    UserDialogs.Instance.ShowLoading();

                    _basicDetailsUpdateRequestData.FirstName = FirstName;
                    _basicDetailsUpdateRequestData.LastName = LastName;
                    _basicDetailsUpdateRequestData.MobileNumber = MobileNo;
                    _basicDetailsUpdateRequestData.EmailAddress = EmailID;

                    var statusResult = await _commonservice.PostAsync<EditBasicInfoDetailsResponse, EditBasicInfoDetailsRequest>(APIData.API_BASE_URL + APIMethods.UpdateBasicInfoDetails, _basicDetailsUpdateRequestData);
                    if (statusResult != null)
                    {
                        if (statusResult.code == "200")
                        {
                            string[] values = { FirstName, LastName, MobileNo };
                            MessagingCenter.Send(this, "UpdateBasicDetails", values);
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(statusResult.message);
                            AppPreferences.IsSeekerDashboardDataDownloaded = false;
                        }
                        else if (statusResult.code == "199")
                        {
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.SessionExpiered);
                            Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                            return;
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(statusResult.message);
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "EditBasicDetailsViewModel.SaveBasicInfo");
            }
        }

        #endregion

        #region VerifyUserMobileNo
        private async Task VerifyUserMobileNo()
        {
            if (!MobileNoValidData())
            {
                if (!string.IsNullOrEmpty(ErrorMessage))
                {
                    await UserDialogs.Instance.AlertAsync(ErrorMessage);
                }
            }
            else if (registeredMobilenumber == true)
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.MobileNoAlreadyExist);
            }
            else
            {
                try
                {

                    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                    if (isNetworkAvailable)
                    {
                        if (AppSessionData.ActiveToken != null)
                        {
                            //  MessagingCenter.Send(this, "UpdateBasicDetails", values);

                            _UserMobileNoUpdateModel.mobile_number = MobileNo;
                            _UserMobileNoUpdateModel.hiremee_id = AppSessionData.ActiveToken.HireMeID;
                            _UserMobileNoUpdateModel.token = AppSessionData.ActiveToken.Token; //AppPreferences.TempToken;
                        }
                        //UserMobileNoUpdateModel,UserMobileNoUpdateResponseValue,UserMobileNoUpdateResponse
                        UserDialogs.Instance.ShowLoading();
                        var result = await _commonservice.PostAsync<UserMobileNoUpdateResponse, UserMobileNoUpdateModel>(APIData.API_BASE_URL + APIMethods.Email_Mobile_Change_OTP_v7, _UserMobileNoUpdateModel);
                        if (result != null)
                        {

                            if (result.code == "200")
                            {

                                UserDialogs.Instance.HideLoading();
                                //AppPreferences.IsVerifyMobileNo = true;
                                AppPreferences.MobileNoUpdateValues = result.responseText;
                                AppPreferences.IsSeekerDashboardDataDownloaded = false;
                                AppPreferences.MobileNumber = MobileNo;
                                //IsMobileNumberVerified = true;
                                await Navigation.PushAsync(new OTPVerifyPage("EditBasicDetailsMobileNo"));

                            }
                            else if (result.code == "199")
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.SessionExpiered);
                                Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                                return;
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                IsMobileNumberVerified = false;
                                await UserDialogs.Instance.AlertAsync(result.message);
                            }
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                    }
                }
                catch (Exception ex)
                {
                    UserDialogs.Instance.HideLoading();
                    Debug.WriteLine(ex.Message);
                    SendErrorMessageToServer(ex, "EditBasicDetailsViewModel.VerifyUserMobileNo");
                    //await UserDialogs.Instance.AlertAsync(ex.Message);

                }
            }
        }

        #endregion

        #region VerifyUserNewEmailAddress
        private async Task VerifyUserNewEmailAddress()
        {

            if (!IsEmailIdValidData())
            {
                if (!string.IsNullOrEmpty(ErrorMessage))
                {
                    await UserDialogs.Instance.AlertAsync(ErrorMessage);
                }
            }
            else if (!Utilities.ValidateEmailAddress(EmailID.Trim()))
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.InvalidEmailAddress);
            }
            else
            {
                try
                {

                    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                    if (isNetworkAvailable)
                    {
                        if (AppSessionData.ActiveToken != null)
                        {
                            // MessagingCenter.Send(this, "UpdateBasicDetails", values);
                            _UserEmailUpdateModel.email_address = EmailID;
                            _UserEmailUpdateModel.hiremee_id = AppSessionData.ActiveToken.HireMeID;
                            _UserEmailUpdateModel.token = AppSessionData.ActiveToken.Token; //AppPreferences.TempToken;

                            //UserEmailUpdateModel, UserEmailUAppSessionData.ActiveTokenpdateResponse ,UserEmailUpdateResponseValue
                            UserDialogs.Instance.ShowLoading();
                            var result = await _commonservice.PostAsync<UserEmailUpdateResponse, UserEmailUpdateModel>(APIData.API_BASE_URL + APIMethods.Email_Mobile_Change_OTP_v7, _UserEmailUpdateModel);
                            if (result != null)
                            {
                                if (result.code == "200")
                                {

                                    AppPreferences.EmailUpdateValues = result.responseText;
                                    //ISCheckMailStatus = true;
                                    //EmailVerificationStatus = "Email Address verified!";
                                    //EmailVerificationTextcolor = Color.Green;
                                    AppPreferences.EmailAddress = EmailID;
                                    usermail = EmailID;
                                    UserDialogs.Instance.HideLoading();
                                    await Navigation.PushAsync(new OTPVerifyPage("EditBasicDetailsEmail"));
                                }
                                else if (result.code == "199")
                                {
                                    UserDialogs.Instance.HideLoading();
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.SessionExpiered);
                                    Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                                    return;
                                }
                                else
                                {
                                    UserDialogs.Instance.HideLoading();
                                    await UserDialogs.Instance.AlertAsync(result.message);
                                }
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnectionSlow);
                        }
                    }
                }
                catch (Exception ex)
                {
                    UserDialogs.Instance.HideLoading();
                    Debug.WriteLine(ex.Message);
                    SendErrorMessageToServer(ex, "EditBasicDetailsViewModel.VerifyUserNewEmailAddress");

                }
            }
        }

        #endregion

        #region Unfocused Command Operation
        private Command<string> tapCommand;
        public Command<string> TapCommand
        {
            get { return tapCommand ?? (tapCommand = new Command<string>(async arg => await OnTappedCommand(arg))); }
        }

        /// <summary>
        /// All Unfocused events are handled by tapcommand.
        /// </summary>
        /// <param name="sender"></param>
        /// <returns></returns>
        #region Unfocused Event
        private async Task OnTappedCommand(string sender)
        {
            switch (sender)
            {
                #region First Name 
                case "FullNameSign":
                    var text = FirstName;
                    //if (text != null) //text = text.Trim();
                    if (string.IsNullOrEmpty(text))
                    {
                        RightSign = (string)Application.Current.Resources["WrongSign"];
                        IsFirstNamevisible = true;
                        FirstNameTextcolor = Color.Red;
                    }
                    else
                    {
                        if (!Utilities.ValidateUserFirstName(text))
                        {
                            RightSign = (string)Application.Current.Resources["WrongSign"];
                            IsFirstNamevisible = true;
                            FirstNameTextcolor = Color.Red;
                        }
                        else
                        {
                            RightSign = (string)Application.Current.Resources["RightSign"];
                            IsFirstNamevisible = true;
                            FirstNameTextcolor = Color.Green;
                        }
                    }
                    break;
                #endregion

                #region Last Name
                case "LastNameSign":
                    var textlastname = LastName;
                    if (textlastname != null) textlastname = textlastname.Trim();
                    if (string.IsNullOrEmpty(textlastname))
                    {
                        LastnameRightSign = (string)Application.Current.Resources["WrongSign"];
                        IsLastNamevisible = true;
                        LastNameTextcolor = Color.Red;
                    }
                    else
                    {
                        if (!Utilities.ValidateUserLastName(textlastname))
                        {
                            LastnameRightSign = (string)Application.Current.Resources["WrongSign"];
                            IsLastNamevisible = true;
                            LastNameTextcolor = Color.Red;
                        }
                        else
                        {
                            LastnameRightSign = (string)Application.Current.Resources["RightSign"];
                            IsLastNamevisible = true;
                            LastNameTextcolor = Color.Green;
                        }

                    }
                    break;
                #endregion

                #region Email 
                case "EmailSign":
                    var textEmailSign = EmailID;
                    if (textEmailSign != null) textEmailSign = textEmailSign.Trim();
                    if (string.IsNullOrEmpty(textEmailSign))
                    {
                        EmailAddress = (string)Application.Current.Resources["WrongSign"];
                        IsEmailvisible = true;
                        EmailTextcolor = Color.Red;
                    }
                    else
                    {
                        if (!Utilities.ValidateEmailAddress(textEmailSign))
                        {
                            EmailAddress = (string)Application.Current.Resources["WrongSign"];
                            IsEmailvisible = true;
                            EmailTextcolor = Color.Red;
                        }
                        else
                        {
                            var mailstatus = await CheckMailStatus(EmailID);
                            if (mailstatus)
                            {
                                EmailAddress = (string)Application.Current.Resources["RightSign"];
                                IsEmailvisible = true;
                                EmailTextcolor = Color.Green;
                                ISCheckMailStatus = true;
                                EmailVerificationStatus = MessageStringConstants.EmailAlreadyExist;
                                EmailVerificationTextcolor = Color.Red;

                            }
                            else
                            {
                                EmailAddress = (string)Application.Current.Resources["RightSign"];
                                IsEmailvisible = true;
                                EmailTextcolor = Color.Green;
                                ISCheckMailStatus = true;
                                if (IsEmailIDVerified == false)
                                {
                                    EmailVerificationStatus = "Email Address not yet verified!";
                                    EmailVerificationTextcolor = Color.Red;
                                }
                                else
                                {
                                    EmailVerificationStatus = "Email Address Already Verified!";
                                    EmailVerificationTextcolor = Color.Green;
                                }

                            }
                        }
                    }
                    break;
                #endregion

                #region Phone Number
                case "PhoneNumberSign":
                    var textPhoneNumberSign = MobileNo;
                    if (textPhoneNumberSign != null) textPhoneNumberSign = textPhoneNumberSign.Trim();
                    if (string.IsNullOrEmpty(textPhoneNumberSign))
                    {
                        MobileNumber = (string)Application.Current.Resources["WrongSign"];
                        IsMobilevisible = true;
                        MobileTextcolor = Color.Red;
                    }
                    else
                    {
                        if (!Utilities.ValidateMobileNumber(textPhoneNumberSign))
                        {
                            MobileNumber = (string)Application.Current.Resources["WrongSign"];
                            IsMobilevisible = true;
                            MobileTextcolor = Color.Red;
                        }
                        else
                        {
                            var mobile = await CheckMobileNumber(MobileNo);
                            if (mobile)
                            {
                                MobileNumber = (string)Application.Current.Resources["WrongSign"];
                                IsMobilevisible = true;
                                MobileTextcolor = Color.Red;
                                ISCheckMobileNumber = true;
                                MobileVerifiedOrNot = "Mobile Number already exist with us!";
                                MobileNumberVerifyOrNotTextColor = Color.Red;

                            }
                            else
                            {
                                MobileNumber = (string)Application.Current.Resources["RightSign"];
                                IsMobilevisible = true;
                                MobileTextcolor = Color.Green;
                                ISCheckMobileNumber = true;
                                if (IsMobileNumberVerified == true)
                                {
                                    MobileVerifiedOrNot = "Mobile Number Verified!";
                                    MobileNumberVerifyOrNotTextColor = Color.Green;
                                }
                                else
                                {
                                    MobileVerifiedOrNot = "Mobile Number Not Yet Verified!";
                                    MobileNumberVerifyOrNotTextColor = Color.Red;
                                }
                            }
                        }
                    }
                    break;
                    #endregion
            }
        }

        #endregion
        #endregion

        #region Checkmail Status 
        public async Task<bool> CheckMailStatus(string mailid)
        {
            UserDialogs.Instance.ShowLoading();
            registeredemail = false;
            IsEmailIDVerified = false;
            var request = new CheckMobileNumberRequest
            {
                HiremeeID = AppSessionData.ActiveToken.HireMeID,
                EmailAddressStratus = EmailID
            };
            var statusResult = await _commonservice.PostAsync<CheckMobileNumberResponse, CheckMobileNumberRequest>(APIData.API_BASE_URL + APIMethods.CheckEmaiID, request);
            if (statusResult != null)
            {
                UserDialogs.Instance.HideLoading();
                if (statusResult.code == "200" && statusResult.verified == "0")
                {
                    registeredemail = true;
                    IsEmailIDVerified = false;
                    await UserDialogs.Instance.AlertAsync(statusResult.message);
                    await VerifyUserNewEmailAddress();
                }
                else if (statusResult.code == "200" && statusResult.verified == "1")
                {
                    registeredemail = false;
                    IsEmailIDVerified = true;
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.EmailAddressAlreadyVerified);
                }
                else if (statusResult.code == "203")
                {
                    registeredemail = true;
                    IsEmailIDVerified = false;
                }
                else if (statusResult.code == "200")
                {
                    registeredemail = false;
                    IsEmailIDVerified = false;
                    await VerifyUserNewEmailAddress();
                }
                else if (statusResult.code == "199")
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.SessionExpiered);
                    Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                }


            }
            else
            {
                UserDialogs.Instance.HideLoading();
            }

            return registeredemail;
        }
        #endregion

        #region Check Mobile Number 
        public async Task<bool> CheckMobileNumber(string mobile)
        { //sudha1
            //UserDialogs.Instance.ShowLoading("verifying Mobile Number...");
            UserDialogs.Instance.ShowLoading();
            registeredMobilenumber = false;
            IsMobileNumberVerified = false;
            var request = new CheckMobileNumberRequest
            {
                HiremeeID = AppPreferences.ActiveToken.HireMeID,
                MobileNumber = MobileNo
            };
            var statusResult = await _commonservice.PostAsync<CheckMobileNumberResponse, CheckMobileNumberRequest>(APIData.API_BASE_URL + APIMethods.CheckMobileNumber, request);
            if (statusResult != null)
            {
                UserDialogs.Instance.HideLoading();
                if (statusResult.code == "200" && statusResult.verified == "0")
                {
                    var yes = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.MobileNumberNotVerified, null, "OK", "Cancel");
                    if (yes)
                    {
                        await VerifyUserMobileNo();
                    }
                }
                else if (statusResult.code == "200" && statusResult.verified == "1")
                {
                    IsMobileNumberVerified = true;
                }
                else if (statusResult.code == "200")
                {
                    var yes = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.MobileNumberNotVerified, null, "OK", "Cancel");
                    if (yes)
                    {
                        await VerifyUserMobileNo();
                    }
                }
                else if (statusResult.code == "203")
                {
                    registeredMobilenumber = true;
                }
                else if (statusResult.code == "199")
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.SessionExpiered);
                    Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                    
                }



            }

            return registeredMobilenumber;
        }
        #endregion

        #region VladidateFields
        private bool IsValidData()
        {
            ErrorMessage = string.Empty;
            bool isvalid = false;

            //if (!Utilities.ValidateUserFullName(FirstName))
            //{
            //    ErrorMessage = MessageStringConstants.EnterValidFirstName;
            //    return isvalid;
            //}

            if (!Utilities.ValidateUserFirstName(FirstName))
            {
                ErrorMessage = MessageStringConstants.EnterValidFirstName;
                return isvalid;
            }
            else if (!Utilities.ValidateUserLastName(LastName))
            {
                ErrorMessage = MessageStringConstants.EnterValidLastName;
                return isvalid;
            }

            else if (!Utilities.ValidateMobileNumber(MobileNo))
            {
                ErrorMessage = MessageStringConstants.EnterValidMobileNumber;
                return isvalid;
            }

            //else if (usermobileno != MobileNo && AppPreferences.IsVerifyMobileNo == false)
            //{
            //    ErrorMessage = MessageStringConstants.VerifyMobileNo;
            //    return isvalid;
            //}



            //if (AppPreferences.IsVerifyMobileNo == false)
            //{
            //	ErrorMessage = MessageStringConstants.VerifyMobileNo;
            //             return isvalid;
            //         }


            isvalid = true;
            if (isvalid)
            {
                _basicDetailsUpdateRequestData.FirstName = FirstName;
                _basicDetailsUpdateRequestData.LastName = LastName;
                _basicDetailsUpdateRequestData.MobileNumber = MobileNo;
                _basicDetailsUpdateRequestData.EmailAddress = EmailID;
                //AppPreferences.FirstName = FirstName;
                //AppPreferences.LastName = LastName;
                //AppPreferences.userName = FirstName.ToUpper() + " " + LastName.ToUpper();
                //AppPreferences.MobileNumber = MobileNo;
                //AppPreferences.EmailAddress = EmailID;
            }
            return isvalid;
        }
        #endregion

        #region ChangeProfilePicture
        private void ChangeProfilePicture(ChangeProfilePictrurePageViewModel sender, string path)
        {
            profilepic = path ?? (string)Application.Current.Resources["IconUser"];

        }

        #endregion

        #region IsEmailIdValidData
        private bool IsEmailIdValidData()
        {
            ErrorMessage = string.Empty;
            bool isvalid = false;
            var tokenValue = AppSessionData.ActiveToken.Token;
            var userHireMeeID = AppSessionData.ActiveToken.HireMeID;
            var userNewEmail = EmailAddress;
            if (string.IsNullOrEmpty(tokenValue.ToString()) && string.IsNullOrEmpty(userHireMeeID.ToString()) && string.IsNullOrEmpty(userNewEmail.ToString()))
            {
                ErrorMessage = MessageStringConstants.TokenMissing;
                return isvalid;
            }
            else
            {
                isvalid = true;
            }
            return isvalid;
        }
        #endregion

        #region MobileNoValidData
        private bool MobileNoValidData()
        {
            ErrorMessage = string.Empty;
            bool isvalid = false;



            var tokenValue = AppSessionData.ActiveToken.Token;
            var userHireMeeID = AppSessionData.ActiveToken.HireMeID;
            var usermobilno = MobileNo;


            if (string.IsNullOrEmpty(tokenValue.ToString()) && string.IsNullOrEmpty(userHireMeeID.ToString()) && string.IsNullOrEmpty(usermobilno.ToString()))
            {
                ErrorMessage = MessageStringConstants.TokenMissing;
                return isvalid;
            }
            else
            {
                isvalid = true;
            }

            return isvalid;
        }
        #endregion

        #region Sign text

        private string _EmailVerificationStatus;

        public string EmailVerificationStatus

        {
            get { return _EmailVerificationStatus; }
            set { _EmailVerificationStatus = value; OnPropertyChanged(); }
        }



        private bool _ISCheckMobileNumber;
        public bool ISCheckMobileNumber
        {
            get { return _ISCheckMobileNumber; }
            set { _ISCheckMobileNumber = value; OnPropertyChanged(); }
        }
        private string _MobileVerifiedOrNot;
        public string MobileVerifiedOrNot
        {
            get { return _MobileVerifiedOrNot; }
            set { _MobileVerifiedOrNot = value; OnPropertyChanged(); }
        }



        private string _rightsign;
        public string RightSign
        {
            get { return _rightsign; }
            set { _rightsign = value; OnPropertyChanged(); }
        }
        private string _mobilenumber;
        public string MobileNumber
        {
            get { return _mobilenumber; }
            set { _mobilenumber = value; OnPropertyChanged(); }
        }
        private string _emailaddress;
        public string EmailAddress
        {
            get { return _emailaddress; }
            set { _emailaddress = value; OnPropertyChanged(); }
        }
        private string _lastnamerightsign;
        public string LastnameRightSign
        {
            get { return _lastnamerightsign; }
            set { _lastnamerightsign = value; OnPropertyChanged(); }
        }
        #endregion

        #region Signtext Color properites

        private Color _mobilenumtextcolor;
        public Color MobileTextcolor
        {
            get { return _mobilenumtextcolor; }
            set { _mobilenumtextcolor = value; OnPropertyChanged(); }
        }
        private Color _firstnametextcolor;
        public Color FirstNameTextcolor
        {
            get { return _firstnametextcolor; }
            set { _firstnametextcolor = value; OnPropertyChanged(); }
        }
        private Color _lastnametextcolor;
        public Color LastNameTextcolor
        {
            get { return _lastnametextcolor; }
            set { _lastnametextcolor = value; OnPropertyChanged(); }
        }
        private Color _emailtextcolor;
        public Color EmailTextcolor
        {
            get { return _emailtextcolor; }
            set { _emailtextcolor = value; OnPropertyChanged(); }
        }

        private Color _emailVerificationtextcolor;
        public Color EmailVerificationTextcolor
        {
            get { return _emailVerificationtextcolor; }
            set { _emailVerificationtextcolor = value; OnPropertyChanged(); }
        }
        private Color _MobileNumberVerifyOrNotTextColor;

        public Color MobileNumberVerifyOrNotTextColor
        {
            get { return _MobileNumberVerifyOrNotTextColor; }
            set { _MobileNumberVerifyOrNotTextColor = value; OnPropertyChanged(); }
        }


        #endregion

        #region Signtext Visibility
        private bool _isfirstnamevisible;
        public bool IsFirstNamevisible
        {
            get { return _isfirstnamevisible; }
            set { _isfirstnamevisible = value; OnPropertyChanged(); }
        }
        private bool _islastnamevisible;
        public bool IsLastNamevisible
        {
            get { return _islastnamevisible; }
            set { _islastnamevisible = value; OnPropertyChanged(); }
        }
        private bool _ismobilevisible;
        public bool IsMobilevisible
        {
            get { return _ismobilevisible; }
            set { _ismobilevisible = value; OnPropertyChanged(); }
        }
        private bool _ismobilvisible;
        public bool IsEmailvisible
        {
            get { return _ismobilvisible; }
            set { _ismobilvisible = value; OnPropertyChanged(); }
        }
        #endregion

        #region Properties

        private bool _ischeckmailstatus;
        public bool ISCheckMailStatus
        {
            get { return _ischeckmailstatus; }
            set { _ischeckmailstatus = value; OnPropertyChanged(); }
        }
        private string _FirstName;
        public string FirstName
        {
            get { return _FirstName; }
            set
            {
                _FirstName = value;
                OnPropertyChanged();
            }
        }

        private string _LastName;
        public string LastName
        {
            get { return _LastName; }
            set
            {
                _LastName = value;
                OnPropertyChanged();
            }
        }
        private string _EmailID;
        public string EmailID
        {
            get { return _EmailID; }
            set
            {
                _EmailID = value;
                OnPropertyChanged();
            }
        }
        private string _MobileNo;
        public string MobileNo
        {
            get { return _MobileNo; }
            set
            {
                _MobileNo = value;
                OnPropertyChanged();
            }
        }
        private string _HiremeeID;
        public string HiremeeID
        {
            get { return _HiremeeID; }
            set
            {
                _HiremeeID = value;
                OnPropertyChanged();
            }
        }
        private string _profilepic = (string)Application.Current.Resources["IconUser"];
        public string profilepic
        {
            get { return _profilepic; }
            set { _profilepic = value; OnPropertyChanged(); }
        }
        #endregion

    }
}
