﻿using GalaSoft.MvvmLight.Command;
using HireMe.Models.Recruiter;
using MvvmHelpers;
using System;
using System.Threading.Tasks;
using Acr.UserDialogs;
using System.Windows.Input;
using Xamarin.Forms;
using Plugin.Connectivity;
using System.Collections.Generic;
using HireMe.Models.JobSeeker;
using System.Collections.ObjectModel;
using HireMe.Helpers;

namespace HireMe.ViewModels.JobSeeker
{

    public class CollegeEducationDetailsViewModel : BaseViewModel, IValueGetter
    {
        #region Initialization
        INavigation Navigation;
        Educational_Details objBindEducationalDetailBO;
        public bool isClicked = true;
        bool isEditMode = false;
        public ICommand OnCommand { get; set; }
        SchoolEducationRequest objSchoolEducationRequest;
        CollegeEducationDetailsRequest objCollegeEducationDetailsRequest;
        ObservableCollection<Educational_Details> CollegeListitemsource;
        private HttpCommonService _commonservice { get; set; }
        #endregion

        #region Constructor from Item Tapped to Edit Screen
        public CollegeEducationDetailsViewModel(INavigation nav, ObservableCollection<Educational_Details> itemsource, Educational_Details EducationalDetailBO)
        {
            MessageStringConstants.IsSchoolOrCollegeDetailsUpdated = false;
            Navigation = nav;
            objBindEducationalDetailBO = EducationalDetailBO;
            _educationdetails = new Educational_Details();
            //CourseType = "Select Course";
            IsEducationGrid = true;
            //IsSchoolEducationGrid = false;
            objSchoolEducationRequest = new SchoolEducationRequest();
            objCollegeEducationDetailsRequest = new CollegeEducationDetailsRequest();
            _commonservice = new HttpCommonService();
            OnCommand = new RelayCommand<string>(DoOpration);

            CourseType = objBindEducationalDetailBO.course_type_name;
            CourseTypeID = objBindEducationalDetailBO.coursetype_id;
            BindEducationalDetailsToView();
            MessagingCenter.Subscribe<DynamicListPageViewModel, CommonListItemSource>(this, "SeekerPersonalandEducational", (sender, arg) =>
            {
                SetFieldValue(arg.fieldType, arg);
            });

            MessagingCenter.Subscribe<MultipleLanguageSelectionPageViewModel, List<Languageknown>>(this, "Language", (sender, arg) =>
            {
                SetFieldValue(Constants.FieldType.Languages, arg);
            });


            if (itemsource == null)
            {
                isEditMode = false;
                CollegeListitemsource = new ObservableCollection<Educational_Details>();
            }
            else
            {
                isEditMode = true;
                CollegeListitemsource = itemsource;
            }

            if (CourseTypeID == "3")
            {
                NotMandatoryRegNo = true;
            }
            else
            {
                MandatoryRegNo = true;
            }

        }
        #endregion

        #region Constructor from Add New Education Details
        public CollegeEducationDetailsViewModel(INavigation nav, ObservableCollection<Educational_Details> itemsource, string courseid)
        {
            MessageStringConstants.IsSchoolOrCollegeDetailsUpdated = false;
            Navigation = nav;
            _educationdetails = new Educational_Details();
            //CourseType = "Select Course";
            IsEducationGrid = true;
            //IsSchoolEducationGrid = false;
            objSchoolEducationRequest = new SchoolEducationRequest();
            objCollegeEducationDetailsRequest = new CollegeEducationDetailsRequest();
            _commonservice = new HttpCommonService();
            OnCommand = new RelayCommand<string>(DoOpration);
            CourseTypeID = courseid;
            BindEducationalDetailsToView();
            MessagingCenter.Subscribe<DynamicListPageViewModel, CommonListItemSource>(this, "SeekerPersonalandEducational", (sender, arg) =>
            {
                SetFieldValue(arg.fieldType, arg);
            });

            MessagingCenter.Subscribe<MultipleLanguageSelectionPageViewModel, List<Languageknown>>(this, "Language", (sender, arg) =>
            {
                SetFieldValue(Constants.FieldType.Languages, arg);
            });


            if (itemsource == null)
            {
                CollegeListitemsource = new ObservableCollection<Educational_Details>();
            }
            else
            {
                CollegeListitemsource = itemsource;
            }

            if (CourseTypeID == "3")
            {
                NotMandatoryRegNo = true;
            }
            else
            {
                MandatoryRegNo = true;
            }

        }
        #endregion

        #region  Command operations
        private async void DoOpration(string obj)
        {
            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
            switch (obj)
            {
                case "tpgSelectCourse":
                    //  var page = new AddEducationPopupPage();
                    //  await PopupNavigation.PushAsync(page);
                    break;

                #region Education Details

                case "OnUniversityItemTapped":
                    if (isClicked)
                    {
                        isClicked = false;

                        if (isNetworkAvailable)
                        {
                            NavigateToDynamicListPage(Constants.FieldType.University, "");
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }

                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                case "OnCollegeItemTapped":
                    if (isClicked)
                    {
                        isClicked = false;

                        if (isNetworkAvailable)
                        {
                            if (!string.IsNullOrEmpty(University))
                            {
                                if (_educationdetails != null && _educationdetails.university_id != null)
                                {
                                    NavigateToDynamicListPage(Constants.FieldType.College, _educationdetails.university_id);
                                }
                                else
                                {
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectUniversity);

                                }
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                case "OnCourseTypeItemTapped":
                    if (isClicked)
                    {
                        isClicked = false;

                        if (isNetworkAvailable)
                        {
                            if (!string.IsNullOrEmpty(CollegeName))
                            {

                                if (_educationdetails != null && _educationdetails.college_id != null)
                                {
                                    NavigateToDynamicListPage(Constants.FieldType.CourseType, _educationdetails.college_id);
                                    //this.Navigation.PushAsync(new DynamicListPage(Constants.FieldType.CourseType, _modifiededucationalDetails.College.ID, this));
                                }
                                else
                                {
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectCollege);
                                }
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                case "OnCourseItemTapped":
                    if (isClicked)
                    {
                        isClicked = false;
                        if (isNetworkAvailable)
                        {
                            if (!string.IsNullOrEmpty(CourseType))
                            {
                                if (CourseTypeID != null && CourseType != null)
                                {
                                    NavigateToDynamicListPage(Constants.FieldType.Course, CourseTypeID);
                                    //this.Navigation.PushAsync(new DynamicListPage(Constants.FieldType.Course, _modifiededucationalDetails.CourseType.ID, this));
                                }
                                else
                                {
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectCourseType);

                                }
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                case "OnSpecializationItemTapped":
                    if (isClicked)
                    {
                        isClicked = false;
                        if (CourseName == "Select Course")
                        {
                            await UserDialogs.Instance.AlertAsync("Select Course");
                        }
                        else
                        {
                            if (isNetworkAvailable)
                            {
                                if (!string.IsNullOrEmpty(Specialization))
                                {
                                    if (_educationdetails != null && _educationdetails.course_id != null)
                                    {
                                        NavigateToDynamicListPage(Constants.FieldType.Specialization, _educationdetails.course_id);
                                        //this.Navigation.PushAsync(new DynamicListPage(Constants.FieldType.Specialization, _modifiededucationalDetails.Course.ID, this));
                                    }
                                    else
                                    {
                                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectCourse);
                                    }
                                }
                            }
                            else
                            {
                                UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                            }
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                case "OnSkillItemTapped":
                    if (isClicked)
                    {
                        isClicked = false;
                        if (Specialization == "Select Specialization")
                        {
                            await UserDialogs.Instance.AlertAsync("Select Specialization");
                        }
                        else
                        {
                            if (isNetworkAvailable)
                            {
                                if (!string.IsNullOrEmpty(Skill))
                                {
                                    if (_educationdetails != null && _educationdetails.specialization_id != null)
                                    {
                                        // await Navigation.PushAsync(new MultipleSkillSelection(_selectionSkills, _educationdetails.specialization_id, "SeekerPersonalandEducational"));
                                    }
                                    else
                                    {
                                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectSpecialization);
                                    }

                                }
                            }
                            else
                            {
                                UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                            }

                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                case "OnYearOfCompletionItemTapped":
                    if (isClicked)
                    {
                        isClicked = false;
                        if (isNetworkAvailable)
                        {
                            if (!string.IsNullOrEmpty(YearOfCompletion))
                            {
                                await Navigation.PushAsync(new DynamicListPage("SeekerPersonalandEducational", Constants.FieldType.YearOfCompletion, ""));
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }


                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                case "OnPermanentStateItemTapped":
                    if (isClicked)
                    {
                        isClicked = false;

                        if (isNetworkAvailable)
                        {
                            NavigateToDynamicListPage(Constants.FieldType.State, "");
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                case "OnPermanentCityItemTapped":
                    if (isClicked)
                    {
                        isClicked = false;
                        if (isNetworkAvailable)
                        {
                            if (string.IsNullOrEmpty(_educationdetails.stateid))
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectState);
                            }

                            else
                            {
                                NavigateToDynamicListPage(Constants.FieldType.City, StateID);
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                #endregion

                #region SaveCollegeEducationalDetails API Call
                case "SaveCollegeEducationalDetails":
                    if (isClicked)
                    {
                        isClicked = false;
                        if (isNetworkAvailable)
                        {
                            if (!ValidateCollegeEducationalDetails())
                            {
                                return;
                            }
                            else
                            {
                                try
                                {
                                    UserDialogs.Instance.ShowLoading();
                                    var response = await _commonservice.PostAsync<EducaionalDetailsResponseData, CollegeEducationDetailsRequest>(APIData.API_BASE_URL + APIMethods.AddCollegeEducationDetails, objCollegeEducationDetailsRequest);
                                    if (response != null)
                                    {
                                        if (response.code == "200")
                                        {
                                            UserDialogs.Instance.HideLoading();
                                            MessageStringConstants.IsSchoolOrCollegeDetailsUpdated = true;
                                            await UserDialogs.Instance.AlertAsync(response.message);
                                            int stacklength = Navigation.NavigationStack.Count;
                                            if (!isEditMode)
                                                Navigation.RemovePage(Navigation.NavigationStack[stacklength - 1]);
                                            await Navigation.PopAsync();
                                        }
                                        else if (response.code == "199")
                                        {
                                            UserDialogs.Instance.HideLoading();
                                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.SessionExpiered);
                                            Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                                            return;
                                        }
                                        else
                                        {
                                            UserDialogs.Instance.HideLoading();
                                            await UserDialogs.Instance.AlertAsync(response.message);
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    System.Diagnostics.Debug.WriteLine(ex.Message);
                                    SendErrorMessageToServer(ex, "CollegeEducationDetailsViewModel.DoOpration.SaveCollegeEducationalDetails");
                                }
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                    #endregion
            }
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        #region BindEducationalDetailsToView
        public void BindEducationalDetailsToView()
        {
            #region BindEducation Details
            if (objBindEducationalDetailBO != null)
            {
                IsEducationGrid = true;
                if (CourseTypeID == "3")
                {
                    NotMandatoryRegNo = true;
                }
                else
                {
                    MandatoryRegNo = true;
                }
                CourseType = objBindEducationalDetailBO.course_type_name;
                CourseTypeID = objBindEducationalDetailBO.coursetype_id;
                University = objBindEducationalDetailBO.university_name;
                _educationdetails.university_id = objBindEducationalDetailBO.university_id;
                CollegeName = objBindEducationalDetailBO.college_name;
                _educationdetails.college_id = objBindEducationalDetailBO.college_id;
                if (!string.IsNullOrEmpty(objBindEducationalDetailBO.zip_code))
                    Zipcode = objBindEducationalDetailBO.zip_code.Trim();
                if (!string.IsNullOrEmpty(objBindEducationalDetailBO.registerNo))
                    RegisterNumber = objBindEducationalDetailBO.registerNo.Trim();
                CourseName = objBindEducationalDetailBO.course_name;
                _educationdetails.course_id = objBindEducationalDetailBO.course_id;
                Specialization = objBindEducationalDetailBO.specialization_name;
                _educationdetails.specialization_id = objBindEducationalDetailBO.specialization_id;
                EntryCGPA = objBindEducationalDetailBO.cgpa;
                EntryPercentage = objBindEducationalDetailBO.percentage;
                YearOfCompletion = objBindEducationalDetailBO.year_of_completion;
                if (EntryCGPA == "0.00" && EntryPercentage == "00.0" || EntryCGPA == "0.00" && EntryPercentage == "0.00")
                {
                    IsEntryCGPA = true;
                    IsEntryPercentage = true;
                    EntryCGPA = string.Empty;
                    EntryPercentage = string.Empty;
                }
                else if (EntryCGPA != "0.00" && !string.IsNullOrEmpty(EntryPercentage))
                {
                    IsEntryCGPA = true;
                    IsEntryPercentage = false;
                    EntryPercentage = string.Empty;
                }
                else if (!string.IsNullOrEmpty(EntryCGPA) && EntryPercentage == "00.00" || EntryPercentage != "0.00")
                {
                    IsEntryCGPA = false;
                    EntryCGPA = string.Empty;
                    IsEntryPercentage = true;
                }
                if (Convert.ToInt32((objBindEducationalDetailBO.backlog == "" ? "0" : objBindEducationalDetailBO.backlog)) == 0)
                {
                    IsBackLogToggled = false;
                }
                else
                {
                    IsBackLogToggled = true;
                }
            }
            else
            {
                if (CourseTypeID == "3")
                {
                    NotMandatoryRegNo = true;
                }
                else
                {
                    MandatoryRegNo = true;
                }
                Zipcode = string.Empty;
                RegisterNumber = string.Empty;
                EntryCGPA = string.Empty;
                EntryPercentage = string.Empty;
                University = "Select University";
                CollegeName = "Select College";
                CourseType = "Select Course Type";
                CourseName = "Select Course";
                Specialization = "Select Specialization";
                State = MessageStringConstants.SelectState;
                City = MessageStringConstants.SelectCity;
                YearOfCompletion = MessageStringConstants.SelectYearOfCompletion;
                IsEntryPercentage = true;
                IsEntryCGPA = true;
            }
            #endregion
        }

        #endregion

        #region TextChanged Event
        private Command<string> textchagedcommand;
        public Command<string> TextChangedCommand
        {
            get { return textchagedcommand ?? (textchagedcommand = new Command<string>(async arg => await OnTextChangedCommand(arg))); }
        }
        private async Task OnTextChangedCommand(string sender)
        {
            switch (sender)
            {
                case "CGPA":
                    if (EntryCGPA != "" && EntryCGPA != "0.00")
                    {
                        IsEntryPercentage = false;
                        IsEntryCGPA = true;
                    }

                    else
                    {
                        IsEntryPercentage = true;
                        EntryCGPA = string.Empty;
                    }
                    break;
                case "Percentage":
                    if (EntryPercentage != "0.00" && EntryPercentage != "")
                    {
                        IsEntryCGPA = false;
                        IsEntryPercentage = true;
                    }

                    else if (EntryCGPA == "0.00" && EntryPercentage == "00.0" || EntryCGPA == "0.00" && EntryPercentage == "0.00")
                    {
                        IsEntryCGPA = true;
                        IsEntryPercentage = true;
                    }
                    else
                    {
                        IsEntryCGPA = true;
                        EntryPercentage = string.Empty;
                    }
                    break;
            }
        }
        #endregion

        #region Private Properties

        private bool _IsEducationGrid;
        public bool IsEducationGrid
        {
            get { return _IsEducationGrid; }
            set { _IsEducationGrid = value; OnPropertyChanged(); }
        }

        private Educational_Details educationdetails;
        public Educational_Details _educationdetails
        {
            get { return educationdetails; }
            set { educationdetails = value; OnPropertyChanged(); }
        }
        private bool _isentryPercentage;

        public bool IsEntryPercentage
        {
            get { return _isentryPercentage; }
            set { _isentryPercentage = value; OnPropertyChanged(); }
        }

        private bool _isentryCGPA;

        public bool IsEntryCGPA
        {
            get { return _isentryCGPA; }
            set { _isentryCGPA = value; OnPropertyChanged(); }
        }
        private string _university;
        public string University
        {
            get { return _university; }
            set
            {
                _university = value;
                OnPropertyChanged();
            }
        }
        private bool _isbacklogtoggled;
        public bool IsBackLogToggled
        {
            get { return _isbacklogtoggled; }
            set { _isbacklogtoggled = value; OnPropertyChanged(); }
        }
        private string _entrycgpa = "0.00";
        public string EntryCGPA
        {
            get { return _entrycgpa; }
            set { _entrycgpa = value; OnPropertyChanged(); }
        }
        private string _entrypercentage = "0.00";

        public string EntryPercentage
        {
            get { return _entrypercentage; }
            set { _entrypercentage = value; OnPropertyChanged(); }
        }
        private string _collegeName;
        public string CollegeName
        {
            get { return _collegeName; }
            set
            {
                _collegeName = value;
                OnPropertyChanged();
            }
        }
        private string _zipcode;
        public string Zipcode
        {
            get { return _zipcode; }
            set
            {
                _zipcode = value;
                OnPropertyChanged();
            }
        }



        private string _RegisterNumber;
        public string RegisterNumber
        {
            get { return _RegisterNumber; }
            set
            {
                _RegisterNumber = value;
                OnPropertyChanged();
            }
        }
        private string _courseType;
        public string CourseType
        {
            get { return _courseType; }
            set
            {
                _courseType = value;
                OnPropertyChanged();
            }
        }
        private string _courseTypeid;
        public string CourseTypeID
        {
            get { return _courseTypeid; }
            set
            {
                _courseTypeid = value;
                OnPropertyChanged();
            }
        }
        private string _courseName;
        public string CourseName
        {
            get { return _courseName; }
            set
            {
                _courseName = value;
                OnPropertyChanged();
            }
        }
        private string _specialization;
        public string Specialization
        {
            get { return _specialization; }
            set
            {
                _specialization = value;
                OnPropertyChanged();
            }
        }
        private string _skill;
        public string Skill
        {
            get { return _skill; }
            set
            {
                _skill = value;
                OnPropertyChanged();
            }
        }
        private string _yearOfCompletion;
        public string YearOfCompletion
        {
            get { return _yearOfCompletion; }
            set
            {
                _yearOfCompletion = value;
                OnPropertyChanged();
            }
        }
        private string _state;
        public string State
        {
            get { return _state; }
            set
            {
                _state = value;
                OnPropertyChanged();
            }
        }
        private string _stateID;
        public string StateID
        {
            get { return _stateID; }
            set
            {
                _stateID = value;
                OnPropertyChanged();
            }
        }
        private string _city;
        public string City
        {
            get { return _city; }
            set
            {
                _city = value;
                OnPropertyChanged();
            }
        }
        //private string _pincode;
        //public string PinCode
        //{
        //    get { return _pincode; }
        //    set
        //    {
        //        _pincode = value;
        //        OnPropertyChanged();
        //    }
        //}

        //private string _boardType;
        //public string BoardType
        //{
        //    get { return _boardType; }
        //    set { _boardType = value; OnPropertyChanged(); }
        //}
        //private string _schoolName;
        //public string SchoolName
        //{
        //    get { return _schoolName; }
        //    set { _schoolName = value; OnPropertyChanged(); }
        //}

        //private string _schoolZipcode;
        //public string SchoolZipcode
        //{
        //    get { return _schoolZipcode; }
        //    set { _schoolZipcode = value; OnPropertyChanged(); }
        //}
        //private string _schoolEntryCGPA;
        //public string SchoolEntryCGPA
        //{
        //    get { return _schoolEntryCGPA; }
        //    set { _schoolEntryCGPA = value; OnPropertyChanged(); }
        //}
        //private string _schoolEntryPercentage;
        //public string SchoolEntryPercentage
        //{
        //    get { return _schoolEntryPercentage; }
        //    set { _schoolEntryPercentage = value; OnPropertyChanged(); }
        //}
        //private string _SchoolYearOfPassing;
        //public string SchoolYearOfPassing
        //{
        //    get { return _SchoolYearOfPassing; }
        //    set { _SchoolYearOfPassing = value; OnPropertyChanged(); }
        //}

        //private void CourseTypeValue(AddEducationPopupViewModel arg1, string[] arg2)
        //{
        //    CourseType = arg2[0];
        //    CourseTypeID = arg2[1];
        //}

        private bool _MandatoryRegNo;
        public bool MandatoryRegNo
        {
            get { return _MandatoryRegNo; }
            set { _MandatoryRegNo = value; OnPropertyChanged(); }
        }

        private bool _NotMandatoryRegNo;
        public bool NotMandatoryRegNo
        {
            get { return _NotMandatoryRegNo; }
            set { _NotMandatoryRegNo = value; OnPropertyChanged(); }
        }
        #endregion

        #region Set Field Value
        public void SetFieldValue(string fieldtype, object fieldvalue)
        {

            if (fieldtype == Constants.FieldType.University)
            {
                if (University != ((CommonListItemSource)fieldvalue).Title.ToString())
                {
                    CollegeName = "Select College";
                    //_educationdetails.College = null;
                }
                University = ((CommonListItemSource)fieldvalue).Title;
                _educationdetails.university_id = ((CommonListItemSource)fieldvalue).ID;
                //_educationdetails.University = new University { ID = ((CommonListItemSource)fieldvalue).ID, UniversityName = ((CommonListItemSource)fieldvalue).Title };
            }
            else if (fieldtype == Constants.FieldType.College)
            {
                CollegeName = ((CommonListItemSource)fieldvalue).Title;
                _educationdetails.college_id = ((CommonListItemSource)fieldvalue).ID;
                //_educationdetails.College = new College { ID = ((CommonListItemSource)fieldvalue).ID, Title = ((CommonListItemSource)fieldvalue).Title };
            }
            else if (fieldtype == Constants.FieldType.Course)
            {
                if (CourseName != ((CommonListItemSource)fieldvalue).Title)
                {
                    Specialization = "Select Specialization";
                }
                CourseName = ((CommonListItemSource)fieldvalue).Title;
                _educationdetails.course_id = ((CommonListItemSource)fieldvalue).ID;
                //_educationdetails.Course = new Course { ID = ((CommonListItemSource)fieldvalue).ID, CourseTitle = ((CommonListItemSource)fieldvalue).Title };
            }
            else if (fieldtype == Constants.FieldType.Specialization)
            {
                if (Specialization != ((CommonListItemSource)fieldvalue).Title)
                {
                    Skill = "Select Skill";
                }
                Specialization = ((CommonListItemSource)fieldvalue).Title;
                _educationdetails.specialization_id = ((CommonListItemSource)fieldvalue).ID;
                //_educationdetails.Specialization = new Specialization { ID = ((CommonListItemSource)fieldvalue).ID, Title = ((CommonListItemSource)fieldvalue).Title };
                //_selectionSkills = new List<Skill>();
            }
            else if (fieldtype == Constants.FieldType.YearOfCompletion)
            {
                YearOfCompletion = ((CommonListItemSource)fieldvalue).Title;
                _educationdetails.year_of_completion = ((CommonListItemSource)fieldvalue).Title;
            }
            else if (fieldtype == Constants.FieldType.State)
            {
                if (State != ((CommonListItemSource)fieldvalue).Title)
                {
                    City = "Select City";
                }
                State = ((CommonListItemSource)fieldvalue).Title;
                _educationdetails.stateid = ((CommonListItemSource)fieldvalue).ID;
                _educationdetails.statename = ((CommonListItemSource)fieldvalue).Title;
            }
            else if (fieldtype == Constants.FieldType.City)
            {
                City = ((CommonListItemSource)fieldvalue).Title;
                _educationdetails.city_id = ((CommonListItemSource)fieldvalue).ID;
                _educationdetails.cityname = ((CommonListItemSource)fieldvalue).Title;
            }
        }
        #endregion

        #region NavigateToDynamicListPage
        public async void NavigateToDynamicListPage(string _fieldType, string _fieldValue)
        {
            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
            if (isNetworkAvailable)
            {
                //_SeekerPersonalPage = new SeekerPersonalAndEducationPage();

                await Navigation.PushAsync(new DynamicListPage("SeekerPersonalandEducational", _fieldType, _fieldValue));
            }
            else
            {
                UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
            }
        }
        #endregion

        #region ValidateCollegeEducationalDetails
        bool ValidateCollegeEducationalDetails()
        {
            bool isvalid = false;
            try
            {
                if (University == "Select University" || string.IsNullOrEmpty(University))
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync("Select University");
                    }); return isvalid;
                }
                if (CollegeName == "Select College")
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync("Select College");
                    }); return isvalid;
                }

                if (CourseName == "Select Course")
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync("Select Course");
                    }); return isvalid;
                }
                if (Specialization == "Select Specialization")
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync("Select Specialization");
                    }); return isvalid;
                }
                if (string.IsNullOrEmpty(YearOfCompletion) || YearOfCompletion == "Select Year Of Completion" || YearOfCompletion == "0000")
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync("Select Year of Completion");
                    }); return isvalid;
                }

                if (CourseTypeID != "3" && string.IsNullOrEmpty(RegisterNumber) )
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidRegisterNumber);
                    });
                    return isvalid;
                }

                if (CourseTypeID != "3" && !string.IsNullOrEmpty(RegisterNumber))
                {
                    int nameLength = RegisterNumber.Trim().Length;
                    if (nameLength < 6 || !Utilities.ValidateRegisterNumber(RegisterNumber))
                    {
                        UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidRegisterNumber);
                        return isvalid;
                    }
                }


                if ((string.IsNullOrEmpty(EntryCGPA) || EntryCGPA == "0.00") && (string.IsNullOrEmpty(EntryPercentage) || EntryPercentage == "0.00") || (EntryCGPA == "0" || EntryCGPA == "00.00" || EntryCGPA == "0.0" || EntryCGPA == "00.0" || EntryCGPA == "00" || EntryPercentage == "0" || EntryPercentage == "00" || EntryPercentage == "00.0" || EntryPercentage == "0.0" || EntryPercentage == "00.00"))
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterCGPAORPercentage);
                    });
                    return isvalid;
                }
                if (string.IsNullOrEmpty(Zipcode) || !Utilities.ValidatePincode(Zipcode))
                {
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterValidPincode);
                    }); Zipcode = string.Empty;
                    return isvalid;
                }


                isvalid = true;
                {
                    objCollegeEducationDetailsRequest.CourseTypeID = CourseTypeID;
                    objCollegeEducationDetailsRequest.CGPA = EntryCGPA;
                    objCollegeEducationDetailsRequest.YearOfCompletion = YearOfCompletion;
                    objCollegeEducationDetailsRequest.Percentage = EntryPercentage;
                    objCollegeEducationDetailsRequest.CourseID = _educationdetails.course_id;
                    objCollegeEducationDetailsRequest.SpecializationID = _educationdetails.specialization_id;
                    objCollegeEducationDetailsRequest.CollegeID = _educationdetails.college_id;
                    objCollegeEducationDetailsRequest.UniversityID = _educationdetails.university_id;
                    objCollegeEducationDetailsRequest.Zipcode = Zipcode;
                    objCollegeEducationDetailsRequest.registerNo = RegisterNumber;
                    if (IsBackLogToggled == true)
                    {
                        objCollegeEducationDetailsRequest.BackLog = "1";
                    }
                    else
                    {
                        objCollegeEducationDetailsRequest.BackLog = "0";
                    }
                }
            }
            catch (Exception)
            {
                return isvalid;
            }
            return isvalid;
        }
        #endregion
    }
}
