﻿using MvvmHelpers;
using Xamarin.Forms;

namespace HireMe
{
    public class CompanyWebSideViewModel : BaseViewModel
	{
        
        public CompanyWebSideViewModel(string url)
        {

            if (url.Contains("http"))
            {
                CompanyUrl = url;
            }
            else
            {
                CompanyUrl = "http://" + url;
            }
        }

		public string companyurl;
		public string CompanyUrl
		{
			get { return companyurl;}
			set { companyurl = value; OnPropertyChanged();}
		}


	}
}
