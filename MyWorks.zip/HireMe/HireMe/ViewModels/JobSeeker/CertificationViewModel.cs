﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using HireMe.Helpers;
using HireMe.Models.JobSeeker;
using HireMe.Models.Recruiter;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;


namespace HireMe.ViewModels.JobSeeker
{
    public class CertificationViewModel : BaseViewModel
    {
        #region variable declreation
        public Command CommonCommand { get; set; }

        public Command SelectedYearChanged { get; set; }
        private HttpCommonService _commonservice { get; set; }
        public YearData item;
        private int certificationCount;
        public bool isClicked = true;
     

        public MasterTableRequestData _yearlistRequestdata;
      //  ObservableCollection<CertificationDetails> _CertificationDetailsList;
        INavigation _navigationservice;
        #endregion

        #region Constroctor
        public CertificationViewModel(INavigation nav, ObservableCollection<CertificationDetails> certifications)
        {
            _navigationservice = nav;
            ClearAll();
            SelectedYearChanged = new Command(SelectYear);
            CommonCommand = new Command(DoCommand);
            certificationCount = 0;
            LoadYearList();
            CertificationItemSource = certifications;

        }
        #endregion

        #region LoadYearList
        async void LoadYearList()
        {
            Debug.WriteLine("@ CertificationViewModel.LoadYearList");
            _commonservice = new HttpCommonService();
            _yearlistRequestdata = new MasterTableRequestData();
            YearList = new ObservableCollection<YearData>();
            try
            {
                UserDialogs.Instance.ShowLoading();
                _yearlistRequestdata.HiremeeID = AppSessionData.ActiveToken.HireMeID;
                _yearlistRequestdata.Token = AppSessionData.ActiveToken.Token;
                _yearlistRequestdata.TableName = "yearofcompletion";
                var responseobj = await _commonservice.PostAsync<YearOfCompletionResponse, MasterTableRequestData>(APIData.API_BASE_URL + APIMethods.MasterTables, _yearlistRequestdata);
                if (responseobj != null)
                {
                    UserDialogs.Instance.HideLoading();
                    if (responseobj.code == "200" && responseobj.responseText.yearofcompletion != null)
                    {
                        foreach (var item in responseobj.responseText.yearofcompletion)
                        {
                            YearList.Add(new YearData() { CertificationYear = item.name });
                        }
                    }
                    else if (responseobj.code == "199")
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.SessionExpiered);
                        Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                        return;
                    }
                    else
                    {
                        await UserDialogs.Instance.AlertAsync(responseobj.message);
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "CertificationViewModel.LoadYearList");
            }
           // BindCertificationToView();
        }
        #endregion

        #region ClearAll
        private void ClearAll()
        {
            PageName = "Add Certification";
            ButtonText = "Add";
            SelectedYear = "Year";
            picker.SelectedIndex = -1;
            CertificateID = string.Empty;
            CertificateName = string.Empty;
            SelectedYearColor = Color.Gray;
        }
        #endregion

        #region DoCommand
        private async void DoCommand(object sender)
        {
            try
            {
                if (sender.ToString() == "DoClear")
                {
                    if (isClicked)
                    {
                        isClicked = false;
                        //BindCertificationToView();
                        ClearAll();

                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                }
                else if (sender.ToString() == "AddCertificate")
                {
                    if (isClicked)
                    {
                        isClicked = false;
                        if (string.IsNullOrWhiteSpace(CertificateName))
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.CertificationNameEmptyMessage);
                        }
                        else if (SelectedYear == "Year")
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.CertificationYearEmptyMessage);
                        }
                        else if (ButtonText == "Add")
                        {
                            if (CertificationItemSource == null)
                            {
                                AddandUpdateCertificateAPI("Add");
                            }
                            else if (CertificationItemSource.Any(i => i.certification_name == CertificateName && i.certification_year == SelectedYear))
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.CertificationDuplicateMessage);
                            }
                            else if (certificationCount <= 4)
                            {
                                AddandUpdateCertificateAPI("Add");
                            }
                            else
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.MaximumCertifications);
                            }
                        }
                        else if (ButtonText == "Update")
                        {
                            AddandUpdateCertificateAPI("Update");
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "CertificationViewModel.DoCommand" + sender.ToString());
            }
        }

        #endregion

        #region Test
        private async void Test(object currentObject)
        {

            var data = currentObject as CertificationDetails;
            if (isClicked)
            {
                isClicked = false;

                try
                {
                    var Confirmation = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.DeleteCertificateAlert);
                    if (Confirmation == true)
                    {
                        if (data.certificate_id != null)
                        {
                            DeleteCertificateAPI(data.certificate_id);
                        }
                        else
                        {
                            UserDialogs.Instance.Alert(MessageStringConstants.ServerBusyMessage);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                    SendErrorMessageToServer(ex, "CertificationViewModel.Test");
                }
            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        #region Load Year Data
        public class YearData
        {
            public string CertificationYear { get; set; }
        }

        Picker picker = new Picker();
        private void SelectYear(object obj)
        {
            try
            {
                picker = (Picker)obj;
                item = (YearData)picker.SelectedItem;
                if (item != null)
                {
                    SelectedYear = item.CertificationYear;
                    SelectedYearColor = Color.Black;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "CertificationViewModel.SelectYear");
            }


        }



        private ObservableCollection<YearData> _identifyYearList;
        public ObservableCollection<YearData> YearList
        {
            get { return _identifyYearList; }
            set
            {
                if (_identifyYearList != value)
                {
                    _identifyYearList = value;
                    OnPropertyChanged();
                }
            }
        }

        #endregion

        #region BindCertificationToView
        public void BindCertificationToView(ObservableCollection<CertificationDetails> _certificateList)
        {
            Device.BeginInvokeOnMainThread(() =>
           {
               try
               {
                   if (_certificateList != null )
                   {
                       CertificationItemSource = _certificateList;
                   }
               }
               catch (Exception ex)
               {
                   UserDialogs.Instance.HideLoading();
                   System.Diagnostics.Debug.WriteLine(ex.Message);
                   SendErrorMessageToServer(ex, "CertificationViewModel.BindCertificationToView");
               }
               finally
               {
                   if (CertificationItemSource != null)
                   {
                       certificationCount = CertificationItemSource.Count;
                       IsLableViewVisible = false;
                       IsListViewVisible = true;
                   }
                   else
                   {
                       certificationCount = 0;
                       IsLableViewVisible = true;
                       IsListViewVisible = false;
                   }
               }
           });
        }
        #endregion

        #region AddandUpdateCertificateAPI
        private async void AddandUpdateCertificateAPI(string operationName)
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                CertificationRequestModel _certificationrequestData = new CertificationRequestModel();
                if (string.IsNullOrWhiteSpace(CertificateID))
                {
                    _certificationrequestData.certification_id = string.Empty;
                }
                else
                {
                    _certificationrequestData.certification_id = CertificateID;
                }
                _certificationrequestData.certification_name = CertificateName;
                _certificationrequestData.certification_year = SelectedYear;


                var result = await _commonservice.PostAsync<CertificationResponseModel, CertificationRequestModel>(APIData.API_BASE_URL + APIMethods.UpdateCertificationDetails, _certificationrequestData);
                if (result != null)
                {
                    if (result.code == "200")
                    {
                        if (result.certificationlist != null)
                        {
                            UserDialogs.Instance.HideLoading();

                            SeekerDashboardResponseModel = AppPreferences.LoadSeekerDashboardData;
                            SeekerDashboardResponseModel.EducationalDetailsResponseData.certifications = result.certificationlist;
                            AppPreferences.LoadSeekerDashboardData = SeekerDashboardResponseModel;

                            BindCertificationToView(result.certificationlist);
                            ClearAll();
                            await UserDialogs.Instance.AlertAsync(result.responseText);
                            MessageStringConstants.IsCertificateDetailsModified = true;
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                        }
                    }
                    else if (result.code == "199")
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.SessionExpiered);
                        Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                        return;
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(result.message);
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "CertificationViewModel.AddCertificateAPI");
            }
        }

        #endregion

        #region DeleteCertificateAPI
        private async void DeleteCertificateAPI(string CertificationID)
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                CertificateDeleteRequestModel _certificationDeleterequestData = new CertificateDeleteRequestModel();
                _certificationDeleterequestData.certification_id = CertificationID;

                var result = await _commonservice.PostAsync<CertificateDeleteResponseModel, CertificateDeleteRequestModel>(APIData.API_BASE_URL + APIMethods.DeleteCertificate, _certificationDeleterequestData);
                if (result != null)
                {
                    if (result.code == "200")
                    {
                        UserDialogs.Instance.HideLoading();

                        SeekerDashboardResponseModel = AppPreferences.LoadSeekerDashboardData;
                        SeekerDashboardResponseModel.EducationalDetailsResponseData.certifications = result.certificationlist;
                        AppPreferences.LoadSeekerDashboardData = SeekerDashboardResponseModel;

                        var itemToRemove = CertificationItemSource.SingleOrDefault(r => r.certificate_id == CertificationID);
                        if (itemToRemove != null)
                            CertificationItemSource.Remove(itemToRemove);


                        ClearAll();
                        await UserDialogs.Instance.AlertAsync(result.responseText);
                        MessageStringConstants.IsCertificateDetailsModified = true;
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(result.message);
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "CertificationViewModel.DeleteCertificateAPI");
            }
        }

        #endregion

        #region Private Properties

        private SeekerDashboardResponseModel _SeekerDashboardResponseModel;
        public SeekerDashboardResponseModel SeekerDashboardResponseModel
        {
            get { return _SeekerDashboardResponseModel; }
            set { _SeekerDashboardResponseModel = value; OnPropertyChanged(); }
        }

        private RelayCommand<object> _OnClickableLabel;
        public RelayCommand<object> OnClickableLabel
        {
            get { return _OnClickableLabel ?? (_OnClickableLabel = new RelayCommand<object>((currentObject) => Test(currentObject))); }
        }

        private bool _IsListViewVisible;
        public bool IsListViewVisible
        {
            get { return _IsListViewVisible; }
            set { _IsListViewVisible = value; OnPropertyChanged(); }
        }

        private bool _IsLableViewVisible;
        public bool IsLableViewVisible
        {
            get { return _IsLableViewVisible; }
            set { _IsLableViewVisible = value; OnPropertyChanged(); }
        }


        private ObservableCollection<CertificationDetails> _certificationItemSource;
        public ObservableCollection<CertificationDetails> CertificationItemSource
        {
            get { return _certificationItemSource; }
            set { _certificationItemSource = value; OnPropertyChanged(); }
        }


        public CertificationDetails _ListViewSelectedItem;
        public CertificationDetails ListViewSelectedItem
        {
            get { return _ListViewSelectedItem; }
            set
            {
                _ListViewSelectedItem = value;
                OnPropertyChanged();
            }
        }





        private string _certificateID;

        public string CertificateID
        {
            get { return _certificateID; }
            set { _certificateID = value; OnPropertyChanged(); }
        }


        private string _certificateName;

        public string CertificateName
        {
            get { return _certificateName; }
            set { _certificateName = value; OnPropertyChanged(); }
        }


        private Color _selectedYearColor;

        public Color SelectedYearColor
        {
            get { return _selectedYearColor; }
            set { _selectedYearColor = value; OnPropertyChanged(); }
        }

        private string _pageName;

        public string PageName
        {
            get { return _pageName; }
            set { _pageName = value; OnPropertyChanged(); }
        }
        private string _buttonText;
        public string ButtonText
        {
            get { return _buttonText; }
            set { _buttonText = value; OnPropertyChanged(); }
        }

        private bool _isVisibleDeleteButton;
        public bool IsVisibleDeleteButton
        {
            get { return _isVisibleDeleteButton; }
            set { _isVisibleDeleteButton = value; OnPropertyChanged(); }
        }

        private string _selectedYear;
        public string SelectedYear
        {
            get { return _selectedYear; }
            set { _selectedYear = value; OnPropertyChanged(); }
        }


        private bool _isvisibleEditEntry;
        public bool IsvisibleEditEntry
        {
            get { return _isvisibleEditEntry; }
            set { _isvisibleEditEntry = value; OnPropertyChanged(); }
        }

        private bool _isvisibleAddEntry;
        public bool IsvisibleAddEntry
        {
            get { return _isvisibleAddEntry; }
            set { _isvisibleAddEntry = value; OnPropertyChanged(); }
        }

        private bool _isvisblePageOptions;

        public bool IsvisblePageOptions
        {
            get { return _isvisblePageOptions; }
            set { _isvisblePageOptions = value; OnPropertyChanged(); }
        }

        #endregion

        #region SelectedCommand
        public ICommand SelectedCommand => new Command(() =>
        {

            if (isClicked)
            {
                isClicked = false;

                CertificateName = ListViewSelectedItem.certification_name;
                SelectedYear = ListViewSelectedItem.certification_year;
                CertificateID = ListViewSelectedItem.certificate_id;
                SelectedYearColor = Color.Black;
                PageName = "Edit Certification";
                ButtonText = "Update";
            }
            Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });

        });
        #endregion
    }
}
