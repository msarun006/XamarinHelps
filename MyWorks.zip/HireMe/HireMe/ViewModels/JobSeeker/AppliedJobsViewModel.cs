﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.Models.JobSeeker;
using HireMe.Views.JobSeeker;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.JobSeeker
{
    public class AppliedJobsViewModel : BaseViewModel
    {
        INavigation Navigation;
        public bool isClicked = true;
        ObservableCollection<SearchJobsResponseData> _tempAppliedJobs;
        public ICommand OnCommand { get; set; }

        private HttpCommonService _commonservice { get; set; }
        public AppliedJobsViewModel(INavigation nav)
        {
            Navigation = nav;
            OnCommand = new Command<string>(DoOperation);
            ProfilePicture = (string)Application.Current.Resources["IconUser"];
            SearchPlaceHolderText = "Search Company";
            _commonservice = new HttpCommonService();
            IsListview = true;
            AppliedJobsAPICall();
        }

        private async void DoOperation(string obj)
        {
            try
            {
                if (obj.Equals("OnStackTapp"))
                {
                    //await Navigation.PushAsync(new JobDetailsViewPage("AppliedJobs", null,null,null,null,null));
                }
            }
            catch (Exception ex)
            {

            }
        }
        #region SelectedCommand
        public ICommand SelectedCommand => new Command(async () =>
        {
            if (isClicked)
            {
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {
                    isClicked = false;
                    await Navigation.PushAsync(new JobDetailsViewPage("AppliedJobs", SelectedItem.JobPostingId,null,null,null,null));
                }
                else
                {
                    UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                }
            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });
        });
        #endregion

        #region Applied Jobs API call
        private async void AppliedJobsAPICall()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();

                ObservableCollection<SearchJobsResponseData> objCurrentOpeningsResponseData = new ObservableCollection<SearchJobsResponseData>();
                SearchJobsRequest objSearchJobsRequest = new SearchJobsRequest();
                objSearchJobsRequest.CandidateHiremeeID = AppSessionData.ActiveToken.HireMeID;
                objSearchJobsRequest.WorkType = "5";
                var statusResult = await _commonservice.PostAsync<SearchJobsResponse, SearchJobsRequest>(APIData.API_BASE_URL + APIMethods.GetAppliedJobs, objSearchJobsRequest);
                if (statusResult != null)
                {
                    UserDialogs.Instance.HideLoading();
                    if (statusResult.Code == "200")
                    {
                        if (statusResult.SearchJobs.Count > 0)
                        {

                            isEnabledSearchBar = true;
                            IsLableViewVisible = false;
                            IsListview = true;
                            _tempAppliedJobs = new ObservableCollection<SearchJobsResponseData>(statusResult.SearchJobs);
                            foreach (var item in statusResult.SearchJobs)
                            {
                                SearchJobsResponseData obj = item;
                                obj.description = Regex.Replace(Regex.Replace(item.description.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty); ;
                                if (item.AppliedStatus == "1")
                                {
                                    obj.txtJobApply = "Job applied ";
                                }
                                else
                                {
                                    obj.txtJobApply = " Apply ";
                                }
                                objCurrentOpeningsResponseData.Add(obj);
                            }
                            ItemSource = objCurrentOpeningsResponseData;
                        }
                        else
                        {
                            isEnabledSearchBar = false;
                            IsLableViewVisible = true;
                            IsListview = false;
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        IsLableViewVisible = true;
                        IsListview = false;
                        await UserDialogs.Instance.AlertAsync(statusResult.Message);
                    }
                }
                else
                {
                    isEnabledSearchBar = false;
                    IsLableViewVisible = true;
                    IsListview = false;
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "AppliedJobsViewModel.AppliedJobsAPICall");
            }
        }
        #endregion
        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, string ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        #region Private properties

        private string _ProfilePicture;

        public string ProfilePicture
        {
            get { return _ProfilePicture; }
            set { _ProfilePicture = value; OnPropertyChanged(); }
        }


        private ObservableCollection<SearchJobsResponseData> _ItemSource;
        public ObservableCollection<SearchJobsResponseData> ItemSource
        {
            get { return _ItemSource; }
            set { _ItemSource = value; OnPropertyChanged(); }
        }

        private SearchJobsResponseData _SelectedItem;
        public SearchJobsResponseData SelectedItem
        {
            get { return _SelectedItem; }
            set { _SelectedItem = value; OnPropertyChanged(); }
        }
        #region Searchbar Controls
        private bool _isVisibleSearchbarCancel;
        public bool IsVisibleSearchbarCancelButton
        {
            get { return _isVisibleSearchbarCancel; }
            set { _isVisibleSearchbarCancel = value; OnPropertyChanged(); }
        }
        public bool _isEnabledSearchBar;

        public bool isEnabledSearchBar
        {
            set { _isEnabledSearchBar = value; OnPropertyChanged(); }
            get { return _isEnabledSearchBar; }
        }
        public string _SearchText;
        public string SearchText
        {
            set
            {
                _SearchText = value;
                SearchText_TextChanged();
                OnPropertyChanged();
            }
            get { return _SearchText; }
        }
        private bool _IsLableViewVisible;

        public bool IsLableViewVisible
        {
            get { return _IsLableViewVisible; }
            set { _IsLableViewVisible = value; OnPropertyChanged(); }
        }
        private bool _IsListview;
        public bool IsListview
        {
            get { return _IsListview; }
            set { _IsListview = value; OnPropertyChanged(); }
        }
        public Command OnSearchClearCommand => new Command(() =>
        {

            SearchText = string.Empty;


        });
        private string _searchPlaceHolder;
        public string SearchPlaceHolderText
        {
            get { return _searchPlaceHolder; }
            set { _searchPlaceHolder = value; OnPropertyChanged(); }
        }
        private void DynamicSearchPlaceholder()
        {
            SearchPlaceHolderText = "Search Company";

        }

        public void SearchText_TextChanged()
        {
            var searchtext = SearchText;
            if (string.IsNullOrEmpty(searchtext))
            {
                SearchPlaceHolderText = "Search Company";
                ItemSource = new ObservableCollection<SearchJobsResponseData>(_tempAppliedJobs);
                IsVisibleSearchbarCancelButton = false;
                return;
            }


            IsVisibleSearchbarCancelButton = true;
            var searchresults = _tempAppliedJobs.Where((obj) => obj.companyname.ToLower().Contains(searchtext.ToLower()));
            ItemSource = new ObservableCollection<SearchJobsResponseData>(searchresults);
        }

        #endregion

        #endregion
    }
}
