﻿using GalaSoft.MvvmLight.Command;
using HireMe.Models.JobSeeker;
using MvvmHelpers;
using Rg.Plugins.Popup.Services;
using System.Collections.Generic;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.JobSeeker
{

    public class BranchAddressPopupViewModel : BaseViewModel
    {
        INavigation NavigationService;
        public ICommand OnCommand { get; set; }
        List<BranchDetail> _brachDetails;
        public BranchAddressPopupViewModel(INavigation objnav, List<BranchDetail> brachDetails)
        {
            BindAddress(brachDetails);
            NavigationService = objnav;
            OnCommand = new RelayCommand<string>(DoAction);
        }

        private void BindAddress(List<BranchDetail> _brachDetails)
        {
            List<BranchDetail> objBranchDetails = new List<BranchDetail>();
            foreach (var item in _brachDetails)
            {
                BranchDetail objBranchDetail = new BranchDetail();
                objBranchDetail.FullAddress = item.address + ", "+ "\n" + item.city + ", " + item.state;
                objBranchDetails.Add(objBranchDetail);
            }
            ListViewItemSource = objBranchDetails;

            if (ListViewItemSource.Count > 0)
            {
                IsLableViewVisible = false;
                IsListViewVisible = true;
            }
            else
            {
                IsListViewVisible = false;
                IsLableViewVisible = true;
            }

          

    }

        #region Private Properties
        private bool _IsListViewVisible;
        public bool IsListViewVisible
        {
            get { return _IsListViewVisible; }
            set { _IsListViewVisible = value; OnPropertyChanged(); }
        }

        private bool _IsLableViewVisible;
        public bool IsLableViewVisible
        {
            get { return _IsLableViewVisible; }
            set { _IsLableViewVisible = value; OnPropertyChanged(); }
        }

        #endregion

        private void DoAction(string sender)
        {
            switch (sender)
            {
                case "Cancel":
                    PopupNavigation.PopAsync();
                    break;
            }
        }

        private string _FullAddress;
        public string FullAddress
        {
            get { return _FullAddress; }
            set { _FullAddress = value; OnPropertyChanged(); }
        }

        public List<BranchDetail> _ListViewItemSource;
        public List<BranchDetail> ListViewItemSource
        {
            get { return _ListViewItemSource; }
            set
            {
                _ListViewItemSource = value;
                OnPropertyChanged();
            }
        }
    }
}
