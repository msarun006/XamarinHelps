﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.Models.JobSeeker;
using MvvmHelpers;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.JobSeeker
{
    public class JobDetailsViewModel : BaseViewModel
    {
        INavigation Navigation;
        public bool isClicked = true;
        public ICommand OnCommand { get; set; }
        public String FullDescription { get; set; }
        private HttpCommonService _commonservice { get; set; }
        private string JobPostingId;
        StackLayout Dynamic_StackLayout_LanguageKnown;
        ObservableCollection<CurrentOpeningsResponseData> _currentOpenings;
        ObservableCollection<SearchJobsResponseData> _searjobs;
        ObservableCollection<RecommendedJobResponseData> _recommendedJobs;
        ObservableCollection<CurrentWalkinsResponseData> _CurrentWalkins;
        string _pageName;

        public JobDetailsViewModel(INavigation nav, string pageName, string _JobPostingID, StackLayout dynamic_StackLayout_LanguageKnown, ObservableCollection<CurrentOpeningsResponseData> currentOpenings, ObservableCollection<SearchJobsResponseData> searjobs, ObservableCollection<RecommendedJobResponseData> recommendedJobs, ObservableCollection<CurrentWalkinsResponseData> CurrentWalkins)
        {
            Navigation = nav;
            OnCommand = new Command<string>(DoOperation);
            JobPostingId = _JobPostingID;
            _commonservice = new HttpCommonService();
            Dynamic_StackLayout_LanguageKnown = dynamic_StackLayout_LanguageKnown;
            _pageName = pageName;
            IsShowMoreDescriptions = false;
            if (pageName == "AppliedJobs")
            {
                IsbtnApply = false;
                IslblApplied = false;
            }
            else
            {
                IsbtnApply = true;
                IslblApplied = false;
            }
            if (pageName == "CurrentWalkins")
            {
                IsWalkinsDetailsStack = true;
            }
            else
            {
                IsWalkinsDetailsStack = false;
            }
            #region Values for ObservableCollection
            if (currentOpenings != null)
            {
                _currentOpenings = currentOpenings;
            }
            else
            {
                _currentOpenings = new ObservableCollection<CurrentOpeningsResponseData>();
            }
            if (searjobs != null)
            {
                _searjobs = searjobs;
            }
            else
            {
                _searjobs = new ObservableCollection<SearchJobsResponseData>();
            }
            if (recommendedJobs != null)
            {
                _recommendedJobs = recommendedJobs;
            }
            else
            {
                _recommendedJobs = new ObservableCollection<RecommendedJobResponseData>();
            }
            if (CurrentWalkins != null)
            {
                _CurrentWalkins = CurrentWalkins;
            }
            else
            {
                _CurrentWalkins = new ObservableCollection<CurrentWalkinsResponseData>();
            }
            #endregion
            JobDetailsAPICall();
        }

        private async void DoOperation(string obj)
        {
            try
            {
                if (obj.Equals("OnApplyClicked"))
                {
                    if (isClicked)
                    {
                        isClicked = false;
                        ApplyJobAPICall();
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                }
                else if (obj.Equals("OnMoreClicked"))

                {


                    Description = FullDescription;
                    IsShowMoreDescriptions = false;


                }

            }
            catch (Exception)
            {

            }
        }

        #region Apply Job API Call
        private async void ApplyJobAPICall()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                ApplyJobRequest objApplyJobRequest = new ApplyJobRequest();
                objApplyJobRequest.jobPostingId = JobPostingId;
                objApplyJobRequest.seekerHiremeeId = AppSessionData.ActiveToken.HireMeID;
                //Status defult value "0"
                objApplyJobRequest.status = "0";
                var statusResult = await _commonservice.PostAsync<ApplyJobResponse, ApplyJobRequest>(APIData.API_BASE_URL + APIMethods.ApplyJob, objApplyJobRequest);
                if (statusResult != null)
                {
                    UserDialogs.Instance.HideLoading();
                    if (statusResult.code == "200")
                    {
                        if (statusResult.responseText == "1")
                        {

                            IslblApplied = true;
                            IsbtnApply = false;
                            if (_pageName == "CurrentWalkins")
                            {
                                var searchJobPostingId = _CurrentWalkins.Where(x => x.JobPostingId == JobPostingId).FirstOrDefault();
                                var index = _CurrentWalkins.IndexOf(searchJobPostingId);
                                if (searchJobPostingId != null)
                                {
                                    searchJobPostingId.txtJobApply = "Job applied";
                                    searchJobPostingId.AppliedStatus = "1";
                                }
                                if (index != -1)
                                    _CurrentWalkins[index] = searchJobPostingId;
                            }
                            if (_pageName == "Current Opennings")
                            {
                                var searchJobPostingId = _currentOpenings.Where(x => x.JobPostingId == JobPostingId).FirstOrDefault();
                                var index = _currentOpenings.IndexOf(searchJobPostingId);
                                if (searchJobPostingId != null)
                                {
                                    searchJobPostingId.txtJobApply = "Job applied";
                                    searchJobPostingId.AppliedStatus = "1";
                                }
                                if (index != -1)
                                    _currentOpenings[index] = searchJobPostingId;

                            }
                            if (_pageName == "SearchJobs")
                            {
                                var searchJobPostingId = _searjobs.Where(x => x.JobPostingId == JobPostingId).FirstOrDefault();
                                var index = _searjobs.IndexOf(searchJobPostingId);
                                if (searchJobPostingId != null)
                                {
                                    searchJobPostingId.txtJobApply = "Job applied";
                                    searchJobPostingId.AppliedStatus = "1";
                                }
                                if (index != -1)
                                    _searjobs[index] = searchJobPostingId;
                            }
                            if (_pageName == "Recommended Jobs")
                            {
                                var searchJobPostingId = _recommendedJobs.Where(x => x.JobPostingId == JobPostingId).FirstOrDefault();
                                var index = _recommendedJobs.IndexOf(searchJobPostingId);
                                if (searchJobPostingId != null)
                                {
                                    searchJobPostingId.txtJobApply = "Job applied";
                                    searchJobPostingId.AppliedStatus = "1";
                                }
                                if (index != -1)
                                    _recommendedJobs[index] = searchJobPostingId;

                            }
                            await UserDialogs.Instance.AlertAsync(statusResult.message);
                        }
                        else
                        {
                            IslblApplied = false;
                            IsbtnApply = true;
                            await UserDialogs.Instance.AlertAsync(statusResult.message);
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(statusResult.message);
                    }
                }

            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "JobDetailsViewModel.ApplyJobAPICall");
            }
        }
        #endregion

        #region Job Details APICall
        private async void JobDetailsAPICall()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                List<Language> objlanguages = new List<Language>();
                JobDetailsRequest objJobDetailsRequest = new JobDetailsRequest();
                objJobDetailsRequest.CandidateHiremeeID = AppSessionData.ActiveToken.HireMeID;
                objJobDetailsRequest.JobPostingId = JobPostingId;
                var statusResult = await _commonservice.PostAsync<JobDetailsResponse, JobDetailsRequest>(APIData.API_BASE_URL + APIMethods.JobDetails, objJobDetailsRequest);
                if (statusResult != null)
                {
                    UserDialogs.Instance.HideLoading();
                    if (statusResult.Code == "200")
                    {


                        JobTitle = statusResult.CommonJobDetails.job_title;
                        Companyname = statusResult.CommonJobDetails.companyname;
                        IndustryName = statusResult.CommonJobDetails.industry_name;
                        Skills = statusResult.CommonJobDetails.skills;
                        Location = statusResult.CommonJobDetails.location;
                        NumberOfPostion = statusResult.CommonJobDetails.numberofpostion;
                        Gender = statusResult.CommonJobDetails.Gender;
                        EmpType = statusResult.CommonJobDetails.EmpType;
                        MandatoryQualification = statusResult.CommonJobDetails.MandatoryQualification;
                        Salary = statusResult.CommonJobDetails.salary_from + "-" + statusResult.CommonJobDetails.salary_to;
                        WalkinFromDate = statusResult.CommonJobDetails.walkin_from;
                        WalkinToDate = statusResult.CommonJobDetails.walkin_to;
                        FromTime = statusResult.CommonJobDetails.start_time;
                        ToTime = statusResult.CommonJobDetails.to_time;
                        InterviewSlot = statusResult.CommonJobDetails.interview_slots;
                        if (statusResult.Venues.Count > 0)
                        {
                            string title = string.Empty;
                            int length = statusResult.Venues.Count;
                            int counter = 0;
                            foreach (var item in statusResult.Venues)
                            {
                                if (!string.IsNullOrEmpty(item.Address))
                                {
                                    counter++;
                                    title += item.Address;
                                    if (counter < length)
                                    {
                                        title += ", ";
                                    }
                                }
                                else
                                {
                                    Venu = "NA";
                                }
                            }
                            Venu = title;
                        }
                        else
                        {
                            Venu = "NA";
                        }
                        if (statusResult.Qualification.Count > 0)
                        {
                            string title = string.Empty;
                            int length = statusResult.Qualification.Count;
                            int counter = 0;
                            foreach (var item in statusResult.Qualification)
                            {
                                if (!string.IsNullOrEmpty(item.CourseName) && !string.IsNullOrEmpty(item.SpecilizationName))
                                {
                                    counter++;
                                    title += item.CourseName + "-" + item.SpecilizationName;
                                    if (counter < length)
                                    {
                                        title += ", ";
                                    }
                                }
                                else
                                {
                                    Qualifications = "NA";
                                }
                            }
                            Qualifications = title;
                        }
                        else
                        {
                            Qualifications = "NA";
                        }
                        PreferredSkills = statusResult.CommonJobDetails.PreferredSkills;
                        Description = Regex.Replace(Regex.Replace(statusResult.CommonJobDetails.description.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);


                        if (Description.Length >= 200)
                        {
                            FullDescription = Description;
                            string str = Description.Substring(0, 199);
                            Description = str;
                            IsShowMoreDescriptions = true;

                        }

                        JobWorkingDays = statusResult.CommonJobDetails.job_working_days;
                        JobWorkingOff = statusResult.CommonJobDetails.job_working_off;
                        CTC = statusResult.CommonJobDetails.CTC;
                        OtherRequirements = statusResult.CommonJobDetails.other_requirements;
                        if (statusResult.CommonJobDetails.AppliedStatus == "1")
                        {
                            IsbtnApply = false;
                            IslblApplied = true;
                        }
                        else
                        {
                            IsbtnApply = true; ;
                            IslblApplied = false;
                        }
                        if (statusResult.Languages.Count > 0)
                        {
                            IsListView = true;
                            IsNotUpdated = false;
                            foreach (var item in statusResult.Languages)
                            {
                                if (!string.IsNullOrEmpty(item.languages) && !string.IsNullOrEmpty(item.read) && !string.IsNullOrEmpty(item.write) && !string.IsNullOrEmpty(item.speak))
                                {
                                    Language obj = item;
                                    if (item.speak == "1")
                                    {
                                        obj.isSpeak = true;
                                    }
                                    else
                                    {
                                        obj.isSpeak = false;
                                    }
                                    if (item.read == "1")
                                    {
                                        obj.isRead = true;
                                    }
                                    else
                                    {
                                        obj.isRead = false;
                                    }
                                    if (item.write == "1")
                                    {
                                        obj.isWrite = true;
                                    }
                                    else
                                    {
                                        obj.isWrite = false;
                                    }
                                    objlanguages.Add(obj);
                                }
                                else
                                {
                                    IsListView = false;
                                    IsNotUpdated = true;
                                }


                                var lbl_Language = new Label { Text = item.languages, TextColor = Color.FromHex("#3d3d3d"), FontAttributes = FontAttributes.Bold, FontSize = Device.GetNamedSize(NamedSize.Small, typeof(Label)) ,WidthRequest=100};
                                var lbl_Colon = new Label { Text = " : ", TextColor = Color.Black, FontAttributes = FontAttributes.Bold };

                                var lbl_Speak = new RoundRectLabel { Text = "  Speak  ", VerticalTextAlignment = TextAlignment.Center, HorizontalTextAlignment = TextAlignment.Center, IsVisible = item.isSpeak, BackgroundColor = Color.Green, CornerRadius = 40, FontSize = Device.GetNamedSize(NamedSize.Micro, typeof(Label)), TextColor = Color.White };
                                var lbl_Read = new RoundRectLabel { Text = "  Read  ", VerticalTextAlignment = TextAlignment.Center, HorizontalTextAlignment = TextAlignment.Center, IsVisible = item.isRead, BackgroundColor = Color.Green, CornerRadius = 40, FontSize = Device.GetNamedSize(NamedSize.Micro, typeof(Label)), TextColor = Color.White };
                                var lbl_Write = new RoundRectLabel { Text = "  Write  ", VerticalTextAlignment = TextAlignment.Center, HorizontalTextAlignment = TextAlignment.Center, IsVisible = item.isWrite, BackgroundColor = Color.Green, CornerRadius = 40, FontSize = Device.GetNamedSize(NamedSize.Micro, typeof(Label)), TextColor = Color.White };


                                var dynamicStackItme = new StackLayout
                                {
                                    Margin = 2,
                                    VerticalOptions = LayoutOptions.Fill,
                                    BackgroundColor = Color.Transparent,
                                    HorizontalOptions = LayoutOptions.StartAndExpand,
                                    Orientation = StackOrientation.Horizontal
                                };




                                dynamicStackItme.Children.Add(lbl_Language);
                                dynamicStackItme.Children.Add(lbl_Colon);

                                dynamicStackItme.Children.Add(lbl_Speak);
                                dynamicStackItme.Children.Add(lbl_Read);
                                dynamicStackItme.Children.Add(lbl_Write);


                                Dynamic_StackLayout_LanguageKnown.Children.Add(dynamicStackItme);
                            }
                            ItemSource = statusResult.Languages;
                        }
                        else
                        {
                            IsListView = false;
                            IsNotUpdated = true;
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(statusResult.Message);
                    }
                }

            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "JobDetailsViewModel.JobDetailsAPICall");
            }
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, string ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        #region Private Properties

        private string _Venu;
        public string Venu
        {
            get { return _Venu; }
            set { _Venu = value; OnPropertyChanged(); }
        }
        private string _InterviewSlot;
        public string InterviewSlot
        {
            get { return _InterviewSlot; }
            set { _InterviewSlot = value; OnPropertyChanged(); }
        }
        private string _ToTime;
        public string ToTime
        {
            get { return _ToTime; }
            set { _ToTime = value; OnPropertyChanged(); }
        }
        private string _FromTime;
        public string FromTime
        {
            get { return _FromTime; }
            set { _FromTime = value; OnPropertyChanged(); }
        }
        private string _ToDate;
        public string WalkinToDate
        {
            get { return _ToDate; }
            set { _ToDate = value; OnPropertyChanged(); }
        }
        private string _FromDate;
        public string WalkinFromDate
        {
            get { return _FromDate; }
            set { _FromDate = value; OnPropertyChanged(); }
        }


        private List<Language> _ItemSource;
        public List<Language> ItemSource
        {
            get { return _ItemSource; }
            set { _ItemSource = value; OnPropertyChanged(); }
        }

        private bool _isListView;
        public bool IsListView
        {
            get { return _isListView; }
            set { _isListView = value; OnPropertyChanged(); }
        }
        private bool _IsNotUpdated;
        public bool IsNotUpdated
        {
            get { return _IsNotUpdated; }
            set { _IsNotUpdated = value; OnPropertyChanged(); }
        }


        private string _job_title;
        public string JobTitle
        {
            get { return _job_title; }
            set { _job_title = value; OnPropertyChanged(); }
        }
        private string industry_name;
        public string IndustryName
        {
            get { return industry_name; }
            set { industry_name = value; OnPropertyChanged(); }
        }
        private string _skills;
        public string Skills
        {
            get { return _skills; }
            set { _skills = value; OnPropertyChanged(); }
        }
        private string last_date;
        public string LastDate
        {
            get { return last_date; }
            set { last_date = value; OnPropertyChanged(); }
        }
        private string _companyname;
        public string Companyname
        {
            get { return _companyname; }
            set { _companyname = value; OnPropertyChanged(); }
        }
        private string _location;
        public string Location
        {
            get { return _location; }
            set { _location = value; OnPropertyChanged(); }
        }
        private string _description;
        public string Description
        {
            get { return _description; }
            set { _description = value; OnPropertyChanged(); }
        }
        private string _numberofpostion;
        public string NumberOfPostion
        {
            get { return _numberofpostion; }
            set { _numberofpostion = value; OnPropertyChanged(); }
        }
        private string _CompanyS3Id;
        public string CompanyS3Id
        {
            get { return _CompanyS3Id; }
            set { _CompanyS3Id = value; OnPropertyChanged(); }
        }
        private string _AppliedStatus;
        public string AppliedStatus
        {
            get { return _AppliedStatus; }
            set { _AppliedStatus = value; OnPropertyChanged(); }
        }

        private string _PreferredSkills;
        public string PreferredSkills
        {
            get { return _PreferredSkills; }
            set { _PreferredSkills = value; OnPropertyChanged(); }
        }

        private string _Gender;
        public string Gender
        {
            get { return _Gender; }
            set { _Gender = value; OnPropertyChanged(); }
        }

        private string _EmpType;
        public string EmpType
        {
            get { return _EmpType; }
            set { _EmpType = value; OnPropertyChanged(); }
        }

        private string _MandatoryQualification;
        public string MandatoryQualification
        {
            get { return _MandatoryQualification; }
            set { _MandatoryQualification = value; OnPropertyChanged(); }
        }

        private string job_working_days;
        public string JobWorkingDays
        {
            get { return job_working_days; }
            set { job_working_days = value; OnPropertyChanged(); }
        }

        private string job_working_off;
        public string JobWorkingOff
        {
            get { return job_working_off; }
            set { job_working_off = value; OnPropertyChanged(); }
        }
        private string _CTC;
        public string CTC
        {
            get { return _CTC; }
            set { _CTC = value; OnPropertyChanged(); }
        }

        private string _Qualifications;
        public string Qualifications
        {
            get { return _Qualifications; }
            set { _Qualifications = value; OnPropertyChanged(); }
        }

        private string other_requirements;
        public string OtherRequirements
        {
            get { return other_requirements; }
            set { other_requirements = value; OnPropertyChanged(); }
        }

        private bool _IsWalkinsDetailsStack;

        public bool IsWalkinsDetailsStack
        {
            get { return _IsWalkinsDetailsStack; }
            set { _IsWalkinsDetailsStack = value; OnPropertyChanged(); }
        }
        private string _Salary;

        public string Salary
        {
            get { return _Salary; }
            set { _Salary = value; OnPropertyChanged(); }
        }



        private bool _islblApplied;
        public bool IslblApplied
        {
            get { return _islblApplied; }
            set { _islblApplied = value; OnPropertyChanged(); }
        }

        private bool _isbtnApply;
        public bool IsbtnApply
        {
            get { return _isbtnApply; }
            set { _isbtnApply = value; OnPropertyChanged(); }
        }

        private bool _IsShowMoreDescriptions;
        public bool IsShowMoreDescriptions
        {
            get { return _IsShowMoreDescriptions; }
            set { _IsShowMoreDescriptions = value; OnPropertyChanged(); }
        }

        #endregion
      
    }
}