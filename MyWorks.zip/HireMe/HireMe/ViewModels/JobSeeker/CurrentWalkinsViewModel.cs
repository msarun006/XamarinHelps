﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.Models.JobSeeker;
using HireMe.Views.JobSeeker;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.JobSeeker
{
    public class CurrentWalkinsViewModel : BaseViewModel
    {
        INavigation Navigation;
        public bool isClicked = true;
        ObservableCollection<CurrentWalkinsResponseData> _tempCurrentWalkinsResponseData;
        public ICommand FocusDatePickerCommand { get; set; }
        public ICommand OnCommand { get; set; }

        private HttpCommonService _commonservice { get; set; }
        public CurrentWalkinsViewModel(INavigation nav)
        {
            Navigation = nav;
            OnCommand = new Command<string>(DoOperation);
            FocusDatePickerCommand = new Command<object>(Onfocus);
            _commonservice = new HttpCommonService();
            ProfilePicture = (string)Application.Current.Resources["IconUser"];
            IconFilter = (string)Application.Current.Resources["IconFilter"];
            SearchPlaceHolderText = "Search Company";
            DatepickerToValue = DateTime.Now.ToString("yyyy-MM-dd");
            DatepickerFromValue = DateTime.Now.ToString("yyyy-MM-dd");
            IsFliterCurrentWalkins = false;
            IsListview = true;
            IsCurrentWalkins = true;
            CurrentWalkinsAPICall();
        }

        private async void DoOperation(string obj)
        {
            try
            {
                if (obj.Equals("OnFilter"))
                {
                    DatepickerToValue = DateTime.Now.ToString("yyyy-MM-dd");
                    DatepickerFromValue = DateTime.Now.ToString("yyyy-MM-dd");
                    if (!IsFliterCurrentWalkins)
                    {
                        IsFliterCurrentWalkins = true;
                        IsCurrentWalkins = false;
                        IsLableViewVisible = false;
                        IconFilter = (string)Application.Current.Resources["IconClose"];
                    }
                    else
                    {
                        IconFilter = (string)Application.Current.Resources["IconFilter"];
                        IsFliterCurrentWalkins = false;
                        IsCurrentWalkins = true;
                        IsListview = true;
                        //if (_tempCurrentWalkinsResponseData.Count > 0)
                        //{
                        //    ItemSource = _tempCurrentWalkinsResponseData;
                        //}
                        //else
                        //{
                        if (isClicked)
                        {
                            isClicked = false;
                            CurrentWalkinsAPICall();
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(500);
                            isClicked = true;
                        });
                        //}
                    }
                    IsLableViewVisible = false;


                }
                else if (obj.Equals("Clear"))
                {
                    DatepickerToValue = DateTime.Now.ToString("yyyy-MM-dd");
                    DatepickerFromValue = DateTime.Now.ToString("yyyy-MM-dd");
                }
                else if (obj.Equals("OnFilterApplyBtn"))
                {
                    if (isClicked)
                    {
                        isClicked = false;
                        CurrentWalkinsAPICall();
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                }
            }
            catch (Exception ex)
            {

            }
        }

        #region Date Picker
        private string _datepickerFromValue;
        public string DatepickerFromValue
        {
            get { return _datepickerFromValue; }
            set
            {
                _datepickerFromValue = value;
                OnPropertyChanged();
            }
        }
        private string _datepickerToValue;
        public string DatepickerToValue
        {
            get { return _datepickerToValue; }
            set
            {
                _datepickerToValue = value;

                OnPropertyChanged();
            }
        }
        private void Onfocus(object obj)
        {
            var datepicker = (DatePicker)obj;
            datepicker.Focus();
        }
        private Command<object> todatechagedcommand;
        public Command<object> ToDateChangedCommand
        {
            get { return todatechagedcommand ?? (todatechagedcommand = new Command<object>(async arg => await OnToDateChangedCommand(arg))); }
        }

        private Command<object> fromdatechagedcommand;
        public Command<object> FromDateChangedCommand
        {
            get { return fromdatechagedcommand ?? (fromdatechagedcommand = new Command<object>(async arg => await OnFromDateChangedCommand(arg))); }
        }
        private async Task OnToDateChangedCommand(object sender)
        {

            var datepicker = (DatePicker)sender;
            DatepickerToValue = datepicker.Date.ToString("yyyy-MM-dd");


        }
        private async Task OnFromDateChangedCommand(object sender)
        {

            var datepicker = (DatePicker)sender;
            DatepickerFromValue = datepicker.Date.ToString("yyyy-MM-dd");
        }
        #endregion

        #region SelectedCommand
        public ICommand SelectedCommand => new Command(async () =>
        {
            if (isClicked)
            {
                isClicked = false;
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {
                    await Navigation.PushAsync(new JobDetailsViewPage("CurrentWalkins", SelectedItem.JobPostingId, null, null, null, ItemSource));
                }
                else
                {
                    UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                }
            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });
        });
        #endregion

        #region Private properties
        private string _IconFilter;

        public string IconFilter
        {
            get { return _IconFilter; }
            set { _IconFilter = value; OnPropertyChanged(); }
        }
        private bool _IsLableViewVisible;
        public bool IsLableViewVisible
        {
            get { return _IsLableViewVisible; }
            set { _IsLableViewVisible = value; OnPropertyChanged(); }
        }
        private bool _IsListview;
        public bool IsListview
        {
            get { return _IsListview; }
            set { _IsListview = value; OnPropertyChanged(); }
        }

        private string _ProfilePicture;

        public string ProfilePicture
        {
            get { return _ProfilePicture; }
            set { _ProfilePicture = value; OnPropertyChanged(); }
        }
        private bool _IsFliterCurrentWalkins;
        public bool IsFliterCurrentWalkins
        {
            get { return _IsFliterCurrentWalkins; }
            set { _IsFliterCurrentWalkins = value; OnPropertyChanged(); }
        }
        private bool _IsCurrentWalkins;
        public bool IsCurrentWalkins
        {
            get { return _IsCurrentWalkins; }
            set { _IsCurrentWalkins = value; OnPropertyChanged(); }
        }

        private ObservableCollection<CurrentWalkinsResponseData> _ItemSource;
        public ObservableCollection<CurrentWalkinsResponseData> ItemSource
        {
            get { return _ItemSource; }
            set { _ItemSource = value; OnPropertyChanged(); }
        }

        private CurrentWalkinsResponseData _SelectedItem;
        public CurrentWalkinsResponseData SelectedItem
        {
            get { return _SelectedItem; }
            set { _SelectedItem = value; OnPropertyChanged(); }
        }
        #region Searchbar Controls
        private bool _isVisibleSearchbarCancel;
        public bool IsVisibleSearchbarCancelButton
        {
            get { return _isVisibleSearchbarCancel; }
            set { _isVisibleSearchbarCancel = value; OnPropertyChanged(); }
        }
        public bool _isEnabledSearchBar;

        public bool isEnabledSearchBar
        {
            set { _isEnabledSearchBar = value; OnPropertyChanged(); }
            get { return _isEnabledSearchBar; }
        }
        public string _SearchText;
        public string SearchText
        {
            set
            {
                _SearchText = value;
                SearchText_TextChanged();
                OnPropertyChanged();
            }
            get { return _SearchText; }
        }
        public Command OnSearchClearCommand => new Command(() =>
        {

            SearchText = string.Empty;


        });
        private string _searchPlaceHolder;
        public string SearchPlaceHolderText
        {
            get { return _searchPlaceHolder; }
            set { _searchPlaceHolder = value; OnPropertyChanged(); }
        }
        private void DynamicSearchPlaceholder()
        {
            SearchPlaceHolderText = "Search Company";

        }

        public void SearchText_TextChanged()
        {
            var searchtext = SearchText;
            if (string.IsNullOrEmpty(searchtext))
            {
                SearchPlaceHolderText = "Search Company";
                ItemSource = new ObservableCollection<CurrentWalkinsResponseData>(_tempCurrentWalkinsResponseData);
                IsVisibleSearchbarCancelButton = false;
                return;
            }


            IsVisibleSearchbarCancelButton = true;
            var searchresults = _tempCurrentWalkinsResponseData.Where((obj) => obj.companyname.ToLower().Contains(searchtext.ToLower()));
            ItemSource = new ObservableCollection<CurrentWalkinsResponseData>(searchresults);


        }

        #endregion

        #endregion

        #region Current Walins API call
        private async void CurrentWalkinsAPICall()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                #region GenereateSkill Id 
                string Primaryskillsid = string.Empty;
                if (AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.Primaryskills != null)
                {
                    int Primaryskillscount = AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.Primaryskills.Count;
                    int Primaryskillscountcounter = 0;
                    foreach (var skill in AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.Primaryskills)
                    {
                        Primaryskillscountcounter++;
                        Primaryskillsid += skill.ID;
                        if (Primaryskillscountcounter < Primaryskillscount)
                        {
                            Primaryskillsid += ",";
                        }

                    }
                }

                string Secondaryskillsid = string.Empty;
                if (AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.Secondaryskills != null)
                {
                    int Secondaryskillscount = AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.Secondaryskills.Count;
                    int counter = 0;
                    foreach (var skill in AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.Secondaryskills)
                    {
                        counter++;
                        Secondaryskillsid += skill.ID;
                        if (counter < Secondaryskillscount)
                        {
                            Secondaryskillsid += ",";
                        }
                    }

                }
                #endregion
                ObservableCollection<CurrentWalkinsResponseData> objCurrentOpeningsResponseData = new ObservableCollection<CurrentWalkinsResponseData>();
                CurrenWalkinsRequest objCurrenWalkinsRequest = new CurrenWalkinsRequest();
                objCurrenWalkinsRequest.CandidateHiremeeId = AppPreferences.ActiveToken.HireMeID;

                if (!string.IsNullOrEmpty(Primaryskillsid) && !string.IsNullOrEmpty(Secondaryskillsid))
                {
                    if (Primaryskillsid.Contains(",Others"))
                    {
                        Primaryskillsid = Primaryskillsid.Replace(",Others", string.Empty);
                    }
                    objCurrenWalkinsRequest.CommaSeperatedSkillId = Primaryskillsid + "," + Secondaryskillsid;
                }
                else if (!string.IsNullOrEmpty(Primaryskillsid))
                {
                    if (Primaryskillsid.Contains(",Others"))
                    {
                        Primaryskillsid = Primaryskillsid.Replace(",Others", string.Empty);
                    }
                    objCurrenWalkinsRequest.CommaSeperatedSkillId = Primaryskillsid;
                }
                else if (!string.IsNullOrEmpty(Secondaryskillsid))
                {
                    objCurrenWalkinsRequest.CommaSeperatedSkillId = Secondaryskillsid;
                }
                else
                {
                    objCurrenWalkinsRequest.CommaSeperatedSkillId = null;
                }

                objCurrenWalkinsRequest.CompanyName = null;
                if (IsFliterCurrentWalkins)
                {
                    objCurrenWalkinsRequest.WalkinFrom = DatepickerFromValue;
                    objCurrenWalkinsRequest.WalkinTo = DatepickerToValue;
                }
                else
                {
                    objCurrenWalkinsRequest.WalkinFrom = null;
                    objCurrenWalkinsRequest.WalkinTo = null;
                }

                var statusResult = await _commonservice.PostAsync<CurrentWalkinsResponse, CurrenWalkinsRequest>(APIData.API_BASE_URL + APIMethods.GetCurrentWalinsList, objCurrenWalkinsRequest);
                if (statusResult != null)
                {
                    UserDialogs.Instance.HideLoading();
                    if (statusResult.Code == "200")
                    {
                        if (IsFliterCurrentWalkins)
                        {
                            if (statusResult.CurrentWalkins != null && statusResult.CurrentWalkins.Count > 0)
                            {
                                IsFliterCurrentWalkins = false;
                                IsCurrentWalkins = true;
                                IsListview = true;
                            }
                            else
                            {
                                ItemSource.Clear();
                                IconFilter = (string)Application.Current.Resources["IconFilter"];
                                IsFliterCurrentWalkins = false;
                                IsCurrentWalkins = true;
                                isEnabledSearchBar = false;
                                IsListview = false;
                                IsLableViewVisible = true;
                            }
                        }
                        if (statusResult.CurrentWalkins != null && statusResult.CurrentWalkins.Count > 0)
                        {
                            isEnabledSearchBar = true;
                            IsLableViewVisible = false;
                            IsListview = true;
                            _tempCurrentWalkinsResponseData = new ObservableCollection<CurrentWalkinsResponseData>(statusResult.CurrentWalkins);
                            foreach (var item in statusResult.CurrentWalkins)
                            {
                                CurrentWalkinsResponseData obj = item;
                                obj.description = Regex.Replace(Regex.Replace(item.description.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty); ;
                                if (item.AppliedStatus == "1")
                                {
                                    obj.txtJobApply = "Job applied";
                                }
                                else
                                {
                                    obj.txtJobApply = "Apply";
                                }
                                obj.Timing = item.start_time + " to " + item.to_time;
                                objCurrentOpeningsResponseData.Add(obj);
                            }
                            ItemSource = objCurrentOpeningsResponseData;
                        }
                        else
                        {
                            isEnabledSearchBar = false;
                            IsListview = false;
                            IsLableViewVisible = true;
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();

                        IsFliterCurrentWalkins = false;
                        IsCurrentWalkins = true;
                        isEnabledSearchBar = false;
                        IconFilter = (string)Application.Current.Resources["IconFilter"];
                        IsListview = false;
                        IsLableViewVisible = true;
                        //await UserDialogs.Instance.AlertAsync(statusResult.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "CurrentWalkinsViewModel.CurrentWalkinsAPICall");
            }
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, string ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
