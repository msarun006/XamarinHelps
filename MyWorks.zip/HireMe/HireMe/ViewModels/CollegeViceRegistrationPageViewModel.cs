﻿using System;
using System.Diagnostics;
using System.Windows.Input;
using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using MvvmHelpers;
using Plugin.Connectivity;
using Xamarin.Forms;
using HireMe.Helpers;

namespace HireMe
{
	public class CollegeViceRegistrationPageViewModel : BaseViewModel
	{
		LoginPageNew _loginPageView;
		TermsOfUse _termofuse;
		private HttpCommonService _commonservice { get; set; }
		string ErrorMessage { get; set; }
		public ICommand FocusDatePickerCommand { get; set; }
		public CollegeViseRegistrationsRequestData RegistrationData { get; set; }
		public Command OnClickedEvent
		{
			get;
			set;
		}
		INavigation Navigation;
		public CollegeViceRegistrationPageViewModel(INavigation navigation)
		{

			Navigation = navigation;
			_commonservice = new HttpCommonService();
			RegistrationData = new CollegeViseRegistrationsRequestData();
			RegistrationData.FirstName = AppPreferences.Collegeviseregistraiton.FirstName;
			RegistrationData.LastName = AppPreferences.Collegeviseregistraiton.LastName;
			RegistrationData.EmailAddress = AppPreferences.Collegeviseregistraiton.EmailAddress;
			RegistrationData.MobileNumber = AppPreferences.Collegeviseregistraiton.MobileNumber;
			ConfirmPasswordText = String.Empty;

			OnClickedEvent = new Command(FunctionCall);
			DOBTextColor = Color.Gray;
			DatePickerIsVisible = false;
			DOBisVisible = true;
			RegistrationData.DOB = "Select DOB";

			ConfirmPasswordIsPassword = true;
			PasswordIsPassword = true;


			HideConfirmPassword = (string)Application.Current.Resources["HidePassword"]; ;
			HidePassword = (string)Application.Current.Resources["HidePassword"];
			PasswordSignHelperTextIsVisible = false;
			FocusDatePickerCommand = new RelayCommand<object>(OnFocus);

		}

		void OnFocus(object obj)
		{

			var datepicker = (DatePicker)obj;
			datepicker.Focus();
			RegistrationData.DOB = datepicker.Date.ToString("dd-MM-yyyy");

		}

		public string _PasswordSignText;
		public string PasswordSignText
		{
			get { return _PasswordSignText; }
			set
			{
				_PasswordSignText = value; OnPropertyChanged();
			}
		}

		public Boolean _PasswordSignIsVisible;
		public Boolean PasswordSignIsVisible
		{
			get { return _PasswordSignIsVisible; }
			set
			{
				_PasswordSignIsVisible = value; OnPropertyChanged();
			}
		}

		public Color _PasswordSignTextColor;
		public Color PasswordSignTextColor
		{
			get { return _PasswordSignTextColor; }
			set
			{
				_PasswordSignTextColor = value; OnPropertyChanged();
			}
		}


		public Boolean _PasswordSignHelperTextIsVisible;
		public Boolean PasswordSignHelperTextIsVisible
		{
			get { return _PasswordSignHelperTextIsVisible; }
			set
			{
				_PasswordSignHelperTextIsVisible = value; OnPropertyChanged();
			}
		}



		public string _ConfirmPasswordSignText;
		public string ConfirmPasswordSignText
		{
			get { return _ConfirmPasswordSignText; }
			set
			{
				_ConfirmPasswordSignText = value; OnPropertyChanged();
			}
		}

		public Boolean _ConfirmPasswordSignIsVisible;
		public Boolean ConfirmPasswordSignIsVisible
		{
			get { return _ConfirmPasswordSignIsVisible; }
			set
			{
				_ConfirmPasswordSignIsVisible = value; OnPropertyChanged();
			}
		}

		public Color _ConfirmPasswordSignTextColor;
		public Color ConfirmPasswordSignTextColor
		{
			get { return _ConfirmPasswordSignTextColor; }
			set
			{
				_ConfirmPasswordSignTextColor = value; OnPropertyChanged();
			}
		}


		public Boolean _ConfirmPasswordIsPassword;
		public Boolean ConfirmPasswordIsPassword
		{
			get { return _ConfirmPasswordIsPassword; }
			set
			{
				_ConfirmPasswordIsPassword = value; OnPropertyChanged();
			}
		}


		public Boolean _PasswordIsPassword;
		public Boolean PasswordIsPassword
		{
			get { return _PasswordIsPassword; }
			set
			{
				_PasswordIsPassword = value; OnPropertyChanged();
			}
		}


		public string _HideConfirmPassword;
		public string HideConfirmPassword
		{
			get { return _HideConfirmPassword; }
			set
			{
				_HideConfirmPassword = value; OnPropertyChanged();
			}
		}

		public string _HidePassword;
		public string HidePassword
		{
			get { return _HidePassword; }
			set
			{
				_HidePassword = value; OnPropertyChanged();
			}
		}

		public void EntryPassword_Unfocused(object sender, FocusEventArgs args)
		{
			var text = ((Entry)sender).Text;
			if (string.IsNullOrEmpty(text) || text.Contains(" "))
			{
				PasswordSignText = (string)Application.Current.Resources["WrongSign"];
				PasswordSignIsVisible = true;
				PasswordSignTextColor = Color.Red;
				PasswordSignHelperTextIsVisible = true;
			}
			else
			{
				if (!Utilities.ValidatePassword(RegistrationData.Password))
				{
					PasswordSignText = (string)Application.Current.Resources["WrongSign"];
					PasswordSignIsVisible = true;
					PasswordSignTextColor = Color.Red;
					PasswordSignHelperTextIsVisible = true;
				}
				else
				{
					PasswordSignText = (string)Application.Current.Resources["RightSign"];
					PasswordSignIsVisible = true;
					PasswordSignTextColor = Color.Green;
					PasswordSignHelperTextIsVisible = false;
				}
			}
		}

		public void EntryConfirmPassword_Unfocused(object sender, FocusEventArgs args)
		{
			var text = ((Entry)sender).Text;
			if (string.IsNullOrEmpty(text))
			{
				ConfirmPasswordSignText = (string)Application.Current.Resources["WrongSign"];
				ConfirmPasswordSignIsVisible = true;
				ConfirmPasswordSignTextColor = Color.Red;
			}
			else
			{
				if (RegistrationData.Password != ConfirmPasswordText)
				{
					ConfirmPasswordSignText = (string)Application.Current.Resources["WrongSign"];
					ConfirmPasswordSignIsVisible = true;
					ConfirmPasswordSignTextColor = Color.Red;
				}
				else
				{
					ConfirmPasswordSignText = (string)Application.Current.Resources["RightSign"];
					ConfirmPasswordSignIsVisible = true;
					ConfirmPasswordSignTextColor = Color.Green;
				}
			}
		}

		public async void FunctionCall(object obj)
		{

			if (obj.ToString() == "confirmpassword")
			{

				if (ConfirmPasswordIsPassword == true)
				{
					HideConfirmPassword = (string)Application.Current.Resources["ShowPassword"];
					ConfirmPasswordIsPassword = false;
				}
				else
				{
					HideConfirmPassword = (string)Application.Current.Resources["HidePassword"];
					ConfirmPasswordIsPassword = true;
				}
			}
			else if (obj.ToString() == "password")
			{
				if (PasswordIsPassword == true)
				{
					HidePassword = (string)Application.Current.Resources["ShowPassword"];
					PasswordIsPassword = false;
				}
				else
				{

					HidePassword = (string)Application.Current.Resources["HidePassword"];
					PasswordIsPassword = true;
				}
			}
			else if (obj.ToString() == "selectDOB")
			{




			}
			else if (obj.ToString() == "termsofuse")
			{

				_termofuse = new TermsOfUse();
				bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
				if (isNetworkAvailable)
				{
					await this.Navigation.PushAsync(_termofuse);
				}
				else
				{
					UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
				}


			}
			else if (obj.ToString() == "register")
			{

				if (!IsValidData())
				{
					if (!string.IsNullOrEmpty(ErrorMessage))
					{

                        await UserDialogs.Instance.AlertAsync(ErrorMessage);

                    }
                }
				else
				{
					try
					{
						UserDialogs.Instance.ShowLoading();

						var statusResult = await _commonservice.PostAsync<CollegeViseRegistrationsResponseData, CollegeViseRegistrationsRequestData>(APIData.API_BASE_URL+APIMethods.CollegeWiseRegistration, RegistrationData);

						UserDialogs.Instance.HideLoading();
						if (statusResult != null)
						{
							if (statusResult.code == "200")
							{
								AppPreferences.IsCollegeViseRegistraiton = false;
							    await	UserDialogs.Instance.AlertAsync(statusResult.message);

                                //Application.Current.MainPage = new LoginPageNew();
                                Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                                return;
                            }
							else
							{

                                await UserDialogs.Instance.AlertAsync(statusResult.message);

                            }
                        }
					}
					catch (Exception ex)
					{
						Debug.WriteLine(ex.Message);
                        SendErrorMessageToServer(ex, "CollegeViceRegistrationPageViewModel.FunctionCall");

                    }

				}


			}
			else if (obj.ToString() == "signin")
			{
				_loginPageView = new LoginPageNew();
				Application.Current.MainPage = new NavigationPage(_loginPageView);
                return;

            }





		}

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion





        #region Private Methods
        private bool IsValidData()
		{
			ErrorMessage = string.Empty;
			bool isvalid = false;
			if (!string.IsNullOrEmpty(RegistrationData.AadharNumber) && !Utilities.ValidateAadhaarNumber(RegistrationData.AadharNumber))
			{
                Device.BeginInvokeOnMainThread(async () =>
                {
                    await UserDialogs.Instance.AlertAsync("Enter Valid Aadhaar Number");
                });
                return isvalid;
			}
			if (RegistrationData.DOB == "DD-MM-YYYY")
			{

                Device.BeginInvokeOnMainThread(async () =>
                {
                    await UserDialogs.Instance.AlertAsync("Enter Data of Birth");
                });
             
				return isvalid;
			}
			if (string.IsNullOrEmpty(RegistrationData.Password))
			{
                Device.BeginInvokeOnMainThread(async () =>
                {
                    await UserDialogs.Instance.AlertAsync("Enter Password");
                });
             
				return isvalid;
			}
			if (string.IsNullOrEmpty(ConfirmPasswordText))
            {
                Device.BeginInvokeOnMainThread(async () =>
                {
                    await UserDialogs.Instance.AlertAsync("Enter Confirm Password");
                });
				return isvalid;
			}

			if (!Utilities.ValidatePassword(RegistrationData.Password))
			{
				ErrorMessage = MessageStringConstants.WeakPassword;
				return isvalid;
			}
			if (RegistrationData.Password != ConfirmPasswordText)
			{
				ErrorMessage = MessageStringConstants.PasswordMismatched;
				return isvalid;
			}
			if (!Utilities.ValidateUserFullName(RegistrationData.FirstName))
			{
				ErrorMessage = MessageStringConstants.EnterValidFirstName;
				return isvalid;
			}
			if (!Utilities.ValidateUserFullName(RegistrationData.LastName))
			{
				ErrorMessage = MessageStringConstants.EnterValidLastName;
				return isvalid;
			}

			if (!Utilities.ValidateMobileNumber(RegistrationData.MobileNumber))
			{
				ErrorMessage = MessageStringConstants.EnterValidMobileNumber;
				return isvalid;
			}

			if (!Utilities.ValidateEmailAddress(RegistrationData.EmailAddress))
			{
				ErrorMessage = MessageStringConstants.InvalidEmailAddress;
				return isvalid;
			}
			if (!string.IsNullOrEmpty(RegistrationData.AadharNumber) && !Utilities.ValidateAadhaarNumber(RegistrationData.AadharNumber))
			{

                Device.BeginInvokeOnMainThread(async () =>
                {
                    await UserDialogs.Instance.AlertAsync("Enter Valid Aadhaar Number");
                });
                

                return isvalid;
			}

			isvalid = true;
			if (isvalid)
			{

				RegistrationData.CollegeID = AppPreferences.Collegeviseregistraiton.CollegeID;
			}
			return isvalid;
		}
		#endregion

		public string confirmPassword;
		public string ConfirmPasswordText
		{
			get { return confirmPassword; }
			set { confirmPassword = value; OnPropertyChanged(); }
		}


		public Color _DOBTextColor;
		public Color DOBTextColor
		{
			get { return _DOBTextColor; }
			set { _DOBTextColor = value; OnPropertyChanged(); }
		}


		public Boolean _DOBisVisible;
		public Boolean DOBisVisible
		{
			get { return _DOBisVisible; }
			set { _DOBisVisible = value; OnPropertyChanged(); }
		}





		public Boolean _DatePickerIsVisible;
		public Boolean DatePickerIsVisible
		{
			get { return _DatePickerIsVisible; }
			set { _DatePickerIsVisible = value; OnPropertyChanged(); }

		}



	}
}
