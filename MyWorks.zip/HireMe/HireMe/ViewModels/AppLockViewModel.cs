﻿using GalaSoft.MvvmLight.Command;
using HireMe.Helpers;
using MvvmHelpers;
using System;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels
{
    public class AppLockViewModel : BaseViewModel
    {
        #region Initial Declarations
        public ICommand OnApplockPageCommand { get; set; }
        public ICommand EntryPasscodeTextChangedCommand { get; set; }
        public string _pageTitle;
        private string _tempPasscode;
        private bool aflag;
        private string _changePwd;
        private string _navigationPage;
        INavigation NavigationService;
        #endregion

        #region Constructors
        public AppLockViewModel(INavigation objNav)
        {
            aflag = false;
            NavigationService = objNav;
            OnApplockPageCommand = new RelayCommand<string>(DoLockInput);
            EntryPasscodeTextChangedCommand = new Command(OnTextChangedEntryPasscode);
        }
        public AppLockViewModel(string pageOperation, INavigation objNav)
        {
            NavigationService = objNav;
            _pageTitle = pageOperation;
            OnApplockPageCommand = new RelayCommand<string>(DoLockInput);
            EntryPasscodeTextChangedCommand = new Command(OnTextChangedEntryPasscode);
            aflag = false;
            InputCode1 = (string)Application.Current.Resources["EmptyValue"];
            InputCode2 = (string)Application.Current.Resources["EmptyValue"];
            InputCode3 = (string)Application.Current.Resources["EmptyValue"];
            InputCode4 = (string)Application.Current.Resources["EmptyValue"];

            if (_pageTitle == "Check Passcode")
            {
                IsVisibleCancelButton = false;
            }
            else
            {
                IsVisibleCancelButton = true;
            }
            if (_pageTitle == "Set Passcode")
            {

                PageTitle = "Enter Your New Passcode";
            }
            else
            {

                PageTitle = "Enter Your Passcode";
            }
        }
        public AppLockViewModel(string pageOperation, string navigationPage, INavigation objNav)
        {
            
            NavigationService = objNav;
            _navigationPage = navigationPage;
            aflag = false;
            OnApplockPageCommand = new RelayCommand<string>(DoLockInput);
            EntryPasscodeTextChangedCommand = new Command(OnTextChangedEntryPasscode);
            InputCode1 = (string)Application.Current.Resources["EmptyValue"];
            InputCode2 = (string)Application.Current.Resources["EmptyValue"];
            InputCode3 = (string)Application.Current.Resources["EmptyValue"];
            InputCode4 = (string)Application.Current.Resources["EmptyValue"];
            _pageTitle = pageOperation;
            if (_pageTitle == "Check Passcode")
            {
                IsVisibleCancelButton = false;
            }
            if (pageOperation == "Check Passcode")
                PageTitle = "Enter Your Passcode";


        }
        #endregion

        #region EntryPassCode OnTextChanged
        private async void OnTextChangedEntryPasscode(object sender)
        {
            #region tEXT cHANGE eVENT
            try
            {
                String val = string.Empty;
                Entry entry = sender as Entry;
                if (entry.Text != null)
                {
                    if (val.Length > 4)//If it is more than your character restriction
                    {
                        val = val.Remove(val.Length - 1);// Remove Last character 
                        entry.Text = val; //Set the Old value
                    }
                    val = entry.Text;
                    //Get Current Text
                    #region  Check Label Status
                    if (val.Length == 1)
                    {
                        ErrorMessage = string.Empty;
                        InputCode1 = (string)Application.Current.Resources["FillValue"];
                        InputCode2 = (string)Application.Current.Resources["EmptyValue"];
                        InputCode3 = (string)Application.Current.Resources["EmptyValue"];
                        InputCode4 = (string)Application.Current.Resources["EmptyValue"];

                    }
                    else if (val.Length == 2)
                    {
                        InputCode1 = (string)Application.Current.Resources["FillValue"];
                        InputCode2 = (string)Application.Current.Resources["FillValue"];
                        InputCode3 = (string)Application.Current.Resources["EmptyValue"];
                        InputCode4 = (string)Application.Current.Resources["EmptyValue"];

                    }
                    else if (val.Length == 3)
                    {
                        InputCode1 = (string)Application.Current.Resources["FillValue"];
                        InputCode2 = (string)Application.Current.Resources["FillValue"];
                        InputCode3 = (string)Application.Current.Resources["FillValue"];
                        InputCode4 = (string)Application.Current.Resources["EmptyValue"];

                    }
                    else if (val.Length == 4)
                    {
                        InputCode1 = (string)Application.Current.Resources["FillValue"];
                        InputCode2 = (string)Application.Current.Resources["FillValue"];
                        InputCode3 = (string)Application.Current.Resources["FillValue"];
                        InputCode4 = (string)Application.Current.Resources["FillValue"];

                    }
                    else if (val.Length == 0)
                    {
                        InputCode1 = (string)Application.Current.Resources["EmptyValue"];
                        InputCode2 = (string)Application.Current.Resources["EmptyValue"];
                        InputCode3 = (string)Application.Current.Resources["EmptyValue"];
                        InputCode4 = (string)Application.Current.Resources["EmptyValue"];
                    }
                    #endregion


                    if (val.Length == 4)
                    {
                       
                        await Task.Delay(50);
                        if (_pageTitle == "Set Passcode" && !aflag)
                        {
                            aflag = true;

                            _tempPasscode = val;
                            PageTitle = "Confirm Passcode";
                            InputCode1 = (string)Application.Current.Resources["EmptyValue"];
                            InputCode2 = (string)Application.Current.Resources["EmptyValue"];
                            InputCode3 = (string)Application.Current.Resources["EmptyValue"];
                            InputCode4 = (string)Application.Current.Resources["EmptyValue"];
                            EntryPassCode = "";

                        }
                        else if (_pageTitle == "Set Passcode" && aflag)
                        {
                            if (_tempPasscode == val)
                            {
                                //UserDialogs.Instance.Toast("Passcode Set Successfully");

                                AppPreferences.IsPasscodeValue = val.ToString();
                                AppPreferences.IsPasscode = true;
                                await NavigationService.PopModalAsync();
                            }
                            else
                            {
                                ErrorMessage = "Passcode Mismatch";
                                EntryPassCode = "";
                            }
                        }
                        else if (_pageTitle == "Check Passcode")
                        {
                            if (AppPreferences.IsPasscodeValue == val)
                            {
                                InputCode1 = (string)Application.Current.Resources["EmptyValue"];
                                InputCode2 = (string)Application.Current.Resources["EmptyValue"];
                                InputCode3 = (string)Application.Current.Resources["EmptyValue"];
                                InputCode4 = (string)Application.Current.Resources["EmptyValue"];
                                PageTitle = "Enter Your Passcode";
                                EntryPassCode = "";
                                GetNavigateOpeartion();

                            }
                            else
                            {
                                ErrorMessage = "Invalid Passcode";
                                // DisplayAlert("", "Passcode Wrong", "OK");
                                // labelPasscodeFailureStatus.Text = "Wrong Passcode";
                                EntryPassCode = "";
                            }
                        }
                        else if (_pageTitle == "Change Passcode")
                        {
                            if (AppPreferences.IsPasscodeValue == val && _changePwd == null)
                            {
                                EntryPassCode = "";
                                InputCode1 = (string)Application.Current.Resources["EmptyValue"];
                                InputCode2 = (string)Application.Current.Resources["EmptyValue"];
                                InputCode3 = (string)Application.Current.Resources["EmptyValue"];
                                InputCode4 = (string)Application.Current.Resources["EmptyValue"];
                                PageTitle = "Enter Your New Passcode";
                                _changePwd = "Set New Passcode";
                            }
                            else if (_changePwd == "Set New Passcode" && !aflag)
                            {
                                aflag = true;

                                _tempPasscode = val;
                                InputCode1 = (string)Application.Current.Resources["EmptyValue"];
                                InputCode2 = (string)Application.Current.Resources["EmptyValue"];
                                InputCode3 = (string)Application.Current.Resources["EmptyValue"];
                                InputCode4 = (string)Application.Current.Resources["EmptyValue"];
                                PageTitle = "Confirm Passcode";
                                _changePwd = "Confirm Passcode";
                                EntryPassCode = "";

                            }
                            else if (_changePwd == "Confirm Passcode" && aflag)
                            {
                                if (_tempPasscode == val)
                                {
                                    //DisplayAlert("", "Passcode setted", "OK");

                                    AppPreferences.IsPasscodeValue = val;
                                    AppPreferences.IsPasscode = true;
                                    await NavigationService.PopModalAsync();

                                }
                                else
                                {
                                    ErrorMessage = "Passcode Mismatched";
                                    EntryPassCode = "";
                                }

                            }
                            else
                            {
                                ErrorMessage = "Invalid Passcode";
                                // DisplayAlert("", "Passcode Wrong", "OK");
                                // labelPasscodeFailureStatus.Text = "Wrong Passcode";
                                EntryPassCode = "";
                            }
                        }
                        else if (_pageTitle == "Remove Passcode")
                        {
                            if (AppPreferences.IsPasscodeValue == val)
                            {
                                //UserDialogs.Instance.Toast("Invalid Passcode");
                                PageTitle = "Enter Your Passcode";
                                EntryPassCode = "";
                                AppPreferences.IsPasscodeValue = "";
                                AppPreferences.IsPasscode = false;
                                await NavigationService.PopModalAsync();
                            }
                            else
                            {
                                ErrorMessage = "Invalid Passcode";
                                //  labelPasscodeFailureStatus.Text = "Wrong Passcode";
                                EntryPassCode = "";
                            }
                        }
                    }


                }
            }
            catch (Exception ex)
            {
                SendErrorMessageToServer(ex, "AppLockViewModel.OnTextChangedEntryPasscode");
            }
            #endregion

        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion





        #region Tap Event
        private Command<string> tapCommand;
        public Command<string> TapCommand
        {
            get { return tapCommand ?? (tapCommand = new Command<string>( arg =>  OnTappedCommand(arg))); }
        }
        public void OnTappedCommand(object sender)
        {
            EntryPassCode += sender.ToString();
            IsEnabledClear = true;
            EntryPassCode = EntryPassCode;
        }
        #endregion

        #region AppLockScreen Commands
        private void DoLockInput(string sender)
        {
            switch (sender)
            {
                case "DoClear":
                    if (EntryPassCode != null)
                    {
                        string txt = EntryPassCode;
                        if (txt.Length > 1)
                            EntryPassCode = txt.Substring(0, txt.Length - 1);
                        else
                        {
                            EntryPassCode = string.Empty;
                        }
                        IsEnabledClear = EntryPassCode.Length > 0;
                        EntryPassCode = EntryPassCode;
                    }
                    else
                    {
                        EntryPassCode = string.Empty;
                        InputCode1 = (string)Application.Current.Resources["EmptyValue"];
                        InputCode2 = (string)Application.Current.Resources["EmptyValue"];
                        InputCode3 = (string)Application.Current.Resources["EmptyValue"];
                        InputCode4 = (string)Application.Current.Resources["EmptyValue"];
                    }
                    break;
                case "DoCancel":
                    NavigationService.PopModalAsync();
                    break;
          
            }

        }
        #endregion

        #region Navigation Operation
        public void GetNavigateOpeartion()
        {
            if (_navigationPage == "Dashboard")
            {
                Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                return;
            }
            else if (_navigationPage == "VideoProfilePage")
            {
                Application.Current.MainPage = new NavigationPage(new VideoProfilePage(true));
                return;
            }
            else if (_navigationPage == "SeekerPersonalAndEducationPage")
            {
                Application.Current.MainPage = new NavigationPage(new SeekerPersonalAndEducationPage(true));
                return;
            }
        }
        #endregion

        #region Binding Properties
        private string _pageTitle1;
        public string PageTitle
        {
            get { return _pageTitle1; }
            set { _pageTitle1 = value; OnPropertyChanged(); }
        }
        private string _entryPassCode;
        public string EntryPassCode
        {
            get { return _entryPassCode; }
            set { _entryPassCode = value; OnPropertyChanged(); }
        }
        private string _inputCode1;
        public string InputCode1
        {
            get { return _inputCode1; }
            set { _inputCode1 = value; OnPropertyChanged(); }
        }
        private string _inputCode2;
        public string InputCode2
        {
            get { return _inputCode2; }
            set { _inputCode2 = value; OnPropertyChanged(); }
        }
        private string _inputCode3;
        public string InputCode3
        {
            get { return _inputCode3; }
            set { _inputCode3 = value; OnPropertyChanged(); }
        }
        private string _inputCode4;
        public string InputCode4
        {
            get { return _inputCode4; }
            set { _inputCode4 = value; OnPropertyChanged(); }
        }
        private string _errorMessage;
        private string pageOperation;

        public string ErrorMessage
        {
            get { return _errorMessage; }
            set { _errorMessage = value; OnPropertyChanged(); }
        }
        private bool _isVisibleCancelButton;

        public bool IsVisibleCancelButton
        {
            get { return _isVisibleCancelButton; }
            set { _isVisibleCancelButton = value; OnPropertyChanged(); }
        }
        private bool _isEnabledClear;
        public bool IsEnabledClear
        {
            get { return _isEnabledClear; }
            set { _isEnabledClear = value; OnPropertyChanged(); }
        }





        #endregion
    }
}
