﻿using Acr.UserDialogs;
using HireMe.Helpers;
using MvvmHelpers;
using Plugin.Connectivity;
using System;

namespace HireMe.ViewModels
{
    public class TermsOfUseViewModel : BaseViewModel
    {
        public TermsOfUseViewModel()
        {
            AppPreferences.Is_HireMee_PRO_User = false;
            LoadDefault();
        }


        private async void LoadDefault()
        {
            try
            {
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {
                    TermsofUse = APIData.TermsAndConditionURL;
                }
                else
                {
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "TermsOfUseViewModel.LoadDefault");
            }
        }



        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion





        private string _termsofuse;

        public string TermsofUse
        {
            get { return _termsofuse; }
            set { _termsofuse = value; OnPropertyChanged(); }
        }
    }
}
