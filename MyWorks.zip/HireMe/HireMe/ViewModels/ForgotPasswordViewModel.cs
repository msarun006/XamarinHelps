﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using HireMe.Helpers;
using HireMe.Models;
using HireMe.Views.JobSeeker;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels
{
    public class ForgotPasswordViewModel : BaseViewModel
    {
        public bool isClicked = true;
        private HttpCommonService _commonservice { get; set; }
        public ICommand ForgotServiceCommand { get; set; }
        public ForgotPasswordRequestData ForgotPasswordRequestData { get; set; }
        public ForgotPasswordFullResponse ForgotPasswordFullResponse { get; set; }
        public string ErrorMessage { get; set; }

        public ForgotPasswordViewModel(INavigation navigation)
        {
            AppPreferences.Is_HireMee_PRO_User = false;
            this.navigation = navigation;
            _commonservice = new HttpCommonService();
            ForgotServiceCommand = new RelayCommand(DoForgot);
            ForgotPasswordRequestData = new ForgotPasswordRequestData();
            ForgotPasswordFullResponse = new ForgotPasswordFullResponse();

            OnVerificationClicked = new Command(VerificationClicked);
            BindingEmail = (string)Application.Current.Resources["CircleSelected"];
            BindingMobileNumber = (string)Application.Current.Resources["CircleUnSelected"];
            VerificationViaIcon = (string)Application.Current.Resources["EmailSign"];
            InputReqText = MessageStringConstants.EnterRegisterEmailAlert;
            OTPReceiveMessage = MessageStringConstants.OTPSendMessageEmail;
            InputPlaceholderText = "Email";
            keyboardType = Keyboard.Email;
            UserInputMethod = "Email";


        }

        void VerificationClicked(object obj)
        {
            InputText = string.Empty;
            IsEmailvisible = false;
            if (obj.ToString() == "Mobile")
            {
                BindingEmail = (string)Application.Current.Resources["CircleSelected"];
                BindingMobileNumber = (string)Application.Current.Resources["CircleUnSelected"];
                VerificationType = "Mobile";

                VerificationViaIcon = (string)Application.Current.Resources["EmailSign"];
                InputReqText = MessageStringConstants.EnterRegisterEmailAlert;
                OTPReceiveMessage = MessageStringConstants.OTPSendMessageEmail;
                InputPlaceholderText = "Email";
                UserInputMethod = "Email";
                keyboardType = Keyboard.Email;
            }
            else if (obj.ToString() == "Email")
            {
                BindingMobileNumber = (string)Application.Current.Resources["CircleSelected"];
                BindingEmail = (string)Application.Current.Resources["CircleUnSelected"];
                VerificationType = "Email";

                VerificationViaIcon = (string)Application.Current.Resources["PhoneSign"];
                InputReqText = MessageStringConstants.EnterRegisterEmailAlert;
                OTPReceiveMessage = MessageStringConstants.OTPSendMessageMobile;
                InputPlaceholderText = "Mobile Number";
                UserInputMethod = "Mobile";
                keyboardType = Keyboard.Numeric;
            }

        }

        #region user Verification types
        public string _verificationType;
        public string VerificationType
        {
            get
            {
                return _verificationType;
            }
            set
            {
                if (value != null)
                {
                    if (value.ToLower() == "Mobile")
                    {
                        _verificationType = "Mobile";
                        BindingMobileNumber = (string)Application.Current.Resources["CircleSelected"];
                        BindingEmail = (string)Application.Current.Resources["CircleUnSelected"];
                    }
                    else if (value.ToLower() == "Email")
                    {
                        BindingEmail = (string)Application.Current.Resources["CircleSelected"];
                        BindingMobileNumber = (string)Application.Current.Resources["CircleUnSelected"];
                        _verificationType = "Email";

                    }
                }
                OnPropertyChanged();
            }
        }
        #endregion



        #region private property

        #region Sign text
        private string _rightsign;
        public string RightSign
        {
            get { return _rightsign; }
            set { _rightsign = value; OnPropertyChanged(); }
        }

        private string _emailaddress;
        public string EmailAddress
        {
            get { return _emailaddress; }
            set { _emailaddress = value; OnPropertyChanged(); }
        }

        #endregion


        #region Signtext Visibility
        private bool _isemailvisible;
        public bool IsEmailvisible
        {
            get { return _isemailvisible; }
            set { _isemailvisible = value; OnPropertyChanged(); }
        }

        private string _InputText;

        public string InputText
        {
            get { return _InputText; }
            set { _InputText = value; OnPropertyChanged(); }
        }

        #endregion


        private string _mobileNumber;

        public string MobileNumber
        {
            get { return _mobileNumber; }
            set { _mobileNumber = value; OnPropertyChanged(); }
        }




        #region Signtext Color properites

        private Color _emailtextcolor;
        public Color EmailTextcolor
        {
            get { return _emailtextcolor; }
            set { _emailtextcolor = value; OnPropertyChanged(); }
        }

        #endregion

        #endregion


        private Command<string> tapCommand;
        private INavigation navigation;

        public Command<string> TapCommand
        {
            get { return tapCommand ?? (tapCommand = new Command<string>(arg => OnTappedCommand(arg))); }
        }



        private void OnTappedCommand(string sender)
        {
            switch (sender)
            {
                case "EmailSign":

                    if (UserInputMethod.Equals("Email"))
                    {
                        var textEmailSign = InputText;
                        if (textEmailSign != null) textEmailSign = textEmailSign.Trim();
                        if (string.IsNullOrEmpty(textEmailSign))
                        {
                            EmailAddress = (string)Application.Current.Resources["WrongSign"];
                            IsEmailvisible = true;
                            EmailTextcolor = Color.Red;
                        }
                        else if (!Utilities.ValidateEmailAddress(InputText))
                        {
                            EmailAddress = (string)Application.Current.Resources["WrongSign"];
                            IsEmailvisible = true;
                            EmailTextcolor = Color.Red;
                        }

                        else
                        {
                            EmailAddress = (string)Application.Current.Resources["RightSign"];
                            IsEmailvisible = true;
                            EmailTextcolor = Color.Green;

                        }
                    }
                    else if (UserInputMethod.Equals("Mobile"))
                    {
                        var textEmailSign = InputText;
                        if (textEmailSign != null) textEmailSign = textEmailSign.Trim();
                        if (string.IsNullOrEmpty(textEmailSign))
                        {
                            EmailAddress = (string)Application.Current.Resources["WrongSign"];
                            IsEmailvisible = true;
                            EmailTextcolor = Color.Red;
                        }
                        else if (!Utilities.ValidateMobileNumber(InputText))
                        {
                            EmailAddress = (string)Application.Current.Resources["WrongSign"];
                            IsEmailvisible = true;
                            EmailTextcolor = Color.Red;
                        }

                        else
                        {
                            EmailAddress = (string)Application.Current.Resources["RightSign"];
                            IsEmailvisible = true;
                            EmailTextcolor = Color.Green;

                        }

                    }

                    break;
            }
        }

        public async void DoForgot()
        {
            if (isClicked)
            {
                isClicked = false;

                if (!IsValidData())
                {
                    if (!string.IsNullOrEmpty(ErrorMessage))
                    {
                        await UserDialogs.Instance.AlertAsync(ErrorMessage);
                    }
                }
                else
                {
                    try
                    {
                        UserDialogs.Instance.ShowLoading();
                        bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                        if (isNetworkAvailable)
                        {
                            AppPreferences.ForgotPasswordEmailAddress = string.Empty;
                            var result = await _commonservice.PostAsync<ForgotPasswordFullResponse, ForgotPasswordRequestData>(APIData.API_BASE_URL + APIMethods.ForgotPassword_V7, ForgotPasswordRequestData);
                            if (result != null)
                            {

                                if (result.code == "200")
                                {
                                    UserDialogs.Instance.HideLoading();

                                    IsEmailvisible = false;
                                    //if (UserInputMethod.Equals("Email"))
                                    //{
                                    //    //AppPreferences.EmailAddress = InputText;
                                    //    //await UserDialogs.Instance.AlertAsync(result.message);
                                    //    //InputText = string.Empty;

                                    //}
                                    //else if (UserInputMethod.Equals("Mobile"))
                                    //{
                                    //    //  AppPreferences.ForgotPasswordValues = result.response;

                                    //}

                                    UserDialogs.Instance.Toast(result.message);
                                    AppPreferences.ForgotPasswordNewValues = result.responseText;
                                    AppPreferences.ForgotPasswordEmailAddress = ForgotPasswordRequestData.key_param;
                                    await navigation.PushAsync(new OTPVerifyPage("ForgotMobileOTP"));
                                }
                                else
                                {
                                    UserDialogs.Instance.HideLoading();
                                    await UserDialogs.Instance.AlertAsync(result.message);
                                }
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                        }
                    }
                    catch (Exception ex)
                    {
                        UserDialogs.Instance.HideLoading();
                        Debug.WriteLine(ex.Message);
                        SendErrorMessageToServer(ex, "ForgotPasswordViewModel.DoForgot");
                    }
                }
            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });
        }


        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion



        public Command OnVerificationClicked
        {
            get;
            set;
        }

        private string _MySelectedUserInput;

        public string UserInputMethod
        {
            get { return _MySelectedUserInput; }
            set
            {
                _MySelectedUserInput = value; OnPropertyChanged();
            }
        }



        private string _placeholderText;

        public string InputPlaceholderText
        {
            get { return _placeholderText; }
            set { _placeholderText = value; OnPropertyChanged(); }
        }

        private Keyboard _keyboardType;

        public Keyboard keyboardType
        {
            get { return _keyboardType; }
            set { _keyboardType = value; OnPropertyChanged(); }
        }


        private string _verificationIcon;

        public string VerificationViaIcon
        {
            get { return _verificationIcon; }
            set { _verificationIcon = value; OnPropertyChanged(); }
        }



        private string _otpReceiveMessage;

        public string OTPReceiveMessage
        {
            get { return _otpReceiveMessage; }
            set { _otpReceiveMessage = value; OnPropertyChanged(); }
        }


        private string _inputReqText;

        public string InputReqText
        {
            get { return _inputReqText; }
            set { _inputReqText = value; OnPropertyChanged(); }
        }


        private string bindingMobileNumber;
        public string BindingMobileNumber
        {
            get { return bindingMobileNumber; }
            set
            {
                bindingMobileNumber = value;
                OnPropertyChanged();
            }
        }



        private string bindingEmailID;
        public string BindingEmail
        {
            get { return bindingEmailID; }
            set
            {
                bindingEmailID = value;
                OnPropertyChanged();
            }
        }


        #region ValidateFields
        private bool IsValidData()
        {
            ErrorMessage = string.Empty;
            bool isvalid = false;


            var passingType = UserInputMethod.ToString();

            if (string.IsNullOrEmpty(InputText) && UserInputMethod == "Email")
            {
                ErrorMessage = MessageStringConstants.EnterInputEmail;
                return isvalid;
            }
            else if (string.IsNullOrEmpty(InputText) && UserInputMethod == "Mobile")
            {
                ErrorMessage = MessageStringConstants.EnterInputMobile;
                return isvalid;
            }
            else
            {
                if (!string.IsNullOrEmpty(passingType) && passingType.Equals("Mobile"))
                {

                    if (!Utilities.ValidateMobileNumber(InputText))
                    {
                        ErrorMessage = MessageStringConstants.EnterValidMobileNumber;
                        return isvalid;
                    }

                    else
                    {
                        // ErrorMessage = MessageStringConstants.EnterValidMobileNumber;
                        isvalid = true;
                    }
                }
                else if (!string.IsNullOrEmpty(passingType) && passingType.Equals("Email"))
                {
                    if (!Utilities.ValidateEmailAddress(InputText))
                    {
                        ErrorMessage = MessageStringConstants.InvalidEmailAddress;
                        return isvalid;
                    }
                    else
                    {
                        //  ErrorMessage = MessageStringConstants.InvalidEmailAddress;
                        isvalid = true;
                    }
                }

            }





            if (isvalid)
            {
                if (passingType.Equals("Mobile"))
                {
                    ForgotPasswordRequestData.key_param = InputText;
                    ForgotPasswordRequestData.type = 7;
                }
                else
                {
                    ForgotPasswordRequestData.key_param = InputText.ToLower();
                    ForgotPasswordRequestData.type = 8;
                    // AppPreferences.ForgotPassUserInput = InputText.ToLower();
                }
            }
            return isvalid;
        }
        #endregion

    }
}
