﻿using HireMe.UI;
using MvvmHelpers;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels
{
    public class PlayVideoViewModel : BaseViewModel
    {
        private string _candidateID;
        private int _resourceType;
        public ICommand OnblockVideoCommand { get; set; }
        INavigation NavigationService;
        public PlayVideoViewModel(string videoFilePath, INavigation objNav)
        {
            IsVisibleBlockButton = true;
            NavigationService = objNav;
            if (!string.IsNullOrEmpty(videoFilePath))
            {
                SetPlayVideo(videoFilePath);
            }
            if (UserType.JobSeeker == AppSessionData.ActiveToken.UserType)
            {
                IsVisibleBlockButton = false;
            }
            OnblockVideoCommand = new Command(DoBlockVideo);

        }
        public PlayVideoViewModel(string videoFilePath, string candidateID, int resocureType, INavigation objNav)
        {
            IsVisibleBlockButton = true;
            NavigationService = objNav;
            _candidateID = candidateID;
            _resourceType = resocureType;
            if (!string.IsNullOrEmpty(videoFilePath))
            {
                SetPlayVideo(videoFilePath);
            }
            if (UserType.JobSeeker == AppSessionData.ActiveToken.UserType)
            {
                IsVisibleBlockButton = false;
            }
            OnblockVideoCommand = new Command(DoBlockVideo);

        }
        private void SetPlayVideo(string videoFilePath)
        {
            VideoFileSource = videoFilePath;
        }

        private void DoBlockVideo(object obj)
        {
            if (UserType.Recruiter == AppSessionData.ActiveToken.UserType)
            {
                var move = new BlockVideo(_candidateID, _resourceType);
                NavigationService.PushAsync(move);
            }
        }

        #region Binding Properties

        private string _filesource;

        public string VideoFileSource
        {
            get { return _filesource; }
            set { _filesource = value; OnPropertyChanged(); }
        }
        private bool _isVisibleBlockButton;

        public bool IsVisibleBlockButton
        {
            get { return _isVisibleBlockButton; }
            set { _isVisibleBlockButton = value; OnPropertyChanged(); }
        }


        #endregion
    }
}
