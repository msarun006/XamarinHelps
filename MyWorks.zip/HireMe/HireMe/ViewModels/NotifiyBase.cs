﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace HireMe
{
    public abstract class NotifiyBase : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected void RaisePropertyChanged([CallerMemberName] string propertyname = null)
        {
            if(PropertyChanged != null && propertyname!= null)
            {
                var eventargs = new PropertyChangedEventArgs(propertyname);
                PropertyChanged(this, eventargs);
            }
        }
    }
}
