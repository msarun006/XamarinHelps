﻿using System;
using System.Windows.Input;
using MvvmHelpers;
using Xamarin.Forms;

namespace HireMe
{
    public class AppUpdatePopupDialogViewModel : BaseViewModel
    {

        public ICommand OnUpdateCommand { get; set; }

        public AppUpdatePopupDialogViewModel(String message)
        {
            OnUpdateCommand = new Command(AppUpdate);
            Message = message;
        }

        private void AppUpdate(object obj)
        {
            if(obj.ToString() == "update")
            {
                //await CrossLatestVersion.Current.OpenAppInStore("com.mobility.hiremeeapp");
                DependencyService.Get<IMyDevice>().OpnePlayStore();
            }
        }



        private String message;
        public String Message{

            get
            {
                return message;
            }

            set
            {
                message = value;
            }
        }

    }
}
