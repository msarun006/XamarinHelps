﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.Models;
using HireMe.Models.JobSeeker;
using HireMe.Models.Recruiter;
using MvvmHelpers;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace HireMe
{
    public class MultipleSkillsSelectionViewModel : BaseViewModel
    {
        #region variable declaration
        ObservableCollection<Skill> skill_list;
        public bool isClicked = true;
        private HttpCommonService _commonservice { get; set; }
        public Command DoneClicked { get; set; }
        private List<Skill> SelectionSkills;
        private List<Skill> SkillsList;
        INavigation Navigation;
        private string PageName;
        private string _skillType;
        #endregion

        #region constroctor
        public MultipleSkillsSelectionViewModel(INavigation navigation, string pageName, List<Skill> skills, string skillType)
        {
            _skillType = skillType;
            Navigation = navigation;
            PageName = pageName;
            SelectionSkills = skills;
            _commonservice = new HttpCommonService();
            SkillsList = new List<Skill>();

            DoneClicked = new Command(onDoneClicked);
            btnSendIsDestructive = false;

            if (AppSessionData.ActiveToken.UserType == UserType.JobSeeker && _skillType == "1")
            {
                if (AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.Others == "true")
                {
                    if (AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.skill_others != null)
                    {
                        IsVisibleAddOtherSkill = true;
                        OthersSkillName = AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.skill_others.skill_name;
                    }
                }
                else
                {
                    IsVisibleAddOtherSkill = false;
                    OthersSkillName = string.Empty;
                }
            }
            else
            {
                IsVisibleAddOtherSkill = false;
                OthersSkillName = string.Empty;
            }

            BindSkillData();
        }
        #endregion

        #region OnSearchClearCommand
        public Command OnSearchClearCommand => new Command(() =>
      {
          SearchText = string.Empty;
      });
        #endregion

        #region SearchText_TextChanged
        public async void SearchText_TextChanged()
        {
            var searchtext = SearchText;
            if (string.IsNullOrEmpty(searchtext))
            {
                if (SkillsList.Count > 0)
                {
                    ItemSource = SkillsList;
                    IsVisibleSearchbarCancelButton = false;
                }
                else
                {
                    IsVisibleSearchbarCancelButton = false;
                    await BindData();
                }
                return;
            }
            IsVisibleSearchbarCancelButton = true;
            var searchresults = SkillsList.FindAll((obj) => obj.SkillName.ToLower().Contains(searchtext.ToLower()));
            ItemSource = searchresults;
        }

        #endregion

        #region BindSkillData
        public async void BindSkillData()
        {
            await BindData();
        }

        async Task BindData()
        {
            SkillsList = new List<Skill>();

            if (skill_list == null)
            {
                try
                {
                    UserDialogs.Instance.ShowLoading();
                    BaseRequestDTO objBaseRequestDTO = new BaseRequestDTO();
                    var responseobj = await _commonservice.PostAsync<DependantSkillResponseData, BaseRequestDTO>(APIData.API_BASE_URL + APIMethods.MultipleSkillSelection, objBaseRequestDTO);
                    if (responseobj != null)
                    {
                        if (responseobj.code == "200" && responseobj.responseText != null)
                        {
                            SkillsList = responseobj.responseText.data;
                            isEnabledSearchBar = true;
                            skill_list = new ObservableCollection<Skill>(SkillsList);


                            if (_skillType != "1")
                            {
                                skill_list.Remove(new Skill() { ID = "Others" });
                            }

                            if (SelectionSkills != null && SelectionSkills.Count > 0)
                            {
                                if (skill_list.Count > 0 && SelectionSkills.Count > 0)
                                {
                                    foreach (var obj in skill_list)
                                    {
                                        obj.IsSelected = false;
                                        foreach (var selectionSkill in SelectionSkills)
                                        {
                                            if (obj.ID == selectionSkill.ID)
                                            {
                                                obj.IsSelected = selectionSkill.IsSelected;
                                            }
                                            if (AppSessionData.ActiveToken.UserType == UserType.JobSeeker && AppPreferences.LoadSeekerDashboardData != null && AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.skill_others != null && AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.Others == "true" && _skillType == "1") //_skillType=1 mean primary skill, _skillType=2 mean secondary skill, 
                                            {
                                                if (obj.ID == "Others")
                                                {
                                                    obj.IsSelected = true;
                                                    IsVisibleAddOtherSkill = true;
                                                }
                                                else
                                                {
                                                    IsVisibleAddOtherSkill = false;
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            ItemSource = SkillsList;
                            UserDialogs.Instance.HideLoading();
                        }
                        else if (responseobj.code == "199")
                        {
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.SessionExpiered);
                            Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                            return;
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            isEnabledSearchBar = false;
                            await UserDialogs.Instance.AlertAsync(responseobj.message);
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        isEnabledSearchBar = false;
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                    UserDialogs.Instance.HideLoading();
                    SendErrorMessageToServer(ex, "MultipleSkillSelectionViewModel.BindData");
                }
            }
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        #region Done Clicked
        public async void onDoneClicked()
        {
            if (isClicked)
            {
                isClicked = false;
                try
                {
                    btnSendIsDestructive = true;
                    Skill objSelectionBO = new Skill();
                    List<Skill> selectedSkillsList = new List<Skill>();

                    if (skill_list != null)
                    {
                        foreach (var item in skill_list)
                        {
                            objSelectionBO.ID = item.ID;
                            objSelectionBO.SkillName = item.SkillName;
                            objSelectionBO.IsSelected = item.IsSelected;
                            if (item.IsSelected)
                            {
                                selectedSkillsList.Add(item);
                            }
                        }
                    }
                    updateSelectedSkill(selectedSkillsList);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                    SendErrorMessageToServer(ex, "MultipleSkillSelectionViewModel.onDoneClicked");
                }
            }
            await Task.Run(async () =>
            {
                await Task.Delay(1000);
                isClicked = true;
            });
        }
        #endregion

        #region updateSelectedSkill
        private async void updateSelectedSkill(List<Skill> selectedSkillsList)
        {
            try
            {
                string skillname = string.Empty;
                string skillid = string.Empty;
                int skillscount = (selectedSkillsList == null ? 0 : selectedSkillsList.Count);
                int counter = 0;

                if (AppSessionData.ActiveToken.UserType == UserType.JobSeeker)
                {
                    if (IsVisibleAddOtherSkill == true && (string.IsNullOrEmpty(OthersSkillName) || string.IsNullOrWhiteSpace(OthersSkillName)))
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterOthersSkill);
                    }
                    else if (skillscount == 0 && _skillType == "1")
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectSkill);
                    }
                    else
                    {

                        foreach (var skill in selectedSkillsList)
                        {
                            counter++;
                            skillname += skill.SkillName;
                            skillid += skill.ID;
                            if (counter < skillscount)
                            {
                                skillname += ", ";
                                skillid += ",";
                            }
                        }
                        if (counter == 0)
                        {
                            Skill = "Select Skill";
                        }
                        else
                        {
                            Skill = skillid;
                        }


                        var request = new SkillUpdateRequest();
                        //request.HiremeeID = AppPreferences.HireMeeID;
                        //request.Token = AppPreferences.ActiveToken.Token;
                        if (Skill != "Select Skill")
                        {
                            request.SkillID = Skill;
                            request.Others_Skill = OthersSkillName;
                            request.Other_SkillID = "";
                            if (!string.IsNullOrEmpty(OthersSkillName))
                            {
                                request.Others_Skill = OthersSkillName;
                                if (AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.skill_others == null)
                                {
                                    request.Other_SkillID = string.Empty;
                                }
                                else
                                {
                                    if (AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.skill_others.temp_skill_id == null)
                                    {
                                        request.Other_SkillID = string.Empty;
                                    }
                                    else
                                    {
                                        request.Other_SkillID = AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.skill_others.temp_skill_id ?? string.Empty;
                                    }
                                }
                            }
                        }
                        else
                        {
                            request.SkillID = "";
                        }

                        #region Jobseeker skill update API Calls

                        try
                        {
                            UserDialogs.Instance.ShowLoading();
                            request.SkillType = _skillType;
                            var statusResult = await _commonservice.PostAsync<EducaionalDetailsResponseData, SkillUpdateRequest>(APIData.API_BASE_URL + APIMethods.UpdateSkillAndJObLocation, request);
                            if (statusResult != null)
                            {
                                if (statusResult.code == "200")
                                {
                                    //SkillOthers obj = new SkillOthers();
                                    //if (!string.IsNullOrEmpty(OthersSkillName))
                                    //{
                                    //    obj.skill_name = OthersSkillName;
                                    //    obj.temp_skill_id = AppPreferences.LoadSeekerDashboardData.EducationalDetailsResponseData.skill_others.temp_skill_id;
                                    //    AppSessionData.OthersSkill = obj;
                                    //}
                                    //await UserDialogs.Instance.AlertAsync(statusResult.Message);

                                    UserDialogs.Instance.HideLoading();
                                    if (PageName == "SeekerPersonalandEducational")
                                    {
                                        if (_skillType == "1")
                                        {
                                            MessagingCenter.Send<MultipleSkillsSelectionViewModel, List<Skill>>(this, "UpdatePrimarySkill", selectedSkillsList);
                                        }
                                        else
                                        {
                                            MessagingCenter.Send<MultipleSkillsSelectionViewModel, List<Skill>>(this, "UpdateSecondarySkill", selectedSkillsList);
                                        }

                                    }
                                    await Navigation.PopAsync();

                                }
                                else if (statusResult.code == "199")
                                {
                                    UserDialogs.Instance.HideLoading();
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.SessionExpiered);
                                    Application.Current.MainPage = new NavigationPage(new LoginPageNew());
                                    return;
                                }
                                else
                                {
                                    UserDialogs.Instance.HideLoading();
                                    await UserDialogs.Instance.AlertAsync(statusResult.message);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            UserDialogs.Instance.HideLoading();
                            Debug.WriteLine(ex.Message);
                            SendErrorMessageToServer(ex, " JobSeeker => MultipleSkillSelectionViewModel.updateSelectedSkill");
                        }
                        #endregion
                    }
                }
                else
                {
                    IsVisibleAddOtherSkill = false;
                    if (PageName == "RecruiterSearchVideoProfile")
                    {
                        MessagingCenter.Send<MultipleSkillsSelectionViewModel, List<Skill>>(this, "RecruiterSearchVideoProfile", selectedSkillsList);
                    }
                    await Navigation.PopAsync();
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                await Navigation.PopAsync();
                SendErrorMessageToServer(ex, "MultipleSkillSelectionViewModel.updateSelectedSkill");
            }

        }
        #endregion

        #region Properties
        private bool _isSearchViewVisible;
        public bool isSearchViewVisible
        {
            get { return _isSearchViewVisible; }
            set { _isSearchViewVisible = value; OnPropertyChanged(); }
        }

        private bool _isVisibleSearchbarCancel;
        public bool IsVisibleSearchbarCancelButton
        {
            get { return _isVisibleSearchbarCancel; }
            set { _isVisibleSearchbarCancel = value; OnPropertyChanged(); }
        }
        public bool _isEnabledSearchBar;

        public bool isEnabledSearchBar
        {
            set { _isEnabledSearchBar = value; OnPropertyChanged(); }
            get { return _isEnabledSearchBar; }
        }
        public string _SearchText;
        public string SearchText
        {
            set
            {
                _SearchText = value;
                SearchText_TextChanged();
                OnPropertyChanged();
            }
            get { return _SearchText; }
        }

        private string _searchPlaceHolder;
        public string SearchPlaceHolderText
        {
            get { return _searchPlaceHolder; }
            set { _searchPlaceHolder = value; OnPropertyChanged(); }
        }
        public Boolean _btnSendIsDestructive;
        public Boolean btnSendIsDestructive
        {
            get { return _btnSendIsDestructive; }
            set { _btnSendIsDestructive = value; OnPropertyChanged(); }
        }



        public List<Skill> _ItemSource;
        public List<Skill> ItemSource
        {
            get { return _ItemSource; }
            set { _ItemSource = value; OnPropertyChanged(); }
        }
        private string _OthersSkillName;
        public string OthersSkillName
        {
            get { return _OthersSkillName; }
            set { _OthersSkillName = value; OnPropertyChanged(); }
        }

        private string _skill;
        public string Skill
        {
            get { return _skill; }
            set
            {
                _skill = value;
                OnPropertyChanged();
            }
        }

        private bool _IsVisibleAddOtherSkill;
        public bool IsVisibleAddOtherSkill
        {
            get { return _IsVisibleAddOtherSkill; }
            set { _IsVisibleAddOtherSkill = value; OnPropertyChanged(); }
        }
        #endregion

        #region On_Toggle
        public async void On_Toggled(object sender, ToggledEventArgs e)
        {
            var selectedSkillItem = ((Switch)sender).BindingContext as Skill;
            try
            {
                if (selectedSkillItem != null)
                {
                    if (selectedSkillItem.ID == "Others" && selectedSkillItem.IsSelected)
                    {
                        IsVisibleAddOtherSkill = true;
                    }
                    else if (selectedSkillItem.ID == "Others" && selectedSkillItem.IsSelected == false)
                    {
                        OthersSkillName = string.Empty;
                        IsVisibleAddOtherSkill = false;
                    }
                    var skillscount = 0;
                    foreach (var skill in skill_list)
                    {
                        if (skill.IsSelected)
                            skillscount++;
                    }
                    if (skillscount > 10)
                    {
                        selectedSkillItem.IsSelected = false;
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectedMaximumSkill);
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "MultipleSkillSelectionViewModel.On_Toggled");
            }
        }
        #endregion
    }
}
