﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using HireMe.Helpers;
using HireMe.Models;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Threading.Tasks;
using System.Windows.Input;

namespace HireMe.ViewModels
{

    public class FeedbackViewModel : BaseViewModel
    {
        public ICommand FeedbackCommand { get; set; }
        private HttpCommonService _commonservice { get; set; }
        public FeedbackRequestData FeedbackRequestData { get; set; }
        public bool isClicked = true;
        public FeedbackViewModel()
        {
            FeedbackCommand = new RelayCommand<string>(DoFeedback);
            FeedbackRequestData = new FeedbackRequestData();
            _commonservice = new HttpCommonService();
            isClicked = true;
        }
        private string _feedbacksubject;

        public string FeedBackSubject
        {
            get { return _feedbacksubject; }
            set { _feedbacksubject = value; OnPropertyChanged(); }
        }

        private string _feedbackcontent;

        public string FeedBackContent
        {
            get { return _feedbackcontent; }
            set { _feedbackcontent = value; OnPropertyChanged(); }
        }

        private async void DoFeedback(string sender)
        {
            switch (sender)
            {
                case "OnFeedbackCommand":
                    if (isClicked)
                    {
                        isClicked = false;
                        if (string.IsNullOrEmpty(FeedBackSubject) || string.IsNullOrWhiteSpace(FeedBackSubject))
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterFeedbackSubject);
                        }
                        else if (string.IsNullOrEmpty(FeedBackContent) || string.IsNullOrWhiteSpace(FeedBackContent))
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.EnterFeedback);
                        }
                        else
                        {
                            try
                            {
                                UserDialogs.Instance.ShowLoading();
                                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                                if (isNetworkAvailable)
                                {
                                    var requestData = new FeedbackRequestData();
                                    requestData.HiremeeID = AppSessionData.ActiveToken.HireMeID;
                                    requestData.Token = AppSessionData.ActiveToken.Token;
                                    requestData.EmailAddress = AppSessionData.ActiveToken.EmailID;
                                    requestData.Subject = FeedBackSubject.Trim();
                                    requestData.Content = FeedBackContent.Trim();
                                    var feedbackResponse = await _commonservice.PostAsync<FeedbacksResponseData, FeedbackRequestData>(APIData.API_BASE_URL + APIMethods.FeedBack, requestData);
                                    UserDialogs.Instance.HideLoading();
                                    if (feedbackResponse != null)
                                    {
                                        if (feedbackResponse.code == "200")
                                        {
                                            UserDialogs.Instance.HideLoading();
                                            await UserDialogs.Instance.AlertAsync(feedbackResponse.message);
                                            FeedBackSubject = string.Empty;
                                            FeedBackContent = string.Empty;
                                        }
                                    }
                                }
                                else
                                {
                                    UserDialogs.Instance.HideLoading();
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                                }
                            }
                            catch (Exception ex)
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync("Your feedback was not submitted.Please try again.");
                                System.Diagnostics.Debug.WriteLine(ex.Message);
                                SendErrorMessageToServer(ex, "FeedbackViewModel.DoFeedback.OnFeedbackCommand");
                            }
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
            }
        }

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
