﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows.Input;
using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using MvvmHelpers;
using Xamarin.Forms;
using HireMe.Helpers;

namespace HireMe
{
    public class CandidateAssessmentDetailsViewModel : BaseViewModel
    {
        ObservableCollection<AssessmentReportResponseModel.Response> _candidateslist;
        AssessmentReportResponseModel.Response _objSearchDetails;
        public ICommand CandidateDetailsCommand { get; set; }

        public CandidateAssessmentDetailsViewModel(ObservableCollection<AssessmentReportResponseModel.Response> candidateslist,AssessmentReportResponseModel.Response objSearchDetails)
        {
            _candidateslist = candidateslist;
            _objSearchDetails = objSearchDetails;
            CandidateDetailsCommand = new RelayCommand<string>(DoOperation);
            loadDefault(objSearchDetails);
        }


        #region loadDefault
        private void loadDefault(AssessmentReportResponseModel.Response objSearchDetails)
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                //BindProfilePic(objSearchDetails.ProfilePicture);

                LblUserName = objSearchDetails.name;
                LblHireMeID = objSearchDetails.hiremee_id;
                LblCourse = objSearchDetails.Course;
                LblSpecialization = objSearchDetails.Specialization;
                LblEmail = objSearchDetails.EmailAddress;
              
                if (objSearchDetails != null)
                {
                    LblVerbal = objSearchDetails.Verbalaptitude.ToString();
                    LblLogical = objSearchDetails.logicalreasoning.ToString();
                    lblTechnical = objSearchDetails.technicalcoredomain.ToString();
                    lblCommunication = objSearchDetails.communication.ToString();
                    lblQuantitative = objSearchDetails.quantitativeaptitude.ToString();
                    lblPersonalCompetencies = objSearchDetails.personalcompetencies.ToString();
                    lblEmotionalCompetencies = objSearchDetails.emotionalcompetencies.ToString();
                    lblMotivationalCompetencies = objSearchDetails.motivationalcompetencies.ToString();
                    lblIntellectualOrientation = objSearchDetails.intellectualorientation.ToString();
                    lblInterPersonalCompetencies = objSearchDetails.interpersonalcompetencies.ToString();
                    lblAptitude = objSearchDetails.technicalcomputerfundamental.ToString();
                }

                UserDialogs.Instance.HideLoading();
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "CandidateAssessmentDetailsViewModel.loadDefault");
            }
        }
        #endregion



        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion



        private void DoOperation(string sender)
        {
            switch (sender)
            {
                case "OnLeftArrowTapped":
                    IsFirstGrid = true;
                    IsSecondGrid = false;
                    IsLeftArrowEnable = false;
                    LeftArrowColor = Color.Gray;
                    IsRightArrowEnable = true;
                    RightArrowColor = Color.Black;
                    break;

                case "OnRightArrowTapped":
                    IsFirstGrid = false;
                    IsSecondGrid = true;
                    IsLeftArrowEnable = true;
                    LeftArrowColor = Color.Black;
                    IsRightArrowEnable = false;
                    RightArrowColor = Color.Gray;
                    break;
            }
        }

        #region Text Properties
        private string _lblusername;
        public string LblUserName
        {
            get { return _lblusername; }
            set { _lblusername = value; OnPropertyChanged(); }
        }

        private string _lblhiremeid;
        public string LblHireMeID
        {
            get { return _lblhiremeid; }
            set { _lblhiremeid = value; OnPropertyChanged(); }
        }

        private string _lblemail;
        public string LblEmail
        {
            get { return _lblemail; }
            set { _lblemail = value; OnPropertyChanged(); }
        }
       
        private string _lblcourse;
        public string LblCourse
        {
            get { return _lblcourse; }
            set { _lblcourse = value; OnPropertyChanged(); }
        }

        private string _lblSpecialization;
        public string LblSpecialization
        {
            get { return _lblSpecialization; }
            set { _lblSpecialization = value; OnPropertyChanged(); }
        }
       
        #endregion

        #region Label Assessment score Properties
        private string _lblVerbal;
        public string LblVerbal
        {
            get { return _lblVerbal; }
            set { _lblVerbal = value; OnPropertyChanged(); }
        }
        private string _lblLogical;
        public string LblLogical
        {
            get { return _lblLogical; }
            set { _lblLogical = value; OnPropertyChanged(); }
        }
        private string _lblTechnical;
        public string lblTechnical
        {
            get { return _lblTechnical; }
            set { _lblTechnical = value; OnPropertyChanged(); }
        }
        private string _lblCommunication;
        public string lblCommunication
        {
            get { return _lblCommunication; }
            set { _lblCommunication = value; OnPropertyChanged(); }
        }
        private string _lblQuantitative;
        public string lblQuantitative
        {
            get { return _lblQuantitative; }
            set { _lblQuantitative = value; OnPropertyChanged(); }
        }
        private string _lblPersonalCompetencies;
        public string lblPersonalCompetencies
        {
            get { return _lblPersonalCompetencies; }
            set { _lblPersonalCompetencies = value; OnPropertyChanged(); }
        }
        private string _lblEmotionalCompetencies;
        public string lblEmotionalCompetencies
        {
            get { return _lblEmotionalCompetencies; }
            set { _lblEmotionalCompetencies = value; OnPropertyChanged(); }
        }
        private string _lblMotivationalCompetencies;
        public string lblMotivationalCompetencies
        {
            get { return _lblMotivationalCompetencies; }
            set { _lblMotivationalCompetencies = value; OnPropertyChanged(); }
        }
        private string _lblIntellectualOrientation;
        public string lblIntellectualOrientation
        {
            get { return _lblIntellectualOrientation; }
            set { _lblIntellectualOrientation = value; OnPropertyChanged(); }
        }
        private string _lblInterPersonalCompetencies;
        public string lblInterPersonalCompetencies
        {
            get { return _lblInterPersonalCompetencies; }
            set { _lblInterPersonalCompetencies = value; OnPropertyChanged(); }
        }
        private string _lblAptitude;
        public string lblAptitude
        {
            get { return _lblAptitude; }
            set { _lblAptitude = value; OnPropertyChanged(); }
        }
        private string _lblStaticText;
        public string lblStaticText
        {
            get { return _lblStaticText; }
            set { _lblStaticText = value; OnPropertyChanged(); }
        }
        private string _lblPercentage;
        public string lblPercentage
        {
            get { return _lblPercentage; }
            set { _lblPercentage = value; OnPropertyChanged(); }
        }
        #endregion

        #region Arrow Tapped
        private bool _isfirstgrid = true;
        public bool IsFirstGrid
        {
            get { return _isfirstgrid; }
            set { _isfirstgrid = value; OnPropertyChanged(); }
        }
        private bool _issecondfgrid = false;
        public bool IsSecondGrid
        {
            get { return _issecondfgrid; }
            set { _issecondfgrid = value; OnPropertyChanged(); }
        }

        private bool _isleftarrowenable = false;
        public bool IsLeftArrowEnable
        {
            get { return _isleftarrowenable; }
            set { _isleftarrowenable = value; OnPropertyChanged(); }
        }
        private bool _isrightarrowenable = false;
        public bool IsRightArrowEnable
        {
            get { return _isrightarrowenable; }
            set { _isrightarrowenable = value; OnPropertyChanged(); }
        }

        private Color _leftarrowcolor = Color.Gray;
        public Color LeftArrowColor
        {
            get { return _leftarrowcolor; }
            set { _leftarrowcolor = value; OnPropertyChanged(); }
        }
        private Color _rightarrowcolor = Color.Black;
        public Color RightArrowColor
        {
            get { return _rightarrowcolor; }
            set { _rightarrowcolor = value; OnPropertyChanged(); }
        }
        #endregion
    }
}
