﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using HireMe.Models.Recruiter;
using MvvmHelpers;
using Plugin.Connectivity;
using Xamarin.Forms;
using HireMe.Helpers;

namespace HireMe
{
    public class AssessmentReportViewModel:BaseViewModel
    {
        private HttpCommonService _commonservice { get; set; }
        public CollegeDashboardRequestModel CollegeDashboardRequestModel { get; set; }
        public ICommand OnCommand { get; set; }
        INavigation Navigation;
        public bool isClicked = true;
        public AssessmentReportViewModel(INavigation nav)
        {
            Navigation = nav;
            _commonservice = new HttpCommonService();
            CollegeDashboardRequestModel = new CollegeDashboardRequestModel();
            _educationdetails = new Educational_Details();
            OnCommand = new RelayCommand<string>(DoOperation);


            Specialization = "Select Specialization";
            CourseType = "Select Course Type";
            CourseName = "Select Course";
            SearchPlaceHolderText = "Search Candidate";

            EmailFontAwesomeFont = (string)Application.Current.Resources["EmailSign"];

            MessagingCenter.Subscribe<DynamicListPageViewModel, CommonListItemSource>(this, "SeekerPersonalandEducational", (sender, arg) =>
            {
                SetFieldValue(arg.fieldType, arg);
            });
            IsEnabledSearchControl = false;

        }



        private bool isEnabledSearchControl;
        public bool IsEnabledSearchControl
        {
            get { return isEnabledSearchControl; }
            set { isEnabledSearchControl = value; OnPropertyChanged(); }
        }

        #region GetCollegAssessmentReportDetails 
        /// <summary>
        /// Webserivce call for CollegeDashboardDetails
        /// </summary>
        public async Task GetCollegeAssessmentReportDetails(string specialization_id)
        {
            try
            {
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
               // bool isHostReachable = await CrossConnectivity.Current.IsRemoteReachable(APIData.HOST_REACHABLE);
                if (isNetworkAvailable)
                {
                    UserDialogs.Instance.ShowLoading();
                    CollegeDashboardRequestModel = new CollegeDashboardRequestModel();

                        Device.BeginInvokeOnMainThread(async () =>
                        {
                          
                            CollegeDashboardRequestModel.specialization_id = specialization_id;
                            var statusResult = await _commonservice.PostAsync<AssessmentReportResponseModel, CollegeDashboardRequestModel>(APIData.API_BASE_URL + APIMethods.AssessmentReport, CollegeDashboardRequestModel);
                            if (statusResult != null)
                            {
                                if (statusResult.code == "200" && statusResult.response.Count > 0)
                                {
                                    if (statusResult.response != null)
                                    {
                                        IsLableViewVisible = false;
                                        IsListViewVisible = true;
                                        IsEnabledSearchControl = true;
                                        isEnabledSearchBar = true;
                                        ItemSource = new ObservableCollection<AssessmentReportResponseModel.Response>(statusResult.response);
                                        TempItemSource = ItemSource;
                                    }
                                    else
                                    {
                                        IsListViewVisible = false;
                                        IsLableViewVisible = true;
                                        IsEnabledSearchControl = false;
                                    }


                                }
                                else
                                {
                                    IsListViewVisible = false;
                                    IsLableViewVisible = true;
                                    IsEnabledSearchControl = false;
                                }
                            }
                            else
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                            }

                          
                        });

                    UserDialogs.Instance.HideLoading();
                }

                else
                {
                    UserDialogs.Instance.HideLoading();
                    UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                //SendErrorMessageToServer(ex, "AssessmentReportViewModel.GetCollegeAssessmentReportDetails");
            }
        }
        #endregion


        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion



        private async void DoOperation(string obj)
        {
            switch (obj)
            {

                case "OnCourseTypeItemTapped":
                    if (isClicked)
                    {
                        isClicked = false;
                        NavigateToDynamicListPage(Constants.FieldType.CourseType, "103");
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;

                case "OnCourseItemTapped":
                    if (isClicked)
                    {
                        isClicked = false;
                        if (!string.IsNullOrEmpty(CourseType))
                        {
                            if (CourseTypeID != null && CourseType != null)
                            {
                                NavigateToDynamicListPage(Constants.FieldType.Course, CourseTypeID);

                            }
                            else
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectCourseType);

                            }
                        }



                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                   
                 
                case "OnSpecializationItemTapped":

                    if (isClicked)
                    {
                        isClicked = false;
                        if (CourseName == "Select Course")
                        {
                            await UserDialogs.Instance.AlertAsync("Select Course");

                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(Specialization))
                            {
                                NavigateToDynamicListPage(Constants.FieldType.Specialization, _educationdetails.course_id);

                            }
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;



                   
            }

           
        }

        public async void NavigateToDynamicListPage(string _fieldType, string _fieldValue)
        {
            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
            if (isNetworkAvailable)
            {
                //_SeekerPersonalPage = new SeekerPersonalAndEducationPage();

                await Navigation.PushAsync(new DynamicListPage("SeekerPersonalandEducational", _fieldType, _fieldValue));
            }
            else
            {
                UserDialogs.Instance.Toast("Check Internet Connection");
            }
        }


        public async void SetFieldValue(string fieldtype, object fieldvalue)
        {
            //_PersonalDetails = new JobSeekerProfileDetails();


            if (fieldtype == Constants.FieldType.CourseType)
            {
                if (CourseType != ((CommonListItemSource)fieldvalue).Title)
                {
                    CourseName = "Select Course";
                    Specialization = "Select Specialization";

                }
                CourseType = ((CommonListItemSource)fieldvalue).Title;
                CourseTypeID = ((CommonListItemSource)fieldvalue).ID;
                //_educationdetails.course_type_name = new CourseType { ID = ((CommonListItemSource)fieldvalue).ID, Name = ((CommonListItemSource)fieldvalue).Title };
            }
            else if (fieldtype == Constants.FieldType.Course)
            {
                if (CourseName != ((CommonListItemSource)fieldvalue).Title)
                {
                    Specialization = "Select Specialization";

                }
                CourseName = ((CommonListItemSource)fieldvalue).Title;
                _educationdetails.course_id = ((CommonListItemSource)fieldvalue).ID;
               // _educationdetails.Course = new Course { ID = ((CommonListItemSource)fieldvalue).ID, CourseTitle = ((CommonListItemSource)fieldvalue).Title };
            }
            else if (fieldtype == Constants.FieldType.Specialization)
            {
                Specialization = ((CommonListItemSource)fieldvalue).Title;
                _educationdetails.specialization_id = ((CommonListItemSource)fieldvalue).ID;
                //_educationdetails.Specialization = new Specialization { ID = ((CommonListItemSource)fieldvalue).ID, Title = ((CommonListItemSource)fieldvalue).Title };
                //await GetCollegeAssessmentReportDetails(_educationdetails.specialization_id);
                await GetCollegeAssessmentReportDetails(_educationdetails.specialization_id);
            }
        }

        #region Searchbar Controls
        private bool _isVisibleSearchbarCancel;
        public bool IsVisibleSearchbarCancelButton
        {
            get { return _isVisibleSearchbarCancel; }
            set { _isVisibleSearchbarCancel = value; OnPropertyChanged(); }
        }

        public string _SearchText;
        public string SearchText
        {
            set
            {
                _SearchText = value;
                SearchText_TextChanged();
                OnPropertyChanged();
            }
            get { return _SearchText; }
        }
        public bool _isEnabledSearchBar;

        public bool isEnabledSearchBar
        {
            set { _isEnabledSearchBar = value; OnPropertyChanged(); }
            get { return _isEnabledSearchBar; }
        }
        public Command OnSearchClearCommand => new Command(() =>
        {
            IsVisibleSearchbarCancelButton = false;
            SearchText = string.Empty;
            SearchPlaceHolderText = "Search Candidate";

        });
        private string _searchPlaceHolder;
        public string SearchPlaceHolderText
        {
            get { return _searchPlaceHolder; }
            set { _searchPlaceHolder = value; OnPropertyChanged(); }
        }


        public async void SearchText_TextChanged()
        {
            var searchtext = SearchText;
            if (string.IsNullOrEmpty(searchtext))
            {
                SearchPlaceHolderText = "Search Candidate";
                IsVisibleSearchbarCancelButton = false;
                await GetCollegeAssessmentReportDetails(_educationdetails.specialization_id);
                return;
            }

            if (TempItemSource != null)
            {

                ItemSource = TempItemSource;
                List<AssessmentReportResponseModel.Response> Suggetions = ItemSource.Where(c =>
                                                                                           c.name.ToLower().Contains(searchtext.ToLower())
                                                                                           || c.Course.ToLower().Contains(searchtext.ToLower())
                                                                                           || c.Specialization.ToLower().Contains(searchtext.ToLower())).ToList();
                ItemSource = new ObservableCollection<AssessmentReportResponseModel.Response>(Suggetions);
                IsVisibleSearchbarCancelButton = true;
            }

        }

        #endregion

        public ICommand SelectedCommand => new Command(() =>
        {
            Navigation.PushAsync(new CandidateAssessmentDetails(_ItemSource,SelectedItem));
        });


        private AssessmentReportResponseModel.Response _SelectedItem;
        public AssessmentReportResponseModel.Response SelectedItem
        {
            get { return _SelectedItem; }
            set { _SelectedItem = value; OnPropertyChanged(); }
        }

        private ObservableCollection<AssessmentReportResponseModel.Response> _ItemSource;
        public ObservableCollection<AssessmentReportResponseModel.Response> ItemSource
        {
            get { return _ItemSource; }
            set { _ItemSource = value; OnPropertyChanged(); }
        }

        private ObservableCollection<AssessmentReportResponseModel.Response> _TempItemSource;
        public ObservableCollection<AssessmentReportResponseModel.Response> TempItemSource
        {
            get { return _TempItemSource; }
            set { _TempItemSource = value; OnPropertyChanged(); }
        }

        private bool _IsListViewVisible;
        public bool IsListViewVisible
        {
            get { return _IsListViewVisible; }
            set { _IsListViewVisible = value; OnPropertyChanged(); }
        }

        private bool _IsLableViewVisible;
        public bool IsLableViewVisible
        {
            get { return _IsLableViewVisible; }
            set { _IsLableViewVisible = value; OnPropertyChanged(); }
        }

        private Educational_Details educationdetails;
        public Educational_Details _educationdetails
        {
            get { return educationdetails; }
            set { educationdetails = value; OnPropertyChanged(); }
        }

        private string _specialization;
        public string Specialization
        {
            get { return _specialization; }
            set
            {
                _specialization = value;
                OnPropertyChanged();
            }
        }

        private string _courseTypeid;
        public string CourseTypeID
        {
            get { return _courseTypeid; }
            set
            {
                _courseTypeid = value;
                OnPropertyChanged();
            }
        }

        private string _courseType;
        public string CourseType
        {
            get { return _courseType; }
            set
            {
                _courseType = value;
                OnPropertyChanged();
            }
        }

        private string _courseName;
        public string CourseName
        {
            get { return _courseName; }
            set
            {
                _courseName = value;
                OnPropertyChanged();
            }
        }

        private string _emailFontAwesomeFont;
        public string EmailFontAwesomeFont
        {
            get { return _emailFontAwesomeFont; }
            set
            {
                if (value == _emailFontAwesomeFont) return;
                _emailFontAwesomeFont = value;
                OnPropertyChanged();
            }
        }
    }
}
