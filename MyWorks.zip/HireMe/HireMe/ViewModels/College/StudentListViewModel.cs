﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Acr.UserDialogs;
using MvvmHelpers;
using Xamarin.Forms;
using HireMe.Helpers;

namespace HireMe
{
    public class StudentListViewModel:BaseViewModel
    {
        private HttpCommonService _commonservice { get; set; }
        public CollegeDashboardRequestModel CollegeDashboardRequestModel { get; set; }
        public StudentListViewModel(string title,string fromdate,string todate)
        {
            _commonservice = new HttpCommonService();

             GetStudentDetails(title, fromdate, todate);
        }

        #region GetStudentDetails 
        /// <summary>
        /// Webserivce call for CollegeDashboardDetails
        /// </summary>
        public async Task GetStudentDetails(string title, string fromdate, string todate)
        {
            CollegeDashboardRequestModel = new CollegeDashboardRequestModel();
            CollegeDashboardRequestModel.fromdate = fromdate;
            CollegeDashboardRequestModel.todate = todate;
            try
            {
                Device.BeginInvokeOnMainThread(async () =>
                {
                    UserDialogs.Instance.ShowLoading();
                    if (title=="TOTAL STUDENTS UPLOADED")
                    {
                        var statusResult = await _commonservice.PostAsync<StudentListModel, CollegeDashboardRequestModel>(APIData.API_BASE_URL + APIMethods.UploadedStudent, CollegeDashboardRequestModel);
                        if (statusResult.code == "200" && statusResult !=null)
                        {
                            if (statusResult.response.Count != 0)
                            {
                                IsLableViewVisible = false;
                                IsListViewVisible = true;

                                isEnabledSearchBar = true;
                                ItemSource = new ObservableCollection<StudentListModel.Response>(statusResult.response);
                                TempItemSource = ItemSource;
                            }
                            else
                            {
                                IsListViewVisible = false;
                                IsLableViewVisible = true;

                            }


                        }
                        else
                        {
                            IsListViewVisible = false;
                            IsLableViewVisible = true;

                        }
                        
                    }else{
                        var statusResult = await _commonservice.PostAsync<StudentListModel, CollegeDashboardRequestModel>(APIData.API_BASE_URL + APIMethods.RegisteredStudent, CollegeDashboardRequestModel);
                        if (statusResult.code == "200" && statusResult !=null)
                        {
                            if (statusResult.response.Count != 0)
                            {
                                IsLableViewVisible = false;
                                IsListViewVisible = true;

                                isEnabledSearchBar = true;
                                ItemSource = new ObservableCollection<StudentListModel.Response>(statusResult.response);
                                TempItemSource = ItemSource;
                            }
                            else
                            {
                                IsListViewVisible = false;
                                IsLableViewVisible = true;

                            }


                        }
                        else
                        {
                            IsListViewVisible = false;
                            IsLableViewVisible = true;

                        }
                    }

                    UserDialogs.Instance.HideLoading();
                });
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "StudentListViewModel.GetStudentDetails");
            }
        }
        #endregion


        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion






        private ObservableCollection<StudentListModel.Response> _ItemSource;
        public ObservableCollection<StudentListModel.Response> ItemSource
        {
            get { return _ItemSource; }
            set { _ItemSource = value; OnPropertyChanged(); }
        }

        private ObservableCollection<StudentListModel.Response> _TempItemSource;
        public ObservableCollection<StudentListModel.Response> TempItemSource
        {
            get { return _TempItemSource; }
            set { _TempItemSource = value; OnPropertyChanged(); }
        }

        private bool _IsListViewVisible;
        public bool IsListViewVisible
        {
            get { return _IsListViewVisible; }
            set { _IsListViewVisible = value; OnPropertyChanged(); }
        }

        private bool _IsLableViewVisible;
        public bool IsLableViewVisible
        {
            get { return _IsLableViewVisible; }
            set { _IsLableViewVisible = value; OnPropertyChanged(); }
        }

        #region Searchbar Controls
        private bool _isVisibleSearchbarCancel;
        public bool IsVisibleSearchbarCancelButton
        {
            get { return _isVisibleSearchbarCancel; }
            set { _isVisibleSearchbarCancel = value; OnPropertyChanged(); }
        }

        public string _SearchText;
        public string SearchText
        {
            set
            {
                _SearchText = value;
                SearchText_TextChanged();
                OnPropertyChanged();
            }
            get { return _SearchText; }
        }
        public bool _isEnabledSearchBar;

        public bool isEnabledSearchBar
        {
            set { _isEnabledSearchBar = value; OnPropertyChanged(); }
            get { return _isEnabledSearchBar; }
        }
        public Command OnSearchClearCommand => new Command(() =>
        {
            IsVisibleSearchbarCancelButton = false;
            SearchText = string.Empty;
            SearchPlaceHolderText = "Search Candidate";

        });
        private string _searchPlaceHolder;
        public string SearchPlaceHolderText
        {
            get { return _searchPlaceHolder; }
            set { _searchPlaceHolder = value; OnPropertyChanged(); }
        }


        public async void SearchText_TextChanged()
        {
            var searchtext = SearchText;
            if (string.IsNullOrEmpty(searchtext))
            {
                SearchPlaceHolderText = "Search Candidate";
                IsVisibleSearchbarCancelButton = false;
                //await GetStudentDetails();
                return;
            }

            if (TempItemSource != null)
            {

                ItemSource = TempItemSource;
                List<StudentListModel.Response> Suggetions = ItemSource.Where(c =>
                                                                              c.fullname.ToLower().Contains(searchtext.ToLower())
                                                                              || c.email_address.ToLower().Contains(searchtext.ToLower())
                                                                              || c.mobile_number.ToLower().Contains(searchtext.ToLower())).ToList();
                ItemSource = new ObservableCollection<StudentListModel.Response>(Suggetions);
                IsVisibleSearchbarCancelButton = true;
            }

        }

        #endregion
    }
}
