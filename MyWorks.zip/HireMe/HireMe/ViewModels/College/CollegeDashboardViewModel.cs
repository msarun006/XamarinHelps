﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Input;
using Acr.UserDialogs;
using MvvmHelpers;
using Plugin.Connectivity;

using Xamarin.Forms;
using HireMe.Helpers;
using Prism.Commands;
using HireMe;

namespace HireMe
{
    public class CollegeDashboardViewModel : BaseViewModel
    {
        private HttpCommonService _commonservice { get; set; }
        public CollegeDashboardRequestModel CollegeDashboardRequestModel { get; set; }

        List<String> monthList;
        // List<String> yearList;
        bool isClicked;
        List<Color> ColorCodeList;
        Random randomColorPicker;

        string WeeklyChangedFromDate, WeeklyChangedToDate;
        public DateTime TempDateTime { get; set; }
        public Command CommonCommand { get; set; }
        // int SetNumberOfDays;

        public string start_date { get; set; }
        public string end_date { get; set; }

        public string SelectedMonth_Start_date { get; set; }
        public string SelectedMonth_end_date { get; set; }

        public int monthMovingCount { get; set; }
        public int yearMovingCount { get; set; }

        // public ICommand GridItemTapCommand { get; private set; }

        public INavigation navigationService;

        public CollegeDashboardViewModel(INavigation navigation)
        {
            navigationService = navigation;
            //GridItemTapCommand = new DelegateCommand<LoadCustomGridItems>(OnArticleTapped);
            randomColorPicker = new Random();
            isClicked = true;
            _commonservice = new HttpCommonService();
            CollegeDashboardRequestModel = new CollegeDashboardRequestModel();
            CommonCommand = new Command(CommonFunctionCall);
            SelectedMonth_Start_date = string.Empty;
            SelectedMonth_end_date = string.Empty;
            monthList = new List<string>() { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
            // yearList = new List<string>() { "2016", "2017", "2018", "2019", "2020" };
            monthMovingCount = (DateTime.Now.Month - 1);

            //for (int i = 0; i < yearList.Count; i++)
            //{
            //    if (yearList[i].Equals(DateTime.Now.Year.ToString()))
            //    {
            //        yearMovingCount = i;
            //    }
            //}
            TempDateTime = DateTime.Today;

            DisplayDate = TempDateTime.ToString("yyyy");
         
            SelectedYear = DisplayDate;
            SelectedMonth = (DateTime.Now.Month).ToString();


            DateTime baseDate = DateTime.Now;

            var currentWeek = baseDate.AddDays(-(int)baseDate.DayOfWeek);
            var ToDateFromWeek = currentWeek.AddDays(6);

            start_date = currentWeek.ToString("yyyy-MM-dd");
            end_date = ToDateFromWeek.ToString("yyyy-MM-dd");






        }

        //private async void OnArticleTapped(LoadCustomGridItems obj)
        //{
        //    if (isClicked)
        //    {
        //        isClicked = false;

        //        //navigationService.PushAsync(new StudentListPage(obj.Title,CollegeDashboardRequestModel.fromdate,CollegeDashboardRequestModel.todate));

        //        await Task.Run(async () =>
        //        {
        //            await Task.Delay(500);
        //            isClicked = true;
        //        });
        //    }
        //}




        public void loadColorCode()
        {
            ColorCodeList.Add(Color.FromHex("#FF5733"));
            ColorCodeList.Add(Color.FromHex("#46B503"));
            ColorCodeList.Add(Color.FromHex("#01E3A9"));
            ColorCodeList.Add(Color.FromHex("#464747"));
            ColorCodeList.Add(Color.FromHex("#025AB3"));
            ColorCodeList.Add(Color.FromHex("#8B02B3"));
            ColorCodeList.Add(Color.FromHex("#26a69a"));
            ColorCodeList.Add(Color.FromHex("#26c6da"));
            ColorCodeList.Add(Color.FromHex("#29b6f6"));
            ColorCodeList.Add(Color.FromHex("#42A5F5"));

        }


        public async void CommonFunctionCall(object obj)
        {
            if (obj.ToString() == "logout")
            {
                AppPreferences.IsCollege = false;
                //AppPreferences.IsLogout = true;
                AppPreferences.IsLoggeedIn = false;
                AppPreferences.IsPasscode = false;
                AppPreferences.IsPasscodeValue = string.Empty;
                var page = new NavigationPage(new LoginPageNew());
                Application.Current.MainPage = page;
                return;
            }

            else if (obj.ToString() == "assessmentpage")
            {
                if (isClicked)
                {
                    isClicked = false;
                    await navigationService.PushAsync(new CollegeAssessmentReportPage());

                }
                await Task.Run(async () =>
                {
                    await Task.Delay(500);
                    isClicked = true;
                });
            }

            else if (obj.ToString() == "previous")
            {


                if (Index == 0)
                {
                    //var CurrentDay = DateTime.Today;
                    //if (CurrentDay >)
                    //{

                    //}
                    TempDateTime = TempDateTime.AddYears(-1);
                    DisplayDate = TempDateTime.ToString("yyyy");
                    SelectedYear = DisplayDate;
                
                    await GetCollegeDashboardDetails();


                    //if (yearMovingCount > 0)
                    //{

                    //    yearMovingCount--;
                    //    DisplayDate = yearList[yearMovingCount];
                    //    SelectedYear = DisplayDate;
                    //    await GetCollegeDashboardDetails();
                    //}
                }
                else if (Index == 1)
                {

                    TempDateTime = TempDateTime.AddMonths(-1);
                    var startDate = new DateTime(TempDateTime.Year, TempDateTime.Month, 1);
                    var endDate = startDate.AddMonths(1).AddDays(-1);
                    SelectedMonth_Start_date = startDate.ToString("yyyy-MM-dd");
                    SelectedMonth_end_date = endDate.ToString("yyyy-MM-dd");
                    DisplayDate = TempDateTime.ToString("MMMM yyyy");
                  
                    await GetCollegeDashboardDetails();

                }
                else if (Index == 2)
                {
                 
                    DateTime pre_ToDateFromWeek = Convert.ToDateTime(start_date).AddDays(-1);
                    DateTime pre_currentWeek = pre_ToDateFromWeek.AddDays(-6);
                    start_date = pre_currentWeek.ToString("yyyy-MM-dd");
                    end_date = pre_ToDateFromWeek.ToString("yyyy-MM-dd");
                    string pre_fromString = pre_currentWeek.ToString("dd MMM yyyy");
                    string pre_toString = pre_ToDateFromWeek.ToString("dd MMM yyyy");
                    DisplayDate = pre_fromString + "  to  " + pre_toString;
                    WeeklyChangedFromDate = pre_currentWeek.ToString("yyyy-MM-dd");
                    WeeklyChangedToDate = pre_ToDateFromWeek.ToString("yyyy-MM-dd");
                    await GetCollegeDashboardDetails();
                }
            }
            else if (obj.ToString() == "next")
            {

                if (Index == 0)
                {
                    if (TempDateTime < DateTime.Today)
                    {
                        TempDateTime = TempDateTime.AddYears(1);
                        DisplayDate = TempDateTime.ToString("yyyy");
                        SelectedYear = DisplayDate;
                        await Task.Run(() => GetCollegeDashboardDetails());
                    }
                    else
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.NoRecordsFound);
                    }

                }
                else if (Index == 1)
                {
                    if (TempDateTime < DateTime.Today)
                    {
                        TempDateTime = TempDateTime.AddMonths(1);
                        var startDate = new DateTime(TempDateTime.Year, TempDateTime.Month, 1);
                        var endDate = startDate.AddMonths(1).AddDays(-1);
                        SelectedMonth_Start_date = startDate.ToString("yyyy-MM-dd");
                        SelectedMonth_end_date = endDate.ToString("yyyy-MM-dd");
                        DisplayDate = TempDateTime.ToString("MMMM yyyy");
                        await GetCollegeDashboardDetails();
                    }
                    else
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.NoRecordsFound);
                    }


                }
                else if (Index == 2)
                {
                    DateTime ThisWeekSunday = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek);
                    DateTime nextWeekSunday = ThisWeekSunday.AddDays(7);
                    DateTime nex_currentWeek = Convert.ToDateTime(end_date).AddDays(1);
                    DateTime nex_ToDateFromWeek = nex_currentWeek.AddDays(6);

                    if (nex_ToDateFromWeek < nextWeekSunday)
                    {
                        start_date = nex_currentWeek.ToString("yyyy-MM-dd");
                        end_date = nex_ToDateFromWeek.ToString("yyyy-MM-dd");
                        string nex_fromString = nex_currentWeek.ToString("dd MMM yyyy");
                        string nex_toString = nex_ToDateFromWeek.ToString("dd MMM yyyy");
                        DisplayDate = nex_fromString + "  to  " + nex_toString;

                        WeeklyChangedFromDate = nex_currentWeek.ToString("yyyy-MM-dd");
                        WeeklyChangedToDate = nex_ToDateFromWeek.ToString("yyyy-MM-dd");


                        await GetCollegeDashboardDetails();
                    }
                    else
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.NoRecordsFound);
                    }

                    
                  
                }
            }
            else if (obj.ToString() == "openpopup")
            {
                if (Index == 0)
                {
                 
                    TempDateTime = DateTime.Today;
                    DisplayDate = TempDateTime.ToString("yyyy");

                }
                else if (Index == 1)
                {
                  
                    TempDateTime = DateTime.Today;
                    DisplayDate = TempDateTime.ToString("MMMM yyyy");
                    var startDate = new DateTime(TempDateTime.Year, TempDateTime.Month, 1);
                    var endDate = startDate.AddMonths(1).AddDays(-1);
                    SelectedMonth_Start_date = startDate.ToString("yyyy-MM-dd");
                    SelectedMonth_end_date = endDate.ToString("yyyy-MM-dd");

                }
                else if (Index == 2)
                {
                  
                    DateTime baseDate = DateTime.Now;
                    var currentWeek = baseDate.AddDays(-(int)baseDate.DayOfWeek);
                    var ToDateFromWeek = currentWeek.AddDays(6);


                    string fromString = currentWeek.ToString("dd MMM yyyy");
                    string toString = ToDateFromWeek.ToString("dd MMM yyyy");

                    WeeklyChangedFromDate = currentWeek.ToString("yyyy-MM-dd");
                    WeeklyChangedToDate = ToDateFromWeek.ToString("yyyy-MM-dd");

                    DisplayDate = fromString + " to  " + toString;
                }
                await GetCollegeDashboardDetails();
            }
        }




        #region GetCollegeDashboardDetails 
        /// <summary>
        /// Webserivce call for CollegeDashboardDetails
        /// </summary>
        public async Task GetCollegeDashboardDetails()
        {
            try
            {
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {
                    CollegeDashboardRequestModel = new CollegeDashboardRequestModel();
                    if (Index == 0)
                    {
                        CollegeDashboardRequestModel.fromdate = DisplayDate + "-" + "01" + "-" + "01";
                        CollegeDashboardRequestModel.todate = DisplayDate + "-" + "12" + "-" + "31";
                    }
                    else if (Index == 1)
                    {
                        CollegeDashboardRequestModel.fromdate = SelectedMonth_Start_date;
                        CollegeDashboardRequestModel.todate = SelectedMonth_end_date;
                        //CollegeDashboardRequestModel.fromdate = SelectedYear + "-" + SelectedMonth + "-" + "01";
                        //CollegeDashboardRequestModel.todate = SelectedYear + "-" + SelectedMonth + "-" + DateTime.DaysInMonth(int.Parse(SelectedYear), int.Parse(SelectedMonth));
                    }
                    else if (Index == 2)
                    {

                        CollegeDashboardRequestModel.fromdate = WeeklyChangedFromDate;
                        CollegeDashboardRequestModel.todate = WeeklyChangedToDate;

                    }


                    Device.BeginInvokeOnMainThread(async () =>
                   {
                       UserDialogs.Instance.ShowLoading();

                       ColorCodeList = new List<Color>();
                       loadColorCode();

                       var statusResult = await _commonservice.PostAsync<CollegeDashbaordResponseModel, CollegeDashboardRequestModel>(APIData.API_BASE_URL + APIMethods.CollegeDashboard, CollegeDashboardRequestModel);

                       if (statusResult.code == "200" && statusResult != null)
                       {

                           if (statusResult.responseText != null)
                           {
                               GridItems = new List<LoadCustomGridItems>();

                               LoadCustomGridItems loadCustomGridItems;

                               for (int i = 0; i < 3; i++)
                               {
                                   loadCustomGridItems = new LoadCustomGridItems();
                                   int r = randomColorPicker.Next(ColorCodeList.Count);

                                   if (i == 0)
                                   {
                                       IsLableViewVisible = false;
                                       loadCustomGridItems.Count = statusResult.responseText.collegedashboard.totaluploadedstudent.ToString();
                                       loadCustomGridItems.Title = "TOTAL STUDENTS UPLOADED";
                                       loadCustomGridItems.CustomImage = (string)Application.Current.Resources["StudentUploadIcon"]; ;
                                       loadCustomGridItems.GridItemBackColor = Color.FromHex("#03a02a");
                                   }
                                   if (i == 1)
                                   {
                                       IsLableViewVisible = false;
                                       loadCustomGridItems.Count = statusResult.responseText.collegedashboard.totalregisterstudent.ToString();
                                       loadCustomGridItems.Title = "TOTAL REGISTERED STUDENT";
                                       loadCustomGridItems.CustomImage = (string)Application.Current.Resources["TotalRegisterIcon"]; ;
                                       loadCustomGridItems.GridItemBackColor = Color.FromHex("#8100a8");

                                   }

                                   if (i == 2)
                                   {
                                       IsLableViewVisible = false;
                                       if (Index == 0)
                                       {
                                           loadCustomGridItems.Title = "SHORTLIST STUDENT YEARWISE";
                                           loadCustomGridItems.Count = statusResult.responseText.collegedashboard.shortlistyearwise.ToString();
                                       }
                                       else if (Index == 1)
                                       {
                                           loadCustomGridItems.Title = "SHORTLIST STUDENT MONTHWISE";
                                           loadCustomGridItems.Count = statusResult.responseText.collegedashboard.shortlistmonthwise.ToString();
                                       }
                                       else if (Index == 2)
                                       {
                                           loadCustomGridItems.Title = "SHORTLIST STUDENT WEEKWISE";
                                           loadCustomGridItems.Count = statusResult.responseText.collegedashboard.shortlistweekwise.ToString();
                                       }


                                       loadCustomGridItems.CustomImage = (string)Application.Current.Resources["CalendarIcon"]; ;
                                       loadCustomGridItems.GridItemBackColor = Color.FromHex("#42A5F5");

                                   }



                                   GridItems.Add(loadCustomGridItems);
                               }
                           }
                       }
                       UserDialogs.Instance.HideLoading();
                   });



                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "CollegeDashboardViewModel.GetCollegeDashboardDetails");
            }
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        #region Properties

        private int index;
        public int Index
        {
            get { return index; }
            set { index = value; OnPropertyChanged(); }
        }

        private bool _IsLableViewVisible;
        public bool IsLableViewVisible
        {
            get { return _IsLableViewVisible; }
            set { _IsLableViewVisible = value; OnPropertyChanged(); }
        }


        private string _DisplayDate;
        public string DisplayDate
        {
            get { return _DisplayDate; }
            set { _DisplayDate = value; OnPropertyChanged(); }
        }



        private String selectedYear;
        public String SelectedYear
        {
            get { return selectedYear; }
            set { selectedYear = value; OnPropertyChanged(); }
        }



        private String selectedMonth;

        public String SelectedMonth
        {
            get { return selectedMonth; }
            set { selectedMonth = value; OnPropertyChanged(); }
        }


        private String selectedDay;

        public String SelectedDay
        {
            get { return selectedDay; }
            set { selectedDay = value; OnPropertyChanged(); }
        }
        
      

        protected List<LoadCustomGridItems> gridItems;
        public List<LoadCustomGridItems> GridItems
        {
            get { return gridItems; }
            set { gridItems = value; OnPropertyChanged(); }
        }
        #endregion

    }
}
