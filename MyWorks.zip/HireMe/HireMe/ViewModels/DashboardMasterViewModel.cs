﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows.Input;
using GalaSoft.MvvmLight.Command;
using HireMe.UI;
using MvvmHelpers;
using Xamarin.Forms;
using HireMe.Models.JobSeeker;
using HireMe.ViewModels;
using HireMe.Views.JobSeeker;
using HireMe.ViewModels.JobSeeker;
using HireMe.Views.Recruiter;
using HireMe.Helpers;
using System.Collections.ObjectModel;

namespace HireMe
{
    public class DashboardMasterViewModel : BaseViewModel
    {

        private DashboardMasterModel _oldProduct;
        public ObservableCollection<DashboardMasterModel> menuList { get; set; }
        public RecruiterDashboardModel RecruiterProfileDetailsModel { get; set; }
        public SeekerDashboardModel SeekerDashboardModel { get; set; }
        public UserResourceRetrivalRequestData UserResourceRequestModel { get; set; }
        private HttpCommonService _commonservice { get; set; }
        public ICommand ProfileCommand { get; set; }
        private string _usertype { get; set; }
        public bool isClicked = true;

        public INavigation _navigationservice;

        public IMasterDetailProfilePicture _detailChangeProfilePicture;
        public IMasterEditBasicDetailsPage _masterEditBasicDetailsPage;



        public DashboardMasterViewModel(string usertype, INavigation nav, IMasterDetailProfilePicture profile, IMasterEditBasicDetailsPage basicEditDetails)
        {
            menuList = new ObservableCollection<DashboardMasterModel>();
            //RecruiterProfileDetailsModel = new RecruiterDashboardModel();
            //SeekerDashboardModel = new SeekerDashboardModel();
            //UserResourceRequestModel = new UserResourceRetrivalRequestData();
            _commonservice = new HttpCommonService();
            ProfileCommand = new RelayCommand<string>(TapProfileCommand);


            _navigationservice = nav;
            _detailChangeProfilePicture = profile;
            _masterEditBasicDetailsPage = basicEditDetails;
            AppPreferences.IsDashboard = true;
            _usertype = usertype;
            LoadUserDetails();
          //  LoadDefault();
            ListViewRowheight = "45";

            MessagingCenter.Subscribe<SeekerDashboardViewModel, string>(this, "ChangeProfilePicture", ChangeSeekerProfilePicture);
            MessagingCenter.Subscribe<SeekerDashboardViewModel, string[]>(this, "UserDetails", ChangeUserDetails);
            MessagingCenter.Subscribe<RecruiterDashboardViewModel, string>(this, "ChangeProfilePicture", ChangeRecruiterProfilePicture);
            MessagingCenter.Subscribe<RecruiterDashboardViewModel, string[]>(this, "UserDetails", ChangeRecruiterDetails);
            MessagingCenter.Subscribe<ChangeProfilePictrurePageViewModel, string>(this, "ChangeProfilePicture", ChangeProfilePicture);
            MessagingCenter.Subscribe<SeekerPersonalAndEducationViewModel, string>(this, "ChangeProfilePicture", SeekerPersonalAndEducationPageChangeProfilePicture);
            MessagingCenter.Subscribe<EditBasicDetailsViewModel, string[]>(this, "UpdateBasicDetails", (sender, arg) =>
            {
                //  FirstName = arg[0];
                // LastName = arg[1];
                // MobileNo = arg[2];
                //EmailID = arg[3];
                UserName = arg[0].ToUpper() + " " + arg[1].ToUpper();
            });
            MessagingCenter.Subscribe<OTPVerifyViewModel, string>(this, "UpdateEmail", (sender, arg) =>
            {
                EmailID = arg;
            });
        }



        private String _ListViewRowheight;

        public String ListViewRowheight
        {
            get { return _ListViewRowheight; }
            set { _ListViewRowheight = value;OnPropertyChanged(); }
        }


        private void LoadUserDetails()
        {
            try
            {
                if (AppPreferences.ProfilePicture != string.Empty)
                {
                    ProfileImage = AppPreferences.ProfilePicture;
                }
                else
                {
                    ProfileImage = (string)Application.Current.Resources["IconUser"];
                }
                if (AppPreferences.userName != string.Empty)
                {
                    UserName = AppPreferences.userName;
                    EmailID = AppPreferences.EmailAddress;
                    HiremeeID = "HireMee ID : " + AppPreferences.HireMeeID;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "DashboardMasterViewModel.LoadUserDetails");
            }
        }



        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        private void SeekerPersonalAndEducationPageChangeProfilePicture(SeekerPersonalAndEducationViewModel sender, string path)
        {
            ProfileImage = path;
            AppPreferences.ProfilePicture = path;
        }

        private void ChangeSeekerProfilePicture(SeekerDashboardViewModel sender, string path)
        {
            ProfileImage = path;
            AppPreferences.ProfilePicture = path;
        }

        void ChangeUserDetails(SeekerDashboardViewModel sender, string[] value)
        {

            UserName = value[0];
            EmailID = value[1];
            HiremeeID = value[2];
            // FirstName = value[3];
            //ProfileImage = AppPreferences.ProfilePicture;

        }
        private void ChangeProfilePicture(ChangeProfilePictrurePageViewModel sender, string path)
        {
            ProfileImage = path;
            AppPreferences.ProfilePicture = path;
        }

        private void ChangeRecruiterProfilePicture(RecruiterDashboardViewModel sender, string path)
        {
            ProfileImage = path;
            AppPreferences.ProfilePicture = path;
        }

        void ChangeRecruiterDetails(RecruiterDashboardViewModel sender, string[] value)
        {

            UserName = value[0];
            EmailID = value[1];
            HiremeeID = value[2];
            //FirstName = value[3];
        }

        //#region loadDefault
        //public async Task LoadDefault()
        //{
        //    try
        //    {
        //        //await GetS3Details();
        //        if (_usertype == UserType.JobSeeker)
        //        {
        //            JobSeekerMenu();
        //            AddCommonMenuItems();

        //        }
        //        else if (_usertype == UserType.Recruiter)
        //        {
        //            RecrutierMenu();
        //            AddCommonMenuItems();

        //        }

        //        //await GetProfilePicture();
        //    }
        //    catch (Exception ex)
        //    {
        //        System.Diagnostics.Debug.WriteLine(ex.Message);
        //        SendErrorMessageToServer(ex, "DashboardMasterViewModel.LoadDefault");
        //        // throw new NotImplementedException();
        //    }

        //}

        //#endregion

      

        
  
         




        #region Click Event Command 
        /// <summary>
        /// Click Event Method
        /// </summary>
        private async void TapProfileCommand(string sender)
        {
            try
            {
                switch (sender)
                {
                    //case "Profile":
                    //    if (isClicked)
                    //    {
                    //        isClicked = false;
                    //        _detailChangeProfilePicture.OnDetail(new ChangeProfilePicturePage());
                    //    }
                    //    await Task.Run(async () =>
                    //    {
                    //        await Task.Delay(500);
                    //        isClicked = true;
                    //    });
                    //    break;

                    case "BasicDetailsEdit":
                        if (isClicked)
                        {
                            isClicked = false;
                            if (_usertype == UserType.JobSeeker)
                            {
                                _masterEditBasicDetailsPage.OnDetail(new EditBasicDetailsPage());
                            }
                            else if (_usertype == UserType.Recruiter)
                            {

                                _detailChangeProfilePicture.OnDetail(new ChangeProfilePicturePage());
                            }
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(500);
                            isClicked = true;
                        });
                        break;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "DashboardMasterViewModel.TapProfileCommand");
            }
        }
        #endregion

        #region private property

        private string _userName;
        public string UserName
        {
            get { return _userName; }
            set
            {
                _userName = value;
                OnPropertyChanged();
            }
        }

        //private string _firstName;
        //public string FirstName
        //{
        //    get { return _firstName; }
        //    set
        //    {
        //        _firstName = value;
        //        OnPropertyChanged();
        //    }
        //}

        //private string _lastName;
        //public string LastName
        //{
        //    get { return _lastName; }
        //    set
        //    {
        //        _lastName = value;
        //        OnPropertyChanged();
        //    }
        //}

        private string _emailID;
        public string EmailID
        {
            get { return _emailID; }
            set
            {
                _emailID = value;
                OnPropertyChanged();
            }
        }

        private string _hiremeeID;
        public string HiremeeID
        {
            get { return _hiremeeID; }
            set
            {
                _hiremeeID = value;
                OnPropertyChanged();
            }

        }

        private string _profileImage;
        public string ProfileImage
        {
            get { return _profileImage; }
            set
            {
                _profileImage = value;
                OnPropertyChanged();

            }
        }

        #endregion
    }
}




//#region AddCommonMenuItems
///// <summary>
///// Adding the common menu items.
///// </summary>
//public void AddCommonMenuItems()
//{
//    // Creating our pages for menu navigation
//    // Here you can define title for item, 
//    // icon on the left side, and page that you want to open after selection
//    //var faq = new DashboardMasterModel() { Title = "FAQ's", Icon = (string)Application.Current.Resources["IconFAQ"], TargetType = typeof(FAQPage) };
//    //var settings = new DashboardMasterModel() { Title = "Settings", Icon = (string)Application.Current.Resources["IconSettings"], TargetType = typeof(SettingsPage) };
//    //var feedback = new DashboardMasterModel() { Title = "Feedback", Icon = (string)Application.Current.Resources["IconFeedback"], TargetType = typeof(FeedbackPage) };
//    //var promoteapp = new DashboardMasterModel() { Title = "Promote App", Icon = (string)Application.Current.Resources["IconPromoteApp"], TargetType = null };
//    //var aboutus = new DashboardMasterModel() { Title = "About Us", Icon = (string)Application.Current.Resources["IconAboutUs"], TargetType = typeof(AboutUsPage) };
//    //var logout = new DashboardMasterModel() { Title = "Log Out", Icon = (string)Application.Current.Resources["IconLogout"], TargetType = null };

//    //// Adding menu items to menuList
//    //menuList.Add(faq);
//    //menuList.Add(settings);
//    //menuList.Add(feedback);
//    //menuList.Add(promoteapp);
//    //menuList.Add(aboutus);
//    //menuList.Add(logout);
//}
//#endregion

//#region RecrutierMenu
///// <summary>
///// Adding the RecrutierMenu.
///// </summary>
//public void RecrutierMenu()
//{
//    // Creating our pages for menu navigation
//    // Here you can define title for item, 
//    // icon on the left side, and page that you want to open after selection
//    //var dashboard = new DashboardMasterModel() { Title = "Dashboard", Icon = (string)Application.Current.Resources["IconDashboard"], TargetType = typeof(RecruiterDashboardPage) };
//    //var searchVideoProfile = new DashboardMasterModel() { Title = "Search Candidate's", Icon = (string)Application.Current.Resources["IconSearch"], TargetType = typeof(RecruiterSearchVideoProfile) };
//    //var searchHistory = new DashboardMasterModel() { Title = "ShortListed Candidate's", Icon = (string)Application.Current.Resources["IconShortListedCandidate"], TargetType = typeof(RecruiterSearchHistory) };
//    //var selectCandidate = new DashboardMasterModel() { Title = "Selected Candidate's", Icon = (string)Application.Current.Resources["IconSelectedCandidate"], TargetType = typeof(SelectionSearchNameList) };
//    //var rejectedCandidate = new DashboardMasterModel() { Title = "Rejected Candidate's", Icon = (string)Application.Current.Resources["IconRejectedCandidate"], TargetType = typeof(RejectionSearchNameList) };

//    // Adding menu items to menuList
//    //menuList.Add(dashboard);
//    //menuList.Add(searchVideoProfile);
//    //menuList.Add(searchHistory);
//    //menuList.Add(selectCandidate);
//    //menuList.Add(rejectedCandidate);
//}
//#endregion

//#region JobSeekerMenu
///// <summary>
///// Adding the JobSeekerMenu.
///// </summary>
//public void JobSeekerMenu()
//{
//    // Creating our pages for menu navigation
//    // Here you can define title for item, 
//    // icon on the left side, and page that you want to open after selection
//    //var createvideoprofile = new DashboardMasterModel() {   Title = "My Dashboard", Icon = (string)Application.Current.Resources["IconDashboard"], TargetType = typeof(SeekerDashboardPage) };
//    //var notification = new DashboardMasterModel() { Title = "Notifications", Icon = (string)Application.Current.Resources["IconNotification"], TargetType = typeof(SeekerNotificationPage) };
//    //var studentID = new DashboardMasterModel() { Title = "Capture Student ID", Icon = (string)Application.Current.Resources["IconIdCard"], TargetType = typeof(StudentIdCardPage) };
//    //var qrcodegenerator = new DashboardMasterModel() {  Title = "QR Code Image", Icon = (string)Application.Current.Resources["IconQRCode"], TargetType = typeof(QRCodeGeneratorPage) };
//    //var recruitersMessage = new DashboardMasterModel() {  Title = "Recruiter's Message", Icon = (string)Application.Current.Resources["IconMessage"], TargetType = typeof(RecruitersMessage) };
//    //var companyDetails = new DashboardMasterModel() {  Title = "Company Details", Icon = (string)Application.Current.Resources["IconCompany"], TargetType = typeof(CompanyDetails) };
//    //var assessmentTest = new DashboardMasterModel() {  Title = "Mock Assessment", Icon = (string)Application.Current.Resources["IconAssessmentTest"], TargetType = typeof(SampleAssessmentTest) };
//    //var takeAssessmentTest = new DashboardMasterModel() {  Title = "HireMee Assessment", Icon = (string)Application.Current.Resources["IconAssessmentTest"], TargetType = typeof(Nullable) };
//    //var searchJobs = new DashboardMasterModel() {  Title = "Jobs", Icon = (string)Application.Current.Resources["IconJobs"], TargetType = typeof(JobsViewPage) };

//    //var autoProctoredAssessment = new DashboardMasterModel() { Title = "Auto Proctored Assessment", Icon = (string)Application.Current.Resources["IconAssessmentTest"], TargetType  = null };

//    // Adding menu items to menuList
//    //menuList.Add(createvideoprofile);
//    //menuList.Add(notification);
//    //menuList.Add(studentID);
//    //menuList.Add(qrcodegenerator);
//    //menuList.Add(recruitersMessage);
//    //menuList.Add(companyDetails);
//    //menuList.Add(assessmentTest);
//    //menuList.Add(takeAssessmentTest);
//    //menuList.Add(searchJobs);

//    //menuList.Add(autoProctoredAssessment);
//    //menuList.Add(changeProfile);
//}
//#endregion