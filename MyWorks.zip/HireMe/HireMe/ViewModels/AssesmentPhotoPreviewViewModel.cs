﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.Helpers.PRO_Assement;
using HireMe.Services;
using HireMe.Views;
using HireMe.Views.Assessment;
using HireMe.Views.PRO_Assessment;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels
{

    public class AssesmentPhotoPreviewViewModel : BaseViewModel
    {
        #region object Declarations
        public ICommand CommonCommand { get; set; }
        string ImageFilePath { get; set; }
        public int IsProfilePictureConfirm = 0;
        public bool isClicked = true;
        #endregion

        #region Constructor
        public AssesmentPhotoPreviewViewModel()
        {
            CommonCommand = new Command(DoCommand);
            ImageFilePath = AppPreferences.CapturedAssesmentImageFilePath;
            PictureInstruction = MessageStringConstants.AssesmentProfileMessage;
            AssementProfilePicture = ImageFilePath;
            ConfirmationCheckBox = (string)Application.Current.Resources["CheckBoxUnSelected"];
            IsProfilePictureConfirm = 0;
        }
        #endregion

        #region DoCommand
        private async void DoCommand(object obj)
        {
            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
            if (isNetworkAvailable)
            {
                if (obj.ToString() == "Proceed")
                {
                    if (isClicked)
                    {
                        isClicked = false;
                      
                        await AssesmentPhotoUploadDetails();
                      
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                }
                else if (obj.ToString() == "Retake")
                {
                    if (isClicked)
                    {
                        isClicked = false;
                        Application.Current.MainPage = new NavigationPage(new AssesmentTakePhotoPage());
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                }
                else if (obj.ToString() == "ConfirmSelection")
                {
                    if (IsProfilePictureConfirm == 0)
                    {
                        ConfirmationCheckBox = (string)Application.Current.Resources["CheckBoxSelected"];
                        IsProfilePictureConfirm = 1;

                    }
                    else if (IsProfilePictureConfirm == 1)
                    {
                        ConfirmationCheckBox = (string)Application.Current.Resources["CheckBoxUnSelected"];
                        IsProfilePictureConfirm = 0;

                    }
                }
            }
            else
            {
                UserDialogs.Instance.HideLoading();
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
            }
        }
        #endregion

        #region AssesmentPhotoUploadDetails
        private async Task AssesmentPhotoUploadDetails()
        {
            try
            {
                if (!string.IsNullOrEmpty(ImageFilePath))
                {
                    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                    if (isNetworkAvailable)
                    {
                        UserDialogs.Instance.ShowLoading();
                        string fileName = System.IO.Path.GetFileName("@" + ImageFilePath);
                        var fileKeyID = AppPreferences.ExamID + "_" + AppPreferences.LoadSeekerDashboardData.ProfileDetails.HireMeeID + "_" + fileName;
                        var S3_ID = await S3Manager.UploadFile(ImageFilePath, fileKeyID, AmazonS3BucketDetails.AssessmentImageBucket);
                        if (!string.IsNullOrEmpty(S3_ID))
                        {
                            UserDialogs.Instance.HideLoading();
                            AppPreferences.CapturedAssesmentImageFilePath = ImageFilePath;
                            Application.Current.MainPage = new NavigationPage(new AssessmentPage());
                        }
                        UserDialogs.Instance.HideLoading();
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);

                    }
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "AssesmentPhotoPreviewViewModel.AssesmentPhotoUploadDetails");
            }
        }

     

      
        #endregion




        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        #region Binding Properties

        private ImageSource _assementProfilePicture;
        public ImageSource AssementProfilePicture
        {
            get
            { return this._assementProfilePicture; }
            set
            {
                if (Equals(value, this._assementProfilePicture))
                { return; }
                this._assementProfilePicture = value;
                OnPropertyChanged();
            }
        }

        private string _pictureInstruction;

        public string PictureInstruction
        {
            get { return _pictureInstruction; }
            set { _pictureInstruction = value; OnPropertyChanged(); }
        }

        private string _confirmationCheckBox;

        public string ConfirmationCheckBox
        {
            get { return _confirmationCheckBox; }
            set { _confirmationCheckBox = value; OnPropertyChanged(); }
        }


        #endregion
    }
}
