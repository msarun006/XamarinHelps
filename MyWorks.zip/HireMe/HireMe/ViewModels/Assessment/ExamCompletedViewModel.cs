﻿using HireMe.Helpers;
using HireMe.LocalDataBase;
using MvvmHelpers;
using System;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace HireMe.ViewModels.Assessment
{
    public class ExamCompletedViewModel : BaseViewModel
    {

        public Command OnCommand { get; set; }
        public bool isClicked = true;
        public LocalDataBase.LocalDB _localDB;
        public ExamCompletedViewModel()
        {
            OnCommand = new Command(CommonFunction);
            _localDB = new LocalDataBase.LocalDB();


            Candidatename = AppPreferences.userName;

            if (Device.RuntimePlatform == Device.iOS)
            {
                IsShowIOSOnly = true;
            }
            else
            {
                IsShowIOSOnly = false;
            }
        }


        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        private async void CommonFunction(object obj)
        {

            try
            {
                if (obj.ToString().Equals("completed"))
                {
                    if (isClicked)
                    {
                        isClicked = false;

                        SqliteOperations sqliteOperations = new SqliteOperations();
                        //Need to check is all record sync with server
                        if (!sqliteOperations.CheckIfAnySyncupDataIsAvailable())
                        {
                            sqliteOperations.DeleteAllLocalRecords();
                        }

                        //Application.Current.MainPage = new NavigationPage(new AssessmentLoginPage());
                        Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                        return;
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                }

            }
            catch (Exception e)
            {
                SendErrorMessageToServer(e, "ExamCompletedViewModel.CommonFunction");
            }
        }


        private string _Candidatename;

        public string Candidatename
        {
            get { return _Candidatename; }
            set
            {
                _Candidatename = value; OnPropertyChanged();
            }
        }



        private bool isShowIOSOnly;
        public bool IsShowIOSOnly
        {
            get { return isShowIOSOnly; }
            set { isShowIOSOnly = value; OnPropertyChanged(); }
        }
    }
}

