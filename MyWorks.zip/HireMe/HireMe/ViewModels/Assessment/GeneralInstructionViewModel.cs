﻿using HireMe.Views.Assessment;
using MvvmHelpers;
using System;
using Xamarin.Forms;
using GalaSoft.MvvmLight.Command;
using System.Windows.Input;

namespace HireMe.ViewModels.Assessment
{

    public class GeneralInstructionViewModel : BaseViewModel
	{

		#region Variables initialization 
		public ICommand OnCommand { get; set; }
public INavigation navigationService { get; set; }
		//private HttpCommonService.HttpCommonService _commonservice { get; set; }
		#endregion

		#region Constructor
		public GeneralInstructionViewModel(INavigation navigation)
		{
			//_commonservice = new HttpCommonService.HttpCommonService();
			OnCommand = new RelayCommand<string>(CommonFunction);
			//OnCommand = new Command(CommonFunction);
			navigationService = navigation;
			//var source = new HtmlWebViewSource();
			//source.BaseUrl = DependencyService.Get<IBaseUrl>().GetGeneralInstruction();
			//SourceURL1 = source.BaseUrl;

			if (Device.RuntimePlatform == Device.iOS)
			{
				IsShowIOSOnly = true;
			}
			else
			{
				IsShowIOSOnly = false;
			}


		}
		#endregion

		private string _SourceURL1;

		public string SourceURL1
		{
			get { return _SourceURL1; }
			set { _SourceURL1 = value; OnPropertyChanged(); }
		}

		private Boolean isShowIOSOnly;

		public Boolean IsShowIOSOnly
		{
			get { return isShowIOSOnly; }
			set { isShowIOSOnly = value; OnPropertyChanged(); }

		}
		private void CommonFunction(string obj)
		{
			switch (obj)
			{
				case "Proceed":
					Application.Current.MainPage = new NavigationPage(new ExamInstruction_Page());
					break;
				//callAPI();
			}
		}


		//#region API Call
		//private async void callAPI()
		//{
		//	try
		//	{
		//		bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
		//		if (isNetworkAvailable)
		//		{
		//			UserDialogs.Instance.ShowLoading("Loading...");
		//			var request = new ExamSelectionRequest();
		//			request.HireMeeID = Application.Current.Properties[AppPreferenceKey.HireMeeID] as string;
		//			request.ExamID = Application.Current.Properties[AppPreferenceKey.ExamID] as string;
		//			var result = await _commonservice.PostAsync<ExamSelectionResponse, ExamSelectionRequest>(APIData.BASE_URL + APIMethods.LoginStatus, request);
		//			UserDialogs.Instance.HideLoading();
		//			if (result != null)
		//			{
		//				UserDialogs.Instance.HideLoading();
		//				if (result.StatusCode == "200")
		//				{
		//					Application.Current.MainPage = new NavigationPage(new SelectAndStartExamPage());
		//				}
		//				else if (result.StatusCode == "201" || result.StatusCode == "202")
		//				{
		//					await UserDialogs.Instance.AlertAsync(result.StatusMessage);
		//					Application.Current.MainPage = new InvigilatorLoginPage();
		//				}
		//				else
		//				{
		//					await UserDialogs.Instance.AlertAsync(result.StatusMessage);
		//					Application.Current.MainPage = new LoginPage();
		//				}
		//			}
		//		}
		//		else
		//		{
		//			UserDialogs.Instance.HideLoading();
		//			UserDialogs.Instance.Alert(MessageStringConstants.CheckInternetConnection);
		//		}
		//	}
		//	catch (Exception ex)
		//	{
		//		UserDialogs.Instance.HideLoading();
		//		Debug.WriteLine(ex.Message);
		//	}
		//}
		//#endregion
	}
}
