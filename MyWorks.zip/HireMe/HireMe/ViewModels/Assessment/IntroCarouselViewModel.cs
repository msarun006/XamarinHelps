﻿using HireMe.Models.Assessment;
using HireMe.Views.Assessment;
using MvvmHelpers;
using System.Collections.Generic;
using Xamarin.Forms;

namespace HireMe.ViewModels.Assessment
{
    public class IntroCarouselViewModel : BaseViewModel
    {
        public Command OnCommand { get; set; }
        public IntroCarouselViewModel()
        {
            OnCommand = new Command<string>(DoOperation);
            MyDataSource = new List<CarouselData>() { new CarouselData() { Name = "Login",Body="HireMee assessments is a CSR Initiative by reputed group of Companies. Bridge between the students and recruiters across the India, there is no charge. it is absolutely FREE OF COST "+
"If your institution or organization centers are charging for the assessment kindly call up on toll free no 1800 - 1111 or you can also write to us support@hiremee.co.in"},
                                                      new CarouselData() { Name = "Invigilator Login" ,Body="Check the front camera before the test. it should be in a working condition. & do not close/shut off the front camera manually once the test begins "+
                                                      "Battery charge percentage should be not less than 50 %"
                                                      +"An Active internet connectivity of at least 1 MBPS required for assessment& Make sure your internet is working (preferably 3G,4G)"
                                                      +"Turn off chat applications (Google talk, yahoo messenger etc.), antivirus, auto updates and other notifications "},
                                                      new CarouselData() { Name = "Exam Selection" ,Body="Please clear the caches and cookies. For better mobile performance"+
                                                      "Please make sure that no applications are running in background while giving a proctored assessment."+
                                                      "Please make sure you are using the latest version of the HireMee Assessment App/ browser"+
                                                      "This assessment link will be opened for 7 days after the registration and assessment can be taken between 7AM – 10PM on any of these days"}
                                                     };
        }

        private void DoOperation(string obj)
        {
            if (obj.Equals("tpgNext"))
            {
                if (Position == 2)
                {
                    Application.Current.MainPage = new NavigationPage(new AssessmentLoginPage());
                    return;
                }
                else
                {
                    Position++;
                }
            }
            else if (obj.Equals("tpgSkip"))
            {
                Application.Current.MainPage = new NavigationPage(new AssessmentLoginPage());
                return;
            }
        }

        public List<CarouselData> MyDataSource { get; set; } // Must have default value or be set before the BindingContext is set.

        private int _position;
        public int Position { get { return _position; } set { _position = value; OnPropertyChanged(); } }

        private string _buttonName;

        public string ButtonName
        {
            get { return _buttonName; }
            set { _buttonName = value; OnPropertyChanged(); }
        }
    }
}
