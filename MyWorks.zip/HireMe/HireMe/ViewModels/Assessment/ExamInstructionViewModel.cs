﻿using System;
using System.Windows.Input;
using GalaSoft.MvvmLight.Command;
using HireMe.Views.Assessment;
using MvvmHelpers;
using Xamarin.Forms;
using HireMe.Interface;
using Acr.UserDialogs;
using System.Threading.Tasks;
using HireMe.Helpers;

namespace HireMe.ViewModels.Assessment
{
    public class ExamInstructionViewModel : BaseViewModel
    {
        public INavigation navigationService { get; set; }
        public ICommand OnCommand { get; set; }
        public bool isClicked = true;
        public ExamInstructionViewModel(INavigation navigation)
        {
            OnCommand = new RelayCommand<string>(DoOperation);
            navigationService = navigation;
            Squareicon = (string)Application.Current.Resources["CheckBoxUnSelected"];

            //Examname =  Application.Current.Properties[AppPreferenceKey.ExamName] as String;
            Examinstruction = AppPreferences.ExamInstruction;//Application.Current.Properties[AppPreferenceKey.ExamInstruction] as String;
            var source = new HtmlWebViewSource();
            source.BaseUrl = DependencyService.Get<IBaseUrl>().GetExamInstruction();
            SourceURL = source.BaseUrl;


            Checkbox = true;

            if (Device.RuntimePlatform == Device.iOS)
            {
                IsShowIOSOnly = true;
            }
            else
            {
                IsShowIOSOnly = false;
            }
        }



        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion


        private String _Examname;

        public String Examname
        {
            get { return _Examname; }
            set { _Examname = value; OnPropertyChanged(); }
        }

        private String _Examinstruction;

        public String Examinstruction
        {
            get { return _Examinstruction; }
            set { _Examinstruction = value; OnPropertyChanged(); }
        }

        private bool isShowIOSOnly;
        public bool IsShowIOSOnly
        {
            get { return isShowIOSOnly; }
            set { isShowIOSOnly = value; OnPropertyChanged(); }
        }


        private string _SourceURL;

        public string SourceURL
        {
            get { return _SourceURL; }
            set { _SourceURL = value; OnPropertyChanged(); }
        }

        private async void DoOperation(string obj)
        {
            try
            {
                switch (obj)
                {
                    case "Proceed":
                        if (isClicked)
                        {
                            isClicked = false;
                            if (!Checkbox)
                            {
                                Application.Current.MainPage = new NavigationPage(new ExternalDeviceStatusPage());
                                return;
                            }
                            else
                            {
                                if (AppPreferences.IsHindi)
                                {
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.TermsAndConditionHindi, null, MessageStringConstants.OKHindi);
                                }
                                else
                                {
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.TermsAndCondition);
                                }

                            }
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(500);
                            isClicked = true;
                        });

                        break;

                    case "SelectSquare":
                        if (isClicked)
                        {
                            isClicked = false;
                            if (Checkbox == true)
                            {
                                Squareicon = (string)Application.Current.Resources["CheckBoxSelected"];
                                //ButtonEnable = true;
                                Checkbox = false;
                            }
                            else
                            {
                                Squareicon = (string)Application.Current.Resources["CheckBoxUnSelected"];
                                //ButtonEnable = false;
                                Checkbox = true;
                            }
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(500);
                            isClicked = true;
                        });

                        break;

                }
            }
            catch (Exception e)
            {
                SendErrorMessageToServer(e, "ExamInstructionViewModel.DoOperation");
            }
        }





        //private Boolean _ButtonEnable;

        //public Boolean ButtonEnable
        //{
        //	get { return _ButtonEnable; }
        //	set { _ButtonEnable = value; OnPropertyChanged(); }
        //}

        private Boolean _checkbox;

        public Boolean Checkbox
        {
            get { return _checkbox; }
            set { _checkbox = value; OnPropertyChanged(); }
        }





        private string _Squareicon;

        public string Squareicon
        {
            get { return _Squareicon; }
            set { _Squareicon = value; OnPropertyChanged(); }
        }

        private string _Squareicontick;

        public string Squareicontick
        {
            get { return _Squareicontick; }
            set { _Squareicontick = value; OnPropertyChanged(); }
        }



    }
}
