﻿using GalaSoft.MvvmLight.Command;
using HireMe.Helpers;
using HireMe.Interface;
using MvvmHelpers;
using Rg.Plugins.Popup.Extensions;
using System;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.Assessment
{
    public  class PoupExamInstructionViewModel : BaseViewModel
    {

        public bool isClicked = true;
        public INavigation navigationService { get; set; }
        public ICommand OnCommand { get; set; }
        public PoupExamInstructionViewModel(INavigation navigation)
        {
            OnCommand = new RelayCommand<string>(CommonFunction);
            navigationService = navigation;
            Examinstruction = AppPreferences.ExamInstruction;//Application.Current.Properties[AppPreferenceKey.ExamInstruction] as String;
            //Examname = Application.Current.Properties[AppPreferenceKey.ExamName] as String;
            var source = new HtmlWebViewSource();
            source.BaseUrl = DependencyService.Get<IBaseUrl>().GetExamInstruction();
            SourceURL = source.BaseUrl;
        }



        public async void CommonFunction(string obj)
        {
            try
            {
                switch (obj)
                {
                    #region iconselect Button Click Event
                    case "OnClose":
                        if (isClicked)
                        {
                            isClicked = false;

                            await navigationService.PopAllPopupAsync();
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(500);
                            isClicked = true;
                        });
                        break;
                        #endregion
                }
            }
            catch(Exception e)
            {
                SendErrorMessageToServer(e, "PoupExamInstructionViewModel.CommonFunction");
            }
        }


        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion



        private String _Examname;

        public String Examname
        {
            get { return _Examname; }
            set { _Examname = value; OnPropertyChanged(); }
        }

        private String _Examinstruction;

        public String Examinstruction
        {
            get { return _Examinstruction; }
            set { _Examinstruction = value; OnPropertyChanged(); }
        }

        private string _SourceURL;

		public string SourceURL
		{
			get { return _SourceURL; }
			set { _SourceURL = value; OnPropertyChanged(); }
		}
    }
}
