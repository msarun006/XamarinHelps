﻿using GalaSoft.MvvmLight.Command;
using HireMe.Helpers;
using MvvmHelpers;
using Rg.Plugins.Popup.Services;
using System;
using System.Windows.Input;

namespace HireMe.ViewModels.Assessment
{
    public class ZoomImageViewModel : BaseViewModel
    {
        public bool isClicked = true;
        public ICommand OnCommand { get; set; }
        public ZoomImageViewModel(string question)
        {
            HtmlSource = question;
            OnCommand = new RelayCommand<string>(DoOperation);
        }

        private async void DoOperation(string obj)
        {

            try
            {

                if (obj.Equals("tpgCancel"))
                {
                    await PopupNavigation.PopAsync();
                }


            }
            catch (Exception ex)
            {
                SendErrorMessageToServer(ex, "ZoomImageViewModel.DoOperation.tpgCancel");
            }
             
        }


        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion






        private string _HtmlSource;
        public string HtmlSource
        {
            get { return _HtmlSource; }
            set { _HtmlSource = value; OnPropertyChanged(); }
        }

    }
}
