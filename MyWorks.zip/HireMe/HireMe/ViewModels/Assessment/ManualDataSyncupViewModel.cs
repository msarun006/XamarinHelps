﻿using System;
using Acr.UserDialogs;
using HireMe.LocalDataBase;
using MvvmHelpers;
using Plugin.Connectivity;
using Xamarin.Forms;
using HireMe.Interface;
using System.Threading.Tasks;
using HireMe.Helpers;

namespace HireMe.ViewModels.Assessment
{
    public class ManualDataSyncupViewModel : BaseViewModel
    {
        #region variable declaration
        public Command OnCommand { get; set; }
        public bool isClicked = true;
        SqliteOperations sqliteOperations;
        public LocalDB _localDB { get; set; }
        #endregion

        #region constructor
        public ManualDataSyncupViewModel()
        {
            _localDB = new LocalDB();
            sqliteOperations = new SqliteOperations();
            OnCommand = new Command(ClickEvent);
            if (Device.RuntimePlatform == Device.iOS)
            {
                IsShowIOSOnly = true;
            }
            else
            {
                IsShowIOSOnly = false;
            }
        }
        #endregion

        #region ClickEvent
        private async void ClickEvent(object obj)
        {
            if (obj.ToString().Equals("syncup"))
            {
                if (isClicked)
                {
                    isClicked = false;
                    try
                    {
                        bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                        if (isNetworkAvailable)
                        {
                            //Need to check is all record sync with server
                            if (sqliteOperations.CheckIfAnySyncupDataIsAvailable())
                            {
                                await sqliteOperations.GetFacialImagesAndUploadToS3("syncup");
                                //Manual Synchronous Process.
                                //UserDialogs.Instance.ShowLoading();
                                //sqliteOperations.BulkInsert().Wait();
                                //await sqliteOperations.BulkInsert("Manual");
                                //UserDialogs.Instance.HideLoading();

                                //    if (string.IsNullOrEmpty(AppPreferences.IsSyncupTryingCount))
                                //{
                                //    AppPreferences.IsSyncupTryingCount = "1";
                                //}
                                //else
                                //{
                                //    AppPreferences.IsSyncupTryingCount = string.Empty;
                                //    DeleteAllLocalData();
                                //    return;
                                //}
                            }

                            //Need to check is all record sync with server
                            if (!sqliteOperations.CheckIfAnySyncupDataIsAvailable())
                            {
                                DeleteAllLocalData();

                                return;
                            }

                        }
                        else
                        {
                            UserDialogs.Instance.Alert(MessageStringConstants.CheckInternetConnection);
                        }

                    }
                    catch (Exception e)
                    {
                        System.Diagnostics.Debug.WriteLine(e.Message);
                        SendErrorMessageToServer(e, "ManualDataSyncupViewModel.ClickEvent.syncup");
                    }
                }
                await Task.Run(async () =>
                {
                    await Task.Delay(500);
                    isClicked = true;
                });
            }
            else if (obj.Equals("Cancel"))
            {
                if (isClicked)
                {
                    isClicked = false;
                    if (AppPreferences.IsDashboard)
                    {
                        Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                        return;
                    }
                    else
                    {
                        Application.Current.MainPage = new LoginPageNew();
                        return;
                    }
                }
                await Task.Run(async () =>
                {
                    await Task.Delay(500);
                    isClicked = true;
                });
            }
        }
        #endregion

        #region DeleteAllLocalData
        private async void DeleteAllLocalData()
        {
            try
            {
                sqliteOperations.DeleteAllLocalRecords();
                DependencyService.Get<ISyncDataWhileInternetAvailable>().IStopAlarmService();
                if (AppPreferences.IsDashboard)
                {
                    Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                    return;
                }
                else
                {
                    Application.Current.MainPage = new LoginPageNew();
                    return;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }

        #endregion

        #region properties
        private bool isShowIOSOnly;

        public bool IsShowIOSOnly
        {
            get { return isShowIOSOnly; }
            set { isShowIOSOnly = value; OnPropertyChanged(); }

        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}