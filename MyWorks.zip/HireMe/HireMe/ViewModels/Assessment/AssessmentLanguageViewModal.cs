﻿using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using HireMe.Interface;
using HireMe.Views.Assessment;
using MvvmHelpers;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.Assessment
{
    class AssessmentLanguageViewModal : BaseViewModel
    {
        private INavigation navigation;
        public ICommand OnSaveLanguage { get; set; }
        public Command onLanguageSelected { get; set; }
        public AssessmentLanguageViewModal(INavigation navigation)
        {
            this.navigation = navigation;
            onLanguageSelected = new Command(ClickEvent);
            OnSaveLanguage = new RelayCommand<string>(OnsaveDetails);
            SelectedText = "-- Select --";
        }

        private async void OnsaveDetails(string sender)
        {
            switch (sender)
            {
                case "SaveLanguage":
                    if (SelectedText == "-- Select --")
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectPreferredLanguage);
                    }
                    else
                    {
                        bool yes;
                        if (SelectedText == "Hindi")
                        {
                            yes = await UserDialogs.Instance.ConfirmAsync("आपने अपनी पसंदीदा भाषा हिंदी चुनी है, क्या आप आगे बढ़ाना चाहते हैं?", "परीक्षा भाषा", MessageStringConstants.OKHindi, MessageStringConstants.CancelHindi);
                        }
                        else
                        {
                            yes = await UserDialogs.Instance.ConfirmAsync("You have chosen your preferred language as English, are you sure you want to continue?", "Assessment Language", "Ok", "Cancel");
                        }
                        if (yes)
                        {
                            await navigation.PushAsync(new ExamInstruction_Page());
                        }
                    }
                    break;
            }
        }
        private async void ClickEvent(object obj)
        {
            try
            {
                if (obj.ToString().Equals("LanguageSelection"))
                {
                    await Task.Run(async () =>
                    {
                        await Task.Delay(200);
                        //#region UserDialogs.ActionSheet Configurations

                        //ActionSheetConfig ActionSheetConfigurations = new ActionSheetConfig();
                        //ActionSheetConfigurations.SetTitle("Select language");
                        //ActionSheetConfigurations.Add("English", () =>
                        //{
                        //    SelectedText = "English";
                        //    AppPreferences.IsEnglish = true;
                        //    AppPreferences.IsHindi = false;
                        //    DependencyService.Get<ILocalize>().ChangeLocale("en");
                        //    App.CultureCode = "en";
                        //    // await UserDialogs.Instance.AlertAsync("Language Selection", "English!", "OK");
                        //});
                        //ActionSheetConfigurations.Add("Hindi", () =>
                        //{
                        //    SelectedText = "Hindi";
                        //    AppPreferences.IsEnglish = false;
                        //    AppPreferences.IsHindi = true;
                        //    DependencyService.Get<ILocalize>().ChangeLocale("hi");
                        //    App.CultureCode = "hi";
                        //    //await UserDialogs.Instance.AlertAsync("Language Selection", "Hindi!", "OK");
                        //});
                        //ActionSheetConfigurations.Add("Cancel", () => { });
                        //UserDialogs.Instance.ActionSheet(ActionSheetConfigurations);

                        //#endregion


                        #region UserDialogs.ActionSheet Configurations
                        ActionSheetConfig ActionSheetConfigurations = new ActionSheetConfig();
                        ActionSheetConfigurations.SetTitle("Select language");

                        foreach (var item in AppSessionData.AvailableLanguage)
                        {
                            ActionSheetConfigurations.Add(item.LanguageName, () =>
                            {
                                //UploadProfilePicture("Pick from Gallery");
                                if (item.LanguageName == "English")
                                {
                                    SelectedText = item.LanguageName;
                                    AppPreferences.SelectedlanguageID = item.LanguageId;
                                    AppPreferences.IsEnglish = true;
                                    AppPreferences.IsHindi = false;
                                    DependencyService.Get<ILocalize>().ChangeLocale("en");
                                    App.CultureCode = "en";
                                }
                                else if (item.LanguageName == "Hindi")
                                {
                                    SelectedText = item.LanguageName;
                                    AppPreferences.SelectedlanguageID = item.LanguageId;
                                    AppPreferences.IsEnglish = false;
                                    AppPreferences.IsHindi = true;
                                    DependencyService.Get<ILocalize>().ChangeLocale("hi");
                                    App.CultureCode = "hi";
                                }
                            });
                        }

                        ActionSheetConfigurations.Add("Cancel", () => { });
                        UserDialogs.Instance.ActionSheet(ActionSheetConfigurations);
                        #endregion


                    });
                }
            }
            catch (System.Exception)
            {

            }
        }

        private string _SelectedText;

        public string SelectedText
        {
            get { return _SelectedText; }
            set { _SelectedText = value; OnPropertyChanged(); }
        }
    }
}
