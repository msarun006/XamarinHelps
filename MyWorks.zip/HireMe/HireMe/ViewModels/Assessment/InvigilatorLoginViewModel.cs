﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.Models.Assessment;
using HireMe.Views.Assessment;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Diagnostics;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace HireMe.ViewModels.Assessment
{
    public class InvigilatorLoginViewModel : BaseViewModel
    {
        #region Variables initialization 
        private HttpCommonService _commonservice { get; set; }
        public Command OnCommand { get; set; }
        private bool clickEye;
        private bool clickEyeInvigilator;
        public InvigilatorLoginModel InvigilatorLoginModel { get; set; }
        private InvigilatorLoginResponse InvigilatorLoginResponse;
        public bool isClicked = true;
        #endregion

        #region Constructor
        public InvigilatorLoginViewModel()
        {

            InvigilatorLoginModel = new InvigilatorLoginModel();
            InvigilatorLoginResponse = new InvigilatorLoginResponse();
            _commonservice = new HttpCommonService();
            OnCommand = new Command(ClickEvent);

            PasswordEyeText = (string)Application.Current.Resources["CloseEyeIcon"];
            clickEye = true;
            IsPasswordVisible = true;
            InvigilatorPasswordEyeText = (string)Application.Current.Resources["CloseEyeIcon"];
            clickEyeInvigilator = true;
            IsInvigilatorPasswordVisible = true;

            //InvigilatorLoginModel.Username = "HC024250";
            //InvigilatorLoginModel.Password = "Temp!123";
            //InvigilatorLoginModel.InvigilatorPassword = "05BgeysS";

        }
        #endregion

        #region Login ClickEvent
        private async void ClickEvent(object obj)
        {

            if (obj.ToString().Equals("login"))
            {

                if (isClicked)
                {
                    isClicked = false;
                    if (IsValidation())
                    {
                        try
                        {
                            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                            if (isNetworkAvailable)
                            {
                                UserDialogs.Instance.ShowLoading();
                                InvigilatorLoginModel.deviceId = DependencyService.Get<IMyDevice>().GetDeviceID() ?? string.Empty;
                                //if (Application.Current.Properties.ContainsKey(AppPreferenceKey.ExamID))
                                if (!string.IsNullOrEmpty(AppPreferences.ExamID))
                                {
                                    InvigilatorLoginModel.ExamID = AppPreferences.ExamID;//Application.Current.Properties[AppPreferenceKey.ExamID] as string;
                                }
                                else
                                {
                                    InvigilatorLoginModel.ExamID = string.Empty;
                                }
                                //if (Application.Current.Properties.ContainsKey(AppPreferenceKey.DeviceId))
                                if (!string.IsNullOrEmpty(AppPreferences.DeviceId))
                                {
                                    //if (Application.Current.Properties[AppPreferenceKey.DeviceId] as string == InvigilatorLoginModel.deviceId)
                                    if (AppPreferences.DeviceId == InvigilatorLoginModel.deviceId)
                                    {
                                        var result = await _commonservice.PostAsync<InvigilatorLoginResponse, InvigilatorLoginModel>(APIData.API_BASE_URL + APIMethods.InvigilatorLogin, InvigilatorLoginModel);
                                       UserDialogs.Instance.HideLoading();
                                        if (result != null)
                                        {
                                            if (result.code == "200")
                                            {
                                                AppPreferences.AssignedID = result.AssignedID;
                                                //Application.Current.Properties[AppPreferenceKey.AssignedID] = result.AssignedID;
                                                //Application.Current.Properties[AppPreferenceKey.ExamID] = result.ExamID;
                                                AppPreferences.ExamID = result.ExamID;
                                                Application.Current.MainPage = new NavigationPage(new ExternalDeviceStatusPage());
                                                return;
                                            }
                                            else if (result.code == "201" || result.code == "202")
                                            {
                                                await UserDialogs.Instance.AlertAsync(result.message);
                                                Application.Current.MainPage = new InvigilatorLoginPage();
                                                return;
                                            }
                                            else
                                            {
                                                await UserDialogs.Instance.AlertAsync(result.message);
                                                Application.Current.MainPage = new AssessmentLoginPage();
                                                return;
                                            }
                                            UserDialogs.Instance.HideLoading();
                                        }
                                        else
                                        {
                                            await UserDialogs.Instance.AlertAsync( MessageStringConstants.ServerBusyMessage);
                                        }
                                    }
                                    else
                                    {
                                        if (AppPreferences.IsHindi)
                                        {
                                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.DeviceIDNotMatchHindi, null, MessageStringConstants.OKHindi);
                                        }
                                        else
                                        {
                                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.DeviceIDNotMatch);
                                        }
                                    }

                                    UserDialogs.Instance.HideLoading();

                                }
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                UserDialogs.Instance.Alert(MessageStringConstants.CheckInternetConnection);
                            }
                        }
                        catch (Exception ex)
                        {
                            UserDialogs.Instance.HideLoading();
                            Debug.WriteLine(ex.Message);
                            SendErrorMessageToServer(ex, "InvigilatorLoginViewModel.ClickEvent.login");
                        }
                    }
                }
                await Task.Run(async () =>
                {
                    await Task.Delay(500);
                    isClicked = true;
                });
            }
            else if (obj.ToString() == "isVisibilityPassword")
            {
                if (isClicked)
                {
                    isClicked = false;
                    if (clickEye)
                    {
                        clickEye = false;
                        PasswordEyeText = (string)Application.Current.Resources["OpenEyeIcon"];
                        IsPasswordVisible = false;
                    }
                    else
                    {
                        clickEye = true;
                        PasswordEyeText = (string)Application.Current.Resources["CloseEyeIcon"];
                        IsPasswordVisible = true;
                    }
                }
                await Task.Run(async () =>
                {
                    await Task.Delay(500);
                    isClicked = true;
                });
            }
            else if (obj.ToString() == "isVisibilityInvigilatorPassword")
            {
                if (isClicked)
                {
                    isClicked = false;
                    if (clickEyeInvigilator)
                    {
                        clickEyeInvigilator = false;
                        InvigilatorPasswordEyeText = (string)Application.Current.Resources["OpenEyeIcon"];
                        IsInvigilatorPasswordVisible = false;
                    }
                    else
                    {
                        clickEyeInvigilator = true;
                        InvigilatorPasswordEyeText = (string)Application.Current.Resources["CloseEyeIcon"];
                        IsInvigilatorPasswordVisible = true;
                    }
                }
                await Task.Run(async () =>
                {
                    await Task.Delay(500);
                    isClicked = true;
                });
            }



        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        #region Validate User Credentials
        bool IsValidation()
        {
            bool isValid = false;

            if (string.IsNullOrEmpty(InvigilatorLoginModel.Username))
            {
                UserDialogs.Instance.Alert(MessageStringConstants.EnterHireMeeID);

            }
            else if (string.IsNullOrWhiteSpace(InvigilatorLoginModel.Username))
            {
                UserDialogs.Instance.Alert(MessageStringConstants.EnterHireMeeID);
                InvigilatorLoginModel.Username = string.Empty;
            }
            else if (string.IsNullOrEmpty(InvigilatorLoginModel.Password))
            {
                UserDialogs.Instance.Alert(MessageStringConstants.EnterPassword);
            }
            else if (string.IsNullOrEmpty(InvigilatorLoginModel.InvigilatorPassword))
            {
                UserDialogs.Instance.Alert(MessageStringConstants.EnterInvigilatorPassword);
            }
            else
            {
                isValid = true;
            }


            return isValid;
        }
        #endregion

        #region Pull Properties
        private bool _IsPasswordVisible;
        public bool IsPasswordVisible
        {
            get { return _IsPasswordVisible; }
            set { _IsPasswordVisible = value; OnPropertyChanged(); }
        }

        private string _PasswordEyeText;
        public string PasswordEyeText
        {
            get { return _PasswordEyeText; }
            set { _PasswordEyeText = value; OnPropertyChanged(); }
        }
        private bool _IsInvigilatorPasswordVisible;
        public bool IsInvigilatorPasswordVisible
        {
            get { return _IsInvigilatorPasswordVisible; }
            set { _IsInvigilatorPasswordVisible = value; OnPropertyChanged(); }
        }

        private string _InvigilatorPasswordEyeText;
        public string InvigilatorPasswordEyeText
        {
            get { return _InvigilatorPasswordEyeText; }
            set { _InvigilatorPasswordEyeText = value; OnPropertyChanged(); }
        }
        #endregion
    }
}
