﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;
using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using MvvmHelpers;
using Xamarin.Forms;
using Plugin.Connectivity;
using System.Diagnostics;
using HireMe.LocalDataBase;
using HireMe.Models.Assessment.SQLTables;
using HireMe.Interface;
using HireMe.Helpers;
using HireMe.Models.Assessment;

namespace HireMe.ViewModels.Assessment
{
    public class ProctoredFeedbackViewModel : BaseViewModel
    {
        public ICommand OnCommandQuestionOne { get; set; }
        public ICommand OnCommandQuestionTwo { get; set; }
        public ICommand OnCommandQuestionThree { get; set; }
        public ICommand OnCommand { get; set; }
        public LocalDB _localDB;
        private HttpCommonService _commonservice { get; set; }

        public FeedBackModelRequest _feedbackData;
        string qustion1ans;
        string qustion2ans;
        public bool isClicked = true;

        public ProctoredFeedbackViewModel()
        {
            Candidatename = AppPreferences.userName;

            _localDB = new LocalDB();
            _feedbackData = new FeedBackModelRequest();
            _commonservice = new HttpCommonService();
            qustion1ans = string.Empty;
            qustion2ans = string.Empty;
            qustion3ans = string.Empty;

            Question1 = "How was your experience in giving the HireMee digital skills exam?";
            Question2 = "How was your experience in terms of navigating the candidate console, ease of using the console, etc.?";
            Question3 = "How was your experience in terms of ease of finding the exam seat through the notice board, instructions, staff guidance,etc.?";
            OnCommandQuestionOne = new RelayCommand<string>(DoOperation);
            OnCommandQuestionTwo = new RelayCommand<string>(DoOperation);
            OnCommandQuestionThree = new RelayCommand<string>(DoOperation);
            OnCommand = new RelayCommand<string>(DoOperation);

            OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
            OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
            OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
            OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];

            OptionARadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
            OptionBRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
            OptionCRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
            OptionDRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];

            OptionARadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
            OptionBRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
            OptionCRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
            OptionDRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];


            if (Device.RuntimePlatform == Device.iOS)
            {
                IsShowIOSOnly = true;
            }
            else
            {
                IsShowIOSOnly = false;
            }


            //ture means AutoProctored exam
            if (AppPreferences.ExamMode == "True")
            {
                AutoProctoredThirdQuestion = true;
                ProctoredThirdQuestion = false;
            }
            else
            {
                AutoProctoredThirdQuestion = false;
                ProctoredThirdQuestion = true;
            }
        }



        private Boolean isShowIOSOnly;

        public Boolean IsShowIOSOnly
        {
            get { return isShowIOSOnly; }
            set { isShowIOSOnly = value; OnPropertyChanged(); }

        }


        private string _Candidatename;

        public string Candidatename
        {
            get { return _Candidatename; }
            set
            {
                _Candidatename = value; OnPropertyChanged();
            }
        }

        #region Command Operation
        private async void DoOperation(string obj)
        {
            switch (obj)
            {

                #region Submit Button Command
                case "Submit":

                    if (isClicked)
                    {
                        isClicked = false;
                        if (String.IsNullOrEmpty(qustion1ans))
                        {
                            UserDialogs.Instance.Alert("Please give your feedback for Question1");
                        }
                        else if (String.IsNullOrEmpty(qustion2ans))
                        {
                            UserDialogs.Instance.Alert("Please give your feedback for Question2");
                        }
                        else if (String.IsNullOrEmpty(qustion3ans))
                        {
                            UserDialogs.Instance.Alert("Please give your feedback for Question3");
                        }
                        else
                        {

                            try
                            {
                                AddFeebackOffline();
                                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                                if (isNetworkAvailable)
                                {

                                    SubmitFeedbackToAPI();
                                }
                                else
                                {
                                    SqliteOperations sqliteOperations = new SqliteOperations();
                                    bool checkExistingData = sqliteOperations.CheckIfAnySyncupDataIsAvailable();
                                    if (checkExistingData)
                                    {
                                        DependencyService.Get<ISyncDataWhileInternetAvailable>().IRegisterIOSService();
                                        DependencyService.Get<ISyncDataWhileInternetAvailable>().IStartAlarmService();
                                    }

                                    CallDashboardPage();
                                    // await UserDialogs.Instance.AlertAsync("Feedback Added Successfully...! Thank You");
                                    //Application.Current.MainPage = new NavigationPage(new ExamCompleted());


                                }
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message);
                                SendErrorMessageToServer(ex, "ProctoredFeedbackViewModel.DoOperation.Submit");
                            }

                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });

                    break;
                #endregion


     

                #region Option Tap Command
                case "tpgOptionA":
                    OptionARadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    qustion1ans = "Exceeded Expectations";
                    break;

                case "tpgOptionB":
                    OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    qustion1ans = "Improvements Needed";
                    break;

                case "tpgOptionC":
                    OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    qustion1ans = "Expectations";
                    break;

                case "tpgOptionD":
                    OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    qustion1ans = "Failed To Meet Expectations";
                    break;
                #endregion


                #region Option Tap Command
                case "tpgOptionAtwo":
                    OptionARadiobuttontwo = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionBRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    qustion2ans = "Exceeded Expectations";
                    break;

                case "tpgOptionBtwo":
                    OptionARadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobuttontwo = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionCRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    qustion2ans = "Improvements Needed";
                    break;

                case "tpgOptionCtwo":
                    OptionARadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobuttontwo = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionDRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    qustion2ans = "Expectations";
                    break;

                case "tpgOptionDtwo":
                    OptionARadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobuttontwo = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    qustion2ans = "Failed To Meet Expectations";
                    break;
                #endregion


                #region Option Tap Command
                case "tpgOptionAthree":
                    OptionARadiobuttonthree = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionBRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    qustion3ans = "Exceeded Expectations";
                    break;

                case "tpgOptionBthree":
                    OptionARadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobuttonthree = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionCRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    qustion3ans = "Improvements Needed";
                    break;

                case "tpgOptionCthree":
                    OptionARadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobuttonthree = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionDRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    qustion3ans = "Expectations";
                    break;

                case "tpgOptionDthree":
                    OptionARadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobuttonthree = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    qustion3ans = "Failed To Meet Expectations";
                    break;
                    #endregion
            }
        }
        #endregion


        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
        private void CallDashboardPage()
        {
            SqliteOperations SycnDataClass = new SqliteOperations();
            //Need to check is all record sync with server
            if (!SycnDataClass.CheckIfAnySyncupDataIsAvailable())
            {
                SycnDataClass.DeleteAllLocalRecords();
            }
            Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
            return;
        }

        public async void SubmitFeedbackToAPI()
        {
            try
            {
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {

                   // UserDialogs.Instance.ShowLoading("Loading.., Please wait.");
                    UserDialogs.Instance.ShowLoading();
                    var SycnDataClass = new SqliteOperations();
                    await SycnDataClass.BulkInsert("Auto");
                    //await SycnDataClass.BulkDataAndUploadToServer();
                    UserDialogs.Instance.HideLoading();

                    if (AppPreferences.IsHindi)
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.FeedbackSuccessHindi, null, MessageStringConstants.OKHindi);
                    }
                    else
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.FeedbackSuccess);
                    }

                    MessagingCenter.Send(this, "StartSyncSerivce", "Syncronization started from Internet availability ");
                    CallDashboardPage();
                    //Application.Current.MainPage = new NavigationPage(new ExamCompleted());
                    //var request = new FeedBackModelRequest();
                    //request.HireMeeID = Application.Current.Properties[AppPreferenceKey.HireMeeID] as string;
                    //request.AssignedID = Application.Current.Properties[AppPreferenceKey.AssignedID] as string;
                    //request.AutoID = Application.Current.Properties[AppPreferenceKey.AutoID] as string;
                    //request.ExamCenter = Application.Current.Properties[AppPreferenceKey.ExamCenterName] as string;
                    //request.ExamName = Application.Current.Properties[AppPreferenceKey.ExamName] as string;
                    //request.Feedback1 = qustion1ans;
                    //request.Feedback2 = qustion2ans;
                    //request.Feedback3 = qustion3ans;

                    //var result = await _commonservice.PostAsync<FeedBackModelResponse, FeedBackModelRequest>(APIData.BASE_URL + APIMethods.InsertFeedBack, request);
                    //UserDialogs.Instance.HideLoading();
                    //if (result != null)
                    //{
                    //    if (result.StatusCode == "200")
                    //    {
                    //        UserDialogs.Instance.HideLoading();
                    //        await UserDialogs.Instance.AlertAsync("Feedback Added Successfully...! Thank You");
                    //        // UserDialogs.Instance.Alert(result.StatusMessage);
                    //        Application.Current.MainPage = new NavigationPage(new ExamCompleted());
                    //    }
                    //    else
                    //    {
                    //        UserDialogs.Instance.HideLoading();
                    //       await UserDialogs.Instance.AlertAsync(result.StatusMessage);
                    //    }
                    //}
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "ProctoredFeedbackViewModel.SubmitFeedbackToAPI");
            }
        }



        public void AddFeebackOffline()
        {
            //if (Application.Current.Properties[AppPreferenceKey.AssignedID] != null)
            if (!string.IsNullOrEmpty(AppPreferences.AssignedID))
            {
              //  _localDB.DeletePreviousFeedbacks();
                _feedbackData.AssignedID = AppPreferences.AssignedID;//Application.Current.Properties[AppPreferenceKey.AssignedID] as string;
                _feedbackData.Feedback1 = qustion1ans;
                _feedbackData.Feedback2 = qustion2ans;
                _feedbackData.Feedback3 = qustion3ans;
                _feedbackData.Comments = string.Empty;
                _feedbackData.IsSynchedUp = false;
                _localDB.UpdateFeedbackModel(_feedbackData);
            }
            else
            {
                UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
            }
        }


        private string _optionARadiobutton;
        public string OptionARadiobutton
        {
            get { return _optionARadiobutton; }
            set { _optionARadiobutton = value; OnPropertyChanged(); }
        }
        private string _optionBRadiobutton;
        public string OptionBRadiobutton
        {
            get { return _optionBRadiobutton; }
            set { _optionBRadiobutton = value; OnPropertyChanged(); }
        }
        private string _optionCRadiobutton;
        public string OptionCRadiobutton
        {
            get { return _optionCRadiobutton; }
            set { _optionCRadiobutton = value; OnPropertyChanged(); }
        }
        private string _optionDRadiobutton;
        public string OptionDRadiobutton
        {
            get { return _optionDRadiobutton; }
            set { _optionDRadiobutton = value; OnPropertyChanged(); }
        }



        private string _optionARadiobuttontwo;
        public string OptionARadiobuttontwo
        {
            get { return _optionARadiobuttontwo; }
            set { _optionARadiobuttontwo = value; OnPropertyChanged(); }
        }
        private string _optionBRadiobuttontwo;
        public string OptionBRadiobuttontwo
        {
            get { return _optionBRadiobuttontwo; }
            set { _optionBRadiobuttontwo = value; OnPropertyChanged(); }
        }
        private string _optionCRadiobuttontwo;
        public string OptionCRadiobuttontwo
        {
            get { return _optionCRadiobuttontwo; }
            set { _optionCRadiobuttontwo = value; OnPropertyChanged(); }
        }
        private string _optionDRadiobuttontwo;
        public string OptionDRadiobuttontwo
        {
            get { return _optionDRadiobuttontwo; }
            set { _optionDRadiobuttontwo = value; OnPropertyChanged(); }
        }


        private string _optionARadiobuttonthree;
        public string OptionARadiobuttonthree
        {
            get { return _optionARadiobuttonthree; }
            set { _optionARadiobuttonthree = value; OnPropertyChanged(); }
        }
        private string _optionBRadiobuttonthree;
        public string OptionBRadiobuttonthree
        {
            get { return _optionBRadiobuttonthree; }
            set { _optionBRadiobuttonthree = value; OnPropertyChanged(); }
        }
        private string _optionCRadiobuttonthree;
        public string OptionCRadiobuttonthree
        {
            get { return _optionCRadiobuttonthree; }
            set { _optionCRadiobuttonthree = value; OnPropertyChanged(); }
        }
        private string _optionDRadiobuttonthree;
        public string OptionDRadiobuttonthree
        {
            get { return _optionDRadiobuttonthree; }
            set { _optionDRadiobuttonthree = value; OnPropertyChanged(); }
        }

        private string _Question1;
        public string Question1
        {
            get { return _Question1; }
            set { _Question1 = value; OnPropertyChanged(); }
        }

        private string _Question2;
        public string Question2
        {
            get { return _Question2; }
            set { _Question2 = value; OnPropertyChanged(); }
        }

        private string _Question3;
        public string Question3
        {
            get { return _Question3; }
            set { _Question3 = value; OnPropertyChanged(); }
        }
        private string _QusNo;
        public string QusNo
        {
            get { return _QusNo; }
            set { _QusNo = value; OnPropertyChanged(); }

        }




        private string _qustion3ans;
        public string qustion3ans
        {
            get { return _qustion3ans; }
            set { _qustion3ans = value; OnPropertyChanged(); }
        }

        private bool _ProctoredThirdQuestion;
        public bool ProctoredThirdQuestion
        {
            get { return _ProctoredThirdQuestion; }
            set { _ProctoredThirdQuestion = value; OnPropertyChanged(); }
        }
        private bool _AutoProctoredThirdQuestion;
        public bool AutoProctoredThirdQuestion
        {
            get { return _AutoProctoredThirdQuestion; }
            set { _AutoProctoredThirdQuestion = value; OnPropertyChanged(); }
        }
    }
}
