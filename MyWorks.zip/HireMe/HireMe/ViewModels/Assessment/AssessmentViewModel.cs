﻿using MvvmHelpers;
using System;
using GalaSoft.MvvmLight.Command;
using System.Windows.Input;
using Xamarin.Forms;
using Acr.UserDialogs;
using System.Threading;
using HireMe.Views.Assessment;
using Plugin.Connectivity;
using HireMe.Models.Assessment;
using Rg.Plugins.Popup.Services;
using System.Threading.Tasks;
using HireMe.Accordion;
using System.Collections.Generic;
using System.Linq;
using HireMe.LocalDataBase;
using HireMe.Models.Assessment.SQLTables;
using Newtonsoft.Json;
using System.Diagnostics;
using HireMe.Helpers;
using HireMe.Interface;
using System.Net;
using System.Text.RegularExpressions;

namespace HireMe.ViewModels.Assessment
{
    public class AssessmentViewModel : BaseViewModel
    {
        #region Variable Declaration
        string selectedOption = string.Empty;
        private List<EnglishGroupDetail> _ListOfDataToAccoridanView;
        public List<EnglishGroupDetail> ListOfDataToAccoridanView
        {
            get { return _ListOfDataToAccoridanView; }
            set { _ListOfDataToAccoridanView = value; OnPropertyChanged(); }
        }


        public LocalDB _localDB;
        public INavigation NavigationService { get; set; }
        List<EnglishQuestion> itemQuestion;
        public bool isClicked = true;
        TimeSpan _ServerTime = new TimeSpan();
        public EnglishQuestion _questiondata;
        CancellationTokenSource cancellationTokenSource;
        ExternalDeviceStatusViewModel objExternalDeviceStatusViewModel;
        string lastFaceCroppedServerTime = String.Empty;
        public ExamAnswersModel _ExamAnswerData;
        public ExamAnswerHistoryModel _ExamAnswerHistoryData;
        public ExamGroupModel _ExamGroupModel;

       // int alertCount = 0;
        DateTime lastQuestionViewedDateTime;
        string lastQuestionViewedServerTime = String.Empty;
        string questionType = String.Empty;


        int NotVisitedCount = 0;
        int AnswerCount = 0;
        int NotAnswerCount = 0;
        public ICommand OnCommand { get; set; }
        private string ExamGroupID;
        TimeSpan _Examtime;


        public List<ExamAnswersModel> ExamAnswerList { get; set; }
        public List<ExamAnswerHistoryModel> ExamAnswersHistoryList { get; set; }
        public List<ExamGroupModel> ExamAssignedGroupList { get; set; }

        private HttpCommonService _commonservice { get; set; }
        CancellationTokenSource _CancellationTokenSource;
        public INavigation navigationService { get; set; }


        private ScrollView synamciButtonScrollView;
        public ScrollView DynamciButtonScrollView
        {
            get
            {

                return synamciButtonScrollView;
            }
            set
            {

                synamciButtonScrollView = value;

            }
        }

        #endregion

        #region Constructor
        public AssessmentViewModel(INavigation navigation, StackLayout dynamicBtnStack, StackLayout accordianStack, ScrollView dynamicBtnScroll)
        {
            NavigationService = navigation;
            IsVisibleGroupOfExamName = false;
            IsVisibleDownTimer = false;
            cancellationTokenSource = new CancellationTokenSource();
            _localDB = new LocalDB();
            objExternalDeviceStatusViewModel = new ExternalDeviceStatusViewModel();
            //alertCount = int.Parse(AppPreferences.FaceNotDetectedAlertCount);
            TimerStart();
            DynamicBtnStack = dynamicBtnStack;
            AccoridanStack = accordianStack;
            OnCommand = new RelayCommand<string>(DoOperation);
            _CancellationTokenSource = new CancellationTokenSource();
            _commonservice = new HttpCommonService();
            navigationService = navigation;
            ArrowChange = (string)Application.Current.Resources["UpArrowIcon"];
            IsShowCameraPreView = true;
            IsClickToCompleteButton = false;

            if (int.Parse(AppPreferences.PreferredLanguageCount) > 1)
            {
                IsShowPreferredLanguageToggle = true;
            }
            else
            {
                IsShowPreferredLanguageToggle = false;
            }
            DynamciButtonScrollView = dynamicBtnScroll;
            if (AppPreferences.IsHindi == true)
            {
                bindSelectedLanguage = "हिंदी";
                PreferredLanguage = "पसंदीदा भाषा";
                IsToggledLanguage = false;
            }
            else //if (AppPreferences.IsEnglish == true)
            {
                bindSelectedLanguage = "English";
                PreferredLanguage = "Preferred Language";
                IsToggledLanguage = true;
            }

            try
            {
                CandidateHireMeeID = AppPreferences.HireMeeID;
                UserProfilePicture = AppPreferences.ProfilePicture;
                if (String.IsNullOrEmpty(UserProfilePicture))
                {
                    UserProfilePicture = "userimage.png";
                }
                CandidateName = AppPreferences.userName;
                ExamName = AppPreferences.ExamName;
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "AssessmentViewModel.Constructor");
            }


            if (Device.RuntimePlatform == Device.iOS)
            {
                IsShowIOSOnly = true;
            }
            else
            {
                IsShowIOSOnly = false;
            }

            AppPreferences.IsActivityDestroy = "false";
            NextButtonColor = "#8fc740";

            var test = _localDB.GetAllData();
            string noofques = AppPreferences.NoOfQuestions;
            int NoOfQueCount = int.Parse(noofques);
            if (test.Count() != 0)
            {
                if (test.Count() == NoOfQueCount && NoOfQueCount != 0)
                {
                    IsRefreshVisible = false;
                }
                else
                {
                    IsRefreshVisible = true;
                }
            }
            else
            {
                IsRefreshVisible = true;
            }
            IsVisbleExamSelectionPart = true;
            IsVisbleExaminationPart = false;
            BindingDataToAccordianView();

            //#region Check Battery
            //CrossBattery.Current.BatteryChanged += async (sender, args) =>
            //{
            //    var _batteryLevel = args.RemainingChargePercent;
            //    var _checkEveryFivePercentage = _batteryLevel % 5;
            //    var _chargingStatus = args.Status.ToString();
            //    if (_batteryLevel <= 30 && _checkEveryFivePercentage == 0 && _chargingStatus != "Charging")
            //    {
            //        await UserDialogs.Instance.AlertAsync(MessageStringConstants.BatteryLowMessage);
            //    }
            //};
            //#endregion




            #region Intenet Connected or DisConnected at the time following method
            if (Device.RuntimePlatform == Device.iOS)
            {
                //Internet Connected 
                CrossConnectivity.Current.ConnectivityChanged += (sender, result) =>
                 {
                     if (result.IsConnected)
                     {
                         SqliteOperations sqliteOperations = new SqliteOperations();
                         //Need to check is all record sync with server
                         if (sqliteOperations.CheckIfAnySyncupDataIsAvailable())
                         {
                             MessagingCenter.Send(this, "StartSyncSerivce", "Syncronization started from manual Data sync");
                         }
                     }
                 };
            }
            #endregion

            MessagingCenter.Subscribe<ExpandableViewTemplate, string[]>(this, "ExpandableViewTemplate", (sender, arg) =>
            {

                #region behaviouralexaminationpage
                if (arg[0].Equals("behaviouralexaminationpage"))
                {
                    ExamGroupID = arg[1];
                    GroupOfExamName = arg[2];
                    string TotalQue = arg[3];
                    _localDB = new LocalDataBase.LocalDB();
                    _ExamAnswerData = new ExamAnswersModel();
                    _ExamAnswerHistoryData = new ExamAnswerHistoryModel();
                    _ExamGroupModel = new ExamGroupModel();


                    ExamAnswerList = new List<ExamAnswersModel>();
                    ExamAnswersHistoryList = new List<ExamAnswerHistoryModel>();
                    _commonservice = new HttpCommonService();
                    _questiondata = new EnglishQuestion();
                    OnCommand = new RelayCommand<string>(DoOperation);
                    faQuestion1 = (string)Application.Current.Resources["RadioButtonIcon"];
                    faQuestion2 = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    ExamName = AppPreferences.ExamName;//Application.Current.Properties[AppPreferenceKey.ExamName] as string;
                    ArrowChange = (string)Application.Current.Resources["UpArrowIcon"];
                    QuestionOneRadioColor = Color.Black;
                    QuestionTwoRadioColor = Color.Black;
                    QuestionOneTextColor = Color.Black;
                    QuestionTwoTextColor = Color.Black;
                    IsOptionVisible = false;
                    CurrentPosition = GetLastQuestionViewedPositionInExamGroupTable();
                    CurrentQue = CurrentPosition + 1;
                    if (AppPreferences.IsHindi == true)
                    {
                        var data = _localDB.GetAllHindiDataBasedOnGroupId("4");
                        lastindex = int.Parse(data.Count().ToString());
                    }
                    else //if (AppPreferences.IsEnglish == true)
                    {
                        var data = _localDB.GetAllDataBasedOnGroupId("4");
                        lastindex = int.Parse(data.Count().ToString());
                    }

                    ShowPreviousandNextButton();

                    //InsertAnswerTable();
                    GetExamStatus();
                    UpdateAssignedExam();
                    LoadBehaviourQuestions();
                    DoOperation("showbehaviourexamination");


                }
                #endregion

                #region normalexaminationpage
                else if (arg[0].Equals("normalexaminationpage"))
                {




                    ExamGroupID = arg[1];
                    GroupOfExamName = arg[2];
                    string TotalQue = arg[3];
                    itemQuestion = new List<EnglishQuestion>();
                    ExamAnswerList = new List<ExamAnswersModel>();
                    ExamAnswersHistoryList = new List<ExamAnswerHistoryModel>();
                    ExamAssignedGroupList = new List<ExamGroupModel>();
                    _commonservice = new HttpCommonService();
                    ButtonColorNotVisited = Color.FromHex("#ebebeb");
                    ButtonColorAnswerwed = Color.Green;
                    ButtonColorNotAnswerwed = Color.Red;

                    ExamName = AppPreferences.ExamName;//Application.Current.Properties[AppPreferenceKey.ExamName] as string;
                    OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    ArrowChange = (string)Application.Current.Resources["UpArrowIcon"];
                    IsQueImage = false;
                    IsQueContent = false;

                    _localDB = new LocalDataBase.LocalDB();
                    _ExamAnswerData = new ExamAnswersModel();
                    _ExamAnswerHistoryData = new ExamAnswerHistoryModel();
                    _ExamGroupModel = new ExamGroupModel();
                    _Examtime = new TimeSpan();
                    _questiondata = new EnglishQuestion();
                    _questiondata.UserKeyed = string.Empty;
                    CurrentPosition = GetLastQuestionViewedPositionInExamGroupTable();
                    CurrentQue = CurrentPosition + 1;
                    lastindex = int.Parse(TotalQue);
                    ShowPreviousandNextButton();

                    //InsertAnswerTable();
                    GetExamStatus();
                    UpdateAssignedExam();
                    LoadQuestionFromLocal();
                    //  LoadButtonColorFromCunstructorCall();//need for proctored exam
                    GeneratePageNumbers();
                    DoOperation("showexamination");


                }
                #endregion
            });

            if (!string.IsNullOrEmpty(AppPreferences.HintStack))
            {
                //if (Application.Current.Properties[AppPreferenceKey.HintStack] as string == "HintVisited")
                if (AppPreferences.HintStack == "HintVisited")
                {
                    IsHintStack = false;
                }
                else
                {
                    IsHintStack = true;
                }
            }
            else
            {
                IsHintStack = true;
            }

            lastQuestionViewedServerTime = String.Empty;

            CheckAllGroupAreCompletedOrNot();
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        #region LoadBehaviourQuestions
        private void LoadBehaviourQuestions()
        {
            try
            {
                var data = _localDB.GetAllDataBasedOnGroupId("4");
                var Hindidata = _localDB.GetAllHindiQuesitonsByGroupId(ExamGroupID);
                lastindex = int.Parse(data.Count().ToString());
                ListViewItemSource = new List<EnglishQuestion>(data);
                if (AppPreferences.IsHindi == true)
                {
                    lastindex = int.Parse(Hindidata.Count().ToString());
                    ListViewItemSource = new List<EnglishQuestion>(Hindidata);
                    StronglyAgree = "पूरी तरह सहमत";
                    Agree = "सहमत";
                    NotSure = "अनिश्चित";
                    Disagree = "असहमत";
                    StrongDisagree = "पूरी तरह से असहमत";
                }
                else //if (AppPreferences.IsEnglish == true)
                {
                    lastindex = int.Parse(data.Count().ToString());
                    ListViewItemSource = new List<EnglishQuestion>(data);
                    StronglyAgree = "StronglyAgree";
                    Agree = "Agree";
                    NotSure = "NotSure";
                    Disagree = "Disagree";
                    StrongDisagree = "StrongDisagree";
                }

                if (int.Parse(AppPreferences.PreferredLanguageCount) > 1)
                {
                    IsShowPreferredLanguageToggle = true;
                }
                else
                {
                    IsShowPreferredLanguageToggle = false;
                }
                UpdateExamGroupStatus();
                BehaviourLoadQuestions();
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "AssessmentViewModel.LoadBehaviourQuestions");
            }

        }


        #endregion

        #region InsertAnswerTable
        private void InsertAnswerTable()
        {
            var res = _localDB.GetAllDataBasedOnGroupId(ExamGroupID.ToString());
            if (res.Count() > 0)
            {
                var IsThereGroupId = _localDB.IsGroupAlreadyExist(ExamGroupID.ToString());
                if (IsThereGroupId.Count() == 0)
                {
                    foreach (var item in res)
                    {
                        //Insert Data in Answer Table
                        _ExamAnswerData.QuestionID = item.QuestionId;
                        _ExamAnswerData.GroupId = item.GroupID.ToString();
                        _ExamAnswerData.UserAnswer = string.Empty;
                        _ExamAnswerData.AdminMark = string.Empty;
                        _ExamAnswerData.IsSynchedUp = false;
                        _ExamAnswerData.LastUpdatedTime = ServerTimerText;
                        _ExamAnswerData.AssignedID = AppPreferences.AssignedID;//Application.Current.Properties[AppPreferenceKey.AssignedID].ToString();
                        _ExamAnswerData.Status = MessageStringConstants.NotVisited;
                        if (AppPreferences.IsHindi)
                        {
                            _ExamAnswerData.LanguageMode = "Hindi";
                        }
                        else //if (AppPreferences.IsEnglish)
                        {
                            _ExamAnswerData.LanguageMode = "English";
                        }
                        _localDB.AddExamAnswer(_ExamAnswerData);
                    }
                }
            }
        }
        #endregion

        #region Binding Data To Accordian View
        private async void BindingDataToAccordianView()
        {
            try
            {


                int count = AccoridanStack.Children.Count;

                if (count > 1)
                {
                    AccoridanStack.Children.RemoveAt(1);
                }

                //var request = new GroupDetailsRequest();
                //request.HireMeeID = Application.Current.Properties[AppPreferenceKey.HireMeeID] as string;
                //request.ExamID = Application.Current.Properties[AppPreferenceKey.ExamID] as string;
                //request.AssignedID = Application.Current.Properties[AppPreferenceKey.AssignedID] as string;

                var serializedData = AppPreferences.GroupDetailsSerialize;//Application.Current.Properties[AppPreferenceKey.GroupDetailsSerialize] as string;
                //serializedData = null;
                if (serializedData != null)
                {
                    List<EnglishGroupDetail> deSerializedData = JsonConvert.DeserializeObject<List<EnglishGroupDetail>>(serializedData);
                    if (deSerializedData != null)
                    {

                        var template = new DataTemplate(typeof(ExpandableViewTemplate));
                        AccordionView accordionView = new AccordionView(template);
                        ListOfDataToAccoridanView = new List<EnglishGroupDetail>();
                        
                        if (!string.IsNullOrEmpty(AppPreferences.ExamDuration))
                        {
                            IsRefreshVisible = false;
                            //AppPreferences.IsFromRefreshButtonClick = false;
                            var examDuration = AppPreferences.ExamDuration;
                            if (examDuration != null)
                            {
                                TotalDuration = AppPreferences.ExamDuration;
                            }

                            ListOfDataToAccoridanView = deSerializedData;

                            accordionView.Template.SetBinding(AccordionSectionView.TitleProperty, "GroupName");
                            accordionView.Template.SetBinding(AccordionSectionView.TitleStatusColorProperty, "TitleStatusColor");
                            accordionView.Template.SetBinding(AccordionSectionView.ItemsSourceProperty, "QuestionGroupStatus");

                            accordionView.ItemsSource = ListOfDataToAccoridanView;
                            AccoridanStack.Children.Add(accordionView);





                        }
                        else
                        {
                            //await objExternalDeviceStatusViewModel.DownloadQuestions();
                            //BindingDataToAccordianView();
                            IsRefreshVisible = true;
                            IsVisbleExamSelectionPart = false;
                            IsVisbleExaminationPart = false;
                            IsVisbleBehaviourExamSelectionPart = false;
                        }
                    }
                    else
                    {
                        //await objExternalDeviceStatusViewModel.DownloadQuestions();
                        //BindingDataToAccordianView();
                        IsRefreshVisible = true;
                        IsVisbleExamSelectionPart = false;
                        IsVisbleExaminationPart = false;
                        IsVisbleBehaviourExamSelectionPart = false;
                    }
                }
                else
                {
                    // await objExternalDeviceStatusViewModel.DownloadQuestions();
                    //BindingDataToAccordianView();
                    IsRefreshVisible = true;
                    IsVisbleExamSelectionPart = false;
                    IsVisbleExaminationPart = false;
                    IsVisbleBehaviourExamSelectionPart = false;

                }

            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "AssessmentViewModel.BindingDataToAccordianView");
            }
        }
        #endregion

        #region GeneratePageNumbers
        public void GeneratePageNumbers()
        {


            if (lastindex != 0)
            {
                int NoOfRows = lastindex;
                Button gridbutton = new Button();

                Grid grid = new Grid();



                int childrenCount = DynamicBtnStack.Children.Count;


                if (childrenCount > 1)
                    DynamicBtnStack.Children.RemoveAt(1);


                grid.VerticalOptions = LayoutOptions.Start;
                grid.HorizontalOptions = LayoutOptions.Fill;
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
                int count = 0;
                for (int r = 0; r < 1; r++)
                {
                    grid.RowDefinitions.Add(new RowDefinition { Height = 40 });
                    for (int c = 0; c < NoOfRows; c++)
                    {
                        if (NoOfRows > count)
                        {
                            count++;
                            if (Device.Idiom == TargetIdiom.Phone)
                            {
                                gridbutton = new Button
                                {
                                    Text = count.ToString(),
                                    TextColor = Color.Black,
                                    ClassId = count.ToString(),
                                    FontSize = 12,
                                    WidthRequest = 40
                                };
                            }
                            else if (Device.Idiom == TargetIdiom.Tablet)
                            {
                                gridbutton = new Button
                                {
                                    Text = count.ToString(),
                                    TextColor = Color.Black,
                                    ClassId = count.ToString(),
                                    FontSize = 18,
                                    WidthRequest = 60
                                };
                            }
                            gridbutton.SetBinding(Button.BackgroundColorProperty, "ButtonColor" + gridbutton.Text);

                            gridbutton.Clicked += Button_Clicked;
                            grid.Children.Add(gridbutton);

                            DynamicBtnStack.Children.Add(grid);

                            Grid.SetRow(gridbutton, r);
                            Grid.SetColumn(gridbutton, c);


                            Device.BeginInvokeOnMainThread(async () =>
                            {

                                await DynamciButtonScrollView.ScrollToAsync(0, 0, true);

                            });

                        }
                    }
                }
            }

        }
        #endregion

        #region Sequence Button Click Event
        private void Button_Clicked(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            string text = (string)button.Text;

            UpdateUserAnswerInAnswerTable();
            ChangeButtonColorSwitch(CurrentQue);
            CurrentQue = int.Parse(text);
            CurrentPosition = int.Parse(text) - 1;
            ShowPreviousandNextButton();

            LoadQuestions();
        }
        #endregion

        #region Command Operation
        private async void DoOperation(string obj)
        {
            switch (obj)
            {


                #region show multiple views
                case "showexamgroupselection":

                    BindingDataToAccordianView();

                    IsVisibleGroupOfExamName = false;
                    IsVisibleDownTimer = false;
                    IsVisbleExaminationPart = false;
                    IsVisbleBehaviourExamSelectionPart = false;


                    IsShowCameraPreView = true;
                    IsVisbleExamSelectionPart = true;
                    IsRefreshVisible = false;
                    lastQuestionViewedServerTime = String.Empty;
                    await CheckAllGroupAreCompletedOrNot();
                    break;
                #endregion

                #region show multiple views
                case "showexamination":

                    lastQuestionViewedServerTime = ServerTimerText;
                    lastQuestionViewedDateTime = DateTime.Parse(ServerTimerText);
                    questionType = "showexamination";

                    IsVisbleExamSelectionPart = false;
                    IsVisbleBehaviourExamSelectionPart = false;
                    IsRefreshVisible = false;
                    IsShowCameraPreView = true;
                    IsVisibleGroupOfExamName = true;

                    IsVisbleExaminationPart = true;


                    //if (Interface.AppPreferences.ExamMode == "True")
                    //{
                    //    IsVisibleDownTimer = true;
                    //}
                    //else
                    //{
                    //    IsVisibleDownTimer = false;
                    //}

                    break;
                #endregion

                #region show multiple views
                case "showbehaviourexamination":

                    lastQuestionViewedServerTime = ServerTimerText;
                    lastQuestionViewedDateTime = DateTime.Parse(ServerTimerText);
                    questionType = "showbehaviourexamination";

                    IsVisbleExamSelectionPart = false;
                    IsVisbleExaminationPart = false;
                    IsRefreshVisible = false;
                    IsShowCameraPreView = true;
                    IsVisibleGroupOfExamName = true;
                    IsVisibleDownTimer = false;
                    IsVisbleBehaviourExamSelectionPart = true;

                    break;
                #endregion

                #region Refresh Button Click
                case "refresh":
                    if (isClicked)
                    {
                        isClicked = false;
                        IsVisbleExamSelectionPart = true;
                        IsVisbleExaminationPart = false;
                        IsRefreshVisible = false;
                        IsShowCameraPreView = true;
                        IsVisibleGroupOfExamName = true;
                        IsVisbleBehaviourExamSelectionPart = false;
                        //AppPreferences.IsFromRefreshButtonClick = true;
                        await objExternalDeviceStatusViewModel.DownloadQuestions();
                        TimerStart();
                        BindingDataToAccordianView();

                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                #endregion

                #region Previous Button Click Event
                case "previousCommand":
                    if (isClicked)
                    {
                        isClicked = false;
                        try
                        {
                            UpdateUserAnswerInAnswerTable();
                            ChangeButtonColorSwitch(CurrentQue);
                            _questiondata.UserKeyed = string.Empty;
                            selectedOption = string.Empty;
                            CurrentPosition -= 1;
                            CurrentQue -= 1;
                            ShowPreviousandNextButton();
                            LoadQuestions();
                        }
                        catch (Exception ex)
                        {
                            System.Diagnostics.Debug.WriteLine(ex.Message);
                            SendErrorMessageToServer(ex, "AssessmentViewModel.DoOperation.previousCommand");
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                #endregion

                #region Next Button Click Event
                case "nextCommand":
                    if (isClicked)
                    {

                        isClicked = false;
                        try
                        {
                            if (AppPreferences.IsHindi == true)
                            {
                                bindSelectedLanguage = "हिंदी";
                                PreferredLanguage = "पसंदीदा भाषा";
                                IsToggledLanguage = false;
                            }
                            else //if (AppPreferences.IsEnglish == true)
                            {
                                bindSelectedLanguage = "English";
                                PreferredLanguage = "Preferred Language";
                                IsToggledLanguage = true;
                            }

                            lastQuestionViewedDateTime = DateTime.Parse(ServerTimerText);


                            if (CurrentQue != lastindex)
                            {
                                CurrentPosition += 1;
                                CurrentQue += 1;
                                ShowPreviousandNextButton();
                                UpdateUserAnswerInAnswerTable();
                                ChangeButtonColorSwitch(CurrentQue);
                                _questiondata.UserKeyed = string.Empty;
                                selectedOption = string.Empty;
                                OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                                OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                                OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                                OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                                LoadQuestions();

                            }
                            else
                            {
                                //its perform when submit button occurs

                                SubmitOrFinishButtonClickEvent("normal");
                            }



                        }
                        catch (Exception ex)
                        {
                            System.Diagnostics.Debug.WriteLine(ex.Message);
                            SendErrorMessageToServer(ex, "AssessmentViewModel.DoOperation.nextCommand");
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                #endregion

                #region Previous Button Command
                case "behaviourpreviousCommand":
                    if (isClicked)
                    {
                        isClicked = false;
                        try
                        {

                            BehaviourUpdateUserAnswerInAnswerTable();
                            _questiondata.UserKeyed = string.Empty;
                            selectedOption = string.Empty;
                            CurrentPosition -= 1;
                            CurrentQue -= 1;
                            ShowPreviousandNextButton();
                            BehaviourLoadQuestions();
                        }
                        catch (Exception ex)
                        {
                            SendErrorMessageToServer(ex, "AssessmentViewModel.DoOperation.behaviourpreviousCommand");
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                #endregion

                #region  behaviournextCommand
                case "behaviournextCommand":
                    if (isClicked)
                    {
                        isClicked = false;
                        try
                        {
                            lastQuestionViewedDateTime = DateTime.Parse(ServerTimerText);
                            if (!string.IsNullOrEmpty(_questiondata.UserKeyed) && !string.IsNullOrEmpty(selectedOption))
                            {
                                if (AppPreferences.IsHindi == true)
                                {
                                    bindSelectedLanguage = "हिंदी";
                                    PreferredLanguage = "पसंदीदा भाषा";
                                    IsToggledLanguage = false;
                                }
                                else //if (AppPreferences.IsEnglish == true)
                                {
                                    bindSelectedLanguage = "English";
                                    PreferredLanguage = "Preferred Language";
                                    IsToggledLanguage = true;
                                }
                                if (CurrentQue != lastindex)
                                {
                                    CurrentPosition += 1;
                                    CurrentQue += 1;
                                    ShowPreviousandNextButton();
                                    BehaviourUpdateUserAnswerInAnswerTable();
                                    _questiondata.UserKeyed = string.Empty;
                                    selectedOption = string.Empty;
                                    IsOptionVisible = false;
                                    QuestionOneRadioColor = Color.Black;
                                    QuestionTwoRadioColor = Color.Black;
                                    QuestionOneTextColor = Color.Black;
                                    QuestionTwoTextColor = Color.Black;

                                    BehaviourLoadQuestions();
                                }
                                else
                                {

                                    SubmitOrFinishButtonClickEvent("behaviour");

                                }


                            }
                            else
                            {
                                if (AppPreferences.IsHindi)
                                {
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.pleaseSelecteAnserHindi, null, MessageStringConstants.OKHindi);
                                }
                                else //if (AppPreferences.IsEnglish)
                                {
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.PleaseSelectAnswer);
                                }

                            }
                        }
                        catch (Exception ex)
                        {
                            System.Diagnostics.Debug.WriteLine(ex.Message);
                            SendErrorMessageToServer(ex, "AssessmentViewModel.DoOperation.behaviournextCommand");

                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });

                    break;

                #endregion

                //#region behaviourfinishCommand
                //case "behaviourfinishCommand":
                //    if (isClicked)
                //    {
                //        isClicked = false;
                //        BehaviourUpdateUserAnswerInAnswerTable();
                //        _questiondata.UserKeyed = string.Empty;
                //        selectedOption = string.Empty;
                //        SubmitOrFinishButtonClickEvent();
                //    }
                //    await Task.Run(async () =>
                //    {
                //        await Task.Delay(500);
                //        isClicked = true;
                //    });
                //    break;
                //#endregion

                #region behaviourbackCommand
                case "behaviourbackCommand":
                    if (isClicked)
                    {
                        isClicked = false;
                        BehaviourUpdateUserAnswerInAnswerTable();
                        _questiondata.UserKeyed = string.Empty;
                        selectedOption = string.Empty;
                        CallBackPage();
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                #endregion

                #region Radio Button Click Event
                case "tpgOptionA":
                    OptionARadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    _questiondata.UserKeyed = "A";
                    break;
                case "tpgOptionB":
                    OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    _questiondata.UserKeyed = "B";
                    break;
                case "tpgOptionC":
                    OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    _questiondata.UserKeyed = "C";
                    break;
                case "tpgOptionD":
                    OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    _questiondata.UserKeyed = "D";
                    break;
                #endregion

                #region Option Question Tap Command
                case "tpgQuestion1":
                    faQuestion1 = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    faQuestion2 = (string)Application.Current.Resources["RadioButtonIcon"];
                    IsOptionVisible = true;
                    QuestionOneRadioColor = Color.FromHex("#B3E27C");
                    QuestionOneTextColor = Color.FromHex("#B3E27C");
                    QuestionTwoRadioColor = Color.Black;
                    QuestionTwoTextColor = Color.Black;
                    _questiondata.UserKeyed = "A";
                    selectedOption = string.Empty;
                    OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    break;
                case "tpgQuestion2":
                    faQuestion1 = (string)Application.Current.Resources["RadioButtonIcon"];
                    faQuestion2 = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    IsOptionVisible = true;
                    QuestionOneRadioColor = Color.Black;
                    QuestionOneTextColor = Color.Black;
                    QuestionTwoRadioColor = Color.FromHex("#B3E27C");
                    QuestionTwoTextColor = Color.FromHex("#B3E27C");
                    _questiondata.UserKeyed = "B";
                    selectedOption = string.Empty;
                    OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    break;
                #endregion

                #region Option Tap Command
                case "behaviourtpgOptionA":
                    OptionARadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    //_questiondata.UserKeyed = "OptionA";
                    selectedOption = "A";
                    break;
                case "behaviourtpgOptionB":
                    OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    // _questiondata.UserKeyed = "OptionB";
                    selectedOption = "B";
                    break;
                case "behaviourtpgOptionC":
                    OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    // _questiondata.UserKeyed = "OptionC";
                    selectedOption = "C";
                    break;
                case "behaviourtpgOptionD":
                    OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    // _questiondata.UserKeyed = "OptionD";
                    selectedOption = "D";
                    break;
                case "behaviourtpgOptionE":
                    OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionERadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    //_questiondata.UserKeyed = "OptionE";
                    selectedOption = "E";
                    break;
                #endregion

                case "backCommand":
                    if (isClicked)
                    {
                        isClicked = false;
                        UpdateUserAnswerInAnswerTable();
                        _questiondata.UserKeyed = string.Empty;
                        selectedOption = string.Empty;
                        CallBackPage();
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                //case "finishCommand":
                //    if (isClicked)
                //    {
                //        isClicked = false;
                //        UpdateUserAnswerInAnswerTable();
                //        _questiondata.UserKeyed = string.Empty;
                //        selectedOption = string.Empty;
                //        ChangeButtonColorSwitch(CurrentQue);
                //        SubmitOrFinishButtonClickEvent();
                //    }
                //    await Task.Run(async () =>
                //    {
                //        await Task.Delay(500);
                //        isClicked = true;
                //    });
                //    break;

                case "tpgShowCameraPreviewCommand":
                    if (isClicked)
                    {
                        isClicked = false;
                        if (IsShowCameraPreView == true)
                        {
                            ArrowChange = (string)Application.Current.Resources["DownArrowIcon"];
                            IsShowCameraPreView = false;
                        }
                        else if (IsShowCameraPreView == false)
                        {
                            ArrowChange = (string)Application.Current.Resources["UpArrowIcon"];
                            IsShowCameraPreView = true;
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                case "tpgHintStack":
                    //Application.Current.Properties[AppPreferenceKey.HintStack] = "HintVisited";
                    AppPreferences.HintStack = "HintVisited";
                    await Application.Current.SavePropertiesAsync();
                    IsHintStack = false;
                    break;

                #region iconselect Button Click Event
                case "iconselect":
                    if (isClicked)
                    {
                        isClicked = false;
                        await PopupNavigation.PushAsync(new PoupExamInstructionPage());
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                #endregion

                #region behaviourbackCommand
                case "FinishTheExam":
                    if (isClicked)
                    {
                        isClicked = false;
                        await FinishEntireExam();
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                #endregion

                #region Image Zoom Tap Event
                case "tpgQuestions":
                    var page = new ZoomImageViewPage(Question);
                    await PopupNavigation.PushAsync(page);
                    break;
                case "tpgZoomOptionA":
                    var pageA = new ZoomImageViewPage(OptionA);
                    await PopupNavigation.PushAsync(pageA);
                    break;
                case "tpgZoomOptionB":
                    var pageB = new ZoomImageViewPage(OptionB);
                    await PopupNavigation.PushAsync(pageB);
                    break;
                case "tpgZoomOptionC":
                    var pageC = new ZoomImageViewPage(OptionC);
                    await PopupNavigation.PushAsync(pageC);
                    break;
                case "tpgZoomOptionD":
                    var pageD = new ZoomImageViewPage(OptionD);
                    await PopupNavigation.PushAsync(pageD);
                    break;
                    #endregion
            }
        }
        #endregion

        #region GetExamStatus
        public void GetExamStatus()
        {
            try
            {
                var answer = _localDB.GetAnsweredStatus(ExamGroupID, MessageStringConstants.Answered);
                var notanswer = _localDB.GetAnsweredStatus(ExamGroupID, MessageStringConstants.NotAnswered);

                if (AppPreferences.IsHindi)
                {
                    if (int.Parse(ExamGroupID) == 1)
                    {
                        var NoOfQuestions = _localDB.GetAllDataBasedOnGroupId(ExamGroupID);
                        int notvisited = Convert.ToInt32(NoOfQuestions.Count()) - Convert.ToInt32(answer.Count()) - Convert.ToInt32(notanswer.Count());
                        NotVisitedCount = notvisited;
                        Answered = "उत्तर दे दिया है[" + answer.Count() + "]";
                        NotAnswered = "उत्तर नहिं दिया है[" + notanswer.Count() + "]";
                        NotVisited = "नहीं देखा है[" + notvisited.ToString() + "]";
                    }
                    else
                    {
                        var NoOfQuestions = _localDB.GetAllHindiDataBasedOnGroupId(ExamGroupID);
                        int notvisited = Convert.ToInt32(NoOfQuestions.Count()) - Convert.ToInt32(answer.Count()) - Convert.ToInt32(notanswer.Count());
                        NotVisitedCount = notvisited;
                        Answered = "उत्तर दे दिया है[" + answer.Count() + "]";
                        NotAnswered = "उत्तर नहिं दिया है[" + notanswer.Count() + "]";
                        NotVisited = "नहीं देखा है[" + notvisited.ToString() + "]";
                    }

                }
                else //if (AppPreferences.IsEnglish)
                {
                    var NoOfQuestions = _localDB.GetAllDataBasedOnGroupId(ExamGroupID);
                    int notvisited = Convert.ToInt32(NoOfQuestions.Count()) - Convert.ToInt32(answer.Count()) - Convert.ToInt32(notanswer.Count());
                    NotVisitedCount = notvisited;
                    Answered = "Answered[" + answer.Count() + "]";
                    NotAnswered = "Not Answered[" + notanswer.Count() + "]";
                    NotVisited = "Not Visited[" + notvisited.ToString() + "]";
                }

                AnswerCount = answer.Count();
                NotAnswerCount = notanswer.Count();

                var serializedData = AppPreferences.GroupDetailsSerialize;
                List<EnglishGroupDetail> deSerializedData = JsonConvert.DeserializeObject<List<EnglishGroupDetail>>(serializedData);
                List<EnglishGroupDetail> objGroupDetails = new List<EnglishGroupDetail>();
                objGroupDetails = deSerializedData;
                for (int i = 0; i < objGroupDetails.Count; i++)
                {

                    if (objGroupDetails[i].GroupID == ExamGroupID)
                    {
                        // objGroupDetails[i].TitleStatusColor = completedStatus;
                        objGroupDetails[i].QuestionGroupStatus[0].AnsweredQuestion = AnswerCount.ToString();
                        objGroupDetails[i].QuestionGroupStatus[0].UnAnsweredQuestions = NotAnswerCount.ToString();
                        objGroupDetails[i].QuestionGroupStatus[0].NotVisitedQuestions = NotVisitedCount.ToString();
                    }
                }
                var serializeValue = JsonConvert.SerializeObject(objGroupDetails);
                AppPreferences.GroupDetailsSerialize = serializeValue;

            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "AssessmentViewModel.GetExamStatus");
            }
        }
        #endregion

        #region UpdateUserAnswerInAnswerTable
        public void UpdateUserAnswerInAnswerTable()
        {
            try
            {
                var item = new ExamAnswersModel();

                if (_questiondata != null)
                {
                    if (!string.IsNullOrEmpty(_questiondata.UserKeyed))
                    {
                        item.Status = MessageStringConstants.Answered;
                        item.UserAnswer = _questiondata.UserKeyed;
                    }
                    else
                    {
                        item.Status = MessageStringConstants.NotAnswered;
                        item.UserAnswer = string.Empty;
                    }
                    item.GroupId = _questiondata.GroupID.ToString();
                    item.QuestionID = _questiondata.QuestionId;
                    item.AssignedID = AppPreferences.AssignedID;
                    item.LastUpdatedTime = ServerTimerText;
                    string actualAnswer = _questiondata.CorrectAnswer;
                    string userSelectedAnswer = _questiondata.UserKeyed;

                    item.Attempt = "1";
                    if (actualAnswer.Equals(userSelectedAnswer))
                    {
                        item.AdminMark = "1";
                    }
                    else
                    {
                        item.AdminMark = "0";
                    }
                    if (AppPreferences.IsHindi)
                    {
                        item.LanguageMode = "Hindi";
                    }
                    else //if (AppPreferences.IsEnglish)
                    {
                        item.LanguageMode = "English";
                    }

                    item.IsSynchedUp = false;
                    _localDB.UpdateExamAnswer(item);
                }
                //var res = _localDB.UpdateUserAnsweredTable(_questiondata.QuestionId);
                //if (res.Count() > 0)
                //{
                //    foreach (var item in res)
                //    {
                //item.UserAnswer = _questiondata.UserKeyed;
                //item.LastUpdatedTime = ServerTimerText;
                //string actualAnswer = _questiondata.CorrectAnswer;
                //string userSelectedAnswer = _questiondata.UserKeyed;
                //if (actualAnswer.Equals(userSelectedAnswer))
                //{
                //    item.AdminMark = "1";
                //}
                //else
                //{
                //    item.AdminMark = "0";
                //}
                //item.Status = MessageStringConstants.Answered;
                //item.IsSynchedUp = false;
                //        _localDB.UpdateExamAnswer(item);
                //    }
                //}
                //}
                //else
                //{
                //    var res = _localDB.UpdateUserAnsweredTable(_questiondata.QuestionId);
                //    if (res.Count() > 0)
                //    {
                //        foreach (var item in res)
                //        {
                //            item.Status = MessageStringConstants.NotAnswered;
                //            item.IsSynchedUp = false;
                //            _localDB.UpdateExamAnswer(item);
                //        }
                //    }
                //}
                GetExamStatus();
                InsertRecordInExamHistoryTable();
                UpdateAssignedExam();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "AssessmentViewModel.UpdateUserAnswerInAnswerTable");
            }
        }
        #endregion

        #region BehaviourUpdateUserAnswerInAnswerTable
        private void BehaviourUpdateUserAnswerInAnswerTable()
        {
            try
            {

                var item = new ExamAnswersModel();
                if (!string.IsNullOrEmpty(_questiondata.UserKeyed) && !string.IsNullOrEmpty(selectedOption))
                {
                    item.Status = MessageStringConstants.Answered;
                    item.UserAnswer = _questiondata.UserKeyed + "," + selectedOption;
                }
                else
                {
                    item.Status = MessageStringConstants.NotAnswered;
                    item.UserAnswer = string.Empty;
                }
                item.GroupId = _questiondata.GroupID.ToString();
                item.QuestionID = _questiondata.QuestionId;
                item.AssignedID = AppPreferences.AssignedID;

                item.LastUpdatedTime = ServerTimerText;
                string actualAnswer = _questiondata.CorrectAnswer;
                string userSelectedAnswer = _questiondata.UserKeyed + "," + selectedOption;
                item.Attempt = "1";
                if (actualAnswer.Equals(userSelectedAnswer))
                {
                    item.AdminMark = "1";
                }
                else
                {
                    item.AdminMark = "0";
                }
                if (AppPreferences.IsHindi)
                {
                    item.LanguageMode = "Hindi";
                }
                else //if (AppPreferences.IsEnglish)
                {
                    item.LanguageMode = "English";
                }
                item.IsSynchedUp = false;
                _localDB.UpdateExamAnswer(item);


                //if (!string.IsNullOrEmpty(_questiondata.UserKeyed))
                //{

                //    var res = _localDB.UpdateUserAnsweredTable(_questiondata.QuestionId);
                //    if (res.Count() > 0)
                //    {
                //        foreach (var item in res)
                //        {
                //            item.UserAnswer = _questiondata.UserKeyed + "," + selectedOption;
                //            item.LastUpdatedTime = ServerTimerText;
                //            string actualAnswer = _questiondata.CorrectAnswer;
                //            string userSelectedAnswer = _questiondata.UserKeyed + "," + selectedOption;
                //            if (actualAnswer.Equals(userSelectedAnswer))
                //            {
                //                item.AdminMark = "1";
                //            }
                //            else
                //            {
                //                item.AdminMark = "0";
                //            }
                //            item.Status = MessageStringConstants.Answered;
                //            item.IsSynchedUp = false;
                //            _localDB.UpdateExamAnswer(item);
                //        }
                //    }
                //}
                //else
                //{
                //    var res = _localDB.UpdateUserAnsweredTable(_questiondata.QuestionId);
                //    if (res.Count() > 0)
                //    {
                //        foreach (var item in res)
                //        {
                //            item.Status = MessageStringConstants.NotAnswered;
                //            item.IsSynchedUp = false;
                //            _localDB.UpdateExamAnswer(item);
                //        }
                //    }
                //}

                GetExamStatus();
                InsertRecordInBehaviourExamHistoryTable();
                UpdateAssignedExam();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "AssessmentViewModel.BehaviourUpdateUserAnswerInAnswerTable");
            }
        }
        #endregion

        #region Load  questions from local sqlite
        public void LoadQuestionFromLocal()
        {
            try
            {
                var examDuration = AppPreferences.ExamDuration;//Application.Current.Properties[AppPreferenceKey.ExamDuration];
                if (examDuration != null)
                {
                    Duration = AppPreferences.ExamDuration;//Application.Current.Properties[AppPreferenceKey.ExamDuration] as string;
                }
                var data = _localDB.GetAllDataBasedOnGroupId(ExamGroupID);
                ListViewItemSource = new List<EnglishQuestion>(data);
                var Hindidata = _localDB.GetAllHindiQuesitonsByGroupId(ExamGroupID);
                if (ExamGroupID == "1")
                {
                    IsShowPreferredLanguageToggle = false;
                    ListViewItemSource = new List<EnglishQuestion>(data);
                }
                else
                {
                    IsShowPreferredLanguageToggle = true;

                    if (AppPreferences.IsHindi == true)
                    {
                        ListViewItemSource = new List<EnglishQuestion>(Hindidata);
                    }
                    else //if (AppPreferences.IsEnglish == true)
                    {
                        ListViewItemSource = new List<EnglishQuestion>(data);
                    }

                }

                UpdateExamGroupStatus();
                LoadQuestions();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "AssessmentViewModel.LoadQuestionFromLocal");
            }
        }
        #endregion

        #region UpdateExamGroupStatus
        void UpdateExamGroupStatus()
        {
            try
            {
                var item = _localDB.CheckGroupIdIsAlreadyPresentInExamCompletedTable(ExamGroupID);
                if (item != null)
                {
                    item.StartTime = ServerTimerText;
                    if (item.Status != "C")
                    {
                        item.Status = "P";
                    }
                    item.IsSynchedUp = false;
                    _localDB.UpdateExamCompletedData(item);
                }
                //if (res.Count() > 0)
                //{
                //    foreach (var item in res)
                //    {
                //        //update
                //        item.StartTime = ServerTimerText;
                //        if (item.Status != "C")
                //        {
                //            item.Status = "P";
                //        }
                //        item.IsSynchedUp = false;
                //        _localDB.UpdateExamCompletedData(item);
                //    }
                //}
                //Checking purpose only
                // var CheckTable = _localDB.GetAllExamCompletedData();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "AssessmentViewModel.UpdateExamGroupStatus");
            }
        }
        #endregion

        #region UpdateLastQuestionViewedPositionInExamGroupTable
        void UpdateLastQuestionViewedPositionInExamGroupTable()
        {
            try
            {
                var item = _localDB.CheckGroupIdIsAlreadyPresentInExamCompletedTable(ExamGroupID);
                if (item != null)
                {
                    item.LastQuestionViewedPosition = CurrentPosition;
                    _localDB.UpdateExamCompletedData(item);
                }
                //if (res.Count() > 0)
                //{
                //    foreach (var item in res)
                //    {
                //        //update
                //        item.LastQuestionViewedPosition = CurrentPosition;
                //        _localDB.UpdateExamCompletedData(item);
                //    }
                //}
                //Checking purpose only
                // var CheckTable = _localDB.GetAllExamCompletedData();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "AssessmentViewModel.UpdateLastQuestionViewedPositionInExamGroupTable");
            }
        }
        #endregion

        #region GetLastQuestionViewedPositionInExamGroupTable
        int GetLastQuestionViewedPositionInExamGroupTable()
        {
            int position = 0;
            try
            {
                var res = _localDB.CheckGroupIdIsAlreadyPresentInExamCompletedTable(ExamGroupID);
                if (res != null)
                {
                    position = res.LastQuestionViewedPosition;
                }
                //if (res.Count() > 0)
                //{
                //    foreach (var item in res)
                //    {
                //        position = item.LastQuestionViewedPosition;
                //    }
                //}
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "AssessmentViewModel.UpdateLastQuestionViewedPositionInExamGroupTable");
            }
            return position;
        }
        #endregion

        #region SubmitOrFinishButtonClickEvent 
        async void SubmitOrFinishButtonClickEvent(String groupname)
        {







            try
            {
                bool returnFlag;//= await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.FinishMessage, string.Empty, "OK", "CANCEL");//press ok means true, cancel means false
                if (AppPreferences.IsHindi)
                {
                    returnFlag = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.FinishMessageHindi, string.Empty, MessageStringConstants.OKHindi, MessageStringConstants.CancelHindi);
                }
                else
                {
                    returnFlag = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.FinishMessage, string.Empty, "OK", "CANCEL");
                }
                if (returnFlag)
                {
                    lastQuestionViewedServerTime = string.Empty;
                    if (groupname == "normal")
                    {
                        UpdateUserAnswerInAnswerTable();
                        ChangeButtonColorSwitch(CurrentQue);
                        _questiondata.UserKeyed = string.Empty;
                        selectedOption = string.Empty;
                    }
                    else if (groupname == "behaviour")
                    {
                        BehaviourUpdateUserAnswerInAnswerTable();
                        _questiondata.UserKeyed = string.Empty;
                        selectedOption = string.Empty;
                    }
                    var item = _localDB.CheckGroupIdIsAlreadyPresentInExamCompletedTable(ExamGroupID);
                    if (item != null)
                    {
                        item.Status = "C";
                        item.EndTime = ServerTimerText;
                        item.IsSynchedUp = false;
                        _localDB.UpdateExamCompletedData(item);
                    }
                    //if (res.Count() > 0)
                    //{
                    //    foreach (var item in res)
                    //    {
                    //        //update
                    //        item.Status = "C";
                    //        item.EndTime = ServerTimerText;
                    //        item.IsSynchedUp = false;
                    //        _localDB.UpdateExamCompletedData(item);
                    //    }
                    //}

                    //Checking purpose only
                    var CheckTable = _localDB.GetAllExamCompletedData();


                    ////if all exam are finished means goto FeedbackPage otherwise SelectAndStartExamPage
                    //res = _localDB.GetAllExamCompletedData();
                    //var completedGroupStatus = _localDB.GetCompletedGroupCount();
                    //if (res.Count() == completedGroupStatus.Count())
                    //{
                    //    UpdateAssignedExamCompleted();
                    //    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                    //    if (isNetworkAvailable)
                    //    {
                    //        var sqliteOperations = new SqliteOperations();

                    //        UserDialogs.Instance.ShowLoading("Loading...");
                    //        await Task.Delay(100);
                    //        //await  sqliteOperations.BulkInsert();
                    //        await sqliteOperations.BulkDataAndUploadToServer();
                    //        UserDialogs.Instance.HideLoading();
                    //        TimerStop();
                    //        MessagingCenter.Send(this, "StartSyncSerivce", "Syncronization started from Internet availability ");
                    //        Application.Current.MainPage = new NavigationPage(new Feedback_Page());
                    //    }
                    //    else
                    //    {
                    //        TimerStop();
                    //        Application.Current.MainPage = new NavigationPage(new Feedback_Page());
                    //    }

                    //    //return;
                    //}
                    //else
                    //{
                    //    CallBackPage();
                    //}

                    CallBackPage();
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "AssessmentViewModel.SubmitOrFinishButtonClickEvent");
            }
        }
        #endregion

        #region CheckAllGroupAreCompletedOrNot
        async Task CheckAllGroupAreCompletedOrNot()
        {
            try
            {

                //if all exam are finished means goto FeedbackPage otherwise SelectAndStartExamPage
                var res = _localDB.GetAllExamCompletedData();
                var completedGroupStatus = _localDB.GetCompletedGroupCount();

                if (res != null && completedGroupStatus != null && res.Count() == completedGroupStatus.Count() && res.Count() != 0 && completedGroupStatus.Count() != 0)
                {
                    ExamFinishBtnBackColor = (Color)Application.Current.Resources["LightGreenColor"];
                    IsClickToCompleteButton = true;
                }
                else
                {
                    ExamFinishBtnBackColor = (Color)Application.Current.Resources["GrayColor"];
                    IsClickToCompleteButton = false;
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "AssessmentViewModel.CheckAllGroupAreCompletedOrNot");
            }
        }
        #endregion

        #region FinishEntireExam
        async Task FinishEntireExam()
        {
            try
            {
                //if all exam are finished means goto FeedbackPage otherwise SelectAndStartExamPage
                var res = _localDB.GetAllExamCompletedData();
                var completedGroupStatus = _localDB.GetCompletedGroupCount();
                TimerStop();
                if (res.Count() == completedGroupStatus.Count())
                {
                    UpdateAssignedExamCompleted();
                    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                    if (isNetworkAvailable)
                    {
                        var sqliteOperations = new SqliteOperations();

                        UserDialogs.Instance.ShowLoading();
                        await Task.Delay(100);
                        //await sqliteOperations.BulkInsert("Manual");
                        await sqliteOperations.GetLocalDataAndUploadToServer("Manual");
                        UserDialogs.Instance.HideLoading();

                        //ture means AutoProctored exam
                        if (AppPreferences.ExamMode == "True")
                        {
                            Application.Current.MainPage = new NavigationPage(new AutoProctoredFeedbackPage());
                            return;
                        }
                        else
                        {
                            Application.Current.MainPage = new NavigationPage(new ProctoredFeedbackPage());
                            return;
                        }

                    }
                    else
                    {
                        if (AppPreferences.IsHindi)
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.HindiOfflineSubmitExam, null, MessageStringConstants.OKHindi);
                        }
                        else
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.OfflineSubmitExam);
                        }
                        //ture means AutoProctored exam
                        if (AppPreferences.ExamMode == "True")
                        {
                            Application.Current.MainPage = new NavigationPage(new AutoProctoredFeedbackPage());
                            return;
                        }
                        else
                        {
                            Application.Current.MainPage = new NavigationPage(new ProctoredFeedbackPage());
                            return;
                        }
                    }
                }
                else
                {
                    if (AppPreferences.IsHindi)
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.MustCompleteAllGroupsHindi, null, MessageStringConstants.OKHindi);
                    }
                    else
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.MustCompleteAllGroups);
                    }

                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "AssessmentViewModel.CheckAllGroupAreCompletedOrNot");
            }

        }
        #endregion

        #region CallBackPage
        private async void CallBackPage()
        {
            try
            {
                string completedStatus = string.Empty;
                var res = _localDB.CheckGroupIdIsAlreadyPresentInExamCompletedTable(ExamGroupID);
                if (res != null)
                {
                    if (res.Status == "C")
                    {
                        completedStatus = MessageStringConstants.CompletedColor;
                        //completed
                    }
                    else
                    {
                        //not completed
                        completedStatus = MessageStringConstants.InCompletedColor;
                    }
                }
                //if (res.Count() > 0)
                //{
                //    foreach (var item in res)
                //    {
                //        //check whether group is completed are not
                //        if (item.Status == "C")
                //        {
                //            completedStatus = MessageStringConstants.CompletedColor;
                //            //completed
                //        }
                //        else
                //        {
                //            //not completed
                //            completedStatus = MessageStringConstants.InCompletedColor;
                //        }
                //    }
                //}
                else
                {
                    //not visited
                    completedStatus = MessageStringConstants.NotStatedColor;
                }
                await CheckAllGroupAreCompletedOrNot();

                var serializedData = AppPreferences.GroupDetailsSerialize;
                List<EnglishGroupDetail> deSerializedData = JsonConvert.DeserializeObject<List<EnglishGroupDetail>>(serializedData);
                List<EnglishGroupDetail> objGroupDetails = new List<EnglishGroupDetail>();
                objGroupDetails = deSerializedData;
                for (int i = 0; i < objGroupDetails.Count; i++)
                {

                    if (objGroupDetails[i].GroupID == ExamGroupID)
                    {
                        objGroupDetails[i].TitleStatusColor = completedStatus;
                        objGroupDetails[i].QuestionGroupStatus[0].AnsweredQuestion = AnswerCount.ToString();
                        objGroupDetails[i].QuestionGroupStatus[0].UnAnsweredQuestions = NotAnswerCount.ToString();
                        objGroupDetails[i].QuestionGroupStatus[0].NotVisitedQuestions = NotVisitedCount.ToString();
                    }
                }
                var serializeValue = JsonConvert.SerializeObject(objGroupDetails);
                AppPreferences.GroupDetailsSerialize = serializeValue;
                DoOperation("showexamgroupselection");



            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "AssessmentViewModel.CallBackPage");
            }

        }
        #endregion

        #region UpdateAssignedExamInEveryQues
        void UpdateAssignedExam()
        {
            try
            {
                // var item = new AssignedExamModel();
                if (_localDB.TableExists("AssignedExamModel"))
                {
                    var item = _localDB.GetAllAssignedExamData();
                    if (item.ExamStartTime == string.Empty)
                    {
                        item.ExamStartTime = ServerTimerText;
                    }
                    item.Status = "P";
                    item.LastUpdatedTime = TimerText;
                    item.LastUpdatedGroupID = ExamGroupID;
                    item.LastUpdatedQuestionID = _questiondata.QuestionId.ToString();
                    item.AssignedID = AppPreferences.AssignedID;
                    _localDB.UpdateAssignedExamData(item);

                    //var res = _localDB.GetAllAssignedExamData();

                    //if (res!=null && res.Count() > 0)
                    //{
                    //    foreach (var item in res)
                    //    {
                    //        if (item.ExamStartTime == string.Empty)
                    //        {
                    //            item.ExamStartTime = ServerTimerText;
                    //        }
                    //        item.Status = "P";
                    //        item.LastUpdatedTime = TimerText;
                    //        item.LastUpdatedGroupID = ExamGroupID;
                    //        item.LastUpdatedQuestionID = _questiondata.QuestionId.ToString();

                    //        _localDB.UpdateAssignedExamData(item);
                    //    }
                    //}
                    ////Checking purpose only
                    //var CheckTable = _localDB.GetAllAssignedExamData();
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                //SendErrorMessageToServer(e, "AssessmentViewModel.UpdateAssignedExam");
            }
        }
        #endregion

        #region UpdateAssignedExamCompleted
        void UpdateAssignedExamCompleted()
        {
            try
            {
                // var item = new AssignedExamModel();
                var item = _localDB.GetAllAssignedExamData();
                item.LastUpdatedTime = TimerText;
                item.LastUpdatedGroupID = ExamGroupID;
                //item.LastUpdatedQuestionID = _questiondata.QuestionId.ToString();
                item.ExamEndTime = ServerTimerText;
                item.Status = "C";
                _localDB.UpdateAssignedExamData(item);
                //var res = _localDB.GetAllAssignedExamData();

                //if (res.Count() > 0)
                //{
                //    foreach (var item in res)
                //    {

                //    }
                //}
                ////Checking purpose only
                //var CheckTable = _localDB.GetAllAssignedExamData();
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "AssessmentViewModel.UpdateAssignedExamCompleted");
            }
        }
        #endregion

        #region UpdateAutoClosedAssignedExamCompleted
        void UpdateAutoClosedAssignedExamCompleted()
        {
            try
            {


                //var item = new AssignedExamModel();
                var item = _localDB.GetAllAssignedExamData();
                item.LastUpdatedTime = TimerText;
                item.LastUpdatedGroupID = ExamGroupID;
                item.LastUpdatedQuestionID = _questiondata.QuestionId.ToString();
                item.ExamEndTime = ServerTimerText;
                item.Status = "C";
                item.ReEvaluationStatus = "AutoClosed";
                _localDB.UpdateAssignedExamData(item);

                //var res = _localDB.GetAllAssignedExamData();

                //if (res.Count() > 0)
                //{
                //    foreach (var item in res)
                //    {

                //        item.LastUpdatedTime = TimerText;
                //        item.LastUpdatedGroupID = ExamGroupID;
                //        item.LastUpdatedQuestionID = _questiondata.QuestionId.ToString();
                //        item.ExamEndTime = ServerTimerText;
                //        item.Status = "C";
                //        item.ReEvaluationStatus = "AutoClosed";
                //        _localDB.UpdateAssignedExamData(item);
                //    }
                //}
                ////Checking purpose only
                //var CheckTable = _localDB.GetAllAssignedExamData();
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "AssessmentViewModel.UpdateAutoClosedAssignedExamCompleted");
            }
        }
        #endregion

        #region Timer Start Function
        private void TimerStart()
        {
            try
            {
                string Servertime, Localtime;

                var isStartWithLogin = AppPreferences.IsStartWithLogin;
                if (isStartWithLogin)
                {
                    AppPreferences.IsStartWithLogin = false;
                    TimeSpan serverTime = new TimeSpan(Convert.ToInt64(AppPreferences.ServerDateTime));
                    TimeSpan.TryParse(AppPreferences.ExamTime, out _Examtime);
                    Servertime = serverTime.Hours + ":" + serverTime.Minutes + ":" + serverTime.Seconds;
                    Localtime = _Examtime.Hours + ":" + _Examtime.Minutes + ":" + _Examtime.Seconds;
                }
                else
                {
                    if (AppPreferences.ServerHour != null && !String.IsNullOrEmpty(AppPreferences.ServerHour))
                    {
                        Servertime = AppPreferences.ServerHour + ":" + AppPreferences.ServerMinute + ":" + AppPreferences.ServerSecond;
                    }
                    else
                    {
                        Servertime = "00:00:01";
                    }
                    if (AppPreferences.UpdatedLocalTime != null && !String.IsNullOrEmpty(AppPreferences.UpdatedLocalTime))
                    {
                        Localtime = AppPreferences.UpdatedLocalTime;
                    }
                    else
                    {
                        Localtime = "00:00:01";
                    }
                }
                

                int TotalSec = (int)TimeSpan.Parse(Localtime).TotalSeconds;
                int ServerTotalSec = (int)TimeSpan.Parse(Servertime).TotalSeconds;
                // UpdateAssignedExam();
                CancellationTokenSource CTS = cancellationTokenSource;
                Device.StartTimer(new TimeSpan(0, 0, 1), () =>
                {

                    if (string.IsNullOrEmpty(AppPreferences.ExamDurationHour) || string.IsNullOrEmpty(AppPreferences.ExamDurationMinute))
                    {
                        return false;
                    }


                    int exitHour = int.Parse(AppPreferences.ExamDurationHour);
                    int exitMinute = int.Parse(AppPreferences.ExamDurationMinute);
                    
                    var UserTime = new TimeSpan(_Examtime.Hours, _Examtime.Minutes, 0);
                    var ExamDuration = new TimeSpan(exitHour, exitMinute, 0);
                    if (UserTime > ExamDuration)
                    {

                        SessionExpired();
                        return false;

                    }
                    else if (CTS.IsCancellationRequested)
                    {
                        return false;
                    }
                    else
                    {

                        Device.BeginInvokeOnMainThread(async () =>
                       {

                           if (_Examtime.Minutes != 0)
                           {
                               if ((_Examtime.Minutes % Constant.BackgroundServiceCallingTimeInterval == 0) && (_Examtime.Seconds == 0))
                               {
                                   //API Call Every Five Minutes.
                                   MessagingCenter.Send(this, "StartSyncSerivce", "Syncronization started from manual Data sync");
                               }
                           }


                           TotalSec = TotalSec + 1;
                           ServerTotalSec = ServerTotalSec + 1;


                           _Examtime = TimeSpan.FromSeconds(TotalSec);
                           _ServerTime = TimeSpan.FromSeconds(ServerTotalSec);

                           ServerTimerText = AppPreferences.ServerDate + " " + string.Format("{0:00}:{1:00}:{2:00}", _ServerTime.Hours, _ServerTime.Minutes, _ServerTime.Seconds);
                           AppPreferences.ServerUpdatedDateTime = ServerTimerText;
                           AppPreferences.ServerSecond = _ServerTime.Seconds.ToString();
                           AppPreferences.ServerMinute = _ServerTime.Minutes.ToString();
                           AppPreferences.ServerHour = _ServerTime.Hours.ToString();


                           if (AppPreferences.IsActivityDestroy == "false")
                           {
                               System.Diagnostics.Debug.WriteLine("Updated Timer----->" + TimerText);
                               TimerText = string.Format("{0:00}:{1:00}:{2:00}", _Examtime.Hours, _Examtime.Minutes, _Examtime.Seconds);
                               AppPreferences.ExamMinute = _Examtime.Minutes.ToString();
                               AppPreferences.UpdatedLocalTime = TimerText;

                               #region lastFaceCroppedServerTime
                               if (string.IsNullOrEmpty(lastFaceCroppedServerTime))
                               {
                                   lastFaceCroppedServerTime = ServerTimerText;
                                   MessageStringConstants.LastFacedCroppedTime = DateTime.Parse(ServerTimerText);
                               }


                               DateTime liveServerTime = DateTime.Parse(ServerTimerText);
                               var lastFaceCappuredServerTime = MessageStringConstants.LastFacedCroppedTime;
                               double diff = (liveServerTime - lastFaceCappuredServerTime).TotalSeconds;
                               if (diff >= Constant.FaceNotDedicationDuration)
                               {
                                   TimerStop();
                                   // alertCount = alertCount + 1;
                                   //AppPreferences.FaceNotDetectedAlertCount = Convert.ToString(alertCount);
                                   MessageStringConstants.IsTakeSnop = false;
                                   if (AppPreferences.IsHindi)
                                   {
                                       await UserDialogs.Instance.AlertAsync(MessageStringConstants.HindiFaceNotDetected, null, MessageStringConstants.OKHindi);
                                   }
                                   else
                                   {
                                       await UserDialogs.Instance.AlertAsync(MessageStringConstants.FaceNotDetected);
                                   }

                                   //if (alertCount >= 3)
                                   //{
                                   //    DependencyService.Get<Interface.IExitApplication>().closeApplication();
                                   //}
                                   //else
                                   //{
                                   MessageStringConstants.LastFacedCroppedTime = DateTime.Parse(ServerTimerText);
                                   TimerStart();
                                   MessageStringConstants.IsTakeSnop = true;
                                   // }
                               }

                               #endregion
                           }







                           //ture means AutoProctored exam
                           //if (Interface.AppPreferences.ExamMode == "True")
                           //{
                           //    AutoNavigationToNextQuestion();
                           //}
                           //else
                           //{
                           //    IsVisibleDownTimer = false;
                           //}
                       });
                        return true;
                    }


                });
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "AssessmentViewModel.TimerStart");
            }
        }
        #endregion

        #region AutoNavigationToNextQuestion
        //private void AutoNavigationToNextQuestion()
        //{
        //    //Automatically navigate to next question
        //    if (!string.IsNullOrEmpty(lastQuestionViewedServerTime))
        //    {
        //        DateTime liveServerTime = DateTime.Parse(ServerTimerText);
        //        double questionTimeDuration = (liveServerTime - lastQuestionViewedDateTime).TotalSeconds;
        //        var countDownTimer = Constant.AutoQuestionNavigateDuration - questionTimeDuration;
        //        TimeSpan _TimeSpan = TimeSpan.FromSeconds(countDownTimer);
        //        DownTimer = string.Format("{0:00}:{1:00}", _TimeSpan.Minutes, _TimeSpan.Seconds);

        //        if (questionTimeDuration >= Constant.AutoQuestionNavigateDuration)
        //        {
        //            if (questionType.Equals("showexamination"))
        //            {
        //                DoOperation("nextCommand");
        //            }
        //            //else if (questionType.Equals("showbehaviourexamination"))
        //            //{
        //            //    DoOperation("behaviournextCommand");
        //            //}
        //        }
        //    }
        //    else
        //    {
        //        DownTimer = "00:00";
        //    }
        //}

        #endregion

        #region SessionExpired
        public async void SessionExpired()
        {

            UpdateAutoClosedAssignedExamCompleted();
            TimerStop();
            if (AppPreferences.IsHindi)
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.ExamTimeOutMessageHindi, null, MessageStringConstants.OKHindi);
            }
            else
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.ExamTimeOutMessage);
            }

            //ture means AutoProctored exam
            if (AppPreferences.ExamMode == "True")
            {
                Application.Current.MainPage = new NavigationPage(new AutoProctoredFeedbackPage());
                return;
            }
            else
            {
                Application.Current.MainPage = new NavigationPage(new ProctoredFeedbackPage());
                return;
            }
        }
        #endregion

        #region Timer Stop Function
        public void TimerStop()
        {
            Interlocked.Exchange(ref cancellationTokenSource, new CancellationTokenSource()).Cancel();
        }
        #endregion

        #region Switch_Toggled

        private bool _isToggledLanguage;

        public bool IsToggledLanguage
        {
            get { return _isToggledLanguage; }
            set { _isToggledLanguage = value; OnPropertyChanged(); }
        }


        public void Switch_Toggled(object sender, ToggledEventArgs e)
        {
            IsToggledLanguage = e.Value;
            if (IsToggledLanguage == true)
            {
                bindSelectedLanguage = "English";
                PreferredLanguage = "Preferred Language";
                AppPreferences.IsToggledEnglish = true;
                AppPreferences.IsToggledHindi = false;
                DependencyService.Get<ILocalize>().ChangeLocale("en");
                App.CultureCode = "en";

            }
            else
            {
                bindSelectedLanguage = "हिंदी";
                PreferredLanguage = "पसंदीदा भाषा";
                AppPreferences.IsToggledEnglish = false;
                AppPreferences.IsToggledHindi = true;
                DependencyService.Get<ILocalize>().ChangeLocale("hi");
                App.CultureCode = "hi";
            }
            #region IsVisbleBehaviourExamSelectionPart
            if (IsVisbleBehaviourExamSelectionPart)
            {
                faQuestion1 = (string)Application.Current.Resources["RadioButtonIcon"];
                faQuestion2 = (string)Application.Current.Resources["RadioButtonIcon"];
                OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                OptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                var data = _localDB.GetAllDataBasedOnGroupId("4");
                var Hindidata = _localDB.GetAllHindiQuesitonsByGroupId(ExamGroupID);
                if (AppPreferences.IsToggledEnglish == true)
                {
                    lastindex = int.Parse(data.Count().ToString());
                    ListViewItemSource = new List<EnglishQuestion>(data);
                    StronglyAgree = "StronglyAgree";
                    Agree = "Agree";
                    NotSure = "NotSure";
                    Disagree = "Disagree";
                    StrongDisagree = "StrongDisagree";
                }
                else if (AppPreferences.IsToggledHindi == true)
                {
                    lastindex = int.Parse(Hindidata.Count().ToString());
                    ListViewItemSource = new List<EnglishQuestion>(Hindidata);
                    StronglyAgree = "दृढ़तापूर्वक सहमत";
                    Agree = "सम्मत होना";
                    NotSure = "निश्चित नहीं";
                    Disagree = "असहमत";
                    StrongDisagree = "दृढ़तापूर्वक असहमत";
                }
                // UpdateExamGroupStatus();
                _questiondata = ListViewItemSource.Find(x => x.QuestionId == CurrentQuestionID); //Find(.ElementAt(CurrentPosition);
                if (_questiondata != null)
                {
                    Question = _questiondata.Question;
                    Question1 = _questiondata.ChoiceA;
                    Question2 = _questiondata.ChoiceB;
                    //UpdateLastQuestionViewedPositionInExamGroupTable();
                    //BehaviourGetSelectedAnswerIfAlreadyAnswered();
                }
            }
            #endregion

            #region IsVisbleExaminationPart
            else if (IsVisbleExaminationPart)
            {
                OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                OptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                var examDuration = AppPreferences.ExamDuration;
                if (examDuration != null)
                {
                    Duration = AppPreferences.ExamDuration;
                }
                var data = _localDB.GetAllDataBasedOnGroupId(ExamGroupID);
                var Hindidata = _localDB.GetAllHindiQuesitonsByGroupId(ExamGroupID);
                if (AppPreferences.IsToggledEnglish == true)
                {
                    ListViewItemSource = new List<EnglishQuestion>(data);
                }
                else if (AppPreferences.IsToggledHindi == true)
                {
                    ListViewItemSource = new List<EnglishQuestion>(Hindidata);
                }
                //UpdateExamGroupStatus();
                _questiondata = ListViewItemSource.Find(x => x.QuestionId == CurrentQuestionID);
                if (_questiondata != null)
                {
                    //UpdateLastQuestionViewedPositionInExamGroupTable();
                    //GetSelectedAnswerIfAlreadyAnswered();

                    #region Question
                    if (string.IsNullOrEmpty(_questiondata.Question))
                    {
                        IsQueImage = false;
                        IsQueContent = false;
                    }
                    else if ((_questiondata.Question.Contains(".jpg") || _questiondata.Question.Contains(".jpeg") || _questiondata.Question.Contains(".png") || _questiondata.Question.Contains("gif")) && (Device.RuntimePlatform == Device.Android || Device.RuntimePlatform == Device.iOS))
                    {
                        IsQueImage = true;
                        IsQueContent = false;
                        Question = _questiondata.Question.Replace("\n", string.Empty);
                    }
                    else
                    {
                        IsQueImage = false;
                        IsQueContent = true;
                        if (int.Parse(ExamGroupID) != 7)
                        {
                            Question = Regex.Replace(_questiondata.Question.Replace("\n", string.Empty), "<.*?>", String.Empty);
                        }
                        else
                        {
                            Question = Regex.Replace(Regex.Replace(_questiondata.Question.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty).Replace("\r", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                        }

                        System.Diagnostics.Debug.WriteLine("Question-- >" + Question);
                    }
                    #endregion

                    #region Option A
                    if (string.IsNullOrEmpty(_questiondata.ChoiceA))
                    {
                        IsQueImageOptionA = false;
                        IsQueContentOptionA = false;
                    }
                    else if ((_questiondata.ChoiceA.Contains(".jpg") || _questiondata.ChoiceA.Contains(".jpeg") || _questiondata.ChoiceA.Contains(".png") || _questiondata.Question.Contains("gif")) && (Device.RuntimePlatform == Device.Android || Device.RuntimePlatform == Device.iOS))
                    {
                        IsQueImageOptionA = true;
                        IsQueContentOptionA = false;
                        OptionA = _questiondata.ChoiceA.Replace("\n", string.Empty);
                    }
                    else
                    {
                        IsQueImageOptionA = false;
                        IsQueContentOptionA = true;
                        if (int.Parse(ExamGroupID) != 7)
                        {
                            OptionA = Regex.Replace(_questiondata.ChoiceA.Replace("\n", string.Empty), "<.*?>", String.Empty);

                        }
                        else
                        {
                            OptionA = Regex.Replace(Regex.Replace(_questiondata.ChoiceA.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty).Replace("\r", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                        }

                        System.Diagnostics.Debug.WriteLine("OptionA-->" + OptionA);

                    }
                    #endregion

                    #region Option B
                    if (string.IsNullOrEmpty(_questiondata.ChoiceB))
                    {
                        IsQueImageOptionB = false;
                        IsQueContentOptionB = false;
                    }
                    else if ((_questiondata.ChoiceB.Contains(".jpg") || _questiondata.ChoiceB.Contains(".jpeg") || _questiondata.ChoiceB.Contains(".png") || _questiondata.Question.Contains("gif")) && (Device.RuntimePlatform == Device.Android || Device.RuntimePlatform == Device.iOS))
                    {
                        IsQueImageOptionB = true;
                        IsQueContentOptionB = false;
                        OptionB = _questiondata.ChoiceB.Replace("\n", string.Empty);
                    }
                    else
                    {
                        IsQueImageOptionB = false;
                        IsQueContentOptionB = true;
                        if (int.Parse(ExamGroupID) != 7)
                        {
                            OptionB = Regex.Replace(_questiondata.ChoiceB.Replace("\n", string.Empty), "<.*?>", String.Empty);

                        }
                        else
                        {
                            OptionB = Regex.Replace(Regex.Replace(_questiondata.ChoiceB.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty).Replace("\r", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                        }
                        //OptionB = Regex.Replace(_questiondata.ChoiceB.Replace("\n", string.Empty), "<.*?>", String.Empty);
                        System.Diagnostics.Debug.WriteLine("OptionB-->" + OptionB);
                    }
                    #endregion

                    #region Option C
                    if (string.IsNullOrEmpty(_questiondata.ChoiceC))
                    {
                        IsQueImageOptionC = false;
                        IsQueContentOptionC = false;
                    }
                    else if ((_questiondata.ChoiceC.Contains(".jpg") || _questiondata.ChoiceC.Contains(".jpeg") || _questiondata.ChoiceC.Contains(".png") || _questiondata.Question.Contains("gif")) && (Device.RuntimePlatform == Device.Android || Device.RuntimePlatform == Device.iOS))
                    {
                        IsQueImageOptionC = true;
                        IsQueContentOptionC = false;
                        OptionC = _questiondata.ChoiceC.Replace("\n", string.Empty);
                    }
                    else
                    {
                        IsQueImageOptionC = false;
                        IsQueContentOptionC = true;
                        if (int.Parse(ExamGroupID) != 7)
                        {
                            OptionC = Regex.Replace(_questiondata.ChoiceC.Replace("\n", string.Empty), "<.*?>", String.Empty);

                        }
                        else
                        {
                            OptionC = Regex.Replace(Regex.Replace(_questiondata.ChoiceC.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty).Replace("\r", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                        }
                        //OptionC = Regex.Replace(_questiondata.ChoiceC.Replace("\n", string.Empty), "<.*?>", String.Empty);
                        System.Diagnostics.Debug.WriteLine("OptionC-->" + OptionC);
                    }
                    #endregion

                    #region Option D
                    if (string.IsNullOrEmpty(_questiondata.ChoiceD))
                    {
                        IsQueImageOptionD = false;
                        IsQueContentOptionD = false;
                    }
                    else if ((_questiondata.ChoiceD.Contains(".jpg") || _questiondata.ChoiceD.Contains(".jpeg") || _questiondata.ChoiceD.Contains(".png") || _questiondata.Question.Contains("gif")) && (Device.RuntimePlatform == Device.Android || Device.RuntimePlatform == Device.iOS))
                    {
                        IsQueImageOptionD = true;
                        IsQueContentOptionD = false;
                        OptionD = _questiondata.ChoiceD.Replace("\n", string.Empty);

                    }
                    else
                    {
                        IsQueImageOptionD = false;
                        IsQueContentOptionD = true;
                        if (int.Parse(ExamGroupID) != 7)
                        {
                            OptionD = Regex.Replace(_questiondata.ChoiceD.Replace("\n", string.Empty), "<.*?>", String.Empty);

                        }
                        else
                        {
                            OptionD = Regex.Replace(Regex.Replace(_questiondata.ChoiceD.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty).Replace("\r", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                        }
                        //OptionD = Regex.Replace(_questiondata.ChoiceD.Replace("\n", string.Empty), "<.*?>", String.Empty);
                        System.Diagnostics.Debug.WriteLine("OptionD-->" + OptionD);
                    }
                    #endregion
                }
            }
            #endregion

            #region Get Exam status.
            try
            {
                var answer = _localDB.GetAnsweredStatus(ExamGroupID, MessageStringConstants.Answered);
                var notanswer = _localDB.GetAnsweredStatus(ExamGroupID, MessageStringConstants.NotAnswered);
                if (AppPreferences.IsToggledEnglish)
                {
                    var NoOfQuestions = _localDB.GetAllDataBasedOnGroupId(ExamGroupID);
                    int notvisited = Convert.ToInt32(NoOfQuestions.Count()) - Convert.ToInt32(answer.Count()) - Convert.ToInt32(notanswer.Count());
                    NotVisitedCount = notvisited;
                    Answered = "Answered[" + answer.Count() + "]";
                    NotAnswered = "Not Answered[" + notanswer.Count() + "]";
                    NotVisited = "Not Visited[" + notvisited.ToString() + "]";
                }
                else if (AppPreferences.IsToggledHindi)
                {
                    var NoOfQuestions = _localDB.GetAllHindiDataBasedOnGroupId(ExamGroupID);
                    int notvisited = Convert.ToInt32(NoOfQuestions.Count()) - Convert.ToInt32(answer.Count()) - Convert.ToInt32(notanswer.Count());
                    NotVisitedCount = notvisited;
                    Answered = "उत्तर दे दिया है[" + answer.Count() + "]";
                    NotAnswered = "उत्तर नहिं दिया है[" + notanswer.Count() + "]";
                    NotVisited = "नहीं देखा है[" + notvisited.ToString() + "]";
                }
                AnswerCount = answer.Count();
                NotAnswerCount = notanswer.Count();

            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "AssessmentViewModel.GetExamStatus");
            }
            #endregion
        }
        #endregion

        #region Private property  

        private bool _IsClickToCompleteButton;
        public bool IsClickToCompleteButton
        {
            get { return _IsClickToCompleteButton; }
            set { _IsClickToCompleteButton = value; OnPropertyChanged(); }
        }


        private bool _IsHintStack;

        public bool IsHintStack
        {
            get { return _IsHintStack; }
            set { _IsHintStack = value; OnPropertyChanged(); }
        }


        private string _LblCurrentQuestion;
        public string LblCurrentQuestion
        {
            get { return _LblCurrentQuestion; }
            set { _LblCurrentQuestion = value; OnPropertyChanged(); }
        }
        private bool _IsDynamicButtonVisibile;
        public bool IsDynamicButtonVisibile
        {
            get { return _IsDynamicButtonVisibile; }
            set { _IsDynamicButtonVisibile = value; OnPropertyChanged(); }
        }
        private bool _IsRightArrowIconVisibile;
        public bool IsRightArrowIconVisibile
        {
            get { return _IsRightArrowIconVisibile; }
            set { _IsRightArrowIconVisibile = value; OnPropertyChanged(); }
        }

        private string _btnNextAndSubmit;
        public string btnNextAndSubmit
        {
            get { return _btnNextAndSubmit; }
            set { _btnNextAndSubmit = value; OnPropertyChanged(); }
        }

        private string _Answered;
        public string Answered
        {
            get { return _Answered; }
            set { _Answered = value; OnPropertyChanged(); }
        }
        private string _NotAnswered;
        public string NotAnswered
        {
            get { return _NotAnswered; }
            set { _NotAnswered = value; OnPropertyChanged(); }
        }
        private string _NotVisited;
        public string NotVisited
        {
            get { return _NotVisited; }
            set { _NotVisited = value; OnPropertyChanged(); }
        }
        #region Option Visibile Property
        private bool _IsQueContent;
        public bool IsQueContent
        {
            get { return _IsQueContent; }
            set { _IsQueContent = value; OnPropertyChanged(); }
        }
        private bool _IsQueContentOptionA;
        public bool IsQueContentOptionA
        {
            get { return _IsQueContentOptionA; }
            set { _IsQueContentOptionA = value; OnPropertyChanged(); }
        }
        private bool _IsQueContentOptionB;
        public bool IsQueContentOptionB
        {
            get { return _IsQueContentOptionB; }
            set { _IsQueContentOptionB = value; OnPropertyChanged(); }
        }
        private bool _IsQueContentOptionC;
        public bool IsQueContentOptionC
        {
            get { return _IsQueContentOptionC; }
            set { _IsQueContentOptionC = value; OnPropertyChanged(); }
        }
        private bool _IsQueContentOptionD;
        public bool IsQueContentOptionD
        {
            get { return _IsQueContentOptionD; }
            set { _IsQueContentOptionD = value; OnPropertyChanged(); }
        }

        private bool _IsQueImage;
        public bool IsQueImage
        {
            get { return _IsQueImage; }
            set { _IsQueImage = value; OnPropertyChanged(); }
        }
        private bool _IsQueImageOptionA;
        public bool IsQueImageOptionA
        {
            get { return _IsQueImageOptionA; }
            set { _IsQueImageOptionA = value; OnPropertyChanged(); }
        }
        private bool _IsQueImageOptionB;
        public bool IsQueImageOptionB
        {
            get { return _IsQueImageOptionB; }
            set { _IsQueImageOptionB = value; OnPropertyChanged(); }
        }
        private bool _IsQueImageOptionC;
        public bool IsQueImageOptionC
        {
            get { return _IsQueImageOptionC; }
            set { _IsQueImageOptionC = value; OnPropertyChanged(); }
        }
        private bool _IsQueImageOptionD;
        public bool IsQueImageOptionD
        {
            get { return _IsQueImageOptionD; }
            set { _IsQueImageOptionD = value; OnPropertyChanged(); }
        }
        #endregion
        private string _StronglyAgree;
        public string StronglyAgree
        {
            get { return _StronglyAgree; }
            set { _StronglyAgree = value; OnPropertyChanged(); }
        }
        private string _Agree;
        public string Agree
        {
            get { return _Agree; }
            set { _Agree = value; OnPropertyChanged(); }
        }
        private string _NotSure;
        public string NotSure
        {
            get { return _NotSure; }
            set { _NotSure = value; OnPropertyChanged(); }
        }
        private string _Disagree;
        public string Disagree
        {
            get { return _Disagree; }
            set { _Disagree = value; OnPropertyChanged(); }
        }
        private string _StrongDisagree;
        public string StrongDisagree
        {
            get { return _StrongDisagree; }
            set { _StrongDisagree = value; OnPropertyChanged(); }
        }
        private bool _IsShowPreferredLanguageToggle;

        public bool IsShowPreferredLanguageToggle
        {
            get { return _IsShowPreferredLanguageToggle; }
            set { _IsShowPreferredLanguageToggle = value; OnPropertyChanged(); }
        }

        private List<EnglishQuestion> _ListViewItemSource;

        public List<EnglishQuestion> ListViewItemSource
        {
            get { return _ListViewItemSource; }
            set { _ListViewItemSource = value; OnPropertyChanged(); }
        }
        private string _question;
        public string Question
        {
            get { return _question; }
            set { _question = value; OnPropertyChanged(); }
        }
        private string _optionA;
        public string OptionA
        {
            get { return _optionA; }
            set { _optionA = value; OnPropertyChanged(); }
        }
        private string _optionB;
        public string OptionB
        {
            get { return _optionB; }
            set { _optionB = value; OnPropertyChanged(); }
        }
        private string _optionC;
        public string OptionC
        {
            get { return _optionC; }
            set { _optionC = value; OnPropertyChanged(); }
        }
        private string _optionD;
        public string OptionD
        {
            get { return _optionD; }
            set { _optionD = value; OnPropertyChanged(); }
        }
        private int currentPosition;
        public int CurrentPosition
        {
            get { return currentPosition; }
            set { currentPosition = value; OnPropertyChanged(); }
        }
        private string _GroupOfExamName;
        public string GroupOfExamName
        {
            get { return _GroupOfExamName; }
            set
            {
                if (AppPreferences.IsHindi)
                {
                    _GroupOfExamName = "अनुभाग : " + value;
                }
                else
                {
                    _GroupOfExamName = "Group : " + value;
                }
                OnPropertyChanged();
            }
        }
        private string _ExamName;
        public string ExamName
        {
            get { return _ExamName; }
            set { _ExamName = value; OnPropertyChanged(); }
        }
        private string _PreferredLanguage;
        public string PreferredLanguage
        {
            get { return _PreferredLanguage; }
            set { _PreferredLanguage = value; OnPropertyChanged(); }
        }


        private string SelectdExamLanguage;

        public string bindSelectedLanguage
        {
            get { return SelectdExamLanguage; }
            set { SelectdExamLanguage = value; OnPropertyChanged(); }
        }
        private bool _Ispreviousbtn;
        public bool Ispreviousbtn
        {
            get { return _Ispreviousbtn; }
            set { _Ispreviousbtn = value; OnPropertyChanged(); }
        }
        private bool _Isnextbtn;
        public bool Isnextbtn
        {
            get { return _Isnextbtn; }
            set { _Isnextbtn = value; OnPropertyChanged(); }
        }

        private int _lastindex;
        public int lastindex
        {
            get { return _lastindex; }
            set { _lastindex = value; OnPropertyChanged(); }
        }
        private int _currentQue;
        public int CurrentQue
        {
            get { return _currentQue; }
            set { _currentQue = value; OnPropertyChanged(); }
        }
        private string _BehaviourcurrentQue;
        public string BehaviourCurrentQue
        {
            get { return _BehaviourcurrentQue; }
            set { _BehaviourcurrentQue = value; OnPropertyChanged(); }
        }
        private string _optionARadiobutton;
        public string OptionARadiobutton
        {
            get { return _optionARadiobutton; }
            set { _optionARadiobutton = value; OnPropertyChanged(); }
        }
        private string _optionBRadiobutton;
        public string OptionBRadiobutton
        {
            get { return _optionBRadiobutton; }
            set { _optionBRadiobutton = value; OnPropertyChanged(); }
        }
        private string _optionCRadiobutton;
        public string OptionCRadiobutton
        {
            get { return _optionCRadiobutton; }
            set { _optionCRadiobutton = value; OnPropertyChanged(); }
        }
        private string _optionDRadiobutton;
        public string OptionDRadiobutton
        {
            get { return _optionDRadiobutton; }
            set { _optionDRadiobutton = value; OnPropertyChanged(); }
        }


        private Color _buttonColor;
        public Color ButtonColor
        {
            get { return _buttonColor; }
            set { _buttonColor = value; OnPropertyChanged(); }
        }
        private string _Duration;
        public string Duration
        {
            get { return _Duration; }
            set { _Duration = value; OnPropertyChanged(); }
        }

        private Color _buttonColorAnswerwed;
        public Color ButtonColorAnswerwed
        {
            get { return _buttonColorAnswerwed; }
            set { _buttonColorAnswerwed = value; OnPropertyChanged(); }
        }

        private Color _buttonColorNotAnswerwed;
        public Color ButtonColorNotAnswerwed
        {
            get { return _buttonColorNotAnswerwed; }
            set { _buttonColorNotAnswerwed = value; OnPropertyChanged(); }
        }
        private Color _buttonColorNotVisited;
        public Color ButtonColorNotVisited
        {
            get { return _buttonColorNotVisited; }
            set { _buttonColorNotVisited = value; OnPropertyChanged(); }
        }

        private string _NextButtonColor;

        public string NextButtonColor
        {
            get { return _NextButtonColor; }
            set { _NextButtonColor = value; OnPropertyChanged(); }
        }
        #endregion

        #region Show Previous and Next Button
        public void ShowPreviousandNextButton()
        {
            if (AppPreferences.IsHindi)
            {
                LblCurrentQuestion = lastindex + " में से " + CurrentQue;
            }
            else
            {
                LblCurrentQuestion = CurrentQue + " of " + lastindex;
            }
            BehaviourCurrentQue = "(" + CurrentQue + ")";
            //if (Application.Current.Properties[AppPreferenceKey.ExamMode] as string == "True")
            //Ture mean exam type AutoProtected, so invisible prev button
            if (AppPreferences.ExamMode == "True")
            {
                Ispreviousbtn = false;
                IsDynamicButtonVisibile = false;
                Isnextbtn = true;
                if (CurrentQue == lastindex)
                {
                    IsRightArrowIconVisibile = false;
                    if (AppPreferences.IsHindi)
                    {
                        btnNextAndSubmit = "सब्मिट";
                    }
                    else
                    {
                        btnNextAndSubmit = "Submit";
                    }
                    NextButtonColor = "#f44b42";
                }
                else
                {
                    IsRightArrowIconVisibile = true;
                    if (AppPreferences.IsHindi)
                    {
                        btnNextAndSubmit = "सेव और अगला";
                    }
                    else
                    {
                        btnNextAndSubmit = "Save & Next";
                    }
                    NextButtonColor = "#8fc740";
                }
            }
            else
            {
                IsDynamicButtonVisibile = true;
                Isnextbtn = true;

                if (CurrentPosition == 0)
                {
                    Ispreviousbtn = false;
                    IsRightArrowIconVisibile = true;
                    if (AppPreferences.IsHindi)
                    {
                        btnNextAndSubmit = "सेव और अगला";
                    }
                    else
                    {
                        btnNextAndSubmit = "Save & Next";
                    }
                    NextButtonColor = "#8fc740";
                }
                else if (CurrentQue == lastindex)
                {
                    Ispreviousbtn = true;
                    IsRightArrowIconVisibile = false;
                    if (AppPreferences.IsHindi)
                    {
                        btnNextAndSubmit = "सब्मिट";
                    }
                    else
                    {
                        btnNextAndSubmit = "Submit";
                    }
                    NextButtonColor = "#f44b42";
                }
                else if (CurrentPosition > 0)
                {
                    Ispreviousbtn = true;
                    IsRightArrowIconVisibile = true;
                    if (AppPreferences.IsHindi)
                    {
                        btnNextAndSubmit = "सेव और अगला";
                    }
                    else
                    {
                        btnNextAndSubmit = "Save & Next";
                    }
                    NextButtonColor = "#8fc740";
                }
            }
        }
        #endregion

        #region  BehaviourLoadQuestions
        public void BehaviourLoadQuestions()
        {
            try
            {
                if ((AppPreferences.IsEnglish != AppPreferences.IsToggledEnglish) || (AppPreferences.IsHindi != AppPreferences.IsToggledHindi))
                {
                    if (IsVisbleBehaviourExamSelectionPart)
                    {
                        // LoadBehaviourQuestions();
                        var data = _localDB.GetAllDataBasedOnGroupId("4");
                        //ListViewItemSource = new List<EnglishQuestion>(data);
                        var Hindidata = _localDB.GetAllHindiQuesitonsByGroupId(ExamGroupID);

                        if (AppPreferences.IsHindi == true)
                        {
                            lastindex = int.Parse(Hindidata.Count().ToString());
                            ListViewItemSource = new List<EnglishQuestion>(Hindidata);
                            StronglyAgree = "पूरी तरह सहमत";
                            Agree = "सहमत";
                            NotSure = "अनिश्चित";
                            Disagree = "असहमत";
                            StrongDisagree = "पूरी तरह से असहमत";
                        }
                        else //if (AppPreferences.IsEnglish == true)
                        {
                            lastindex = int.Parse(data.Count().ToString());
                            ListViewItemSource = new List<EnglishQuestion>(data);
                            StronglyAgree = "StronglyAgree";
                            Agree = "Agree";
                            NotSure = "NotSure";
                            Disagree = "Disagree";
                            StrongDisagree = "StrongDisagree";

                        }

                        UpdateExamGroupStatus();
                    }
                }
                faQuestion1 = (string)Application.Current.Resources["RadioButtonIcon"];
                faQuestion2 = (string)Application.Current.Resources["RadioButtonIcon"];
                OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                OptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                _questiondata = ListViewItemSource.ElementAt(CurrentPosition);

                if (_questiondata != null)
                {
                    CurrentQuestionID = _questiondata.QuestionId;
                    Question = _questiondata.Question;
                    Question1 = _questiondata.ChoiceA;
                    Question2 = _questiondata.ChoiceB;

                    UpdateLastQuestionViewedPositionInExamGroupTable();
                    //BehaviourGetSelectedAnswerIfAlreadyAnswered();

                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "AssessmentViewModel.BehaviourLoadQuestions");
            }

        }
        #endregion

        #region Load Question Every Button Click and Load List StartUp
        public int CurrentQuestionID { get; set; }
        public void LoadQuestions()
        {
            try
            {
                OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                OptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                if (AppPreferences.IsHindi)
                {
                    LblCurrentQuestion = lastindex + " में से " + CurrentQue;
                }
                else
                {
                    LblCurrentQuestion = CurrentQue + " of " + lastindex;
                }

                BehaviourCurrentQue = "(" + CurrentQue + ")";

                if ((AppPreferences.IsEnglish != AppPreferences.IsToggledEnglish) || (AppPreferences.IsHindi != AppPreferences.IsToggledHindi))
                {
                    if (IsVisbleExaminationPart)
                    {
                        var examDuration = AppPreferences.ExamDuration;
                        if (examDuration != null)
                        {
                            Duration = AppPreferences.ExamDuration;
                        }
                        var data = _localDB.GetAllDataBasedOnGroupId(ExamGroupID);
                        var Hindidata = _localDB.GetAllHindiQuesitonsByGroupId(ExamGroupID);
                        if (ExamGroupID == "1")
                        {
                            IsShowPreferredLanguageToggle = false;
                            ListViewItemSource = new List<EnglishQuestion>(data);
                        }
                        else
                        {
                            IsShowPreferredLanguageToggle = true;
                            if (AppPreferences.IsHindi == true)
                            {
                                ListViewItemSource = new List<EnglishQuestion>(Hindidata);
                            }
                            else //if (AppPreferences.IsEnglish == true)
                            {
                                ListViewItemSource = new List<EnglishQuestion>(data);
                            }

                        }
                        UpdateExamGroupStatus();
                    }
                }
                if (int.Parse(AppPreferences.PreferredLanguageCount) > 1 && int.Parse(ExamGroupID) != 1)
                {
                    IsShowPreferredLanguageToggle = true;
                }
                else
                {
                    IsShowPreferredLanguageToggle = false;
                }
                _questiondata = ListViewItemSource.ElementAt(CurrentPosition);
                if (_questiondata != null)
                {
                    CurrentQuestionID = _questiondata.QuestionId;
                    UpdateLastQuestionViewedPositionInExamGroupTable();
                    // GetSelectedAnswerIfAlreadyAnswered();

                    #region Question
                    if (string.IsNullOrEmpty(_questiondata.Question))
                    {
                        IsQueImage = false;
                        IsQueContent = false;
                    }
                    else if ((_questiondata.Question.Contains(".jpg") || _questiondata.Question.Contains(".jpeg") || _questiondata.Question.Contains(".png") || _questiondata.Question.Contains("gif")) && (Device.RuntimePlatform == Device.Android || Device.RuntimePlatform == Device.iOS))
                    {
                        IsQueImage = true;
                        IsQueContent = false;
                        Question = _questiondata.Question.Replace("\n", string.Empty);
                    }
                    else
                    {
                        IsQueImage = false;
                        IsQueContent = true;
                        Question = _questiondata.Question.Replace("\n", string.Empty);
                        //Question = WebUtility.HtmlDecode(_questiondata.Question);
                        //if (int.Parse(ExamGroupID) != 7)
                        //{
                        //    Question = Regex.Replace(_questiondata.Question.Replace("\n", string.Empty), "<.*?>", String.Empty);
                        //}
                        //else
                        //{
                        //    Question = Regex.Replace(Regex.Replace(_questiondata.Question.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                        //}

                        System.Diagnostics.Debug.WriteLine("Question-- >" + Question);
                    }
                    #endregion

                    #region Option A
                    if (string.IsNullOrEmpty(_questiondata.ChoiceA))
                    {
                        IsQueImageOptionA = false;
                        IsQueContentOptionA = false;
                    }
                    else if ((_questiondata.ChoiceA.Contains(".jpg") || _questiondata.ChoiceA.Contains(".jpeg") ||
                        _questiondata.ChoiceA.Contains(".png") || _questiondata.Question.Contains("gif")) && (Device.RuntimePlatform == Device.Android || Device.RuntimePlatform == Device.iOS))
                    {
                        IsQueImageOptionA = true;
                        IsQueContentOptionA = false;
                        OptionA = _questiondata.ChoiceA.Replace("\n", string.Empty);
                    }
                    else
                    {
                        IsQueImageOptionA = false;
                        IsQueContentOptionA = true;
                        if (int.Parse(ExamGroupID) != 7)
                        {
                            OptionA = Regex.Replace(_questiondata.ChoiceA.Replace("\n", string.Empty), "<.*?>", String.Empty);

                        }
                        else
                        {
                            OptionA = Regex.Replace(Regex.Replace(_questiondata.ChoiceA.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                        }

                        System.Diagnostics.Debug.WriteLine("OptionA-->" + OptionA);

                    }
                    #endregion

                    #region Option B
                    if (string.IsNullOrEmpty(_questiondata.ChoiceB))
                    {
                        IsQueImageOptionB = false;
                        IsQueContentOptionB = false;
                    }
                    else if ((_questiondata.ChoiceB.Contains(".jpg") || _questiondata.ChoiceB.Contains(".jpeg") || _questiondata.ChoiceB.Contains(".png") || _questiondata.Question.Contains("gif")) && (Device.RuntimePlatform == Device.Android || Device.RuntimePlatform == Device.iOS))
                    {
                        IsQueImageOptionB = true;
                        IsQueContentOptionB = false;
                        OptionB = _questiondata.ChoiceB.Replace("\n", string.Empty);
                    }
                    else
                    {
                        IsQueImageOptionB = false;
                        IsQueContentOptionB = true;
                        if (int.Parse(ExamGroupID) != 7)
                        {
                            OptionB = Regex.Replace(_questiondata.ChoiceB.Replace("\n", string.Empty), "<.*?>", String.Empty);

                        }
                        else
                        {
                            OptionB = Regex.Replace(Regex.Replace(_questiondata.ChoiceB.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                        }
                        //OptionB = Regex.Replace(_questiondata.ChoiceB.Replace("\n", string.Empty), "<.*?>", String.Empty);
                        System.Diagnostics.Debug.WriteLine("OptionB-->" + OptionB);
                    }
                    #endregion

                    #region Option C
                    if (string.IsNullOrEmpty(_questiondata.ChoiceC))
                    {
                        IsQueImageOptionC = false;
                        IsQueContentOptionC = false;
                    }
                    else if ((_questiondata.ChoiceC.Contains(".jpg") || _questiondata.ChoiceC.Contains(".jpeg") || _questiondata.ChoiceC.Contains(".png") || _questiondata.Question.Contains("gif")) && (Device.RuntimePlatform == Device.Android || Device.RuntimePlatform == Device.iOS))
                    {
                        IsQueImageOptionC = true;
                        IsQueContentOptionC = false;
                        OptionC = _questiondata.ChoiceC.Replace("\n", string.Empty);
                    }
                    else
                    {
                        IsQueImageOptionC = false;
                        IsQueContentOptionC = true;
                        if (int.Parse(ExamGroupID) != 7)
                        {
                            OptionC = Regex.Replace(_questiondata.ChoiceC.Replace("\n", string.Empty), "<.*?>", String.Empty);

                        }
                        else
                        {
                            OptionC = Regex.Replace(Regex.Replace(_questiondata.ChoiceC.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                        }
                        //OptionC = Regex.Replace(_questiondata.ChoiceC.Replace("\n", string.Empty), "<.*?>", String.Empty);
                        System.Diagnostics.Debug.WriteLine("OptionC-->" + OptionC);
                    }
                    #endregion

                    #region Option D
                    if (string.IsNullOrEmpty(_questiondata.ChoiceD))
                    {
                        IsQueImageOptionD = false;
                        IsQueContentOptionD = false;
                    }
                    else if ((_questiondata.ChoiceD.Contains(".jpg") || _questiondata.ChoiceD.Contains(".jpeg") || _questiondata.ChoiceD.Contains(".png") || _questiondata.Question.Contains("gif")) && (Device.RuntimePlatform == Device.Android || Device.RuntimePlatform == Device.iOS))
                    {
                        IsQueImageOptionD = true;
                        IsQueContentOptionD = false;
                        OptionD = _questiondata.ChoiceD.Replace("\n", string.Empty);

                    }
                    else
                    {
                        IsQueImageOptionD = false;
                        IsQueContentOptionD = true;
                        if (int.Parse(ExamGroupID) != 7)
                        {
                            OptionD = Regex.Replace(_questiondata.ChoiceD.Replace("\n", string.Empty), "<.*?>", String.Empty);

                        }
                        else
                        {
                            OptionD = Regex.Replace(Regex.Replace(_questiondata.ChoiceD.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                        }
                        //OptionD = Regex.Replace(_questiondata.ChoiceD.Replace("\n", string.Empty), "<.*?>", String.Empty);
                        System.Diagnostics.Debug.WriteLine("OptionD-->" + OptionD);
                    }
                    #endregion
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "AssessmentViewModel.LoadQuestions");
            }
        }
        #endregion

        #region BehaviourGetSelectedAnswerIfAlreadyAnswered
        private void BehaviourGetSelectedAnswerIfAlreadyAnswered()
        {
            try
            {
                var value = _localDB.GetSelectedAnswerIfAlreadyAnswered(_questiondata.QuestionId);
                if (value != null)
                {
                    if (value.UserAnswer.Contains("A,A"))
                    {
                        DoOperation("tpgQuestion1");
                        DoOperation("behaviourtpgOptionA");
                    }
                    else if (value.UserAnswer.Contains("A,B"))
                    {
                        DoOperation("tpgQuestion1");
                        DoOperation("behaviourtpgOptionB");
                    }
                    else if (value.UserAnswer.Contains("A,C"))
                    {
                        DoOperation("tpgQuestion1");
                        DoOperation("behaviourtpgOptionC");
                    }
                    else if (value.UserAnswer.Contains("A,D"))
                    {
                        DoOperation("tpgQuestion1");
                        DoOperation("behaviourtpgOptionD");
                    }
                    else if (value.UserAnswer.Contains("A,E"))
                    {
                        DoOperation("tpgQuestion1");
                        DoOperation("behaviourtpgOptionE");
                    }
                    else if (value.UserAnswer.Contains("B,A"))
                    {
                        DoOperation("tpgQuestion2");
                        DoOperation("behaviourtpgOptionA");
                    }
                    else if (value.UserAnswer.Contains("B,B"))
                    {
                        DoOperation("tpgQuestion2");
                        DoOperation("behaviourtpgOptionB");
                    }
                    else if (value.UserAnswer.Contains("B,C"))
                    {
                        DoOperation("tpgQuestion2");
                        DoOperation("behaviourtpgOptionC");
                    }
                    else if (value.UserAnswer.Contains("B,D"))
                    {
                        DoOperation("tpgQuestion2");
                        DoOperation("behaviourtpgOptionD");
                    }
                    else if (value.UserAnswer.Contains("B,E"))
                    {
                        DoOperation("tpgQuestion2");
                        DoOperation("behaviourtpgOptionE");
                    }
                    else
                    {
                        faQuestion1 = (string)Application.Current.Resources["RadioButtonIcon"];
                        faQuestion2 = (string)Application.Current.Resources["RadioButtonIcon"];
                        OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                        OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                        OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                        OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                        OptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    }
                }
                else
                {
                    faQuestion1 = (string)Application.Current.Resources["RadioButtonIcon"];
                    faQuestion2 = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "AssessmentViewModel.BehaviourGetSelectedAnswerIfAlreadyAnswered");
            }
        }
        #endregion

        #region GetSelectedAnswerIfAlreadyAnswered
        private void GetSelectedAnswerIfAlreadyAnswered()
        {
            try
            {
                var value = _localDB.GetSelectedAnswerIfAlreadyAnswered(_questiondata.QuestionId);
                if (value != null)
                {
                    if (value.UserAnswer.Contains("A"))
                    {
                        DoOperation("tpgOptionA");
                    }
                    else if (value.UserAnswer.Contains("B"))
                    {

                        DoOperation("tpgOptionB");
                    }
                    else if (value.UserAnswer.Contains("C"))
                    {

                        DoOperation("tpgOptionC");
                    }
                    else if (value.UserAnswer.Contains("D"))
                    {

                        DoOperation("tpgOptionD");
                    }
                    else
                    {
                        OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                        OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                        OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                        OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    }
                }
                else
                {
                    OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "AssessmentViewModel.GetSelectedAnswerIfAlreadyAnswered");
            }
        }
        #endregion

        #region InsertRecordInExamHistoryTable
        public void InsertRecordInExamHistoryTable()
        {
            try
            {
                _ExamAnswerHistoryData = new ExamAnswerHistoryModel();
                _ExamAnswerHistoryData.AssignedID = AppPreferences.AssignedID;// Application.Current.Properties[AppPreferenceKey.AssignedID].ToString();
                _ExamAnswerHistoryData.QuestionID = _questiondata.QuestionId.ToString();
                _ExamAnswerHistoryData.UserAnswer = _questiondata.UserKeyed;
                _ExamAnswerHistoryData.LastUpdatedQuestionID = _questiondata.QuestionId.ToString();
                _ExamAnswerHistoryData.LastUpdatedQuestionTime = ServerTimerText;
                _ExamAnswerHistoryData.LastUpdatedSystemDate = ServerTimerText;
                _ExamAnswerHistoryData.IsSynchedUp = false;
                if (int.Parse(AppPreferences.PreferredLanguageCount) > 1)
                {
                    foreach (var item in AppPreferences.AvailableLanguage)
                    {
                        if (AppPreferences.IsToggledHindi)
                        {
                            if (item.LanguageName == "Hindi")
                            {
                                _ExamAnswerHistoryData.LanguageId = int.Parse(item.LanguageId);
                            }
                        }
                        else if (AppPreferences.IsToggledEnglish)
                        {
                            if (item.LanguageName == "English")
                            {
                                _ExamAnswerHistoryData.LanguageId = int.Parse(item.LanguageId);
                            }
                        }
                        else
                        {
                            _ExamAnswerHistoryData.LanguageId = int.Parse(AppPreferences.SelectedlanguageID);
                        }
                    }
                }
                else
                {
                    _ExamAnswerHistoryData.LanguageId = int.Parse(AppPreferences.SelectedlanguageID);
                }
                _ExamAnswerHistoryData.IsChargerConnected = false;
                _ExamAnswerHistoryData.IsHeadsetConnected = false;

                // _ExamAnswerHistoryData.IsChargerConnected = DependencyService.Get<IExternalDeviceStatus>().isBluetoothStatus();
                //  _ExamAnswerHistoryData.IsHeadsetConnected = DependencyService.Get<IExternalDeviceStatus>().isHeadPhoneConnected();
                _localDB.AddExamAnswerHistoryData(_ExamAnswerHistoryData);
                //Checking purpose only
                var CheckTable = _localDB.GetExamAnswerHistoryData();
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "AssessmentViewModel.InsertRecordInExamHistoryTable");
            }
        }
        #endregion

        #region InsertRecordInBehaviourExamHistoryTable
        public void InsertRecordInBehaviourExamHistoryTable()
        {
            try
            {
                _ExamAnswerHistoryData = new ExamAnswerHistoryModel();
                _ExamAnswerHistoryData.AssignedID = AppPreferences.AssignedID;//Application.Current.Properties[AppPreferenceKey.AssignedID].ToString();
                _ExamAnswerHistoryData.QuestionID = _questiondata.QuestionId.ToString();
                _ExamAnswerHistoryData.UserAnswer = _questiondata.UserKeyed + "," + selectedOption;
                _ExamAnswerHistoryData.LastUpdatedQuestionID = _questiondata.QuestionId.ToString();
                _ExamAnswerHistoryData.LastUpdatedQuestionTime = ServerTimerText;
                _ExamAnswerHistoryData.LastUpdatedSystemDate = ServerTimerText;
                _ExamAnswerHistoryData.IsSynchedUp = false;
                if (int.Parse(AppPreferences.PreferredLanguageCount) > 1)
                {
                    foreach (var item in AppPreferences.AvailableLanguage)
                    {
                        if (AppPreferences.IsToggledHindi)
                        {
                            if (item.LanguageName == "Hindi")
                            {
                                _ExamAnswerHistoryData.LanguageId = int.Parse(item.LanguageId);
                            }
                        }
                        else if (AppPreferences.IsToggledEnglish)
                        {
                            if (item.LanguageName == "English")
                            {
                                _ExamAnswerHistoryData.LanguageId = int.Parse(item.LanguageId);
                            }
                        }
                        else
                        {
                            _ExamAnswerHistoryData.LanguageId = int.Parse(AppPreferences.SelectedlanguageID);
                        }
                    }
                }
                else
                {
                    _ExamAnswerHistoryData.LanguageId = int.Parse(AppPreferences.SelectedlanguageID);
                }
                _ExamAnswerHistoryData.IsChargerConnected = false;
                _ExamAnswerHistoryData.IsHeadsetConnected = false;
                _localDB.AddExamAnswerHistoryData(_ExamAnswerHistoryData);
                //Checking purpose only
                var CheckTable = _localDB.GetExamAnswerHistoryData();
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "AssessmentViewModel.InsertRecordInBehaviourExamHistoryTable");
            }
        }
        #endregion

        #region SetButtonColor
        private Color SetButtonColor(int CurrentQuestion)
        {
            if (!string.IsNullOrEmpty(_questiondata.UserKeyed))
            {
                return ButtonColorAnswerwed;

            }
            else
            {
                return ButtonColorNotAnswerwed;
            }

        }
        #endregion

        #region SetButtonColorFromBulk
        private Color SetButtonColorFromBulk(string answerType)
        {
            if (answerType == "Answered")
            {
                return ButtonColorAnswerwed;

            }
            else if (answerType == "NotAnswered")
            {
                return ButtonColorNotAnswerwed;
            }
            else

                return ButtonColorNotVisited;
        }
        #endregion

        #region LoadButton Collor From Constructor Call
        private void LoadButtonColorFromCunstructorCall()
        {
            int Count = 1;
            string answerType = string.Empty;
            foreach (var item in ListViewItemSource)
            {
                var resultCheckAnswer = _localDB.GetAllAnswerBasedOnQuestionId(item.QuestionId.ToString());
                foreach (var obj in resultCheckAnswer)
                {

                    if (obj.UserAnswer != string.Empty)
                    {
                        //AnswerCount++;
                        //if(answerType==string.Empty)
                        answerType = "Answered";
                        string[] value = { Count.ToString(), answerType };
                        LoadButtonColorIfAlreadyExamComplete(value);
                    }
                    else
                    {
                        var a = _localDB.CheckQuestionIdIsAlreadyExist(item.QuestionId.ToString());
                        if (a.Count() > 0)
                        {
                            //visited not answered
                            answerType = "NotAnswered";
                            string[] value = { Count.ToString(), answerType };
                            LoadButtonColorIfAlreadyExamComplete(value);

                        }
                        else
                        {

                            //not visied
                            answerType = "NotVisited";
                            string[] value = { Count.ToString(), answerType };
                            LoadButtonColorIfAlreadyExamComplete(value);
                        }

                    }

                }
                Count++;
            }

        }

        #endregion

        #region LoadButtonColor If Already Complete the exam
        private void LoadButtonColorIfAlreadyExamComplete(string[] count)
        {
            switch (count[0])
            {
                case "1":
                    ButtonColor1 = SetButtonColorFromBulk(count[1]);
                    break;
                case "2":
                    ButtonColor2 = SetButtonColorFromBulk(count[1]);
                    break;
                case "3":
                    ButtonColor3 = SetButtonColorFromBulk(count[1]);
                    break;
                case "4":
                    ButtonColor4 = SetButtonColorFromBulk(count[1]);
                    break;
                case "5":
                    ButtonColor5 = SetButtonColorFromBulk(count[1]);
                    break;
                case "6":
                    ButtonColor6 = SetButtonColorFromBulk(count[1]);
                    break;
                case "7":
                    ButtonColor7 = SetButtonColorFromBulk(count[1]);
                    break;
                case "8":
                    ButtonColor8 = SetButtonColorFromBulk(count[1]);
                    break;
                case "9":
                    ButtonColor9 = SetButtonColorFromBulk(count[1]);
                    break;
                case "10":
                    ButtonColor10 = SetButtonColorFromBulk(count[1]);
                    break;

                case "11":
                    ButtonColor11 = SetButtonColorFromBulk(count[1]);
                    break;
                case "12":
                    ButtonColor12 = SetButtonColorFromBulk(count[1]);
                    break;
                case "13":
                    ButtonColor13 = SetButtonColorFromBulk(count[1]);
                    break;
                case "14":
                    ButtonColor14 = SetButtonColorFromBulk(count[1]);
                    break;
                case "15":
                    ButtonColor15 = SetButtonColorFromBulk(count[1]);
                    break;
                case "16":
                    ButtonColor16 = SetButtonColorFromBulk(count[1]);
                    break;
                case "17":
                    ButtonColor17 = SetButtonColorFromBulk(count[1]);
                    break;
                case "18":
                    ButtonColor18 = SetButtonColorFromBulk(count[1]);
                    break;
                case "19":
                    ButtonColor19 = SetButtonColorFromBulk(count[1]);
                    break;
                case "20":
                    ButtonColor20 = SetButtonColorFromBulk(count[1]);
                    break;
                case "21":
                    ButtonColor21 = SetButtonColorFromBulk(count[1]);
                    break;
                case "22":
                    ButtonColor22 = SetButtonColorFromBulk(count[1]);
                    break;
                case "23":
                    ButtonColor23 = SetButtonColorFromBulk(count[1]);
                    break;
                case "24":
                    ButtonColor24 = SetButtonColorFromBulk(count[1]);
                    break;
                case "25":
                    ButtonColor25 = SetButtonColorFromBulk(count[1]);
                    break;
                case "26":
                    ButtonColor26 = SetButtonColorFromBulk(count[1]);
                    break;
                case "27":
                    ButtonColor27 = SetButtonColorFromBulk(count[1]);
                    break;
                case "28":
                    ButtonColor28 = SetButtonColorFromBulk(count[1]);
                    break;
                case "29":
                    ButtonColor29 = SetButtonColorFromBulk(count[1]);
                    break;
                case "30":
                    ButtonColor30 = SetButtonColorFromBulk(count[1]);
                    break;

                case "31":
                    ButtonColor31 = SetButtonColorFromBulk(count[1]);
                    break;
                case "32":
                    ButtonColor32 = SetButtonColorFromBulk(count[1]);
                    break;
                case "33":
                    ButtonColor33 = SetButtonColorFromBulk(count[1]);
                    break;
                case "34":
                    ButtonColor34 = SetButtonColorFromBulk(count[1]);
                    break;
                case "35":
                    ButtonColor35 = SetButtonColorFromBulk(count[1]);
                    break;
                case "36":
                    ButtonColor36 = SetButtonColorFromBulk(count[1]);
                    break;
                case "37":
                    ButtonColor37 = SetButtonColorFromBulk(count[1]);
                    break;
                case "38":
                    ButtonColor38 = SetButtonColorFromBulk(count[1]);
                    break;
                case "39":
                    ButtonColor39 = SetButtonColorFromBulk(count[1]);
                    break;
                case "40":
                    ButtonColor40 = SetButtonColorFromBulk(count[1]);
                    break;
            }
        }
        #endregion

        #region ChangeButtonColorSwitch
        public void ChangeButtonColorSwitch(int CurrentQeustionButtonColor)
        {
            switch (CurrentQeustionButtonColor)
            {
                case 1:
                    ButtonColor1 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 2:
                    ButtonColor2 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 3:
                    ButtonColor3 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 4:
                    ButtonColor4 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 5:
                    ButtonColor5 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 6:
                    ButtonColor6 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 7:
                    ButtonColor7 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 8:
                    ButtonColor8 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 9:
                    ButtonColor9 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 10:
                    ButtonColor10 = SetButtonColor(CurrentQeustionButtonColor);
                    break;

                case 11:
                    ButtonColor11 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 12:
                    ButtonColor12 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 13:
                    ButtonColor13 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 14:
                    ButtonColor14 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 15:
                    ButtonColor15 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 16:
                    ButtonColor16 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 17:
                    ButtonColor17 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 18:
                    ButtonColor18 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 19:
                    ButtonColor19 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 20:
                    ButtonColor20 = SetButtonColor(CurrentQeustionButtonColor);
                    break;

                case 21:
                    ButtonColor21 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 22:
                    ButtonColor22 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 23:
                    ButtonColor23 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 24:
                    ButtonColor24 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 25:
                    ButtonColor25 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 26:
                    ButtonColor26 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 27:
                    ButtonColor27 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 28:
                    ButtonColor28 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 29:
                    ButtonColor29 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 30:
                    ButtonColor30 = SetButtonColor(CurrentQeustionButtonColor);
                    break;

                case 31:
                    ButtonColor31 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 32:
                    ButtonColor32 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 33:
                    ButtonColor33 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 34:
                    ButtonColor34 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 35:
                    ButtonColor35 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 36:
                    ButtonColor36 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 37:
                    ButtonColor37 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 38:
                    ButtonColor38 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 39:
                    ButtonColor9 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 40:
                    ButtonColor40 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
            }
        }
        #endregion

        #region button color
        private Color _buttonColor1;
        public Color ButtonColor1
        {
            get { return _buttonColor1; }
            set { _buttonColor1 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor2;
        public Color ButtonColor2
        {
            get { return _buttonColor2; }
            set { _buttonColor2 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor3;
        public Color ButtonColor3
        {
            get { return _buttonColor3; }
            set { _buttonColor3 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor4;
        public Color ButtonColor4
        {
            get { return _buttonColor4; }
            set { _buttonColor4 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor5;
        public Color ButtonColor5
        {
            get { return _buttonColor5; }
            set { _buttonColor5 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor6;
        public Color ButtonColor6
        {
            get { return _buttonColor6; }
            set { _buttonColor6 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor7;
        public Color ButtonColor7
        {
            get { return _buttonColor7; }
            set { _buttonColor7 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor8;
        public Color ButtonColor8
        {
            get { return _buttonColor8; }
            set { _buttonColor8 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor9;
        public Color ButtonColor9
        {
            get { return _buttonColor9; }
            set { _buttonColor9 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor10;
        public Color ButtonColor10
        {
            get { return _buttonColor10; }
            set { _buttonColor10 = value; OnPropertyChanged(); }
        }

        private Color _buttonColor11;
        public Color ButtonColor11
        {
            get { return _buttonColor11; }
            set { _buttonColor11 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor12;
        public Color ButtonColor12
        {
            get { return _buttonColor12; }
            set { _buttonColor12 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor13;
        public Color ButtonColor13
        {
            get { return _buttonColor13; }
            set { _buttonColor13 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor14;
        public Color ButtonColor14
        {
            get { return _buttonColor14; }
            set { _buttonColor14 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor15;
        public Color ButtonColor15
        {
            get { return _buttonColor15; }
            set { _buttonColor15 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor16;
        public Color ButtonColor16
        {
            get { return _buttonColor16; }
            set { _buttonColor16 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor17;
        public Color ButtonColor17
        {
            get { return _buttonColor17; }
            set { _buttonColor17 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor18;
        public Color ButtonColor18
        {
            get { return _buttonColor18; }
            set { _buttonColor18 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor19;
        public Color ButtonColor19
        {
            get { return _buttonColor19; }
            set { _buttonColor19 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor20;
        public Color ButtonColor20
        {
            get { return _buttonColor20; }
            set { _buttonColor20 = value; OnPropertyChanged(); }
        }

        private Color _buttonColor21;
        public Color ButtonColor21
        {
            get { return _buttonColor21; }
            set { _buttonColor21 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor22;
        public Color ButtonColor22
        {
            get { return _buttonColor22; }
            set { _buttonColor22 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor23;
        public Color ButtonColor23
        {
            get { return _buttonColor23; }
            set { _buttonColor23 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor24;
        public Color ButtonColor24
        {
            get { return _buttonColor24; }
            set { _buttonColor24 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor25;
        public Color ButtonColor25
        {
            get { return _buttonColor25; }
            set { _buttonColor25 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor26;
        public Color ButtonColor26
        {
            get { return _buttonColor26; }
            set { _buttonColor26 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor27;
        public Color ButtonColor27
        {
            get { return _buttonColor27; }
            set { _buttonColor27 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor28;
        public Color ButtonColor28
        {
            get { return _buttonColor28; }
            set { _buttonColor28 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor29;
        public Color ButtonColor29
        {
            get { return _buttonColor29; }
            set { _buttonColor29 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor30;
        public Color ButtonColor30
        {
            get { return _buttonColor30; }
            set { _buttonColor30 = value; OnPropertyChanged(); }
        }

        private Color _buttonColor31;
        public Color ButtonColor31
        {
            get { return _buttonColor31; }
            set { _buttonColor31 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor32;
        public Color ButtonColor32
        {
            get { return _buttonColor32; }
            set { _buttonColor32 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor33;
        public Color ButtonColor33
        {
            get { return _buttonColor33; }
            set { _buttonColor33 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor34;
        public Color ButtonColor34
        {
            get { return _buttonColor34; }
            set { _buttonColor34 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor35;
        public Color ButtonColor35
        {
            get { return _buttonColor35; }
            set { _buttonColor35 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor36;
        public Color ButtonColor36
        {
            get { return _buttonColor36; }
            set { _buttonColor36 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor37;
        public Color ButtonColor37
        {
            get { return _buttonColor37; }
            set { _buttonColor37 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor38;
        public Color ButtonColor38
        {
            get { return _buttonColor38; }
            set { _buttonColor38 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor39;
        public Color ButtonColor39
        {
            get { return _buttonColor39; }
            set { _buttonColor39 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor40;
        public Color ButtonColor40
        {
            get { return _buttonColor40; }
            set { _buttonColor40 = value; OnPropertyChanged(); }
        }
        #endregion

        #region FullProperties

        private bool _IsRefreshVisible;

        public bool IsRefreshVisible
        {
            get { return _IsRefreshVisible; }
            set { _IsRefreshVisible = value; OnPropertyChanged(); }
        }


        //private bool _IsRefreshView;
        //public bool IsRefreshView
        //{
        //    get { return _IsRefreshView; }
        //    set
        //    {
        //        _IsRefreshView = value;

        //        OnPropertyChanged();
        //        //if (IsVisbleExamSelectionPart)
        //        //{
        //        //    IsVisbleExamSelectionPart = false;
        //        //    IsVisbleExaminationPart = true;
        //        //}
        //        //else
        //        //{
        //        //    IsVisbleExaminationPart = false;
        //        //    IsVisbleExamSelectionPart = true;
        //        //}
        //    }
        //}



        private Boolean _IsVisbleExamSelectionPart;
        public Boolean IsVisbleExamSelectionPart
        {
            get { return _IsVisbleExamSelectionPart; }
            set { _IsVisbleExamSelectionPart = value; OnPropertyChanged(); }
        }

        private Boolean _IsVisbleExaminationPart;
        public Boolean IsVisbleExaminationPart
        {
            get { return _IsVisbleExaminationPart; }
            set { _IsVisbleExaminationPart = value; OnPropertyChanged(); }
        }



        private bool _IsShowCameraPreView;
        public bool IsShowCameraPreView
        {
            get { return _IsShowCameraPreView; }
            set { _IsShowCameraPreView = value; OnPropertyChanged(); }
        }
        private string _arrowChange;
        public string ArrowChange
        {
            get { return _arrowChange; }
            set { _arrowChange = value; OnPropertyChanged(); }
        }

        private Boolean isShowIOSOnly;
        public Boolean IsShowIOSOnly
        {
            get { return isShowIOSOnly; }
            set { isShowIOSOnly = value; OnPropertyChanged(); }
        }


        private bool _Termsvisible;

        public bool Termsvisible
        {
            get { return _Termsvisible; }
            set { _Termsvisible = value; OnPropertyChanged(); }
        }


        private String candidateName;
        public String CandidateName
        {
            get { return candidateName; }
            set { candidateName = value; OnPropertyChanged(); }
        }
        private String _DownTimer;
        public String DownTimer
        {
            get { return _DownTimer; }
            set { _DownTimer = value; OnPropertyChanged(); }
        }

        private bool _IsVisibleDownTimer;
        public bool IsVisibleDownTimer
        {
            get { return _IsVisibleDownTimer; }
            set { _IsVisibleDownTimer = value; OnPropertyChanged(); }
        }

        private String userProfilePicture;
        public String UserProfilePicture
        {
            get { return userProfilePicture; }
            set { userProfilePicture = value; OnPropertyChanged(); }
        }

        private String candidateHireMeeID;
        public String CandidateHireMeeID
        {
            get { return candidateHireMeeID; }
            set { candidateHireMeeID = value; OnPropertyChanged(); }
        }

        private String totalDuration;
        public String TotalDuration
        {
            get { return totalDuration; }
            set { totalDuration = value; OnPropertyChanged(); }
        }


        private Color _ExamFinishBtnBackColor;

        public Color ExamFinishBtnBackColor
        {
            get { return _ExamFinishBtnBackColor; }
            set { _ExamFinishBtnBackColor = value; OnPropertyChanged(); }
        }


        private StackLayout _dynamicBtnStack;

        public StackLayout DynamicBtnStack
        {
            get { return _dynamicBtnStack; }
            set { _dynamicBtnStack = value; }
        }


        private StackLayout _accordianStack;

        public StackLayout AccoridanStack
        {
            get { return _accordianStack; }
            set { _accordianStack = value; }
        }


        private String timerText;
        public String TimerText
        {
            get { return timerText; }
            set { timerText = value; OnPropertyChanged(); }
        }

        private String serverTimerText;
        public String ServerTimerText
        {
            get { return serverTimerText; }
            set { serverTimerText = value; OnPropertyChanged(); }
        }


        private string _faQuestion1;
        public string faQuestion1
        {
            get { return _faQuestion1; }
            set { _faQuestion1 = value; OnPropertyChanged(); }
        }
        private string _faQuestion2;
        public string faQuestion2
        {
            get { return _faQuestion2; }
            set { _faQuestion2 = value; OnPropertyChanged(); }
        }
        private string _optionERadiobutton;
        public string OptionERadiobutton
        {
            get { return _optionERadiobutton; }
            set { _optionERadiobutton = value; OnPropertyChanged(); }
        }
        #region Color Property for Choosed Question
        private Color _QuestionOneRadioColor;
        public Color QuestionOneRadioColor
        {
            get { return _QuestionOneRadioColor; }
            set { _QuestionOneRadioColor = value; OnPropertyChanged(); }
        }
        private Color _QuestionTwoRadioColor;

        public Color QuestionTwoRadioColor
        {
            get { return _QuestionTwoRadioColor; }
            set { _QuestionTwoRadioColor = value; OnPropertyChanged(); }
        }
        private Color _QuestionOneTextColor;

        public Color QuestionOneTextColor
        {
            get { return _QuestionOneTextColor; }
            set { _QuestionOneTextColor = value; OnPropertyChanged(); }
        }
        private Color _QuestionTwoTextColor;
        public Color QuestionTwoTextColor
        {
            get { return _QuestionTwoTextColor; }
            set { _QuestionTwoTextColor = value; OnPropertyChanged(); }
        }

        private bool _IsOptionVisible;

        public bool IsOptionVisible
        {
            get { return _IsOptionVisible; }
            set { _IsOptionVisible = value; OnPropertyChanged(); }
        }




        private bool _IsVisbleBehaviourExamSelectionPart;
        public bool IsVisbleBehaviourExamSelectionPart
        {
            get { return _IsVisbleBehaviourExamSelectionPart; }
            set { _IsVisbleBehaviourExamSelectionPart = value; OnPropertyChanged(); }
        }
        private string _question1;
        public string Question1
        {
            get { return _question1; }
            set { _question1 = value; OnPropertyChanged(); }
        }
        private string _question2;
        public string Question2
        {
            get { return _question2; }
            set { _question2 = value; OnPropertyChanged(); }
        }

        private bool _IsVisibleGroupOfExamName;
        public bool IsVisibleGroupOfExamName
        {
            get { return _IsVisibleGroupOfExamName; }
            set { _IsVisibleGroupOfExamName = value; OnPropertyChanged(); }
        }




        #endregion

        #endregion
    }
}
