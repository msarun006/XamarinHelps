﻿using HireMe.Helpers;
using HireMe.Views.Assessment;
using MvvmHelpers;
using System;
using Xamarin.Forms;

namespace HireMe.ViewModels.Assessment
{
    public  class BannerInstructionViewModel : BaseViewModel
    {

        public Command OnCommand { get; set; }
        public BannerInstructionViewModel()
        {
            OnCommand = new Command(CommonFunction);
        }

        private void CommonFunction(object obj)
        {


            try
            {
                if (obj.ToString() == "skip")
                {
                    Application.Current.MainPage = new NavigationPage(new AssessmentLoginPage());
                    return;
                }
            }
            catch(Exception e)
            {
                SendErrorMessageToServer(e,"BannerInstructionViewModel.CommonFunction");
            }
            

        }


        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
