﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.Helpers.Assessment;
using HireMe.Interface;
using HireMe.LocalDataBase;
using HireMe.Models;
using HireMe.Models.Assessment.SQLTables;
using HireMe.Views;
using HireMe.Views.Assessment;
using MvvmHelpers;
using Plugin.Battery;
using Plugin.Connectivity;
using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using System;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace HireMe.ViewModels.Assessment
{
    public class ExternalDeviceStatusViewModel : BaseViewModel
    {
        #region Variable Declaration
        public INavigation navigationService { get; set; }
        public Command OnCommand { get; set; }
        public Boolean isValidBatteryLevel { get; set; }
        public Boolean isValidFrontCamera { get; set; }
        public SaveImageToLocal _saveAndExtractImages { get; set; }
        public Boolean isValidMemorySize { get; set; }

        public bool isClicked = true;
        private string _chargingStatusContent = string.Empty;
        private HttpCommonService _commonservice { get; set; }

        public LocalDataBase.LocalDB _localDB;
        public ExamAnswersModel _ExamAnswerData;
        public QuestionsRequestData _QuestionsDownloadRequest { get; set; }
        public EnglishQuestion _questionData { get; set; }
        #endregion

        #region Empty Constructor
        public ExternalDeviceStatusViewModel()
        {
            //OnCommand = new Command(CommonFunction);
            //isValidBatteryLevel = false;
            //isValidFrontCamera = false;
            //isValidMemorySize = false;

            //// IsShowBluetoothWarning = true;
            //IsShowMemoryWarning = true;
            //IsShowCameraWarning = true;
            //IsShowBatteryLevelWarning = true;

            //_saveAndExtractImages = new SaveImageToLocal();
            //_localDB = new LocalDataBase.LocalDB();
            //_QuestionsDownloadRequest = new QuestionsRequestData();
            //_questionData = new EnglishQuestion();
            //_ExamAnswerData = new ExamAnswersModel();
            //_commonservice = new HttpCommonService();
            ////CrossBattery.Current.BatteryChanged += (sender, args) =>
            ////{
            ////    BatteryLevel = args.RemainingChargePercent.ToString() + " %";
            ////    ChargerConnected = args.Status.ToString();
            //  CheckDeviceStatus();
            ////};

            //if (Device.RuntimePlatform == Device.iOS)
            //{
            //    IsShowIOSOnly = true;
            //    IsDetectorGrid = false;
            //}
            //else
            //{
            //    IsShowIOSOnly = false;
            //    IsDetectorGrid = true;
            //}

        }
        #endregion

        #region Constructor
        public ExternalDeviceStatusViewModel(INavigation navigation)
        {
            navigationService = navigation;
            OnCommand = new Command(CommonFunction);
            isValidBatteryLevel = false;
            isValidFrontCamera = false;
            isValidMemorySize = false;
            IsEnglish = false;
            IsHindi = true;
            // IsShowBluetoothWarning = true;
            IsShowMemoryWarning = true;
            IsShowCameraWarning = true;
            IsShowBatteryLevelWarning = true;

            _saveAndExtractImages = new SaveImageToLocal();
            _localDB = new LocalDataBase.LocalDB();

            _questionData = new EnglishQuestion();
            _ExamAnswerData = new ExamAnswersModel();
            _commonservice = new HttpCommonService();

            if (AppPreferences.IsHindi)
            {
                BatteryLevelMessage = "न्यूनतम " + AppPreferences.BatteryLevel + "% की आवश्यकता होती है";
            }
            else //if (AppPreferences.IsEnglish)
            {
                BatteryLevelMessage = "Minimum " + AppPreferences.BatteryLevel + "% require";
            }


            BatteryLevel = Plugin.Battery.CrossBattery.Current.RemainingChargePercent.ToString();
            _chargingStatusContent = Plugin.Battery.CrossBattery.Current.Status.ToString();
            if (!string.IsNullOrEmpty(_chargingStatusContent))
            {
                if (AppPreferences.IsHindi)
                {
                    if (_chargingStatusContent == "Charging")
                    {
                        ChargerConnected = "चार्जिंग";
                    }
                    else
                    {
                        ChargerConnected = "चार्ज नहीं हो रहा है";
                    }
                }
                else
                {
                    ChargerConnected = Plugin.Battery.CrossBattery.Current.Status.ToString();
                }
            }
            else
            {
                ChargerConnected = Plugin.Battery.CrossBattery.Current.Status.ToString();
            }


            //CrossBattery.Current.BatteryChanged += (sender, args) =>
            //{
            //    BatteryLevel = args.RemainingChargePercent.ToString() + " %";
            //    ChargerConnected = args.Status.ToString();
            CheckDeviceStatus();
            //};

            if (Device.RuntimePlatform == Device.iOS)
            {
                IsShowIOSOnly = true;
                IsDetectorGrid = false;
            }
            else
            {
                IsShowIOSOnly = false;
                IsDetectorGrid = true;
            }

        }
        #endregion


        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        #region AskRunTimePermission
        private async void AskRunTimePermissionAsync()
        {
            try
            {
                var status = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Camera);
                var storage = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Storage);

                if (status != PermissionStatus.Granted || storage != PermissionStatus.Granted)
                {
                    IsShowPermissionWarning = true;
                    if (AppPreferences.IsHindi)
                    {
                        PermissionsStatus = "से इनकार किया";
                    }
                    else
                    {
                        PermissionsStatus = "Denied";
                    }
                    //if (await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Camera))
                    //{
                    //    await UserDialogs.Instance.AlertAsync("Need Camera Permission", "Access Camera", "OK");
                    //}
                    //if (await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Storage))
                    //{
                    //    await UserDialogs.Instance.AlertAsync("Need Storage Permission", "Access Storage", "OK");
                    //}
                    var results = await CrossPermissions.Current.RequestPermissionsAsync(new[] { Permission.Camera, Permission.Storage });
                    if (results != null)
                    {
                        status = results[Permission.Camera];
                        storage = results[Permission.Storage];
                    }
                }

                if (status == PermissionStatus.Granted && storage == PermissionStatus.Granted)
                {
                    IsShowPermissionWarning = false;
                    if (AppPreferences.IsHindi)
                    {
                        PermissionsStatus = "स्वीकृत";
                    }
                    else
                    {
                        PermissionsStatus = "Granted";
                    }
                }
                else if (status != PermissionStatus.Unknown)
                {
                    IsShowPermissionWarning = true;
                    if (AppPreferences.IsHindi)
                    {
                        PermissionsStatus = "से इनकार किया";
                    }
                    else
                    {
                        PermissionsStatus = "Denied";
                    }

                    UserDialogs.Instance.Toast(MessageStringConstants.PermissionMessage);
                    //await UserDialogs.Instance.AlertAsync(MessageStringConstants.CameraMessage, MessageStringConstants.PermissionMessage, "OK");
                }



                if (Device.RuntimePlatform == Device.Android)
                {

                    var IsLolipopAboveVersion = DependencyService.Get<IMyDevice>().PermissionStatus();

                    if (IsLolipopAboveVersion)
                    {
                        if (status != PermissionStatus.Granted || storage != PermissionStatus.Granted)
                        {
                            IsShowPermissionWarning = true;
                            if (AppPreferences.IsHindi)
                            {
                                PermissionsStatus = "से इनकार किया";
                            }
                            else
                            {
                                PermissionsStatus = "Denied";
                            }
                        }

                        if (status == PermissionStatus.Granted && storage == PermissionStatus.Granted)
                        {
                            IsShowPermissionWarning = false;
                            if (AppPreferences.IsHindi)
                            {
                                PermissionsStatus = "स्वीकृत";
                            }
                            else
                            {
                                PermissionsStatus = "Granted";
                            }
                        }
                        else if (status != PermissionStatus.Unknown)
                        {
                            IsShowPermissionWarning = true;
                            if (AppPreferences.IsHindi)
                            {
                                PermissionsStatus = "से इनकार किया";
                            }
                            else
                            {
                                PermissionsStatus = "Denied";
                            }
                            UserDialogs.Instance.Toast(MessageStringConstants.PermissionMessage);
                            //await UserDialogs.Instance.AlertAsync(MessageStringConstants.CameraMessage, MessageStringConstants.PermissionMessage, "OK");
                        }
                    }
                    else
                    {
                        IsShowPermissionWarning = false;
                        if (AppPreferences.IsHindi)
                        {
                            PermissionsStatus = "से इनकार किया";
                        }
                        else
                        {
                            PermissionsStatus = "Denied";
                        }
                    }

                }
                else if (Device.RuntimePlatform == Device.iOS)
                {
                    if (status != PermissionStatus.Granted || storage != PermissionStatus.Granted)
                    {
                        IsShowPermissionWarning = true;
                        if (AppPreferences.IsHindi)
                        {
                            PermissionsStatus = "से इनकार किया";
                        }
                        else
                        {
                            PermissionsStatus = "Denied";
                        }
                    }

                    if (status == PermissionStatus.Granted && storage == PermissionStatus.Granted)
                    {
                        IsShowPermissionWarning = false;
                        if (AppPreferences.IsHindi)
                        {
                            PermissionsStatus = "स्वीकृत";
                        }
                        else
                        {
                            PermissionsStatus = "Granted";
                        }
                    }
                    else if (status != PermissionStatus.Unknown)
                    {
                        IsShowPermissionWarning = true;
                        if (AppPreferences.IsHindi)
                        {
                            PermissionsStatus = "से इनकार किया";
                        }
                        else
                        {
                            PermissionsStatus = "Denied";
                        }
                        UserDialogs.Instance.Toast(MessageStringConstants.PermissionMessage);
                        //await UserDialogs.Instance.AlertAsync(MessageStringConstants.CameraMessage, MessageStringConstants.PermissionMessage, "OK");
                    }
                }


            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "ExternalDeviceStatusViewModel.AskRunTimePermissionAsync");
            }
        }
        #endregion

        #region Click Event
        public async void CommonFunction(object obj)
        {
            #region RefreshButton Click Event
            if (obj.ToString().Equals("refresh"))
            {
                UserDialogs.Instance.ShowLoading();
                CheckDeviceStatus();
                UserDialogs.Instance.HideLoading();
            }
            #endregion

            #region OpenGooglePlayService
            else if (obj.Equals("tpgOpenGooglePlayService"))
            {
                DependencyService.Get<IMyDevice>().OpenGooglePlayService();
            }
            #endregion

            #region proceed Click Event
            else if (obj.ToString().Equals("proceed"))
            {

                if (isClicked)
                {
                    isClicked = false;
                    CommonFunction("refresh");
                    try
                    {
                        var _batteryLevel = Plugin.Battery.CrossBattery.Current.RemainingChargePercent;
                        var _chargingStatus = Plugin.Battery.CrossBattery.Current.Status.ToString();
                        if (_batteryLevel <= 30 && _chargingStatus != "Charging")
                        {
                            if (AppPreferences.IsHindi)
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.HindiBatteryLowMessage);
                            }
                            else
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.BatteryLowMessage);
                            }
                        }
                        if (IsShowDetectorWarning)
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.UpdateGooglePlayService);
                        }

                        if (!IsShowPermissionWarning && !IsShowMemoryWarning && !IsShowCameraWarning)//&& !IsShowDetectorWarning && !IsShowBatteryLevelWarning && !IsShowBluetoothWarning
                        {


                            var status = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Camera);
                            var storage = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Storage);
                            if (status != PermissionStatus.Granted || storage != PermissionStatus.Granted)
                            {
                                IsShowPermissionWarning = true;
                                if (AppPreferences.IsHindi)
                                {
                                    PermissionsStatus = "से इनकार किया";
                                }
                                else
                                {
                                    PermissionsStatus = "Denied";
                                }

                                var results = await CrossPermissions.Current.RequestPermissionsAsync(new[] { Permission.Camera, Permission.Storage });
                                status = results[Permission.Camera];
                                storage = results[Permission.Storage];

                            }

                            if (status == PermissionStatus.Granted && storage == PermissionStatus.Granted)
                            {
                                IsShowPermissionWarning = false;
                                if (AppPreferences.IsHindi)
                                {
                                    PermissionsStatus = "स्वीकृत";
                                }
                                else
                                {
                                    PermissionsStatus = "Granted";
                                }

                                if (MessageStringConstants.IsSameUser)
                                {
                                    if (_localDB.TableExists("EnglishQuestion"))
                                    {
                                        var count = _localDB.CountRecords();
                                        int noofques = int.Parse(AppPreferences.NoOfQuestions);
                                        if (count == noofques)
                                        {
                                            bool isNetworkAvailable;
                                            if (Device.RuntimePlatform == Device.Android)
                                            {
                                                isNetworkAvailable = DependencyService.Get<IMyDevice>().IsInternetAvailable();

                                                var type = DependencyService.Get<IMyDevice>().NetworkType();

                                                //if (type == "2G")
                                                //{
                                                //    UserDialogs.Instance.HideLoading();
                                                //    UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnectionSlow);
                                                //    return default(T1);
                                                //}
                                            }
                                            else
                                            {
                                                isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                                            }
                                            if (isNetworkAvailable)
                                            {
                                                await CallNoOfAttemptsAPI();
                                                Application.Current.MainPage = new NavigationPage(new AssessmentPage());
                                                return;
                                            }
                                            else
                                            {
                                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                                            }
                                        }
                                        else
                                        {
                                            await DownloadQuestions();
                                        }
                                    }
                                    else
                                    {
                                        await DownloadQuestions();
                                    }
                                }
                                else
                                {

                                    UserDialogs.Instance.HideLoading();
                                    await DownloadQuestions();
                                }
                            }
                            else if (status != PermissionStatus.Unknown)
                            {
                                UserDialogs.Instance.Toast(MessageStringConstants.PermissionMessage);
                            }

                            //if (!MessageStringConstants.IsSameUser)
                            //{

                            //    var status = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Camera);
                            //    var storage = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Storage);
                            //    if (status != PermissionStatus.Granted || storage != PermissionStatus.Granted)
                            //    {
                            //        IsShowPermissionWarning = true;
                            //        PermissionsStatus = "Denied";

                            //        var results = await CrossPermissions.Current.RequestPermissionsAsync(new[] { Permission.Camera, Permission.Storage });
                            //        status = results[Permission.Camera];
                            //        storage = results[Permission.Storage];

                            //    }

                            //    if (status == PermissionStatus.Granted && storage == PermissionStatus.Granted)
                            //    {
                            //        IsShowPermissionWarning = false;
                            //        PermissionsStatus = "Granted";
                            //        if (_localDB.TableExists("EnglishQuestion"))
                            //        {
                            //            var count = _localDB.CountRecords();
                            //            int noofques = int.Parse(AppPreferences.NoOfQuestions);
                            //            if (count == noofques)
                            //            {
                            //                await CallNoOfAttemptsAPI();
                            //                Application.Current.MainPage = new NavigationPage(new AssessmentPage());
                            //            }
                            //            else
                            //            {
                            //                await DownloadQuestions();
                            //            }
                            //        }
                            //        else
                            //        {
                            //            await DownloadQuestions();
                            //        }

                            //    }
                            //    else if (status != PermissionStatus.Unknown)
                            //    {
                            //        UserDialogs.Instance.Toast(MessageStringConstants.PermissionMessage);
                            //    }
                            //}
                            //else
                            //{
                            //    if (_localDB.TableExists("EnglishQuestion"))
                            //    {
                            //        var test = _localDB.GetAllData();
                            //        string noofques = AppPreferences.NoOfQuestions;
                            //        int NoOfQueCount = int.Parse(noofques);
                            //        if (test.Count() != 0)
                            //        {
                            //            if (test.Count() == NoOfQueCount && NoOfQueCount != 0)
                            //            {
                            //                UserDialogs.Instance.HideLoading();
                            //                await CallNoOfAttemptsAPI();
                            //                Application.Current.MainPage = new NavigationPage(new AssessmentPage());
                            //            }
                            //            else
                            //            {
                            //                UserDialogs.Instance.HideLoading();
                            //                await DownloadQuestions();
                            //            }
                            //        }
                            //        else
                            //        {
                            //            UserDialogs.Instance.HideLoading();
                            //            await DownloadQuestions();
                            //        }
                            //    }
                            //    else
                            //    {
                            //        UserDialogs.Instance.HideLoading();
                            //        await DownloadQuestions();
                            //    }
                            //}

                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            if (AppPreferences.IsHindi)
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.WarningHindi, null, MessageStringConstants.OKHindi);
                            }
                            else
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.Warning);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        UserDialogs.Instance.HideLoading();
                        System.Diagnostics.Debug.WriteLine(ex.Message);
                        SendErrorMessageToServer(ex, "ExternalDeviceStatusViewModel.CommonFunction");
                    }


                }
                await Task.Run(async () =>
                {
                    await Task.Delay(500);
                    isClicked = true;
                });

            }
            #endregion
        }
        #endregion


        #region CheckDeviceStatus
        private void CheckDeviceStatus()
        {
            try
            {
                //if (isClicked)
                //{
                //    isClicked = false;

                AskRunTimePermissionAsync();

                int batteryLevel = CrossBattery.Current.RemainingChargePercent;
                isValidBatteryLevel = true;
                IsShowBatteryLevelWarning = false;
                // //if (batteryLevel >= Models.Assessment.Constants.BatteryPercentage)
                //if (batteryLevel >= Int32.Parse(Interface.AppPreferences.BatteryLevel))
                //{
                //    isValidBatteryLevel = true;
                //    IsShowBatteryLevelWarning = false;
                //   // BatteryHintTextIsVisible = false;
                //    BatteryLevelColor = (Color)Application.Current.Resources["DarkGreenColor"];
                //    BatteryLevelAccept = (string)Application.Current.Resources["TickIcon"];
                //}
                //else
                //{
                //    IsShowBatteryLevelWarning = true;
                //    isValidBatteryLevel = false;
                //  //  BatteryHintTextIsVisible = true;
                //    BatteryLevelAccept = (string)Application.Current.Resources["WarningIcon"];
                //    BatteryLevelColor = (Color)Application.Current.Resources["DarkRedColor"];
                //}
                BatteryLevel = CrossBattery.Current.RemainingChargePercent.ToString() + " %";

                if (!string.IsNullOrEmpty(_chargingStatusContent))
                {
                    if (AppPreferences.IsHindi)
                    {
                        if (_chargingStatusContent == "Charging")
                        {
                            ChargerConnected = "चार्जिंग";
                        }
                        else
                        {
                            ChargerConnected = "चार्ज नहीं हो रहा है";
                        }
                    }
                    else
                    {
                        ChargerConnected = Plugin.Battery.CrossBattery.Current.Status.ToString();
                    }
                }
                else
                {
                    ChargerConnected = Plugin.Battery.CrossBattery.Current.Status.ToString();
                }

                if (DependencyService.Get<IExternalDeviceStatus>().isOTGConnected())
                {
                    if (AppPreferences.IsHindi)
                    {
                        USBConnected = "जुड़े";
                    }
                    else
                    {
                        USBConnected = "Connected";
                    }

                }
                else
                {
                    if (AppPreferences.IsHindi)
                    {
                        USBConnected = "कनेक्ट नहीं किया गया है";
                    }
                    else
                    {
                        USBConnected = "Not Connected";
                    }

                }



                var freeMemorySpace = DependencyService.Get<IExternalDeviceStatus>().GetMemorySize();

                if (freeMemorySpace != null)
                {
                    AvailableMemory = freeMemorySpace + " GB";

                    var freeMemorySpaceinMB = DependencyService.Get<IExternalDeviceStatus>().GetMemorySizeInMB();

                    if (freeMemorySpaceinMB >= Constant.MemorySize)
                    {
                        IsShowMemoryWarning = false;
                        isValidMemorySize = true;
                        MemoryHintTextIsVisible = false;
                        AvailableMemoryAccept = (string)Application.Current.Resources["TickIcon"];
                        AvailableMemoryColor = (Color)Application.Current.Resources["DarkGreenColor"];
                    }
                    else
                    {
                        IsShowMemoryWarning = true;
                        MemoryHintTextIsVisible = true;
                        isValidMemorySize = false;
                        AvailableMemoryAccept = (string)Application.Current.Resources["WarningIcon"];
                        AvailableMemoryColor = (Color)Application.Current.Resources["DarkRedColor"];
                    }

                }
                else
                {
                    AvailableMemory = "Didn't Get Memory Space";
                }


                if (DependencyService.Get<IExternalDeviceStatus>().IsFrontCameraAvailable())
                {
                    IsShowCameraWarning = false;
                    isValidFrontCamera = true;
                    if (AppPreferences.IsHindi)
                    {
                        FrontCameraStatus = "उपलब्ध";
                    }
                    else
                    {
                        FrontCameraStatus = "Available";
                    }
                    FrontCameraStatusAccept = (string)Application.Current.Resources["TickIcon"];
                    FrontCameraStatusColor = (Color)Application.Current.Resources["DarkGreenColor"];
                }
                else
                {
                    IsShowCameraWarning = true;
                    isValidFrontCamera = false;
                    if (AppPreferences.IsHindi)
                    {
                        FrontCameraStatus = "उपलब्ध नहीं है";
                    }
                    else
                    {
                        FrontCameraStatus = "Not Available";
                    }

                    FrontCameraStatusAccept = (string)Application.Current.Resources["WarningIcon"];
                    FrontCameraStatusColor = (Color)Application.Current.Resources["DarkRedColor"];
                }

                //if (DependencyService.Get<IExternalDeviceStatus>().isBluetoothStatus())
                //{
                //    IsShowBluetoothWarning = true;
                //    BluetoothStatus = "On";
                //}
                //else
                //{
                //    IsShowBluetoothWarning = false;
                //    BluetoothStatus = "Off";
                //}

                if (DependencyService.Get<IExternalDeviceStatus>().isHeadPhoneConnected())
                {
                    if (AppPreferences.IsHindi)
                    {
                        HeadPhoneStatus = "जुड़े";
                    }
                    else
                    {
                        HeadPhoneStatus = "Connected";
                    }

                }
                else
                {
                    if (AppPreferences.IsHindi)
                    {
                        HeadPhoneStatus = "जुड़े";
                    }
                    else
                    {
                        HeadPhoneStatus = "Not Connected";
                    }
                }

                //if (!IsShowBatteryLevelWarning && !IsShowMemoryWarning && !IsShowCameraWarning) //&& !IsShowDetectorWarning)// && !IsShowBluetoothWarning
                //{
                //    ProceedBtnBackColor = (Color)Application.Current.Resources["LightGreenColor"];
                //}
                //else
                //{
                //    ProceedBtnBackColor = (Color)Application.Current.Resources["GrayColor"];
                //}

                if (Device.RuntimePlatform == Device.Android)
                {
                    var IsDetectorUpdate = DependencyService.Get<IMyDevice>().IsDeviceSupportToDetectTheUserFace();
                    if (IsDetectorUpdate)
                    {
                        if (AppPreferences.IsHindi)
                        {
                            DetectorStatus = "हाँ";
                        }
                        else
                        {
                            DetectorStatus = "Yes";
                        }

                        IsShowDetectorWarning = false;
                    }
                    else
                    {
                        if (AppPreferences.IsHindi)
                        {
                            DetectorStatus = "ना";
                        }
                        else
                        {
                            DetectorStatus = "Yes";
                        }
                        IsShowDetectorWarning = true;
                    }
                }
                else
                {
                    IsDetectorGrid = false;
                    IsShowDetectorWarning = false;
                }

                // }

                //await Task.Run(async () =>
                //{
                //    await Task.Delay(500);
                //    isClicked = true;
                //});
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "ExternalDeviceStatusViewModel.CheckDeviceStatus");
            }
        }
        #endregion

        # region CallNoOfAttemptsAPI
        private async Task CallNoOfAttemptsAPI()
        {
            try
            {
                var request = new NoOfAttemptsRequestModel();
                request.examid = AppPreferences.ExamID;
                var result = await _commonservice.PostAsync<NoOfAttemptsResponse, NoOfAttemptsRequestModel>(APIData.API_BASE_URL + APIMethods.IncreaseNoOfAttempt, request);
                if (result != null)
                {
                    if (result.code == "200")
                    {

                    }
                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "ExternalDeviceStatusViewModel.CallNoOfAttemptsAPI");
            }
        }
        #endregion

        #region Download Questions
        public async Task DownloadQuestions()
        {

            try
            {
                UserDialogs.Instance.ShowLoading();
                bool isnetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isnetworkAvailable)
                {
                    _QuestionsDownloadRequest = new QuestionsRequestData();
                    _localDB = new LocalDataBase.LocalDB();
                    //_localDB.DropAllTables(); 
                    // _localDB.CreateTables();
                    // _localDB.TestIftablesCreated();
                    _questionData = new EnglishQuestion();
                    _QuestionsDownloadRequest.AssignedID = AppPreferences.AssignedID;
                    _QuestionsDownloadRequest.DeviceID = DependencyService.Get<IMyDevice>().GetDeviceID() ?? string.Empty;
                    _QuestionsDownloadRequest.LanguageID = AppPreferences.SelectedlanguageID;
                    var result = await _commonservice.PostAsync<QuestionsResponseData, QuestionsRequestData>(APIData.API_BASE_URL + APIMethods.Getloadbulkquestions, _QuestionsDownloadRequest);
                    if (result != null)
                    {
                        UserDialogs.Instance.HideLoading();
                        if (result.StatusCode == "200")
                        {
                            AppPreferences.IsStartWithLogin = true;
                            AppPreferences.ServerDateTime = result.ServerTime.Ticks.ToString();
                            AppPreferences.ServerDate = result.ServerTime.Date.ToString("yyyy-MM-dd");
                            AppPreferences.ServerUpdatedDateTime = result.ServerTime.Date.ToString();
                            AppPreferences.UpdatedLocalTime = result.ElaspedTime.ToString();
                            AppPreferences.ExamTime = result.ElaspedTime;
                            AppPreferences.ExamDuration = result.Duration;
                            AppPreferences.ExamCenterName = result.ExamCentreName;
                            AppPreferences.ExamName = result.ExamName;
                            TimeSpan ExamDuration = TimeSpan.Parse(result.Duration);
                            AppPreferences.ExamDurationHour = ExamDuration.Hours.ToString();
                            AppPreferences.ExamDurationMinute = ExamDuration.Minutes.ToString();

                            SqliteOperations sqliteOperations = new SqliteOperations();
                            await sqliteOperations.InsertFullExamDetailsInToLocalDatabaseAsync(result);

                            var CountofEnglish = _localDB.GetAllData();
                            var CountofHindi = _localDB.GetAllHindiData();
                            string noofques = AppPreferences.NoOfQuestions;
                            int NoOfQueCount = int.Parse(noofques);
                            if (CountofEnglish.Count() != 0 || CountofHindi.Count() != 0)
                            {

                                if (NoOfQueCount != 0 && CountofEnglish.Count() < NoOfQueCount)
                                {
                                    _localDB.DeleteAllTables();
                                    if (AppPreferences.IsHindi)
                                    {
                                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.HindiinsufficientQuestion, null, MessageStringConstants.OKHindi);
                                    }
                                    else
                                    {
                                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.insufficientQuestion);
                                    }
                                    var page = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                                    App.Current.MainPage = page;
                                    return;
                                }
                                else
                                {
                                    if (NoOfQueCount != 0 && (CountofEnglish.Count() == NoOfQueCount || CountofHindi.Count() == NoOfQueCount))
                                    {
                                        UserDialogs.Instance.HideLoading();
                                        Application.Current.MainPage = new NavigationPage(new AssessmentPage());
                                        return;
                                    }
                                    else if (NoOfQueCount != 0 && (CountofEnglish.Count() > NoOfQueCount || CountofHindi.Count() > NoOfQueCount))
                                    {
                                        _localDB.DeleteAllTables();
                                        await DownloadQuestions();
                                    }
                                    else
                                    {
                                        await DownloadQuestions();
                                    }
                                }
                            }
                            else
                            {
                                await DownloadQuestions();
                            }

                            UserDialogs.Instance.HideLoading();

                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            if (AppPreferences.IsHindi)
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.QuestionsNotFoundHinid, null, MessageStringConstants.OKHindi);
                            }
                            else
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.QuestionsNotFound);
                            }
                        }

                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "ExternalDeviceStatusViewModel.DownloadQuestions");
            }
        }

        #endregion

        #region Full Properties


        private Color frontCameraStatusColor;
        public Color FrontCameraStatusColor
        {
            get { return frontCameraStatusColor; }
            set { frontCameraStatusColor = value; OnPropertyChanged(); }
        }

        private bool memoryHintTextIsVisible;
        public bool MemoryHintTextIsVisible
        {
            get { return memoryHintTextIsVisible; }
            set { memoryHintTextIsVisible = value; OnPropertyChanged(); }
        }

        //private bool batteryHintTextIsVisible;
        //public bool BatteryHintTextIsVisible
        //{
        //    get { return batteryHintTextIsVisible; }
        //    set { batteryHintTextIsVisible = value; OnPropertyChanged(); }
        //}

        private String frontCameraStatusAccept;
        public String FrontCameraStatusAccept
        {
            get { return frontCameraStatusAccept; }
            set { frontCameraStatusAccept = value; OnPropertyChanged(); }
        }

        private String frontCameraStatus;
        public String FrontCameraStatus
        {
            get { return frontCameraStatus; }
            set { frontCameraStatus = value; OnPropertyChanged(); }
        }



        private String chargerConnected;
        public String ChargerConnected
        {
            get { return chargerConnected; }
            set { chargerConnected = value; OnPropertyChanged(); }
        }


        private String batteryLevel;

        public String BatteryLevel
        {
            get { return batteryLevel; }
            set { batteryLevel = value; OnPropertyChanged(); }
        }

        private String batteryLevelMessage;

        public String BatteryLevelMessage
        {
            get { return batteryLevelMessage; }
            set { batteryLevelMessage = value; OnPropertyChanged(); }
        }


        private Color batteryLevelColor;

        public Color BatteryLevelColor
        {
            get { return batteryLevelColor; }
            set { batteryLevelColor = value; OnPropertyChanged(); }
        }


        private String batteryLevelAccept;

        public String BatteryLevelAccept
        {
            get { return batteryLevelAccept; }
            set { batteryLevelAccept = value; OnPropertyChanged(); }
        }

        private Color proceedBtnBackColor;

        public Color ProceedBtnBackColor
        {
            get { return proceedBtnBackColor; }
            set { proceedBtnBackColor = value; OnPropertyChanged(); }
        }



        private String bluetoothStatus;

        public String BluetoothStatus
        {
            get { return bluetoothStatus; }
            set { bluetoothStatus = value; OnPropertyChanged(); }
        }


        private String usbConnected;

        public String USBConnected
        {
            get { return usbConnected; }
            set { usbConnected = value; OnPropertyChanged(); }
        }


        private String headPhoneStatus;

        public String HeadPhoneStatus
        {
            get { return headPhoneStatus; }
            set { headPhoneStatus = value; OnPropertyChanged(); }
        }

        private String permissionsStatus;

        public String PermissionsStatus
        {
            get { return permissionsStatus; }
            set { permissionsStatus = value; OnPropertyChanged(); }
        }





        private String availableMemory;

        public String AvailableMemory
        {
            get { return availableMemory; }
            set { availableMemory = value; OnPropertyChanged(); }
        }

        private String availableMemoryAccept;

        public String AvailableMemoryAccept
        {
            get { return availableMemoryAccept; }
            set { availableMemoryAccept = value; OnPropertyChanged(); }
        }


        private Color availableMemoryColor;

        public Color AvailableMemoryColor
        {
            get { return availableMemoryColor; }
            set { availableMemoryColor = value; OnPropertyChanged(); }
        }




        private Boolean isShowPermissionWarning;
        public Boolean IsShowPermissionWarning
        {
            get { return isShowPermissionWarning; }
            set { isShowPermissionWarning = value; OnPropertyChanged(); }
        }
        private bool _IsHindi;
        public bool IsHindi
        {
            get { return _IsHindi; }
            set { _IsHindi = value; OnPropertyChanged(); }
        }

        private bool _IsEnglish;
        public bool IsEnglish
        {
            get { return _IsEnglish; }
            set { _IsEnglish = value; OnPropertyChanged(); }
        }

        private Boolean isShowBluetoothWarning;
        public Boolean IsShowBluetoothWarning
        {
            get { return isShowBluetoothWarning; }
            set { isShowBluetoothWarning = value; OnPropertyChanged(); }
        }

        private Boolean isShowMemoryWarning;
        public Boolean IsShowMemoryWarning
        {
            get { return isShowMemoryWarning; }
            set { isShowMemoryWarning = value; OnPropertyChanged(); }
        }

        private Boolean isShowCameraWarning;
        public Boolean IsShowCameraWarning
        {
            get { return isShowCameraWarning; }
            set { isShowCameraWarning = value; OnPropertyChanged(); }
        }

        private Boolean isShowBatteryLevelWarning;
        public Boolean IsShowBatteryLevelWarning
        {
            get { return isShowBatteryLevelWarning; }
            set { isShowBatteryLevelWarning = value; OnPropertyChanged(); }
        }




        private Boolean isShowIOSOnly;

        public Boolean IsShowIOSOnly
        {
            get { return isShowIOSOnly; }
            set { isShowIOSOnly = value; OnPropertyChanged(); }
        }
        private bool _IsDetectorGrid;
        public bool IsDetectorGrid
        {
            get { return _IsDetectorGrid; }
            set { _IsDetectorGrid = value; OnPropertyChanged(); }
        }

        private string _DetectorStatus;

        public string DetectorStatus
        {
            get { return _DetectorStatus; }
            set { _DetectorStatus = value; OnPropertyChanged(); }
        }
        private bool _IsShowDetectorWarning;

        public bool IsShowDetectorWarning
        {
            get { return _IsShowDetectorWarning; }
            set { _IsShowDetectorWarning = value; OnPropertyChanged(); }
        }



        #endregion
    }
}
