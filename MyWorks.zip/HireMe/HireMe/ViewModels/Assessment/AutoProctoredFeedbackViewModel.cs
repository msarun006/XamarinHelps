﻿using System;
using System.Threading.Tasks;
using System.Windows.Input;
using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using MvvmHelpers;
using Xamarin.Forms;
using Plugin.Connectivity;
using System.Diagnostics;
using HireMe.LocalDataBase;
using HireMe.Models.Assessment.SQLTables;
using HireMe.Interface;
using HireMe.Helpers;
using HireMe.Models.Assessment;

namespace HireMe.ViewModels.Assessment
{
    public class AutoProctoredFeedbackViewModel : BaseViewModel
    {
        #region Variables initialization 
        public ICommand OnCommandQuestionOne { get; set; }
        public ICommand OnCommandQuestionTwo { get; set; }
        public ICommand OnCommandQuestionThree { get; set; }
        public ICommand OnCommand { get; set; }
        public LocalDB _localDB;
        private HttpCommonService _commonservice { get; set; }

        public FeedBackModelRequest _feedbackData;
        string qustion1ans;
        string qustion2ans;
        string qustion3ans;
        public bool isClicked = true;
        #endregion

        #region Constructor
        public AutoProctoredFeedbackViewModel()
        {
            Candidatename = AppPreferences.userName;

            _localDB = new LocalDB();
            _feedbackData = new FeedBackModelRequest();
            _commonservice = new HttpCommonService();
            qustion1ans = string.Empty;
            qustion2ans = string.Empty;
            qustion3ans = string.Empty;

            Question1 = "How was your experience in giving the HireMee app-based remote assessment?";
            Question2 = "How do you rate the HireMee CSR initiative free assessment app?";
            Question3 = "How was your overall experience in terms of navigating to the candidate console, ease of using the console, etc.?";
            //OnCommandQuestionOne = new RelayCommand<string>(DoOperation);
            //OnCommandQuestionTwo = new RelayCommand<string>(DoOperation);
            //OnCommandQuestionThree = new RelayCommand<string>(DoOperation);
            OnCommand = new RelayCommand<string>(DoOperation);

            OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
            OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
            OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
            OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];

            OptionARadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
            OptionBRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
            OptionCRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
            OptionDRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];

            OptionARadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
            OptionBRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
            OptionCRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
            OptionDRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];

            QuestionOneFirstStar = (string)Application.Current.Resources["EmptyStarIcon"];
            QuestionOneSecondStar = (string)Application.Current.Resources["EmptyStarIcon"];
            QuestionOneThirdStar = (string)Application.Current.Resources["EmptyStarIcon"];
            QuestionOneFourthStar = (string)Application.Current.Resources["EmptyStarIcon"];
            QuestionOneFifthStar = (string)Application.Current.Resources["EmptyStarIcon"];

            if (Device.RuntimePlatform == Device.iOS)
            {
                IsShowIOSOnly = true;
            }
            else
            {
                IsShowIOSOnly = false;
            }

            qustion4ans = string.Empty;
        }

        #endregion

        #region Command Operation
        private async void DoOperation(string obj)
        {
            switch (obj)
            {
                #region Submit Button Command
                case "Submit":
                    if (isClicked)
                    {
                        isClicked = false;
                        //if (String.IsNullOrEmpty(qustion1ans) || String.IsNullOrEmpty(qustion2ans) || String.IsNullOrEmpty(qustion3ans))
                        //{

                        //    if (AppPreferences.IsHindi)
                        //    {
                        //        UserDialogs.Instance.Alert(MessageStringConstants.HindiFeed1message, null, MessageStringConstants.OKHindi);
                        //    }
                        //    else //if (AppPreferences.IsEnglish)
                        //    {
                        //        UserDialogs.Instance.Alert(MessageStringConstants.FillAllFeedbacks);
                        //    }
                        //}
                        if (String.IsNullOrEmpty(qustion1ans))
                        {
                            if (AppPreferences.IsHindi)
                            {
                                UserDialogs.Instance.Alert(MessageStringConstants.HindiFeed1message, null, MessageStringConstants.OKHindi);
                            }
                            else //if (AppPreferences.IsEnglish)
                            {
                                UserDialogs.Instance.Alert(MessageStringConstants.Feed1message);
                            }

                        }
                        else if (String.IsNullOrEmpty(qustion2ans))
                        {
                            if (AppPreferences.IsHindi)
                            {
                                UserDialogs.Instance.Alert(MessageStringConstants.HindiFeed2message, null, MessageStringConstants.OKHindi);
                            }
                            else //if (AppPreferences.IsEnglish)
                            {
                                UserDialogs.Instance.Alert(MessageStringConstants.Feed2message);
                            }


                        }
                        else if (String.IsNullOrEmpty(qustion3ans))
                        {
                            if (AppPreferences.IsHindi)
                            {
                                UserDialogs.Instance.Alert(MessageStringConstants.HindiFeed3message, null, MessageStringConstants.OKHindi);
                            }
                            else //if (AppPreferences.IsEnglish)
                            {
                                UserDialogs.Instance.Alert(MessageStringConstants.Feed3message);
                            }
                        }
                        else if (String.IsNullOrEmpty(qustion4ans))
                        {
                            if (AppPreferences.IsHindi)
                            {
                                UserDialogs.Instance.Alert(MessageStringConstants.HindiFeed4message, null, MessageStringConstants.OKHindi);
                            }
                            else //if(AppPreferences.IsEnglish)
                            {
                                UserDialogs.Instance.Alert(MessageStringConstants.Feed4message);
                            }

                        }
                        else
                        {

                            try
                            {
                                FeedbackInsertInToLocalDB();

                                SqliteOperations sqliteOperations = new SqliteOperations();
                                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                                if (isNetworkAvailable)
                                {
                                    //   SubmitFeedbackToAPI();

                                    UserDialogs.Instance.ShowLoading();
                                    await Task.Delay(100);
                                    await sqliteOperations.BulkInsert("Auto");
                                    UserDialogs.Instance.HideLoading();

                                }
                                else
                                {
                                    bool checkExistingData = sqliteOperations.CheckIfAnySyncupDataIsAvailable();
                                    if (checkExistingData)
                                    {
                                        DependencyService.Get<ISyncDataWhileInternetAvailable>().IRegisterIOSService();
                                        DependencyService.Get<ISyncDataWhileInternetAvailable>().IStartAlarmService();
                                    }
                                }

                                if (AppPreferences.IsHindi)
                                {
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.FeedbackSuccessHindi, null, MessageStringConstants.OKHindi);
                                }
                                else
                                {
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.FeedbackSuccess);
                                }
                                CallDashboardPage();

                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex.Message);
                                SendErrorMessageToServer(ex, "AutoProctoredFeedbackViewModel.DoOperation.Submit");
                            }
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });

                    break;
                #endregion

                #region Option Tap Command
                case "tpgOptionA":
                    OptionARadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    qustion1ans = "Excellent";
                    break;

                case "tpgOptionB":
                    OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    qustion1ans = "Good";
                    break;

                case "tpgOptionC":
                    OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    qustion1ans = "Average";
                    break;

                case "tpgOptionD":
                    OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    qustion1ans = "Needs improvement";
                    break;
                #endregion

                #region Option Tap Command
                case "tpgOptionAtwo":
                    OptionARadiobuttontwo = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionBRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    qustion2ans = "Excellent";
                    break;

                case "tpgOptionBtwo":
                    OptionARadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobuttontwo = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionCRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    qustion2ans = "Good";
                    break;

                case "tpgOptionCtwo":
                    OptionARadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobuttontwo = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionDRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    qustion2ans = "Average";
                    break;

                case "tpgOptionDtwo":
                    OptionARadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobuttontwo = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    qustion2ans = "Needs improvement";
                    break;
                #endregion

                #region Option Tap Command
                case "tpgOptionAthree":
                    OptionARadiobuttonthree = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionBRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    qustion3ans = "Excellent";
                    break;

                case "tpgOptionBthree":
                    OptionARadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobuttonthree = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionCRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    qustion3ans = "Good";
                    break;

                case "tpgOptionCthree":
                    OptionARadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobuttonthree = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    OptionDRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    qustion3ans = "Average";
                    break;

                case "tpgOptionDthree":
                    OptionARadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionBRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionCRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionDRadiobuttonthree = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    qustion3ans = "Needs improvement";
                    break;
                #endregion

                #region Question One Star Rating
                case "QuestionOneFirstStarClicked":
                    QuestionOneFirstStar = (string)Application.Current.Resources["FilledStarIcon"];
                    QuestionOneSecondStar = (string)Application.Current.Resources["EmptyStarIcon"];
                    QuestionOneThirdStar = (string)Application.Current.Resources["EmptyStarIcon"];
                    QuestionOneFourthStar = (string)Application.Current.Resources["EmptyStarIcon"];
                    QuestionOneFifthStar = (string)Application.Current.Resources["EmptyStarIcon"];
                    break;

                case "QuestionOneSecondStarClicked":
                    QuestionOneFirstStar = (string)Application.Current.Resources["FilledStarIcon"];
                    QuestionOneSecondStar = (string)Application.Current.Resources["FilledStarIcon"];
                    QuestionOneThirdStar = (string)Application.Current.Resources["EmptyStarIcon"];
                    QuestionOneFourthStar = (string)Application.Current.Resources["EmptyStarIcon"];
                    QuestionOneFifthStar = (string)Application.Current.Resources["EmptyStarIcon"];
                    break;

                case "QuestionOneThirdStarClicked":
                    QuestionOneFirstStar = (string)Application.Current.Resources["FilledStarIcon"];
                    QuestionOneSecondStar = (string)Application.Current.Resources["FilledStarIcon"];
                    QuestionOneThirdStar = (string)Application.Current.Resources["FilledStarIcon"];
                    QuestionOneFourthStar = (string)Application.Current.Resources["EmptyStarIcon"];
                    QuestionOneFifthStar = (string)Application.Current.Resources["EmptyStarIcon"];
                    break;

                case "QuestionOneFourthStarClicked":
                    QuestionOneFirstStar = (string)Application.Current.Resources["FilledStarIcon"];
                    QuestionOneSecondStar = (string)Application.Current.Resources["FilledStarIcon"];
                    QuestionOneThirdStar = (string)Application.Current.Resources["FilledStarIcon"];
                    QuestionOneFourthStar = (string)Application.Current.Resources["FilledStarIcon"];
                    QuestionOneFifthStar = (string)Application.Current.Resources["EmptyStarIcon"];
                    break;

                case "QuestionOneFifthStarClicked":
                    QuestionOneFirstStar = (string)Application.Current.Resources["FilledStarIcon"];
                    QuestionOneSecondStar = (string)Application.Current.Resources["FilledStarIcon"];
                    QuestionOneThirdStar = (string)Application.Current.Resources["FilledStarIcon"];
                    QuestionOneFourthStar = (string)Application.Current.Resources["FilledStarIcon"];
                    QuestionOneFifthStar = (string)Application.Current.Resources["FilledStarIcon"];
                    break;
                    #endregion

            }
        }
        #endregion


        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        #region CallDashboardPage
        private void CallDashboardPage()
        {
            SqliteOperations SycnDataClass = new SqliteOperations();
            //Need to check is all record sync with server
            if (!SycnDataClass.CheckIfAnySyncupDataIsAvailable())
            {
                SycnDataClass.DeleteAllLocalRecords();
            }
            Constant.IsSideMenuDashboard = true;
            Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
            return;
        }
        #endregion

        //#region SubmitFeedbackToAPI
        //public async void SubmitFeedbackToAPI()
        //{
        //    try
        //    {
        //        bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
        //        if (isNetworkAvailable)
        //        {

        //            UserDialogs.Instance.ShowLoading();

        //            var SycnDataClass = new SqliteOperations();
        //            await SycnDataClass.BulkInsert("Auto");
        //            //await SycnDataClass.BulkDataAndUploadToServer();

        //            UserDialogs.Instance.HideLoading();
        //            if (AppPreferences.IsHindi)
        //            {
        //                await UserDialogs.Instance.AlertAsync(MessageStringConstants.FeedbackSuccessHindi, null, MessageStringConstants.OKHindi);
        //            }
        //            else
        //            {
        //                await UserDialogs.Instance.AlertAsync(MessageStringConstants.FeedbackSuccess);
        //            }

        //            MessagingCenter.Send(this, "StartSyncSerivce", "Syncronization started from Internet availability ");

        //            CallDashboardPage();


        //            //Application.Current.MainPage = new NavigationPage(new ExamCompleted());



        //            //var request = new FeedBackModelRequest();
        //            //request.HireMeeID = Application.Current.Properties[AppPreferenceKey.HireMeeID] as string;
        //            //request.AssignedID = Application.Current.Properties[AppPreferenceKey.AssignedID] as string;
        //            //request.AutoID = Application.Current.Properties[AppPreferenceKey.AutoID] as string;
        //            //request.ExamCenter = Application.Current.Properties[AppPreferenceKey.ExamCenterName] as string;
        //            //request.ExamName = Application.Current.Properties[AppPreferenceKey.ExamName] as string;
        //            //request.Feedback1 = qustion1ans;
        //            //request.Feedback2 = qustion2ans;
        //            //request.Feedback3 = qustion3ans;

        //            //var result = await _commonservice.PostAsync<FeedBackModelResponse, FeedBackModelRequest>(APIData.BASE_URL + APIMethods.InsertFeedBack, request);
        //            //UserDialogs.Instance.HideLoading();
        //            //if (result != null)
        //            //{

        //            //    if (result.StatusCode == "200")
        //            //    {
        //            //        UserDialogs.Instance.HideLoading();
        //            //        await UserDialogs.Instance.AlertAsync("Feedback Added Successfully...! Thank You");
        //            //        // UserDialogs.Instance.Alert(result.StatusMessage);
        //            //        Application.Current.MainPage = new NavigationPage(new ExamCompleted());
        //            //    }
        //            //    else
        //            //    {
        //            //        UserDialogs.Instance.HideLoading();
        //            //       await UserDialogs.Instance.AlertAsync(result.StatusMessage);
        //            //    }
        //            //}
        //        }
        //        else
        //        {
        //            UserDialogs.Instance.HideLoading();
        //            await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        UserDialogs.Instance.HideLoading();
        //        Debug.WriteLine(ex.Message);
        //        SendErrorMessageToServer(ex, "AutoProctoredFeedbackViewModel.SubmitFeedbackToAPI");
        //    }
        //}
        //#endregion

        #region AddFeebackOffline
        public void FeedbackInsertInToLocalDB()
        {
            if (!string.IsNullOrEmpty(AppPreferences.AssignedID))
            {
                _feedbackData.AssignedID = AppPreferences.AssignedID;
                _feedbackData.HireMeeID = AppPreferences.HireMeeID;
                _feedbackData.AssignedID = AppPreferences.AssignedID;
                _feedbackData.AutoID = AppPreferences.AutoID;
                _feedbackData.ExamCenter = AppPreferences.ExamCenterName;
                _feedbackData.ExamName = AppPreferences.ExamName;
                _feedbackData.Feedback1 = qustion1ans;
                _feedbackData.Feedback2 = qustion2ans;
                _feedbackData.Feedback3 = qustion3ans;
                _feedbackData.Comments = qustion4ans;
                _feedbackData.IsSynchedUp = false;
                _localDB.UpdateFeedbackModel(_feedbackData);
            }
            else
            {
                UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
            }
        }
        #endregion

        #region Pull Properties


        private Boolean isShowIOSOnly;

        public Boolean IsShowIOSOnly
        {
            get { return isShowIOSOnly; }
            set { isShowIOSOnly = value; OnPropertyChanged(); }

        }


        private string _Candidatename;

        public string Candidatename
        {
            get { return _Candidatename; }
            set
            {
                _Candidatename = value; OnPropertyChanged();
            }
        }

        private string _optionARadiobutton;
        public string OptionARadiobutton
        {
            get { return _optionARadiobutton; }
            set { _optionARadiobutton = value; OnPropertyChanged(); }
        }
        private string _optionBRadiobutton;
        public string OptionBRadiobutton
        {
            get { return _optionBRadiobutton; }
            set { _optionBRadiobutton = value; OnPropertyChanged(); }
        }
        private string _optionCRadiobutton;
        public string OptionCRadiobutton
        {
            get { return _optionCRadiobutton; }
            set { _optionCRadiobutton = value; OnPropertyChanged(); }
        }
        private string _optionDRadiobutton;
        public string OptionDRadiobutton
        {
            get { return _optionDRadiobutton; }
            set { _optionDRadiobutton = value; OnPropertyChanged(); }
        }



        private string _optionARadiobuttontwo;
        public string OptionARadiobuttontwo
        {
            get { return _optionARadiobuttontwo; }
            set { _optionARadiobuttontwo = value; OnPropertyChanged(); }
        }
        private string _optionBRadiobuttontwo;
        public string OptionBRadiobuttontwo
        {
            get { return _optionBRadiobuttontwo; }
            set { _optionBRadiobuttontwo = value; OnPropertyChanged(); }
        }
        private string _optionCRadiobuttontwo;
        public string OptionCRadiobuttontwo
        {
            get { return _optionCRadiobuttontwo; }
            set { _optionCRadiobuttontwo = value; OnPropertyChanged(); }
        }
        private string _optionDRadiobuttontwo;
        public string OptionDRadiobuttontwo
        {
            get { return _optionDRadiobuttontwo; }
            set { _optionDRadiobuttontwo = value; OnPropertyChanged(); }
        }


        private string _optionARadiobuttonthree;
        public string OptionARadiobuttonthree
        {
            get { return _optionARadiobuttonthree; }
            set { _optionARadiobuttonthree = value; OnPropertyChanged(); }
        }
        private string _optionBRadiobuttonthree;
        public string OptionBRadiobuttonthree
        {
            get { return _optionBRadiobuttonthree; }
            set { _optionBRadiobuttonthree = value; OnPropertyChanged(); }
        }
        private string _optionCRadiobuttonthree;
        public string OptionCRadiobuttonthree
        {
            get { return _optionCRadiobuttonthree; }
            set { _optionCRadiobuttonthree = value; OnPropertyChanged(); }
        }
        private string _optionDRadiobuttonthree;
        public string OptionDRadiobuttonthree
        {
            get { return _optionDRadiobuttonthree; }
            set { _optionDRadiobuttonthree = value; OnPropertyChanged(); }
        }

        private string _Question1;
        public string Question1
        {
            get { return _Question1; }
            set { _Question1 = value; OnPropertyChanged(); }
        }

        private string _Question2;
        public string Question2
        {
            get { return _Question2; }
            set { _Question2 = value; OnPropertyChanged(); }
        }

        private string _Question3;
        public string Question3
        {
            get { return _Question3; }
            set { _Question3 = value; OnPropertyChanged(); }
        }
        private string _QusNo;
        public string QusNo
        {
            get { return _QusNo; }
            set { _QusNo = value; OnPropertyChanged(); }

        }


        private string _qustion4ans;
        public string qustion4ans
        {
            get { return _qustion4ans; }
            set { _qustion4ans = value; OnPropertyChanged(); }

        }



        private string _QuestionOneFirstStar;

        public string QuestionOneFirstStar
        {
            get { return _QuestionOneFirstStar; }
            set { _QuestionOneFirstStar = value; OnPropertyChanged(); }
        }

        private string _QuestionOneSecondStar;

        public string QuestionOneSecondStar
        {
            get { return _QuestionOneSecondStar; }
            set { _QuestionOneSecondStar = value; OnPropertyChanged(); }
        }
        private string _QuestionOneThirdStar;

        public string QuestionOneThirdStar
        {
            get { return _QuestionOneThirdStar; }
            set { _QuestionOneThirdStar = value; OnPropertyChanged(); }
        }
        private string _QuestionOneFourthStar;

        public string QuestionOneFourthStar
        {
            get { return _QuestionOneFourthStar; }
            set { _QuestionOneFourthStar = value; OnPropertyChanged(); }
        }
        private string _QuestionOneFifthStar;

        public string QuestionOneFifthStar
        {
            get { return _QuestionOneFifthStar; }
            set { _QuestionOneFifthStar = value; OnPropertyChanged(); }
        }

        #endregion
    }
}
