﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using Acr.UserDialogs;
using HireMe.DataLayer.Models;
using MvvmHelpers;
using Xamarin.Forms;
using System.Threading.Tasks;
using HireMe.Models;
using HireMe.Helpers;

namespace HireMe.ViewModels
{
    public class MultipleSelectionViewModel : BaseViewModel
    {
        INavigation Navigation;
        string SelectedListName;
        private HttpCommonService _commonservice { get; set; }
        private string SearchName = "";

        ObservableCollection<CommonBO> _commonListdata;
        List<CommonBO> CommonListData = new List<CommonBO>();
        public bool isClicked = true;


        private List<CommonBO> SelectedItems;


        public MultipleSelectionViewModel(INavigation navigation, string ListName, List<CommonBO> ListData)
        {
            Navigation = navigation;
            SelectedListName = ListName;
            SelectedItems = ListData;
            btnSendIsDestructive = false;
            IsVisibleRecordNotFound = false;
            IsVisibleListView = true;
            _commonservice = new HttpCommonService();
            DynamicDataFields();
            DoneClicked = new Command(onDoneClicked);

        }



        async void BindSpecializationData()
        {
            Debug.WriteLine("@ DynamicListPage.CourseType");
            int currentYear = DateTime.Now.Year;
            CommonListData = new List<CommonBO>();
            if (_commonListdata == null)
            {
                try
                {
                    UserDialogs.Instance.ShowLoading();
                    SpecializationRequestData SpecializationRequestData = new SpecializationRequestData()
                    {
                        CourseID = AppPreferences.SelectedCourseID
                    };
                    var responseobj = await _commonservice.PostAsync<SpecializationResponseData, SpecializationRequestData>(APIData.API_BASE_URL + APIMethods.SearchCandidateBySpecialization, SpecializationRequestData);
                    if (responseobj != null)
                    {

                        if (responseobj.code == "200" && responseobj.Response != null)
                        {
                            if (responseobj.Response.Response != null)
                            {
                                foreach (var item in responseobj.Response.Response)
                                {
                                    CommonListData.Add(new CommonBO { ID = item.ID.ToString(), Title = item.Title });
                                }
                                isEnabledSearchBar = true;
                                _commonListdata = new ObservableCollection<CommonBO>(CommonListData);
                                UserDialogs.Instance.HideLoading();
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                isEnabledSearchBar = false;
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.NoRecordsFound);
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            isEnabledSearchBar = false;
                            await UserDialogs.Instance.AlertAsync(responseobj.message);
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        isEnabledSearchBar = false;
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                    UserDialogs.Instance.HideLoading();
                    SendErrorMessageToServer(ex, "MultipleSelectionViewModel.BindSpecializationData");
                }
            }
            if (SelectedItems != null && SelectedItems.Count > 0)
            {

                if (_commonListdata.Count > 0 && SelectedItems.Count > 0)
                {
                    foreach (var item in _commonListdata)
                    {
                        item.IsSelected = false;
                        foreach (var selectionitem in SelectedItems)
                        {
                            if (item.ID == selectionitem.ID)
                            {
                                item.IsSelected = selectionitem.IsSelected;
                            }
                        }
                    }
                }
            }

            CommonListItemSource = CommonListData;
        }




        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion





        async void BindCourseData()
        {
            Debug.WriteLine("@ DynamicListPage.CourseType");
            int currentYear = DateTime.Now.Year;
            CommonListData = new List<CommonBO>();
            if (_commonListdata == null)
            {
                try
                {
                    UserDialogs.Instance.ShowLoading();
                    CourseRequestData CourseRequestData = new CourseRequestData()
                    {

                        CourseTypeID = AppPreferences.SelectedCourseTypeID
                    };
                    var responseobj = await _commonservice.PostAsync<CourseResponseData, CourseRequestData>(APIData.API_BASE_URL + APIMethods.SearchCandidateByCourse, CourseRequestData);
                    if (responseobj != null)
                    {

                        if (responseobj.code == "200" && responseobj.Response != null)
                        {

                            if (responseobj.Response.Response != null)
                            {
                                foreach (var item in responseobj.Response.Response)
                                {
                                    CommonListData.Add(new CommonBO { ID = item.ID.ToString(), Title = item.Title });
                                }
                                isEnabledSearchBar = true;
                                _commonListdata = new ObservableCollection<CommonBO>(CommonListData);
                                UserDialogs.Instance.HideLoading();
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                isEnabledSearchBar = false;
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.NoRecordsFound);
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            isEnabledSearchBar = false;
                            await UserDialogs.Instance.AlertAsync(responseobj.message);
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        isEnabledSearchBar = false;
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                    UserDialogs.Instance.HideLoading();
                    SendErrorMessageToServer(ex, "MultipleSelectionViewModel.BindCourseData");
                }


            }
            if (SelectedItems != null && SelectedItems.Count > 0)
            {

                if (_commonListdata.Count > 0 && SelectedItems.Count > 0)
                {
                    foreach (var item in _commonListdata)
                    {
                        item.IsSelected = false;
                        foreach (var selectionitem in SelectedItems)
                        {
                            if (item.ID == selectionitem.ID)
                            {
                                item.IsSelected = selectionitem.IsSelected;
                            }
                        }
                    }
                }
                else
                {
                    AppPreferences.SelectedCourseTypeID = string.Empty;
                }
            }

            CommonListItemSource = CommonListData;
        }
        async void BindCourseTypeData()
        {
            Debug.WriteLine("@ DynamicListPage.CourseType");
            int currentYear = DateTime.Now.Year;
            CommonListData = new List<CommonBO>();
            if (_commonListdata == null)
            {
                try
                {
                    UserDialogs.Instance.ShowLoading();
                    MasterTableRequestData MasterTableRequestData = new MasterTableRequestData()
                    {
                        HiremeeID = AppSessionData.ActiveToken.HireMeID,
                        Token = AppSessionData.ActiveToken.Token,
                        TableName = "coursetype"
                    };
                    var responseobj = await _commonservice.PostAsync<CourseTypeResponseData, MasterTableRequestData>(APIData.API_BASE_URL + APIMethods.MasterTables, MasterTableRequestData);
                    if (responseobj != null)
                    {

                        if (responseobj.code == "200" && responseobj.Response != null)
                        {

                            if (responseobj.Response.Response != null)
                            {
                                foreach (var item in responseobj.Response.Response)
                                {
                                    CommonListData.Add(new CommonBO { ID = item.ID.ToString(), Title = item.Title });
                                }
                                isEnabledSearchBar = true;
                                _commonListdata = new ObservableCollection<CommonBO>(CommonListData);
                                UserDialogs.Instance.HideLoading();
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                isEnabledSearchBar = false;
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.NoRecordsFound);
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();

                            isEnabledSearchBar = false;
                            await UserDialogs.Instance.AlertAsync(responseobj.message);
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        isEnabledSearchBar = false;
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                    UserDialogs.Instance.HideLoading();
                    SendErrorMessageToServer(ex, "MultipleSelectionViewModel.BindCourseTypeData");
                }


            }
            if (SelectedItems != null && SelectedItems.Count > 0)
            {

                if (_commonListdata.Count > 0 && SelectedItems.Count > 0)
                {
                    foreach (var item in _commonListdata)
                    {
                        item.IsSelected = false;
                        foreach (var selectionitem in SelectedItems)
                        {
                            if (item.ID == selectionitem.ID)
                            {
                                item.IsSelected = selectionitem.IsSelected;
                            }
                        }
                    }
                }
            }

            CommonListItemSource = CommonListData;
        }
        async void BindCollegeData()
        {
            Debug.WriteLine("@ DynamicListPage.Colleges");
            int currentYear = DateTime.Now.Year;
            CommonListData = new List<CommonBO>();
            if (_commonListdata == null)
            {
                try
                {
                    UserDialogs.Instance.ShowLoading();
                    var objRequestData = new BaseRequestDTO();
                    var responseobj = await _commonservice.PostAsync<CollegeNameListFullResponseData, BaseRequestDTO>(APIData.API_BASE_URL + APIMethods.BindCollegeName, objRequestData);
                    if (responseobj != null)
                    {
                        if (responseobj.code == "200" && responseobj.ResponseText.ResponseData != null)
                        {

                            if (responseobj.ResponseText.ResponseData != null)
                            {
                                foreach (var item in responseobj.ResponseText.ResponseData)
                                {
                                    CommonListData.Add(new CommonBO { ID = item.ID.ToString(), Title = item.Title });
                                }
                                isEnabledSearchBar = true;
                                _commonListdata = new ObservableCollection<CommonBO>(CommonListData);
                                UserDialogs.Instance.HideLoading();
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                isEnabledSearchBar = false;
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.NoRecordsFound);
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            isEnabledSearchBar = false;
                            await UserDialogs.Instance.AlertAsync(responseobj.message);
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        isEnabledSearchBar = false;
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                    UserDialogs.Instance.HideLoading();
                    SendErrorMessageToServer(ex, "MultipleSelectionViewModel.BindCollegeData");
                }


            }
            if (SelectedItems != null && SelectedItems.Count > 0)
            {

                if (_commonListdata.Count > 0 && SelectedItems.Count > 0)
                {
                    foreach (var item in _commonListdata)
                    {
                        item.IsSelected = false;
                        foreach (var selectionitem in SelectedItems)
                        {
                            if (item.ID == selectionitem.ID)
                            {
                                item.IsSelected = selectionitem.IsSelected;
                            }
                        }
                    }
                }
            }

            CommonListItemSource = CommonListData;
        }
        async void BindCityData()
        {
            Debug.WriteLine("@ DynamicListPage.City");
            CommonListData = new List<CommonBO>();
            if (_commonListdata == null)
            {
                try
                {
                    UserDialogs.Instance.ShowLoading();
                    DistrictRequestData DistrictRequestData = new DistrictRequestData()
                    {
                        StateID = AppPreferences.SelectedStateID
                    };
                    var responseobj = await _commonservice.PostAsync<DistrictResponseData, DistrictRequestData>(APIData.API_BASE_URL + APIMethods.SearchCandidateByDistrict, DistrictRequestData);
                    if (responseobj != null)
                    {
                        if (responseobj.code == "200" && responseobj.Response != null)
                        {

                            if (responseobj.Response.Response != null)
                            {
                                foreach (var item in responseobj.Response.Response)
                                {
                                    CommonListData.Add(new CommonBO { ID = item.ID.ToString(), Title = item.Title });
                                }
                                isEnabledSearchBar = true;
                                _commonListdata = new ObservableCollection<CommonBO>(CommonListData);
                                UserDialogs.Instance.HideLoading();
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                isEnabledSearchBar = false;
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.NoRecordsFound);
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            isEnabledSearchBar = false;
                            await UserDialogs.Instance.AlertAsync(responseobj.message);
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        isEnabledSearchBar = false;
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                    UserDialogs.Instance.HideLoading();
                    SendErrorMessageToServer(ex, "MultipleSelectionViewModel.BindCityData");
                }


            }
            if (SelectedItems != null && SelectedItems.Count > 0)
            {

                if (_commonListdata.Count > 0 && SelectedItems.Count > 0)
                {
                    foreach (var item in _commonListdata)
                    {
                        item.IsSelected = false;
                        foreach (var selectionitem in SelectedItems)
                        {
                            if (item.ID == selectionitem.ID)
                            {
                                item.IsSelected = selectionitem.IsSelected;
                            }
                        }
                    }
                }
                else
                {
                    AppPreferences.SelectedStateID = string.Empty;
                }
            }

            CommonListItemSource = CommonListData;
        }

        public Boolean _btnSendIsDestructive;
        public Boolean btnSendIsDestructive
        {
            get { return _btnSendIsDestructive; }
            set { _btnSendIsDestructive = value; OnPropertyChanged(); }
        }

        public Command DoneClicked
        {
            get;
            set;
        }

        public List<CommonBO> _commonListItemSource;
        public List<CommonBO> CommonListItemSource
        {
            get { return _commonListItemSource; }
            set { _commonListItemSource = value; OnPropertyChanged(); }
        }




        #region Searchbar Controls
        private bool _isVisibleSearchbarCancel;
        public bool IsVisibleSearchbarCancelButton
        {
            get { return _isVisibleSearchbarCancel; }
            set { _isVisibleSearchbarCancel = value; OnPropertyChanged(); }
        }
        public bool _isEnabledSearchBar;

        public bool isEnabledSearchBar
        {
            set { _isEnabledSearchBar = value; OnPropertyChanged(); }
            get { return _isEnabledSearchBar; }
        }
        public string _SearchText;
        public string SearchText
        {
            set
            {
                _SearchText = value;
                SearchText_TextChanged();
                OnPropertyChanged();
            }
            get { return _SearchText; }
        }
        public Command OnSearchClearCommand => new Command(() =>
        {

            SearchText = string.Empty;


        });
        private string _searchPlaceHolder;
        private string listData;
        private List<CourseType> courseTypes;

        public string SearchPlaceHolderText
        {
            get { return _searchPlaceHolder; }
            set { _searchPlaceHolder = value; OnPropertyChanged(); }
        }
        private void DynamicDataFields()
        {
            if (SelectedListName == Constants.FieldType.College)
            {
                PageTitle = "Select College";
                SearchPlaceHolderText = "Search College";
                BindCollegeData();
            }
            else if (SelectedListName == Constants.FieldType.CourseType)
            {
                PageTitle = "Select Course Types";
                SearchPlaceHolderText = "Search Course Type";
                BindCourseTypeData();
            }
            else if (SelectedListName == Constants.FieldType.Course)
            {
                PageTitle = "Select Courses";
                SearchPlaceHolderText = "Search Course";
                BindCourseData();
            }
            else if (SelectedListName == Constants.FieldType.Specialization)
            {
                PageTitle = "Select Specializations";
                SearchPlaceHolderText = "Search Specialization";
                BindSpecializationData();
            }
            else if (SelectedListName == Constants.FieldType.City)
            {
                PageTitle = "Select City";
                SearchPlaceHolderText = "Search City";
                BindCityData();
            }


        }

        public void SearchText_TextChanged()
        {
            var searchtext = SearchText;
            if (string.IsNullOrEmpty(searchtext))
            {


                if (CommonListData.Count > 0)
                {
                    CommonListItemSource = CommonListData;
                    IsVisibleSearchbarCancelButton = false;
                }
                else
                {
                    IsVisibleSearchbarCancelButton = false;
                    if (SelectedListName == Constants.FieldType.College)
                    {
                        BindCollegeData();
                    }
                    else if (SelectedListName == Constants.FieldType.CourseType)
                    {
                        BindCourseTypeData();
                    }
                    else if (SelectedListName == Constants.FieldType.Course)
                    {
                        BindCourseData();
                    }
                    else if (SelectedListName == Constants.FieldType.Specialization)
                    {
                        BindSpecializationData();
                    }
                    else if (SelectedListName == Constants.FieldType.City)
                    {
                        BindCityData();
                    }



                }

                return;
            }
            IsVisibleSearchbarCancelButton = true;
            var searchresults = CommonListData.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
            CommonListItemSource = searchresults;



        }

        #endregion


        public async void onDoneClicked()
        {
            if (isClicked)
            {
                isClicked = false;
                btnSendIsDestructive = true;
                MultipleSelectionBO objSelectionBO = new MultipleSelectionBO();
                List<CommonBO> selectedCollection = new List<CommonBO>();
                if (_commonListdata != null)
                {
                    foreach (var item in _commonListdata)
                    {
                        objSelectionBO.SearchName = SearchName;
                        objSelectionBO.SelectedItemID = item.ID;
                        objSelectionBO.Title = item.Title;
                        objSelectionBO.IsSelected = item.IsSelected;
                        objSelectionBO.CreatedOn = DateTime.Now;
                        //objSelectionHelper.AddData(objSelectionBO);
                        if (item.IsSelected)
                        {
                            selectedCollection.Add(item);
                        }
                    }
                }
                MessagingCenter.Send<MultipleSelectionViewModel, List<CommonBO>>(this, SelectedListName, selectedCollection);
                Navigation.PopAsync();

            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });


        }




        public async void OnSelectionSwitch_Toggled(object sender, ToggledEventArgs e)
        {
            var selectedItem = ((Switch)sender).BindingContext as CommonBO;

            try
            {

                var selectioncount = 0;
                foreach (var skill in _commonListdata)
                {
                    if (skill.IsSelected)
                        selectioncount++;
                }

                if (selectioncount > 3)
                {
                    selectedItem.IsSelected = false;
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.SelectedMaximumData);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "MultipleSelectionViewModel.OnSelectionSwitch_Toggled");
            }
        }

        private string _pageTitle;

        public string PageTitle
        {
            get { return _pageTitle; }
            set { _pageTitle = value; OnPropertyChanged(); }
        }
        private bool _isVisibleRecordNotFound;

        public bool IsVisibleRecordNotFound
        {
            get { return _isVisibleRecordNotFound; }
            set { _isVisibleRecordNotFound = value; OnPropertyChanged(); }
        }
        private bool _isVisibleListView;

        public bool IsVisibleListView
        {
            get { return _isVisibleListView; }
            set { _isVisibleListView = value; OnPropertyChanged(); }
        }


    }
}
