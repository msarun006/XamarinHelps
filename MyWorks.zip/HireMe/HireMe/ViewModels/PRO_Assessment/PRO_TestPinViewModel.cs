﻿
using System;
using HireMe.Helpers;
using MvvmHelpers;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;
using Acr.UserDialogs;
using HireMe.Views.PRO_Assessment;
using HireMe.Models.PRO_Assessment;
using Plugin.Connectivity;
using System.Diagnostics;
using HireMe.LocalDataBase;
using System.Collections.Generic;

namespace HireMe.ViewModels.PRO_Assessment
{
    public class PRO_TestPinViewModel : BaseViewModel
    {
        #region Initial Declarations
        private HttpCommonService _commonservice { get; set; }
        public LocalDB _localDB { get; set; }
        public ICommand OnSubmitCommand { get; set; }
        public string _pageTitle;
        public INavigation NavigationService { get; set; }
        public bool isClicked = true;
        #endregion

        #region Constructor
        public PRO_TestPinViewModel(INavigation objNav)
        {
            Constant.heartbeatlogRunning = false;
            AppPreferences.Is_NavigationLog = false;
            NavigationService = objNav;
            _commonservice = new HttpCommonService();
            OnSubmitCommand = new Command(SubmitCommandAsync);
           _localDB = new LocalDB();
            AppPreferences.IsPRO_Assesment_TimerRunning = false;

        }
        #endregion

        #region SubmitCommandAsync
        private async void SubmitCommandAsync(object obj)
        {

            if (obj.ToString() == "submit")
            {
                if (isClicked)
                {
                    isClicked = false;
                    SubmitTestPin();
                }
                await Task.Run(async () =>
                {
                    await Task.Delay(500);
                    isClicked = true;
                });
            }
        }
        #endregion

        #region API Call with TestPin
        private async void SubmitTestPin()
        {
            if (string.IsNullOrEmpty(TestPinValue) || string.IsNullOrWhiteSpace(TestPinValue))
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.EmptyTestPin);
            }
            else if (TestPinValue.ToString().Length < 6)
            {
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.TestPinValidation);
            }
            else
            {
                try
                {
                    UserDialogs.Instance.ShowLoading();
                    await Task.Delay(100);
                    Clear_PRO_Preferences();
                    var _TestPinRequestData = new TestPinRequestData();
                    _TestPinRequestData.testpin = TestPinValue;
                    _TestPinRequestData.DeviceID = Utilities.GetDeviceID();
                    _TestPinRequestData.DeviceModel = Utilities.GetDeviceModel();
                    _TestPinRequestData.DeviceOS = Utilities.GetDeviceOS();
                    _TestPinRequestData.mobile_brand = Utilities.GetDeviceBrandName();
                    _TestPinRequestData.os_version = Utilities.GetDeviceVersion();
                    _TestPinRequestData.SecretKey = "40709fe7-6790-4056-8b75-a65f54239fbc";

                    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                    if (isNetworkAvailable)
                    {
                        var result = await _commonservice.PostAsync<TestPinResponseData, TestPinRequestData>(APIData.API_BASE_URL + APIMethods.ValidateTestPin, _TestPinRequestData);
                        if (result != null)
                        {
                          
                            if (result.code == "200")
                            {
                                if (result.responseText != null)
                                {
                                    if (result.responseText.mode == Convert.ToString((int)mode.Mobile) || result.responseText.mode == Convert.ToString((int)mode.WebAndMobile))
                                    {
                                        AppPreferences.Is_HireMee_PRO_User = true;


                                        #region Local Storage Initialize 
                                        //Drop All PRO Tables 
                                       try
                                        {
                                            _localDB.DropAllPROTables();
                                        }
                                        catch(Exception  ex)
                                        {

                                        }
                                          
                                        
                                        //Create Necessart tables for HireMee PRO Assessment like (tbl_timer, question, option)
                                        _localDB.CreatePROTables();
                                        #endregion

                                        #region Load PRO AWS Credentials
                                        if (result.AWSCredential != null)
                                        {
                                            if (result.AWSCredential.Count > 0 && result.AWSCredential[0].credential_type == AmazonS3BucketDetails.PRO_CandidateAWS_KEY)
                                            {
                                                AppPreferences.PRO_AWS_Credentials = result.AWSCredential[0];
                                            }
                                       
                                        }
                                        #endregion

                                        #region Load Proof Image(Training Image)
                                        AppPreferences.Is_Traning_Image_Available = result.is_training_image_available;
                                        if (AppPreferences.Is_Traning_Image_Available != null && AppPreferences.Is_Traning_Image_Available == "True")
                                        {
                                            await Get_Image_from_S3(result.s3_id_training_image, "ProofImage");
                                        }
                                        #endregion

                                        #region Load Test Logo
                                        if (result.responseText.test_logo != null)
                                        {
                                            if (result.responseText.test_logo.Contains("http"))
                                            {
                                                AppPreferences.PRO_TestLogo = result.responseText.test_logo;
                                            }
                                            else
                                            {
                                                await Get_Image_from_S3(result.responseText.test_logo, "TestLogo");
                                            }
                                        }
                                        #endregion

                                        #region Load Elapsed Time
                                       if (!string.IsNullOrEmpty(result.Last_ElapsedTime_inSeconds))
                                        {
                                            AppPreferences.PRO_ExamLastElapsedTime = result.Last_ElapsedTime_inSeconds;
                                        }
                                        #endregion

                                        #region Load Server Time
                                        //Server Timer
                                        if (result.responseText.sever_time != null)
                                        {
                                            AppPreferences.ServerDateTime = result.responseText.sever_time.Ticks.ToString();
                                            AppPreferences.ServerDate = result.responseText.sever_time.Date.ToString("yyyy-MM-dd");
                                            AppPreferences.ServerUpdatedDateTime = result.responseText.sever_time.ToString();
                                        }

                                        if (!string.IsNullOrEmpty(result.last_updated_sectionid))
                                        {
                                            AppPreferences.LastUpdatedSectionID = result.last_updated_sectionid;
                                        }

                                        #endregion

                                        #region Load Result Data
                                        var tokenData = new ApplicationToken()
                                        {
                                            Token = result.TokenID,
                                            Expire = DateTime.Now.AddSeconds(Convert.ToDouble(result.TokenExpiry)),
                                            RefreshToken = result.Refreshtoken,
                                        };
                                        if (!string.IsNullOrEmpty(result.company_name))
                                        {
                                            AppPreferences.PRO_CompanyName = result.company_name;
                                        }
                                        else
                                        {
                                            AppPreferences.PRO_CompanyName = string.Empty;
                                        }
                                        AppSessionData.ActiveToken = tokenData;




                                        AppPreferences.TestPinMasterData = result.responseText;

                                        #endregion

                                        UserDialogs.Instance.HideLoading();
                                        Application.Current.MainPage = new NavigationPage(new PRO_ExternalDeviceStatusPage());
                                    }
                                    else
                                    {
                                        UserDialogs.Instance.HideLoading();
                                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ModeValidationMessage);
                                        return;
                                    }
                                }
                                else
                                {
                                    UserDialogs.Instance.HideLoading();
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                                }

                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                await UserDialogs.Instance.AlertAsync(result.message);
                            }

                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                    }
                }
                catch (Exception ex)
                {
                    UserDialogs.Instance.HideLoading();
                    Debug.WriteLine(ex.Message);
                    SendErrorMessageToServer(ex, "PRO_TestPinViewModel.SubmitTestPin");
                }
            }
        }

        #endregion

        public async Task Get_Image_from_S3(string s3_ID,string _imageType)
        {
            try
            {
                #region Download TestLogo from S3
                if (!string.IsNullOrEmpty(s3_ID))
                {
                    if(AppPreferences.PRO_AWS_Credentials != null)
                    {
                        string BucketName = AppPreferences.PRO_AWS_Credentials.buketname;
                        Application.Current.Properties["Bucket_name"] = AppPreferences.PRO_AWS_Credentials.buketname;
                        await App.Current.SavePropertiesAsync();
                        var S3ImageDownloder = new S3ImageDownloder();
                        string DownloadedImage = S3ImageDownloder.DownloadS3Image(s3_ID, BucketName);
                     

                        if (_imageType == "TestLogo")
                        {
                            if (!string.IsNullOrEmpty(DownloadedImage))
                            {
                                AppPreferences.PRO_TestLogo = DownloadedImage;
                            }
                            else
                            {
                                AppPreferences.PRO_TestLogo = string.Empty;
                            }
                            Application.Current.Properties.Remove("Bucket_name");
                            await App.Current.SavePropertiesAsync();

                        }
                        else if (_imageType == "ProofImage")
                        {
                            if (!string.IsNullOrEmpty(DownloadedImage))
                            {
                                AppPreferences.CapturedAssesmentImageFilePath = DownloadedImage;
                            }
                            else
                            {
                                AppPreferences.Is_Traning_Image_Available = "False";
                                AppPreferences.CapturedAssesmentImageFilePath = string.Empty;
                            }
                            Application.Current.Properties.Remove("Bucket_name");
                            await App.Current.SavePropertiesAsync();
                        }
                       
                    }

                  
                }

                #endregion
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "PRO_TestPinViewModel.Get_Image_from_S3");
            }
        }
        public async void Clear_PRO_Preferences()
        {
            try
            {

                Application.Current.Properties.Remove("Bucket_name");
                await App.Current.SavePropertiesAsync();
                AppSessionData.ActiveToken = null;
                AppPreferences.TestPinMasterData = null;
                AppPreferences.PRO_AWS_Credentials = null;
                AppPreferences.Is_Traning_Image_Available = string.Empty;
                AppPreferences.PRO_TestLogo = string.Empty;
                AppPreferences.CapturedAssesmentImageFilePath = string.Empty;
                AppPreferences.S3AccessKeyID = string.Empty;
                AppPreferences.S3SecretAccessKey = string.Empty;
                AppPreferences.LastUpdatedSectionID = string.Empty;
                AppPreferences.PRO_ExamLastElapsedTime = string.Empty;
                AppPreferences.ServerDateTime = string.Empty;
                AppPreferences.ServerDate = string.Empty;
                AppPreferences.ServerUpdatedDateTime = string.Empty;
                AppPreferences.PRO_CompanyName = string.Empty;
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "PRO_TestPinViewModel.Clear_PRO_Preferences");
            }
        }

        #region Binding Properties

        private string _TestPinValue;
        public string TestPinValue
        {
            get { return _TestPinValue; }
            set { _TestPinValue = value; OnPropertyChanged(); }
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}

