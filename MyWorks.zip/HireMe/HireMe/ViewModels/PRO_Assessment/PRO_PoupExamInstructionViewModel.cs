﻿

using Acr.UserDialogs;
using GalaSoft.MvvmLight.Command;
using HireMe.Helpers;
using HireMe.Interface;
using HireMe.Views.PRO_Assessment;
using MvvmHelpers;
using Rg.Plugins.Popup.Extensions;
using System;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.Assessment
{
    public  class PRO_PoupExamInstructionViewModel : BaseViewModel
    {

        public bool isClicked = true;
        public INavigation navigationService { get; set; }
        public ICommand OnCommand { get; set; }
        public PRO_PoupExamInstructionViewModel(INavigation navigation,bool IsShowExamInstruction)
        {
            OnCommand = new RelayCommand<string>(CommonFunction);
            navigationService = navigation;
            // Examinstruction = null;
            InstructionTitle = "Exam Instruction";
            if (IsShowExamInstruction)
            {
                
                if (AppPreferences.TestPinMasterData.is_section_navigation == Convert.ToString((int)is_section_navigation.Enable))
                {
                   LoadHTMLSource(AppPreferences.SectionInstruction);
                    InstructionTitle = "Section Instruction";
                }
                else
                {
                    LoadHTMLSource(AppPreferences.ExamInstruction);
                    InstructionTitle = "Exam Instruction";
                }
            }
            else
            {

                LoadHTMLSource(AppPreferences.ExamInstruction);
                InstructionTitle = "Exam Instruction";

            }



        }


        #region LoadHTMLSource - Dynamic Instruction
        public async void LoadHTMLSource(string objContent)
        {
            try
            {
                //  string data = _TestPinMasterData.exam_instruction;

                string data = objContent;

                if (!string.IsNullOrEmpty(data))
                {
                    UserDialogs.Instance.ShowLoading();
                    string htmlText = data.Replace(@"\", string.Empty);
                    var html = new HtmlWebViewSource
                    {
                        Html = htmlText
                    };
                    WebviewContent = html;
                    UserDialogs.Instance.HideLoading();


                }
                else
                {
                   await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    App.Current.MainPage = new NavigationPage(new PRO_ExamPage());
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "PRO_ExamInstructionViewModel.LoadHTMLSource");
            }
        }
        #endregion




        public async void CommonFunction(string obj)
        {
            try
            {
                switch (obj)
                {
                    #region iconselect Button Click Event
                    case "OnClose":
                        if (isClicked)
                        {
                            isClicked = false;

                            await navigationService.PopAllPopupAsync();
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(500);
                            isClicked = true;
                        });
                        break;
                        #endregion
                }
            }
            catch(Exception e)
            {
                SendErrorMessageToServer(e, "PoupExamInstructionViewModel.CommonFunction");
            }
        }


        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion



        private String _Examname;

        public String Examname
        {
            get { return _Examname; }
            set { _Examname = value; OnPropertyChanged(); }
        }

        private String _InstructionTitle;

        public String InstructionTitle
        {
            get { return _InstructionTitle; }
            set { _InstructionTitle = value; OnPropertyChanged(); }
        }



        private HtmlWebViewSource _webviewContent;

        public HtmlWebViewSource WebviewContent
        {
            get { return _webviewContent; }
            set { _webviewContent = value; OnPropertyChanged(); }
        }

        private string _SourceURL;

        public string SourceURL
        {
            get { return _SourceURL; }
            set { _SourceURL = value; OnPropertyChanged(); }
        }
    }
}
