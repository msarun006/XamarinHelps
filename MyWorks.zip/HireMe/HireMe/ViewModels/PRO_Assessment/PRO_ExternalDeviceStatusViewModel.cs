﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.Helpers.PRO_Assement;
using HireMe.Interface;
using HireMe.Services;
using HireMe.Views;
using HireMe.Views.PRO_Assessment;
using MvvmHelpers;
using Plugin.Connectivity;
using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using System;
using System.Diagnostics;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace HireMe.ViewModels.PRO_Assessment
{
    public class PRO_ExternalDeviceStatusViewModel : BaseViewModel
    {

        #region Variable Declaration
        public Command OnCommand { get; set; }
        public Boolean isValidFrontCamera { get; set; }
        public bool isClicked = true;
        public string AssessmentImagePath { get; set; } = string.Empty;
        private HttpCommonService _commonservice { get; set; }
        #endregion

        #region Constructor
        public PRO_ExternalDeviceStatusViewModel()
        {
            AppPreferences.IsPRO_Assesment_TimerRunning = false;
            Constant.heartbeatlogRunning = false;
            AppPreferences.Is_NavigationLog = false;
            _commonservice = new HttpCommonService();
            if (AppPreferences.TestPinMasterData.is_image_proctering == Constant.IsImageProctoringOptionsShow)
            {
                IsVisibleCameraPermission = true;
            }
            else
            {
                IsVisibleCameraPermission = false;
            }

            OnCommand = new Command(CommonFunction);
            isValidFrontCamera = false;
            IsShowCameraWarning = true;
            IsShowNetworkWarning = true;
            IsShowServerWarning = true;

            TestPicture = AppPreferences.PRO_TestLogo;
            if (String.IsNullOrEmpty(TestPicture))
            {
                TestPicture = "hiremee_assessment_icon.png";
            }




            CheckDeviceStatus();
            if (Device.RuntimePlatform == Device.iOS)
            {
                IsShowIOSOnly = true;
            }
            else
            {
                IsShowIOSOnly = false;

            }
            loadImage();
        }
        #endregion

        private async void loadImage()
        {
            if (AppPreferences.TestPinMasterData.is_image_proctering == Constant.IsImageProctoringOptionsShow)
            {
                if (!String.IsNullOrEmpty(AppPreferences.CapturedAssesmentImageFilePath))
                {
                    AssementProfilePicture = AppPreferences.CapturedAssesmentImageFilePath;
                }
                else
                {
                    AssementProfilePicture = "userimage.png";
                }
            }
            else
            {
                AssementProfilePicture = "userimage.png";
            }


        }


        private bool isShowIOSOnly;

        public bool IsShowIOSOnly
        {
            get => isShowIOSOnly;
            set { isShowIOSOnly = value; OnPropertyChanged(); }
        }

        #region AskRunTimePermission
        private async void AskRunTimePermissionAsync()
        {
            try
            {
                var CameraAccess = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Camera);
                var StorageAccess = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Storage);

                if (CameraAccess != PermissionStatus.Granted || StorageAccess != PermissionStatus.Granted)
                {
                    IsShowPermissionWarning = true;
                    PermissionsStatus = "Denied";
                    var results = await CrossPermissions.Current.RequestPermissionsAsync(new[] { Permission.Camera, Permission.Storage });
                    if (results != null)
                    {
                        CameraAccess = results[Permission.Camera];
                        StorageAccess = results[Permission.Storage];
                    }
                }

                if (CameraAccess == PermissionStatus.Granted && StorageAccess == PermissionStatus.Granted)
                {
                    IsShowPermissionWarning = false;

                    PermissionsStatus = "Granted";

                }
                else if (CameraAccess != PermissionStatus.Unknown)
                {
                    IsShowPermissionWarning = true;
                    PermissionsStatus = "Denied";
                    UserDialogs.Instance.Toast(MessageStringConstants.PermissionMessage);
                }



                if (Device.RuntimePlatform == Device.Android)
                {

                    var IsLolipopAboveVersion = DependencyService.Get<IMyDevice>().PermissionStatus();

                    if (IsLolipopAboveVersion)
                    {
                        if (CameraAccess != PermissionStatus.Granted || StorageAccess != PermissionStatus.Granted)
                        {
                            IsShowPermissionWarning = true;

                            PermissionsStatus = "Denied";

                        }

                        if (CameraAccess == PermissionStatus.Granted && StorageAccess == PermissionStatus.Granted)
                        {
                            IsShowPermissionWarning = false;

                            PermissionsStatus = "Granted";

                        }
                        else if (CameraAccess != PermissionStatus.Unknown)
                        {
                            IsShowPermissionWarning = true;

                            PermissionsStatus = "Denied";

                            UserDialogs.Instance.Toast(MessageStringConstants.PermissionMessage);
                            //await UserDialogs.Instance.AlertAsync(MessageStringConstants.CameraMessage, MessageStringConstants.PermissionMessage, "OK");
                        }
                    }
                    else
                    {
                        IsShowPermissionWarning = false;

                        PermissionsStatus = "Denied";

                    }

                }
                else if (Device.RuntimePlatform == Device.iOS)
                {
                    if (CameraAccess != PermissionStatus.Granted || StorageAccess != PermissionStatus.Granted)
                    {
                        IsShowPermissionWarning = true;

                        PermissionsStatus = "Denied";

                    }

                    if (CameraAccess == PermissionStatus.Granted && StorageAccess == PermissionStatus.Granted)
                    {


                        PermissionsStatus = "Granted";

                    }
                    else if (CameraAccess != PermissionStatus.Unknown)
                    {
                        IsShowPermissionWarning = true;
                        if (AppPreferences.IsHindi)
                        {
                            PermissionsStatus = "से इनकार किया";
                        }
                        else
                        {
                            PermissionsStatus = "Denied";
                        }
                        UserDialogs.Instance.Toast(MessageStringConstants.PermissionMessage);
                        //await UserDialogs.Instance.AlertAsync(MessageStringConstants.CameraMessage, MessageStringConstants.PermissionMessage, "OK");
                    }
                }


            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "ExternalDeviceStatusViewModel.AskRunTimePermissionAsync");
            }
        }
        #endregion

        #region CheckDeviceStatus
        private void CheckDeviceStatus()
        {
            try
            {


                UserDialogs.Instance.ShowLoading();
                AskRunTimePermissionAsync();

                if (AppPreferences.TestPinMasterData.is_image_proctering == Constant.IsImageProctoringOptionsShow)
                {

                    if (DependencyService.Get<IExternalDeviceStatus>().IsFrontCameraAvailable())
                    {
                        IsShowCameraWarning = false;
                        isValidFrontCamera = true;
                        FrontCameraStatus = "Available";
                        FrontCameraStatusAccept = (string)Application.Current.Resources["TickIcon"];
                        FrontCameraStatusColor = (Color)Application.Current.Resources["DarkGreenColor"];
                    }
                    else
                    {
                        IsShowCameraWarning = true;
                        isValidFrontCamera = false;
                        FrontCameraStatus = "Not Available";
                        FrontCameraStatusAccept = (string)Application.Current.Resources["WarningIcon"];
                        FrontCameraStatusColor = (Color)Application.Current.Resources["DarkRedColor"];
                    }
                }
                #region Check Network Availability
                bool isNetworkAvailable;
                if (Device.RuntimePlatform == Device.Android)
                {
                    isNetworkAvailable = DependencyService.Get<IMyDevice>().IsInternetAvailable();
                }
                else
                {
                    isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                }
                if (isNetworkAvailable)
                {
                    IsShowNetworkWarning = false;
                    NetworkStatus = "Available";
                }
                else
                {
                    IsShowNetworkWarning = true;
                    NetworkStatus = "Un available";
                }
                #endregion

                #region Check Host Reachable
                if (isNetworkAvailable)
                {
                    bool isHostReachable = DependencyService.Get<IMyDevice>().IsHostReachable();
                    if (isHostReachable)
                    {
                        IsShowServerWarning = false;
                        ServerStatus = "Reachable";
                    }
                    else
                    {
                        IsShowServerWarning = true;
                        ServerStatus = "Not Reachable";
                    }
                }
                else
                {
                    IsShowServerWarning = true;
                    ServerStatus = "Not Reachable";
                }

                #endregion

                UserDialogs.Instance.HideLoading();
            }
            catch (Exception e)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "ExternalDeviceStatusViewModel.CheckDeviceStatus");
            }
        }
        #endregion

        #region Click Event
        public async void CommonFunction(object obj)
        {
            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
            #region RefreshButton Click Event
            if (obj.ToString().Equals("refresh"))
            {


                CheckDeviceStatus();


            }
            #endregion

            #region Take Photo Click Event
            if (obj.ToString().Equals("takephoto"))
            {
                if (isClicked)
                {
                    isClicked = false;
                    if (isNetworkAvailable)
                    {
                        if (AppPreferences.Is_Traning_Image_Available != "True")
                        {
                            var status = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Camera);
                            var storage = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Storage);
                            if (status != PermissionStatus.Granted || storage != PermissionStatus.Granted)
                            {
                                IsShowPermissionWarning = true;
                                PermissionsStatus = "Denied";
                                var results = await CrossPermissions.Current.RequestPermissionsAsync(new[] { Permission.Camera, Permission.Storage });
                                status = results[Permission.Camera];
                                storage = results[Permission.Storage];
                            }
                            if (status == PermissionStatus.Granted && storage == PermissionStatus.Granted)
                            {
                                UserDialogs.Instance.HideLoading();
                                App.Current.MainPage = new NavigationPage(new AssesmentTakePhotoPage());
                            }
                            else if (status != PermissionStatus.Unknown)
                            {
                                UserDialogs.Instance.HideLoading();
                                UserDialogs.Instance.Toast(MessageStringConstants.PermissionMessage);
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            UserDialogs.Instance.Toast(MessageStringConstants.PRO_YourProofImageAlreadyAvailable);
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                    }
                }
                await Task.Run(async () =>
                {
                    await Task.Delay(500);
                    isClicked = true;
                });
            }
            #endregion


            #region proceed Click Event
            else if (obj.ToString().Equals("proceed"))
            {

                if (isClicked)
                {
                    isClicked = false;
                    CommonFunction("refresh");
                    if (isNetworkAvailable)
                    {

                        UserDialogs.Instance.ShowLoading();
                        await OnProceedClicked();
                        UserDialogs.Instance.HideLoading();
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                    }
                }
                await Task.Run(async () =>
                {
                    await Task.Delay(500);
                    isClicked = true;
                });
                #endregion
            }
            #endregion


        }



        private async Task OnProceedClicked()
        {

            try
            {
                if (AppPreferences.TestPinMasterData.is_image_proctering == Constant.IsImageProctoringOptionsShow)
                {
                    var status = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Camera);
                    var storage = await CrossPermissions.Current.CheckPermissionStatusAsync(Permission.Storage);
                    if (!IsShowPermissionWarning && !IsShowCameraWarning)
                    {

                        if (status != PermissionStatus.Granted || storage != PermissionStatus.Granted)
                        {
                            IsShowPermissionWarning = true;
                            PermissionsStatus = "Denied";
                            var results = await CrossPermissions.Current.RequestPermissionsAsync(new[] { Permission.Camera, Permission.Storage });
                            status = results[Permission.Camera];
                            storage = results[Permission.Storage];
                        }
                        if (status == PermissionStatus.Granted && storage == PermissionStatus.Granted)
                        {

                            PermissionsStatus = "Granted";

                            if (AppPreferences.Is_Traning_Image_Available != "True")
                            {
                                #region Upload Assesment Picture to ImageProctored Log
                                if (!String.IsNullOrEmpty(AppPreferences.CapturedAssesmentImageFilePath))
                                {
                                    #region Upload to S3 Bucket
                                    try
                                    {

                                        string fileName = System.IO.Path.GetFileName("@" + AppPreferences.CapturedAssesmentImageFilePath);
                                        if (AppPreferences.PRO_AWS_Credentials != null)
                                        {
                                            string BucketName = AppPreferences.PRO_AWS_Credentials.buketname;
                                            Application.Current.Properties["Bucket_name"] = AppPreferences.PRO_AWS_Credentials.buketname;
                                            await App.Current.SavePropertiesAsync();

                                            var S3_ID = await S3Manager.UploadFile(AppPreferences.CapturedAssesmentImageFilePath, AppPreferences.TestPinMasterData.testpin + "/" + fileName, BucketName);
                                            if (!string.IsNullOrEmpty(S3_ID))
                                            {

                                                Application.Current.Properties.Remove("Bucket_name");
                                                await Application.Current.SavePropertiesAsync();
                                                PRO_CommonLog _objImageLog = new PRO_CommonLog();
                                                _objImageLog.ImageProctored_Log(S3_ID, Constant.IsImageProctoringOptionsShow);
                                                MoveToNextPage();
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        UserDialogs.Instance.HideLoading();
                                        Debug.WriteLine(ex.Message);
                                        SendErrorMessageToServer(ex, "AssesmentPhotoPreviewViewModel.Upload_To_PRO_Assesment_Bucket.Upload to S3 Bucket");
                                    }

                                    #endregion
                                }
                                else
                                {
                                    UserDialogs.Instance.HideLoading();
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.PRO_CaptureYourAssesmentPhoto);
                                }
                                #endregion
                            }
                            else
                            {
                                MoveToNextPage();
                            }
                        }

                    }
                    else if (status != PermissionStatus.Unknown)
                    {
                        UserDialogs.Instance.HideLoading();
                        UserDialogs.Instance.Toast(MessageStringConstants.PermissionMessage);
                    }


                }
                else
                {
                    MoveToNextPage();
                }

            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "PRO_ExternalDeviceStatusViewModel.OnProceedClicked");
            }
        }


        private void MoveToNextPage()
        {
            try
            {
                string data = AppPreferences.TestPinMasterData.exam_instruction;
                AppPreferences.ExamInstruction = AppPreferences.TestPinMasterData.exam_instruction;
                HireMe.Models.PRO_Assessment.SectionInstructionContent objContent = new HireMe.Models.PRO_Assessment.SectionInstructionContent();
                objContent.section_content = data;
                objContent.isshow_instruction = true;
                UserDialogs.Instance.HideLoading();
                App.Current.MainPage = new NavigationPage(new PRO_ExamInstructionPage(objContent));
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "PRO_ExternalDeviceStatusViewModel.MoveToNextPage");
            }
        }


        #region Full Properties

        private Color frontCameraStatusColor;
        public Color FrontCameraStatusColor
        {
            get => frontCameraStatusColor;
            set { frontCameraStatusColor = value; OnPropertyChanged(); }
        }

        private String frontCameraStatusAccept;
        public String FrontCameraStatusAccept
        {
            get => frontCameraStatusAccept;
            set { frontCameraStatusAccept = value; OnPropertyChanged(); }
        }

        private String frontCameraStatus;
        public String FrontCameraStatus
        {
            get => frontCameraStatus;
            set { frontCameraStatus = value; OnPropertyChanged(); }
        }

        private String permissionsStatus;

        public String PermissionsStatus
        {
            get => permissionsStatus;
            set { permissionsStatus = value; OnPropertyChanged(); }
        }
        private String networkStatus;

        public String NetworkStatus
        {
            get => networkStatus;
            set { networkStatus = value; OnPropertyChanged(); }
        }
        private String serverStatus;

        public String ServerStatus
        {
            get => serverStatus;
            set { serverStatus = value; OnPropertyChanged(); }
        }

        private Boolean isShowPermissionWarning;
        public Boolean IsShowPermissionWarning
        {
            get => isShowPermissionWarning;
            set { isShowPermissionWarning = value; OnPropertyChanged(); }
        }

        private Boolean isShowCameraWarning;
        public Boolean IsShowCameraWarning
        {
            get => isShowCameraWarning;
            set { isShowCameraWarning = value; OnPropertyChanged(); }
        }

        private Boolean isShowNetworkWarning;
        public Boolean IsShowNetworkWarning
        {
            get => isShowNetworkWarning;
            set { isShowNetworkWarning = value; OnPropertyChanged(); }
        }

        private Boolean isShowServerWarning;
        public Boolean IsShowServerWarning
        {
            get => isShowServerWarning;
            set { isShowServerWarning = value; OnPropertyChanged(); }
        }


        private Boolean isVisibleCameraPermission;
        public Boolean IsVisibleCameraPermission
        {
            get => isVisibleCameraPermission;
            set { isVisibleCameraPermission = value; OnPropertyChanged(); }
        }

        private String testPicture;
        public String TestPicture
        {
            get => testPicture;
            set { testPicture = value; OnPropertyChanged(); }
        }

        private ImageSource _assementProfilePicture;
        public ImageSource AssementProfilePicture
        {
            get => this._assementProfilePicture;
            set
            {
                if (Equals(value, this._assementProfilePicture))
                { return; }
                this._assementProfilePicture = value;
                OnPropertyChanged();
            }
        }








        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

    }
}
