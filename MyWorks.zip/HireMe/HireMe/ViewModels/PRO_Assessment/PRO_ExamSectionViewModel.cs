﻿using MvvmHelpers;
using System;
using GalaSoft.MvvmLight.Command;
using System.Windows.Input;
using Xamarin.Forms;
using Acr.UserDialogs;
using HireMe.Views.Assessment;
using Rg.Plugins.Popup.Services;
using System.Threading.Tasks;
using HireMe.Accordion;
using System.Collections.Generic;
using HireMe.LocalDataBase;
using Newtonsoft.Json;
using System.Diagnostics;
using HireMe.Models.PRO_Assessment;
using HireMe.Views.PRO_Assessment;
using System.Text.RegularExpressions;
using Plugin.Connectivity;
using HireMe.Helpers;
using HireMee.Models.PRO_Assessment;

namespace HireMe.ViewModels.PRO_Assessment
{
    public class PRO_ExamSectionViewModel : BaseViewModel
    {
        StackLayout AccoridanStack;
        public bool isClicked = true;
        private List<SectionDetailsResponseData> _ListOfDataToAccoridanView;
        public List<SectionDetailsResponseData> ListOfDataToAccoridanView
        {
            get { return _ListOfDataToAccoridanView; }
            set { _ListOfDataToAccoridanView = value; OnPropertyChanged(); }
        }
        private HttpCommonService _commonservice { get; set; }
        ResultResponse ExamResult { get; set; }
        public ICommand OnCommand { get; set; }

        public LocalDB _localDB { get; set; }
        private AssignedAssessmentDetails _TestPinMasterData { get; set; } = AppPreferences.TestPinMasterData;

        public PRO_ExamSectionViewModel(INavigation navigation, StackLayout accordianStack)
        {
            AppPreferences.IsPRO_Assesment_TimerRunning = false;
            Constant.heartbeatlogRunning = false;
            AppPreferences.Is_NavigationLog = true;
            if (Device.RuntimePlatform == Device.iOS)
            {
                IsShowIOSOnly = true;
            }
            else
            {
                IsShowIOSOnly = false;
            }
            ExamResult = new ResultResponse();
            _commonservice = new HttpCommonService();
            AccoridanStack = accordianStack;
            _localDB = new LocalDB();
            ListOfDataToAccoridanView = new List<SectionDetailsResponseData>();

            //   TimerText = "02/20/2019";
            ExamName = _TestPinMasterData.assessment_name;
            if (!string.IsNullOrEmpty(_TestPinMasterData.assessment_name))
            {
                ExamName = _TestPinMasterData.assessment_name;
            }
            else
            {
                ExamName = " N/A";
            }

            if (!string.IsNullOrEmpty(_TestPinMasterData.syllabus))
            {
                //SyllabusName =  Regex.Replace(Regex.Replace(_TestPinMasterData.syllabus.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                SyllabusName = "Syllabus : "+_TestPinMasterData.syllabus;

                if (SyllabusName.Length >= 100)
                {
                    SyllabusName_substring = SyllabusName;
                    string str = SyllabusName.Substring(0, 99);
                    SyllabusName = str;
                    lblMore = "more...";
                }
            }
            else
            {
                SyllabusName = " N/A";
            }

            IsShowCameraPreView = true;
            CandidateName = _TestPinMasterData.first_name + _TestPinMasterData.last_name;
            if (string.IsNullOrEmpty(CandidateName))
            {
                SyllabusName = "N/A";
            }

            CompanyName = AppPreferences.PRO_CompanyName;

            if (!string.IsNullOrEmpty(_TestPinMasterData.is_endtest))
            {
                if (_TestPinMasterData.is_endtest == Convert.ToString((int)is_endtest.Enable))
                {
                    IsVisibleFinishButton = true;
                }
                else
                {
                    IsVisibleFinishButton = false;
                }
            }

            if (_TestPinMasterData.is_image_proctering == Convert.ToString((int)Is_image_proctering.Enable))
            {
                IsShowUserProfileView = true;
            }

            TestPicture = AppPreferences.PRO_TestLogo;
            if (String.IsNullOrEmpty(TestPicture))
            {
                TestPicture = "hiremee_assessment_icon.png";
            }

            if (!String.IsNullOrEmpty(AppPreferences.CapturedAssesmentImageFilePath))
            {
                PRO_AssesmentProfilePicture = AppPreferences.CapturedAssesmentImageFilePath;
            }
            else
            {
                PRO_AssesmentProfilePicture = "userimage.png";
            }




            ArrowChange = (string)Application.Current.Resources["UpArrowIcon"];
            OnCommand = new RelayCommand<string>(DoOperation);
            BindingDataToAccordianView();
            AllSectionCompltedInternallShowEndTestButton();
        }



        #region AllSectionCompltedInternallShowEndTestButton
        public void AllSectionCompltedInternallShowEndTestButton()
        {

            try
            {


                var totalcount = _localDB.GetAllPROSectionTimerList();
                var compltedcount = _localDB.GetCompletedCount();
                var elapsedcount = _localDB.GetElapsedCount();
                if (totalcount != null && compltedcount != null && elapsedcount != null && (totalcount.Count == (compltedcount.Count + elapsedcount.Count)))
                {
                    //Enable End Test Button
                    IsVisibleFinishButton = true;
                }
            }
            catch (Exception)
            {

            }
        }
        #endregion

        #region Binding Data To Accordian View
        private async void BindingDataToAccordianView()
        {
            try
            {
                int count = AccoridanStack.Children.Count;
                if (count > 1)
                {
                    AccoridanStack.Children.RemoveAt(1);
                }

                var serializedData = AppPreferences.TestPinGroupDetailsSerialize;
                ListOfDataToAccoridanView = JsonConvert.DeserializeObject<List<SectionDetailsResponseData>>(serializedData);

                if (ListOfDataToAccoridanView != null)
                {
                    var template = new DataTemplate(typeof(PRO_ExpandableViewTemplate));
                    PRO_AccordionView accordionView = new PRO_AccordionView(template);
                    accordionView.Template.SetBinding(PRO_AccordionSectionView.TitleProperty, "name");
                    accordionView.Template.SetBinding(PRO_AccordionSectionView.TitleStatusColorProperty, "section_colour");
                    accordionView.Template.SetBinding(PRO_AccordionSectionView.ItemsSourceProperty, "content");
                    accordionView.ItemsSource = ListOfDataToAccoridanView;
                    AccoridanStack.Children.Add(accordionView);
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                // SendErrorMessageToServer(ex, "AssessmentViewModel.BindingDataToAccordianView");
            }
        }
        #endregion


        #region UpdateExamCompletedStatustoServer
        public async void UpdateExamCompletedStatustoServer()
        {
            try
            {
                Device.BeginInvokeOnMainThread(async () =>
                {
                    UserDialogs.Instance.ShowLoading();
                    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                    if (isNetworkAvailable)
                    {
                        List<ResultResponseData> _tempitemSource = new List<ResultResponseData>();
                        ResultRequestModel ResultRequestModel = new ResultRequestModel()
                        {
                            testpin = _TestPinMasterData.testpin,
                            login_audit_id = _TestPinMasterData.login_audit_id,
                            assign_id = int.Parse(_TestPinMasterData.assign_id)
                        };
                        var result = await _commonservice.PostAsync<ResultResponse, ResultRequestModel>(APIData.API_BASE_URL + APIMethods.GetScore, ResultRequestModel);

                        if (result != null)
                        {
                            UserDialogs.Instance.HideLoading();

                            if (result.code == "200")
                            {


                                if (_TestPinMasterData.is_feedback == Convert.ToString((int)is_feedback.Enable))
                                {
                                    Application.Current.MainPage = new NavigationPage(new PRO_ExamFeedbackPage(result));
                                    return;
                                }
                                else
                                {
                                    Application.Current.MainPage = new NavigationPage(new PRO_ExamCompletedPage(result));
                                    return;
                                }

                            }
                            else if (result.code == "199")
                            {

                                await UserDialogs.Instance.AlertAsync(result.message);
                                Application.Current.MainPage = new NavigationPage(new PRO_TestPinPage());
                            }
                            else
                            {

                                await UserDialogs.Instance.AlertAsync(result.message);
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                            var dialogResult = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.ServerBusyMessage, null, "Yes", "No");
                            //if (dialogResult)
                            //{

                            //    ShowSectionScoreList();
                            //}
                            // await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        //IsShowScoreDetails = false;
                        //IsShowNoScoreViewVisible = true;
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                    }
                });
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "PRO_ExamCompletedViewModel.ShowCompanyList");
            }
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        #region Command Operation
        private async void DoOperation(string obj)
        {
            switch (obj)
            {


                case "tpgShowCameraPreviewCommand":
                    if (isClicked)
                    {
                        isClicked = false;
                        if (IsShowCameraPreView == true)
                        {
                            ArrowChange = (string)Application.Current.Resources["DownArrowIcon"];
                            IsShowCameraPreView = false;
                        }
                        else if (IsShowCameraPreView == false)
                        {
                            ArrowChange = (string)Application.Current.Resources["UpArrowIcon"];
                            IsShowCameraPreView = true;
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;

                case "FinishTheExam":
                    if (isClicked)
                    {
                        isClicked = false;
                        var result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.FinishAlertAssessment, null, "Yes", "No");
                        if (result)
                        {
                            UpdateExamCompletedStatustoServer();

                            //if (_TestPinMasterData.is_feedback == Convert.ToString((int)is_feedback.Enable))
                            //{
                            //    Application.Current.MainPage = new NavigationPage(new PRO_ExamFeedbackPage());
                            //    return;
                            //}
                            //else
                            //{
                            //    Application.Current.MainPage = new NavigationPage(new PRO_ExamCompletedPage());
                            //    return;
                            //}
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;

                case "OnMoreClicked":
                    if (lblMore == "more...")
                    {
                        SyllabusName = SyllabusName_substring;
                        lblMore = "less...";
                    }
                    else if (lblMore == "less...")
                    {
                        if (SyllabusName.Length >= 100)
                        {
                            SyllabusName_substring = SyllabusName;
                            string str = SyllabusName.Substring(0, 99);
                            SyllabusName = str;
                            lblMore = "more...";
                        }
                    }
                    break;


                #region iconselect Button Click Event
                case "iconselect":
                    if (isClicked)
                    {
                        isClicked = false;

                        await PopupNavigation.PushAsync(new PRO_PoupExamInstructionPage(false));
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                    break;
                    #endregion


            }
        }
        #endregion

        #region FullProperties

        private String testPicture;
        public String TestPicture
        {
            get { return testPicture; }
            set { testPicture = value; OnPropertyChanged(); }
        }

        private String _pro_AssesmentProfilePicture;
        public String PRO_AssesmentProfilePicture
        {
            get { return _pro_AssesmentProfilePicture; }
            set { _pro_AssesmentProfilePicture = value; OnPropertyChanged(); }
        }

        private string _companyName;
        public string CompanyName
        {
            get { return _companyName; }
            set { _companyName = value; OnPropertyChanged(); }
        }

        private String timerText;
        public String TimerText
        {
            get { return timerText; }
            set { timerText = value; OnPropertyChanged(); }
        }

        private string _ExamName;
        public string ExamName
        {
            get { return _ExamName; }
            set { _ExamName = value; OnPropertyChanged(); }
        }



        private String _SyllabusName_substring;
        public String SyllabusName_substring
        {
            get { return _SyllabusName_substring; }
            set { _SyllabusName_substring = value; OnPropertyChanged(); }
        }
        private String _lblMore;
        public String lblMore
        {
            get { return _lblMore; }
            set { _lblMore = value; OnPropertyChanged(); }
        }

        private String _syllabusName;
        public String SyllabusName
        {
            get { return   _syllabusName; }
            set { _syllabusName = value; OnPropertyChanged(); }
        }
        private String totalDuration;
        public String TotalDuration
        {
            get { return totalDuration; }
            set { totalDuration = "Duration :" + value; OnPropertyChanged(); }
        }

        private string _arrowChange;
        public string ArrowChange
        {
            get { return _arrowChange; }
            set { _arrowChange = value; OnPropertyChanged(); }
        }
        private bool _IsShowCameraPreView;
        public bool IsShowCameraPreView
        {
            get { return _IsShowCameraPreView; }
            set { _IsShowCameraPreView = value; OnPropertyChanged(); }
        }
        private bool _IsVisibleFinishButton;
        public bool IsVisibleFinishButton
        {
            get { return _IsVisibleFinishButton; }
            set { _IsVisibleFinishButton = value; OnPropertyChanged(); }
        }

        private bool _IsShowUserProfileView;
        public bool IsShowUserProfileView
        {
            get { return _IsShowUserProfileView; }
            set { _IsShowUserProfileView = value; OnPropertyChanged(); }
        }

        private String candidateName;
        public String CandidateName
        {
            get { return candidateName; }
            set { candidateName = "Name : " + value; OnPropertyChanged(); }
        }
        private String candidateHireMeeID;
        public String CandidateHireMeeID
        {
            get { return candidateHireMeeID; }
            set { candidateHireMeeID = value; OnPropertyChanged(); }
        }

        private Boolean isShowIOSOnly;
        public Boolean IsShowIOSOnly
        {
            get { return isShowIOSOnly; }
            set { isShowIOSOnly = value; OnPropertyChanged(); }
        }

        private string _profilepic = (string)Application.Current.Resources["IconUser"];

        public string profilepic
        {
            get { return _profilepic; }
            set { _profilepic = value; OnPropertyChanged(); }
        }

        #endregion
    }
}

