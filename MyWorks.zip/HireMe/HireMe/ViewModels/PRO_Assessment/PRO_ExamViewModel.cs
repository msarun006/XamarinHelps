﻿using MvvmHelpers;
using System;
using GalaSoft.MvvmLight.Command;
using System.Windows.Input;
using Xamarin.Forms;
using Acr.UserDialogs;
using System.Threading;
using HireMe.Views.Assessment;
using Plugin.Connectivity;
using Rg.Plugins.Popup.Services;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using HireMe.LocalDataBase;
using System.Diagnostics;
using HireMe.Helpers;
using System.Text.RegularExpressions;
using HireMe.Views.PRO_Assessment;
using HireMe.Models.PRO_Assessment;
using System.Collections.ObjectModel;
using HireMee.Models.PRO_Assessment;
using Newtonsoft.Json;

namespace HireMe.ViewModels.PRO_Assessment
{
    public class PRO_ExamViewModel : BaseViewModel
    {
        #region Variable Declaration
        public LocalDB _localDB;
        public INavigation NavigationService { get; set; }
        public ICommand OnCommand { get; set; }
        private string selectedSubQuestionId { get; set; } = string.Empty;
        public ICommand OnLikerButtonCommand { get; set; }

        private AssignedAssessmentDetails _TestPinMasterData;
        private HttpCommonService _commonservice { get; set; }
        public bool isClicked = true;

        public ExamQuestions _questiondata { get; set; }
        private string selectedOptionId { get; set; }
        private int ElapsedSeconds { get; set; }

        private string selectedOption { get; set; }
        private string selectedBehaviouralQuestion { get; set; }


        private string SelectedSectionID;
        private int  SectionCurrentIndex= 0;
        private int SectionLastIndex = 0;
        List<Exam_Sub_Questions> SubQuestionList;         List<Exam_Question_Options> SubQuestionOptionsList;

        private string optionA_ID;
        private string optionB_ID;
        private string optionC_ID;
        private string optionD_ID;
        private string optionE_ID;
        private string optionF_ID;

        #region Liker SubQuestion & OptionID Declaration

        private string LikerSubQuestion1_ID { get; set; }
        private string LikerSubQuestion2_ID { get; set; }
        private string LikerSubQuestion3_ID { get; set; }
        private string LikerSubQuestion4_ID { get; set; }
        private string LikerSubQuestion5_ID { get; set; }
        private string LikerSubQuestion6_ID { get; set; }




        private string LikerOptionQ1A_ID { get; set; }
        private string LikerOptionQ1B_ID { get; set; }
        private string LikerOptionQ1C_ID { get; set; }
        private string LikerOptionQ1D_ID { get; set; }
        private string LikerOptionQ1E_ID { get; set; }
        private string LikerOptionQ1F_ID { get; set; }


        private string LikerOptionQ2A_ID { get; set; }
        private string LikerOptionQ2B_ID { get; set; }
        private string LikerOptionQ2C_ID { get; set; }
        private string LikerOptionQ2D_ID { get; set; }
        private string LikerOptionQ2E_ID { get; set; }
        private string LikerOptionQ2F_ID { get; set; }


        private string LikerOptionQ3A_ID { get; set; }
        private string LikerOptionQ3B_ID { get; set; }
        private string LikerOptionQ3C_ID { get; set; }
        private string LikerOptionQ3D_ID { get; set; }
        private string LikerOptionQ3E_ID { get; set; }
        private string LikerOptionQ3F_ID { get; set; }

        private string LikerOptionQ4A_ID { get; set; }
        private string LikerOptionQ4B_ID { get; set; }
        private string LikerOptionQ4C_ID { get; set; }
        private string LikerOptionQ4D_ID { get; set; }
        private string LikerOptionQ4E_ID { get; set; }
        private string LikerOptionQ4F_ID { get; set; }


        private string LikerOptionQ5A_ID { get; set; }
        private string LikerOptionQ5B_ID { get; set; }
        private string LikerOptionQ5C_ID { get; set; }
        private string LikerOptionQ5D_ID { get; set; }
        private string LikerOptionQ5E_ID { get; set; }
        private string LikerOptionQ5F_ID { get; set; }


        private string LikerOptionQ6A_ID { get; set; }
        private string LikerOptionQ6B_ID { get; set; }
        private string LikerOptionQ6C_ID { get; set; }
        private string LikerOptionQ6D_ID { get; set; }
        private string LikerOptionQ6E_ID { get; set; }
        private string LikerOptionQ6F_ID { get; set; }
        #endregion

        private string IsCheckedOptionA = string.Empty;
        private string IsCheckedOptionB = string.Empty;
        private string IsCheckedOptionC = string.Empty;
        private string IsCheckedOptionD = string.Empty;
        private string IsCheckedOptionE = string.Empty;
        private string IsCheckedOptionF = string.Empty;

        public string UpdateEventLogTimer = "00:00:00";

        TimeSpan _Examtime;
        TimeSpan _ServerTime = new TimeSpan();
        CancellationTokenSource cancellationTokenSource;
        #endregion

        #region Constructor
        public PRO_ExamViewModel(INavigation navigation, StackLayout dynamicBtnStack,  SectionInstructionContent content)
        {
            _TestPinMasterData = AppPreferences.TestPinMasterData;
            Constant.heartbeatlogRunning = true;
            AppPreferences.Is_NavigationLog = true;
            cancellationTokenSource = new CancellationTokenSource();            
            _commonservice = new HttpCommonService();
            OnCommand = new RelayCommand<string>(DoOperation);
            OnLikerButtonCommand = new Command(DoLikerAnswer);
            _localDB = new LocalDB();
           
            IsVisibleNormalQuestions = false;
            IsVisibleLikerQuestions = false;
            IsVisiblePsychometricView = false;
            
            CurrentPosition = 0;
            CurrentQue = CurrentPosition + 1;
            SectionCurrentIndex = SectionCurrentIndex + 1;
            SectionCurrentQue = CurrentPosition;
            if (!string.IsNullOrEmpty(_TestPinMasterData.is_endtest))
            {
                if (_TestPinMasterData.is_endtest == Convert.ToString((int)is_endtest.Enable))
                {
                    IsVisibleFinishButton = true;
                }
                else
                {
                    IsVisibleFinishButton = false;
                }
            }

            if (content != null)
            {
                IsVisibleSectionName = true;
                SelectedSectionID = content.section_id;
                SectionName = content.name;
                lastindex = Convert.ToInt32(content.section_count);
                if (_TestPinMasterData.duration_type == Convert.ToString((int)duration_type.ExamDuration))
                {
                    if (!string.IsNullOrEmpty(_TestPinMasterData.exam_duration))
                    {
                        TimeSpan examduration = TimeSpan.FromMinutes(Convert.ToDouble(_TestPinMasterData.exam_duration));
                        TotalDuration = string.Format("{0:00}:{1:00}:{2:00}", examduration.Hours, examduration.Minutes, examduration.Seconds);
                    }
                    else
                    {
                        TotalDuration = "00:00:00";
                    }
                }
                else if (_TestPinMasterData.duration_type == Convert.ToString((int)duration_type.SectionDuration))
                {
                    if (!string.IsNullOrEmpty(content.section_duration))
                    {
                        TimeSpan examduration = TimeSpan.FromMinutes(Convert.ToDouble(content.section_duration));
                        TotalDuration = string.Format("{0:00}:{1:00}:{2:00}", examduration.Hours, examduration.Minutes, examduration.Seconds);
                    }
                    else
                    {
                        TotalDuration = "00:00:00";
                    }
                }
            }
            else
            {
                IsVisibleSectionName = true;
                tbl_timer sectionDetails;
                var data = _localDB.GetAllPROSectionTimerList();
                if (!string.IsNullOrEmpty(AppPreferences.LastUpdatedSectionID))
                {
                    
                    SelectedSectionID = AppPreferences.LastUpdatedSectionID;
                    sectionDetails = _localDB.GetPROSectionTimerBySectionID(SelectedSectionID);
                    SectionCurrentIndex = sectionDetails.ID;
                }
                else
                {
                    sectionDetails = _localDB.GetPROSectionDetailsByID(SectionCurrentIndex);
                    SelectedSectionID = sectionDetails.section_id;
                    AppPreferences.LastUpdatedSectionID = SelectedSectionID;
                }
                SectionName = sectionDetails.sectionname;

                if (_TestPinMasterData.duration_type == Convert.ToString((int)duration_type.SectionDuration))
                {
                    SetSectoinDuration(sectionDetails);
                    //if (!string.IsNullOrEmpty(sectionDetails.section_duration))
                    //    {
                    //        TimeSpan examduration = TimeSpan.FromMinutes(Convert.ToDouble(sectionDetails.section_duration));
                    //        TotalDuration = string.Format("{0:00}:{1:00}:{2:00}", examduration.Hours, examduration.Minutes, examduration.Seconds);
                    //    }
                    //    else
                    //    {
                    //        TotalDuration = "00:00:00";
                    //    }
                }
                else
                {
                    if (_TestPinMasterData.duration_type == Convert.ToString((int)duration_type.ExamDuration))
                    {
                        if (!string.IsNullOrEmpty(_TestPinMasterData.exam_duration))
                        {
                            TimeSpan examduration = TimeSpan.FromMinutes(Convert.ToDouble(_TestPinMasterData.exam_duration));
                            TotalDuration = string.Format("{0:00}:{1:00}:{2:00}", examduration.Hours, examduration.Minutes, examduration.Seconds);
                        }
                        else
                        {
                            TotalDuration = "00:00:00";
                        }
                    }
                }
            }

            if (Device.RuntimePlatform == Device.iOS)
            {
                IsShowIOSOnly = true;
            }
            else
            {
                IsShowIOSOnly = false;
            }
            NavigationService = navigation;
            DynamicBtnStack = dynamicBtnStack;
           // DynamciButtonScrollView = dynamicBtnScroll;
            ArrowChange = (string)Application.Current.Resources["UpArrowIcon"];
            CandidateName = _TestPinMasterData.first_name + _TestPinMasterData.last_name;
            CandidateSyllabus = _TestPinMasterData.syllabus;
            CandidateAssessmentName = _TestPinMasterData.assessment_name;
            CompanyName = AppPreferences.PRO_CompanyName;
            TestPicture = TestPicture = AppPreferences.PRO_TestLogo;
            if (String.IsNullOrEmpty(TestPicture))
            {
                TestPicture = "hiremee_assessment_icon.png";
            }
            IsShowUserProfile = true;
            _questiondata = new ExamQuestions();
            ButtonColorNotVisited = Color.FromHex("#ebebeb");
            ButtonColorAnswerwed = Color.Green;
            ButtonColorNotAnswerwed = Color.Red;
            LoadQuestions(true);
            GeneratePageNumbers();
            TimerText = "00:00:00";
            _Examtime = new TimeSpan();
             TimerStart();
            LoadButtonColorFromCunstructorCall();
            _localDB.UpdateSectionStatusBySectionid(SelectedSectionID,"P", AppPreferences.ServerUpdatedDateTime);
            AllSectionCompltedInternallShowEndTestButton();
            HeartBigLogAPICall();
        }

        private void HeartBigLogAPICall()
        {
            Device.StartTimer(TimeSpan.FromSeconds(30), () =>
            {
                if (AppPreferences.IsPRO_Assesment_TimerRunning == true && Constant.heartbeatlogRunning == true)
                {
                    Heartbeatlog();
                }
                return true; // True = Repeat again, False = Stop the timer
            });
        }
        #endregion

        #region LoadButton Collor From Constructor Call
        private void LoadButtonColorFromCunstructorCall()
        {
            try
            {
                int Count = 1;
                string answerType = string.Empty;
                foreach (var obj in ListViewItemSource)
                {
                    // var obj = _localDB.GetQuestion_Palette_Enum_Id(item.id);
                    //foreach (var obj in resultCheckAnswer)
                    //{
                    if (obj.question_palette_enum_Id == Convert.ToString((int)Question_Palette_Enum_Id.Answered))
                    {
                        answerType = "Answered";
                    }
                    if (obj.question_palette_enum_Id == Convert.ToString((int)Question_Palette_Enum_Id.NotViewed))
                    {
                        answerType = "NotVisited";
                    }
                    if (obj.question_palette_enum_Id == Convert.ToString((int)Question_Palette_Enum_Id.NotAnswered))
                    {
                        answerType = "NotAnswered";
                    }
                    string[] value = { Count.ToString(), answerType };
                    LoadButtonColorIfAlreadyExamComplete(value);

                    //}
                    Count++;
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "PROPRO_ExamViewModel.LoadButtonColorFromCunstructorCall");
            }
        }
        #endregion

        #region LoadQuestions
        public async void LoadQuestions(bool IsConstructor)
        {
            try
            {
                if (_questiondata != null)
                {
                    List<ExamQuestions> data = new List<ExamQuestions>();
                    List<ExamQuestions> sectiondata = new List<ExamQuestions>();

                    if (_TestPinMasterData.is_section_navigation == Convert.ToString((int)is_section_navigation.Enable))
                     {
                        data = _localDB.GetPROQuestionListBySectionID(Convert.ToInt32(SelectedSectionID));
                        lastindex = data.Count();
                        SectionLastIndex = lastindex;
                    }
                     else
                     {
                            data = _localDB.GetAllPROQuestionList();
                            sectiondata = _localDB.GetPROQuestionListBySectionID(Convert.ToInt32(SelectedSectionID));
                            SectionLastIndex = sectiondata.Count;
                            lastindex = data.Count();
                    }
                    ListViewItemSource = new List<ExamQuestions>(data);
                    if (IsConstructor)
                    {
                        CurrentPosition = data.FindIndex(x => x.resume_point == "1");
                        if (CurrentPosition == -1)
                        {
                            CurrentPosition = 0;
                        }
                        CurrentQue = CurrentPosition + 1;
                        SectionCurrentPosition = sectiondata.FindIndex(x => x.resume_point == "1");
                        if (SectionCurrentPosition == -1)
                        {
                            SectionCurrentPosition = 0;
                        }
                        SectionCurrentQue = SectionCurrentPosition + 1;
                    }

                    if (_TestPinMasterData.is_section_navigation == Convert.ToString((int)is_section_navigation.Enable))
                    {
                        SectionCurrentQue = CurrentQue;
                    }

                    if (CurrentQue >= lastindex)
                    {
                        CurrentQue = lastindex;
                        CurrentPosition = CurrentQue - 1;
                    }

                  

                    ShowPreviousandNextButton();
                     if(CurrentQue <= 1)
                     {
                        Ispreviousbtn = false;
                     }

                    _questiondata = ListViewItemSource.ElementAt(CurrentPosition);


                    if (_TestPinMasterData.duration_type == Convert.ToString((int)duration_type.ExamDuration))
                    {
                        LblCurrentQuestion = CurrentQue + " of " + lastindex;
                        QuestionNumber = "(" + CurrentQue + ")";
                    }
                    else if (_TestPinMasterData.duration_type == Convert.ToString((int)duration_type.SectionDuration))
                    {
                        LblCurrentQuestion = SectionCurrentQue + " of " + SectionLastIndex;
                        QuestionNumber = "(" + SectionCurrentQue + ")";
                    }
                     if (_questiondata.question_type == Convert.ToString((int)question_type.likert))
                    {
                        QuestionNumber = CurrentQue.ToString() + ". ";
                    }
                    //else if (_TestPinMasterData.duration_type == Convert.ToString((int)duration_type.ExamDuration))
                    //{
                    //    QuestionNumber = "(" + CurrentQue + ")";
                    //}
                    //else
                    //{
                    //    QuestionNumber = "(" + SectionCurrentQue + ")";
                    //}

                    if (_questiondata.question_type == Convert.ToString((int)question_type.MCQ)
                    || _questiondata.question_type == Convert.ToString((int)question_type.Situation_Reaction))
                    {
                        NormalQuestionConfiguration();
                    }
                    else if (_questiondata.question_type == Convert.ToString((int)question_type.Behaviour) && _questiondata.is_question_mandatory == "0")
                    {
                        BehaviouralQuestionConfigurationAsync();
                    }
                    else if (_questiondata.question_type == Convert.ToString((int)question_type.Behaviour) && _questiondata.is_question_mandatory == "1")
                    {
                        LikertQuestionConfiguration();
                    }else if(_questiondata.question_type == Convert.ToString((int)question_type.likert) && _questiondata.is_question_mandatory == "0")
                    {
                        LikertQuestionConfiguration();
                    }
                }
            }
            catch (Exception e)
            {
               // await UserDialogs.Instance.AlertAsync(e.Message.ToString());
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "PRO_ExamViewModel.LoadQuestions");
            }
        }
        #endregion

        #region LoadBehavioural Quesiton         private async Task BehaviouralQuestionConfigurationAsync()         {              try             {
                IsVisibleLikerQuestions = false;
                IsVisiblePsychometricView = true;
                IsVisibleNormalQuestions = false;
                                 selectedBehaviouralQuestion = string.Empty;                 int QuestionID =  _questiondata.id;                 selectedOptionId = string.Empty;                 selectedSubQuestionId = "0";                 SubQuestionList = _localDB.GetSubQuestionsByQuestionId(QuestionID);                  if (SubQuestionList != null && SubQuestionList.Count == 2)                 {                      SubQuestionOptionsList = _localDB.GetPRO_OptionListBySubQuestionID(QuestionID.ToString(), "0");                      Question = Regex.Replace(Regex.Replace(_questiondata.question.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty).Replace("<strong>", string.Empty).Replace("</strong>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);                    // PsySubQuestion1 = Regex.Replace(Regex.Replace(SubQuestionList[0].sub_question.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty).Replace("<strong>", string.Empty).Replace("</strong>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);

                    PsySubQuestion1 = SubQuestionList[0].sub_question.Replace("\n", string.Empty);                   //PsySubQuestion2 = Regex.Replace(Regex.Replace(SubQuestionList[1].sub_question.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty).Replace("<strong>", string.Empty).Replace("</strong>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);                     PsySubQuestion2 = SubQuestionList[1].sub_question.Replace("\n", string.Empty);                       PsyFAQuestion1 = (string)Application.Current.Resources["RadioButtonIcon"];                     PsyFAQuestion2 = (string)Application.Current.Resources["RadioButtonIcon"];                       OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                     OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                     OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                     OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                     OptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                      QuestionOneRadioColor = Color.Black;                     QuestionTwoRadioColor = Color.Black;                     QuestionOneTextColor = Color.Black;                     QuestionTwoTextColor = Color.Black;

                    IsVisible_PsyOptionA = false;
                    IsVisible_PsyOptionB = false;
                    IsVisible_PsyOptionC = false;
                    IsVisible_PsyOptionD = false;
                    IsVisible_PsyOptionE = false;                      if (SubQuestionOptionsList != null && SubQuestionOptionsList.Count >0)                     {
                        if(SubQuestionOptionsList.Count>=1)
                        {
                           //PsyOptionA = StripHTML(SubQuestionOptionsList[0].options);
                            PsyOptionA = SubQuestionOptionsList[0].options.Replace("\n", string.Empty);
                            IsVisible_PsyOptionA = true;
                        }
                        if (SubQuestionOptionsList.Count >= 2)
                        {
                            // PsyOptionB = StripHTML(SubQuestionOptionsList[1].options);
                            PsyOptionB = SubQuestionOptionsList[1].options.Replace("\n", string.Empty);
                            IsVisible_PsyOptionB = true;
                        }
                        if (SubQuestionOptionsList.Count >= 3)
                        {    // PsyOptionC = StripHTML(SubQuestionOptionsList[2].options);
                            PsyOptionC = SubQuestionOptionsList[2].options.Replace("\n", string.Empty);
                            IsVisible_PsyOptionC = true;
                        }
                        if (SubQuestionOptionsList.Count >= 4)
                        {
                           // PsyOptionD = StripHTML(SubQuestionOptionsList[3].options);
                            PsyOptionD =SubQuestionOptionsList[3].options.Replace("\n", string.Empty);
                            IsVisible_PsyOptionD = true;
                       }
                        if (SubQuestionOptionsList.Count >= 5)
                        {
                            //PsyOptionE = StripHTML(SubQuestionOptionsList[4].options);
                            PsyOptionE = SubQuestionOptionsList[4].options.Replace("\n", string.Empty); 
                            IsVisible_PsyOptionE = true;
                        }
                      }                      var AnswerData = _localDB.GetAssessmentAnswersByQuestionID(_questiondata.id);                     if (AnswerData != null && AnswerData.Count >= 1)                     {                         for (int i = 0; i < AnswerData.Count; i++)                         {                             if (AnswerData[i].exam_answer != null && AnswerData[i].exam_answer != "0")                             {
                                //var index = SubQuestionList.Find()                                 if ( AnswerData[i].sub_question_id == SubQuestionList[0].subquestion_id)                                 {                                     PsyFAQuestion1 = (string)Application.Current.Resources["DotCheckedRadioButton"];                                 }                                 else if (AnswerData[i].sub_question_id == SubQuestionList[1].subquestion_id)                                 {                                     PsyFAQuestion2 = (string)Application.Current.Resources["DotCheckedRadioButton"];                                 }
                                 if (SubQuestionOptionsList[0].id == AnswerData[i].exam_answer && SubQuestionOptionsList.Count >= 1)                                 {                                     OptionARadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedBehaviouralQuestion = "AlreadySelected";
                                    selectedSubQuestionId = AnswerData[i].sub_question_id;                                     selectedOptionId = AnswerData[i].exam_answer;                                     break;                                 }                                 else if (SubQuestionOptionsList[1].id == AnswerData[i].exam_answer && SubQuestionOptionsList.Count >= 2)                                 {                                     OptionBRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedBehaviouralQuestion = "AlreadySelected";
                                    selectedSubQuestionId = AnswerData[i].sub_question_id;                                     selectedOptionId = AnswerData[i].exam_answer;                                     break;                                 }                                 else if (SubQuestionOptionsList[2].id == AnswerData[i].exam_answer && SubQuestionOptionsList.Count >= 3)                                 {                                     OptionCRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedBehaviouralQuestion = "AlreadySelected";
                                    selectedSubQuestionId = AnswerData[i].sub_question_id;                                     selectedOptionId = AnswerData[i].exam_answer;                                     break;                                 }                                 else if (SubQuestionOptionsList[3].id == AnswerData[i].exam_answer && SubQuestionOptionsList.Count >= 4)                                 {                                     OptionDRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];                                     selectedBehaviouralQuestion = "AlreadySelected";
                                    selectedSubQuestionId = AnswerData[i].sub_question_id;                                     selectedOptionId = AnswerData[i].exam_answer;                                     break;                                 }                                 else if (SubQuestionOptionsList[4].id == AnswerData[i].exam_answer && SubQuestionOptionsList.Count >= 5)                                 {                                     OptionERadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedBehaviouralQuestion = "AlreadySelected";
                                    selectedSubQuestionId = AnswerData[i].sub_question_id;                                     selectedOptionId = AnswerData[i].exam_answer;                                     break;                                 }                             }                         }                     }
                                     }
                else
                {
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.insufficientQuestion);
                }             }             catch (Exception e)             {                 System.Diagnostics.Debug.WriteLine(e.Message);                 SendErrorMessageToServer(e, "PRO_ExamViewModel.LikertQuestionConfiguration");             }         }
        #endregion

        #region Load Question Normal
        private async void NormalQuestionConfiguration()
        {
            try
            {
                IsVisibleLikerQuestions = false;
                IsVisiblePsychometricView = false;
                IsVisibleNormalQuestions = true;

                IsQueImageOptionA = false;
                IsQueContentOptionA = false;
                IsQueImageOptionB = false;
                IsQueContentOptionB = false;
                IsQueImageOptionC = false;
                IsQueContentOptionC = false;
                IsQueImageOptionD = false;
                IsQueContentOptionD = false;
                IsQueImageOptionE = false;
                IsQueContentOptionE = false;
                IsQueImageOptionF = false;
                IsQueContentOptionF = false;

                IsQueImage = false;
                IsQueContent = false;

                selectedOptionId = string.Empty;

                IsCheckedOptionA = string.Empty;
                IsCheckedOptionB = string.Empty;
                IsCheckedOptionC = string.Empty;
                IsCheckedOptionD = string.Empty;
                IsCheckedOptionE = string.Empty;
                IsCheckedOptionF = string.Empty;

                if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Single_Slection))
                {
                    OptionA_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionB_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionC_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionD_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionE_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                    OptionF_Button = (string)Application.Current.Resources["RadioButtonIcon"];

                }
                if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Multi_Slection))
                {
                    OptionA_Button = (string)Application.Current.Resources["CheckBoxUnSelected"];
                    OptionB_Button = (string)Application.Current.Resources["CheckBoxUnSelected"];
                    OptionC_Button = (string)Application.Current.Resources["CheckBoxUnSelected"];
                    OptionD_Button = (string)Application.Current.Resources["CheckBoxUnSelected"];
                    OptionE_Button = (string)Application.Current.Resources["CheckBoxUnSelected"];
                    OptionF_Button = (string)Application.Current.Resources["CheckBoxUnSelected"];
                }

                #region Question
                if (string.IsNullOrEmpty(_questiondata.question))
                {
                    IsQueImage = false;
                    IsQueContent = false;
                }
                else if ((_questiondata.question.ToLower().Contains(".jpg") || _questiondata.question.ToLower().Contains(".jpeg") || _questiondata.question.ToLower().Contains(".png") || _questiondata.question.ToLower().Contains("gif")) && (Device.RuntimePlatform == Device.Android || Device.RuntimePlatform == Device.iOS))
                {
                    IsQueImage = true;
                    IsQueContent = false;
                    Question = _questiondata.question.Replace("\n", string.Empty);
                }
                else
                {
                    IsQueImage = false;
                    IsQueContent = true;
                    //  Question = Regex.Replace(Regex.Replace(_questiondata.question.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                    Question = _questiondata.question.Replace("\n", string.Empty);
                }
                #endregion

                #region  MCQ Answer Option List
                var answerData = _localDB.GetExamAnswerBasedOnQuestionId(_questiondata.id.ToString());
                List<string> selectedOpionList = new List<string>();
                if (answerData != null && !string.IsNullOrEmpty(answerData.exam_answer) && answerData.exam_answer != "0")
                {
                    string[] selectedOpionArray = answerData.exam_answer.Split(',');
                    selectedOpionList = new List<string>(selectedOpionArray.Length);
                    selectedOpionList.AddRange(selectedOpionArray);
                    selectedOpionList.Reverse();
                }
                #endregion

                var options = _localDB.GetPROOptionListByQuestionID(_questiondata.id);
                if (options != null)
                {
                    #region Option A

                    if (options.Count() < 1 || string.IsNullOrEmpty(options[0].options))
                    {
                        IsQueImageOptionA = false;
                        IsQueContentOptionA = false;
                    }
                    else if ((options[0].options.ToLower().Contains(".jpg") || options[0].options.ToLower().Contains(".jpeg") || options[0].options.ToLower().ToLower().Contains(".png") || options[0].options.ToLower().Contains("gif")) && (Device.RuntimePlatform == Device.Android || Device.RuntimePlatform == Device.iOS))
                    {
                        IsQueImageOptionA = true;
                        IsQueContentOptionA = false;
                        optionA_ID = options[0].id.ToString();
                        OptionA = options[0].options.Replace("\n", string.Empty);
                    }
                    else
                    {
                        IsQueImageOptionA = false;
                        IsQueContentOptionA = true;
                        optionA_ID = options[0].id.ToString();
                        //  OptionA = Regex.Replace(Regex.Replace(options[0].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                        // OptionA = StripHTML(options[0].options);
                        OptionA = options[0].options.Replace("\n", string.Empty);
                    }

                    if (!string.IsNullOrEmpty(optionA_ID))
                    {
                        if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Single_Slection) && answerData.exam_answer == optionA_ID.ToString())
                        {
                            OptionA_Button = (string)Application.Current.Resources["DotCheckedRadioButton"];
                            selectedOptionId = optionA_ID.ToString();
                        }
                        else if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Multi_Slection) && selectedOpionList.Count() != 0)
                        {
                            //show selected option check a check box
                            if (selectedOpionList.Contains(optionA_ID.ToString()))
                            {
                                OptionA_Button = (string)Application.Current.Resources["CheckBoxSelected"];
                                IsCheckedOptionA = optionA_ID.ToString();
                            }
                            else
                            {
                                OptionA_Button = (string)Application.Current.Resources["CheckBoxUnSelected"];
                                IsCheckedOptionA = string.Empty;
                            }
                        }
                    }

                    #endregion

                    #region Option B
                    if (options.Count() < 2 || string.IsNullOrEmpty(options[1].options))
                    {
                        IsQueImageOptionB = false;
                        IsQueContentOptionB = false;
                    }
                    else if ((options[1].options.ToLower().Contains(".jpg") || options[1].options.ToLower().Contains(".jpeg") || options[1].options.ToLower().Contains(".png") || options[1].options.ToLower().Contains("gif")) && (Device.RuntimePlatform == Device.Android || Device.RuntimePlatform == Device.iOS))
                    {
                        IsQueImageOptionB = true;
                        IsQueContentOptionB = false;
                        optionB_ID = options[1].id.ToString();
                        OptionB = options[1].options.Replace("\n", string.Empty);
                    }
                    else
                    {
                        IsQueImageOptionB = false;
                        IsQueContentOptionB = true;
                        optionB_ID = options[1].id.ToString();
                      //  OptionB = Regex.Replace(Regex.Replace(options[1].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                      //   OptionB = StripHTML(options[1].options);
                        OptionB = options[1].options.Replace("\n", string.Empty);

                    }

                    if (!string.IsNullOrEmpty(optionB_ID))
                    {
                        if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Single_Slection) && answerData.exam_answer == optionB_ID.ToString())
                        {

                            OptionB_Button = (string)Application.Current.Resources["DotCheckedRadioButton"];
                            selectedOptionId = optionB_ID.ToString();

                        }
                        else if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Multi_Slection) && selectedOpionList.Count() != 0)
                        {
                            //show selected option check a check box
                            if (selectedOpionList.Contains(optionB_ID.ToString()))
                            {
                                OptionB_Button = (string)Application.Current.Resources["CheckBoxSelected"];
                                IsCheckedOptionA = optionB_ID.ToString();

                            }
                            else
                            {
                                OptionB_Button = (string)Application.Current.Resources["CheckBoxUnSelected"];
                                IsCheckedOptionB = string.Empty;
                            }
                        }
                    }


                    #endregion

                    #region Option C
                    if (options.Count() < 3 || string.IsNullOrEmpty(options[2].options))
                    {
                        IsQueImageOptionC = false;
                        IsQueContentOptionC = false;
                    }
                    else if ((options[2].options.ToLower().Contains(".jpg") || options[2].options.ToLower().Contains(".jpeg") || options[2].options.ToLower().Contains(".png") || options[2].options.ToLower().Contains("gif")) && (Device.RuntimePlatform == Device.Android || Device.RuntimePlatform == Device.iOS))
                    {
                        IsQueImageOptionC = true;
                        IsQueContentOptionC = false;
                        optionC_ID = options[2].id;
                        OptionC = options[2].options.Replace("\n", string.Empty);
                    }
                    else
                    {
                        IsQueImageOptionC = false;
                        IsQueContentOptionC = true;
                        optionC_ID = options[2].id;
                        // OptionC = Regex.Replace(Regex.Replace(options[2].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                        // OptionC = StripHTML(options[2].options);
                        OptionC =options[2].options.Replace("\n", string.Empty);

                    }

                    if (!string.IsNullOrEmpty(optionC_ID))
                    {
                        if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Single_Slection) && answerData.exam_answer == optionC_ID.ToString())
                        {

                            OptionC_Button = (string)Application.Current.Resources["DotCheckedRadioButton"];
                            selectedOptionId = optionC_ID.ToString();

                        }
                        else if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Multi_Slection) && selectedOpionList.Count() != 0)
                        {
                            //show selected option check a check box
                            if (selectedOpionList.Contains(optionC_ID.ToString()))
                            {
                                OptionC_Button = (string)Application.Current.Resources["CheckBoxSelected"];
                                IsCheckedOptionC = optionC_ID.ToString();

                            }
                            else
                            {
                                OptionC_Button = (string)Application.Current.Resources["CheckBoxUnSelected"];
                                IsCheckedOptionC = string.Empty;
                            }
                        }
                    }

                    #endregion

                    #region Option D
                    if (options.Count() < 4 || string.IsNullOrEmpty(options[3].options))
                    {
                        IsQueImageOptionD = false;
                        IsQueContentOptionD = false;
                    }
                    else if ((options[3].options.ToLower().Contains(".jpg") || options[3].options.ToLower().Contains(".jpeg") || options[3].options.ToLower().Contains(".png") || options[3].options.ToLower().Contains("gif")) && (Device.RuntimePlatform == Device.Android || Device.RuntimePlatform == Device.iOS))
                    {
                        IsQueImageOptionD = true;
                        IsQueContentOptionD = false;
                        optionD_ID = options[3].id.ToString();
                        OptionD = options[3].options.Replace("\n", string.Empty);
                    }
                    else
                    {
                        IsQueImageOptionD = false;
                        IsQueContentOptionD = true;
                        optionD_ID = options[3].id.ToString();
                        //  OptionD = Regex.Replace(Regex.Replace(options[3].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                      //  OptionD = StripHTML(options[3].options);
                        OptionD = options[3].options.Replace("\n", string.Empty);
                    }

                    if (!string.IsNullOrEmpty(optionD_ID))
                    {
                        if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Single_Slection) && answerData.exam_answer == optionD_ID.ToString())
                        {

                            OptionD_Button = (string)Application.Current.Resources["DotCheckedRadioButton"];
                            selectedOptionId = optionD_ID.ToString();

                        }
                        else if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Multi_Slection) && selectedOpionList.Count() != 0)
                        {
                            //show selected option check a check box
                            if (selectedOpionList.Contains(optionD_ID.ToString()))
                            {
                                OptionD_Button = (string)Application.Current.Resources["CheckBoxSelected"];
                                IsCheckedOptionC = optionD_ID.ToString();
                            }
                            else
                            {
                                OptionD_Button = (string)Application.Current.Resources["CheckBoxUnSelected"];
                                IsCheckedOptionD = string.Empty;
                            }
                        }
                    }

                    #endregion

                    #region Option E
                    if (options.Count() < 5 || string.IsNullOrEmpty(options[4].options))
                    {
                        IsQueImageOptionE = false;
                        IsQueContentOptionE = false;
                    }
                    else if ((options[4].options.ToLower().Contains(".jpg") || options[4].options.ToLower().Contains(".jpeg") || options[4].options.ToLower().Contains(".png") || options[4].options.ToLower().Contains("gif")) && (Device.RuntimePlatform == Device.Android || Device.RuntimePlatform == Device.iOS))
                    {
                        IsQueImageOptionE = true;
                        IsQueContentOptionE = false;
                        optionE_ID = options[4].id.ToString();
                        OptionE = options[4].options.Replace("\n", string.Empty);
                    }
                    else
                    {
                        IsQueImageOptionE = false;
                        IsQueContentOptionE = true;
                        optionE_ID = options[4].id.ToString();
                       // OptionE = Regex.Replace(Regex.Replace(options[4].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                        //OptionE = StripHTML(options[4].options);
                        OptionE = options[4].options.Replace("\n", string.Empty);
                    }

                    if (!string.IsNullOrEmpty(optionE_ID))
                    {

                        if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Single_Slection) && answerData.exam_answer == optionE_ID.ToString())
                        {

                            OptionE_Button = (string)Application.Current.Resources["DotCheckedRadioButton"];
                            selectedOptionId = optionE_ID.ToString();

                        }
                        else if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Multi_Slection) && selectedOpionList.Count() != 0)
                        {
                            //show selected option check a check box
                            if (selectedOpionList.Contains(optionE_ID.ToString()))
                            {
                                OptionE_Button = (string)Application.Current.Resources["CheckBoxSelected"];
                                IsCheckedOptionE = optionE_ID.ToString();
                            }
                            else
                            {
                                OptionE_Button = (string)Application.Current.Resources["CheckBoxUnSelected"];
                                IsCheckedOptionE = string.Empty;
                            }
                        }
                    }

                    #endregion

                    #region Option F
                    if (options.Count() < 6 || string.IsNullOrEmpty(options[5].options))
                    {
                        IsQueImageOptionF = false;
                        IsQueContentOptionF = false;
                    }
                    else if ((options[5].options.ToLower().Contains(".jpg") || options[5].options.ToLower().Contains(".jpeg") || options[5].options.ToLower().Contains(".png") || options[5].options.ToLower().Contains("gif")) && (Device.RuntimePlatform == Device.Android || Device.RuntimePlatform == Device.iOS))
                    {
                        IsQueImageOptionF = true;
                        IsQueContentOptionF = false;
                        optionF_ID = options[5].id.ToString();
                        OptionF = options[5].options.Replace("\n", string.Empty);
                    }
                    else
                    {
                        IsQueImageOptionF = false;
                        IsQueContentOptionF = true;
                        optionF_ID = options[5].id.ToString();
                       // OptionF = Regex.Replace(Regex.Replace(options[5].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                     //   OptionF = StripHTML(options[5].options);
                        OptionF = options[5].options.Replace("\n", string.Empty);
                    }

                    if (!string.IsNullOrEmpty(optionF_ID))
                    {
                        if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Single_Slection) && answerData.exam_answer == optionF_ID.ToString())
                    {

                        OptionF_Button = (string)Application.Current.Resources["DotCheckedRadioButton"];
                        selectedOptionId = optionF_ID.ToString();

                    }
                    else if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Multi_Slection) && selectedOpionList.Count() != 0)
                    {
                            //show selected option check a check box
                            if (selectedOpionList.Contains(optionF_ID.ToString()))
                            {
                                OptionF_Button = (string)Application.Current.Resources["CheckBoxSelected"];
                                IsCheckedOptionF = optionF_ID.ToString();
                            }
                            else
                            {
                                OptionF_Button = (string)Application.Current.Resources["CheckBoxUnSelected"];
                                IsCheckedOptionF = string.Empty;

                            }
                        }
                    }

                    #endregion
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "PROPRO_ExamViewModel.NormalQuestionConfiguration");
            }
        }
        #endregion

        public static string StripHTML(string input)
        {
            return Regex.Replace(input, "<.*?>", String.Empty).Replace("&nbsp", String.Empty);
        }

        #region Load Question Likert
        private void LikertQuestionConfiguration()
        {
            try
            {
                IsVisibleLikerQuestions = true;
                IsVisiblePsychometricView = false;
                IsVisibleNormalQuestions = false;

                #region Initialize Liker Option Radio Button
                LikerOptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionFRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];

                LikerOptionARadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionBRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionCRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionDRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionERadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionFRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];

                LikerOptionARadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionBRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionCRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionDRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionERadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionFRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];

                LikerOptionARadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionBRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionCRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionDRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionERadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionFRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];

                LikerOptionARadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionBRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionCRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionDRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionERadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionFRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];

                LikerOptionARadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionBRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionCRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionDRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionERadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                LikerOptionFRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];

                #endregion

                #region Questions & Option Visiblity




                IsVisible_LikerSubQuestion1 = false;
                IsVisible_LikerSubQuestion2 = false;
                IsVisible_LikerSubQuestion3 = false;
                IsVisible_LikerSubQuestion4 = false;
                IsVisible_LikerSubQuestion5 = false;
                IsVisible_LikerSubQuestion6 = false;


                IsVisible_Likert_SQ1_OptionA = false;
                IsVisible_Likert_SQ1_OptionB = false;
                IsVisible_Likert_SQ1_OptionC = false;
                IsVisible_Likert_SQ1_OptionD = false;
                IsVisible_Likert_SQ1_OptionE = false;
                IsVisible_Likert_SQ1_OptionF = false;

                IsVisible_Likert_SQ2_OptionA = false;
                IsVisible_Likert_SQ2_OptionB = false;
                IsVisible_Likert_SQ2_OptionC = false;
                IsVisible_Likert_SQ2_OptionD = false;
                IsVisible_Likert_SQ2_OptionE = false;
                IsVisible_Likert_SQ2_OptionF = false;

                IsVisible_Likert_SQ3_OptionA = false;
                IsVisible_Likert_SQ3_OptionB = false;
                IsVisible_Likert_SQ3_OptionC = false;
                IsVisible_Likert_SQ3_OptionD = false;
                IsVisible_Likert_SQ3_OptionE = false;
                IsVisible_Likert_SQ3_OptionF = false;

                IsVisible_Likert_SQ4_OptionA = false;
                IsVisible_Likert_SQ4_OptionB = false;
                IsVisible_Likert_SQ4_OptionC = false;
                IsVisible_Likert_SQ4_OptionD = false;
                IsVisible_Likert_SQ4_OptionE = false;
                IsVisible_Likert_SQ4_OptionF = false;


                IsVisible_Likert_SQ5_OptionA = false;
                IsVisible_Likert_SQ5_OptionB = false;
                IsVisible_Likert_SQ5_OptionC = false;
                IsVisible_Likert_SQ5_OptionD = false;
                IsVisible_Likert_SQ5_OptionE = false;
                IsVisible_Likert_SQ5_OptionF = false;

                IsVisible_Likert_SQ6_OptionA = false;
                IsVisible_Likert_SQ6_OptionB = false;
                IsVisible_Likert_SQ6_OptionC = false;
                IsVisible_Likert_SQ6_OptionD = false;
                IsVisible_Likert_SQ6_OptionE = false;
                IsVisible_Likert_SQ6_OptionF = false;

                #endregion

                #region Bind Liker Question
                //if (string.IsNullOrEmpty(_questiondata.question))
                //{
                //    LikerQuestion = "Question not received";
                //}
                //else
                // {
                //   LikerQuestion = Regex.Replace(Regex.Replace(_questiondata.question.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                LikerQuestion = _questiondata.question.Replace("\n", string.Empty);

                //  }
                #endregion

                #region Bind Liker Sub Questions
                var _resSubQuestion = _localDB.GetSubQuestionsByQuestionId(_questiondata.id);
                if (_resSubQuestion != null)
                {
                    #region SubQuestion1
                    if (_resSubQuestion.Count() < 1 || string.IsNullOrEmpty(_resSubQuestion[0].sub_question))
                    {
                        LikerSubQuestion1 = string.Empty;
                    }
                    else
                    {
                        IsVisible_LikerSubQuestion1 = true;
                        LikerSubQuestion1_ID = _resSubQuestion[0].subquestion_id;
                        //  LikerSubQuestion1 = Regex.Replace(Regex.Replace(_resSubQuestion[0].sub_question.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty).Replace("<strong>", string.Empty).Replace("</strong>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);

                        LikerSubQuestion1 = _resSubQuestion[0].sub_question.Replace("\n", string.Empty);

                    }
                    #endregion

                    #region SubQuestion2
                    if (_resSubQuestion.Count() < 2 || string.IsNullOrEmpty(_resSubQuestion[1].sub_question))
                    {
                        LikerSubQuestion2 = string.Empty;
                    }
                    else
                    {
                        IsVisible_LikerSubQuestion2 = true;
                        LikerSubQuestion2_ID = _resSubQuestion[1].subquestion_id;
                        //    LikerSubQuestion2 = Regex.Replace(Regex.Replace(_resSubQuestion[1].sub_question.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty).Replace("<strong>", string.Empty).Replace("</strong>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);

                        LikerSubQuestion2 = _resSubQuestion[1].sub_question.Replace("\n", string.Empty);
                    }
                    #endregion

                    #region SubQuestion3
                    if (_resSubQuestion.Count() < 3 || string.IsNullOrEmpty(_resSubQuestion[2].sub_question))
                    {
                        LikerSubQuestion3 = string.Empty;
                    }
                    else
                    {
                        IsVisible_LikerSubQuestion3 = true;
                        LikerSubQuestion3_ID = _resSubQuestion[2].subquestion_id;
                        // LikerSubQuestion3 = Regex.Replace(Regex.Replace(_resSubQuestion[2].sub_question.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                        LikerSubQuestion3 = _resSubQuestion[2].sub_question.Replace("\n", string.Empty);


                    }
                    #endregion

                    #region SubQuestion4
                    if (_resSubQuestion.Count() < 4 || string.IsNullOrEmpty(_resSubQuestion[3].sub_question))
                    {
                        LikerSubQuestion4 = string.Empty;
                    }
                    else
                    {
                        IsVisible_LikerSubQuestion4 = true;
                        LikerSubQuestion4_ID = _resSubQuestion[3].subquestion_id;
                        // LikerSubQuestion4 = Regex.Replace(Regex.Replace(_resSubQuestion[3].sub_question.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);

                        LikerSubQuestion4 = _resSubQuestion[3].sub_question.Replace("\n", string.Empty);
                    }
                    #endregion

                    #region SubQuestion5
                    if (_resSubQuestion.Count() < 5 || string.IsNullOrEmpty(_resSubQuestion[4].sub_question))
                    {
                        LikerSubQuestion5 = string.Empty;
                    }
                    else
                    {
                        IsVisible_LikerSubQuestion5 = true;
                        LikerSubQuestion5_ID = _resSubQuestion[4].subquestion_id;
                        //  LikerSubQuestion5 = Regex.Replace(Regex.Replace(_resSubQuestion[4].sub_question.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                        LikerSubQuestion5 = _resSubQuestion[4].sub_question.Replace("\n", string.Empty);

                    }
                    #endregion

                    #region SubQuestion6
                    if (_resSubQuestion.Count() < 6 || string.IsNullOrEmpty(_resSubQuestion[5].sub_question))
                    {
                        LikerSubQuestion6 = string.Empty;
                    }
                    else
                    {
                        IsVisible_LikerSubQuestion6 = true;
                        LikerSubQuestion6_ID = _resSubQuestion[5].subquestion_id;
                        //     LikerSubQuestion6 = Regex.Replace(Regex.Replace(_resSubQuestion[5].sub_question.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                        LikerSubQuestion6 = _resSubQuestion[5].sub_question.Replace("\n", string.Empty);
                    }
                    #endregion
                }
                #endregion

                #region Load Likert Options
                if (_questiondata.is_question_mandatory == "True")
                {

                    #region Load Sub Question 1 Options

                    if (_resSubQuestion.Count >= 1)
                    {

                        if (!string.IsNullOrEmpty(_resSubQuestion[0].subquestion_id))
                        {
                            List<Exam_Question_Options> _subQuestion1_Options;
                            if (_questiondata.question_type == Convert.ToString((int)question_type.likert))
                            {
                                _subQuestion1_Options = _localDB.GetPRO_OptionListBySubQuestionID(_questiondata.id.ToString(), _resSubQuestion[0].subquestion_id);
                            }
                            else
                            {
                                _subQuestion1_Options = _localDB.GetPRO_OptionListBySubQuestionID(_questiondata.id.ToString(), "0");
                            }


                            if (_subQuestion1_Options != null)
                            {
                                #region Option A
                                if (_subQuestion1_Options.Count() < 1 || string.IsNullOrEmpty(_subQuestion1_Options[0].options))
                                {
                                    IsVisible_Likert_SQ1_OptionA = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ1_OptionA = true;
                                    LikerOptionQ1A_ID = _subQuestion1_Options[0].id.ToString();
                                    LikerQ1OptionContentA = Regex.Replace(Regex.Replace(_subQuestion1_Options[0].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);

                                }
                                #endregion

                                #region Option B
                                if (_subQuestion1_Options.Count() < 2 || string.IsNullOrEmpty(_subQuestion1_Options[1].options))
                                {
                                    IsVisible_Likert_SQ1_OptionB = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ1_OptionB = true;
                                    LikerOptionQ1B_ID = _subQuestion1_Options[1].id.ToString();
                                    LikerQ1OptionContentB = Regex.Replace(Regex.Replace(_subQuestion1_Options[1].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option C
                                if (_subQuestion1_Options.Count() < 3 || string.IsNullOrEmpty(_subQuestion1_Options[2].options))
                                {
                                    IsVisible_Likert_SQ1_OptionC = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ1_OptionC = true;
                                    LikerOptionQ1C_ID = _subQuestion1_Options[2].id.ToString();
                                    LikerQ1OptionContentC = Regex.Replace(Regex.Replace(_subQuestion1_Options[2].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option D
                                if (_subQuestion1_Options.Count() < 4 || string.IsNullOrEmpty(_subQuestion1_Options[3].options))
                                {
                                    IsVisible_Likert_SQ1_OptionD = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ1_OptionD = true;
                                    LikerOptionQ1D_ID = _subQuestion1_Options[3].id.ToString();
                                    LikerQ1OptionContentD = Regex.Replace(Regex.Replace(_subQuestion1_Options[3].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                                #region Option E
                                if (_subQuestion1_Options.Count() < 5 || string.IsNullOrEmpty(_subQuestion1_Options[4].options))
                                {
                                    IsVisible_Likert_SQ1_OptionE = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ1_OptionE = true;
                                    LikerOptionQ1E_ID = _subQuestion1_Options[4].id.ToString();
                                    LikerQ1OptionContentE = Regex.Replace(Regex.Replace(_subQuestion1_Options[4].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option F
                                if (_subQuestion1_Options.Count() < 6 || string.IsNullOrEmpty(_subQuestion1_Options[5].options))
                                {
                                    IsVisible_Likert_SQ1_OptionF = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ1_OptionF = true;
                                    LikerOptionQ1F_ID = _subQuestion1_Options[5].id.ToString();
                                    LikerQ1OptionContentF = Regex.Replace(Regex.Replace(_subQuestion1_Options[5].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                            }
                        }
                    }








                    #endregion

                    #region Load Sub Question 2 options
                    if (_resSubQuestion.Count >= 2)
                    {


                        if (!string.IsNullOrEmpty(_resSubQuestion[1].subquestion_id))
                        {

                            List<Exam_Question_Options> _subQuestion2_Options;
                            if (_questiondata.question_type == Convert.ToString((int)question_type.likert))
                            {
                                _subQuestion2_Options = _localDB.GetPRO_OptionListBySubQuestionID(_questiondata.id.ToString(), _resSubQuestion[1].subquestion_id);

                            }
                            else
                            {
                                _subQuestion2_Options = _localDB.GetPRO_OptionListBySubQuestionID(_questiondata.id.ToString(), "0");

                            }


                            if (_subQuestion2_Options != null)
                            {
                                #region Option A
                                if (_subQuestion2_Options.Count() < 1 || string.IsNullOrEmpty(_subQuestion2_Options[0].options))
                                {
                                    IsVisible_Likert_SQ2_OptionA = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ2_OptionA = true;
                                    LikerOptionQ2A_ID = _subQuestion2_Options[0].id.ToString();
                                    LikerQ2OptionContentA = Regex.Replace(Regex.Replace(_subQuestion2_Options[0].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option B
                                if (_subQuestion2_Options.Count() < 2 || string.IsNullOrEmpty(_subQuestion2_Options[1].options))
                                {
                                    IsVisible_Likert_SQ2_OptionB = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ2_OptionB = true;
                                    LikerOptionQ2B_ID = _subQuestion2_Options[1].id.ToString();
                                    LikerQ2OptionContentB = Regex.Replace(Regex.Replace(_subQuestion2_Options[1].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option C
                                if (_subQuestion2_Options.Count() < 3 || string.IsNullOrEmpty(_subQuestion2_Options[2].options))
                                {
                                    IsVisible_Likert_SQ2_OptionC = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ2_OptionC = true;
                                    LikerOptionQ2C_ID = _subQuestion2_Options[2].id.ToString();
                                    LikerQ2OptionContentC = Regex.Replace(Regex.Replace(_subQuestion2_Options[2].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                                #region Option D
                                if (_subQuestion2_Options.Count() < 4 || string.IsNullOrEmpty(_subQuestion2_Options[3].options))
                                {
                                    IsVisible_Likert_SQ2_OptionD = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ2_OptionD = true;
                                    LikerOptionQ2D_ID = _subQuestion2_Options[3].id.ToString();
                                    LikerQ2OptionContentD = Regex.Replace(Regex.Replace(_subQuestion2_Options[3].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option E
                                if (_subQuestion2_Options.Count() < 5 || string.IsNullOrEmpty(_subQuestion2_Options[4].options))
                                {
                                    IsVisible_Likert_SQ2_OptionE = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ2_OptionE = true;
                                    LikerOptionQ2E_ID = _subQuestion2_Options[4].id.ToString();
                                    LikerQ2OptionContentE = Regex.Replace(Regex.Replace(_subQuestion2_Options[4].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option F
                                if (_subQuestion2_Options.Count() < 6 || string.IsNullOrEmpty(_subQuestion2_Options[5].options))
                                {
                                    IsVisible_Likert_SQ2_OptionF = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ2_OptionF = true;
                                    LikerOptionQ2F_ID = _subQuestion2_Options[5].id.ToString();
                                    LikerQ2OptionContentF = Regex.Replace(Regex.Replace(_subQuestion2_Options[5].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                            }
                        }
                    }
                    #endregion

                    #region Load Sub Question 3 options
                    if (_resSubQuestion.Count >= 3)
                    {


                        if (!string.IsNullOrEmpty(_resSubQuestion[2].subquestion_id))
                        {
                            // var _subQuestion3_Options = _localDB.GetPRO_OptionListBySubQuestionID(_questiondata.id.ToString(), "0");
                            List<Exam_Question_Options> _subQuestion3_Options;
                            if (_questiondata.question_type == Convert.ToString((int)question_type.likert))
                            {
                                _subQuestion3_Options = _localDB.GetPRO_OptionListBySubQuestionID(_questiondata.id.ToString(), _resSubQuestion[2].subquestion_id);
                            }
                            else
                            {
                                _subQuestion3_Options = _localDB.GetPRO_OptionListBySubQuestionID(_questiondata.id.ToString(), "0");

                            }
                            if (_subQuestion3_Options != null)
                            {
                                #region Option A
                                if (_subQuestion3_Options.Count() < 1 || string.IsNullOrEmpty(_subQuestion3_Options[0].options))
                                {
                                    IsVisible_Likert_SQ3_OptionA = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ3_OptionA = true;
                                    LikerOptionQ3A_ID = _subQuestion3_Options[0].id.ToString();
                                    LikerQ3OptionContentA = Regex.Replace(Regex.Replace(_subQuestion3_Options[0].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }


                                #endregion

                                #region Option B
                                if (_subQuestion3_Options.Count() < 2 || string.IsNullOrEmpty(_subQuestion3_Options[1].options))
                                {
                                    IsVisible_Likert_SQ3_OptionB = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ3_OptionB = true;
                                    LikerOptionQ3B_ID = _subQuestion3_Options[1].id.ToString();
                                    LikerQ3OptionContentB = Regex.Replace(Regex.Replace(_subQuestion3_Options[1].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                                #region Option C
                                if (_subQuestion3_Options.Count() < 3 || string.IsNullOrEmpty(_subQuestion3_Options[2].options))
                                {
                                    IsVisible_Likert_SQ3_OptionC = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ3_OptionC = true;
                                    LikerOptionQ3C_ID = _subQuestion3_Options[2].id.ToString();
                                    LikerQ3OptionContentC = Regex.Replace(Regex.Replace(_subQuestion3_Options[2].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }


                                #endregion

                                #region Option D
                                if (_subQuestion3_Options.Count() < 4 || string.IsNullOrEmpty(_subQuestion3_Options[3].options))
                                {
                                    IsVisible_Likert_SQ3_OptionD = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ3_OptionD = true;
                                    LikerOptionQ3D_ID = _subQuestion3_Options[3].id.ToString();
                                    LikerQ3OptionContentD = Regex.Replace(Regex.Replace(_subQuestion3_Options[3].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                                #region Option E
                                if (_subQuestion3_Options.Count() < 5 || string.IsNullOrEmpty(_subQuestion3_Options[4].options))
                                {
                                    IsVisible_Likert_SQ3_OptionE = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ3_OptionE = true;
                                    LikerOptionQ3E_ID = _subQuestion3_Options[4].id.ToString();
                                    LikerQ3OptionContentE = Regex.Replace(Regex.Replace(_subQuestion3_Options[4].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                                #region Option F
                                if (_subQuestion3_Options.Count() < 6 || string.IsNullOrEmpty(_subQuestion3_Options[5].options))
                                {
                                    IsVisible_Likert_SQ3_OptionF = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ3_OptionF = true;
                                    LikerOptionQ3F_ID = _subQuestion3_Options[5].id.ToString();
                                    LikerQ3OptionContentF = Regex.Replace(Regex.Replace(_subQuestion3_Options[5].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                            }
                        }
                    }
                    #endregion

                    #region Load Sub Question 4 options

                    if (_resSubQuestion.Count >= 4)
                    {

                        if (!string.IsNullOrEmpty(_resSubQuestion[3].subquestion_id))
                        {
                            //  var _subQuestion4_Options = _localDB.GetPRO_OptionListBySubQuestionID(_questiondata.id.ToString(), "0");
                            List<Exam_Question_Options> _subQuestion4_Options;
                            if (_questiondata.question_type == Convert.ToString((int)question_type.likert))
                            {
                                _subQuestion4_Options = _localDB.GetPRO_OptionListBySubQuestionID(_questiondata.id.ToString(), _resSubQuestion[3].subquestion_id);
                            }
                            else
                            {
                                _subQuestion4_Options = _localDB.GetPRO_OptionListBySubQuestionID(_questiondata.id.ToString(), "0");

                            }
                            if (_subQuestion4_Options != null)
                            {
                                #region Option A
                                if (_subQuestion4_Options.Count() < 1 || string.IsNullOrEmpty(_subQuestion4_Options[0].options))
                                {
                                    IsVisible_Likert_SQ4_OptionA = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ4_OptionA = true;
                                    LikerOptionQ4A_ID = _subQuestion4_Options[0].id.ToString();
                                    LikerQ4OptionContentA = Regex.Replace(Regex.Replace(_subQuestion4_Options[0].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }


                                #endregion

                                #region Option B
                                if (_subQuestion4_Options.Count() < 2 || string.IsNullOrEmpty(_subQuestion4_Options[1].options))
                                {
                                    IsVisible_Likert_SQ4_OptionB = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ4_OptionB = true;
                                    LikerOptionQ4B_ID = _subQuestion4_Options[1].id.ToString();
                                    LikerQ4OptionContentB = Regex.Replace(Regex.Replace(_subQuestion4_Options[1].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option C
                                if (_subQuestion4_Options.Count() < 3 || string.IsNullOrEmpty(_subQuestion4_Options[2].options))
                                {
                                    IsVisible_Likert_SQ4_OptionC = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ4_OptionC = true;
                                    LikerOptionQ4C_ID = _subQuestion4_Options[2].id.ToString();
                                    LikerQ4OptionContentC = Regex.Replace(Regex.Replace(_subQuestion4_Options[2].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }


                                #endregion

                                #region Option D
                                if (_subQuestion4_Options.Count() < 4 || string.IsNullOrEmpty(_subQuestion4_Options[3].options))
                                {
                                    IsVisible_Likert_SQ4_OptionD = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ4_OptionD = true;
                                    LikerOptionQ4D_ID = _subQuestion4_Options[3].id.ToString();
                                    LikerQ4OptionContentD = Regex.Replace(Regex.Replace(_subQuestion4_Options[3].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                                #region Option E
                                if (_subQuestion4_Options.Count() < 5 || string.IsNullOrEmpty(_subQuestion4_Options[4].options))
                                {
                                    IsVisible_Likert_SQ4_OptionE = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ4_OptionE = true;
                                    LikerOptionQ4E_ID = _subQuestion4_Options[4].id.ToString();
                                    LikerQ4OptionContentE = Regex.Replace(Regex.Replace(_subQuestion4_Options[4].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                                #region Option F
                                if (_subQuestion4_Options.Count() < 6 || string.IsNullOrEmpty(_subQuestion4_Options[5].options))
                                {
                                    IsVisible_Likert_SQ4_OptionF = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ4_OptionF = true;
                                    LikerOptionQ4F_ID = _subQuestion4_Options[5].id.ToString();
                                    LikerQ4OptionContentF = Regex.Replace(Regex.Replace(_subQuestion4_Options[5].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                            }
                        }
                    }
                    #endregion

                    #region Load Sub Question 5 options

                    if (_resSubQuestion.Count >= 5)
                    {


                        if (!string.IsNullOrEmpty(_resSubQuestion[4].subquestion_id))
                        {
                            // var _subQuestion5_Options = _localDB.GetPRO_OptionListBySubQuestionID(_questiondata.id.ToString(), "0");
                            List<Exam_Question_Options> _subQuestion5_Options;
                            if (_questiondata.question_type == Convert.ToString((int)question_type.likert))
                            {
                                _subQuestion5_Options = _localDB.GetPRO_OptionListBySubQuestionID(_questiondata.id.ToString(), _resSubQuestion[4].subquestion_id);
                            }
                            else
                            {
                                _subQuestion5_Options = _localDB.GetPRO_OptionListBySubQuestionID(_questiondata.id.ToString(), "0");

                            }
                            if (_subQuestion5_Options != null)
                            {
                                #region Option A
                                if (_subQuestion5_Options.Count() < 1 || string.IsNullOrEmpty(_subQuestion5_Options[0].options))
                                {
                                    IsVisible_Likert_SQ5_OptionA = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ5_OptionA = true;
                                    LikerOptionQ5A_ID = _subQuestion5_Options[0].id.ToString();
                                    LikerQ5OptionContentA = Regex.Replace(Regex.Replace(_subQuestion5_Options[0].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }


                                #endregion

                                #region Option B
                                if (_subQuestion5_Options.Count() < 2 || string.IsNullOrEmpty(_subQuestion5_Options[1].options))
                                {
                                    IsVisible_Likert_SQ5_OptionB = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ5_OptionB = true;
                                    LikerOptionQ5B_ID = _subQuestion5_Options[1].id.ToString();
                                    LikerQ5OptionContentB = Regex.Replace(Regex.Replace(_subQuestion5_Options[1].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                                #region Option C
                                if (_subQuestion5_Options.Count() < 3 || string.IsNullOrEmpty(_subQuestion5_Options[2].options))
                                {
                                    IsVisible_Likert_SQ5_OptionC = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ5_OptionC = true;
                                    LikerOptionQ5C_ID = _subQuestion5_Options[2].id.ToString();
                                    LikerQ5OptionContentC = Regex.Replace(Regex.Replace(_subQuestion5_Options[2].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                                #region Option D
                                if (_subQuestion5_Options.Count() < 4 || string.IsNullOrEmpty(_subQuestion5_Options[3].options))
                                {
                                    IsVisible_Likert_SQ5_OptionD = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ5_OptionD = true;
                                    LikerOptionQ5D_ID = _subQuestion5_Options[3].id.ToString();
                                    LikerQ5OptionContentD = Regex.Replace(Regex.Replace(_subQuestion5_Options[3].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }


                                #endregion

                                #region Option E
                                if (_subQuestion5_Options.Count() < 5 || string.IsNullOrEmpty(_subQuestion5_Options[4].options))
                                {
                                    IsVisible_Likert_SQ5_OptionE = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ5_OptionE = true;
                                    LikerOptionQ5E_ID = _subQuestion5_Options[4].id.ToString();
                                    LikerQ5OptionContentE = Regex.Replace(Regex.Replace(_subQuestion5_Options[4].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }


                                #endregion

                                #region Option F
                                if (_subQuestion5_Options.Count() < 6 || string.IsNullOrEmpty(_subQuestion5_Options[5].options))
                                {
                                    IsVisible_Likert_SQ5_OptionF = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ5_OptionF = true;
                                    LikerOptionQ5F_ID = _subQuestion5_Options[5].id.ToString();
                                    LikerQ5OptionContentF = Regex.Replace(Regex.Replace(_subQuestion5_Options[5].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                            }
                        }
                    }
                    #endregion

                    #region Load Sub Question 6 options

                    if (_resSubQuestion.Count >= 6)
                    {


                        if (!string.IsNullOrEmpty(_resSubQuestion[5].subquestion_id))
                        {
                            //  var _subQuestion6_Options = _localDB.GetPRO_OptionListBySubQuestionID(_questiondata.id.ToString(), "0");
                            List<Exam_Question_Options> _subQuestion6_Options;
                            if (_questiondata.question_type == Convert.ToString((int)question_type.likert))
                            {
                                _subQuestion6_Options = _localDB.GetPRO_OptionListBySubQuestionID(_questiondata.id.ToString(), _resSubQuestion[5].subquestion_id);
                            }
                            else
                            {
                                _subQuestion6_Options = _localDB.GetPRO_OptionListBySubQuestionID(_questiondata.id.ToString(), "0");

                            }
                            if (_subQuestion6_Options != null)
                            {
                                #region Option A
                                if (_subQuestion6_Options.Count() < 1 || string.IsNullOrEmpty(_subQuestion6_Options[0].options))
                                {
                                    IsVisible_Likert_SQ6_OptionA = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ6_OptionA = true;
                                    LikerOptionQ6A_ID = _subQuestion6_Options[0].id.ToString();
                                    LikerQ6OptionContentA = Regex.Replace(Regex.Replace(_subQuestion6_Options[0].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option B
                                if (_subQuestion6_Options.Count() < 2 || string.IsNullOrEmpty(_subQuestion6_Options[1].options))
                                {
                                    IsVisible_Likert_SQ6_OptionB = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ6_OptionB = true;
                                    LikerOptionQ6B_ID = _subQuestion6_Options[1].id.ToString();
                                    LikerQ6OptionContentB = Regex.Replace(Regex.Replace(_subQuestion6_Options[1].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option C
                                if (_subQuestion6_Options.Count() < 3 || string.IsNullOrEmpty(_subQuestion6_Options[2].options))
                                {
                                    IsVisible_Likert_SQ6_OptionC = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ6_OptionC = true;
                                    LikerOptionQ6C_ID = _subQuestion6_Options[2].id.ToString();
                                    LikerQ6OptionContentC = Regex.Replace(Regex.Replace(_subQuestion6_Options[2].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option D
                                if (_subQuestion6_Options.Count() < 4 || string.IsNullOrEmpty(_subQuestion6_Options[3].options))
                                {
                                    IsVisible_Likert_SQ6_OptionD = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ6_OptionD = true;
                                    LikerOptionQ6D_ID = _subQuestion6_Options[3].id.ToString();
                                    LikerQ6OptionContentD = Regex.Replace(Regex.Replace(_subQuestion6_Options[3].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option E
                                if (_subQuestion6_Options.Count() < 5 || string.IsNullOrEmpty(_subQuestion6_Options[4].options))
                                {
                                    IsVisible_Likert_SQ6_OptionE = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ6_OptionE = true;
                                    LikerOptionQ6E_ID = _subQuestion6_Options[4].id.ToString();
                                    LikerQ6OptionContentE = Regex.Replace(Regex.Replace(_subQuestion6_Options[4].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option F
                                if (_subQuestion6_Options.Count() < 6 || string.IsNullOrEmpty(_subQuestion6_Options[5].options))
                                {
                                    IsVisible_Likert_SQ6_OptionF = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ6_OptionF = true;
                                    LikerOptionQ6F_ID = _subQuestion6_Options[5].id.ToString();
                                    LikerQ6OptionContentF = Regex.Replace(Regex.Replace(_subQuestion6_Options[5].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                            }
                        }
                    }
                    #endregion
                }
                else
                {

                    #region Load Sub Question 1 Options

                    if (_resSubQuestion.Count >= 1)
                    {

                        if (!string.IsNullOrEmpty(_resSubQuestion[0].subquestion_id))
                        {
                            var _subQuestion1_Options = _localDB.GetPRO_OptionListBySubQuestionID(_questiondata.id.ToString(), _resSubQuestion[0].subquestion_id);
                            if (_subQuestion1_Options != null)
                            {
                                #region Option A
                                if (_subQuestion1_Options.Count() < 1 || string.IsNullOrEmpty(_subQuestion1_Options[0].options))
                                {
                                    IsVisible_Likert_SQ1_OptionA = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ1_OptionA = true;
                                    LikerOptionQ1A_ID = _subQuestion1_Options[0].id.ToString();
                                    LikerQ1OptionContentA = Regex.Replace(Regex.Replace(_subQuestion1_Options[0].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option B
                                if (_subQuestion1_Options.Count() < 2 || string.IsNullOrEmpty(_subQuestion1_Options[1].options))
                                {
                                    IsVisible_Likert_SQ1_OptionB = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ1_OptionB = true;
                                    LikerOptionQ1B_ID = _subQuestion1_Options[1].id.ToString();
                                    LikerQ1OptionContentB = Regex.Replace(Regex.Replace(_subQuestion1_Options[1].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option C
                                if (_subQuestion1_Options.Count() < 3 || string.IsNullOrEmpty(_subQuestion1_Options[2].options))
                                {
                                    IsVisible_Likert_SQ1_OptionC = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ1_OptionC = true;
                                    LikerOptionQ1C_ID = _subQuestion1_Options[2].id.ToString();
                                    LikerQ1OptionContentC = Regex.Replace(Regex.Replace(_subQuestion1_Options[2].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option D
                                if (_subQuestion1_Options.Count() < 4 || string.IsNullOrEmpty(_subQuestion1_Options[3].options))
                                {
                                    IsVisible_Likert_SQ1_OptionD = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ1_OptionD = true;
                                    LikerOptionQ1D_ID = _subQuestion1_Options[3].id.ToString();
                                    LikerQ1OptionContentD = Regex.Replace(Regex.Replace(_subQuestion1_Options[3].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                                #region Option E
                                if (_subQuestion1_Options.Count() < 5 || string.IsNullOrEmpty(_subQuestion1_Options[4].options))
                                {
                                    IsVisible_Likert_SQ1_OptionE = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ1_OptionE = true;
                                    LikerOptionQ1E_ID = _subQuestion1_Options[4].id.ToString();
                                    LikerQ1OptionContentE = Regex.Replace(Regex.Replace(_subQuestion1_Options[4].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option F
                                if (_subQuestion1_Options.Count() < 6 || string.IsNullOrEmpty(_subQuestion1_Options[5].options))
                                {
                                    IsVisible_Likert_SQ1_OptionF = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ1_OptionF = true;
                                    LikerOptionQ1F_ID = _subQuestion1_Options[5].id.ToString();
                                    LikerQ1OptionContentF = Regex.Replace(Regex.Replace(_subQuestion1_Options[5].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                            }
                        }
                    }








                    #endregion

                    #region Load Sub Question 2 options
                    if (_resSubQuestion.Count >= 2)
                    {


                        if (!string.IsNullOrEmpty(_resSubQuestion[1].subquestion_id))
                        {
                            var _subQuestion2_Options = _localDB.GetPRO_OptionListBySubQuestionID(_questiondata.id.ToString(), _resSubQuestion[1].subquestion_id);
                            if (_subQuestion2_Options != null)
                            {
                                #region Option A
                                if (_subQuestion2_Options.Count() < 1 || string.IsNullOrEmpty(_subQuestion2_Options[0].options))
                                {
                                    IsVisible_Likert_SQ2_OptionA = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ2_OptionA = true;
                                    LikerOptionQ2A_ID = _subQuestion2_Options[0].id.ToString();
                                    LikerQ2OptionContentA = Regex.Replace(Regex.Replace(_subQuestion2_Options[0].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option B
                                if (_subQuestion2_Options.Count() < 2 || string.IsNullOrEmpty(_subQuestion2_Options[1].options))
                                {
                                    IsVisible_Likert_SQ2_OptionB = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ2_OptionB = true;
                                    LikerOptionQ2B_ID = _subQuestion2_Options[1].id.ToString();
                                    LikerQ2OptionContentB = Regex.Replace(Regex.Replace(_subQuestion2_Options[1].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option C
                                if (_subQuestion2_Options.Count() < 3 || string.IsNullOrEmpty(_subQuestion2_Options[2].options))
                                {
                                    IsVisible_Likert_SQ2_OptionC = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ2_OptionC = true;
                                    LikerOptionQ2C_ID = _subQuestion2_Options[2].id.ToString();
                                    LikerQ2OptionContentC = Regex.Replace(Regex.Replace(_subQuestion2_Options[2].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                                #region Option D
                                if (_subQuestion2_Options.Count() < 4 || string.IsNullOrEmpty(_subQuestion2_Options[3].options))
                                {
                                    IsVisible_Likert_SQ2_OptionD = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ2_OptionD = true;
                                    LikerOptionQ2D_ID = _subQuestion2_Options[3].id.ToString();
                                    LikerQ2OptionContentD = Regex.Replace(Regex.Replace(_subQuestion2_Options[3].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option E
                                if (_subQuestion2_Options.Count() < 5 || string.IsNullOrEmpty(_subQuestion2_Options[4].options))
                                {
                                    IsVisible_Likert_SQ2_OptionE = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ2_OptionE = true;
                                    LikerOptionQ2E_ID = _subQuestion2_Options[4].id.ToString();
                                    LikerQ2OptionContentE = Regex.Replace(Regex.Replace(_subQuestion2_Options[4].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option F
                                if (_subQuestion2_Options.Count() < 6 || string.IsNullOrEmpty(_subQuestion2_Options[5].options))
                                {
                                    IsVisible_Likert_SQ2_OptionF = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ2_OptionF = true;
                                    LikerOptionQ2F_ID = _subQuestion2_Options[5].id.ToString();
                                    LikerQ2OptionContentF = Regex.Replace(Regex.Replace(_subQuestion2_Options[5].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                            }
                        }
                    }
                    #endregion

                    #region Load Sub Question 3 options
                    if (_resSubQuestion.Count >= 3)
                    {


                        if (!string.IsNullOrEmpty(_resSubQuestion[2].subquestion_id))
                        {
                            var _subQuestion3_Options = _localDB.GetPRO_OptionListBySubQuestionID(_questiondata.id.ToString(), _resSubQuestion[2].subquestion_id);
                            if (_subQuestion3_Options != null)
                            {
                                #region Option A
                                if (_subQuestion3_Options.Count() < 1 || string.IsNullOrEmpty(_subQuestion3_Options[0].options))
                                {
                                    IsVisible_Likert_SQ3_OptionA = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ3_OptionA = true;
                                    LikerOptionQ3A_ID = _subQuestion3_Options[0].id.ToString();
                                    LikerQ3OptionContentA = Regex.Replace(Regex.Replace(_subQuestion3_Options[0].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }


                                #endregion

                                #region Option B
                                if (_subQuestion3_Options.Count() < 2 || string.IsNullOrEmpty(_subQuestion3_Options[1].options))
                                {
                                    IsVisible_Likert_SQ3_OptionB = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ3_OptionB = true;
                                    LikerOptionQ3B_ID = _subQuestion3_Options[1].id.ToString();
                                    LikerQ3OptionContentB = Regex.Replace(Regex.Replace(_subQuestion3_Options[1].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                                #region Option C
                                if (_subQuestion3_Options.Count() < 3 || string.IsNullOrEmpty(_subQuestion3_Options[2].options))
                                {
                                    IsVisible_Likert_SQ3_OptionC = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ3_OptionC = true;
                                    LikerOptionQ3C_ID = _subQuestion3_Options[2].id.ToString();
                                    LikerQ3OptionContentC = Regex.Replace(Regex.Replace(_subQuestion3_Options[2].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }


                                #endregion

                                #region Option D
                                if (_subQuestion3_Options.Count() < 4 || string.IsNullOrEmpty(_subQuestion3_Options[3].options))
                                {
                                    IsVisible_Likert_SQ3_OptionD = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ3_OptionD = true;
                                    LikerOptionQ3D_ID = _subQuestion3_Options[3].id.ToString();
                                    LikerQ3OptionContentD = Regex.Replace(Regex.Replace(_subQuestion3_Options[3].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                                #region Option E
                                if (_subQuestion3_Options.Count() < 5 || string.IsNullOrEmpty(_subQuestion3_Options[4].options))
                                {
                                    IsVisible_Likert_SQ3_OptionE = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ3_OptionE = true;
                                    LikerOptionQ3E_ID = _subQuestion3_Options[4].id.ToString();
                                    LikerQ3OptionContentE = Regex.Replace(Regex.Replace(_subQuestion3_Options[4].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                                #region Option F
                                if (_subQuestion3_Options.Count() < 6 || string.IsNullOrEmpty(_subQuestion3_Options[5].options))
                                {
                                    IsVisible_Likert_SQ3_OptionF = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ3_OptionF = true;
                                    LikerOptionQ3F_ID = _subQuestion3_Options[5].id.ToString();
                                    LikerQ3OptionContentF = Regex.Replace(Regex.Replace(_subQuestion3_Options[5].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                            }
                        }
                    }
                    #endregion

                    #region Load Sub Question 4 options

                    if (_resSubQuestion.Count >= 4)
                    {

                        if (!string.IsNullOrEmpty(_resSubQuestion[3].subquestion_id))
                        {
                            var _subQuestion4_Options = _localDB.GetPRO_OptionListBySubQuestionID(_questiondata.id.ToString(), _resSubQuestion[3].subquestion_id);
                            if (_subQuestion4_Options != null)
                            {
                                #region Option A
                                if (_subQuestion4_Options.Count() < 1 || string.IsNullOrEmpty(_subQuestion4_Options[0].options))
                                {
                                    IsVisible_Likert_SQ4_OptionA = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ4_OptionA = true;
                                    LikerOptionQ4A_ID = _subQuestion4_Options[0].id.ToString();
                                    LikerQ4OptionContentA = Regex.Replace(Regex.Replace(_subQuestion4_Options[0].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }


                                #endregion

                                #region Option B
                                if (_subQuestion4_Options.Count() < 2 || string.IsNullOrEmpty(_subQuestion4_Options[1].options))
                                {
                                    IsVisible_Likert_SQ4_OptionB = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ4_OptionB = true;
                                    LikerOptionQ4B_ID = _subQuestion4_Options[1].id.ToString();
                                    LikerQ4OptionContentB = Regex.Replace(Regex.Replace(_subQuestion4_Options[1].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option C
                                if (_subQuestion4_Options.Count() < 3 || string.IsNullOrEmpty(_subQuestion4_Options[2].options))
                                {
                                    IsVisible_Likert_SQ4_OptionC = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ4_OptionC = true;
                                    LikerOptionQ4C_ID = _subQuestion4_Options[2].id.ToString();
                                    LikerQ4OptionContentC = Regex.Replace(Regex.Replace(_subQuestion4_Options[2].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }


                                #endregion

                                #region Option D
                                if (_subQuestion4_Options.Count() < 4 || string.IsNullOrEmpty(_subQuestion4_Options[3].options))
                                {
                                    IsVisible_Likert_SQ4_OptionD = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ4_OptionD = true;
                                    LikerOptionQ4D_ID = _subQuestion4_Options[3].id.ToString();
                                    LikerQ4OptionContentD = Regex.Replace(Regex.Replace(_subQuestion4_Options[3].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                                #region Option E
                                if (_subQuestion4_Options.Count() < 5 || string.IsNullOrEmpty(_subQuestion4_Options[4].options))
                                {
                                    IsVisible_Likert_SQ4_OptionE = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ4_OptionE = true;
                                    LikerOptionQ4E_ID = _subQuestion4_Options[4].id.ToString();
                                    LikerQ4OptionContentE = Regex.Replace(Regex.Replace(_subQuestion4_Options[4].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                                #region Option F
                                if (_subQuestion4_Options.Count() < 6 || string.IsNullOrEmpty(_subQuestion4_Options[5].options))
                                {
                                    IsVisible_Likert_SQ4_OptionF = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ4_OptionF = true;
                                    LikerOptionQ4F_ID = _subQuestion4_Options[5].id.ToString();
                                    LikerQ4OptionContentF = Regex.Replace(Regex.Replace(_subQuestion4_Options[5].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                            }
                        }
                    }
                    #endregion

                    #region Load Sub Question 5 options

                    if (_resSubQuestion.Count >= 5)
                    {


                        if (!string.IsNullOrEmpty(_resSubQuestion[4].subquestion_id))
                        {
                            var _subQuestion5_Options = _localDB.GetPRO_OptionListBySubQuestionID(_questiondata.id.ToString(), _resSubQuestion[4].subquestion_id);
                            if (_subQuestion5_Options != null)
                            {
                                #region Option A
                                if (_subQuestion5_Options.Count() < 1 || string.IsNullOrEmpty(_subQuestion5_Options[0].options))
                                {
                                    IsVisible_Likert_SQ5_OptionA = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ5_OptionA = true;
                                    LikerOptionQ5A_ID = _subQuestion5_Options[0].id.ToString();
                                    LikerQ5OptionContentA = Regex.Replace(Regex.Replace(_subQuestion5_Options[0].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }


                                #endregion

                                #region Option B
                                if (_subQuestion5_Options.Count() < 2 || string.IsNullOrEmpty(_subQuestion5_Options[1].options))
                                {
                                    IsVisible_Likert_SQ5_OptionB = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ5_OptionB = true;
                                    LikerOptionQ5B_ID = _subQuestion5_Options[1].id.ToString();
                                    LikerQ5OptionContentB = Regex.Replace(Regex.Replace(_subQuestion5_Options[1].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                                #region Option C
                                if (_subQuestion5_Options.Count() < 3 || string.IsNullOrEmpty(_subQuestion5_Options[2].options))
                                {
                                    IsVisible_Likert_SQ5_OptionC = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ5_OptionC = true;
                                    LikerOptionQ5C_ID = _subQuestion5_Options[2].id.ToString();
                                    LikerQ5OptionContentC = Regex.Replace(Regex.Replace(_subQuestion5_Options[2].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                                #region Option D
                                if (_subQuestion5_Options.Count() < 4 || string.IsNullOrEmpty(_subQuestion5_Options[3].options))
                                {
                                    IsVisible_Likert_SQ5_OptionD = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ5_OptionD = true;
                                    LikerOptionQ5D_ID = _subQuestion5_Options[3].id.ToString();
                                    LikerQ5OptionContentD = Regex.Replace(Regex.Replace(_subQuestion5_Options[3].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }


                                #endregion

                                #region Option E
                                if (_subQuestion5_Options.Count() < 5 || string.IsNullOrEmpty(_subQuestion5_Options[4].options))
                                {
                                    IsVisible_Likert_SQ5_OptionE = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ5_OptionE = true;
                                    LikerOptionQ5E_ID = _subQuestion5_Options[4].id.ToString();
                                    LikerQ5OptionContentE = Regex.Replace(Regex.Replace(_subQuestion5_Options[4].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }


                                #endregion

                                #region Option F
                                if (_subQuestion5_Options.Count() < 6 || string.IsNullOrEmpty(_subQuestion5_Options[5].options))
                                {
                                    IsVisible_Likert_SQ5_OptionF = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ5_OptionF = true;
                                    LikerOptionQ5F_ID = _subQuestion5_Options[5].id.ToString();
                                    LikerQ5OptionContentF = Regex.Replace(Regex.Replace(_subQuestion5_Options[5].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }

                                #endregion

                            }
                        }
                    }
                    #endregion

                    #region Load Sub Question 6 options

                    if (_resSubQuestion.Count >= 6)
                    {


                        if (!string.IsNullOrEmpty(_resSubQuestion[5].subquestion_id))
                        {
                            var _subQuestion6_Options = _localDB.GetPRO_OptionListBySubQuestionID(_questiondata.id.ToString(), _resSubQuestion[5].subquestion_id);
                            if (_subQuestion6_Options != null)
                            {
                                #region Option A
                                if (_subQuestion6_Options.Count() < 1 || string.IsNullOrEmpty(_subQuestion6_Options[0].options))
                                {
                                    IsVisible_Likert_SQ6_OptionA = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ6_OptionA = true;
                                    LikerOptionQ6A_ID = _subQuestion6_Options[0].id.ToString();
                                    LikerQ6OptionContentA = Regex.Replace(Regex.Replace(_subQuestion6_Options[0].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option B
                                if (_subQuestion6_Options.Count() < 2 || string.IsNullOrEmpty(_subQuestion6_Options[1].options))
                                {
                                    IsVisible_Likert_SQ6_OptionB = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ6_OptionB = true;
                                    LikerOptionQ6B_ID = _subQuestion6_Options[1].id.ToString();
                                    LikerQ6OptionContentB = Regex.Replace(Regex.Replace(_subQuestion6_Options[1].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option C
                                if (_subQuestion6_Options.Count() < 3 || string.IsNullOrEmpty(_subQuestion6_Options[2].options))
                                {
                                    IsVisible_Likert_SQ6_OptionC = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ6_OptionC = true;
                                    LikerOptionQ6C_ID = _subQuestion6_Options[2].id.ToString();
                                    LikerQ6OptionContentC = Regex.Replace(Regex.Replace(_subQuestion6_Options[2].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option D
                                if (_subQuestion6_Options.Count() < 4 || string.IsNullOrEmpty(_subQuestion6_Options[3].options))
                                {
                                    IsVisible_Likert_SQ6_OptionD = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ6_OptionD = true;
                                    LikerOptionQ6D_ID = _subQuestion6_Options[3].id.ToString();
                                    LikerQ6OptionContentD = Regex.Replace(Regex.Replace(_subQuestion6_Options[3].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option E
                                if (_subQuestion6_Options.Count() < 5 || string.IsNullOrEmpty(_subQuestion6_Options[4].options))
                                {
                                    IsVisible_Likert_SQ6_OptionE = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ6_OptionE = true;
                                    LikerOptionQ6E_ID = _subQuestion6_Options[4].id.ToString();
                                    LikerQ6OptionContentE = Regex.Replace(Regex.Replace(_subQuestion6_Options[4].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                                #region Option F
                                if (_subQuestion6_Options.Count() < 6 || string.IsNullOrEmpty(_subQuestion6_Options[5].options))
                                {
                                    IsVisible_Likert_SQ6_OptionF = false;
                                }
                                else
                                {
                                    IsVisible_Likert_SQ6_OptionF = true;
                                    LikerOptionQ6F_ID = _subQuestion6_Options[5].id.ToString();
                                    LikerQ6OptionContentF = Regex.Replace(Regex.Replace(_subQuestion6_Options[5].options.Replace("\n", string.Empty).Replace("<p>", string.Empty).Replace("</p>", string.Empty), @"(<br/>|<br />|</br>|</br>)", "\r\n"), @"<span([^>]*)>(.*)<\/span>", string.Empty);
                                }
                                #endregion

                            }
                        }
                    }
                    #endregion
                }
                #endregion

                #region Likert Answer Bind
                if (_resSubQuestion != null)
                {
                    if (_resSubQuestion.Count >= 1)
                    {
                        #region Sub Question 1 Answer Bind
                        var SubQuestion1_AnswerData = _localDB.Get_PRO_SubQuestionAnswers(_questiondata.id.ToString(), _resSubQuestion[0].subquestion_id);
                        if (SubQuestion1_AnswerData != null && SubQuestion1_AnswerData.Count !=0)
                        {

                            if (!string.IsNullOrEmpty(SubQuestion1_AnswerData[0].exam_answer) && SubQuestion1_AnswerData[0].exam_answer != "0")
                            {
                                if (SubQuestion1_AnswerData[0].exam_answer == LikerOptionQ1A_ID)
                                {

                                    LikerOptionARadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ1A_ID;
                                    selectedSubQuestionId = LikerSubQuestion1_ID;
                                }
                                else if (SubQuestion1_AnswerData[0].exam_answer == LikerOptionQ1B_ID)
                                {
                                    LikerOptionBRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ1B_ID;
                                    selectedSubQuestionId = LikerSubQuestion1_ID;

                                }
                                else if (SubQuestion1_AnswerData[0].exam_answer == LikerOptionQ1C_ID)
                                {

                                    LikerOptionCRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ1C_ID;
                                    selectedSubQuestionId = LikerSubQuestion1_ID;

                                }
                                else if (SubQuestion1_AnswerData[0].exam_answer == LikerOptionQ1D_ID)
                                {

                                    LikerOptionDRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ1D_ID;
                                    selectedSubQuestionId = LikerSubQuestion1_ID;
                                }

                                else if (SubQuestion1_AnswerData[0].exam_answer == LikerOptionQ1E_ID)
                                {

                                    LikerOptionERadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ1E_ID;
                                    selectedSubQuestionId = LikerSubQuestion1_ID;
                                }
                                else if (SubQuestion1_AnswerData[0].exam_answer == LikerOptionQ1F_ID)
                                {

                                    LikerOptionFRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ1F_ID;
                                    selectedSubQuestionId = LikerSubQuestion1_ID;
                                }
                            }

                        }
                        #endregion
                    }
                    if (_resSubQuestion.Count >= 2)
                    {
                        #region Sub Question 2 Answer Bind
                        var SubQuestion2_AnswerData = _localDB.Get_PRO_SubQuestionAnswers(_questiondata.id.ToString(), _resSubQuestion[1].subquestion_id);
                        if (SubQuestion2_AnswerData != null && SubQuestion2_AnswerData.Count != 0)
                        {

                            if (!string.IsNullOrEmpty(SubQuestion2_AnswerData[0].exam_answer) && SubQuestion2_AnswerData[0].exam_answer != "0")
                            {
                                if (SubQuestion2_AnswerData[0].exam_answer == LikerOptionQ2A_ID)
                                {

                                    _LikerOptionARadiobuttontwo = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ2A_ID;
                                    selectedSubQuestionId = LikerSubQuestion2_ID;
                                }
                                else if (SubQuestion2_AnswerData[0].exam_answer == LikerOptionQ2B_ID)
                                {
                                    LikerOptionBRadiobuttontwo = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ2B_ID;
                                    selectedSubQuestionId = LikerSubQuestion2_ID;

                                }
                                else if (SubQuestion2_AnswerData[0].exam_answer == LikerOptionQ2C_ID)
                                {

                                    LikerOptionCRadiobuttontwo = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ2C_ID;
                                    selectedSubQuestionId = LikerSubQuestion2_ID;

                                }
                                else if (SubQuestion2_AnswerData[0].exam_answer == LikerOptionQ2D_ID)
                                {

                                    LikerOptionDRadiobuttontwo = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ2D_ID;
                                    selectedSubQuestionId = LikerSubQuestion2_ID;
                                }

                                else if (SubQuestion2_AnswerData[0].exam_answer == LikerOptionQ2E_ID)
                                {

                                    LikerOptionERadiobuttontwo = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ2E_ID;
                                    selectedSubQuestionId = LikerSubQuestion2_ID;
                                }
                                else if (SubQuestion2_AnswerData[0].exam_answer == LikerOptionQ2F_ID)
                                {

                                    LikerOptionFRadiobuttontwo = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ2F_ID;
                                    selectedSubQuestionId = LikerSubQuestion2_ID;
                                }
                            }

                        }
                        #endregion
                    }
                    if (_resSubQuestion.Count >= 3)
                    {
                        #region Sub Question 3 Answer Bind
                        var SubQuestion3_AnswerData = _localDB.Get_PRO_SubQuestionAnswers(_questiondata.id.ToString(), _resSubQuestion[2].subquestion_id);
                        if (SubQuestion3_AnswerData != null && SubQuestion3_AnswerData.Count != 0)
                        {
                            if (!string.IsNullOrEmpty(SubQuestion3_AnswerData[0].exam_answer) && SubQuestion3_AnswerData[0].exam_answer != "0")
                            {
                                if (SubQuestion3_AnswerData[0].exam_answer == LikerOptionQ3A_ID)
                                {
                                    LikerOptionARadiobuttonthree = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ3A_ID;
                                    selectedSubQuestionId = LikerSubQuestion3_ID;
                                }
                                else if (SubQuestion3_AnswerData[0].exam_answer == LikerOptionQ3B_ID)
                                {
                                    LikerOptionBRadiobuttonthree = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ3B_ID;
                                    selectedSubQuestionId = LikerSubQuestion3_ID;
                                }
                                else if (SubQuestion3_AnswerData[0].exam_answer == LikerOptionQ3C_ID)
                                {
                                    LikerOptionCRadiobuttonthree = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ3C_ID;
                                    selectedSubQuestionId = LikerSubQuestion3_ID;
                                }

                                else if (SubQuestion3_AnswerData[0].exam_answer == LikerOptionQ3D_ID)
                                {
                                    LikerOptionDRadiobuttonthree = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ3D_ID;
                                    selectedSubQuestionId = LikerSubQuestion3_ID;
                                }
                                else if (SubQuestion3_AnswerData[0].exam_answer == LikerOptionQ3E_ID)
                                {
                                    LikerOptionERadiobuttonthree = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ3E_ID;
                                    selectedSubQuestionId = LikerSubQuestion3_ID;
                                }
                                else if (SubQuestion3_AnswerData[0].exam_answer == LikerOptionQ3F_ID)
                                {
                                    LikerOptionFRadiobuttonthree = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ3F_ID;
                                    selectedSubQuestionId = LikerSubQuestion3_ID;
                                }

                            }
                        }
                        #endregion
                    }
                    if (_resSubQuestion.Count >= 4)
                    {
                        #region Sub Question 4 Answer Bind
                        var SubQuestion4_AnswerData = _localDB.Get_PRO_SubQuestionAnswers(_questiondata.id.ToString(), _resSubQuestion[3].subquestion_id);
                        if (SubQuestion4_AnswerData != null && SubQuestion4_AnswerData.Count != 0)
                        {
                            if (!string.IsNullOrEmpty(SubQuestion4_AnswerData[0].exam_answer) && SubQuestion4_AnswerData[0].exam_answer != "0")
                            {
                                if (SubQuestion4_AnswerData[0].exam_answer == LikerOptionQ4A_ID)
                                {
                                    LikerOptionARadiobuttonFour = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ4A_ID;
                                    selectedSubQuestionId = LikerSubQuestion4_ID;
                                }
                                else if (SubQuestion4_AnswerData[0].exam_answer == LikerOptionQ4B_ID)
                                {
                                    LikerOptionBRadiobuttonFour = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ4B_ID;
                                    selectedSubQuestionId = LikerSubQuestion4_ID;
                                }
                                else if (SubQuestion4_AnswerData[0].exam_answer == LikerOptionQ4C_ID)
                                {
                                    LikerOptionCRadiobuttonFour = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ4C_ID;
                                    selectedSubQuestionId = LikerSubQuestion4_ID;
                                }

                                else if (SubQuestion4_AnswerData[0].exam_answer == LikerOptionQ4D_ID)
                                {
                                    LikerOptionDRadiobuttonFour = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ4D_ID;
                                    selectedSubQuestionId = LikerSubQuestion4_ID;
                                }
                                else if (SubQuestion4_AnswerData[0].exam_answer == LikerOptionQ4E_ID)
                                {
                                    LikerOptionERadiobuttonFour = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ4E_ID;
                                    selectedSubQuestionId = LikerSubQuestion4_ID;
                                }
                                else if (SubQuestion4_AnswerData[0].exam_answer == LikerOptionQ4F_ID)
                                {
                                    LikerOptionFRadiobuttonFour = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ4F_ID;
                                    selectedSubQuestionId = LikerSubQuestion4_ID;
                                }

                            }
                        }
                        #endregion
                    }
                    if (_resSubQuestion.Count >= 5)
                    {
                        #region Sub Question 5 Answer Bind
                        var SubQuestion5_AnswerData = _localDB.Get_PRO_SubQuestionAnswers(_questiondata.id.ToString(), _resSubQuestion[4].subquestion_id);
                        if (SubQuestion5_AnswerData != null && SubQuestion5_AnswerData.Count != 0)
                        {
                            if (!string.IsNullOrEmpty(SubQuestion5_AnswerData[0].exam_answer) && SubQuestion5_AnswerData[0].exam_answer != "0")
                            {
                                if (SubQuestion5_AnswerData[0].exam_answer == LikerOptionQ5A_ID)
                                {
                                    LikerOptionARadiobuttonFive = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ5A_ID;
                                    selectedSubQuestionId = LikerSubQuestion5_ID;
                                }
                                else if (SubQuestion5_AnswerData[0].exam_answer == LikerOptionQ5B_ID)
                                {
                                    LikerOptionBRadiobuttonFive = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ5B_ID;
                                    selectedSubQuestionId = LikerSubQuestion5_ID;
                                }
                                else if (SubQuestion5_AnswerData[0].exam_answer == LikerOptionQ5C_ID)
                                {
                                    LikerOptionCRadiobuttonFive = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ5C_ID;
                                    selectedSubQuestionId = LikerSubQuestion5_ID;
                                }

                                else if (SubQuestion5_AnswerData[0].exam_answer == LikerOptionQ5D_ID)
                                {
                                    LikerOptionDRadiobuttonFive = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ5D_ID;
                                    selectedSubQuestionId = LikerSubQuestion5_ID;
                                }
                                else if (SubQuestion5_AnswerData[0].exam_answer == LikerOptionQ5E_ID)
                                {
                                    LikerOptionERadiobuttonFive = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ5E_ID;
                                    selectedSubQuestionId = LikerSubQuestion5_ID;
                                }
                                else if (SubQuestion5_AnswerData[0].exam_answer == LikerOptionQ5F_ID)
                                {
                                    LikerOptionFRadiobuttonFive = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ5F_ID;
                                    selectedSubQuestionId = LikerSubQuestion5_ID;
                                }

                            }
                        }
                        #endregion
                    }
                    if (_resSubQuestion.Count >= 6)
                    {
                        #region Sub Question 6 Answer Bind
                        var SubQuestion6_AnswerData = _localDB.Get_PRO_SubQuestionAnswers(_questiondata.id.ToString(), _resSubQuestion[5].subquestion_id);
                        if (SubQuestion6_AnswerData != null)
                        {
                            if (!string.IsNullOrEmpty(SubQuestion6_AnswerData[0].exam_answer) && SubQuestion6_AnswerData[0].exam_answer != "0")
                            {
                                if (SubQuestion6_AnswerData[0].exam_answer == LikerOptionQ6A_ID)
                                {
                                    LikerOptionARadiobuttonSix = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ6A_ID;
                                    selectedSubQuestionId = LikerSubQuestion6_ID;
                                }
                                else if (SubQuestion6_AnswerData[0].exam_answer == LikerOptionQ6B_ID)
                                {
                                    LikerOptionBRadiobuttonSix = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ6B_ID;
                                    selectedSubQuestionId = LikerSubQuestion6_ID;
                                }
                                else if (SubQuestion6_AnswerData[0].exam_answer == LikerOptionQ6C_ID)
                                {
                                    LikerOptionCRadiobuttonSix = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ6C_ID;
                                    selectedSubQuestionId = LikerSubQuestion6_ID;
                                }

                                else if (SubQuestion6_AnswerData[0].exam_answer == LikerOptionQ6D_ID)
                                {
                                    LikerOptionDRadiobuttonSix = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ6D_ID;
                                    selectedSubQuestionId = LikerSubQuestion6_ID;
                                }
                                else if (SubQuestion6_AnswerData[0].exam_answer == LikerOptionQ6E_ID)
                                {
                                    LikerOptionERadiobuttonSix = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ6E_ID;
                                    selectedSubQuestionId = LikerSubQuestion6_ID;
                                }
                                else if (SubQuestion6_AnswerData[0].exam_answer == LikerOptionQ6F_ID)
                                {
                                    LikerOptionFRadiobuttonSix = (string)Application.Current.Resources["DotCheckedRadioButton"];
                                    selectedOptionId = LikerOptionQ6F_ID;
                                    selectedSubQuestionId = LikerSubQuestion6_ID;
                                }

                            }
                        }
                        #endregion
                    }
                }

              
                #endregion
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "PRO_ExamViewModel.LikertQuestionConfiguration");
            }
        }
        #endregion

        #region Liker Commmands
        private async void DoLikerAnswer(object sender)
        {
            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
            if (isNetworkAvailable)
            {
                #region Likert Option Click Events
                if (sender.ToString() == "tpgQ1OptionA")
                {
                    LikerOptionARadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ1A_ID, LikerSubQuestion1_ID);

                }
                else if (sender.ToString() == "tpgQ1OptionB")
                {
                    LikerOptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ1B_ID, LikerSubQuestion1_ID);
                }
                else if (sender.ToString() == "tpgQ1OptionC")
                {
                    LikerOptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ1C_ID, LikerSubQuestion1_ID);
                }
                else if (sender.ToString() == "tpgQ1OptionD")
                {
                    LikerOptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ1D_ID, LikerSubQuestion1_ID);

                }
                else if (sender.ToString() == "tpgQ1OptionE")
                {
                    LikerOptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionFRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ1E_ID, LikerSubQuestion1_ID);
                }
                else if (sender.ToString() == "tpgQ1OptionF")
                {
                    LikerOptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LoadLikertEventLogData(LikerOptionQ1F_ID, LikerSubQuestion1_ID);
                }






                else if (sender.ToString() == "tpgQ2OptionA")
                {
                    LikerOptionARadiobuttontwo = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionBRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ2A_ID, LikerSubQuestion2_ID);

                }
                else if (sender.ToString() == "tpgQ2OptionB")
                {
                    LikerOptionARadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttontwo = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionCRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ2B_ID, LikerSubQuestion2_ID);
                }
                else if (sender.ToString() == "tpgQ2OptionC")
                {
                    LikerOptionARadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttontwo = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionDRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ2C_ID, LikerSubQuestion2_ID);

                }
                else if (sender.ToString() == "tpgQ2OptionD")
                {
                    LikerOptionARadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttontwo = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionERadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ2D_ID, LikerSubQuestion2_ID);
                }
                else if (sender.ToString() == "tpgQ2OptionE")
                {
                    LikerOptionARadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttontwo = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionFRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ2E_ID, LikerSubQuestion2_ID);
                }
                else if (sender.ToString() == "tpgQ2OptionF")
                {
                    LikerOptionARadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttontwo = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttontwo = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LoadLikertEventLogData(LikerOptionQ2F_ID, LikerSubQuestion2_ID);
                }





                else if (sender.ToString() == "tpgQ3OptionA")
                {
                    LikerOptionARadiobuttonthree = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionBRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ3A_ID, LikerSubQuestion3_ID);
                }
                else if (sender.ToString() == "tpgQ3OptionB")
                {
                    LikerOptionARadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttonthree = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionCRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ3B_ID, LikerSubQuestion3_ID);
                }
                else if (sender.ToString() == "tpgQ3OptionC")
                {
                    LikerOptionARadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttonthree = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionDRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ3C_ID, LikerSubQuestion3_ID);
                }
                else if (sender.ToString() == "tpgQ3OptionD")
                {
                    LikerOptionARadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttonthree = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionERadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ3D_ID, LikerSubQuestion3_ID);
                }
                else if (sender.ToString() == "tpgQ3OptionE")
                {
                    LikerOptionARadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttonthree = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionFRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ3E_ID, LikerSubQuestion3_ID);
                }
                else if (sender.ToString() == "tpgQ3OptionF")
                {
                    LikerOptionARadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttonthree = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttonthree = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LoadLikertEventLogData(LikerOptionQ3F_ID, LikerSubQuestion3_ID);
                }





                else if (sender.ToString() == "tpgQ4OptionA")
                {
                    LikerOptionARadiobuttonFour = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionBRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ4A_ID, LikerSubQuestion4_ID);
                }
                else if (sender.ToString() == "tpgQ4OptionB")
                {
                    LikerOptionARadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttonFour = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionCRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ4B_ID, LikerSubQuestion4_ID);
                }
                else if (sender.ToString() == "tpgQ4OptionC")
                {
                    LikerOptionARadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttonFour = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionDRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ4C_ID, LikerSubQuestion4_ID);
                }
                else if (sender.ToString() == "tpgQ4OptionD")
                {
                    LikerOptionARadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttonFour = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionERadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ4D_ID, LikerSubQuestion4_ID);
                }
                else if (sender.ToString() == "tpgQ4OptionE")
                {
                    LikerOptionARadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttonFour = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionFRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ4E_ID, LikerSubQuestion4_ID);
                }
                else if (sender.ToString() == "tpgQ4OptionF")
                {
                    LikerOptionARadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttonFour = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttonFour = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LoadLikertEventLogData(LikerOptionQ4F_ID, LikerSubQuestion4_ID);
                }


                else if (sender.ToString() == "tpgQ5OptionA")
                {
                    LikerOptionARadiobuttonFive = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionBRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ5A_ID, LikerSubQuestion5_ID);
                }
                else if (sender.ToString() == "tpgQ5OptionB")
                {
                    LikerOptionARadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttonFive = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionCRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ5B_ID, LikerSubQuestion5_ID);
                }
                else if (sender.ToString() == "tpgQ5OptionC")
                {
                    LikerOptionARadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttonFive = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionDRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ5C_ID, LikerSubQuestion5_ID);
                }
                else if (sender.ToString() == "tpgQ5OptionD")
                {
                    LikerOptionARadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttonFive = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionERadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ5D_ID, LikerSubQuestion5_ID);
                }
                else if (sender.ToString() == "tpgQ5OptionE")
                {
                    LikerOptionARadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttonFive = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionFRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ5E_ID, LikerSubQuestion5_ID);
                }
                else if (sender.ToString() == "tpgQ5OptionF")
                {
                    LikerOptionARadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttonFive = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttonFive = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LoadLikertEventLogData(LikerOptionQ5F_ID, LikerSubQuestion5_ID);
                }






                else if (sender.ToString() == "tpgQ6OptionA")
                {
                    LikerOptionARadiobuttonSix = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionBRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ6A_ID, LikerSubQuestion6_ID);
                }
                else if (sender.ToString() == "tpgQ6OptionB")
                {
                    LikerOptionARadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttonSix = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionCRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ6B_ID, LikerSubQuestion6_ID);
                }
                else if (sender.ToString() == "tpgQ6OptionC")
                {
                    LikerOptionARadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttonSix = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionDRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ6C_ID, LikerSubQuestion6_ID);
                }
                else if (sender.ToString() == "tpgQ6OptionD")
                {
                    LikerOptionARadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttonSix = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionERadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ6D_ID, LikerSubQuestion6_ID);
                }
                else if (sender.ToString() == "tpgQ6OptionE")
                {
                    LikerOptionARadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttonSix = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LikerOptionFRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LoadLikertEventLogData(LikerOptionQ6E_ID, LikerSubQuestion6_ID);
                }
                else if (sender.ToString() == "tpgQ6OptionF")
                {
                    LikerOptionARadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionBRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionCRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionDRadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionERadiobuttonSix = (string)Application.Current.Resources["RadioButtonIcon"];
                    LikerOptionFRadiobuttonSix = (string)Application.Current.Resources["DotCheckedRadioButton"];
                    LoadLikertEventLogData(LikerOptionQ6F_ID, LikerSubQuestion6_ID);
                }
                #endregion
            }
            else
            {
                await  UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
            }
        }
        #endregion

        #region PRO_Configurations
        public void PRO_Configurations()
        {
            try
            {
                //Show and Hide Camera
                if (_TestPinMasterData.is_image_proctering == Convert.ToString((int)Is_image_proctering.Enable))
                {
                    IsShowCameraPreView = true;
                }
                else
                {
                    IsShowCameraPreView = false;
                }

                
                //IsShowCameraPreView = false;
                //  Show and Hide Previous Button
                if (_TestPinMasterData.is_previous == Convert.ToString((int)is_previous.Enable))
                {
                    Ispreviousbtn = true;
                }
                else
                {
                    Ispreviousbtn = false;
                }

                // Show and Hide Question Pallet
                if (_TestPinMasterData.is_question_pallete == Convert.ToString((int)is_question_pallete.Enable) && _TestPinMasterData.is_section_navigation == Convert.ToString((int)is_section_navigation.Enable))
                {
                    IsQuestionPalletVisible = true;
                }
                else
                {
                    IsQuestionPalletVisible = false;
                }
                //back button
                if (_TestPinMasterData.is_section_navigation == Convert.ToString((int)is_section_navigation.Enable))
                {
                    IsVisibleGoBackButton = true;
                }
                else
                {
                    IsVisibleGoBackButton = false;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                // await UserDialogs.Instance.AlertAsync("Error"+ ex.Message);
                SendErrorMessageToServer(ex, "PRO_ExamViewModel.PRO_Configurations");
            }
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        #region GeneratePageNumbers
        public void GeneratePageNumbers()
        {
            if (lastindex != 0)
            {
                int NoOfRows = lastindex;
                Button gridbutton = new Button();

                Grid grid = new Grid();
                int childrenCount = DynamicBtnStack.Children.Count;

                if (childrenCount > 1)
                    DynamicBtnStack.Children.RemoveAt(1);


                grid.VerticalOptions = LayoutOptions.Start;
                grid.HorizontalOptions = LayoutOptions.Fill;
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
                int count = 0;
                for (int r = 0; r < 1; r++)
                {
                    grid.RowDefinitions.Add(new RowDefinition { Height = 40 });
                    for (int c = 0; c < NoOfRows; c++)
                    {
                        if (NoOfRows > count)
                        {
                            count++;
                            if (Device.Idiom == TargetIdiom.Phone)
                            {
                                gridbutton = new Button
                                {
                                    Text = count.ToString(),
                                    TextColor = Color.Black,
                                    ClassId = count.ToString(),
                                    FontSize = 12,
                                    WidthRequest = 53,
                                    BackgroundColor = Color.Gray
                                };
                            }
                            else if (Device.Idiom == TargetIdiom.Tablet)
                            {
                                gridbutton = new Button
                                {
                                    Text = count.ToString(),
                                    TextColor = Color.Black,
                                    ClassId = count.ToString(),
                                    FontSize = 18,
                                    WidthRequest = 60
                                };
                            }
                            gridbutton.SetBinding(Button.BackgroundColorProperty, "ButtonColor" + gridbutton.Text);
                            gridbutton.Clicked += Question_Pallete_Button_Clicked;
                            grid.Children.Add(gridbutton);
                            DynamicBtnStack.Children.Add(grid);
                            Grid.SetRow(gridbutton, r);
                            Grid.SetColumn(gridbutton, c);


                            //Device.BeginInvokeOnMainThread(async () =>
                            //{
                            //    await DynamciButtonScrollView.ScrollToAsync(0, 0, true);
                            //});
                        }
                    }
                }
            }

        }
        #endregion

        #region Sequence Button Click Event
        private async void Question_Pallete_Button_Clicked(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            string text = (string)button.Text;
            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
            if (isNetworkAvailable)
            {
                bool responseFlag = await UpdateEventLog(true);
                if (responseFlag)
                {
                    ChangeButtonColorSwitch(CurrentQue);
                    CurrentQue = int.Parse(text);
                    SectionCurrentQue = CurrentQue;
                    CurrentPosition = int.Parse(text) - 1;

                    var data = ListViewItemSource.ElementAt(CurrentPosition);
                    SelectedSectionID = data.section_id;

                    var timerdata = _localDB.GetPROSectionTimerBySectionID(SelectedSectionID);
                    SectionCurrentIndex = timerdata.ID;
                    LoadQuestions(false);
                }
            }
            else
            {
                TimerStop();
                await  UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
            }
        }
        #endregion

        #region Command Operation
        private async void DoOperation(string obj)
        {
            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
            if (isNetworkAvailable)
            {
                switch (obj)
                {
                    #region Previous Button Click Event
                    case "previousCommand":
                        if (isClicked)
                        {
                            isClicked = false;
                            try
                            {
                                bool responseFlag = await UpdateEventLog(true);
                                if (responseFlag)
                                {
                                    ChangeButtonColorSwitch(CurrentQue);
                                    CurrentPosition -= 1;
                                    CurrentQue -= 1;
                                    if (SectionCurrentQue == 1)
                                    {
                                         
                                            var temp_sec_index = SectionCurrentIndex;
                                            SectionCurrentIndex = SectionCurrentIndex - 1;

                                            if (_TestPinMasterData.is_section_navigation == Convert.ToString((int)is_section_navigation.Disable)
                                                           && _TestPinMasterData.duration_type == Convert.ToString((int)duration_type.SectionDuration))
                                            {

                                                var returnvalue = CheckExamStatus("previous", SectionCurrentIndex);
                                                if (returnvalue != "E")
                                                {
                                                    //Check all the previous section, if any one of the section not in "E" status mean, navigate to those section
                                                    //CallBackPage("previous");
                                                    NewSectionFirstQuestion("previous");
                                                }
                                                else
                                                {
                                                    //Check all the previous section, if everything is in "E" status mean, displaying previous section elapsed message
                                                    SectionCurrentIndex = temp_sec_index;
                                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.SectionTimeOutMessageForPreviousSection);
                                                }
                                            }
                                            else
                                            {
                                                NewSectionFirstQuestion("previous");
                                            }
                                    }
                                    else
                                    {
                                        SectionCurrentQue -= 1;
                                        LoadQuestions(false);
                                    }
                                } 
                            }
                            catch (Exception ex)
                            {
                                System.Diagnostics.Debug.WriteLine(ex.Message);
                                SendErrorMessageToServer(ex, "PRO_ExamViewModel.DoOperation.previousCommand");
                            }
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(500);
                            isClicked = true;
                        });
                        break;
                    #endregion

                    #region Next Button Click Event
                    case "nextCommand":
                        if (isClicked)
                        {
                            isClicked = false;
                            try
                            {
                                if (SectionCurrentQue < SectionLastIndex)
                                {
                                    bool responseFlag = await UpdateEventLog(true);
                                    if (responseFlag)
                                    {
                                        ChangeButtonColorSwitch(CurrentQue);
                                        CurrentPosition += 1;
                                        CurrentQue += 1;
                                        SectionCurrentQue += 1;
                                        LoadQuestions(false);
                                    }
                                }
                                else
                                {
                                    //its perform when submit button occurs
                                    if (btnNextAndSubmit == " Submit ")
                                    {
                                        bool returnFlag = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.FinishTheSection, string.Empty, "OK", "CANCEL");
                                        if (returnFlag)
                                        {
                                            _localDB.UpdateSectionStatusEndTimeBySectionid(SelectedSectionID, "C", ServerTimerText, ElapsedSeconds.ToString());

                                            bool responseFlag = await UpdateEventLog(true);
                                            if (responseFlag)
                                            {
                                                if (_TestPinMasterData.is_section_navigation == Convert.ToString((int)is_section_navigation.Enable))
                                                {
                                                    //section navigation =1 (Have section page), Duration type = 1(Exam based timer) and 2(Section based timer), 
                                                    GoBackSectionPage();
                                                }
                                                else
                                                {
                                                    //section navigation =0 (Don't Have section page), Duration type = 1(exam based timer) and 2(Section based timer), 
                                                    //Auto load next section details
                                                    List<tbl_timer> tbl_Timers = _localDB.GetAllPROSectionTimerList();
                                                    if (tbl_Timers.Count > 0)
                                                    {
                                                        if (SectionCurrentIndex < tbl_Timers.Count)
                                                        {
                                                            _localDB.UpdateSectionStatusEndTimeBySectionid(SelectedSectionID, "C", ServerTimerText, ElapsedSeconds.ToString());
                                                            var temp_sec_index = SectionCurrentIndex;
                                                            SectionCurrentIndex = SectionCurrentIndex + 1;

                                                            if (_TestPinMasterData.is_section_navigation == Convert.ToString((int)is_section_navigation.Disable)
                                                                && _TestPinMasterData.duration_type == Convert.ToString((int)duration_type.SectionDuration))
                                                            {
                                                                // Duration type =  2(Section based timer),
                                                                var returnvalue = CheckExamStatus("next", SectionCurrentIndex);
                                                                if (returnvalue != "E")
                                                                {
                                                                    CurrentPosition += 1;
                                                                    CurrentQue += 1;
                                                                    SectionCurrentQue += 1;
                                                                    NewSectionFirstQuestion("next");
                                                                    // CallBackPage("next");
                                                                }
                                                                else
                                                                {
                                                                    //check all the next upcoming sections, if all are in "E" status mean, display next section time elapsed
                                                                    SectionCurrentIndex = temp_sec_index;
                                                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.SectionTimeOutMessageForNextSection);
                                                                  
                                                                }
                                                            }
                                                            else
                                                            {
                                                                // Duration type =  1(Exam based timer),
                                                                CurrentPosition += 1;
                                                                CurrentQue += 1;
                                                                SectionCurrentQue += 1;
                                                                // CallBackPage("next");
                                                                NewSectionFirstQuestion("next");
                                                            }
                                                        }
                                                        else if (SectionCurrentIndex == tbl_Timers.Count)
                                                        {
                                                            //ExamDuratoin, we have only one submit button for Last Section, Se we show here End Test Button.
                                                           if(_TestPinMasterData.is_section_navigation == Convert.ToString((int)is_section_navigation.Disable)
                                                             && _TestPinMasterData.duration_type == Convert.ToString((int)duration_type.ExamDuration))
                                                            {
                                                                IsVisibleFinishButton = true;
                                                            }

                                                            AllSectionCompltedInternallShowEndTestButton();
                                                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.PRO_FinishExamusingEndTestButton);

                                                            SectionCurrentIndex = 1;
                                                            CurrentPosition = -1;
                                                            CurrentQue = CurrentPosition + 1;
                                                            SectionCurrentQue = 0;
                                                            var returnvalue = CheckExamStatus("next", SectionCurrentIndex);
                                                            if (returnvalue != "E")
                                                            {
                                                                CurrentPosition += 1;
                                                                CurrentQue = CurrentPosition + 1;
                                                                SectionCurrentQue += 1;

                                                                //IsRightArrowIconVisibile = true;
                                                                //btnNextAndSubmit = " Next ";
                                                                //NextButtonColor = "#8fc740";

                                                                // CallBackPage("next");
                                                                NewSectionFirstQuestion("next");
                                                            }

                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        SectionCurrentIndex = SectionCurrentIndex + 1;
                                        CurrentPosition += 1;
                                        CurrentQue += 1;
                                        SectionCurrentQue += 1;
                                        // CallBackPage("next");
                                        NewSectionFirstQuestion("next");
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                System.Diagnostics.Debug.WriteLine(ex.Message);
                                SendErrorMessageToServer(ex, "PRO_ExamViewModel.DoOperation.nextCommand");
                            }
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(500);
                            isClicked = true;
                        });
                        break;
                    #endregion

                    #region MCQ Options List
                    case "tpgOptionA":
                        if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Single_Slection))
                        {
                            OptionA_Button = (string)Application.Current.Resources["DotCheckedRadioButton"];
                            OptionB_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionC_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionD_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionE_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionF_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            selectedOptionId = optionA_ID.ToString();

                        }
                        else
                        {
                            if (OptionA_Button == (string)Application.Current.Resources["CheckBoxUnSelected"])
                            {
                                OptionA_Button = (string)Application.Current.Resources["CheckBoxSelected"];
                                IsCheckedOptionA = optionA_ID.ToString();
                            }
                            else if (OptionA_Button == (string)Application.Current.Resources["CheckBoxSelected"])
                            {
                                OptionA_Button = (string)Application.Current.Resources["CheckBoxUnSelected"];
                                IsCheckedOptionA = string.Empty;
                            }
                        }

                        await UpdateEventLogInSQLite();
                        break;
                    case "tpgOptionB":
                        if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Single_Slection))
                        {
                            OptionA_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionB_Button = (string)Application.Current.Resources["DotCheckedRadioButton"];
                            OptionC_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionD_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionE_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionF_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            selectedOptionId = optionB_ID.ToString();

                        }
                        else
                        {
                            if (OptionB_Button == (string)Application.Current.Resources["CheckBoxUnSelected"])
                            {
                                OptionB_Button = (string)Application.Current.Resources["CheckBoxSelected"];
                                IsCheckedOptionB = optionB_ID.ToString();
                            }
                            else if (OptionB_Button == (string)Application.Current.Resources["CheckBoxSelected"])
                            {
                                OptionB_Button = (string)Application.Current.Resources["CheckBoxUnSelected"];
                                IsCheckedOptionB = string.Empty;
                            }
                        }
                        await UpdateEventLogInSQLite();

                        break;
                    case "tpgOptionC":
                        if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Single_Slection))
                        {
                            OptionA_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionB_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionC_Button = (string)Application.Current.Resources["DotCheckedRadioButton"];
                            OptionD_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionE_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionF_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            selectedOptionId = optionC_ID.ToString();

                        }
                        else
                        {
                            if (OptionC_Button == (string)Application.Current.Resources["CheckBoxUnSelected"])
                            {
                                OptionC_Button = (string)Application.Current.Resources["CheckBoxSelected"];
                                IsCheckedOptionC = optionC_ID.ToString();
                            }
                            else if (OptionC_Button == (string)Application.Current.Resources["CheckBoxSelected"])
                            {
                                OptionC_Button = (string)Application.Current.Resources["CheckBoxUnSelected"];
                                IsCheckedOptionC = string.Empty;
                            }
                        }
                        await UpdateEventLogInSQLite();
                        break;
                    case "tpgOptionD":
                        if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Single_Slection))
                        {
                            OptionA_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionB_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionC_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionD_Button = (string)Application.Current.Resources["DotCheckedRadioButton"];
                            OptionE_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionF_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            selectedOptionId = optionD_ID.ToString();

                        }
                        else
                        {
                            if (OptionD_Button == (string)Application.Current.Resources["CheckBoxUnSelected"])
                            {
                                OptionD_Button = (string)Application.Current.Resources["CheckBoxSelected"];
                                IsCheckedOptionD = optionD_ID.ToString();
                            }
                            else if (OptionD_Button == (string)Application.Current.Resources["CheckBoxSelected"])
                            {
                                OptionD_Button = (string)Application.Current.Resources["CheckBoxUnSelected"];
                                IsCheckedOptionD = string.Empty;
                            }
                        }
                        await UpdateEventLogInSQLite();
                        break;
                    case "tpgOptionE":
                        if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Single_Slection))
                        {
                            OptionA_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionB_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionC_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionD_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionE_Button = (string)Application.Current.Resources["DotCheckedRadioButton"];
                            OptionF_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            selectedOptionId = optionE_ID.ToString();

                        }
                        else
                        {
                            if (OptionE_Button == (string)Application.Current.Resources["CheckBoxUnSelected"])
                            {
                                OptionE_Button = (string)Application.Current.Resources["CheckBoxSelected"];
                                IsCheckedOptionE = optionE_ID.ToString();
                            }
                            else if (OptionE_Button == (string)Application.Current.Resources["CheckBoxSelected"])
                            {
                                OptionE_Button = (string)Application.Current.Resources["CheckBoxUnSelected"];
                                IsCheckedOptionE = string.Empty;
                            }
                        }
                        await UpdateEventLogInSQLite();
                        break;
                    case "tpgOptionF":
                        if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Single_Slection))
                        {
                            OptionA_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionB_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionC_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionD_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionE_Button = (string)Application.Current.Resources["RadioButtonIcon"];
                            OptionF_Button = (string)Application.Current.Resources["DotCheckedRadioButton"];
                            selectedOptionId = optionF_ID.ToString();
                        }
                        else
                        {
                            if (OptionF_Button == (string)Application.Current.Resources["CheckBoxUnSelected"])
                            {
                                OptionF_Button = (string)Application.Current.Resources["CheckBoxSelected"];
                                IsCheckedOptionF = optionF_ID.ToString();
                            }
                            else if (OptionF_Button == (string)Application.Current.Resources["CheckBoxSelected"])
                            {
                                OptionF_Button = (string)Application.Current.Resources["CheckBoxUnSelected"];
                                IsCheckedOptionF = optionF_ID.ToString();
                            }
                        }
                        await UpdateEventLogInSQLite();
                        break;
                    #endregion

                    case "backCommand":
                        if (isClicked)
                        {
                            isClicked = false;
                            bool responseFlag = await UpdateEventLog(false);
                            if (responseFlag)
                            {
                                bool returnFlag = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.FinishTheSection, string.Empty, "OK", "CANCEL");
                                if (returnFlag)
                                {
                                    GoBackSectionPage();
                                }
                                else
                                {
                                    TimerStart();
                                }
                            }
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(500);
                            isClicked = true;
                        });
                        break;

                    case "tpgShowCameraPreviewCommand":
                        if (isClicked)
                        {
                            isClicked = false;
                            if (IsShowUserProfile == true)
                            {
                                ArrowChange = (string)Application.Current.Resources["DownArrowIcon"];
                                IsShowUserProfile = false;
                            }
                            else if (IsShowUserProfile == false)
                            {
                                ArrowChange = (string)Application.Current.Resources["UpArrowIcon"];
                                IsShowUserProfile = true;
                            }
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(500);
                            isClicked = true;
                        });
                        break;
                    case "tpgHintStack":
                        AppPreferences.HintStack = "HintVisited";
                        await Application.Current.SavePropertiesAsync();
                        IsHintStack = false;
                        break;

                    #region iconselect Button Click Event
                    case "iconselect":
                        if (isClicked)
                        {
                            isClicked = false;
                            
                            if(!string.IsNullOrEmpty(AppPreferences.SectionInstruction))
                            {
                                await PopupNavigation.PushAsync(new PRO_PoupExamInstructionPage(true));
                            }
                            else
                            {
                                await PopupNavigation.PushAsync(new PRO_PoupExamInstructionPage(false));
                            }

                            

                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(500);
                            isClicked = true;
                        });
                        break;
                    #endregion

                    #region FinishTheExam
                    case "FinishTheExam":
                        if (isClicked)
                        {
                            isClicked = false;
                            await FinishEntireExam();
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(500);
                            isClicked = true;
                        });
                        break;
                    #endregion

                    #region Image Zoom Tap Event
                    case "tpgQuestions":
                        var page = new ZoomImageViewPage(Question);
                        await PopupNavigation.PushAsync(page);
                        break;
                    case "tpgZoomOptionA":
                        var pageA = new ZoomImageViewPage(OptionA);
                        await PopupNavigation.PushAsync(pageA);
                        break;
                    case "tpgZoomOptionB":
                        var pageB = new ZoomImageViewPage(OptionB);
                        await PopupNavigation.PushAsync(pageB);
                        break;
                    case "tpgZoomOptionC":
                        var pageC = new ZoomImageViewPage(OptionC);
                        await PopupNavigation.PushAsync(pageC);
                        break;
                    case "tpgZoomOptionD":
                        var pageD = new ZoomImageViewPage(OptionD);
                        await PopupNavigation.PushAsync(pageD);
                        break;
                    case "tpgZoomOptionE":
                        var pageE = new ZoomImageViewPage(OptionE);
                        await PopupNavigation.PushAsync(pageE);
                        break;
                    case "tpgZoomOptionF":
                        var pageF = new ZoomImageViewPage(OptionF);
                        await PopupNavigation.PushAsync(pageF);
                        break;
                    #endregion


                    #region Psychometric SubQuestions Click Event                     case "tpgQuestion1":                         PsyFAQuestion1 = (string)Application.Current.Resources["DotCheckedRadioButton"];                         PsyFAQuestion2 = (string)Application.Current.Resources["RadioButtonIcon"];

                     //   QuestionOneRadioColor = Color.FromHex("#B3E27C");                       //  QuestionOneTextColor = Color.FromHex("#B3E27C");                      //   QuestionTwoRadioColor = Color.Black;                      //   QuestionTwoTextColor = Color.Black;
                        selectedBehaviouralQuestion = "A";
                        selectedOption = string.Empty;
                        _localDB.UpdateExamAnswerAssessmentAnswerTableByQuestionID(_questiondata.id.ToString());                         selectedSubQuestionId = SubQuestionList[0].subquestion_id.ToString();                         OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                         OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                         OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                         OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                         OptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                         break;                     case "tpgQuestion2":                         PsyFAQuestion1 = (string)Application.Current.Resources["RadioButtonIcon"];                         PsyFAQuestion2 = (string)Application.Current.Resources["DotCheckedRadioButton"];

                    //    QuestionOneRadioColor = Color.Black;                     //    QuestionOneTextColor = Color.Black;                     //    QuestionTwoRadioColor = Color.FromHex("#B3E27C");                     //    QuestionTwoTextColor = Color.FromHex("#B3E27C");
                        selectedBehaviouralQuestion = "B";                         selectedOption = string.Empty;
                        _localDB.UpdateExamAnswerAssessmentAnswerTableByQuestionID(_questiondata.id.ToString());                         selectedSubQuestionId = SubQuestionList[1].subquestion_id.ToString();                         OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                         OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                         OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                         OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                         OptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                         break;
                    #endregion 
                    #region Psychometric Option Tap Command                     case "behaviourtpgOptionA":                         if ( IsSelectedBehaviouralQuestion())                         {                             OptionARadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];                             OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                             OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                             OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                             OptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                             selectedOptionId = SubQuestionOptionsList[0].id.ToString();
                            selectedOption = "A";
                           await UpdateEventLogInSQLite();     
                        }                          break;                     case "behaviourtpgOptionB":                         if (IsSelectedBehaviouralQuestion())                         {                             OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                             OptionBRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];                             OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                             OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                             OptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];
                            selectedOptionId = SubQuestionOptionsList[1].id.ToString();
                            selectedOption = "B";
                            await UpdateEventLogInSQLite();                         }                         break;                     case "behaviourtpgOptionC":                         if (IsSelectedBehaviouralQuestion())                         {                             OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                             OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                             OptionCRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];                             OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                             OptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                             selectedOptionId = SubQuestionOptionsList[2].id.ToString();
                            selectedOption = "C";
                            await UpdateEventLogInSQLite();                         }                         break;                     case "behaviourtpgOptionD":                         if (IsSelectedBehaviouralQuestion())                         {                             OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                             OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                             OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                             OptionDRadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];                             OptionERadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                             selectedOptionId = SubQuestionOptionsList[3].id.ToString();
                            selectedOption = "D";
                            await UpdateEventLogInSQLite();                         }                         break;                     case "behaviourtpgOptionE":                         if (IsSelectedBehaviouralQuestion())                         {                             OptionARadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                             OptionBRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                             OptionCRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                             OptionDRadiobutton = (string)Application.Current.Resources["RadioButtonIcon"];                             OptionERadiobutton = (string)Application.Current.Resources["DotCheckedRadioButton"];                             selectedOptionId = SubQuestionOptionsList[4].id.ToString();
                            selectedOption = "E";
                            await UpdateEventLogInSQLite();                         }                         break;
                        #endregion


                }
            }
            else
            {
                TimerStop();
                await  UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
            }
        }
        #endregion

        #region CheckExamStatus
        public string CheckExamStatus(string value, int currentIndex)
        {
            string retrun_value = "";
            if (value == "next")
            {
                //It will working for jumping purpose. example 1st section to 3rd section, 2nd section to last 5th section
                    var totalSection = _localDB.GetAllPROSectionTimerList();
                for (int i = currentIndex; i <= totalSection.Count; i++)
                {
                    var obj = _localDB.GetPROSectionDetailsByID(i);
                    if (obj.examstatus == "E")
                    {
                        SectionCurrentIndex = SectionCurrentIndex + 1;
                        CurrentPosition = CurrentPosition + Convert.ToInt32(obj.sectioncount);
                        CurrentQue = CurrentPosition + 1;
                        retrun_value = obj.examstatus;
                    }
                    else
                    {
                        retrun_value = obj.examstatus;
                        break;
                    }
                }
            }
            else if (value == "previous")
            {
             
                for (int i = currentIndex; i >= 1; i--)
                {
                    var obj = _localDB.GetPROSectionDetailsByID(i);
                    if (obj.examstatus == "E")
                    {
                        SectionCurrentIndex = SectionCurrentIndex - 1;
                        CurrentPosition = CurrentPosition - Convert.ToInt32(obj.sectioncount);
                        CurrentQue = CurrentPosition + 1;
                        retrun_value = obj.examstatus;
                    }
                    else
                    {
                        retrun_value = obj.examstatus;
                        break;
                    }
                }
            }
            return retrun_value;
        }
        #endregion


        #region IsSelectedBehaviouralQuestion
        public bool IsSelectedBehaviouralQuestion()
        {
            if (!string.IsNullOrEmpty(selectedBehaviouralQuestion))
            {
                return true;
            }
            else
            {
                UserDialogs.Instance.Alert(MessageStringConstants.PleaseSelectOption);
                return false;
            }
        }
        #endregion

        #region ValidateBehaviouralQuestionandOptions
        public async Task ValidateBehaviouralQuestionandOptionsAsync()
        {
            if (_questiondata.question_type == Convert.ToString((int)question_type.Behaviour) && _questiondata.is_question_mandatory == "False")
            {
                if (!string.IsNullOrEmpty(selectedBehaviouralQuestion))
                {
                    if(string.IsNullOrEmpty(selectedOption))
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.PleaseSelectAnswer);
                    }
                }
            }
        }
        #endregion

    #region Update Likert Select Option Details to SQlite
    public async void LoadLikertEventLogData(string OptionID, string subQuestionID)
        {

            selectedSubQuestionId = subQuestionID;
            selectedOptionId = OptionID;
            await UpdateEventLogInSQLite();
        }
        #endregion

        #region UpdateEvent Log in SQLite
        public async Task<bool> UpdateEventLogInSQLite()
        {
            bool responseFlag = false;
            try
            {
                if (_TestPinMasterData.is_section_navigation == Convert.ToString((int)is_section_navigation.Enable))
                {
                    _localDB.Update_Resume_Point(SelectedSectionID);
                    _localDB.Update_Resume_Point(SelectedSectionID, _questiondata.id.ToString());
                }

                if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Multi_Slection))
                {
                    selectedOptionId = GetSelectedAnswer();
                }


                if (_questiondata.question_type == Convert.ToString((int)question_type.likert))
                {
                    await _localDB.UpdateExamAnswerAssessmentLikertType(selectedOptionId, selectedSubQuestionId, _questiondata.id.ToString());
                }
                else
                {
                    await _localDB.UpdateExamAnswerAssessmentAnswerTable(selectedOptionId, selectedSubQuestionId, _questiondata.id.ToString());
                }
               
            }
            catch (Exception ex)
            {
                SendErrorMessageToServer(ex, "ProExamViewModel.UpdateEventLog");
                responseFlag = false;
            }
            return responseFlag;
        }
        #endregion

        #region UpdatePRO Event LOG API
        public async Task<bool> UpdateEventLog(bool IsStartTimer)
        {
            bool responseFlag = false;
            try
            {
                UserDialogs.Instance.ShowLoading();
                Event_LogRequestData _logRequestdata = new Event_LogRequestData();
                tbl_timer timerData = _localDB.GetPROSectionTimerBySectionID(SelectedSectionID);

                _logRequestdata.test_pin = _TestPinMasterData.testpin;
                _logRequestdata.company_id = _TestPinMasterData.company_id;
                _logRequestdata.assign_id = _TestPinMasterData.assign_id;
                _logRequestdata.login_audit_id = _TestPinMasterData.login_audit_id;
                _logRequestdata.candidate_id = _TestPinMasterData.candidate_id;
                _logRequestdata.attempt_id = _TestPinMasterData.attempt_id;
                _logRequestdata.Last_ElapsedTime = UpdateEventLogTimer;
                _logRequestdata.Resume_point = "1";
                _logRequestdata.section_id = SelectedSectionID;
                _logRequestdata.question_type = _questiondata.question_type;
                _logRequestdata.question_id = _questiondata.id.ToString();
                _logRequestdata.Sectionstatus = timerData.examstatus;

                if(!string.IsNullOrEmpty(timerData.starttime))
                {
                    _logRequestdata.section_start_time = Convert.ToDateTime(timerData.starttime).ToString("yyyy-MM-dd HH:mm:ss");
                }else
                {
                    _logRequestdata.section_start_time = timerData.starttime;
                }

                if (!string.IsNullOrEmpty(timerData.endtime))
                {
                    _logRequestdata.section_end_time = Convert.ToDateTime(timerData.endtime).ToString("yyyy-MM-dd HH:mm:ss");
                }
                else
                {
                    _logRequestdata.section_end_time = timerData.endtime;
                }
                    // _logRequestdata.section_start_time = timerData.starttime;
                    
                
                
                #region get exam data from local table
                List<Exam_Sub_Questions> listSubQuestion = new List<Exam_Sub_Questions>();
                var AnswerData = _localDB.GetAssessmentAnswersByQuestionID(_questiondata.id);
                if (AnswerData != null)
                {
                    foreach (var data in AnswerData)
                    {
                        if ((_questiondata.question_type == Convert.ToString((int)question_type.Behaviour)) || (_questiondata.question_type == Convert.ToString((int)question_type.likert)))
                        {
                            //    Exam_Sub_Questions obj = new Exam_Sub_Questions();
                            //    obj.exam_answer = data.exam_answer;
                            //    obj.question_id = _questiondata.id.ToString();
                            //obj.subquestion_id = data.sub_question_id;
                            //    listSubQuestion.Add(obj);
                            //}


                            if (_questiondata.question_type == Convert.ToString((int)question_type.Behaviour))
                            {
                                if (!string.IsNullOrEmpty(selectedBehaviouralQuestion))
                                {
                                    Exam_Sub_Questions obj = new Exam_Sub_Questions();
                                    if (data.exam_answer != "0")
                                    {
                                        obj.exam_answer = data.exam_answer;
                                        obj.question_id = _questiondata.id.ToString();
                                        obj.subquestion_id = data.sub_question_id;
                                        listSubQuestion.Add(obj);
                                    }
                                    else
                                    {
                                        UserDialogs.Instance.HideLoading();
                                        UserDialogs.Instance.Alert(MessageStringConstants.PleaseSelectOption);
                                        return false;
                                    }
                                }
                                else
                                {
                                    Exam_Sub_Questions obj = new Exam_Sub_Questions();
                                    obj.exam_answer = data.exam_answer;
                                    obj.question_id = _questiondata.id.ToString();
                                    obj.subquestion_id = data.sub_question_id;
                                    listSubQuestion.Add(obj);
                                }
                                
                            }


                            if (_questiondata.question_type == Convert.ToString((int)question_type.likert))
                            {
                                Exam_Sub_Questions obj = new Exam_Sub_Questions();
                                obj.exam_answer = data.exam_answer;
                                obj.question_id = _questiondata.id.ToString();
                                obj.subquestion_id = data.sub_question_id;
                                listSubQuestion.Add(obj);
                            }
                           
                        }
                        else
                        {
                            //_logRequestdata.question_id = _questiondata.id.ToString();
                            _logRequestdata.exam_answer = data.exam_answer;
                        }
                    if (string.IsNullOrEmpty(data.exam_answer) || data.exam_answer == "0")                         {                             _logRequestdata.Question_Palette_Enum_Id = Convert.ToString((int)Question_Palette_Enum_Id.NotAnswered);                             _localDB.Update_Question_Palette_Enum_Id(Convert.ToString((int)Question_Palette_Enum_Id.NotAnswered), _questiondata.id);                         }                         else                         {                             _logRequestdata.Question_Palette_Enum_Id = Convert.ToString((int)Question_Palette_Enum_Id.Answered);                             _localDB.Update_Question_Palette_Enum_Id(Convert.ToString((int)Question_Palette_Enum_Id.Answered), _questiondata.id);                         }                     }
                }
                _logRequestdata.subquestion = listSubQuestion;

                #endregion

             await   TimerStop();

                var result = await _commonservice.PostAsync<LogResponseData, Event_LogRequestData>(APIData.API_BASE_URL + APIMethods.Eventlog, _logRequestdata);
                UserDialogs.Instance.HideLoading();
                if (result != null)
                {
                    Debug.WriteLine(result.code + result.message);
                    if (result.code == "200")
                    {
                        if (IsStartTimer)
                        {
                            await TimerStart();
                        }
                        responseFlag = true;
                    }
                    else if (result.code == "199")
                    {
                        await TimerStop();
                        await  UserDialogs.Instance.AlertAsync(result.message);
                        Application.Current.MainPage = new NavigationPage(new PRO_TestPinPage());
                        responseFlag = false;
                    }
                    else if (result.code != "200")
                    {
                        await  UserDialogs.Instance.AlertAsync(result.message);
                        responseFlag = false;
                    }
                }
                else
                {
                    await  UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    responseFlag = false;
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "ProExamViewModel.UpdateEventLog");
                responseFlag = false;
            }
            return responseFlag;
        }
        #endregion

        #region  GetSelectedAnswer
        private string GetSelectedAnswer()
        {
            string value = string.Empty;
            try
            {
                if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Single_Slection))
                {
                    value = selectedOptionId.ToString();
                    return value;
                }
                else if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Multi_Slection))
                {
                    if (!string.IsNullOrEmpty(IsCheckedOptionA))
                    {
                        value = IsCheckedOptionA;
                    }
                    if (!string.IsNullOrEmpty(IsCheckedOptionB))
                    {
                        if (!string.IsNullOrEmpty(value))
                        {
                            value = value + "," + IsCheckedOptionB;
                        }
                        else
                        {
                            value = IsCheckedOptionB;
                        }
                    }
                    if (!string.IsNullOrEmpty(IsCheckedOptionC))
                    {
                        if (!string.IsNullOrEmpty(value))
                        {
                            value = value + "," + IsCheckedOptionC;
                        }
                        else
                        {
                            value = IsCheckedOptionC;
                        }
                    }
                    if (!string.IsNullOrEmpty(IsCheckedOptionD))
                    {
                        if (!string.IsNullOrEmpty(value))
                        {
                            value = value + "," + IsCheckedOptionD;
                        }
                        else
                        {
                            value = IsCheckedOptionD;
                        }
                    }
                    if (!string.IsNullOrEmpty(IsCheckedOptionE))
                    {
                        if (!string.IsNullOrEmpty(value))
                        {
                            value = value + "," + IsCheckedOptionE;
                        }
                        else
                        {
                            value = IsCheckedOptionE;
                        }
                    }
                    if (!string.IsNullOrEmpty(IsCheckedOptionF))
                    {
                        if (!string.IsNullOrEmpty(value))
                        {
                            value = value + "," + IsCheckedOptionF;
                        }
                        else
                        {
                            value = IsCheckedOptionF;
                        }
                    }
                    return value;
                }
                return value;
            }
            catch (Exception ex)
            {
                SendErrorMessageToServer(ex, "PRO_ExamViewModel.GetSelectedAnswer");
                return value;
            }
        }
        #endregion

        #region UpdateExamCompletedStatustoServer
        public async void UpdateExamCompletedStatustoServer()
        {
            try
            {
                Device.BeginInvokeOnMainThread(async () =>
                {
                    UserDialogs.Instance.ShowLoading();
                    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                    if (isNetworkAvailable)
                    {
                        List<ResultResponseData> _tempitemSource = new List<ResultResponseData>();
                        ResultRequestModel ResultRequestModel = new ResultRequestModel()
                        {
                            testpin = _TestPinMasterData.testpin,
                            login_audit_id = _TestPinMasterData.login_audit_id,
                            assign_id = int.Parse(_TestPinMasterData.assign_id)
                        };
                        var result = await _commonservice.PostAsync<ResultResponse, ResultRequestModel>(APIData.API_BASE_URL + APIMethods.GetScore, ResultRequestModel);

                        if (result != null)
                        {
                            UserDialogs.Instance.HideLoading();

                            if (result.code == "200")
                            {
                                if (_TestPinMasterData.is_feedback == Convert.ToString((int)is_feedback.Enable))
                                {
                                    Application.Current.MainPage = new NavigationPage(new PRO_ExamFeedbackPage(result));
                                    return;
                                }
                                else
                                {
                                    Application.Current.MainPage = new NavigationPage(new PRO_ExamCompletedPage(result));
                                    return;
                                }

                            }
                            else if (result.code == "199")
                            {
                                await  UserDialogs.Instance.AlertAsync(result.message);
                                Application.Current.MainPage = new NavigationPage(new PRO_TestPinPage());
                            }
                            else
                            {
                                
                                     await  UserDialogs.Instance.AlertAsync(result.message);
                            }
                        }
                        else
                        {
                            UserDialogs.Instance.HideLoading();
                          // var dialogResult = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.ServerBusyMessage, null, "Yes", "No");
                            //if (dialogResult)
                            //{

                            //    ShowSectionScoreList();
                            //}
                             await  UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        //IsShowScoreDetails = false;
                        //IsShowNoScoreViewVisible = true;
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                    }
                });
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "PRO_ExamViewModel.UpdateExamCompletedStatustoServer");
            }
        }
        #endregion

        #region FinishEntireExam
        async Task FinishEntireExam()
        {
            try
            {
                var result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.FinishAlertAssessment, null, "Yes", "No");
                if (result)
                {
                    await TimerStop();
                    bool responseFlag = await UpdateEventLog(false);
                    if (responseFlag)
                    {
                        UpdateExamCompletedStatustoServer();
                    }
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "PRO_ExamViewModel.CheckAllGroupAreCompletedOrNot");
            }
        }
        #endregion

        #region AllSectionCompltedInternallShowEndTestButton
        public void AllSectionCompltedInternallShowEndTestButton()
        {
            try
            {
                var totalcount = _localDB.GetAllPROSectionTimerList();
                var compltedcount = _localDB.GetCompletedCount();
                var elapsedcount =  _localDB.GetElapsedCount();
                if (totalcount != null && compltedcount != null && elapsedcount != null && (totalcount.Count == (compltedcount.Count + elapsedcount.Count)) )
                {
                    //Enable End Test Button
                    IsVisibleFinishButton = true;
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "PRO_ExamViewModel.AllSectionCompltedInternallShowEndTestButton");
            }
        }
        #endregion


        #region GoBackSctionPageWithoutEventLog
        public void GoBackSctionPageWithoutEventLog()
        {
            try
            {
                var serializedData1 = AppPreferences.TestPinGroupDetailsSerialize;
                List<SectionDetailsResponseData> deSerializedData = JsonConvert.DeserializeObject<List<SectionDetailsResponseData>>(serializedData1);
                List<SectionDetailsResponseData> objGroupDetails = new List<SectionDetailsResponseData>();
                objGroupDetails = deSerializedData;
                List<tbl_timer> tbl_Timers = _localDB.GetAllPROSectionTimerList();

                if (tbl_Timers != null && tbl_Timers.Count > 0)
                {
                    for (int i = 0; i < objGroupDetails.Count; i++)
                    {
                        for (int j = 0; j < tbl_Timers.Count; j++)
                        {
                            if (objGroupDetails[i].section_id == tbl_Timers[j].section_id)
                            {
                                if (tbl_Timers[j].examstatus == "E")      // T - timerelabsed
                                {
                                    objGroupDetails[i].section_colour = MessageStringConstants.ExamTimeElapsedColor;
                                }
                                else if (tbl_Timers[j].examstatus == "C") // C - examcomplted
                                {
                                    objGroupDetails[i].section_colour = MessageStringConstants.ExamCompletedColor;
                                }
                                else if (tbl_Timers[j].examstatus == "P") // P - examinprogress
                                {
                                    objGroupDetails[i].section_colour = MessageStringConstants.ExamProgressColor;
                                }
                                else if (tbl_Timers[j].examstatus == "N") // N - examnotstarted
                                {
                                    objGroupDetails[i].section_colour = MessageStringConstants.ExamNotStartedColor;
                                }
                            }
                        }
                    }
                }
                var serializeValue = JsonConvert.SerializeObject(objGroupDetails);
                AppPreferences.TestPinGroupDetailsSerialize = serializeValue;
                Application.Current.MainPage = new NavigationPage(new PRO_ExamSectionPage());
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "PRO_ExamViewModel.GoBackWctionPageWithoutEventLog");
            }
        }

        #endregion

        #region GoBackSectionPage
        private async void GoBackSectionPage()
        {
            try
            {
              //  bool returnFlag = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.FinishTheSection, string.Empty, "OK", "CANCEL");
              //  if (returnFlag)
              //  {
                    await TimerStop();
                    var serializedData1 = AppPreferences.TestPinGroupDetailsSerialize;
                    List<SectionDetailsResponseData> deSerializedData = JsonConvert.DeserializeObject<List<SectionDetailsResponseData>>(serializedData1);
                    List<SectionDetailsResponseData> objGroupDetails = new List<SectionDetailsResponseData>();
                    objGroupDetails = deSerializedData;
                    List<tbl_timer> tbl_Timers = _localDB.GetAllPROSectionTimerList();

                    if (tbl_Timers != null && tbl_Timers.Count > 0)
                    {
                        for (int i = 0; i < objGroupDetails.Count; i++)
                        {
                            for (int j = 0; j < tbl_Timers.Count; j++)
                            {
                                if (objGroupDetails[i].section_id == tbl_Timers[j].section_id)
                                {
                                    if (tbl_Timers[j].examstatus == "E")      // T - timerelabsed
                                    {
                                        objGroupDetails[i].section_colour = MessageStringConstants.ExamTimeElapsedColor;
                                    }
                                    else if (tbl_Timers[j].examstatus == "C") // C - examcomplted
                                    {
                                        objGroupDetails[i].section_colour = MessageStringConstants.ExamCompletedColor;
                                    }
                                    else if (tbl_Timers[j].examstatus == "P") // P - examinprogress
                                    {
                                        objGroupDetails[i].section_colour = MessageStringConstants.ExamProgressColor;
                                    }
                                    else if (tbl_Timers[j].examstatus == "N") // N - examnotstarted
                                    {
                                        objGroupDetails[i].section_colour = MessageStringConstants.ExamNotStartedColor;
                                    }
                                }
                            }
                        }
                    }

                    var serializeValue = JsonConvert.SerializeObject(objGroupDetails);
                    AppPreferences.TestPinGroupDetailsSerialize = serializeValue;

                    bool responseFlag = await UpdateEventLog(false);
                    if (responseFlag)
                    {
                        Application.Current.MainPage = new NavigationPage(new PRO_ExamSectionPage());
                    }
                //}
                //else
                //{
                //    await TimerStart();
                //}
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "PRO_ExamViewModel.GoBackSectionPage");
            }
        }
        #endregion



        #region NewSectionFirstQuestion
        private async void NewSectionFirstQuestion(string value)
        {
            try
            {


                if (SectionCurrentIndex > 0)
                {

                    // var data = _localDB.GetAllPROSectionTimerList();

                    await TimerStop();
                    var sectionDetails = _localDB.GetPROSectionDetailsByID(SectionCurrentIndex);
                    SelectedSectionID = sectionDetails.section_id;
                    AppPreferences.LastUpdatedSectionID = SelectedSectionID;
                    if (value == "previous")
                    {
                        SectionCurrentQue = Convert.ToInt32(sectionDetails.sectioncount);
                    }
                    else if (value == "next")
                    {

                        SectionCurrentQue = 1;
                    }
                    SectionName = sectionDetails.sectionname;
                    if (_TestPinMasterData.duration_type == Convert.ToString((int)duration_type.SectionDuration))
                    {
                        SetSectoinDuration(sectionDetails);
                    }
                    await TimerStart();
                    LoadQuestions(false);
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "PRO_ExamViewModel.NewSectionFirstQuestion");
            }
        }
        #endregion

        #region SetSectoinDuration
        public void SetSectoinDuration(tbl_timer sectionDetails)
        {
            if (!string.IsNullOrEmpty(sectionDetails.section_duration))
            {
                TimeSpan examduration = TimeSpan.FromMinutes(Convert.ToDouble(sectionDetails.section_duration));
                TotalDuration = string.Format("{0:00}:{1:00}:{2:00}", examduration.Hours, examduration.Minutes, examduration.Seconds);
            }
            else
            {
                TotalDuration = "00:00:00";
            }
        }
        #endregion

        #region CallBackPage
        private async void CallBackPage(string value)
        {
            try
            {
                AllSectionCompltedInternallShowEndTestButton();
                if (_TestPinMasterData.is_section_navigation == Convert.ToString((int)is_section_navigation.Enable))
                {
                    bool returnFlag = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.FinishTheSection, string.Empty, "OK", "CANCEL");
                    if (returnFlag)
                    {
                        await TimerStop();
                        var serializedData1 = AppPreferences.TestPinGroupDetailsSerialize;
                        List<SectionDetailsResponseData> deSerializedData = JsonConvert.DeserializeObject<List<SectionDetailsResponseData>>(serializedData1);
                        List<SectionDetailsResponseData> objGroupDetails = new List<SectionDetailsResponseData>();
                        objGroupDetails = deSerializedData;
                        List<tbl_timer> tbl_Timers = _localDB.GetAllPROSectionTimerList();

                        if (tbl_Timers != null && tbl_Timers.Count > 0)
                        {
                            for (int i = 0; i < objGroupDetails.Count; i++)
                            {
                                for (int j = 0; j < tbl_Timers.Count; j++)
                                {
                                    if (objGroupDetails[i].section_id == tbl_Timers[j].section_id)
                                    {
                                        if (tbl_Timers[j].examstatus == "E")      // T - timerelabsed
                                        {
                                            objGroupDetails[i].section_colour = MessageStringConstants.ExamTimeElapsedColor;
                                        }
                                        else if (tbl_Timers[j].examstatus == "C") // C - examcomplted
                                        {
                                            objGroupDetails[i].section_colour = MessageStringConstants.ExamCompletedColor;
                                        }
                                        else if (tbl_Timers[j].examstatus == "P") // P - examinprogress
                                        {
                                            objGroupDetails[i].section_colour = MessageStringConstants.ExamProgressColor;
                                        }
                                        else if (tbl_Timers[j].examstatus == "N") // N - examnotstarted
                                        {
                                            objGroupDetails[i].section_colour = MessageStringConstants.ExamNotStartedColor;
                                        }
                                    }
                                }
                            }
                        }

                        var serializeValue = JsonConvert.SerializeObject(objGroupDetails);
                        AppPreferences.TestPinGroupDetailsSerialize = serializeValue;

                        bool responseFlag = await UpdateEventLog(false);
                        if (responseFlag)
                        {
                            Application.Current.MainPage = new NavigationPage(new PRO_ExamSectionPage());
                        }
                    }
                    else
                    {
                        await TimerStart();
                    }
                }
                else
                {

                    bool responseFlag = await UpdateEventLog(false);
                    if (responseFlag)
                    {
                        if (btnNextAndSubmit == " Submit " && value == "next")
                        {
                            //_localDB.UpdateSectionStatusEndTimeBySectionid(SelectedSectionID, "C", ServerTimerText, ElapsedSeconds.ToString());
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.PRO_FinishExamusingEndTestButton);
                            await TimerStart();
                            return;
                        }
                        else if (SectionCurrentIndex > 0)
                        {

                           // var data = _localDB.GetAllPROSectionTimerList();



                            await TimerStop();
                            var sectionDetails = _localDB.GetPROSectionDetailsByID(SectionCurrentIndex);
                            SelectedSectionID = sectionDetails.section_id;
                            AppPreferences.LastUpdatedSectionID = SelectedSectionID;
                            if (value == "previous")
                            {
                                SectionCurrentQue = Convert.ToInt32(sectionDetails.sectioncount);
                            }
                            else if (value == "next")
                            {

                                SectionCurrentQue = 1;
                            }
                            SectionName = sectionDetails.sectionname;

                            if (_TestPinMasterData.duration_type == Convert.ToString((int)duration_type.SectionDuration))
                            {
                                if (!string.IsNullOrEmpty(sectionDetails.section_duration))
                                {
                                    TimeSpan examduration = TimeSpan.FromMinutes(Convert.ToDouble(sectionDetails.section_duration));
                                    TotalDuration = string.Format("{0:00}:{1:00}:{2:00}", examduration.Hours, examduration.Minutes, examduration.Seconds);
                                }
                                else
                                {
                                    TotalDuration = "00:00:00";
                                }
                            }
                            await TimerStart();
                            LoadQuestions(false);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "PRO_ExamViewModel.CallBackPage");
            }
        }
        #endregion

        #region UpdateSectionStatus
        public void UpdateSectionStatus(string sectionstatus)
        {

            //var obj = _localDB.GetPROSectionTimerBySectionID(SelectedSectionID); 
            //if(obj.examstatus != "C")
            //{
                _localDB.UpdateSectionStatusBySectionid(SelectedSectionID, sectionstatus);
            //}
        }


        //public void UpdateSectionStatusWithTimer(string startTimer,string sectionstatus)
        //{
        //    var obj = _localDB.GetPROSectionTimerBySectionID(SelectedSectionID);
        //   _localDB.UpdateSectionTimer(SelectedSectionID, startTimer, sectionstatus);
        //}
        #endregion


        #region Heartbeatlog API Call
        public async void Heartbeatlog()
        {
            try
            {
                HeartBeat_LogRequestData _HeartBeatLogRequest = new HeartBeat_LogRequestData();
                tbl_timer timerData = _localDB.GetPROSectionTimerBySectionID(SelectedSectionID);

                var obj = AppPreferences.TestPinMasterData;

                _HeartBeatLogRequest.testpin = obj.testpin;
                _HeartBeatLogRequest.company_id = obj.company_id;
                _HeartBeatLogRequest.assign_id = obj.assign_id;
                _HeartBeatLogRequest.section_id = SelectedSectionID;
                _HeartBeatLogRequest.attempt_id = obj.attempt_id;
                _HeartBeatLogRequest.login_audit_id = obj.login_audit_id;
                _HeartBeatLogRequest.elapse_time = UpdateEventLogTimer;
                _HeartBeatLogRequest.Sectionstatus = timerData.examstatus;
                // _HeartBeatLogRequest.section_start_time = timerData.starttime;
                // _HeartBeatLogRequest.section_end_time = timerData.endtime;

                if (!string.IsNullOrEmpty(timerData.starttime))
                {
                    _HeartBeatLogRequest.section_start_time = Convert.ToDateTime(timerData.starttime).ToString("yyyy-MM-dd HH:mm:ss");
                }
                else
                {
                    _HeartBeatLogRequest.section_start_time = timerData.starttime;
                }

                if (!string.IsNullOrEmpty(timerData.endtime))
                {
                    _HeartBeatLogRequest.section_end_time = Convert.ToDateTime(timerData.endtime).ToString("yyyy-MM-dd HH:mm:ss");
                }
                else
                {
                    _HeartBeatLogRequest.section_end_time = timerData.endtime;
                }


                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {
                    var result = await _commonservice.PostAsync<LogResponseData, HeartBeat_LogRequestData>(APIData.API_BASE_URL + APIMethods.Heartbeatlog, _HeartBeatLogRequest);
                    if (result != null)
                    {
                        if (result.code == "199")
                        {
                            await TimerStop();
                            await UserDialogs.Instance.AlertAsync(result.message);
                            Application.Current.MainPage = new NavigationPage(new PRO_TestPinPage());
                        }
                        else if (result.code != "200")
                        {
                            await TimerStop();
                            await UserDialogs.Instance.AlertAsync(result.message);
                        }
                    }
                    else
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                else
                {
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                    await TimerStop();
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "PRO_AssesmentViewModel.Heartbeatlog");
            }
        }
        #endregion

        #region SetButtonColor
        private Color SetButtonColor(int CurrentQuestion)
        {

            if (_questiondata.IsMultipleOption == Convert.ToString((int)IsMultipleOption.IS_Multi_Slection))
            {
                selectedOptionId = GetSelectedAnswer();
            }

            if (string.IsNullOrEmpty(selectedOptionId))
            {
                return ButtonColorNotAnswerwed;
            }
            else
            {
                return ButtonColorAnswerwed;
            }
        }
        #endregion



        #region CheckExamCompltedorNot         public async Task CheckExamCompltedorNotAsync()         {

            try             {
                var totalcount = _localDB.GetAllPROSectionTimerList();
                // var compltedcount = _localDB.GetCompletedCount().Count;
                var elapsedcount = _localDB.GetElapsedCount().Count;
                bool responseFlag = await UpdateEventLog(false);
                if (responseFlag)
                {

                    if (totalcount.Count == elapsedcount)
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ExamTimeOutMessage);
                        UpdateExamCompletedStatustoServer();
                    }
                    else
                    {
                        if (_TestPinMasterData.is_section_navigation == Convert.ToString((int)is_section_navigation.Enable))
                        {

                            if (_TestPinMasterData.duration_type == Convert.ToString((int)duration_type.ExamDuration) && elapsedcount == 1)
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.ExamTimeOutMessage);
                                UpdateExamCompletedStatustoServer();
                            }
                            else
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.ExamTimeOutMessageForSection);
                                GoBackSctionPageWithoutEventLog();
                            }
                        }
                        else
                        {
                            if (_TestPinMasterData.duration_type == Convert.ToString((int)duration_type.ExamDuration))
                            {
                                await UserDialogs.Instance.AlertAsync(MessageStringConstants.ExamTimeOutMessage);
                                UpdateExamCompletedStatustoServer();
                            }
                            else
                            {
                                if (SectionCurrentIndex < totalcount.Count)
                                {
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ExamTimeOutMessageForSection);
                                    CurrentPosition = GetCurrentPosition(SectionCurrentIndex);
                                    CurrentQue = CurrentPosition + 1;
                                    SectionCurrentIndex = SectionCurrentIndex + 1;

                                    var returnvalue = CheckExamStatus("next", SectionCurrentIndex);
                                    if (returnvalue != "E")
                                    {
                                        NewSectionFirstQuestion("next");
                                    }
                                }
                                else if (SectionCurrentIndex == totalcount.Count)
                                {
                                    AllSectionCompltedInternallShowEndTestButton();
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ExamTimeOutMessageForSection);
                                    SectionCurrentIndex = 1;
                                    CurrentPosition = -1;
                                    CurrentQue = CurrentPosition + 1;
                                    SectionCurrentQue = 0;
                                    var returnvalue = CheckExamStatus("next", SectionCurrentIndex);
                                    if (returnvalue != "E")
                                    {
                                        CurrentPosition += 1;
                                        CurrentQue = CurrentPosition + 1;
                                        SectionCurrentQue += 1;
                                        NewSectionFirstQuestion("next");
                                    }
                                }
                            }
                        }
                    }
                }
            }             catch (Exception ex)             {                 Debug.WriteLine(ex.Message);                 SendErrorMessageToServer(ex, "PRO_ExamSectionViewModel.CheckExamCompltedorNot");             }
        }
        #endregion 



        #region GetCurrentPosition
        public int GetCurrentPosition(int index_value)
        {
            int val = 0;

            try
            {
                for (int i = index_value; i > 0; i--)
                {
                    var a = _localDB.GetPROSectionDetailsByID(i);
                    val = val + Convert.ToInt32(a.sectioncount);
                }
            }
            catch (Exception e)
            {
                SendErrorMessageToServer(e, "PRO_ExamViewModel.GetCurrentPosition");
            }
            return val;
        }
        #endregion



        #region Timer Start Function
        public async Task   TimerStart()
        {
            #region Timer Functionality
            try
            {
                AppPreferences.IsPRO_Assesment_TimerRunning = true;
                int StartSecond = 0;
                string Servertime;
                int ServerTotalSec = 0;

                #region Get timer from local db 
                if (_TestPinMasterData.duration_type == Convert.ToString((int)duration_type.SectionDuration))
                {
                    var obj = _localDB.GetPROSectionTimerBySectionID(SelectedSectionID.ToString());
                    StartSecond = Convert.ToInt32(obj.elapsed_time);
                }
                else if (_TestPinMasterData.duration_type == Convert.ToString((int)duration_type.ExamDuration))
                {
                    var obj = _localDB.GetPROSectionDetailsByID(1);
                    StartSecond = Convert.ToInt32(obj.elapsed_time);
                }
                #endregion

                try
                {
                    TimeSpan serverTime = new TimeSpan(Convert.ToInt64(AppPreferences.ServerDateTime));
                    // TimeSpan serverTime = new TimeSpan(Convert.ToInt64(AppPreferences.ServerUpdatedDateTime));
                    Servertime = serverTime.Hours + ":" + serverTime.Minutes + ":" + serverTime.Seconds;
                    ServerTotalSec = (int)TimeSpan.Parse(Servertime).TotalSeconds;
                }
                catch (Exception e)
                {
                    SendErrorMessageToServer(e, "PRO_ExamViewModel.TimerStart");
                }

                CancellationTokenSource CTS = cancellationTokenSource;
                Device.StartTimer(new TimeSpan(0, 0, 1),   () =>
                {
                    if (CTS.IsCancellationRequested)
                    {
                        return false;
                    }
                    #region Only time elapse
                    else if (StartSecond == 0)
                    {
                        if (AppPreferences.IsPRO_Assesment_TimerRunning == true)
                        {
                            TimerStop();
                            if (_TestPinMasterData.duration_type == Convert.ToString((int)duration_type.ExamDuration))
                            {
                                _localDB.UpdateSectionTimerByID(1, StartSecond.ToString());
                            }
                            _localDB.UpdateSectionStatusEndTimeBySectionid(SelectedSectionID, "E", ServerTimerText, StartSecond.ToString());
                            CheckExamCompltedorNotAsync();
                            return false;
                        }
                    }
                    #endregion
                    else
                    {
                        //    Device.BeginInvokeOnMainThread(() =>
                        //    {
                        if (AppPreferences.IsPRO_Assesment_TimerRunning == true)
                        {
                            StartSecond = StartSecond - 1;
                            ElapsedSeconds = StartSecond;
                        }
                        ServerTotalSec = ServerTotalSec + 1;

                        if (_TestPinMasterData.duration_type == Convert.ToString((int)duration_type.ExamDuration))
                        {
                            _localDB.UpdateSectionTimerByID(1, StartSecond.ToString());
                        }
                        _localDB.UpdateSectionTimerBySectionid(SelectedSectionID, StartSecond.ToString());

                        _Examtime = TimeSpan.FromSeconds(StartSecond);
                        try
                        {
                            _ServerTime = TimeSpan.FromSeconds(ServerTotalSec);
                            ServerTimerText = AppPreferences.ServerDate + " " + string.Format("{0:00}:{1:00}:{2:00}", _ServerTime.Hours, _ServerTime.Minutes, _ServerTime.Seconds);                             AppPreferences.ServerUpdatedDateTime = ServerTimerText;
                            AppPreferences.ServerDateTime = Convert.ToDateTime(ServerTimerText).Ticks.ToString();
                        }
                        catch (Exception)
                        {

                        }  //    AppPreferences.ServerSecond = _ServerTime.Seconds.ToString();
                           //   AppPreferences.ServerMinute = _ServerTime.Minutes.ToString();
                           //   AppPreferences.ServerHour = _ServerTime.Hours.ToString();

                        TimerText = string.Format("  {0:00}:{1:00}:{2:00}", _Examtime.Hours, _Examtime.Minutes, _Examtime.Seconds);
                        UpdateEventLogTimer = string.Format("{0:00}:{1:00}:{2:00}", _Examtime.Hours, _Examtime.Minutes, _Examtime.Seconds);
                        //if (_Examtime.Seconds == 29 || _Examtime.Seconds == 59)
                        //{
                        //    if (AppPreferences.IsPRO_Assesment_TimerRunning == true && Constant.heartbeatlogRunning ==true)
                        //    {
                        //        Heartbeatlog();
                        //    }
                        //}


                      

                    }
                    return true;
                });
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                // await UserDialogs.Instance.AlertAsync("Error"+ ex.Message);
                SendErrorMessageToServer(ex, "PRO_ExamViewModel.TimerStart");
            }
            #endregion
        }
        #endregion

        #region Timer Stop Function
        public async Task TimerStop()
        {
            try
            {
                AppPreferences.IsPRO_Assesment_TimerRunning = false;
                Interlocked.Exchange(ref cancellationTokenSource, new CancellationTokenSource()).Cancel();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "PRO_ExamViewModel.TimerStop");
            }
        }
        #endregion

        #region Private property  

        private bool _IsHintStack;

        public bool IsHintStack
        {
            get { return _IsHintStack; }
            set { _IsHintStack = value; OnPropertyChanged(); }
        }


        private string _LblCurrentQuestion;
        public string LblCurrentQuestion
        {
            get { return _LblCurrentQuestion; }
            set { _LblCurrentQuestion = "Position :" + value; OnPropertyChanged(); }
        }
        private bool _IsQuestionPalletVisible;
        public bool IsQuestionPalletVisible
        {
            get { return _IsQuestionPalletVisible; }
            set { _IsQuestionPalletVisible = value; OnPropertyChanged(); }
        }
        private bool _IsRightArrowIconVisibile;
        public bool IsRightArrowIconVisibile
        {
            get { return _IsRightArrowIconVisibile; }
            set { _IsRightArrowIconVisibile = value; OnPropertyChanged(); }
        }

        private string _btnNextAndSubmit;
        public string btnNextAndSubmit
        {
            get { return _btnNextAndSubmit; }
            set { _btnNextAndSubmit = value; OnPropertyChanged(); }
        }



        //        private string _Answered;
        //        public string Answered
        //        {
        //            get { return _Answered; }
        //            set { _Answered = value; OnPropertyChanged(); }
        //        }
        //        private string _NotAnswered;
        //        public string NotAnswered
        //        {
        //            get { return _NotAnswered; }
        //            set { _NotAnswered = value; OnPropertyChanged(); }
        //        }
        //        private string _NotVisited;
        //        public string NotVisited
        //        {
        //            get { return _NotVisited; }
        //            set { _NotVisited = value; OnPropertyChanged(); }
        //        }


        #region Option Visibile Property
        private bool _IsQueContent;
        public bool IsQueContent
        {
            get { return _IsQueContent; }
            set { _IsQueContent = value; OnPropertyChanged(); }
        }
        private bool _IsQueContentOptionA;
        public bool IsQueContentOptionA
        {
            get { return _IsQueContentOptionA; }
            set { _IsQueContentOptionA = value; OnPropertyChanged(); }
        }
        private bool _IsQueContentOptionB;
        public bool IsQueContentOptionB
        {
            get { return _IsQueContentOptionB; }
            set { _IsQueContentOptionB = value; OnPropertyChanged(); }
        }
        private bool _IsQueContentOptionC;
        public bool IsQueContentOptionC
        {
            get { return _IsQueContentOptionC; }
            set { _IsQueContentOptionC = value; OnPropertyChanged(); }
        }
        private bool _IsQueContentOptionD;
        public bool IsQueContentOptionD
        {
            get { return _IsQueContentOptionD; }
            set { _IsQueContentOptionD = value; OnPropertyChanged(); }
        }
        private bool _IsQueContentOptionE;
        public bool IsQueContentOptionE
        {
            get { return _IsQueContentOptionE; }
            set { _IsQueContentOptionE = value; OnPropertyChanged(); }
        }
        private bool _IsQueContentOptionF;
        public bool IsQueContentOptionF
        {
            get { return _IsQueContentOptionF; }
            set { _IsQueContentOptionF = value; OnPropertyChanged(); }
        }

        private bool _IsQueImage;
        public bool IsQueImage
        {
            get { return _IsQueImage; }
            set { _IsQueImage = value; OnPropertyChanged(); }
        }
        private bool _IsQueImageOptionA;
        public bool IsQueImageOptionA
        {
            get { return _IsQueImageOptionA; }
            set { _IsQueImageOptionA = value; OnPropertyChanged(); }
        }
        private bool _IsQueImageOptionB;
        public bool IsQueImageOptionB
        {
            get { return _IsQueImageOptionB; }
            set { _IsQueImageOptionB = value; OnPropertyChanged(); }
        }
        private bool _IsQueImageOptionC;
        public bool IsQueImageOptionC
        {
            get { return _IsQueImageOptionC; }
            set { _IsQueImageOptionC = value; OnPropertyChanged(); }
        }
        private bool _IsQueImageOptionD;
        public bool IsQueImageOptionD
        {
            get { return _IsQueImageOptionD; }
            set { _IsQueImageOptionD = value; OnPropertyChanged(); }
        }
        private bool _IsQueImageOptionE;
        public bool IsQueImageOptionE
        {
            get { return _IsQueImageOptionE; }
            set { _IsQueImageOptionE = value; OnPropertyChanged(); }
        }
        private bool _IsQueImageOptionF;
        public bool IsQueImageOptionF
        {
            get { return _IsQueImageOptionF; }
            set { _IsQueImageOptionF = value; OnPropertyChanged(); }
        }
        #endregion


      
        //        }
        //        private bool _IsShowPreferredLanguageToggle;

        //        public bool IsShowPreferredLanguageToggle
        //        {
        //            get { return _IsShowPreferredLanguageToggle; }
        //            set { _IsShowPreferredLanguageToggle = value; OnPropertyChanged(); }
        //        }

        private string _companyName;
        public string CompanyName
        {
            get { return _companyName; }
            set { _companyName = value; OnPropertyChanged(); }
        }



        private List<ExamQuestions> _ListViewItemSource;
        public List<ExamQuestions> ListViewItemSource
        {
            get { return _ListViewItemSource; }
            set { _ListViewItemSource = value; OnPropertyChanged(); }
        }
        private string _question;
        public string Question
        {
            get { return _question; }
            set { _question = value; OnPropertyChanged(); }
        }
        private string _optionA;
        public string OptionA
        {
            get { return _optionA; }
            set { _optionA = value; OnPropertyChanged(); }
        }
        private string _optionB;
        public string OptionB
        {
            get { return _optionB; }
            set { _optionB = value; OnPropertyChanged(); }
        }
        private string _optionC;
        public string OptionC
        {
            get { return _optionC; }
            set { _optionC = value; OnPropertyChanged(); }
        }
        private string _optionD;
        public string OptionD
        {
            get { return _optionD; }
            set { _optionD = value; OnPropertyChanged(); }
        }
        private string _optionE;
        public string OptionE
        {
            get { return _optionE; }
            set { _optionE = value; OnPropertyChanged(); }
        }
        private string _optionF;
        public string OptionF
        {
            get { return _optionF; }
            set { _optionF = value; OnPropertyChanged(); }
        }
        private int _CurrentPosition;
        public int CurrentPosition
        {
            get { return _CurrentPosition; }
            set { _CurrentPosition = value; OnPropertyChanged(); }
        }

        private int _SectionCurrentPosition;
        public int SectionCurrentPosition
        {
            get { return _SectionCurrentPosition; }
            set { _SectionCurrentPosition = value; OnPropertyChanged(); }
        }

        

        private string _SectionName;
        public string SectionName
        {
            get { return _SectionName; }
            set
            {
                _SectionName = "Section : " + value;
                OnPropertyChanged();
            }
        }


        private bool _IsVisibleSectionName;
        public bool IsVisibleSectionName
        {
            get { return _IsVisibleSectionName; }
            set { _IsVisibleSectionName = value; OnPropertyChanged(); }
        }


        private bool _IsVisibleNormalQuestions;
        public bool IsVisibleNormalQuestions
        {
            get { return _IsVisibleNormalQuestions; }
            set { _IsVisibleNormalQuestions = value; OnPropertyChanged(); }
        }

        private bool _IsVisibleLikerQuestions;
        public bool IsVisibleLikerQuestions
        {
            get { return _IsVisibleLikerQuestions; }
            set { _IsVisibleLikerQuestions = value; OnPropertyChanged(); }
        }



        private String candidateName;
        public String CandidateName
        {
            get { return candidateName; }
            set { candidateName = "Name : " + value; OnPropertyChanged(); }
        }
        //        private string _ExamName;
        //        public string ExamName
        //        {
        //            get { return _ExamName; }
        //            set { _ExamName = value; OnPropertyChanged(); }
        //        }
        //        private string _PreferredLanguage;
        //        public string PreferredLanguage
        //        {
        //            get { return _PreferredLanguage; }
        //            set { _PreferredLanguage = value; OnPropertyChanged(); }
        //        }


        //        private string SelectdExamLanguage;

        //        public string bindSelectedLanguage
        //        {
        //            get { return SelectdExamLanguage; }
        //            set { SelectdExamLanguage = value; OnPropertyChanged(); }
        //        }
        private bool _Ispreviousbtn;
        public bool Ispreviousbtn
        {
            get { return _Ispreviousbtn; }
            set { _Ispreviousbtn = value; OnPropertyChanged(); }
        }
        private bool _Isnextbtn;
        public bool Isnextbtn
        {
            get { return _Isnextbtn; }
            set { _Isnextbtn = value; OnPropertyChanged(); }
        }

        private int _lastindex;
        public int lastindex
        {
            get { return _lastindex; }
            set { _lastindex = value; OnPropertyChanged(); }
        }
        private int _currentQue;
        public int CurrentQue
        {
            get { return _currentQue; }
            set { _currentQue = value; OnPropertyChanged(); }
        }
        private int _SectionCurrentQue;
        public int SectionCurrentQue
        {
            get { return _SectionCurrentQue; }
            set { _SectionCurrentQue = value; OnPropertyChanged(); }
        }

        private string _BehaviourcurrentQue;
        public string QuestionNumber
        {
            get { return _BehaviourcurrentQue; }
            set { _BehaviourcurrentQue = value; OnPropertyChanged(); }
        }

        private string _OptionA_Button;
        public string OptionA_Button
        {
            get { return _OptionA_Button; }
            set { _OptionA_Button = value; OnPropertyChanged(); }
        }
        private string _OptionB_Button;
        public string OptionB_Button
        {
            get { return _OptionB_Button; }
            set { _OptionB_Button = value; OnPropertyChanged(); }
        }
        private string _OptionC_Button;
        public string OptionC_Button
        {
            get { return _OptionC_Button; }
            set { _OptionC_Button = value; OnPropertyChanged(); }
        }
        private string _OptionD_Button;
        public string OptionD_Button
        {
            get { return _OptionD_Button; }
            set { _OptionD_Button = value; OnPropertyChanged(); }
        }
        private string _OptionE_Button;
        public string OptionE_Button
        {
            get { return _OptionE_Button; }
            set { _OptionE_Button = value; OnPropertyChanged(); }
        }
        private string _OptionF_Button;
        public string OptionF_Button
        {
            get { return _OptionF_Button; }
            set { _OptionF_Button = value; OnPropertyChanged(); }
        }

        private Color _buttonColor;
        public Color ButtonColor
        {
            get { return _buttonColor; }
            set { _buttonColor = value; OnPropertyChanged(); }
        }
        private string _Duration;
        public string Duration
        {
            get { return _Duration; }
            set { _Duration = value; OnPropertyChanged(); }
        }

        private Color _buttonColorAnswerwed;
        public Color ButtonColorAnswerwed
        {
            get { return _buttonColorAnswerwed; }
            set { _buttonColorAnswerwed = value; OnPropertyChanged(); }
        }

        private Color _buttonColorNotAnswerwed;
        public Color ButtonColorNotAnswerwed
        {
            get { return _buttonColorNotAnswerwed; }
            set { _buttonColorNotAnswerwed = value; OnPropertyChanged(); }
        }
        private Color _buttonColorNotVisited;
        public Color ButtonColorNotVisited
        {
            get { return _buttonColorNotVisited; }
            set { _buttonColorNotVisited = value; OnPropertyChanged(); }
        }

        private string _NextButtonColor;

        public string NextButtonColor
        {
            get { return _NextButtonColor; }
            set { _NextButtonColor = value; OnPropertyChanged(); }
        }

        #region LikerType Questions Bindings


        private bool _IsVisible_LikerSubQuestion1;
        public bool IsVisible_LikerSubQuestion1
        {
            get { return _IsVisible_LikerSubQuestion1; }
            set { _IsVisible_LikerSubQuestion1 = value; OnPropertyChanged(); }
        }

        private bool _IsVisible_LikerSubQuestion2;
        public bool IsVisible_LikerSubQuestion2
        {
            get { return _IsVisible_LikerSubQuestion2; }
            set { _IsVisible_LikerSubQuestion2 = value; OnPropertyChanged(); }
        }

        private bool _IsVisible_LikerSubQuestion3;
        public bool IsVisible_LikerSubQuestion3
        {
            get { return _IsVisible_LikerSubQuestion3; }
            set { _IsVisible_LikerSubQuestion3 = value; OnPropertyChanged(); }
        }

        private bool _IsVisible_LikerSubQuestion4;
        public bool IsVisible_LikerSubQuestion4
        {
            get { return _IsVisible_LikerSubQuestion4; }
            set { _IsVisible_LikerSubQuestion4 = value; OnPropertyChanged(); }
        }

        private bool _IsVisible_LikerSubQuestion5;
        public bool IsVisible_LikerSubQuestion5
        {
            get { return _IsVisible_LikerSubQuestion5; }
            set { _IsVisible_LikerSubQuestion5 = value; OnPropertyChanged(); }
        }
        private bool _IsVisible_LikerSubQuestion6;
        public bool IsVisible_LikerSubQuestion6
        {
            get { return _IsVisible_LikerSubQuestion6; }
            set { _IsVisible_LikerSubQuestion6 = value; OnPropertyChanged(); }
        }



        private bool _IsVisible_LikerQ1A_Button;
        public bool IsVisible_Likert_SQ1_OptionA
        {
            get { return _IsVisible_LikerQ1A_Button; }
            set { _IsVisible_LikerQ1A_Button = value; OnPropertyChanged(); }
        }

        private bool _IsVisible_LikerQ1B_Button;
        public bool IsVisible_Likert_SQ1_OptionB
        {
            get { return _IsVisible_LikerQ1B_Button; }
            set { _IsVisible_LikerQ1B_Button = value; OnPropertyChanged(); }
        }

        private bool _IsVisible_LikerQ1C_Button;
        public bool IsVisible_Likert_SQ1_OptionC
        {
            get { return _IsVisible_LikerQ1C_Button; }
            set { _IsVisible_LikerQ1C_Button = value; OnPropertyChanged(); }
        }

        private bool _IsVisible_LikerQ1D_Button;
        public bool IsVisible_Likert_SQ1_OptionD
        {
            get { return _IsVisible_LikerQ1D_Button; }
            set { _IsVisible_LikerQ1D_Button = value; OnPropertyChanged(); }
        }

        private bool _IsVisible_LikerQ1E_Button;
        public bool IsVisible_Likert_SQ1_OptionE
        {
            get { return _IsVisible_LikerQ1E_Button; }
            set { _IsVisible_LikerQ1E_Button = value; OnPropertyChanged(); }
        }

        private bool _IsVisible_LikerQ1F_Button;
        public bool IsVisible_Likert_SQ1_OptionF
        {
            get { return _IsVisible_LikerQ1F_Button; }
            set { _IsVisible_LikerQ1F_Button = value; OnPropertyChanged(); }
        }


        private bool _IsVisible_LikerQ2A_Button;
        public bool IsVisible_Likert_SQ2_OptionA
        {
            get { return _IsVisible_LikerQ2A_Button; }
            set { _IsVisible_LikerQ2A_Button = value; OnPropertyChanged(); }
        }

        private bool _IsVisible_LikerQ2B_Button;
        public bool IsVisible_Likert_SQ2_OptionB
        {
            get { return _IsVisible_LikerQ2B_Button; }
            set { _IsVisible_LikerQ2B_Button = value; OnPropertyChanged(); }
        }
        private bool _IsVisible_LikerQ2C_Button;
        public bool IsVisible_Likert_SQ2_OptionC
        {
            get { return _IsVisible_LikerQ2C_Button; }
            set { _IsVisible_LikerQ2C_Button = value; OnPropertyChanged(); }
        }
        private bool _IsVisible_LikerQ2D_Button;
        public bool IsVisible_Likert_SQ2_OptionD
        {
            get { return _IsVisible_LikerQ2D_Button; }
            set { _IsVisible_LikerQ2D_Button = value; OnPropertyChanged(); }
        }
        private bool _IsVisible_LikerQ2E_Button;
        public bool IsVisible_Likert_SQ2_OptionE
        {
            get { return _IsVisible_LikerQ2E_Button; }
            set { _IsVisible_LikerQ2E_Button = value; OnPropertyChanged(); }
        }
        private bool _IsVisible_LikerQ2F_Button;
        public bool IsVisible_Likert_SQ2_OptionF
        {
            get { return _IsVisible_LikerQ2F_Button; }
            set { _IsVisible_LikerQ2F_Button = value; OnPropertyChanged(); }
        }


        private bool _IsVisible_LikerQ3A_Button;
        public bool IsVisible_Likert_SQ3_OptionA
        {
            get { return _IsVisible_LikerQ3A_Button; }
            set { _IsVisible_LikerQ3A_Button = value; OnPropertyChanged(); }
        }
        private bool _IsVisible_LikerQ3B_Button;
        public bool IsVisible_Likert_SQ3_OptionB
        {
            get { return _IsVisible_LikerQ3B_Button; }
            set { _IsVisible_LikerQ3B_Button = value; OnPropertyChanged(); }
        }
        private bool _IsVisible_LikerQ3C_Button;
        public bool IsVisible_Likert_SQ3_OptionC
        {
            get { return _IsVisible_LikerQ3C_Button; }
            set { _IsVisible_LikerQ3C_Button = value; OnPropertyChanged(); }
        }
        private bool _IsVisible_LikerQ3D_Button;
        public bool IsVisible_Likert_SQ3_OptionD
        {
            get { return _IsVisible_LikerQ3D_Button; }
            set { _IsVisible_LikerQ3D_Button = value; OnPropertyChanged(); }
        }
        private bool _IsVisible_LikerQ3E_Button;
        public bool IsVisible_Likert_SQ3_OptionE
        {
            get { return _IsVisible_LikerQ3E_Button; }
            set { _IsVisible_LikerQ3E_Button = value; OnPropertyChanged(); }
        }
        private bool _IsVisible_LikerQ3F_Button;
        public bool IsVisible_Likert_SQ3_OptionF
        {
            get { return _IsVisible_LikerQ3F_Button; }
            set { _IsVisible_LikerQ3F_Button = value; OnPropertyChanged(); }
        }



        private bool _IsVisible_LikerQ4A_Button;
        public bool IsVisible_Likert_SQ4_OptionA
        {
            get { return _IsVisible_LikerQ4A_Button; }
            set { _IsVisible_LikerQ4A_Button = value; OnPropertyChanged(); }
        }
        private bool _IsVisible_LikerQ4B_Button;
        public bool IsVisible_Likert_SQ4_OptionB
        {
            get { return _IsVisible_LikerQ4B_Button; }
            set { _IsVisible_LikerQ4B_Button = value; OnPropertyChanged(); }
        }
        private bool _IsVisible_LikerQ4C_Button;
        public bool IsVisible_Likert_SQ4_OptionC
        {
            get { return _IsVisible_LikerQ4C_Button; }
            set { _IsVisible_LikerQ4C_Button = value; OnPropertyChanged(); }
        }
        private bool _IsVisible_LikerQ4D_Button;
        public bool IsVisible_Likert_SQ4_OptionD
        {
            get { return _IsVisible_LikerQ4D_Button; }
            set { _IsVisible_LikerQ4D_Button = value; OnPropertyChanged(); }
        }
        private bool _IsVisible_LikerQ4E_Button;
        public bool IsVisible_Likert_SQ4_OptionE
        {
            get { return _IsVisible_LikerQ4E_Button; }
            set { _IsVisible_LikerQ4E_Button = value; OnPropertyChanged(); }
        }
        private bool _IsVisible_LikerQ4F_Button;
        public bool IsVisible_Likert_SQ4_OptionF
        {
            get { return _IsVisible_LikerQ4F_Button; }
            set { _IsVisible_LikerQ4F_Button = value; OnPropertyChanged(); }
        }



        private bool _IsVisible_LikerQ5A_Button;
        public bool IsVisible_Likert_SQ5_OptionA
        {
            get { return _IsVisible_LikerQ5A_Button; }
            set { _IsVisible_LikerQ5A_Button = value; OnPropertyChanged(); }
        }

        private bool _IsVisible_LikerQ5B_Button;
        public bool IsVisible_Likert_SQ5_OptionB
        {
            get { return _IsVisible_LikerQ5B_Button; }
            set { _IsVisible_LikerQ5B_Button = value; OnPropertyChanged(); }

        }

        private bool _IsVisible_LikerQ5C_Button;
        public bool IsVisible_Likert_SQ5_OptionC
        {
            get { return _IsVisible_LikerQ5C_Button; }
            set { _IsVisible_LikerQ5C_Button = value; OnPropertyChanged(); }

        }

        private bool _IsVisible_LikerQ5D_Button;
        public bool IsVisible_Likert_SQ5_OptionD
        {
            get { return _IsVisible_LikerQ5D_Button; }
            set { _IsVisible_LikerQ5D_Button = value; OnPropertyChanged(); }

        }

        private bool _IsVisible_LikerQ5E_Button;
        public bool IsVisible_Likert_SQ5_OptionE
        {
            get { return _IsVisible_LikerQ5E_Button; }
            set { _IsVisible_LikerQ5E_Button = value; OnPropertyChanged(); }

        }

        private bool _IsVisible_LikerQ5F_Button;
        public bool IsVisible_Likert_SQ5_OptionF
        {
            get { return _IsVisible_LikerQ5F_Button; }
            set { _IsVisible_LikerQ5F_Button = value; OnPropertyChanged(); }

        }

        private bool _IsVisible_LikerQ6A_Button;
        public bool IsVisible_Likert_SQ6_OptionA
        {
            get { return _IsVisible_LikerQ6A_Button; }
            set { _IsVisible_LikerQ6A_Button = value; OnPropertyChanged(); }
        }
        private bool _IsVisible_LikerQ6B_Button;
        public bool IsVisible_Likert_SQ6_OptionB
        {
            get { return _IsVisible_LikerQ6B_Button; }
            set { _IsVisible_LikerQ6B_Button = value; OnPropertyChanged(); }
        }
        private bool _IsVisible_LikerQ6C_Button;
        public bool IsVisible_Likert_SQ6_OptionC
        {
            get { return _IsVisible_LikerQ6C_Button; }
            set { _IsVisible_LikerQ6C_Button = value; OnPropertyChanged(); }
        }
        private bool _IsVisible_LikerQ6D_Button;
        public bool IsVisible_Likert_SQ6_OptionD
        {
            get { return _IsVisible_LikerQ6D_Button; }
            set { _IsVisible_LikerQ6D_Button = value; OnPropertyChanged(); }
        }
        private bool _IsVisible_LikerQ6E_Button;
        public bool IsVisible_Likert_SQ6_OptionE
        {
            get { return _IsVisible_LikerQ6E_Button; }
            set { _IsVisible_LikerQ6E_Button = value; OnPropertyChanged(); }
        }
        private bool _IsVisible_LikerQ6F_Button;
        public bool IsVisible_Likert_SQ6_OptionF
        {
            get { return _IsVisible_LikerQ6F_Button; }
            set { _IsVisible_LikerQ6F_Button = value; OnPropertyChanged(); }
        }








        private string _LikerOptionARadiobutton;
        public string LikerOptionARadiobutton
        {
            get { return _LikerOptionARadiobutton; }
            set { _LikerOptionARadiobutton = value; OnPropertyChanged(); }
        }
        private string _LikerOptionBRadiobutton;
        public string LikerOptionBRadiobutton
        {
            get { return _LikerOptionBRadiobutton; }
            set { _LikerOptionBRadiobutton = value; OnPropertyChanged(); }
        }
        private string _LikerOptionCRadiobutton;
        public string LikerOptionCRadiobutton
        {
            get { return _LikerOptionCRadiobutton; }
            set { _LikerOptionCRadiobutton = value; OnPropertyChanged(); }
        }
        private string _LikerOptionDRadiobutton;
        public string LikerOptionDRadiobutton
        {
            get { return _LikerOptionDRadiobutton; }
            set { _LikerOptionDRadiobutton = value; OnPropertyChanged(); }
        }


        private string _LikerOptionERadiobutton;
        public string LikerOptionERadiobutton
        {
            get { return _LikerOptionERadiobutton; }
            set { _LikerOptionERadiobutton = value; OnPropertyChanged(); }
        }

        private string _LikerOptionFRadiobutton;
        public string LikerOptionFRadiobutton
        {
            get { return _LikerOptionFRadiobutton; }
            set { _LikerOptionFRadiobutton = value; OnPropertyChanged(); }
        }



        private string _LikerOptionARadiobuttontwo;
        public string LikerOptionARadiobuttontwo
        {
            get { return _LikerOptionARadiobuttontwo; }
            set { _LikerOptionARadiobuttontwo = value; OnPropertyChanged(); }
        }
        private string _LikerOptionBRadiobuttontwo;
        public string LikerOptionBRadiobuttontwo
        {
            get { return _LikerOptionBRadiobuttontwo; }
            set { _LikerOptionBRadiobuttontwo = value; OnPropertyChanged(); }
        }
        private string _LikerOptionCRadiobuttontwo;
        public string LikerOptionCRadiobuttontwo
        {
            get { return _LikerOptionCRadiobuttontwo; }
            set { _LikerOptionCRadiobuttontwo = value; OnPropertyChanged(); }
        }
        private string _LikerOptionDRadiobuttontwo;
        public string LikerOptionDRadiobuttontwo
        {
            get { return _LikerOptionDRadiobuttontwo; }
            set { _LikerOptionDRadiobuttontwo = value; OnPropertyChanged(); }
        }

        private string _LikerOptionERadiobuttontwo;
        public string LikerOptionERadiobuttontwo
        {
            get { return _LikerOptionERadiobuttontwo; }
            set { _LikerOptionERadiobuttontwo = value; OnPropertyChanged(); }
        }

        private string _LikerOptionFRadiobuttontwo;
        public string LikerOptionFRadiobuttontwo
        {
            get { return _LikerOptionFRadiobuttontwo; }
            set { _LikerOptionFRadiobuttontwo = value; OnPropertyChanged(); }
        }




        private string _LikerOptionARadiobuttonthree;
        public string LikerOptionARadiobuttonthree
        {
            get { return _LikerOptionARadiobuttonthree; }
            set { _LikerOptionARadiobuttonthree = value; OnPropertyChanged(); }
        }
        private string _LikerOptionBRadiobuttonthree;
        public string LikerOptionBRadiobuttonthree
        {
            get { return _LikerOptionBRadiobuttonthree; }
            set { _LikerOptionBRadiobuttonthree = value; OnPropertyChanged(); }
        }
        private string _LikerOptionCRadiobuttonthree;
        public string LikerOptionCRadiobuttonthree
        {
            get { return _LikerOptionCRadiobuttonthree; }
            set { _LikerOptionCRadiobuttonthree = value; OnPropertyChanged(); }
        }
        private string _LikerOptionDRadiobuttonthree;
        public string LikerOptionDRadiobuttonthree
        {
            get { return _LikerOptionDRadiobuttonthree; }
            set { _LikerOptionDRadiobuttonthree = value; OnPropertyChanged(); }
        }

        private string _LikerOptionERadiobuttonthree;
        public string LikerOptionERadiobuttonthree
        {
            get { return _LikerOptionERadiobuttonthree; }
            set { _LikerOptionERadiobuttonthree = value; OnPropertyChanged(); }
        }

        private string _LikerOptionFRadiobuttonthree;
        public string LikerOptionFRadiobuttonthree
        {
            get { return _LikerOptionFRadiobuttonthree; }
            set { _LikerOptionFRadiobuttonthree = value; OnPropertyChanged(); }
        }



        private string _LikerOptionARadiobuttonFour;
        public string LikerOptionARadiobuttonFour
        {
            get { return _LikerOptionARadiobuttonFour; }
            set { _LikerOptionARadiobuttonFour = value; OnPropertyChanged(); }
        }
        private string _LikerOptionBRadiobuttonFour;
        public string LikerOptionBRadiobuttonFour
        {
            get { return _LikerOptionBRadiobuttonFour; }
            set { _LikerOptionBRadiobuttonFour = value; OnPropertyChanged(); }
        }
        private string _LikerOptionCRadiobuttonFour;
        public string LikerOptionCRadiobuttonFour
        {
            get { return _LikerOptionCRadiobuttonFour; }
            set { _LikerOptionCRadiobuttonFour = value; OnPropertyChanged(); }
        }
        private string _LikerOptionDRadiobuttonFour;
        public string LikerOptionDRadiobuttonFour
        {
            get { return _LikerOptionDRadiobuttonFour; }
            set { _LikerOptionDRadiobuttonFour = value; OnPropertyChanged(); }
        }

        private string _LikerOptionERadiobuttonFour;
        public string LikerOptionERadiobuttonFour
        {
            get { return _LikerOptionERadiobuttonFour; }
            set { _LikerOptionERadiobuttonFour = value; OnPropertyChanged(); }
        }

        private string _LikerOptionFRadiobuttonFour;
        public string LikerOptionFRadiobuttonFour
        {
            get { return _LikerOptionFRadiobuttonFour; }
            set { _LikerOptionFRadiobuttonFour = value; OnPropertyChanged(); }
        }



        private string _LikerOptionARadiobuttonFive;
        public string LikerOptionARadiobuttonFive
        {
            get { return _LikerOptionARadiobuttonFive; }
            set { _LikerOptionARadiobuttonFive = value; OnPropertyChanged(); }
        }
        private string _LikerOptionBRadiobuttonFive;
        public string LikerOptionBRadiobuttonFive
        {
            get { return _LikerOptionBRadiobuttonFive; }
            set { _LikerOptionBRadiobuttonFive = value; OnPropertyChanged(); }
        }
        private string _LikerOptionCRadiobuttonFive;
        public string LikerOptionCRadiobuttonFive
        {
            get { return _LikerOptionCRadiobuttonFive; }
            set { _LikerOptionCRadiobuttonFive = value; OnPropertyChanged(); }
        }
        private string _LikerOptionDRadiobuttonFive;
        public string LikerOptionDRadiobuttonFive
        {
            get { return _LikerOptionDRadiobuttonFive; }
            set { _LikerOptionDRadiobuttonFive = value; OnPropertyChanged(); }
        }

        private string _LikerOptionERadiobuttonFive;
        public string LikerOptionERadiobuttonFive
        {
            get { return _LikerOptionERadiobuttonFive; }
            set { _LikerOptionERadiobuttonFive = value; OnPropertyChanged(); }
        }

        private string _LikerOptionFRadiobuttonFive;
        public string LikerOptionFRadiobuttonFive
        {
            get { return _LikerOptionFRadiobuttonFive; }
            set { _LikerOptionFRadiobuttonFive = value; OnPropertyChanged(); }
        }

        private string _LikerOptionARadiobuttonSix;
        public string LikerOptionARadiobuttonSix
        {
            get { return _LikerOptionARadiobuttonSix; }
            set { _LikerOptionARadiobuttonSix = value; OnPropertyChanged(); }
        }
        private string _LikerOptionBRadiobuttonSix;
        public string LikerOptionBRadiobuttonSix
        {
            get { return _LikerOptionBRadiobuttonSix; }
            set { _LikerOptionBRadiobuttonSix = value; OnPropertyChanged(); }
        }
        private string _LikerOptionCRadiobuttonSix;
        public string LikerOptionCRadiobuttonSix
        {
            get { return _LikerOptionCRadiobuttonSix; }
            set { _LikerOptionCRadiobuttonSix = value; OnPropertyChanged(); }
        }
        private string _LikerOptionDRadiobuttonSix;
        public string LikerOptionDRadiobuttonSix
        {
            get { return _LikerOptionDRadiobuttonSix; }
            set { _LikerOptionDRadiobuttonSix = value; OnPropertyChanged(); }
        }

        private string _LikerOptionERadiobuttonSix;
        public string LikerOptionERadiobuttonSix
        {
            get { return _LikerOptionERadiobuttonSix; }
            set { _LikerOptionERadiobuttonSix = value; OnPropertyChanged(); }
        }

        private string _LikerOptionFRadiobuttonSix;
        public string LikerOptionFRadiobuttonSix
        {
            get { return _LikerOptionFRadiobuttonSix; }
            set { _LikerOptionFRadiobuttonSix = value; OnPropertyChanged(); }
        }





        private string _likerQuestion;
        public string LikerQuestion
        {
            get { return _likerQuestion; }
            set { _likerQuestion = value; OnPropertyChanged(); }
        }


        private string _likerSubQuestion1;
        public string LikerSubQuestion1
        {
            get { return _likerSubQuestion1; }
            set { _likerSubQuestion1 = value; OnPropertyChanged(); }
        }

        private string _likerSubQuestion2;
        public string LikerSubQuestion2
        {
            get { return _likerSubQuestion2; }
            set { _likerSubQuestion2 = value; OnPropertyChanged(); }
        }

        private string _likerSubQuestion3;
        public string LikerSubQuestion3
        {
            get { return _likerSubQuestion3; }
            set { _likerSubQuestion3 = value; OnPropertyChanged(); }
        }


        private string _likerSubQuestion4;
        public string LikerSubQuestion4
        {
            get { return _likerSubQuestion4; }
            set { _likerSubQuestion4 = value; OnPropertyChanged(); }
        }


        private string _likerSubQuestion5;
        public string LikerSubQuestion5
        {
            get { return _likerSubQuestion5; }
            set { _likerSubQuestion5 = value; OnPropertyChanged(); }
        }

        private string _likerSubQuestion6;
        public string LikerSubQuestion6
        {
            get { return _likerSubQuestion6; }
            set { _likerSubQuestion6 = value; OnPropertyChanged(); }
        }





        private string _likerQ1OptionContentA;
        public string LikerQ1OptionContentA
        {
            get { return _likerQ1OptionContentA; }
            set { _likerQ1OptionContentA = value; OnPropertyChanged(); }
        }

        private string _likerQ1OptionContentB;
        public string LikerQ1OptionContentB
        {
            get { return _likerQ1OptionContentB; }
            set { _likerQ1OptionContentB = value; OnPropertyChanged(); }
        }

        private string _likerQ1OptionContentC;
        public string LikerQ1OptionContentC
        {
            get { return _likerQ1OptionContentC; }
            set { _likerQ1OptionContentC = value; OnPropertyChanged(); }
        }

        private string _likerQ1OptionContentD;
        public string LikerQ1OptionContentD
        {
            get { return _likerQ1OptionContentD; }
            set { _likerQ1OptionContentD = value; OnPropertyChanged(); }
        }

        private string _likerQ1OptionContentE;
        public string LikerQ1OptionContentE
        {
            get { return _likerQ1OptionContentE; }
            set { _likerQ1OptionContentE = value; OnPropertyChanged(); }
        }

        private string _likerQ1OptionContentF;
        public string LikerQ1OptionContentF
        {
            get { return _likerQ1OptionContentF; }
            set { _likerQ1OptionContentF = value; OnPropertyChanged(); }
        }




        private string _likerQ2OptionContentA;
        public string LikerQ2OptionContentA
        {
            get { return _likerQ2OptionContentA; }
            set { _likerQ2OptionContentA = value; OnPropertyChanged(); }
        }

        private string _likerQ2OptionContentB;
        public string LikerQ2OptionContentB
        {
            get { return _likerQ2OptionContentB; }
            set { _likerQ2OptionContentB = value; OnPropertyChanged(); }
        }

        private string _likerQ2OptionContentC;
        public string LikerQ2OptionContentC
        {
            get { return _likerQ2OptionContentC; }
            set { _likerQ2OptionContentC = value; OnPropertyChanged(); }
        }

        private string _likerQ2OptionContentD;
        public string LikerQ2OptionContentD
        {
            get { return _likerQ2OptionContentD; }
            set { _likerQ2OptionContentD = value; OnPropertyChanged(); }
        }


        private string _likerQ2OptionContentE;
        public string LikerQ2OptionContentE
        {
            get { return _likerQ2OptionContentE; }
            set { _likerQ2OptionContentE = value; OnPropertyChanged(); }
        }

        private string _likerQ2OptionContentF;
        public string LikerQ2OptionContentF
        {
            get { return _likerQ2OptionContentF; }
            set { _likerQ2OptionContentF = value; OnPropertyChanged(); }
        }





        private string _likerQ3OptionContentA;
        public string LikerQ3OptionContentA
        {
            get { return _likerQ3OptionContentA; }
            set { _likerQ3OptionContentA = value; OnPropertyChanged(); }
        }

        private string _likerQ3OptionContentB;
        public string LikerQ3OptionContentB
        {
            get { return _likerQ3OptionContentB; }
            set { _likerQ3OptionContentB = value; OnPropertyChanged(); }
        }

        private string _likerQ3OptionContentC;
        public string LikerQ3OptionContentC
        {
            get { return _likerQ3OptionContentC; }
            set { _likerQ3OptionContentC = value; OnPropertyChanged(); }
        }

        private string _likerQ3OptionContentD;
        public string LikerQ3OptionContentD
        {
            get { return _likerQ3OptionContentD; }
            set { _likerQ3OptionContentD = value; OnPropertyChanged(); }
        }

        private string _likerQ3OptionContentE;
        public string LikerQ3OptionContentE
        {
            get { return _likerQ3OptionContentE; }
            set { _likerQ3OptionContentE = value; OnPropertyChanged(); }
        }

        private string _likerQ3OptionContentF;
        public string LikerQ3OptionContentF
        {
            get { return _likerQ3OptionContentF; }
            set { _likerQ3OptionContentF = value; OnPropertyChanged(); }
        }







        private string _likerQ4OptionContentA;
        public string LikerQ4OptionContentA
        {
            get { return _likerQ4OptionContentA; }
            set { _likerQ4OptionContentA = value; OnPropertyChanged(); }
        }

        private string _likerQ4OptionContentB;
        public string LikerQ4OptionContentB
        {
            get { return _likerQ4OptionContentB; }
            set { _likerQ4OptionContentB = value; OnPropertyChanged(); }
        }

        private string _likerQ4OptionContentC;
        public string LikerQ4OptionContentC
        {
            get { return _likerQ4OptionContentC; }
            set { _likerQ4OptionContentC = value; OnPropertyChanged(); }
        }

        private string _likerQ4OptionContentD;
        public string LikerQ4OptionContentD
        {
            get { return _likerQ4OptionContentD; }
            set { _likerQ4OptionContentD = value; OnPropertyChanged(); }
        }

        private string _likerQ4OptionContentE;
        public string LikerQ4OptionContentE
        {
            get { return _likerQ4OptionContentE; }
            set { _likerQ4OptionContentE = value; OnPropertyChanged(); }
        }

        private string _likerQ4OptionContentF;
        public string LikerQ4OptionContentF
        {
            get { return _likerQ4OptionContentF; }
            set { _likerQ4OptionContentF = value; OnPropertyChanged(); }
        }




        private string _likerQ5OptionContentA;
        public string LikerQ5OptionContentA
        {
            get { return _likerQ5OptionContentA; }
            set { _likerQ5OptionContentA = value; OnPropertyChanged(); }
        }

        private string _likerQ5OptionContentB;
        public string LikerQ5OptionContentB
        {
            get { return _likerQ5OptionContentB; }
            set { _likerQ5OptionContentB = value; OnPropertyChanged(); }
        }

        private string _likerQ5OptionContentC;
        public string LikerQ5OptionContentC
        {
            get { return _likerQ5OptionContentC; }
            set { _likerQ5OptionContentC = value; OnPropertyChanged(); }
        }

        private string _likerQ5OptionContentD;
        public string LikerQ5OptionContentD
        {
            get { return _likerQ5OptionContentD; }
            set { _likerQ5OptionContentD = value; OnPropertyChanged(); }
        }

        private string _likerQ5OptionContentE;
        public string LikerQ5OptionContentE
        {
            get { return _likerQ5OptionContentE; }
            set { _likerQ5OptionContentE = value; OnPropertyChanged(); }
        }

        private string _likerQ5OptionContentF;
        public string LikerQ5OptionContentF
        {
            get { return _likerQ5OptionContentF; }
            set { _likerQ5OptionContentF = value; OnPropertyChanged(); }
        }






        private string _likerQ6OptionContentA;
        public string LikerQ6OptionContentA
        {
            get { return _likerQ6OptionContentA; }
            set { _likerQ6OptionContentA = value; OnPropertyChanged(); }
        }

        private string _likerQ6OptionContentB;
        public string LikerQ6OptionContentB
        {
            get { return _likerQ6OptionContentB; }
            set { _likerQ6OptionContentB = value; OnPropertyChanged(); }
        }

        private string _likerQ6OptionContentC;
        public string LikerQ6OptionContentC
        {
            get { return _likerQ6OptionContentC; }
            set { _likerQ6OptionContentC = value; OnPropertyChanged(); }
        }

        private string _likerQ6OptionContentD;
        public string LikerQ6OptionContentD
        {
            get { return _likerQ6OptionContentD; }
            set { _likerQ6OptionContentD = value; OnPropertyChanged(); }
        }

        private string _likerQ6OptionContentE;
        public string LikerQ6OptionContentE
        {
            get { return _likerQ6OptionContentE; }
            set { _likerQ6OptionContentE = value; OnPropertyChanged(); }
        }

        private string _likerQ6OptionContentF;
        public string LikerQ6OptionContentF
        {
            get { return _likerQ6OptionContentF; }
            set { _likerQ6OptionContentF = value; OnPropertyChanged(); }
        }
        #endregion

        #region Behavioural Full Properties Start 

        private bool _IsVisiblePsychometricView;         public bool IsVisiblePsychometricView         {             get { return _IsVisiblePsychometricView; }             set { _IsVisiblePsychometricView = value; OnPropertyChanged(); }         }          private string _PsySubQuestion1;         public string PsySubQuestion1         {             get { return _PsySubQuestion1; }             set { _PsySubQuestion1 = value; OnPropertyChanged(); }         }         private string _PsySubQuestion2;         public string PsySubQuestion2         {             get { return _PsySubQuestion2; }             set { _PsySubQuestion2 = value; OnPropertyChanged(); }         }           private string _PsyFAQuestion1;         public string PsyFAQuestion1         {             get { return _PsyFAQuestion1; }             set { _PsyFAQuestion1 = value; OnPropertyChanged(); }         }         private string _PsyFAQuestion2;         public string PsyFAQuestion2         {             get { return _PsyFAQuestion2; }             set { _PsyFAQuestion2 = value; OnPropertyChanged(); }         }         private Color _QuestionOneRadioColor;         public Color QuestionOneRadioColor         {             get { return _QuestionOneRadioColor; }             set { _QuestionOneRadioColor = value; OnPropertyChanged(); }         }         private Color _QuestionTwoRadioColor;          public Color QuestionTwoRadioColor         {             get { return _QuestionTwoRadioColor; }             set { _QuestionTwoRadioColor = value; OnPropertyChanged(); }         }         private Color _QuestionOneTextColor;          public Color QuestionOneTextColor         {             get { return _QuestionOneTextColor; }             set { _QuestionOneTextColor = value; OnPropertyChanged(); }         }         private Color _QuestionTwoTextColor;         public Color QuestionTwoTextColor         {             get { return _QuestionTwoTextColor; }             set { _QuestionTwoTextColor = value; OnPropertyChanged(); }         }




        private string _PsyOptionA;         public string PsyOptionA         {             get { return _PsyOptionA; }             set { _PsyOptionA = value; OnPropertyChanged(); }         }           private string _PsyOptionB;         public string PsyOptionB         {             get { return _PsyOptionB; }             set { _PsyOptionB = value; OnPropertyChanged(); }         }          private string _PsyOptionC;         public string PsyOptionC         {             get { return _PsyOptionC; }             set { _PsyOptionC = value; OnPropertyChanged(); }         }          private string _PsyOptionD;         public string PsyOptionD         {             get { return _PsyOptionD; }             set { _PsyOptionD = value; OnPropertyChanged(); }         }          private string _PsyOptionE;         public string PsyOptionE         {             get { return _PsyOptionE; }             set { _PsyOptionE = value; OnPropertyChanged(); }         }



        private bool _IsVisible_PsyOptionA;
        public bool IsVisible_PsyOptionA
        {
            get { return _IsVisible_PsyOptionA; }
            set { _IsVisible_PsyOptionA = value; OnPropertyChanged(); }
        }


        private bool _IsVisible_PsyOptionB;
        public bool IsVisible_PsyOptionB
        {
            get { return _IsVisible_PsyOptionB; }
            set { _IsVisible_PsyOptionB = value; OnPropertyChanged(); }
        }

        private bool _IsVisible_PsyOptionC;
        public bool IsVisible_PsyOptionC
        {
            get { return _IsVisible_PsyOptionC; }
            set { _IsVisible_PsyOptionC = value; OnPropertyChanged(); }
        }

        private bool _IsVisible_PsyOptionD;
        public bool IsVisible_PsyOptionD
        {
            get { return _IsVisible_PsyOptionD; }
            set { _IsVisible_PsyOptionD = value; OnPropertyChanged(); }
        }

        private bool _IsVisible_PsyOptionE;
        public bool IsVisible_PsyOptionE
        {
            get { return _IsVisible_PsyOptionE; }
            set { _IsVisible_PsyOptionE = value; OnPropertyChanged(); }
        }
           private string _optionARadiobutton;         public string OptionARadiobutton         {             get { return _optionARadiobutton; }             set { _optionARadiobutton = value; OnPropertyChanged(); }         }         private string _optionBRadiobutton;         public string OptionBRadiobutton         {             get { return _optionBRadiobutton; }             set { _optionBRadiobutton = value; OnPropertyChanged(); }         }         private string _optionCRadiobutton;         public string OptionCRadiobutton         {             get { return _optionCRadiobutton; }             set { _optionCRadiobutton = value; OnPropertyChanged(); }         }         private string _optionDRadiobutton;         public string OptionDRadiobutton         {             get { return _optionDRadiobutton; }             set { _optionDRadiobutton = value; OnPropertyChanged(); }         }         private string _optionERadiobutton;         public string OptionERadiobutton         {             get { return _optionERadiobutton; }             set { _optionERadiobutton = value; OnPropertyChanged(); }         }



        #endregion  Behavioural Full Properties End




        #endregion

        #region Show Previous and Next Button
        public void ShowPreviousandNextButton()
        {

            Isnextbtn = true;
            PRO_Configurations();
            if (CurrentQue == 1 && lastindex == 1)
            {
                Ispreviousbtn = false;
            }

            if (CurrentQue == lastindex)
            {
                IsRightArrowIconVisibile = false;
                btnNextAndSubmit = " Submit ";
                NextButtonColor = "#f44b42";
            }
            else if (CurrentPosition == 0)
            {
                Ispreviousbtn = false;
                IsRightArrowIconVisibile = true;
                btnNextAndSubmit = " Next ";
                NextButtonColor = "#8fc740";
            }
            else if (CurrentPosition > 0)
            {
                IsRightArrowIconVisibile = true;
                btnNextAndSubmit = " Next ";
                NextButtonColor = "#8fc740";
            }

            if (_TestPinMasterData.duration_type == Convert.ToString((int)duration_type.SectionDuration) && SectionCurrentQue == SectionLastIndex)
            {
                IsRightArrowIconVisibile = false;
                btnNextAndSubmit = " Submit ";
                NextButtonColor = "#f44b42";
            } 
        }
        #endregion

        #region LoadButtonColor If Already Complete the exam
        private void LoadButtonColorIfAlreadyExamComplete(string[] count)
        {
            switch (count[0])
            {
                case "1":
                    ButtonColor1 = SetButtonColorFromBulk(count[1]);
                    break;
                case "2":
                    ButtonColor2 = SetButtonColorFromBulk(count[1]);
                    break;
                case "3":
                    ButtonColor3 = SetButtonColorFromBulk(count[1]);
                    break;
                case "4":
                    ButtonColor4 = SetButtonColorFromBulk(count[1]);
                    break;
                case "5":
                    ButtonColor5 = SetButtonColorFromBulk(count[1]);
                    break;
                case "6":
                    ButtonColor6 = SetButtonColorFromBulk(count[1]);
                    break;
                case "7":
                    ButtonColor7 = SetButtonColorFromBulk(count[1]);
                    break;
                case "8":
                    ButtonColor8 = SetButtonColorFromBulk(count[1]);
                    break;
                case "9":
                    ButtonColor9 = SetButtonColorFromBulk(count[1]);
                    break;
                case "10":
                    ButtonColor10 = SetButtonColorFromBulk(count[1]);
                    break;

                case "11":
                    ButtonColor11 = SetButtonColorFromBulk(count[1]);
                    break;
                case "12":
                    ButtonColor12 = SetButtonColorFromBulk(count[1]);
                    break;
                case "13":
                    ButtonColor13 = SetButtonColorFromBulk(count[1]);
                    break;
                case "14":
                    ButtonColor14 = SetButtonColorFromBulk(count[1]);
                    break;
                case "15":
                    ButtonColor15 = SetButtonColorFromBulk(count[1]);
                    break;
                case "16":
                    ButtonColor16 = SetButtonColorFromBulk(count[1]);
                    break;
                case "17":
                    ButtonColor17 = SetButtonColorFromBulk(count[1]);
                    break;
                case "18":
                    ButtonColor18 = SetButtonColorFromBulk(count[1]);
                    break;
                case "19":
                    ButtonColor19 = SetButtonColorFromBulk(count[1]);
                    break;
                case "20":
                    ButtonColor20 = SetButtonColorFromBulk(count[1]);
                    break;
                case "21":
                    ButtonColor21 = SetButtonColorFromBulk(count[1]);
                    break;
                case "22":
                    ButtonColor22 = SetButtonColorFromBulk(count[1]);
                    break;
                case "23":
                    ButtonColor23 = SetButtonColorFromBulk(count[1]);
                    break;
                case "24":
                    ButtonColor24 = SetButtonColorFromBulk(count[1]);
                    break;
                case "25":
                    ButtonColor25 = SetButtonColorFromBulk(count[1]);
                    break;
                case "26":
                    ButtonColor26 = SetButtonColorFromBulk(count[1]);
                    break;
                case "27":
                    ButtonColor27 = SetButtonColorFromBulk(count[1]);
                    break;
                case "28":
                    ButtonColor28 = SetButtonColorFromBulk(count[1]);
                    break;
                case "29":
                    ButtonColor29 = SetButtonColorFromBulk(count[1]);
                    break;
                case "30":
                    ButtonColor30 = SetButtonColorFromBulk(count[1]);
                    break;

                case "31":
                    ButtonColor31 = SetButtonColorFromBulk(count[1]);
                    break;
                case "32":
                    ButtonColor32 = SetButtonColorFromBulk(count[1]);
                    break;
                case "33":
                    ButtonColor33 = SetButtonColorFromBulk(count[1]);
                    break;
                case "34":
                    ButtonColor34 = SetButtonColorFromBulk(count[1]);
                    break;
                case "35":
                    ButtonColor35 = SetButtonColorFromBulk(count[1]);
                    break;
                case "36":
                    ButtonColor36 = SetButtonColorFromBulk(count[1]);
                    break;
                case "37":
                    ButtonColor37 = SetButtonColorFromBulk(count[1]);
                    break;
                case "38":
                    ButtonColor38 = SetButtonColorFromBulk(count[1]);
                    break;
                case "39":
                    ButtonColor39 = SetButtonColorFromBulk(count[1]);
                    break;
                case "40":
                    ButtonColor40 = SetButtonColorFromBulk(count[1]);
                    break;
                case "41":
                    ButtonColor41 = SetButtonColorFromBulk(count[1]);
                    break;
                case "42":
                    ButtonColor42 = SetButtonColorFromBulk(count[1]);
                    break;
                case "43":
                    ButtonColor43 = SetButtonColorFromBulk(count[1]);
                    break;
                case "44":
                    ButtonColor44 = SetButtonColorFromBulk(count[1]);
                    break;
                case "45":
                    ButtonColor45 = SetButtonColorFromBulk(count[1]);
                    break;
                case "46":
                    ButtonColor46 = SetButtonColorFromBulk(count[1]);
                    break;
                case "47":
                    ButtonColor47 = SetButtonColorFromBulk(count[1]);
                    break;
                case "48":
                    ButtonColor48 = SetButtonColorFromBulk(count[1]);
                    break;
                case "49":
                    ButtonColor49 = SetButtonColorFromBulk(count[1]);
                    break;
                case "50":
                    ButtonColor50 = SetButtonColorFromBulk(count[1]);
                    break;
                case "51":
                    ButtonColor51 = SetButtonColorFromBulk(count[1]);
                    break;
                case "52":
                    ButtonColor52 = SetButtonColorFromBulk(count[1]);
                    break;
                case "53":
                    ButtonColor53 = SetButtonColorFromBulk(count[1]);
                    break;
                case "54":
                    ButtonColor54 = SetButtonColorFromBulk(count[1]);
                    break;
                case "55":
                    ButtonColor55 = SetButtonColorFromBulk(count[1]);
                    break;
                case "56":
                    ButtonColor56 = SetButtonColorFromBulk(count[1]);
                    break;
                case "57":
                    ButtonColor57 = SetButtonColorFromBulk(count[1]);
                    break;
                case "58":
                    ButtonColor58 = SetButtonColorFromBulk(count[1]);
                    break;
                case "59":
                    ButtonColor59 = SetButtonColorFromBulk(count[1]);
                    break;
                case "60":
                    ButtonColor60 = SetButtonColorFromBulk(count[1]);
                    break;
                case "61":
                    ButtonColor61 = SetButtonColorFromBulk(count[1]);
                    break;
                case "62":
                    ButtonColor62 = SetButtonColorFromBulk(count[1]);
                    break;
                case "63":
                    ButtonColor63 = SetButtonColorFromBulk(count[1]);
                    break;
                case "64":
                    ButtonColor64 = SetButtonColorFromBulk(count[1]);
                    break;
                case "65":
                    ButtonColor65 = SetButtonColorFromBulk(count[1]);
                    break;
                case "66":
                    ButtonColor66 = SetButtonColorFromBulk(count[1]);
                    break;
                case "67":
                    ButtonColor67 = SetButtonColorFromBulk(count[1]);
                    break;
                case "68":
                    ButtonColor68 = SetButtonColorFromBulk(count[1]);
                    break;
                case "69":
                    ButtonColor69 = SetButtonColorFromBulk(count[1]);
                    break;
                case "70":
                    ButtonColor70 = SetButtonColorFromBulk(count[1]);
                    break;
                case "71":
                    ButtonColor71 = SetButtonColorFromBulk(count[1]);
                    break;
                case "72":
                    ButtonColor72 = SetButtonColorFromBulk(count[1]);
                    break;
                case "73":
                    ButtonColor73 = SetButtonColorFromBulk(count[1]);
                    break;
                case "74":
                    ButtonColor74 = SetButtonColorFromBulk(count[1]);
                    break;
                case "75":
                    ButtonColor75 = SetButtonColorFromBulk(count[1]);
                    break;
                case "76":
                    ButtonColor76 = SetButtonColorFromBulk(count[1]);
                    break;
                case "77":
                    ButtonColor77 = SetButtonColorFromBulk(count[1]);
                    break;
                case "78":
                    ButtonColor78 = SetButtonColorFromBulk(count[1]);
                    break;
                case "79":
                    ButtonColor79 = SetButtonColorFromBulk(count[1]);
                    break;
                case "80":
                    ButtonColor80 = SetButtonColorFromBulk(count[1]);
                    break;
                case "81":
                    ButtonColor81 = SetButtonColorFromBulk(count[1]);
                    break;
                case "82":
                    ButtonColor82 = SetButtonColorFromBulk(count[1]);
                    break;
                case "83":
                    ButtonColor83 = SetButtonColorFromBulk(count[1]);
                    break;
                case "84":
                    ButtonColor84 = SetButtonColorFromBulk(count[1]);
                    break;
                case "85":
                    ButtonColor85 = SetButtonColorFromBulk(count[1]);
                    break;
                case "86":
                    ButtonColor86 = SetButtonColorFromBulk(count[1]);
                    break;
                case "87":
                    ButtonColor87 = SetButtonColorFromBulk(count[1]);
                    break;
                case "88":
                    ButtonColor88 = SetButtonColorFromBulk(count[1]);
                    break;
                case "89":
                    ButtonColor89 = SetButtonColorFromBulk(count[1]);
                    break;
                case "90":
                    ButtonColor90 = SetButtonColorFromBulk(count[1]);
                    break;
                case "91":
                    ButtonColor91 = SetButtonColorFromBulk(count[1]);
                    break;
                case "92":
                    ButtonColor92 = SetButtonColorFromBulk(count[1]);
                    break;
                case "93":
                    ButtonColor93 = SetButtonColorFromBulk(count[1]);
                    break;
                case "94":
                    ButtonColor94 = SetButtonColorFromBulk(count[1]);
                    break;
                case "95":
                    ButtonColor95 = SetButtonColorFromBulk(count[1]);
                    break;
                case "96":
                    ButtonColor96 = SetButtonColorFromBulk(count[1]);
                    break;
                case "97":
                    ButtonColor97 = SetButtonColorFromBulk(count[1]);
                    break;
                case "98":
                    ButtonColor98 = SetButtonColorFromBulk(count[1]);
                    break;
                case "99":
                    ButtonColor99 = SetButtonColorFromBulk(count[1]);
                    break;
                case "100":
                    ButtonColor100 = SetButtonColorFromBulk(count[1]);
                    break;
                case "101":
                    ButtonColor101 = SetButtonColorFromBulk(count[1]);
                    break;
                case "102":
                    ButtonColor102 = SetButtonColorFromBulk(count[1]);
                    break;
                case "103":
                    ButtonColor103 = SetButtonColorFromBulk(count[1]);
                    break;
                case "104":
                    ButtonColor104 = SetButtonColorFromBulk(count[1]);
                    break;
                case "105":
                    ButtonColor105 = SetButtonColorFromBulk(count[1]);
                    break;
                case "106":
                    ButtonColor106 = SetButtonColorFromBulk(count[1]);
                    break;
                case "107":
                    ButtonColor107 = SetButtonColorFromBulk(count[1]);
                    break;
                case "108":
                    ButtonColor108 = SetButtonColorFromBulk(count[1]);
                    break;
                case "109":
                    ButtonColor109 = SetButtonColorFromBulk(count[1]);
                    break;
                case "110":
                    ButtonColor110 = SetButtonColorFromBulk(count[1]);
                    break;
                case "111":
                    ButtonColor111 = SetButtonColorFromBulk(count[1]);
                    break;
                case "112":
                    ButtonColor112 = SetButtonColorFromBulk(count[1]);
                    break;
                case "113":
                    ButtonColor113 = SetButtonColorFromBulk(count[1]);
                    break;
                case "114":
                    ButtonColor114 = SetButtonColorFromBulk(count[1]);
                    break;
                case "115":
                    ButtonColor115 = SetButtonColorFromBulk(count[1]);
                    break;
                case "116":
                    ButtonColor116 = SetButtonColorFromBulk(count[1]);
                    break;
                case "117":
                    ButtonColor117 = SetButtonColorFromBulk(count[1]);
                    break;
                case "118":
                    ButtonColor118 = SetButtonColorFromBulk(count[1]);
                    break;
                case "119":
                    ButtonColor119 = SetButtonColorFromBulk(count[1]);
                    break;
                case "120":
                    ButtonColor120 = SetButtonColorFromBulk(count[1]);
                    break;
                case "121":
                    ButtonColor121 = SetButtonColorFromBulk(count[1]);
                    break;
                case "122":
                    ButtonColor122 = SetButtonColorFromBulk(count[1]);
                    break;
                case "123":
                    ButtonColor123 = SetButtonColorFromBulk(count[1]);
                    break;
                case "124":
                    ButtonColor124 = SetButtonColorFromBulk(count[1]);
                    break;
                case "125":
                    ButtonColor125 = SetButtonColorFromBulk(count[1]);
                    break;
                case "126":
                    ButtonColor126 = SetButtonColorFromBulk(count[1]);
                    break;
                case "127":
                    ButtonColor127 = SetButtonColorFromBulk(count[1]);
                    break;
                case "128":
                    ButtonColor128 = SetButtonColorFromBulk(count[1]);
                    break;
                case "129":
                    ButtonColor129 = SetButtonColorFromBulk(count[1]);
                    break;
                case "130":
                    ButtonColor130 = SetButtonColorFromBulk(count[1]);
                    break;
                case "131":
                    ButtonColor131 = SetButtonColorFromBulk(count[1]);
                    break;
                case "132":
                    ButtonColor132 = SetButtonColorFromBulk(count[1]);
                    break;
                case "133":
                    ButtonColor133 = SetButtonColorFromBulk(count[1]);
                    break;
                case "134":
                    ButtonColor134 = SetButtonColorFromBulk(count[1]);
                    break;

                case "135":
                    ButtonColor135 = SetButtonColorFromBulk(count[1]);
                    break;
                case "136":
                    ButtonColor136 = SetButtonColorFromBulk(count[1]);
                    break;
                case "137":
                    ButtonColor137 = SetButtonColorFromBulk(count[1]);
                    break;
                case "138":
                    ButtonColor138 = SetButtonColorFromBulk(count[1]);
                    break;
                case "139":
                    ButtonColor139 = SetButtonColorFromBulk(count[1]);
                    break;
                case "140":
                    ButtonColor140 = SetButtonColorFromBulk(count[1]);
                    break;
                case "141":
                    ButtonColor141 = SetButtonColorFromBulk(count[1]);
                    break;
                case "142":
                    ButtonColor142 = SetButtonColorFromBulk(count[1]);
                    break;
                case "143":
                    ButtonColor143 = SetButtonColorFromBulk(count[1]);
                    break;
                case "144":
                    ButtonColor144 = SetButtonColorFromBulk(count[1]);
                    break;
                case "145":
                    ButtonColor145 = SetButtonColorFromBulk(count[1]);
                    break;
                case "146":
                    ButtonColor146 = SetButtonColorFromBulk(count[1]);
                    break;
                case "147":
                    ButtonColor147 = SetButtonColorFromBulk(count[1]);
                    break;
                case "148":
                    ButtonColor148 = SetButtonColorFromBulk(count[1]);
                    break;
                case "149":
                    ButtonColor149 = SetButtonColorFromBulk(count[1]);
                    break;
                case "150":
                    ButtonColor150 = SetButtonColorFromBulk(count[1]);
                    break;
                case "151":
                    ButtonColor151 = SetButtonColorFromBulk(count[1]);
                    break;
                case "152":
                    ButtonColor152 = SetButtonColorFromBulk(count[1]);
                    break;
                case "153":
                    ButtonColor153 = SetButtonColorFromBulk(count[1]);
                    break;
                case "154":
                    ButtonColor154 = SetButtonColorFromBulk(count[1]);
                    break;
                case "155":
                    ButtonColor155 = SetButtonColorFromBulk(count[1]);
                    break;
                case "156":
                    ButtonColor156 = SetButtonColorFromBulk(count[1]);
                    break;
                case "157":
                    ButtonColor157 = SetButtonColorFromBulk(count[1]);
                    break;
                case "158":
                    ButtonColor158 = SetButtonColorFromBulk(count[1]);
                    break;
                case "159":
                    ButtonColor159 = SetButtonColorFromBulk(count[1]);
                    break;
                case "160":
                    ButtonColor160 = SetButtonColorFromBulk(count[1]);
                    break;
                case "161":
                    ButtonColor161 = SetButtonColorFromBulk(count[1]);
                    break;
                case "162":
                    ButtonColor162 = SetButtonColorFromBulk(count[1]);
                    break;
                case "163":
                    ButtonColor163 = SetButtonColorFromBulk(count[1]);
                    break;
                case "164":
                    ButtonColor164 = SetButtonColorFromBulk(count[1]);
                    break;
                case "165":
                    ButtonColor165 = SetButtonColorFromBulk(count[1]);
                    break;
                case "166":
                    ButtonColor166 = SetButtonColorFromBulk(count[1]);
                    break;
                case "167":
                    ButtonColor167 = SetButtonColorFromBulk(count[1]);
                    break;
                case "168":
                    ButtonColor168 = SetButtonColorFromBulk(count[1]);
                    break;
                case "169":
                    ButtonColor169 = SetButtonColorFromBulk(count[1]);
                    break;
                case "170":
                    ButtonColor170 = SetButtonColorFromBulk(count[1]);
                    break;
                case "171":
                    ButtonColor171 = SetButtonColorFromBulk(count[1]);
                    break;
                case "172":
                    ButtonColor172 = SetButtonColorFromBulk(count[1]);
                    break;
                case "173":
                    ButtonColor173 = SetButtonColorFromBulk(count[1]);
                    break;
                case "174":
                    ButtonColor174 = SetButtonColorFromBulk(count[1]);
                    break;
                case "175":
                    ButtonColor175 = SetButtonColorFromBulk(count[1]);
                    break;
                case "176":
                    ButtonColor176 = SetButtonColorFromBulk(count[1]);
                    break;
                case "177":
                    ButtonColor177 = SetButtonColorFromBulk(count[1]);
                    break;
                case "178":
                    ButtonColor178 = SetButtonColorFromBulk(count[1]);
                    break;
                case "179":
                    ButtonColor179 = SetButtonColorFromBulk(count[1]);
                    break;
                case "180":
                    ButtonColor180 = SetButtonColorFromBulk(count[1]);
                    break;
                case "181":
                    ButtonColor181 = SetButtonColorFromBulk(count[1]);
                    break;
                case "182":
                    ButtonColor182 = SetButtonColorFromBulk(count[1]);
                    break;
                case "183":
                    ButtonColor183 = SetButtonColorFromBulk(count[1]);
                    break;
                case "184":
                    ButtonColor184 = SetButtonColorFromBulk(count[1]);
                    break;
                case "185":
                    ButtonColor185 = SetButtonColorFromBulk(count[1]);
                    break;
                case "186":
                    ButtonColor186 = SetButtonColorFromBulk(count[1]);
                    break;
                case "187":
                    ButtonColor187 = SetButtonColorFromBulk(count[1]);
                    break;
                case "188":
                    ButtonColor188 = SetButtonColorFromBulk(count[1]);
                    break;
                case "189":
                    ButtonColor189 = SetButtonColorFromBulk(count[1]);
                    break;
                case "190":
                    ButtonColor190 = SetButtonColorFromBulk(count[1]);
                    break;
                case "191":
                    ButtonColor191 = SetButtonColorFromBulk(count[1]);
                    break;

                case "192":
                    ButtonColor192 = SetButtonColorFromBulk(count[1]);
                    break;
                case "193":
                    ButtonColor193 = SetButtonColorFromBulk(count[1]);
                    break;
                case "194":
                    ButtonColor194 = SetButtonColorFromBulk(count[1]);
                    break;
                case "195":
                    ButtonColor195 = SetButtonColorFromBulk(count[1]);
                    break;
                case "196":
                    ButtonColor196 = SetButtonColorFromBulk(count[1]);
                    break;
                case "197":
                    ButtonColor197 = SetButtonColorFromBulk(count[1]);
                    break;
                case "198":
                    ButtonColor198 = SetButtonColorFromBulk(count[1]);
                    break;
                case "199":
                    ButtonColor199 = SetButtonColorFromBulk(count[1]);
                    break;
                case "200":
                    ButtonColor200 = SetButtonColorFromBulk(count[1]);
                    break;
            }
        }
        #endregion

        #region SetButtonColorFromBulk
        private Color SetButtonColorFromBulk(string answerType)
        {
            if (answerType == "Answered")
            {
                return ButtonColorAnswerwed;
            }
            else if (answerType == "NotAnswered")
            {
                return ButtonColorNotAnswerwed;
            }
            else
            {
                return ButtonColorNotVisited;
            }
        }
        #endregion

        #region properties
        private bool _IsVisibleFinishButton;
        public bool IsVisibleFinishButton
        {
            get { return _IsVisibleFinishButton; }
            set { _IsVisibleFinishButton = value; OnPropertyChanged(); }
        }

        private bool _IsShowCameraPreView;
        public bool IsShowCameraPreView
        {
            get { return _IsShowCameraPreView; }
            set { _IsShowCameraPreView = value; OnPropertyChanged(); }
        }

        private bool _IsShowUserProfile;
        public bool IsShowUserProfile
        {
            get { return _IsShowUserProfile; }
            set { _IsShowUserProfile = value; OnPropertyChanged(); }
        }
        private string _arrowChange;
        public string ArrowChange
        {
            get { return _arrowChange; }
            set { _arrowChange = value; OnPropertyChanged(); }
        }


        private Boolean isShowIOSOnly;
        public Boolean IsShowIOSOnly
        {
            get { return isShowIOSOnly; }
            set { isShowIOSOnly = value; OnPropertyChanged(); }
        }

        private String candidateAssessmentName;
        public String CandidateAssessmentName
        {
            get { return candidateAssessmentName; }
            set { candidateAssessmentName = value; OnPropertyChanged(); }
        }

        private String candidateSyllabus;
        public String CandidateSyllabus
        {
            get { return candidateSyllabus; }
            set { candidateSyllabus = value; OnPropertyChanged(); }
        }

        private String testPicture;
        public String TestPicture
        {
            get { return testPicture; }
            set { testPicture = value; OnPropertyChanged(); }
        }

        private String totalDuration;
        public String TotalDuration
        {
            get { return totalDuration; }
            set { totalDuration = "Duration :" + value; OnPropertyChanged(); }
        }


        private StackLayout _dynamicBtnStack;
        public StackLayout DynamicBtnStack
        {
            get { return _dynamicBtnStack; }
            set { _dynamicBtnStack = value; }
        }


        private String timerText;
        public String TimerText
        {
            get { return timerText; }
            set { timerText = value; OnPropertyChanged(); }
        }

        private bool _isVisibleGoBackButton;
        public bool IsVisibleGoBackButton
        {
            get { return _isVisibleGoBackButton; }
            set { _isVisibleGoBackButton = value; OnPropertyChanged(); }
        }

        private String serverTimerText;
        public String ServerTimerText
        {
            get { return serverTimerText; }
            set { serverTimerText = value; OnPropertyChanged(); }
        }


        private bool _IsVisbleBehaviourExamSelectionPart;
        public bool IsVisbleBehaviourExamSelectionPart
        {
            get { return _IsVisbleBehaviourExamSelectionPart; }
            set { _IsVisbleBehaviourExamSelectionPart = value; OnPropertyChanged(); }
        }

        //private ScrollView synamciButtonScrollView;
        //public ScrollView DynamciButtonScrollView
        //{
        //    get { return synamciButtonScrollView; }
        //    set { synamciButtonScrollView = value; }
        //}
        #endregion

        #region ChangeButtonColorSwitch
        public void ChangeButtonColorSwitch(int CurrentQeustionButtonColor)
        {
            switch (CurrentQeustionButtonColor)
            {
                case 1:
                    ButtonColor1 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 2:
                    ButtonColor2 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 3:
                    ButtonColor3 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 4:
                    ButtonColor4 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 5:
                    ButtonColor5 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 6:
                    ButtonColor6 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 7:
                    ButtonColor7 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 8:
                    ButtonColor8 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 9:
                    ButtonColor9 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 10:
                    ButtonColor10 = SetButtonColor(CurrentQeustionButtonColor);
                    break;

                case 11:
                    ButtonColor11 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 12:
                    ButtonColor12 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 13:
                    ButtonColor13 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 14:
                    ButtonColor14 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 15:
                    ButtonColor15 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 16:
                    ButtonColor16 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 17:
                    ButtonColor17 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 18:
                    ButtonColor18 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 19:
                    ButtonColor19 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 20:
                    ButtonColor20 = SetButtonColor(CurrentQeustionButtonColor);
                    break;

                case 21:
                    ButtonColor21 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 22:
                    ButtonColor22 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 23:
                    ButtonColor23 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 24:
                    ButtonColor24 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 25:
                    ButtonColor25 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 26:
                    ButtonColor26 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 27:
                    ButtonColor27 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 28:
                    ButtonColor28 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 29:
                    ButtonColor29 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 30:
                    ButtonColor30 = SetButtonColor(CurrentQeustionButtonColor);
                    break;

                case 31:
                    ButtonColor31 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 32:
                    ButtonColor32 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 33:
                    ButtonColor33 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 34:
                    ButtonColor34 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 35:
                    ButtonColor35 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 36:
                    ButtonColor36 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 37:
                    ButtonColor37 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 38:
                    ButtonColor38 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 39:
                    ButtonColor39 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 40:
                    ButtonColor40 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 41:
                    ButtonColor41 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 42:
                    ButtonColor42 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 43:
                    ButtonColor43 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 44:
                    ButtonColor44 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 45:
                    ButtonColor45 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 46:
                    ButtonColor46 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 47:
                    ButtonColor47 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 48:
                    ButtonColor48 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 49:
                    ButtonColor49 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 50:
                    ButtonColor50 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 51:
                    ButtonColor51 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 52:
                    ButtonColor52 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 53:
                    ButtonColor53 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 54:
                    ButtonColor54 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 55:
                    ButtonColor55 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 56:
                    ButtonColor56 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 57:
                    ButtonColor57 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 58:
                    ButtonColor58 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 59:
                    ButtonColor59 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 60:
                    ButtonColor60 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 61:
                    ButtonColor61 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 62:
                    ButtonColor62 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 63:
                    ButtonColor63 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 64:
                    ButtonColor64 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 65:
                    ButtonColor65 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 66:
                    ButtonColor66 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 67:
                    ButtonColor67 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 68:
                    ButtonColor68 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 69:
                    ButtonColor69 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 70:
                    ButtonColor70 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 71:
                    ButtonColor71 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 72:
                    ButtonColor72 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 73:
                    ButtonColor73 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 74:
                    ButtonColor74 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 75:
                    ButtonColor75 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 76:
                    ButtonColor76 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 77:
                    ButtonColor77 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 78:
                    ButtonColor78 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 79:
                    ButtonColor79 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 80:
                    ButtonColor80 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 81:
                    ButtonColor81 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 82:
                    ButtonColor82 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 83:
                    ButtonColor83 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 84:
                    ButtonColor84 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 85:
                    ButtonColor85 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 86:
                    ButtonColor86 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 87:
                    ButtonColor87 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 88:
                    ButtonColor88 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 89:
                    ButtonColor89 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 90:
                    ButtonColor90 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 91:
                    ButtonColor91 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 92:
                    ButtonColor92 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 93:
                    ButtonColor93 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 94:
                    ButtonColor94 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 95:
                    ButtonColor95 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 96:
                    ButtonColor96 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 97:
                    ButtonColor97 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 98:
                    ButtonColor98 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 99:
                    ButtonColor99 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 100:
                    ButtonColor100 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 101:
                    ButtonColor101 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 102:
                    ButtonColor102 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 103:
                    ButtonColor103 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 104:
                    ButtonColor104 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 105:
                    ButtonColor105 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 106:
                    ButtonColor106 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 107:
                    ButtonColor107 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 108:
                    ButtonColor108 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 109:
                    ButtonColor109 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 110:
                    ButtonColor110 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 111:
                    ButtonColor111 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 112:
                    ButtonColor112 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 113:
                    ButtonColor113 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 114:
                    ButtonColor114 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 115:
                    ButtonColor115 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 116:
                    ButtonColor116 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 117:
                    ButtonColor117 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 118:
                    ButtonColor118 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 119:
                    ButtonColor119 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 120:
                    ButtonColor120 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 121:
                    ButtonColor121 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 122:
                    ButtonColor122 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 123:
                    ButtonColor123 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 124:
                    ButtonColor124 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 125:
                    ButtonColor125 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 126:
                    ButtonColor126 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 127:
                    ButtonColor127 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 128:
                    ButtonColor128 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 129:
                    ButtonColor129 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 130:
                    ButtonColor130 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 131:
                    ButtonColor131 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 132:
                    ButtonColor132 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 133:
                    ButtonColor133 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 134:
                    ButtonColor134 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 135:
                    ButtonColor135 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 136:
                    ButtonColor136 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 137:
                    ButtonColor137 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 138:
                    ButtonColor138 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 139:
                    ButtonColor139 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 140:
                    ButtonColor140 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 141:
                    ButtonColor141 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 142:
                    ButtonColor142 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 143:
                    ButtonColor143 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 144:
                    ButtonColor144 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 145:
                    ButtonColor145 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 146:
                    ButtonColor146 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 147:
                    ButtonColor147 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 148:
                    ButtonColor148 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 149:
                    ButtonColor149 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 150:
                    ButtonColor150 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 151:
                    ButtonColor151 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 152:
                    ButtonColor152 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 153:
                    ButtonColor153 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 154:
                    ButtonColor154 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 155:
                    ButtonColor155 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 156:
                    ButtonColor156 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 157:
                    ButtonColor157 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 158:
                    ButtonColor158 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 159:
                    ButtonColor159 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 160:
                    ButtonColor160 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 161:
                    ButtonColor161 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 162:
                    ButtonColor162 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 163:
                    ButtonColor163 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 164:
                    ButtonColor164 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 165:
                    ButtonColor165 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 166:
                    ButtonColor166 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 167:
                    ButtonColor167 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 168:
                    ButtonColor168 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 169:
                    ButtonColor169 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 170:
                    ButtonColor170 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 171:
                    ButtonColor171 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 172:
                    ButtonColor172 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 173:
                    ButtonColor173 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 174:
                    ButtonColor174 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 175:
                    ButtonColor175 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 176:
                    ButtonColor176 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 177:
                    ButtonColor177 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 178:
                    ButtonColor178 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 179:
                    ButtonColor179 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 180:
                    ButtonColor180 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 181:
                    ButtonColor181 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 182:
                    ButtonColor182 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 183:
                    ButtonColor183 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 184:
                    ButtonColor184 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 185:
                    ButtonColor185 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 186:
                    ButtonColor186 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 187:
                    ButtonColor187 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 188:
                    ButtonColor188 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 189:
                    ButtonColor189 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 190:
                    ButtonColor190 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 191:
                    ButtonColor191 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 192:
                    ButtonColor192 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 194:
                    ButtonColor194 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 195:
                    ButtonColor195 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 196:
                    ButtonColor196 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 197:
                    ButtonColor197 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 198:
                    ButtonColor198 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 199:
                    ButtonColor199 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
                case 200:
                    ButtonColor200 = SetButtonColor(CurrentQeustionButtonColor);
                    break;
            }
        }
        #endregion

        #region button color properties

        private Color _buttonColor1;
        public Color ButtonColor1
        {
            get { return _buttonColor1; }
            set { _buttonColor1 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor2;
        public Color ButtonColor2
        {
            get { return _buttonColor2; }
            set { _buttonColor2 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor3;
        public Color ButtonColor3
        {
            get { return _buttonColor3; }
            set { _buttonColor3 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor4;
        public Color ButtonColor4
        {
            get { return _buttonColor4; }
            set { _buttonColor4 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor5;
        public Color ButtonColor5
        {
            get { return _buttonColor5; }
            set { _buttonColor5 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor6;
        public Color ButtonColor6
        {
            get { return _buttonColor6; }
            set { _buttonColor6 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor7;
        public Color ButtonColor7
        {
            get { return _buttonColor7; }
            set { _buttonColor7 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor8;
        public Color ButtonColor8
        {
            get { return _buttonColor8; }
            set { _buttonColor8 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor9;
        public Color ButtonColor9
        {
            get { return _buttonColor9; }
            set { _buttonColor9 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor10;
        public Color ButtonColor10
        {
            get { return _buttonColor10; }
            set { _buttonColor10 = value; OnPropertyChanged(); }
        }

        private Color _buttonColor11;
        public Color ButtonColor11
        {
            get { return _buttonColor11; }
            set { _buttonColor11 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor12;
        public Color ButtonColor12
        {
            get { return _buttonColor12; }
            set { _buttonColor12 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor13;
        public Color ButtonColor13
        {
            get { return _buttonColor13; }
            set { _buttonColor13 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor14;
        public Color ButtonColor14
        {
            get { return _buttonColor14; }
            set { _buttonColor14 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor15;
        public Color ButtonColor15
        {
            get { return _buttonColor15; }
            set { _buttonColor15 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor16;
        public Color ButtonColor16
        {
            get { return _buttonColor16; }
            set { _buttonColor16 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor17;
        public Color ButtonColor17
        {
            get { return _buttonColor17; }
            set { _buttonColor17 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor18;
        public Color ButtonColor18
        {
            get { return _buttonColor18; }
            set { _buttonColor18 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor19;
        public Color ButtonColor19
        {
            get { return _buttonColor19; }
            set { _buttonColor19 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor20;
        public Color ButtonColor20
        {
            get { return _buttonColor20; }
            set { _buttonColor20 = value; OnPropertyChanged(); }
        }

        private Color _buttonColor21;
        public Color ButtonColor21
        {
            get { return _buttonColor21; }
            set { _buttonColor21 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor22;
        public Color ButtonColor22
        {
            get { return _buttonColor22; }
            set { _buttonColor22 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor23;
        public Color ButtonColor23
        {
            get { return _buttonColor23; }
            set { _buttonColor23 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor24;
        public Color ButtonColor24
        {
            get { return _buttonColor24; }
            set { _buttonColor24 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor25;
        public Color ButtonColor25
        {
            get { return _buttonColor25; }
            set { _buttonColor25 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor26;
        public Color ButtonColor26
        {
            get { return _buttonColor26; }
            set { _buttonColor26 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor27;
        public Color ButtonColor27
        {
            get { return _buttonColor27; }
            set { _buttonColor27 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor28;
        public Color ButtonColor28
        {
            get { return _buttonColor28; }
            set { _buttonColor28 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor29;
        public Color ButtonColor29
        {
            get { return _buttonColor29; }
            set { _buttonColor29 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor30;
        public Color ButtonColor30
        {
            get { return _buttonColor30; }
            set { _buttonColor30 = value; OnPropertyChanged(); }
        }

        private Color _buttonColor31;
        public Color ButtonColor31
        {
            get { return _buttonColor31; }
            set { _buttonColor31 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor32;
        public Color ButtonColor32
        {
            get { return _buttonColor32; }
            set { _buttonColor32 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor33;
        public Color ButtonColor33
        {
            get { return _buttonColor33; }
            set { _buttonColor33 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor34;
        public Color ButtonColor34
        {
            get { return _buttonColor34; }
            set { _buttonColor34 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor35;
        public Color ButtonColor35
        {
            get { return _buttonColor35; }
            set { _buttonColor35 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor36;
        public Color ButtonColor36
        {
            get { return _buttonColor36; }
            set { _buttonColor36 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor37;
        public Color ButtonColor37
        {
            get { return _buttonColor37; }
            set { _buttonColor37 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor38;
        public Color ButtonColor38
        {
            get { return _buttonColor38; }
            set { _buttonColor38 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor39;
        public Color ButtonColor39
        {
            get { return _buttonColor39; }
            set { _buttonColor39 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor40;
        public Color ButtonColor40
        {
            get { return _buttonColor40; }
            set { _buttonColor40 = value; OnPropertyChanged(); }
        }

        private Color _buttonColor41;
        public Color ButtonColor41
        {
            get { return _buttonColor41; }
            set { _buttonColor41 = value; OnPropertyChanged(); }
        }

        private Color _buttonColor42;
        public Color ButtonColor42
        {
            get { return _buttonColor42; }
            set { _buttonColor42 = value; OnPropertyChanged(); }
        }

        private Color _buttonColor43;
        public Color ButtonColor43
        {
            get { return _buttonColor43; }
            set { _buttonColor43 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor44;
        public Color ButtonColor44
        {
            get { return _buttonColor44; }
            set { _buttonColor44 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor45;
        public Color ButtonColor45
        {
            get { return _buttonColor45; }
            set { _buttonColor45 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor46;
        public Color ButtonColor46
        {
            get { return _buttonColor46; }
            set { _buttonColor46 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor47;
        public Color ButtonColor47
        {
            get { return _buttonColor47; }
            set { _buttonColor47 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor48;
        public Color ButtonColor48
        {
            get { return _buttonColor48; }
            set { _buttonColor48 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor49;
        public Color ButtonColor49
        {
            get { return _buttonColor49; }
            set { _buttonColor49 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor50;
        public Color ButtonColor50
        {
            get { return _buttonColor50; }
            set { _buttonColor50 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor51;
        public Color ButtonColor51
        {
            get { return _buttonColor51; }
            set { _buttonColor51 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor52;
        public Color ButtonColor52
        {
            get { return _buttonColor52; }
            set { _buttonColor52 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor53;
        public Color ButtonColor53
        {
            get { return _buttonColor53; }
            set { _buttonColor53 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor54;
        public Color ButtonColor54
        {
            get { return _buttonColor54; }
            set { _buttonColor54 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor55;
        public Color ButtonColor55
        {
            get { return _buttonColor55; }
            set { _buttonColor55 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor56;
        public Color ButtonColor56
        {
            get { return _buttonColor56; }
            set { _buttonColor56 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor57;
        public Color ButtonColor57
        {
            get { return _buttonColor57; }
            set { _buttonColor57 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor58;
        public Color ButtonColor58
        {
            get { return _buttonColor58; }
            set { _buttonColor58 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor59;
        public Color ButtonColor59
        {
            get { return _buttonColor59; }
            set { _buttonColor59 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor60;
        public Color ButtonColor60
        {
            get { return _buttonColor60; }
            set { _buttonColor60 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor61;
        public Color ButtonColor61
        {
            get { return _buttonColor61; }
            set { _buttonColor61 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor62;
        public Color ButtonColor62
        {
            get { return _buttonColor62; }
            set { _buttonColor62 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor63;
        public Color ButtonColor63
        {
            get { return _buttonColor63; }
            set { _buttonColor63 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor64;
        public Color ButtonColor64
        {
            get { return _buttonColor64; }
            set { _buttonColor64 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor65;
        public Color ButtonColor65
        {
            get { return _buttonColor65; }
            set { _buttonColor65 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor66;
        public Color ButtonColor66
        {
            get { return _buttonColor66; }
            set { _buttonColor66 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor67;
        public Color ButtonColor67
        {
            get { return _buttonColor67; }
            set { _buttonColor67 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor68;
        public Color ButtonColor68
        {
            get { return _buttonColor68; }
            set { _buttonColor68 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor69;
        public Color ButtonColor69
        {
            get { return _buttonColor69; }
            set { _buttonColor69 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor70;
        public Color ButtonColor70
        {
            get { return _buttonColor70; }
            set { _buttonColor70 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor71;
        public Color ButtonColor71
        {
            get { return _buttonColor71; }
            set { _buttonColor71 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor72;
        public Color ButtonColor72
        {
            get { return _buttonColor72; }
            set { _buttonColor72 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor73;
        public Color ButtonColor73
        {
            get { return _buttonColor73; }
            set { _buttonColor73 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor74;
        public Color ButtonColor74
        {
            get { return _buttonColor74; }
            set { _buttonColor74 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor75;
        public Color ButtonColor75
        {
            get { return _buttonColor75; }
            set { _buttonColor75 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor76;
        public Color ButtonColor76
        {
            get { return _buttonColor76; }
            set { _buttonColor76 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor77;
        public Color ButtonColor77
        {
            get { return _buttonColor77; }
            set { _buttonColor77 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor78;
        public Color ButtonColor78
        {
            get { return _buttonColor78; }
            set { _buttonColor78 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor79;
        public Color ButtonColor79
        {
            get { return _buttonColor79; }
            set { _buttonColor79 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor80;
        public Color ButtonColor80
        {
            get { return _buttonColor80; }
            set { _buttonColor80 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor81;
        public Color ButtonColor81
        {
            get { return _buttonColor81; }
            set { _buttonColor81 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor82;
        public Color ButtonColor82
        {
            get { return _buttonColor82; }
            set { _buttonColor82 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor83;
        public Color ButtonColor83
        {
            get { return _buttonColor83; }
            set { _buttonColor83 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor84;
        public Color ButtonColor84
        {
            get { return _buttonColor84; }
            set { _buttonColor84 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor85;
        public Color ButtonColor85
        {
            get { return _buttonColor85; }
            set { _buttonColor85 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor86;
        public Color ButtonColor86
        {
            get { return _buttonColor86; }
            set { _buttonColor86 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor87;
        public Color ButtonColor87
        {
            get { return _buttonColor87; }
            set { _buttonColor87 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor88;
        public Color ButtonColor88
        {
            get { return _buttonColor88; }
            set { _buttonColor88 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor89;
        public Color ButtonColor89
        {
            get { return _buttonColor89; }
            set { _buttonColor89 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor90;
        public Color ButtonColor90
        {
            get { return _buttonColor90; }
            set { _buttonColor90 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor91;
        public Color ButtonColor91
        {
            get { return _buttonColor91; }
            set { _buttonColor91 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor92;
        public Color ButtonColor92
        {
            get { return _buttonColor92; }
            set { _buttonColor92 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor93;
        public Color ButtonColor93
        {
            get { return _buttonColor93; }
            set { _buttonColor93 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor94;
        public Color ButtonColor94
        {
            get { return _buttonColor94; }
            set { _buttonColor94 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor95;
        public Color ButtonColor95
        {
            get { return _buttonColor95; }
            set { _buttonColor95 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor96;
        public Color ButtonColor96
        {
            get { return _buttonColor96; }
            set { _buttonColor96 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor97;
        public Color ButtonColor97
        {
            get { return _buttonColor97; }
            set { _buttonColor97 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor98;
        public Color ButtonColor98
        {
            get { return _buttonColor98; }
            set { _buttonColor98 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor99;
        public Color ButtonColor99
        {
            get { return _buttonColor99; }
            set { _buttonColor99 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor100;
        public Color ButtonColor100
        {
            get { return _buttonColor100; }
            set { _buttonColor100 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor101;
        public Color ButtonColor101
        {
            get { return _buttonColor101; }
            set { _buttonColor101 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor102;
        public Color ButtonColor102
        {
            get { return _buttonColor102; }
            set { _buttonColor102 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor103;
        public Color ButtonColor103
        {
            get { return _buttonColor103; }
            set { _buttonColor103 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor104;
        public Color ButtonColor104
        {
            get { return _buttonColor104; }
            set { _buttonColor104 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor105;
        public Color ButtonColor105
        {
            get { return _buttonColor105; }
            set { _buttonColor105 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor106;
        public Color ButtonColor106
        {
            get { return _buttonColor106; }
            set { _buttonColor106 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor107;
        public Color ButtonColor107
        {
            get { return _buttonColor107; }
            set { _buttonColor107 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor108;
        public Color ButtonColor108
        {
            get { return _buttonColor108; }
            set { _buttonColor108 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor109;
        public Color ButtonColor109
        {
            get { return _buttonColor109; }
            set { _buttonColor109 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor110;
        public Color ButtonColor110
        {
            get { return _buttonColor110; }
            set { _buttonColor110 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor111;
        public Color ButtonColor111
        {
            get { return _buttonColor111; }
            set { _buttonColor111 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor112;
        public Color ButtonColor112
        {
            get { return _buttonColor112; }
            set { _buttonColor112 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor113;
        public Color ButtonColor113
        {
            get { return _buttonColor113; }
            set { _buttonColor113 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor114;
        public Color ButtonColor114
        {
            get { return _buttonColor114; }
            set { _buttonColor114 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor115;
        public Color ButtonColor115
        {
            get { return _buttonColor115; }
            set { _buttonColor115 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor116;
        public Color ButtonColor116
        {
            get { return _buttonColor116; }
            set { _buttonColor116 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor117;
        public Color ButtonColor117
        {
            get { return _buttonColor117; }
            set { _buttonColor117 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor118;
        public Color ButtonColor118
        {
            get { return _buttonColor118; }
            set { _buttonColor118 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor119;
        public Color ButtonColor119
        {
            get { return _buttonColor119; }
            set { _buttonColor119 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor120;
        public Color ButtonColor120
        {
            get { return _buttonColor120; }
            set { _buttonColor120 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor121;
        public Color ButtonColor121
        {
            get { return _buttonColor121; }
            set { _buttonColor121 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor122;
        public Color ButtonColor122
        {
            get { return _buttonColor122; }
            set { _buttonColor122 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor123;
        public Color ButtonColor123
        {
            get { return _buttonColor123; }
            set { _buttonColor123 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor124;
        public Color ButtonColor124
        {
            get { return _buttonColor124; }
            set { _buttonColor124 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor125;
        public Color ButtonColor125
        {
            get { return _buttonColor125; }
            set { _buttonColor125 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor126;
        public Color ButtonColor126
        {
            get { return _buttonColor126; }
            set { _buttonColor126 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor127;
        public Color ButtonColor127
        {
            get { return _buttonColor127; }
            set { _buttonColor127 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor128;
        public Color ButtonColor128
        {
            get { return _buttonColor128; }
            set { _buttonColor128 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor129;
        public Color ButtonColor129
        {
            get { return _buttonColor129; }
            set { _buttonColor129 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor130;
        public Color ButtonColor130
        {
            get { return _buttonColor130; }
            set { _buttonColor130 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor131;
        public Color ButtonColor131
        {
            get { return _buttonColor131; }
            set { _buttonColor131 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor132;
        public Color ButtonColor132
        {
            get { return _buttonColor132; }
            set { _buttonColor132 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor133;
        public Color ButtonColor133
        {
            get { return _buttonColor133; }
            set { _buttonColor133 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor134;
        public Color ButtonColor134
        {
            get { return _buttonColor134; }
            set { _buttonColor134 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor135;
        public Color ButtonColor135
        {
            get { return _buttonColor135; }
            set { _buttonColor135 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor136;
        public Color ButtonColor136
        {
            get { return _buttonColor136; }
            set { _buttonColor136 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor137;
        public Color ButtonColor137
        {
            get { return _buttonColor137; }
            set { _buttonColor137 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor138;
        public Color ButtonColor138
        {
            get { return _buttonColor138; }
            set { _buttonColor138 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor139;
        public Color ButtonColor139
        {
            get { return _buttonColor139; }
            set { _buttonColor139 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor140;
        public Color ButtonColor140
        {
            get { return _buttonColor140; }
            set { _buttonColor140 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor141;
        public Color ButtonColor141
        {
            get { return _buttonColor141; }
            set { _buttonColor141 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor142;
        public Color ButtonColor142
        {
            get { return _buttonColor142; }
            set { _buttonColor142 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor143;
        public Color ButtonColor143
        {
            get { return _buttonColor143; }
            set { _buttonColor143 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor144;
        public Color ButtonColor144
        {
            get { return _buttonColor144; }
            set { _buttonColor144 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor145;
        public Color ButtonColor145
        {
            get { return _buttonColor145; }
            set { _buttonColor145 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor146;
        public Color ButtonColor146
        {
            get { return _buttonColor146; }
            set { _buttonColor146 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor147;
        public Color ButtonColor147
        {
            get { return _buttonColor147; }
            set { _buttonColor147 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor148;
        public Color ButtonColor148
        {
            get { return _buttonColor148; }
            set { _buttonColor148 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor149;
        public Color ButtonColor149
        {
            get { return _buttonColor149; }
            set { _buttonColor149 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor150;
        public Color ButtonColor150
        {
            get { return _buttonColor150; }
            set { _buttonColor150 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor151;
        public Color ButtonColor151
        {
            get { return _buttonColor151; }
            set { _buttonColor151 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor152;
        public Color ButtonColor152
        {
            get { return _buttonColor152; }
            set { _buttonColor152 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor153;
        public Color ButtonColor153
        {
            get { return _buttonColor153; }
            set { _buttonColor153 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor154;
        public Color ButtonColor154
        {
            get { return _buttonColor154; }
            set { _buttonColor154 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor155;
        public Color ButtonColor155
        {
            get { return _buttonColor155; }
            set { _buttonColor155 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor156;
        public Color ButtonColor156
        {
            get { return _buttonColor156; }
            set { _buttonColor156 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor157;
        public Color ButtonColor157
        {
            get { return _buttonColor157; }
            set { _buttonColor157 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor158;
        public Color ButtonColor158
        {
            get { return _buttonColor158; }
            set { _buttonColor158 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor159;
        public Color ButtonColor159
        {
            get { return _buttonColor159; }
            set { _buttonColor159 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor160;
        public Color ButtonColor160
        {
            get { return _buttonColor160; }
            set { _buttonColor160 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor161;
        public Color ButtonColor161
        {
            get { return _buttonColor161; }
            set { _buttonColor161 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor162;
        public Color ButtonColor162
        {
            get { return _buttonColor162; }
            set { _buttonColor162 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor163;
        public Color ButtonColor163
        {
            get { return _buttonColor163; }
            set { _buttonColor163 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor164;
        public Color ButtonColor164
        {
            get { return _buttonColor164; }
            set { _buttonColor164 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor165;
        public Color ButtonColor165
        {
            get { return _buttonColor165; }
            set { _buttonColor165 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor166;
        public Color ButtonColor166
        {
            get { return _buttonColor166; }
            set { _buttonColor166 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor167;
        public Color ButtonColor167
        {
            get { return _buttonColor167; }
            set { _buttonColor167 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor168;
        public Color ButtonColor168
        {
            get { return _buttonColor168; }
            set { _buttonColor168 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor169;
        public Color ButtonColor169
        {
            get { return _buttonColor169; }
            set { _buttonColor169 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor170;
        public Color ButtonColor170
        {
            get { return _buttonColor170; }
            set { _buttonColor170 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor171;
        public Color ButtonColor171
        {
            get { return _buttonColor171; }
            set { _buttonColor171 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor172;
        public Color ButtonColor172
        {
            get { return _buttonColor172; }
            set { _buttonColor172 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor173;
        public Color ButtonColor173
        {
            get { return _buttonColor173; }
            set { _buttonColor173 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor174;
        public Color ButtonColor174
        {
            get { return _buttonColor174; }
            set { _buttonColor174 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor175;
        public Color ButtonColor175
        {
            get { return _buttonColor175; }
            set { _buttonColor175 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor176;
        public Color ButtonColor176
        {
            get { return _buttonColor176; }
            set { _buttonColor176 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor177;
        public Color ButtonColor177
        {
            get { return _buttonColor177; }
            set { _buttonColor177 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor178;
        public Color ButtonColor178
        {
            get { return _buttonColor178; }
            set { _buttonColor178 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor179;
        public Color ButtonColor179
        {
            get { return _buttonColor179; }
            set { _buttonColor179 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor180;
        public Color ButtonColor180
        {
            get { return _buttonColor180; }
            set { _buttonColor180 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor181;
        public Color ButtonColor181
        {
            get { return _buttonColor181; }
            set { _buttonColor181 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor182;
        public Color ButtonColor182
        {
            get { return _buttonColor182; }
            set { _buttonColor182 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor183;
        public Color ButtonColor183
        {
            get { return _buttonColor183; }
            set { _buttonColor183 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor184;
        public Color ButtonColor184
        {
            get { return _buttonColor184; }
            set { _buttonColor184 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor185;
        public Color ButtonColor185
        {
            get { return _buttonColor185; }
            set { _buttonColor185 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor186;
        public Color ButtonColor186
        {
            get { return _buttonColor186; }
            set { _buttonColor186 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor187;
        public Color ButtonColor187
        {
            get { return _buttonColor187; }
            set { _buttonColor187 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor188;
        public Color ButtonColor188
        {
            get { return _buttonColor188; }
            set { _buttonColor188 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor189;
        public Color ButtonColor189
        {
            get { return _buttonColor189; }
            set { _buttonColor189 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor190;
        public Color ButtonColor190
        {
            get { return _buttonColor190; }
            set { _buttonColor190 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor191;
        public Color ButtonColor191
        {
            get { return _buttonColor191; }
            set { _buttonColor191 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor192;
        public Color ButtonColor192
        {
            get { return _buttonColor192; }
            set { _buttonColor192 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor193;
        public Color ButtonColor193
        {
            get { return _buttonColor193; }
            set { _buttonColor193 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor194;
        public Color ButtonColor194
        {
            get { return _buttonColor194; }
            set { _buttonColor194 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor195;
        public Color ButtonColor195
        {
            get { return _buttonColor195; }
            set { _buttonColor195 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor196;
        public Color ButtonColor196
        {
            get { return _buttonColor196; }
            set { _buttonColor196 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor197;
        public Color ButtonColor197
        {
            get { return _buttonColor197; }
            set { _buttonColor197 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor198;
        public Color ButtonColor198
        {
            get { return _buttonColor198; }
            set { _buttonColor198 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor199;
        public Color ButtonColor199
        {
            get { return _buttonColor199; }
            set { _buttonColor199 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor200;
        public Color ButtonColor200
        {
            get { return _buttonColor200; }
            set { _buttonColor200 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor201;
        public Color ButtonColor201
        {
            get { return _buttonColor201; }
            set { _buttonColor201 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor202;
        public Color ButtonColor202
        {
            get { return _buttonColor202; }
            set { _buttonColor202 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor203;
        public Color ButtonColor203
        {
            get { return _buttonColor203; }
            set { _buttonColor203 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor204;
        public Color ButtonColor204
        {
            get { return _buttonColor204; }
            set { _buttonColor204 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor205;
        public Color ButtonColor205
        {
            get { return _buttonColor205; }
            set { _buttonColor205 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor206;
        public Color ButtonColor206
        {
            get { return _buttonColor206; }
            set { _buttonColor206 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor207;
        public Color ButtonColor207
        {
            get { return _buttonColor207; }
            set { _buttonColor207 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor208;
        public Color ButtonColor208
        {
            get { return _buttonColor208; }
            set { _buttonColor208 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor209;
        public Color ButtonColor209
        {
            get { return _buttonColor209; }
            set { _buttonColor209 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor210;
        public Color ButtonColor210
        {
            get { return _buttonColor210; }
            set { _buttonColor210 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor211;
        public Color ButtonColor211
        {
            get { return _buttonColor211; }
            set { _buttonColor211 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor212;
        public Color ButtonColor212
        {
            get { return _buttonColor212; }
            set { _buttonColor212 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor213;
        public Color ButtonColor213
        {
            get { return _buttonColor213; }
            set { _buttonColor213 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor214;
        public Color ButtonColor214
        {
            get { return _buttonColor214; }
            set { _buttonColor214 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor215;
        public Color ButtonColor215
        {
            get { return _buttonColor215; }
            set { _buttonColor215 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor216;
        public Color ButtonColor216
        {
            get { return _buttonColor216; }
            set { _buttonColor216 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor217;
        public Color ButtonColor217
        {
            get { return _buttonColor217; }
            set { _buttonColor217 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor218;
        public Color ButtonColor218
        {
            get { return _buttonColor218; }
            set { _buttonColor218 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor219;
        public Color ButtonColor219
        {
            get { return _buttonColor219; }
            set { _buttonColor219 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor220;
        public Color ButtonColor220
        {
            get { return _buttonColor220; }
            set { _buttonColor220 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor221;
        public Color ButtonColor221
        {
            get { return _buttonColor221; }
            set { _buttonColor221 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor222;
        public Color ButtonColor222
        {
            get { return _buttonColor222; }
            set { _buttonColor222 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor223;
        public Color ButtonColor223
        {
            get { return _buttonColor223; }
            set { _buttonColor223 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor224;
        public Color ButtonColor224
        {
            get { return _buttonColor224; }
            set { _buttonColor224 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor225;
        public Color ButtonColor225
        {
            get { return _buttonColor225; }
            set { _buttonColor225 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor226;
        public Color ButtonColor226
        {
            get { return _buttonColor226; }
            set { _buttonColor226 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor227;
        public Color ButtonColor227
        {
            get { return _buttonColor227; }
            set { _buttonColor227 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor228;
        public Color ButtonColor228
        {
            get { return _buttonColor228; }
            set { _buttonColor228 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor229;
        public Color ButtonColor229
        {
            get { return _buttonColor229; }
            set { _buttonColor229 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor230;
        public Color ButtonColor230
        {
            get { return _buttonColor230; }
            set { _buttonColor230 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor231;
        public Color ButtonColor231
        {
            get { return _buttonColor231; }
            set { _buttonColor231 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor232;
        public Color ButtonColor232
        {
            get { return _buttonColor232; }
            set { _buttonColor232 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor233;
        public Color ButtonColor233
        {
            get { return _buttonColor233; }
            set { _buttonColor233 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor234;
        public Color ButtonColor234
        {
            get { return _buttonColor234; }
            set { _buttonColor234 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor235;
        public Color ButtonColor235
        {
            get { return _buttonColor235; }
            set { _buttonColor235 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor236;
        public Color ButtonColor236
        {
            get { return _buttonColor236; }
            set { _buttonColor236 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor237;
        public Color ButtonColor237
        {
            get { return _buttonColor237; }
            set { _buttonColor237 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor238;
        public Color ButtonColor238
        {
            get { return _buttonColor238; }
            set { _buttonColor238 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor239;
        public Color ButtonColor239
        {
            get { return _buttonColor239; }
            set { _buttonColor239 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor240;
        public Color ButtonColor240
        {
            get { return _buttonColor240; }
            set { _buttonColor240 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor241;
        public Color ButtonColor241
        {
            get { return _buttonColor241; }
            set { _buttonColor241 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor242;
        public Color ButtonColor242
        {
            get { return _buttonColor242; }
            set { _buttonColor242 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor243;
        public Color ButtonColor243
        {
            get { return _buttonColor243; }
            set { _buttonColor243 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor244;
        public Color ButtonColor244
        {
            get { return _buttonColor244; }
            set { _buttonColor244 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor245;
        public Color ButtonColor245
        {
            get { return _buttonColor245; }
            set { _buttonColor245 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor246;
        public Color ButtonColor246
        {
            get { return _buttonColor246; }
            set { _buttonColor246 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor247;
        public Color ButtonColor247
        {
            get { return _buttonColor247; }
            set { _buttonColor247 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor248;
        public Color ButtonColor248
        {
            get { return _buttonColor248; }
            set { _buttonColor248 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor249;
        public Color ButtonColor249
        {
            get { return _buttonColor249; }
            set { _buttonColor249 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor250;
        public Color ButtonColor250
        {
            get { return _buttonColor250; }
            set { _buttonColor250 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor251;
        public Color ButtonColor251
        {
            get { return _buttonColor251; }
            set { _buttonColor251 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor252;
        public Color ButtonColor252
        {
            get { return _buttonColor252; }
            set { _buttonColor252 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor253;
        public Color ButtonColor253
        {
            get { return _buttonColor253; }
            set { _buttonColor253 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor254;
        public Color ButtonColor254
        {
            get { return _buttonColor254; }
            set { _buttonColor254 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor255;
        public Color ButtonColor255
        {
            get { return _buttonColor255; }
            set { _buttonColor255 = value; OnPropertyChanged(); }
        }

        private Color _buttonColor256;
        public Color ButtonColor256
        {
            get { return _buttonColor256; }
            set { _buttonColor256 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor257;
        public Color ButtonColor257
        {
            get { return _buttonColor257; }
            set { _buttonColor257 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor258;
        public Color ButtonColor258
        {
            get { return _buttonColor258; }
            set { _buttonColor258 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor259;
        public Color ButtonColor259
        {
            get { return _buttonColor259; }
            set { _buttonColor259 = value; OnPropertyChanged(); }
        }
        private Color _buttonColor260;
        public Color ButtonColor260
        {
            get { return _buttonColor260; }
            set { _buttonColor260 = value; OnPropertyChanged(); }
        }
        #endregion

    }
}
























