﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.LocalDataBase;
using HireMe.Models.PRO_Assessment;
using HireMe.Views;
using HireMe.Views.PRO_Assessment;
using MvvmHelpers;
using Newtonsoft.Json;
using Plugin.Connectivity;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace HireMe.ViewModels.PRO_Assessment
{
    public class PRO_ExamInstructionViewModel : BaseViewModel
    {
        #region variable declaration
        public ICommand CommonCommand { get; set; }
        public int IsInstructionConfirm = 0;
        CancellationTokenSource _CancellationTokenSource;
        public bool isClicked = true;
        private HttpCommonService _commonservice { get; set; }
        public LocalDB _localDB { get; set; }
        SectionInstructionContent ObjContent { get; set; }
        private AssignedAssessmentDetails _TestPinMasterData;
        #endregion

        #region constructor
        public PRO_ExamInstructionViewModel(SectionInstructionContent objContent)
        {
            AppPreferences.IsPRO_Assesment_TimerRunning = false;
            Constant.heartbeatlogRunning = false;
            AppPreferences.Is_NavigationLog = false;
            ObjContent = objContent;
            IsVisibleTimer = true;
            IsVisibleProceed = false;
            _CancellationTokenSource = new CancellationTokenSource();
            IsInstructionConfirm = 0;
            CommonCommand = new Command(DoCommand);
            _commonservice = new HttpCommonService();
            _TestPinMasterData = AppPreferences.TestPinMasterData;
            _localDB = new LocalDB();
            ConfirmationCheckBox = (string)Application.Current.Resources["CheckBoxUnSelected"];
            AgreeInstructionMessage = "I read all the Instructions";
            TimerNotes = "Kindly Read the Instructions - ";
            LoadHTMLSource(objContent);
            if(objContent.isshow_instruction)
            {
                UpdateCompatiablityLOG();
            } 
        }
        #endregion

        #region DoCommand
        private async void DoCommand(object obj)
        {
            try
            {
                if (obj.ToString() == "Proceed")
                {
                    if (isClicked)
                    {
                        isClicked = false;
                        bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                        if (IsInstructionConfirm != 0 && isNetworkAvailable)
                        {
                            try
                            {
                                _localDB.DeletePROTables();
                            }
                            catch(Exception ex)
                            {
                                SendErrorMessageToServer(ex, "PRO_ExamInstructionViewModel.DeletePROTables");
                            }
                                
                                UserDialogs.Instance.ShowLoading();
                                await GetSectionDetails();
                           
                        }
                        else if (!isNetworkAvailable)
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                        }
                        else
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.PRO_InstructionReadConfirmation);
                        }
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                }
                else if (obj.ToString() == "ConfirmSelection")
                {
                    if (IsInstructionConfirm == 0)
                    {
                        ConfirmationCheckBox = (string)Application.Current.Resources["CheckBoxSelected"];
                        IsInstructionConfirm = 1;

                    }
                    else if (IsInstructionConfirm == 1)
                    {
                        ConfirmationCheckBox = (string)Application.Current.Resources["CheckBoxUnSelected"];
                        IsInstructionConfirm = 0;
                    }
                }
                else if (obj.ToString() == "Skip")
                {
                    App.Current.MainPage = new NavigationPage(new PRO_ExamPage(ObjContent));
                }
            }
            catch (Exception ex)
            {
                
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "PRO_ExamInstructionViewModel.DoCommand");
            }
        }
        #endregion

       

        #region LoadHTMLSource - Dynamic Instruction
        public async void LoadHTMLSource(SectionInstructionContent objContent)
        {
            try
            { 
                string data =    objContent.section_content;
               // string data = @"<span style=padding - left:30px;>" + objContent.section_content + "</span> ";
               // string data = @"<div style='margin: 0px 20px;'>" + objContent.section_content + "</div> ";
                if (!string.IsNullOrEmpty(data))
                {
                    UserDialogs.Instance.ShowLoading();
                    string htmlText = data.Replace(@"\", string.Empty);
                    var html = new HtmlWebViewSource
                    {
                        Html = htmlText
                    };
                    WebviewContent = html;
                    UserDialogs.Instance.HideLoading();

                    if (objContent.isshow_instruction)
                    {
                        PageTitle = "Exam Instruction";
                        TimerStart();
                    }
                    else
                    {
                        PageTitle = "Section Instruction";
                        IsVisibleSkip = true;
                        IsVisibleTimer = false;
                        IsVisibleProceed = false;
                    }
                }
                else
                {
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    App.Current.MainPage = new NavigationPage(new PRO_TestPinPage());
                }
            }
            catch (Exception ex)
            {
                
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "PRO_ExamInstructionViewModel.LoadHTMLSource");
            }
          
        }
        #endregion


        #region Update Compatiablity Log
        public async void UpdateCompatiablityLOG()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                var _CompatiablityRequest = new Compatiablity_LogRequestData();
                _CompatiablityRequest.testpin = AppPreferences.TestPinMasterData.testpin;
                _CompatiablityRequest.login_audit_id = AppPreferences.TestPinMasterData.login_audit_id;
                var result = await _commonservice.PostAsync<LogResponseData, Compatiablity_LogRequestData>(APIData.API_BASE_URL + APIMethods.CompatiablityLog, _CompatiablityRequest);
                if (result != null)
                {
                    if (result.code == "200")
                    {

                        UserDialogs.Instance.HideLoading();
                        //string data = AppPreferences.TestPinMasterData.exam_instruction;
                        //AppPreferences.ExamInstruction = AppPreferences.TestPinMasterData.exam_instruction;
                        //HireMe.Models.PRO_Assessment.SectionInstructionContent objContent = new HireMe.Models.PRO_Assessment.SectionInstructionContent();
                        //objContent.section_content = data;
                        //objContent.isshow_instruction = true;


                        //App.Current.MainPage = new NavigationPage(new PRO_ExamInstructionPage(objContent));

                     

                    }
                    else if (result.code == "199")
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(result.message);
                        Application.Current.MainPage = new NavigationPage(new PRO_TestPinPage());
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(result.message);
                        Application.Current.MainPage = new NavigationPage(new PRO_TestPinPage());
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    Application.Current.MainPage = new NavigationPage(new PRO_TestPinPage());
                }
            }
            catch (Exception ex)
            {
                
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "PRO_ExamInstructionViewModel.UpdateCompatiablityLOG");
            }
        }
        #endregion

        #region GetSectionDetails
        public async Task GetSectionDetails()
        {
            try
            {
                var _SectionDetailsRequest = new SectionDetailsRequest();
                _SectionDetailsRequest.testpin = _TestPinMasterData.testpin;
                _SectionDetailsRequest.assign_id = _TestPinMasterData.assign_id;
                _SectionDetailsRequest.login_audit_id = _TestPinMasterData.login_audit_id;

                var result = await _commonservice.PostAsync<SectionDetailsResponse, SectionDetailsRequest>(APIData.API_BASE_URL + APIMethods.GetSectionDetails, _SectionDetailsRequest);
                if (result != null)
                {
                    if (result.code == "200")
                    {

                        var serializeValue = JsonConvert.SerializeObject(result.responsedata);
                        AppPreferences.TestPinGroupDetailsSerialize = serializeValue;

                                List<tbl_timer> objtimer = new List<tbl_timer>();
                                tbl_timer tbl_timer;
                        for (int i = 0; i < result.responsedata.Count; i++)
                        {
                            tbl_timer = new tbl_timer();

                            if (_TestPinMasterData.duration_type == Convert.ToString((int)duration_type.ExamDuration))
                            {
                                if (i == 0)
                                {
                                    tbl_timer.elapsed_time = AppPreferences.PRO_ExamLastElapsedTime;
                                }
                            }
                            else
                            {
                                if (result.responsedata[i].Last_ElapsedTimeInSeconds != null)
                                {
                                    tbl_timer.elapsed_time = result.responsedata[i].Last_ElapsedTimeInSeconds;
                                }
                            }
                            //AppPreferences.SectionDetailsMasterData = result.responsedata[i];
                            tbl_timer.section_id = result.responsedata[i].section_id;
                            tbl_timer.examstatus = result.responsedata[i].section_status;
                            tbl_timer.sectionname = result.responsedata[i].name;
                            tbl_timer.sectioncount = result.responsedata[i].section_count;
                            tbl_timer.section_duration = result.responsedata[i].section_duration;
                            objtimer.Add(tbl_timer);
                        }
                        await _localDB.AddPROSectionTimerDetails(objtimer);
                        await GetQuestionDetails();
                    }
                    else if (result.code == "199")
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(result.message);
                        Application.Current.MainPage = new NavigationPage(new PRO_TestPinPage());
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(result.message);
                        Application.Current.MainPage = new NavigationPage(new PRO_TestPinPage());
                        return;
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    //Application.Current.MainPage = new NavigationPage(new PRO_TestPinPage());
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "PRO_ExamInstructionViewModel.GetSectionDetails");
            }
        } 
        #endregion

        #region GetQuestionDetails
        public async Task GetQuestionDetails()
        {
            try
            {
                var _QuestionDetailsRequest = new QuestionDetailsRequest();
                _QuestionDetailsRequest.testpin = _TestPinMasterData.testpin;
                _QuestionDetailsRequest.login_audit_id = _TestPinMasterData.login_audit_id;


                var result = await _commonservice.PostAsync<QuestionDetailsResponse, QuestionDetailsRequest>(APIData.API_BASE_URL + APIMethods.GetQuestionDetails, _QuestionDetailsRequest);
                if (result != null)
                {
                    if (result.code == "200")
                    {
                        var data = _localDB.GetAllPROSectionTimerList();

                        await _localDB.AddPROQuestions(result.questions);
                         var checking_purpose = _localDB.GetAllPROQuestionList();
                        await _localDB.AddPROOptions(result.questions_options);
                          var checking_purpos = _localDB.GetAllPROOptionList();
                        await _localDB.AddAssessmentAnswer(result.assessment_answer);
                         var checking_purpo = _localDB.GetAllAssessmentAnswer();
                        await _localDB.AddPROSubQuestions(result.sub_questions);
                         var checking_purposd = _localDB.GetAllPROSubQuestionList();


                        UserDialogs.Instance.HideLoading();
                        //string isImageProctore = _TestPinMasterData.is_image_proctering;
                        //if (!string.IsNullOrEmpty(isImageProctore) && isImageProctore == Convert.ToString((int)Is_image_proctering.Enable))
                        //{
                        //    Application.Current.MainPage = new NavigationPage(new AssesmentTakePhotoPage());
                        //}
                        //else
                        //{
                            if (_TestPinMasterData.is_section_navigation == Convert.ToString((int)is_section_navigation.Enable))
                            {
                                //GO to section page
                                Application.Current.MainPage = new NavigationPage(new PRO_ExamSectionPage());
                            }
                            else
                            {
                                // Directly go to MCQ screen
                                Application.Current.MainPage = new NavigationPage(new PRO_ExamPage());
                            }
                       // }
                    }
                    else if (result.code == "199")
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(result.message);
                        Application.Current.MainPage = new NavigationPage(new PRO_TestPinPage());
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(result.message);
                        Application.Current.MainPage = new NavigationPage(new PRO_TestPinPage());
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                }
            }
            catch (Exception ex)
            {
                
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "PRO_ExamInstructionViewModel.GetQuestionDetails");
            }
        } 
        #endregion

        #region Timer 
        private void TimerStart()
        {
            try
            {
                int Min = 0;
                int Sec = Constant.PRO_InstructionReadTiming;
                int TotalSec = (Min * 60) + Sec;

                CancellationTokenSource CTS = _CancellationTokenSource;

                Device.StartTimer(new TimeSpan(0, 0, 1), () =>
                {
                    if (CTS.IsCancellationRequested)
                    {
                        IsVisibleTimer = false;
                        IsVisibleProceed = true;
                        return false;
                    }
                    else
                    {
                        if (TotalSec == 0)
                        {
                            IsVisibleTimer = false;
                            IsVisibleProceed = true;
                            return false;
                        }
                        Device.BeginInvokeOnMainThread(() =>
                        {
                            TotalSec = TotalSec - 1;
                            TimeSpan _TimeSpan = TimeSpan.FromSeconds(TotalSec);
                            CountDownTik = string.Format("{1}", _TimeSpan.Minutes, _TimeSpan.Seconds);
                        });
                        return true;
                    }
                });
            }
            catch (Exception ex)
            {
                
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "PRO_ExamInstructionViewModel.TimerStart");
            }
        }

        public void TimerStop()
        {
            Interlocked.Exchange(ref _CancellationTokenSource, new CancellationTokenSource()).Cancel();
        }
        #endregion

        #region Binding Properties

        private string _AgreeInstructionMessage;

        public string AgreeInstructionMessage
        {
            get { return _AgreeInstructionMessage; }
            set { _AgreeInstructionMessage = value; OnPropertyChanged(); }
        }

        private string _confirmationCheckBox;

        public string ConfirmationCheckBox
        {
            get { return _confirmationCheckBox; }
            set { _confirmationCheckBox = value; OnPropertyChanged(); }
        }

        private string _TimerNotes;

        public string TimerNotes
        {
            get { return _TimerNotes; }
            set { _TimerNotes = value; OnPropertyChanged(); }
        }


        private bool _isVisibleProceed;

        public bool IsVisibleProceed
        {
            get { return _isVisibleProceed; }
            set { _isVisibleProceed = value; OnPropertyChanged(); }
        }

        private bool _isVisibleTimer;

        public bool IsVisibleTimer
        {
            get { return _isVisibleTimer; }
            set { _isVisibleTimer = value; OnPropertyChanged(); }
        }

        private string _countDownTik;

        public string CountDownTik
        {
            get { return _countDownTik; }
            set { _countDownTik = value; OnPropertyChanged(); }
        }



        bool _IsVisibleSkip;

        public bool IsVisibleSkip
        {
            get { return _IsVisibleSkip; }
            set { _IsVisibleSkip = value; OnPropertyChanged(); }
        }

        string _PageTitle;

        public string PageTitle
        {
            get { return _PageTitle; }
            set { _PageTitle = value; OnPropertyChanged(); }
        }




        private HtmlWebViewSource _webviewContent;

        public HtmlWebViewSource WebviewContent
        {
            get { return _webviewContent; }
            set { _webviewContent = value; OnPropertyChanged(); }
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
