﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.Interface;
using HireMe.LocalDataBase;
using HireMe.Models.PRO_Assessment;
using HireMe.Views.PRO_Assessment;
using HireMee.Models.PRO_Assessment;
using MvvmHelpers;
using Plugin.Connectivity;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace HireMe.ViewModels.PRO_Assessment
{
    public class PRO_ExamCompletedViewModel : BaseViewModel
    {
        #region  object declreation
        public bool isClicked = true;
        public Command OnCommand { get; set; }
        public INavigation NavigationService { get; set; }
        private HttpCommonService _commonservice { get; set; }
        private AssignedAssessmentDetails _TestPinMasterData { get; set; } = AppPreferences.TestPinMasterData;
        ResultResponse ExamResult { get; set; }
        #endregion

        #region constroctor
        public PRO_ExamCompletedViewModel(ResultResponse _ExamResult)
        {
            AppPreferences.IsPRO_Assesment_TimerRunning = false;
            Constant.heartbeatlogRunning = false;
            AppPreferences.Is_NavigationLog = false;
            ExamResult = _ExamResult;
            OnCommand = new Command(CommonFunction);
            _commonservice = new HttpCommonService();
            IsShowSectionScoreDetails = false;             IsShowNoScoreViewVisible = false;             IsShowScoreDetails = false;
            TestPicture = AppPreferences.PRO_TestLogo;
            if (String.IsNullOrEmpty(TestPicture))
            {
                TestPicture = "hiremee_assessment_icon.png";
            }
            ShowSectionScore();
        }
        #endregion
        public async void ShowSectionScore()
        {
            if (_TestPinMasterData.is_score_display == Convert.ToString((int)is_score_display.Enable))
            {
                if (!String.IsNullOrEmpty(ExamResult.answered_question))
                {
                    AnsweredQuestion = ExamResult.answered_question;
                }
                else
                {
                    AnsweredQuestion = "0";
                }
                if (!String.IsNullOrEmpty(ExamResult.unanswered_question))
                {
                    UnAnsweredQuestion = ExamResult.unanswered_question;
                }
                else
                {
                    UnAnsweredQuestion = "0";
                }

                if (!String.IsNullOrEmpty(ExamResult.negative_mark))
                {
                    NegativeMark = ExamResult.negative_mark;
                }
                else
                {
                    NegativeMark = "0";
                }
                if (ExamResult.SectionResult != null && ExamResult.SectionResult.Count > 0)
                {
                    List<ResultResponseData> _tempitemSource = new List<ResultResponseData>();
                    foreach (var item in ExamResult.SectionResult)
                    {
                        ResultResponseData obj = new ResultResponseData();
                        obj.outof_score = item.overall_score + "/" + item.total_score;
                        obj.section_name = item.section_name;
                        //obj.pool_name = item.pool_name;
                        //obj.topic_name = item.topic_name;
                        _tempitemSource.Add(obj);
                    }
                    SectionScoreListItemSource = _tempitemSource;
                    IsShowSectionScoreDetails = true;
                }
                IsShowScoreDetails = true;
            }
            else
            {
                UserDialogs.Instance.HideLoading();
                IsShowSectionScoreDetails = false;
                IsShowNoScoreViewVisible = false;
                IsShowScoreDetails = false;
            }
        }
    
        #region properties
        public List<ResultResponseData> _SectionScoreListItemSource;
        public List<ResultResponseData> SectionScoreListItemSource
        {
            get { return _SectionScoreListItemSource; }
            set { _SectionScoreListItemSource = value; OnPropertyChanged(); }
        }

        private Boolean _IsShowSectionScoreDetails;         public Boolean IsShowSectionScoreDetails         {             get { return _IsShowSectionScoreDetails; }             set { _IsShowSectionScoreDetails = value; OnPropertyChanged(); }         }          private Boolean _IsShowScoreDetails;         public Boolean IsShowScoreDetails         {             get { return _IsShowScoreDetails; }             set { _IsShowScoreDetails = value; OnPropertyChanged(); }         }

                private Boolean _IsShowNoScoreViewVisible;         public Boolean IsShowNoScoreViewVisible         {             get { return _IsShowNoScoreViewVisible; }             set { _IsShowNoScoreViewVisible = value; OnPropertyChanged(); }         }



        private String testPicture;
        public String TestPicture
        {
            get { return testPicture; }
            set { testPicture = value; OnPropertyChanged(); }
        }

        private string _answeredQuestion;
        public string AnsweredQuestion
        {
            get { return _answeredQuestion; }
            set { _answeredQuestion = value; OnPropertyChanged(); }
        }

        private string _unAnsweredQuestion;
        public string UnAnsweredQuestion
        {
            get { return _unAnsweredQuestion; }
            set { _unAnsweredQuestion = value; OnPropertyChanged(); }
        }

        private string _negativeMark;
        public string NegativeMark
        {
            get { return _negativeMark; }
            set { _negativeMark = value; OnPropertyChanged(); }
        }

        #endregion

        #region CommonFunction
        private async void CommonFunction(object obj)
        {

            try
            {
                if (obj.ToString().Equals("Proceed"))
                {
                    if (isClicked)
                    {
                        isClicked = false;
                        LocalDB ob = new LocalDB();
                        ob.DropAllPROTables();

                        if (!String.IsNullOrEmpty(_TestPinMasterData.redirect_url))
                        {
                            Device.OpenUri(new Uri(_TestPinMasterData.redirect_url));
                        }

                        DependencyService.Get<IExitApplication>().closeApplication();
                    }
                    await Task.Run(async () =>
                    {
                        await Task.Delay(500);
                        isClicked = true;
                    });
                }

            }
            catch (Exception e)
            {
                SendErrorMessageToServer(e, "PRO_ExamCompletedViewModel.ShowSectionScoreList");
            }
        } 
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
