﻿using HireMe.Interface;
using MvvmHelpers;
using Xamarin.Forms;

namespace HireMe.ViewModels
{
    public class AboutUsViewModel : BaseViewModel
    {
        public AboutUsViewModel()
        {
            //Version = "version 1.0.0.3";
            //var versionCode = DependencyService.Get<IPackageInfo>().VersionName;
            //Version = versionCode;
            var source = new HtmlWebViewSource();
            source.BaseUrl = DependencyService.Get<IBaseUrl>().GetAboutUS();
            SourceURL = source.BaseUrl;
        }
        private string _SourceURL;

        public string SourceURL
        {
            get { return _SourceURL; }
            set { _SourceURL = value; OnPropertyChanged(); }
        }
        //private string _version;

        //public string Version
        //{
        //    get { return _version; }
        //    set { _version = value;  OnPropertyChanged(); }
        //}
    }
}
