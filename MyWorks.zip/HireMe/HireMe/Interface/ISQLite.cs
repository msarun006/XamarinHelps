﻿using SQLite.Net;
using SQLite.Net.Async;

namespace HireMe.Interface

{
    public interface ISQLite
    {
        //SQLiteConnection GetConnection();
        //SQLiteAsyncConnection GetAsyncConnection();
        string ExternalStoragePathToFile(string filename = null);
    }
}
