﻿using System.Globalization;

namespace HireMe.Interface
{
    public interface ILocalize
    {

        CultureInfo GetCurrentCultureInfo();
        CultureInfo GetCurrentCultureInfo(string sLanguageCode);
        void SetLocale();
        void ChangeLocale(string sLanguageCode);
    }
}
