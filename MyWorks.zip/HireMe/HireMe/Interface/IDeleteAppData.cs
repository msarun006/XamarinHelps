﻿namespace HireMe.Interface
{
    public interface IDeleteAppData
    {
       void DeleteCapturedImageFile();

    }
}
