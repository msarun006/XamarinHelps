﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HireMe.Interface
{
    public interface INetworkFast
    {
        bool IsConnectionFast();

        double _CheckInternetSpeed();
    }
}
