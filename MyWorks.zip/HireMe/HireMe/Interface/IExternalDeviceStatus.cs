﻿namespace HireMe.Interface
{
    public  interface IExternalDeviceStatus
    {
        bool isHeadPhoneConnected();
        bool isOTGConnected();
        bool isBluetoothStatus();
        string GetMemorySize();

        double GetMemorySizeInMB();
        bool IsFrontCameraAvailable();

    }
}
