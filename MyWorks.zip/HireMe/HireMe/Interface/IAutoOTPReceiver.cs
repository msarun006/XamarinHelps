﻿namespace HireMe.Interface
{
    public interface IAutoOTPReceiver
    {
    }
}
