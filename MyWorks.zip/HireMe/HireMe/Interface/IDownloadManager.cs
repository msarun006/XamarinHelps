﻿using System.Threading.Tasks;

namespace HireMe.Interface
{
    public interface IDownloadManager
    {
        Task<string> DownloadFile(string ImageURL);
    }
}
