﻿namespace HireMe.Interface
{
    public interface IExitApplication
    {
        void closeApplication();
    }
}
