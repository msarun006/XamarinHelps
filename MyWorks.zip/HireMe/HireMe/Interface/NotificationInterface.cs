﻿namespace HireMe.Interface
{
    public interface NotificationInterface
    {
        string GetPlatformMessage();
        void IStartAlarmService();
        void IStopAlarmService();
    }

}
