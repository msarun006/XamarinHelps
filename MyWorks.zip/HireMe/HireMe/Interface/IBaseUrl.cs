﻿namespace HireMe.Interface
{
    public interface IBaseUrl
    {
        string GetExamInstruction();
        string GetFAQ();

        string GetAboutUS();
    }
}
