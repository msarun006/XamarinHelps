﻿namespace HireMe.Interface
{
    public interface ISyncDataWhileInternetAvailable
    {
        string GetPlatformMessage();
        void IStartAlarmService();
        void IStopAlarmService();
        void IRegisterIOSService();

       //  Task<bool> IsHostReachable(string host);

    }
}
