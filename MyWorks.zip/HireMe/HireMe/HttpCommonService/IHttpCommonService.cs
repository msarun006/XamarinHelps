﻿using System.Threading.Tasks;

namespace HireMe
{
    public interface IHttpCommonService
	{
		Task<T> GetAsync<T>(string url);

		Task<T1> PostAsync<T1, T2>(string url, T2 model);



	}
}
