﻿using System;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Text;
using Xamarin.Forms;
using Plugin.Connectivity;
using Acr.UserDialogs;
using System.Net.Http;
using System.Diagnostics;
using HireMe.Helpers;
using ModernHttpClient;
using HireMe.Models;

namespace HireMe
{
    public class HttpCommonService : IHttpCommonService
    {
        private static HttpClient _client;
        private HttpResponseMessage response;
        private string result;

        public HttpCommonService()
        {
        }

        public async Task<T> GetAsync<T>(string url)
        {
            try
            {
                bool isNetworkAvailable;
                if (Device.RuntimePlatform == Device.Android)
                {
                    isNetworkAvailable = DependencyService.Get<IMyDevice>().IsInternetAvailable();
                }
                else
                {
                    isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                }
                if (isNetworkAvailable)
                {
                    bool isHostReachable = DependencyService.Get<IMyDevice>().IsHostReachable();
                    if (isHostReachable)
                    {
                        var uri = new Uri(string.Format(url));
                        _client = CreateWebRequest(uri);
                        var message = new HttpRequestMessage(HttpMethod.Get, uri);
                        response = _client.SendAsync(message).Result;
                        result = await response.Content.ReadAsStringAsync();
                        var responseResult = JsonConvert.DeserializeObject<T>(result);
                        return responseResult;
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        // UserDialogs.Instance.Toast(MessageStringConstants.ServerNotReachable);
                        HttpResponse res = new HttpResponse();
                        res.code = "505";
                        res.message = MessageStringConstants.ServerNotReachable;
                        res.StatusCode = "505";
                        res.StatusMessage = MessageStringConstants.ServerNotReachable;
                        var jsonString = JsonConvert.SerializeObject(res);
                        var content = new StringContent(jsonString, Encoding.UTF8, "application/json");
                        HttpResponseMessage response = new HttpResponseMessage();
                        response.Content = content;
                        result = await response.Content.ReadAsStringAsync();
                        var responseresult = JsonConvert.DeserializeObject<T>(jsonString);
                        return responseresult;
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    // UserDialogs.Instance.Toast(MessageStringConstants.ServerNotReachable);
                    HttpResponse res = new HttpResponse();
                    res.code = "505";
                    res.message = MessageStringConstants.CheckInternetConnection;

                    res.StatusCode = "505";
                    // await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                    res.StatusMessage = MessageStringConstants.CheckInternetConnection;
                    var jsonString = JsonConvert.SerializeObject(res);
                    var content = new StringContent(jsonString, Encoding.UTF8, "application/json");
                    HttpResponseMessage response = new HttpResponseMessage();
                    response.Content = content;
                    result = await response.Content.ReadAsStringAsync();
                    var responseresult = JsonConvert.DeserializeObject<T>(jsonString);
                    return responseresult;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "HttpCommonService.PostAsync " + url);
                return default(T);
            }
        }

        public async Task<T1> PostAsync<T1, T2>(string url, T2 model)
        {
            try
            {
                bool isNetworkAvailable;
                if (Device.RuntimePlatform == Device.Android)
                {
                    isNetworkAvailable = DependencyService.Get<IMyDevice>().IsInternetAvailable();

                    var type = DependencyService.Get<IMyDevice>().NetworkType();

                }
                else
                {
                    isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                }
                if (isNetworkAvailable)
                {

                    bool isHostReachable = DependencyService.Get<IMyDevice>().IsHostReachable();

                   
                    if (isHostReachable)
                    {
                        var uri = new Uri(string.Format(url));
                        _client = CreateWebRequest(uri);
                        var json = JsonConvert.SerializeObject(model);
                        var content = new StringContent(json, Encoding.UTF8, "application/json");
                        response = await _client.PostAsync(uri, content);
                        if (response.IsSuccessStatusCode)
                        {
                            result = await response.Content.ReadAsStringAsync();

                            var settings = new JsonSerializerSettings
                            {
                                NullValueHandling = NullValueHandling.Ignore,
                                MissingMemberHandling = MissingMemberHandling.Ignore,
                             
                            };


                            var responseresult = JsonConvert.DeserializeObject<T1>(result, settings);
                            return responseresult;
                        }
                        else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                        {

                            if (AppSessionData.ActiveToken == null)
                            {
                                HttpResponse res = new HttpResponse();
                                res.code = "199";
                                res.message = MessageStringConstants.SessionExpiered;

                                res.StatusCode = "199";
                                res.StatusMessage = MessageStringConstants.SessionExpiered;
                                var jsonString = JsonConvert.SerializeObject(res);
                                content = new StringContent(jsonString, Encoding.UTF8, "application/json");
                                HttpResponseMessage responsemsg = new HttpResponseMessage();
                                responsemsg.Content = content;
                                result = await responsemsg.Content.ReadAsStringAsync();
                                var responseresult = JsonConvert.DeserializeObject<T1>(jsonString);
                                UserDialogs.Instance.HideLoading();
                                return responseresult;
                                // throw new Exception("No token found, Please login to application");
                                // Navigate To Login Page;
                            }
                            else
                            {
                                TimeZoneInfo localTime = TimeZoneInfo.Local;
                                System.Globalization.CultureInfo cultureinfo = new System.Globalization.CultureInfo("en-US");
                                DateTime TokenExpiry = Convert.ToDateTime(AppSessionData.ActiveToken.Expire);

                                TimeSpan localTimeDifference = TimeZoneInfo.Local.GetUtcOffset(TokenExpiry);
                                TokenExpiry.AddMinutes(localTimeDifference.TotalMinutes);
                                if (Convert.ToDateTime(TokenExpiry) < DateTime.Now)
                                {
                                    Func<int> function = new Func<int>(() => RefreshTokenAsync().Result);
                                    int refreshstatus = await Task.Run<int>(function);

                                    if (refreshstatus == 0)
                                    {
                                        HttpResponse res = new HttpResponse();
                                        res.code = "199";
                                        res.message = MessageStringConstants.SessionExpiered;

                                        res.StatusCode = "199";
                                        res.StatusMessage = MessageStringConstants.SessionExpiered;
                                        var jsonString = JsonConvert.SerializeObject(res);
                                        content = new StringContent(jsonString, Encoding.UTF8, "application/json");
                                        HttpResponseMessage responsemsg = new HttpResponseMessage();
                                        responsemsg.Content = content;
                                        result = await responsemsg.Content.ReadAsStringAsync();
                                        var responseresult = JsonConvert.DeserializeObject<T1>(jsonString);

                                        return responseresult;
                                    }
                                    else
                                    {
                                        HttpResponse res = new HttpResponse();
                                        res.code = "199";
                                        res.message = MessageStringConstants.ServerBusyMessage;

                                        res.StatusCode = "199";
                                        res.StatusMessage = MessageStringConstants.ServerBusyMessage;
                                        var jsonString = JsonConvert.SerializeObject(res);
                                        content = new StringContent(jsonString, Encoding.UTF8, "application/json");
                                        HttpResponseMessage responsemsg = new HttpResponseMessage();
                                        responsemsg.Content = content;
                                        result = await responsemsg.Content.ReadAsStringAsync();
                                        var responseresult = JsonConvert.DeserializeObject<T1>(jsonString);
                                        UserDialogs.Instance.HideLoading();
                                        return responseresult;
                                    }
                                    //Task.Run(() => RefreshTokenAsync()).Wait();
                                    //await Task.Delay(1000);
                                    //App.Current.MainPage = new NavigationPage(new LoginPageNew());
                                }
                                else
                                {
                                    HttpResponse res = new HttpResponse();
                                    res.code = "199";
                                    res.message = MessageStringConstants.SessionExpiered;

                                    res.StatusCode = "199";
                                    res.StatusMessage = MessageStringConstants.SessionExpiered;
                                    var jsonString = JsonConvert.SerializeObject(res);
                                    content = new StringContent(jsonString, Encoding.UTF8, "application/json");
                                    HttpResponseMessage responsemsg = new HttpResponseMessage();
                                    responsemsg.Content = content;
                                    result = await responsemsg.Content.ReadAsStringAsync();
                                    var responseresult = JsonConvert.DeserializeObject<T1>(jsonString);
                                    UserDialogs.Instance.HideLoading();
                                    return responseresult;
                                }
                            }
                        }
                        else
                        {
                            response = await _client.PostAsync(uri, content);
                            if (response.IsSuccessStatusCode)
                            {
                                result = await response.Content.ReadAsStringAsync();
                                var responseresult = JsonConvert.DeserializeObject<T1>(result);
                                return responseresult;
                            }
                            else
                            {
                                UserDialogs.Instance.HideLoading();
                                return default(T1);
                            }
                        }
                    }
                    else
                    {
                        UserDialogs.Instance.HideLoading();
                        HttpResponse res = new HttpResponse();
                        res.code = "505";
                        res.message = MessageStringConstants.ServerNotReachable;

                        res.StatusCode = "505";
                        res.StatusMessage = MessageStringConstants.ServerNotReachable;
                        var jsonString = JsonConvert.SerializeObject(res);
                        var content = new StringContent(jsonString, Encoding.UTF8, "application/json");
                        HttpResponseMessage response = new HttpResponseMessage();
                        response.Content = content;
                        result = await response.Content.ReadAsStringAsync();
                        var responseresult = JsonConvert.DeserializeObject<T1>(jsonString);
                        return responseresult;
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    // UserDialogs.Instance.Toast(MessageStringConstants.ServerNotReachable);
                    HttpResponse res = new HttpResponse();
                    res.code = "505";
                    res.message = MessageStringConstants.CheckInternetConnection;

                    res.StatusCode = "505";
                    // await UserDialogs.Instance.AlertAsync(MessageStringConstants.CheckInternetConnection);
                    res.StatusMessage = MessageStringConstants.CheckInternetConnection;
                    var jsonString = JsonConvert.SerializeObject(res);
                    var content = new StringContent(jsonString, Encoding.UTF8, "application/json");
                    HttpResponseMessage response = new HttpResponseMessage();
                    response.Content = content;
                    result = await response.Content.ReadAsStringAsync();
                    var responseresult = JsonConvert.DeserializeObject<T1>(jsonString);
                    return responseresult;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                UserDialogs.Instance.HideLoading();
                // UserDialogs.Instance.Toast(ex.Message);
                // return default(T1);
                //await UserDialogs.Instance.AlertAsync(ex.Message.ToString());

                SendErrorMessageToServer(ex, "HttpCommonService.PostAsync " + url);
                return default(T1);
            }
        }

      

        private async Task<int> RefreshTokenAsync()
        {
            try
            {
                HttpCommonService _commonservice = new HttpCommonService();
                var baserequest = new BaseRequestDTO(AppSessionData.ActiveToken.Token, AppSessionData.ActiveToken.HireMeID, AppSessionData.ActiveToken.RefreshToken);
                RegenerateTokenResponseBO responsetoken = null;
                responsetoken = await _commonservice.PostAsync<RegenerateTokenResponseBO, BaseRequestDTO>(APIData.API_BASE_URL + APIMethods.Regeneratetoken, baserequest);
                if (responsetoken != null && responsetoken.code == "200")
                {
                    ApplicationToken token = new ApplicationToken();
                    //HiremeeID = responsetoken.Response.HireMeID;
                    //Token = responsetoken.Response.Token;
                    token.HireMeID = responsetoken.Response.HireMeID;
                    token.Token = responsetoken.Response.TokenID;
                    token.RefreshToken = responsetoken.Response.Refreshtoken;
                    token.Expire = DateTime.Now.AddSeconds(Convert.ToDouble(responsetoken.Response.TokenExpiry));
                    token.EmailID = AppSessionData.ActiveToken.EmailID;
                    token.UserType = AppSessionData.ActiveToken.UserType;
                    AppSessionData.ActiveToken = token;
                    return 1;
                }
                else //if (responsetoken.Code == "401")
                {
                    return 0;
                    // await UserDialogs.Instance.AlertAsync(MessageStringConstants.SessionExpiered);
                    //  App.Current.MainPage = new NavigationPage(new LoginPageNew());
                }
            }
            catch (Exception ex)
            {
                SendErrorMessageToServer(ex, "BaseRequestDTO.RefreshToken");
                return 0;
            }

        }

        public HttpClient CreateWebRequestLinkedIn(Uri serviceUrl)
        {
            var handler = new NativeMessageHandler() { UseCookies = false };
            _client = new HttpClient(handler) { BaseAddress = serviceUrl };
            _client.DefaultRequestHeaders.Add("Accept", "application/json");
            _client.DefaultRequestHeaders.Add("Authorization", "Bearer " + AppPreferences.LinkedinAccessToken);
            return _client;
        }
       

        private HttpClient CreateWebRequest(Uri serviceUrl)
        {
            //var handler = new HttpClientHandler() { UseCookies = false };
            var handler = new NativeMessageHandler() { UseCookies = false };
            _client = new HttpClient(handler) { BaseAddress = serviceUrl };



            if (AppSessionData.ActiveToken != null)
            {
                if (!string.IsNullOrEmpty(AppSessionData.ActiveToken.Token))//if (HireMe.Interface.AppPreferences.IsAssessmentGetToken == true)
                {
                    _client.DefaultRequestHeaders.Add("Accept", "application/json");
                    _client.DefaultRequestHeaders.Add("Authorization", "Bearer " + AppSessionData.ActiveToken.Token);
                }
                //else if (Application.Current.Properties.ContainsKey("token"))
                //{
                //    _client.DefaultRequestHeaders.Add("Accept", "application/json");
                //    _client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Application.Current.Properties["token"].ToString());
                //}

            }
            //   _client.Timeout = new TimeSpan(0, 0, 25);

            return _client;
        }




        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        #region Response
        public class HttpResponse
        {

            public string code { get; set; }
            public string message { get; set; }
            public string StatusCode { get; set; }
            public string StatusMessage { get; set; }

        }
        #endregion
    }
}
