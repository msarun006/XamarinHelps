﻿namespace HireMe
{
    public class ProfilePicInsertRequest
    {
        public string Token { get; set; }
        public string HiremeeId { get; set; }
        public string ResourcetypeId { get; set; }
        public string S3_ID { get; set; }
        public string ResourceURL { get; set; }
    }

}
