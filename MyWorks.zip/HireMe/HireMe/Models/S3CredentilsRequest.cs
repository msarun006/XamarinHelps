﻿using Newtonsoft.Json;

namespace HireMe
{
    public class GetS3CredentialsRequest
    {
        [JsonProperty(PropertyName = "userResource")]
        public string UserResource { get; set; }
        [JsonProperty(PropertyName = "token")]
        public string Token { get; set; }
        [JsonProperty(PropertyName = "hiremee_id")]
        public string HireMeID { get; set; }
    }

    public class GetS3CredentialsResponse
    {
        [JsonProperty(PropertyName = "code")]
        public int Code { get; set; }
        [JsonProperty(PropertyName = "message")]
        public string Message { get; set; }
        [JsonProperty(PropertyName = "ResponseText")]
        public GetS3CredentialsResponseText ResponseText { get; set; }
    }

    public class GetS3CredentialsResponseText
    {
        [JsonProperty(PropertyName = "s3username")]
        public string S3UserName { get; set; }
        [JsonProperty(PropertyName = "s3accesskeyid")]
        public string S3AccessKeyID { get; set; }
        [JsonProperty(PropertyName = "s3secretaccesskey")]
        public string S3SecretAccessKey { get; set; }
        [JsonProperty(PropertyName = "token")]
        public string Token { get; set; }
        [JsonProperty(PropertyName = "hiremee_id")]
        public string HireMeID { get; set; }
        [JsonProperty(PropertyName = "token_expiry")]
        public string Token_Expiry { get; set; }
    }
}
