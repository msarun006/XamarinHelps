﻿using System.Collections.Generic;

namespace HireMe
{
    public class AssessmentReportResponseModel
    {
        public AssessmentReportResponseModel()
        {
        }
        public string code { get; set; }
        public string message { get; set; }
        public List<Response> response { get; set; }

        public class Response
        {
            public string hiremee_id { get; set; }
            public string name { get; set; }
            public string EmailAddress { get; set; }
            public string Course { get; set; }
            public string Specialization { get; set; }
            public int Verbalaptitude { get; set; }
            public int quantitativeaptitude { get; set; }
            public int logicalreasoning { get; set; }
            public int technicalcomputerfundamental { get; set; }
            public int communication { get; set; }
            public int technicalcoredomain { get; set; }
            public int interpersonalcompetencies { get; set; }
            public int personalcompetencies { get; set; }
            public int emotionalcompetencies { get; set; }
            public int motivationalcompetencies { get; set; }
            public int intellectualorientation { get; set; }
            public int Total { get; set; }
        }
    }
}
