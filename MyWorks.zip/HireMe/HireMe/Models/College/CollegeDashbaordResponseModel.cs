﻿using System;
using MvvmHelpers;
using Xamarin.Forms;

namespace HireMe
{


    public class CollegeDashbaordResponseModel
    {
        public string code { get; set; }
        public string message { get; set; }
        public CollegeData responseText { get; set; }
    }

    public class CollegeData
    {
        public Collegedashboard collegedashboard { get; set; }
    }

    public class Collegedashboard
    {
        public string shortlistmonthwise { get; set; }
        public string shortlistyearwise { get; set; }
        public string shortlistweekwise { get; set; }
        public string totalregisterstudent { get; set; }
        public string totaluploadedstudent { get; set; }
    }



    public class LoadCustomGridItems : BaseViewModel
    {

        private String count;
        public String Count { get { return count; } set { count = value; OnPropertyChanged(); } }

        private String title;
        public String Title { get { return title; } set { title = value; OnPropertyChanged(); } }

        private String customImage;
        public String CustomImage { get { return customImage; } set { customImage = value; OnPropertyChanged(); } }


        private Color gridItemBackColor;
        public Color GridItemBackColor
        {
            get { return gridItemBackColor; }
            set { gridItemBackColor = value; OnPropertyChanged(); }
        }

    }

}
