﻿using HireMe.Models;

namespace HireMe
{
    public class CollegeDashboardRequestModel : BaseRequestDTO
    {
        public string fromdate { get; set; }
        public string todate { get; set; }
        public string specialization_id { get; set; }
    }
}
