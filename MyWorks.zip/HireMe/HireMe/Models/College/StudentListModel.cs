﻿using System.Collections.Generic;

namespace HireMe
{
    public class StudentListModel
    {
        public string code { get; set; }
        public string message { get; set; }
        public List<Response> response { get; set; }

        public class Response
        {
            public string hiremee_id { get; set; }
            public string fullname { get; set; }
            public string email_address { get; set; }
            public string mobile_number { get; set; }
            public string created_at { get; set; }
            public string status { get; set; }
        }

    }
}
