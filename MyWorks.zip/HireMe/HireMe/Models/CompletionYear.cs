﻿namespace HireMe
{
	public class CompletionYear
	{
		public string YearID { get; set; }
		public string Title { get; set;}
	}

    public class CompletionItem
    {
        public string id { get; set; }
        public string name { get; set; }
    }
}
