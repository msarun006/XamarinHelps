﻿using System;
using System.Text.RegularExpressions;
using Xamarin.Forms;

namespace HireMe
{
    public static class Utilities
    {
        public static bool ValidatePassword(string password)
        {
            if (string.IsNullOrEmpty(password)) return false;
            return PasswordValidator.IsValidPassword(password.Trim());
        }

        public static bool ValidateEmailAddress(string email)
        {
            if (string.IsNullOrEmpty(email)) return false;

            return EmailValidator.IsValidEmail(email.Trim());
        }

        public static string GetDeviceID()
        {
            return Convert.ToString(DependencyService.Get<IMyDevice>().GetDeviceID());
        }

        public static string GetDeviceModel()
        {
            return Convert.ToString(DependencyService.Get<IMyDevice>().GetDeviceModel());
        }

        public static string GetDeviceBrandName()
        {
            return Convert.ToString(DependencyService.Get<IMyDevice>().GetDeviceBrandName());
        }
        public static string GetDeviceVersion()
        {
            return Convert.ToString(DependencyService.Get<IMyDevice>().GetDeviceVersion());
        }
        public static string GetDeviceOS()
        {
            return Convert.ToString(DependencyService.Get<IMyDevice>().GetDeviceType());
        }
        public static bool ValidateMobileNumber(string mobilenumber)
        {
            if (string.IsNullOrEmpty(mobilenumber)) return false;

            if (mobilenumber.Length != 10) return false;

            bool isnumber = true;

            foreach (char ch in mobilenumber)
            {
                if (!char.IsNumber(ch)) isnumber = false;
            }

            return isnumber;
        }

        public static bool ValidateCGPA(string number)
        {
            if (string.IsNullOrEmpty(number.Trim())) return false;

            if (number.Length > 1) return false;

            bool isnumber = true;

            foreach (char ch in number)
            {
                if (!char.IsNumber(ch)) isnumber = false;
            }

            return isnumber;
        }

        public static bool ValidatePercentage(string number)
        {
            return true;
        }

        public static bool ValidateAadhaarNumber(string aadhaarnumber)
        {

            if (string.IsNullOrEmpty(aadhaarnumber.Trim())) return true;
            if (aadhaarnumber.Length != 12) return false;
            bool isNumber = true;
            foreach (char ch in aadhaarnumber)
            {
                if (!char.IsNumber(ch)) isNumber = false;
            }
            return isNumber;

        }
        public static bool ValidatePassportNumber(string passportnumber)
        {
            string pattern = ("^[A-Za-z]{1}[0-9]{7}$");
            if (!char.IsLetter(passportnumber[0])) return false;
            if (string.IsNullOrEmpty(passportnumber.Trim())) return false;
            int index = passportnumber.IndexOf(' ');
            if (index != -1 && index < passportnumber.Length) return false;
            if (passportnumber.Length != 8) return false;
            if (Regex.IsMatch(passportnumber.Trim(), pattern))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool ValidatePANNumber(string PANnumber)
        {
            string pattern = @"[A-Z]{5}\d{4}[A-Z]{1}";
            if (!char.IsLetter(PANnumber[0])) return false;
            if (string.IsNullOrEmpty(PANnumber.Trim())) return false;
            int index = PANnumber.IndexOf(' ');
            if (index != -1 && index < PANnumber.Length) return false;
            if (PANnumber.Length != 10) return false;
            if (Regex.IsMatch(PANnumber.Trim(), pattern))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool ValidateRegisterNumber(string inputValue)
        {
            var regex = new Regex(@"^[a-zA-Z0-9]*$");
            if (regex.IsMatch(inputValue))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool ValidatePincode(string collegepincodenumber)
        {

            if (string.IsNullOrEmpty(collegepincodenumber.Trim())) return true;
            if (collegepincodenumber.Length != 6) return false;
            bool isNumber = true;
            foreach (char ch in collegepincodenumber)
            {
                if (!char.IsNumber(ch)) isNumber = false;
            }
            return isNumber;
        }

        //public static bool ValidateUserFullName(string fullname)
        //{
        //    if (string.IsNullOrEmpty(fullname)) return false;

        //    bool isvalid = true;

        //    foreach (char ch in fullname)
        //    {
        //        if (!char.IsLetter(ch) && ch != ' ') isvalid = false;
        //    }

        //    return isvalid;
        //}

        public static bool ValidateUserFullName(string fullname)
        {
            if (string.IsNullOrEmpty(fullname) || string.IsNullOrWhiteSpace(fullname)) return false;
            fullname = fullname.Trim();
            string pattern = (@"(^[a-zA-Z. ]{3,100}$)");
            int index = fullname.IndexOf(' ');
            if (index != -1 && index < 3) return false;
            if (fullname.Length <= 3)
            {
                if (fullname.Contains(" ") || fullname.Length < 3)
                    return false;
                else
                    return true;
            }
            else if (Regex.IsMatch(fullname.Trim(), pattern))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool ValidateUserFirstName(string firstname)
        {
            if (string.IsNullOrEmpty(firstname) || string.IsNullOrWhiteSpace(firstname)) return false;
            firstname = firstname.Trim();
            if (Regex.IsMatch(firstname, @"(^[a-zA-Z. ]{1,100}$)"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool ValidateUserLastName(string lastname)
        {
            if (string.IsNullOrEmpty(lastname) || string.IsNullOrWhiteSpace(lastname)) return false;
            lastname = lastname.Trim();
            if (Regex.IsMatch(lastname, @"(^[a-zA-Z. ]{1,100}$)"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool IsValidPassword(string password)
        {
            string pattern = null;
            //Password must contain: Minimum 8 and Maximum 20 characters atleast 1 UpperCase Alphabet, 1 LowerCase Alphabet, 1 Number and 1 Special Character
            pattern = (@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$!@#$%^&*()_+=\[{\]};:<>|./?,-~`])[A-Za-z\d$!@#$%^&*()_+=\[{\]};:<>|./?,-~`]{8,20}");
            if (string.IsNullOrEmpty(password) || string.IsNullOrWhiteSpace(password)) return false;
            if (Regex.IsMatch(password, pattern))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool Address(string address)
        {
            int pattern = address.Length;
            if (string.IsNullOrEmpty(address.Trim())) return false;
            if (pattern < 5)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public static bool AboutMe(string textContent)
        {
            int pattern = textContent.Length;
            if (string.IsNullOrEmpty(textContent.Trim())) return false;
            if (pattern < 50)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public static string ReadOTP(string OTP)
        {
            string otp_value = string.Empty;
            string pattern = @"\d{4}";
            Regex r = new Regex(pattern);
            if (string.IsNullOrEmpty(OTP))
            {
                otp_value = string.Empty;
            }
            else
            {
                otp_value = r.Match(OTP).ToString();
            }
            return otp_value;
        }
    }
}
