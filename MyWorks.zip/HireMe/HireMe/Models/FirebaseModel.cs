﻿using Newtonsoft.Json;

namespace HireMe.Models
{
    public class FirebaseMessagingRequestData : BaseRequestDTO
    {


        [JsonProperty(PropertyName = "firebase_id")]
        public string FirebaseToken { get; set; }

    }
    public class FirebaseMessagingResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }
        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }
        [JsonProperty(PropertyName = "responseText")]
        public string ResponseText { get; set; }
    }
    public class FirebaseMessagingUnRegisterRequestData : BaseRequestDTO
    { }
    public class FirebaseMessagingUnRegisterResponseData
    {
        public string code { get; set; }
        public string message { get; set; }
        public FCMResponsetext responseText { get; set; }
    }

    public class FCMResponsetext
    {
        public string hiremee_id { get; set; }
    }
}
