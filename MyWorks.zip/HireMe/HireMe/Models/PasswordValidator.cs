﻿using System;
namespace HireMe
{
	public static class PasswordValidator
	{
		public static bool IsValidPassword(string password)
		{
			const int MIN_LENGTH = 6;
			const int MAX_LENGTH = 15;
			if (password == null) throw new ArgumentNullException();

			bool meetsLengthRequirements = password.Length >= MIN_LENGTH && password.Length <= MAX_LENGTH;

            #region HireMee version 7 req (Only password lenght validation only apply)

            //bool hasUpperCaseLetter = false;
            //bool hasLowerCaseLetter = false;
            //bool hasDecimalDigit = false;
            //bool hasSpecialChar = false;
            //bool startedWithLetter = false;

            //if (meetsLengthRequirements)
            //{
            //	bool firstchar = true;
            //	foreach (char c in password)
            //	{
            //		if (firstchar)
            //		{
            //			startedWithLetter = char.IsLetter(c);
            //			firstchar = false;
            //		}
            //		if (startedWithLetter)
            //		{
            //			if (char.IsUpper(c)) hasUpperCaseLetter = true;
            //			else if (char.IsLower(c)) hasLowerCaseLetter = true;
            //			else if (char.IsDigit(c)) hasDecimalDigit = true;
            //			else if (!char.IsLetterOrDigit(c)) hasSpecialChar = true;
            //		}
            //	}
            //}

            #endregion

            bool isValid = meetsLengthRequirements;
				//&& hasUpperCaseLetter
				//&& hasLowerCaseLetter
				//&& hasDecimalDigit
				//&& startedWithLetter
				//&& hasSpecialChar;
			return isValid;
		}
	}
}
