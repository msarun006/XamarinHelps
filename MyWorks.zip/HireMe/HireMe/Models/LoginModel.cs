﻿using Newtonsoft.Json;

namespace HireMe.Models
{
    public class LoginModel
    {
    }
    #region Login Request Data

    public class LoginRequestData
    {
        [JsonProperty(PropertyName = "username")]
        public string UserName { get; set; }

        [JsonProperty(PropertyName = "udid")]
        public string DeviceID { get; set; }

        [JsonProperty(PropertyName = "devmodel")]
        public string DeviceModel { get; set; }

        [JsonProperty(PropertyName = "devos")]
        public string DeviceOS { get; set; }

        [JsonProperty(PropertyName = "password")]
        public string Password { get; set; }

        public string SecretKey { get; set; }
        [JsonProperty(PropertyName = "firebase_id")]
        public string FirebaseToken { get; set; }
    }


    public class TokenRequestData : BaseRequestDTO
    {

    }
    #endregion

    #region Login Response Data
    /// <summary>
    /// Login response data.
    /// </summary>
    public class LoginResponseData  : SessionToken
    {
        public string code { get; set; }
        public string message { get; set; }

        [JsonProperty(PropertyName = "user_type")]
        public string UserType { get; set; }

        [JsonProperty(PropertyName = "email_address")]
        public string EmailAddress { get; set; }

        [JsonProperty(PropertyName = "mobile_number")]
        public string MobileNo { get; set; }

        [JsonProperty(PropertyName = "user_name")]
        public string user_name { get; set; }

        [JsonProperty(PropertyName = "s3_id")]
        public string s3_id { get; set; }

        [JsonProperty(PropertyName = "password")]
        public bool SocialLoginPasswordStatus { get; set; }

        [JsonProperty(PropertyName = "profileweightage")]
        public Profileweightage ProfileWeightage { get; set; }

        public Userresourcecredential Userresourcecredential { get; set; }
        public Appversioncheck apiVersionCheck { get; set; }
    }

    public class Appversioncheck
    {
        public string ioS_VersionName { get; set; }
        public string ioS_VersionCode { get; set; }
        public string android_VersionName { get; set; }
        public string android_VersionCode { get; set; }
    }


    public class Userresourcecredential
    {
        public string s3username { get; set; }
        public string s3accesskeyid { get; set; }
        public string s3secretaccesskey { get; set; }
        public string baseurl { get; set; }
        public string systemname { get; set; }
        public string compressquality { get; set; }
        public string videoquality { get; set; }
    }

    public class Profileweightage
    {
        [JsonProperty(PropertyName = "personaldetails")]
        public object PersonalDetails { get; set; }
        [JsonProperty(PropertyName = "educationaldetails")]

        public object EducationalDetails { get; set; }
        [JsonProperty(PropertyName = "video")]
        public object Video { get; set; }
        [JsonProperty(PropertyName = "profilepic")]
        public object ProfilePicture { get; set; }
    }



    #endregion

    #region SocialLoginRequest Data

    public class SocialLoginRequest
    {
        [JsonProperty(PropertyName = "social_id")]
        public string SocialID { get; set; }

        [JsonProperty(PropertyName = "udid")]
        public string DeviceID { get; set; }

        [JsonProperty(PropertyName = "devmodel")]
        public string DeviceModel { get; set; }

        [JsonProperty(PropertyName = "devos")]
        public string DeviceOS { get; set; }

        [JsonProperty(PropertyName = "provider_type")]
        public string ProviderType { get; set; }

        [JsonProperty(PropertyName = "email_address")]
        public string emailAddress { get; set; }
    }


    //public class TokenRequestData : BaseRequestDTO
    //{

    //}
    #endregion
}
