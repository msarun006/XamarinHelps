﻿namespace HireMe.Models
{
    public class UserRegistration_mobile_Model
    {
        public string name { get; set; }
        public string mobile_number { get; set; }
        public string email_address { get; set; }
    }

    public class SocialRegisterRequestData
    {
        public string mobile_number { get; set; }
        public string social_id { get; set; }
        public string social_type { get; set; }
        public string name { get; set; }
        public string email_address { get; set; }

    }
    public class UserResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public UserResponseValues responseText { get; set; }
            }
    public class UserResponseValues
    {
        public string mobile_number { get; set; }
        public int register_id { get; set; }
        public int resend { get; set; }
        public string message { get; set; }
        public string otp { get; set; }
        public string email_address { get; set; }
        public Appversioncheck apiVersionCheck { get; set; }
    }
}
