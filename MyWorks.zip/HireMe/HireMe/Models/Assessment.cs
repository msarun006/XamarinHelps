﻿
namespace HireMe.Models
{
    public class AssessmentScoreModel
    {
        public int verbalaptitude { get; set; }
        public int quantitativeaptitude { get; set; }
        public int logicalreasoning { get; set; }
        public int technicalcomputerfundamental { get; set; }
        public int communication { get; set; }
        public int technicalcoredomain { get; set; }
        public int interpersonalcompetencies { get; set; }
        public int personalcompetencies { get; set; }
        public int emotionalcompetencies { get; set; }
        public int motivationalcompetencies { get; set; }
        public int intellectualorientation { get; set; }


    }
}
