﻿
using Newtonsoft.Json;
using System;
using System.Collections.Generic; 

namespace HireMe.Models.Assessment
{
    public class BulkInsert
    {

    }
 

    public class BulkInsertRequest 
    {
        public List<SQLTables.ExamAnswersModel> ExamAnswers { get; set; }
        public List<SQLTables.ExamAnswerHistoryModel> ExamAnswersHistory { get; set; }
        public List<SQLTables.ExamGroupModel> AssignedGroup { get; set; }
        public List<SQLTables.FacialImageDetailsModel> FacialImage { get; set; }
        public SQLTables.AssignedExamModel AssignedExams { get; set; }
        public FeedBackModelRequest Feedback { get; set; }
    }


    public class Data
    {
        public List<SQLTables.ExamAnswersModel> ExamAnswers { get; set; }
        public List<SQLTables.ExamAnswerHistoryModel> ExamAnswersHistory { get; set; }
        public List<SQLTables.ExamGroupModel> AssignedGroup { get; set; }
        public List<SQLTables.FacialImageDetailsModel> FacialImages { get; set; }
       
    }

    public class BulkInsertResponse
    {
        [JsonProperty(PropertyName = "StatusCode")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "StatusMessage")]
        public string message { get; set; }

        public Data Data { get; set; }


    }

}
