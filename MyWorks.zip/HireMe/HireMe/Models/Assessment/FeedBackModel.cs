﻿using System;
using SQLite.Net.Attributes;

namespace HireMe.Models.Assessment
{


    public class FeedBackModelRequest
    {
        [PrimaryKey, AutoIncrement]
        public int ID { get; set; }
        public String HireMeeID { get; set; }
        public String Feedback1 { get; set; }
        public String Feedback2 { get; set; }
        public String Feedback3 { get; set; }
        public String Comments { get; set; }
        public String ExamName { get; set; }
        public bool IsSynchedUp { get; set; }
        public String ExamCenter { get; set; }

        public String AssignedID { get; set; }
        public String AutoID { get; set; }
    }
    public class FeedBackModelResponse
    {
        public String StatusCode { get; set; }
        public String StatusMessage { get; set; }

    }
}
