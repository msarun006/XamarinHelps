﻿namespace HireMe.Models.Assessment
{
    public class CarouselData
    {
        public string Name { get; set; }
        public string Body { get; set; }

    }
}
