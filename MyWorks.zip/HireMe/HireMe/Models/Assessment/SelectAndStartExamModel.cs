﻿using MvvmHelpers;
using System;
using System.Collections.Generic;

namespace HireMe.Models.Assessment
{
    public class SelectAndStartExamModel : BaseViewModel
    {
        public String ExamTitle { get; set; }
        public List<Status> ExamStatus { get; set; }
    }


    public class Status
    {
        public String answered { get; set; }

        public String notanswered { get; set; }

        public String notvisited { get; set; }

        public String startExam { get; set; }
    }


    public class GroupDetailsRequest
    {
        public String HireMeeID { get; set; }
        public String ExamID { get; set; }
        public String AssignedID { get; set; }





    }


    public class GroupDetailsResponse
    {
        public string StatusCode { get; set; }
        public string StatusMessage { get; set; }

        public string ExamDuration { get; set; }

        public string ElapsedTime { get; set; }

        public List<EnglishGroupDetail> data { get; set; }
    }



    public class EnglishGroupDetail
    {
        public string Title { get; set; }
        public string ExamID { get; set; }
        public string GroupID { get; set; }
        public string GroupName { get; set; }
        public string TitleStatusColor { get; set; }
        public string NoOfQuestions { get; set; }
        public List<Questiongroupstatus> QuestionGroupStatus { get; set; }
    }
    public class HindiGroupDetail
    {
        public string Title { get; set; }
        public string ExamID { get; set; }
        public string GroupID { get; set; }
        public string GroupName { get; set; }
        public string TitleStatusColor { get; set; }
        public string NoOfQuestions { get; set; }
        public List<Questiongroupstatus> QuestionGroupStatus { get; set; }
    }

    public class Questiongroupstatus
    {

        private string anseredQuestion;
        public string AnsweredQuestion
        {
            get
            {

                var value = anseredQuestion;

                if (value.Contains("["))
                {
                    value = anseredQuestion;
                }
                else
                {
                    if (AppPreferences.IsHindi)
                    {
                        value = "उत्तर दे दिया है [" + anseredQuestion + "]";
                    }
                    else
                    {
                        value = "Answered [" + anseredQuestion + "]";
                    }

                }

                return value;



            }
            set { anseredQuestion = value; }
        }

        private string unAnseredQuestions;
        public string UnAnsweredQuestions
        {
            get
            {
                var value = unAnseredQuestions;

                if (value.Contains("["))
                {
                    value = unAnseredQuestions;
                }
                else
                {
                    if (AppPreferences.IsHindi)
                    {
                        value = "उत्तर नहिं दिया है [" + unAnseredQuestions + "]";
                    }
                    else
                    {
                        value = "UnAnswered [" + unAnseredQuestions + "]";
                    }

                }

                return value;
            }






            set { unAnseredQuestions = value; }
        }

        private string notVisitedQuestions;
        public string NotVisitedQuestions
        {
            get

            {


                var value = notVisitedQuestions;

                if (value.Contains("["))
                {
                    value = notVisitedQuestions;
                }
                else
                {
                    if (AppPreferences.IsHindi)
                    {
                        value = "नहीं देखा है [" + notVisitedQuestions + "]";
                    }
                    else
                    {
                        value = "NotVisited [" + notVisitedQuestions + "]";
                    }

                }

                return value;



            }
            set { notVisitedQuestions = value; }
        }



        public string GroupName { get; set; }
        public string NoOfQuestions { get; set; }


        private string questionGroupID;

        public string QuestionGroupID
        {
            get { return questionGroupID; }
            set { questionGroupID = value; }
        }







        public string GroupStatus { get; set; }

        public string StartExam { get; set; }


    }


}
