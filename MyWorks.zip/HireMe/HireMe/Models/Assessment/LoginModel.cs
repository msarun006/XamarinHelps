﻿using MvvmHelpers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace HireMe.Models.Assessment
{
   public class LoginModel : BaseRequestDTO
    {

        private string userName;
        public string Username
        {
            get { return userName; }
            set { userName = value; OnPropertyChanged(); }
        }

        private string password;

        public string Password
        {
            get { return password; }
            set { password = value; OnPropertyChanged(); }
        }
        public string DeviceID { get; set; }

        public string DeviceBrand { get; set; }
        public string DeviceModel { get; set; }
        public string DeviceOS { get; set; }
        public string DeviceOSVersion { get; set; }



    }

  
    public class CandidateDetails
    {
        public string AutoID { get; set; }
        public string PhotoPath { get; set; }
        public string HireMeeID { get; set; }
        public string CandidateName { get; set; }
    }

    public class Examdetail
    {
        public string DeviceID { get; set; }
        public string ExamID { get; set; }
        public string AssignedID { get; set; }
        public string NoOfAttempt { get; set; }
        public string HallTicketAttendanceComments { get; set; }
        public string LoginStatus { get; set; }
        public string IsFirstTime { get; set; }
        public string ExamName { get; set; }
        public string IsAutoProctored { get; set; }
        public string TotalNoOfQuestions { get; set; }
        public string ExamInstruction { get; set; }
        public string ExamCentreName { get; set; }
        public string Duration { get; set; }
        public string ElaspedTime { get; set; }
        public object LastUpdatedQuestionID { get; set; }
        public object LastUpdatedGroupID { get; set; }
        public DateTime ExamStartTime { get; set; }
        public DateTime ExamEndTime { get; set; }
        public DateTime ServerTime { get; set; }
    }
    public class AvailableLanguage
    {
        public string LanguageId { get; set; }
        public string LanguageName { get; set; }
    }
    public class LoginResponse
    {
        public CandidateDetails CandidateDetails { get; set; }
        public Examdetail ExamDetails { get; set; }
        public string AccessToken { get; set; }
        public string TokenExpires { get; set; }

        [JsonProperty(PropertyName = "StatusCode")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "StatusMessage")]
        public string message { get; set; }

        public string BatteryLevel { get; set; }
        public string NoofAttempts { get; set; }
        public AvailableLanguage[] AvailableLanguages { get; set; }

    }
}
