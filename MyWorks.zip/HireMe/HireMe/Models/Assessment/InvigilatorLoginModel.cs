﻿using MvvmHelpers;
using Newtonsoft.Json;

namespace HireMe.Models.Assessment
{
    public class InvigilatorLoginModel : BaseRequestDTO
    {

        private string userName;
        public string Username
        {
            get { return userName; }
            set { userName = value; OnPropertyChanged(); }
        }

        private string password;
        public string Password
        {
            get { return password; }
            set { password = value; OnPropertyChanged(); }
        }

        
        private string invigilatorPassword;
        public string InvigilatorPassword
        {
            get { return invigilatorPassword; }
            set { invigilatorPassword = value; OnPropertyChanged(); }
        }

        public string deviceId { get; set; }
        public string ExamID { get; set; }
    }

    public class InvigilatorLoginResponse
    {
        [JsonProperty(PropertyName = "StatusCode")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "StatusMessage")]
        public string message { get; set; }
       

        public string AssignedID { get; set; }

        public string ExamID { get; set; }


    }

  
}
