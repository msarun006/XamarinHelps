﻿
namespace HireMe.Models.Assessment
{
    public class MCQModel
    {
        public SQLTables.EnglishQuestion[] questions { get; set; }
    }

}