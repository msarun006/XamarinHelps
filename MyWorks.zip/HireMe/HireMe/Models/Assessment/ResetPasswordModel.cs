﻿using Newtonsoft.Json;

namespace HireMe.Models.Assessment
{
    #region Reset Password Request Data
    public class ResetPasswordRequestData
    {
        public string email_address { get; set; }
        public string password { get; set; }
        public string CofirmPassword { get; set; }
    }
    #endregion

    #region Reset Password Response Data
    public class ResetPasswordResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string Code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string Message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public ResetPasswordData Response { get; set; }
    }
    #endregion
    public class ResetPasswordData : ResetPasswordRequestData
        {


        }
    }
    

