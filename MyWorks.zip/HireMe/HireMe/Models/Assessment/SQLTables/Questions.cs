﻿using MvvmHelpers;
using System.Collections.Generic;
using HireMe.Helpers.Assessment;
using System;
using SQLite;

namespace HireMe.Models.Assessment.SQLTables
{



    public class QuestionsRequestData : BaseRequestDTO
    {

        public string AssignedID { get; set; }
        public string DeviceID { get; set; }
        public string LanguageID { get; set; }
    }

    public class EnglishQuestion : BaseViewModel
    {
        SaveImageToLocal objSaveImageToLocal = new SaveImageToLocal();



        public string _Question { get; set; }
        public string Question
        {
            get
            {

                return _Question;
            }

            set
            {
                _Question = value;
                if (_Question.Contains(".jpg") || _Question.Contains(".jpeg") || _Question.Contains(".png"))
                {
                    IsImageQuestion = true;
                }
                else
                {
                    IsImageQuestion = false;
                }
                OnPropertyChanged();
            }
        }


        public string _ChoiceA { get; set; }
        public string ChoiceA
        {
            get
            {

                return _ChoiceA;
            }

            set
            {
                _ChoiceA = value;
                if (_ChoiceA.Contains(".jpg") || _ChoiceA.Contains(".jpeg") || _ChoiceA.Contains(".png"))
                {
                    IsImageQuestion = true;
                }
                else if (!IsImageQuestion)
                {
                    IsImageQuestion = false;
                }
                OnPropertyChanged();
            }
        }


        public string _ChoiceB { get; set; }
        public string ChoiceB
        {
            get
            {

                return _ChoiceB;
            }

            set
            {
                _ChoiceB = value;
                if (_ChoiceB.Contains(".jpg") || _ChoiceB.Contains(".jpeg") || _ChoiceB.Contains(".png"))
                {
                    IsImageQuestion = true;
                }
                else if (!IsImageQuestion)
                {
                    IsImageQuestion = false;
                }
                OnPropertyChanged();
            }
        }


        public string _ChoiceC { get; set; }
        public string ChoiceC
        {
            get
            {

                return _ChoiceC;
            }

            set
            {
                _ChoiceC = value;
                if (_ChoiceC.Contains(".jpg") || _ChoiceC.Contains(".jpeg") || _ChoiceC.Contains(".png"))
                {
                    IsImageQuestion = true;
                }
                else if (!IsImageQuestion)
                {
                    IsImageQuestion = false;
                }
                OnPropertyChanged();
            }
        }


        public string _ChoiceD { get; set; }
        public string ChoiceD
        {
            get
            {

                return _ChoiceD;
            }

            set
            {
                _ChoiceD = value;
                if (_ChoiceD.Contains(".jpg") || _ChoiceD.Contains(".jpeg") || _ChoiceD.Contains(".png"))
                {
                    IsImageQuestion = true;
                }
                else if (!IsImageQuestion)
                {
                    IsImageQuestion = false;
                }
                OnPropertyChanged();
            }
        }



        public bool _IsImageQuestion { get; set; }
        public bool IsImageQuestion
        {
            get { return _IsImageQuestion; }

            set { _IsImageQuestion = value; OnPropertyChanged(); }
        }

        [PrimaryKey, AutoIncrement]
        public int QuestionsDataID { get; set; }
        public int Id { get; set; }
        public string QuestionImage { get; set; }
        public string CaseStudy { get; set; }
        public int QuestionId { get; set; }
        public int QuestionType { get; set; }
        public string UserKeyed { get; set; }
        public int ScorePerQuestion { get; set; }
        public string ImagePath { get; set; }
        public string Answered { get; set; }
        public string QtnTypeName { get; set; }
        public string LastUpdatedTime { get; set; }
        public int LastUpdatedQuestionID { get; set; }
        public string Category { get; set; }
        public string ContentReference { get; set; }
        public string CorrectAnswer { get; set; }
        public int GroupID { get; set; }
    }
    public class HindiQuestion : BaseViewModel
    {
        SaveImageToLocal objSaveImageToLocal = new SaveImageToLocal();



        public string _Question { get; set; }
        public string Question
        {
            get
            {

                return _Question;
            }

            set
            {
                _Question = value;
                if (_Question.Contains(".jpg") || _Question.Contains(".jpeg") || _Question.Contains(".png"))
                {
                    IsImageQuestion = true;
                }
                else
                {
                    IsImageQuestion = false;
                }
                OnPropertyChanged();
            }
        }


        public string _ChoiceA { get; set; }
        public string ChoiceA
        {
            get
            {

                return _ChoiceA;
            }

            set
            {
                _ChoiceA = value;
                if (_ChoiceA.Contains(".jpg") || _ChoiceA.Contains(".jpeg") || _ChoiceA.Contains(".png"))
                {
                    IsImageQuestion = true;
                }
                else if (!IsImageQuestion)
                {
                    IsImageQuestion = false;
                }
                OnPropertyChanged();
            }
        }


        public string _ChoiceB { get; set; }
        public string ChoiceB
        {
            get
            {

                return _ChoiceB;
            }

            set
            {
                _ChoiceB = value;
                if (_ChoiceB.Contains(".jpg") || _ChoiceB.Contains(".jpeg") || _ChoiceB.Contains(".png"))
                {
                    IsImageQuestion = true;
                }
                else if (!IsImageQuestion)
                {
                    IsImageQuestion = false;
                }
                OnPropertyChanged();
            }
        }


        public string _ChoiceC { get; set; }
        public string ChoiceC
        {
            get
            {

                return _ChoiceC;
            }

            set
            {
                _ChoiceC = value;
                if (_ChoiceC.Contains(".jpg") || _ChoiceC.Contains(".jpeg") || _ChoiceC.Contains(".png"))
                {
                    IsImageQuestion = true;
                }
                else if (!IsImageQuestion)
                {
                    IsImageQuestion = false;
                }
                OnPropertyChanged();
            }
        }


        public string _ChoiceD { get; set; }
        public string ChoiceD
        {
            get
            {

                return _ChoiceD;
            }

            set
            {
                _ChoiceD = value;
                if (_ChoiceD.Contains(".jpg") || _ChoiceD.Contains(".jpeg") || _ChoiceD.Contains(".png"))
                {
                    IsImageQuestion = true;
                }
                else if (!IsImageQuestion)
                {
                    IsImageQuestion = false;
                }
                OnPropertyChanged();
            }
        }



        public bool _IsImageQuestion { get; set; }
        public bool IsImageQuestion
        {
            get { return _IsImageQuestion; }

            set { _IsImageQuestion = value; OnPropertyChanged(); }
        }

        [PrimaryKey, AutoIncrement]
        public int QuestionsDataID { get; set; }
        public int Id { get; set; }
        public string QuestionImage { get; set; }
        public string CaseStudy { get; set; }
        public int QuestionId { get; set; }
        public int QuestionType { get; set; }
        public string UserKeyed { get; set; }
        public int ScorePerQuestion { get; set; }
        public string ImagePath { get; set; }
        public string Answered { get; set; }
        public string QtnTypeName { get; set; }
        public string LastUpdatedTime { get; set; }
        public int LastUpdatedQuestionID { get; set; }
        public string Category { get; set; }
        public string ContentReference { get; set; }
        public string CorrectAnswer { get; set; }
        public int GroupID { get; set; }
    }
    public class QuestionsResponseData
    {
        public string ExamName { get; set; }
        public string TotalNoOfQuestions { get; set; }
        public string IsAutoProctored { get; set; }
        public string ExamInstruction { get; set; }
        public string ExamCentreName { get; set; }
        public string Duration { get; set; }
        public string ElaspedTime { get; set; }
        public string LastUpdatedTime { get; set; }
        public List<EnglishQuestion> EnglishQuestions { get; set; }
        public List<HindiQuestion> HindiQuestions { get; set; }
        public string Answered { get; set; }
        public string UnAnswered { get; set; }
        public string NotVisited { get; set; }
        public string StatusCode { get; set; }
        public string StatusMessage { get; set; }

        public DateTime ServerTime { get; set; }


        public List<EnglishGroupDetail> EnglishGroupDetails { get; set; }
        public List<EnglishGroupDetail> HindiGroupDetails { get; set; }

        public List<QuestionLanguage> QuestionLanguages { get; set; }
        public Assignedexams AssignedExams { get; set; }

    }
    public class QuestionLanguage
    {
        public int LangID { get; set; }
        public string Language { get; set; }
    }

    public class Assignedexams
    {
        public int Id { get; set; }
        public int AssignedID { get; set; }
        public string QuestionID { get; set; }
        public string LastUpdatedTime { get; set; }
        public string LastUpdatedQuestionID { get; set; }
        public string Status { get; set; }
        public DateTime ExamStartTime { get; set; }
        public DateTime ExamEndTime { get; set; }
        public DateTime AssignedDate { get; set; }
        public object AutoID { get; set; }
        public string ExamID { get; set; }
        public string HireMeeID { get; set; }
        public string ReEvaluationStatus { get; set; }
        public string LastUpdatedGroupID { get; set; }
        public string ScoreUpdatedStatus { get; set; }
    }




}

