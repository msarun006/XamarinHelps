﻿using SQLite;

namespace HireMe.Models.Assessment.SQLTables
{
    public class ExamAnswersModel
    {
        [PrimaryKey, AutoIncrement]
        public int ID { get; set; }
        public string AssignedID { get; set; }
        public int QuestionID { get; set; }
        public string UserAnswer { get; set; }
        public string AdminMark { get; set; }
        public bool IsSynchedUp { get; set; }
        public string LastUpdatedTime { get; set; }
        public string GroupId { get; set; }
        public string Status { get; set; }
        public string LanguageMode { get; set; }
 
        public string Attempt { get; set; }
        public string EvaluatedBy { get; set; }
        public string EvaluatedDate { get; set; }
        public string MarkForReview { get; set; }
    }








}
