﻿using SQLite.Net.Attributes;

namespace HireMe.Models.Assessment.SQLTables
{
    public class ExamQuestionsModel
    {
        [PrimaryKey, AutoIncrement]
        public int ID { get; set; }
        public string AssignedID { get; set; }
        public string QuestionID { get; set; }
        public string CategoryID { get; set; }
        public string QuestionType { get; set; }
        public string Question { get; set; }
        public string CaseStudy { get; set; }
        public string OptionA { get; set; }
        public string OptionB { get; set; }
        public string OptionC { get; set; }
        public string OptionD { get; set; }
        public string OptionE { get; set; }
        public string CorrectAnswer { get; set; }
        public string ScorePerQuestion { get; set; }
        public string Category { get; set; }
        public string ContentReference { get; set; }
        public string GroupID { get; set; }

    }
}
