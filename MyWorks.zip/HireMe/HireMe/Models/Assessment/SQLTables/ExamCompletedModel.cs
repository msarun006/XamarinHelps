﻿using SQLite;

namespace HireMe.Models.Assessment.SQLTables
{
    public class ExamGroupModel
    {
        [PrimaryKey, AutoIncrement]
        public int ID { get; set; }
        public string AssignedID { get; set; }
        public string Status { get; set; }
        public string GroupID { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }
        public bool IsSynchedUp { get; set; }

        public int LastQuestionViewedPosition { get; set; }
    }
}
