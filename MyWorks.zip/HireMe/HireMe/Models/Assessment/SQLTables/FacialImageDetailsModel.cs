﻿using SQLite;

namespace HireMe.Models.Assessment.SQLTables
{ 
    public class FacialImageDetailsModel
    {

        [PrimaryKey, AutoIncrement]
        public int ID { get; set; }
        public string AssignedID { get; set; }
        public bool IsUploadedInToS3 { get; set; }
        public string ImageName { get; set; }
        public string FilePath { get; set; }
        public string UpdatedDate { get; set; }
        public bool IsSynchedUp { get; set; }
    }
}
