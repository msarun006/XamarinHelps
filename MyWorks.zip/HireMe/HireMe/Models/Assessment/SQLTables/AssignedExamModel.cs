﻿using SQLite;
namespace HireMe.Models.Assessment.SQLTables
{
	public class AssignedExamModel
	{
	[PrimaryKey, AutoIncrement]
	public int ID { get; set; }
	public string AssignedID { get; set; }
	public string AssignedDate { get; set; }
	public string Status { get; set; }
	public string ExamStartTime { get; set; }
	public string ExamEndTime { get; set; }
	public string ReEvaluationStatus { get; set; }
	public string LastUpdatedTime { get; set; }
	public string LastUpdatedQuestionID { get; set; }
	public string ScoreUpdatedStatus { get; set; }
	public string LastUpdatedGroupID { get; set; }
       
	}
}