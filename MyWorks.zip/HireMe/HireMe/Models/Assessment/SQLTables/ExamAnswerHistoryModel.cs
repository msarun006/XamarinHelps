﻿using SQLite;


namespace HireMe.Models.Assessment.SQLTables
{
    public class ExamAnswerHistoryModel
    {
        [PrimaryKey, AutoIncrement]
        public int ID { get; set; }
        public string AssignedID { get; set; }
        public string QuestionID { get; set; }
        public string UserAnswer { get; set; }
        public string LastUpdatedQuestionID { get; set; }
        public string LastUpdatedQuestionTime { get; set; }
        public string LastUpdatedSystemDate { get; set; }
        public bool IsSynchedUp { get; set; }
        public bool IsChargerConnected { get; set; }
        public bool IsHeadsetConnected { get; set; }
        public int LanguageId { get; set; }
    }
}
