﻿using SQLite;
namespace HireMe.Models.Assessment.SQLTables
{
    public class FeedbackModel
    {
        [PrimaryKey, AutoIncrement]
        public int ID { get; set; }
        public string AssignedID { get; set; }
        public string Feedback1 { get; set; }
        public string Feedback2 { get; set; }
        public string Feedback3 { get; set; }
        public string Comments { get; set; }
        public bool IsSynchedUp { get; set; }
    }
}
