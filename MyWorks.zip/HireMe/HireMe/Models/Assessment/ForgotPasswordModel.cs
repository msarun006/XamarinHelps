﻿
namespace HireMe.Models.Assessment
{

    public class ForgotPasswordResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public Response response { get; set; }
    }

    public class Response
    {
        public string email { get; set; }
        public string hiremee_id { get; set; }
    }
    public struct ForgotPasswordModelRequest
    {
        public string email_address { get; set; }
        public string token { get; set; }
    }

    public class ForgotPasswordRequestData
    {

        public string EmailAddress { get; set; }
        public string key_param { get; set; }
        public int type { get; set; }

    }
}
