﻿using HireMe.Models;
using MvvmHelpers;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace HireMe
{
    /// <summary>
    /// Course request data.
    /// </summary>
    #region Course Request Data
    public class CourseRequestData : BaseRequestDTO
    {
        [JsonProperty(PropertyName = "course_type_id")]
        public string CourseTypeID { get; set; }
    }

    #endregion

    /// <summary>
    /// Course response details.
    /// </summary>
    #region Course Response Data
    public class CourseResponseDetails : CourseRequestData
    {
        [JsonProperty(PropertyName = "data")]
        public List<Course> Response { get; set; }
    }



    /// <summary>
    /// Course response data.
    /// </summary>
    public class CourseResponseData
    {
        public string code { get; set; }
        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public CourseResponseDetails Response { get; set; }
    }


    /// <summary>
    /// Course.
    /// </summary>
    public class Course : BaseViewModel
    {
        [JsonProperty(PropertyName = "id")]
        public string ID { get; set; }

        //[JsonProperty(PropertyName = "name")]
        //public string Title { get; set; }
        private string _CourseTitle;
        [JsonProperty(PropertyName = "name")]
        public string Title
        {
            get { return _CourseTitle; }
            set { _CourseTitle = value; OnPropertyChanged(); }
        }


        private bool _isSelected;
        public bool IsSelected
        {
            get { return _isSelected; }
            set { _isSelected = value; OnPropertyChanged(); }
        }
    }


    #endregion

}
