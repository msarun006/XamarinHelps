﻿using Newtonsoft.Json;

namespace HireMe
{

    #region GetUserProfileInfo
    public class GetUserProfileInfoRequest
    {
        [JsonProperty(PropertyName = "token")]
        public string Token { get; set; }
        [JsonProperty(PropertyName = "hiremee_id")]
        public string HireMeID { get; set; }
    }

    public class GetUserProfileInfoResponse
    {
        [JsonProperty(PropertyName = "code")]
        public int Code { get; set; }
        [JsonProperty(PropertyName = "message")]
        public string Message { get; set; }
        [JsonProperty(PropertyName = "ResponseText")]
        public GetUserProfileInfoResponseText ResponseText { get; set; }
    }
    public class GetUserProfileInfoResponseText
    {
        [JsonProperty(PropertyName = "hiremee_id")]
        public string HireMeID { get; set; }
        [JsonProperty(PropertyName = "tokenid")]
        public string TokenID { get; set; }
        [JsonProperty(PropertyName = "fullname")]
        public string FullName { get; set; }
        [JsonProperty(PropertyName = "email_address")]
        public string EmailAddress { get; set; }
        [JsonProperty(PropertyName = "mobile_number")]
        public string MobileNumber { get; set; }
        [JsonProperty(PropertyName = "aadhaar_number")]
        public string AADHAARNumber { get; set; }
        [JsonProperty(PropertyName = "date_of_birth")]
        public string DateOfBirth { get; set; }
        [JsonProperty(PropertyName = "gender")]
        public string Gender { get; set; }
        [JsonProperty(PropertyName = "current_state")]
        public State CurrentState { get; set; }
        [JsonProperty(PropertyName = "current_city")]
        public District CurrentCity { get; set; }
    }

    #endregion

    #region GetUserProfilePicUrl
    public class GetUserProfilePicUrlRequest
    {
        [JsonProperty(PropertyName = "token")]
        public string Token { get; set; }
        [JsonProperty(PropertyName = "hiremee_id")]
        public string HireMeID { get; set; }
        [JsonProperty(PropertyName = "resourcetype_id")]
        public string ResourceTypeID { get; set; }
    }
    public class GetUserProfilePicUrlResponse
    {
        [JsonProperty(PropertyName = "code")]
        public int Code { get; set; }
        [JsonProperty(PropertyName = "message")]
        public string Message { get; set; }
        [JsonProperty(PropertyName = "responseText")]
        public GetUserProfilePicUrlResponseText ResponseText { get; set; }
    }
    public class GetUserProfilePicUrlResponseText
    {
        [JsonProperty(PropertyName = "token")]
        public string Token { get; set; }
        [JsonProperty(PropertyName = "hiremee_id")]
        public string HireMeID { get; set; }
        [JsonProperty(PropertyName = "resourcetype_id")]
        public string ResourceTypeID { get; set; }
        [JsonProperty(PropertyName = "s3_id")]
        public string S3ID { get; set; }
        [JsonProperty(PropertyName = "resourceurl")]
        public string ResourceURL { get; set; }

        [JsonProperty(PropertyName = "token_expiry")]
        public string Token_Expiry { get; set; }

    }

    #endregion

    #region  UpdateUserProfilePicUrl
    public class UpdateUserProfilePicUrlRequest
    {
        [JsonProperty(PropertyName = "token")]
        public string Token { get; set; }
        [JsonProperty(PropertyName = "hiremee_id")]
        public string HireMeID { get; set; }
        [JsonProperty(PropertyName = "resourcetype_id")]
        public string ResourceTypeID { get; set; }
        [JsonProperty(PropertyName = "s3_id")]
        public string S3ID { get; set; }
        [JsonProperty(PropertyName = "resourceurl")]
        public string ResourceURL { get; set; }
    }
    public class UpdateUserProfilePicUrlResponse
    {
        [JsonProperty(PropertyName = "code")]
        public int Code { get; set; }
        [JsonProperty(PropertyName = "message")]
        public string Message { get; set; }
        [JsonProperty(PropertyName = "responseText")]
        public UpdateUserProfilePicResponseText ResponseText { get; set; }

    }

    public class UpdateUserProfilePicResponseText
    {
        [JsonProperty(PropertyName = "token")]
        public string Token { get; set; }
        [JsonProperty(PropertyName = "hiremee_id")]
        public string HireMeID { get; set; }
        [JsonProperty(PropertyName = "expire")]
        public string Expire { get; set; }

    }
    #endregion

}
