﻿ 
using Amazon;

namespace HireMe
{
    public static class UserType
    {
        public const string JobSeeker = "seeker";
        public const string Recruiter = "recruiter";
        public const string College = "college";
    }
    public static class AmazonS3BucketDetails
    {
        #region LIVE  AMAZON S3 Buckets
        //public const string AssessmentImageBucket = "hiremee.mobileassessmentphotos";
        //public const string PhotoBucket = "hiremee.photos";
        //public const string HallTicketBucket = "hiremee.qrcodepdf";
        //public const string StudentIDCard = "hiremee.studentidcard";
        //public const string CollegeLogo = "hiremee.collegelogos";
        //public const string CompanyLogoBucket = "hiremee.companylogos";
        //public const string CompanyvideoBucket = "hiremee.companyvideos";
        //public const string VideoBucket = "hiremee.videos";
        #endregion

        #region UAT  AMAZON S3 Buckets
        public const string AssessmentImageBucket = "dev.hiremee.mobileassessmentphotos";
        public const string PhotoBucket = "dev.hiremee.photos";
        public const string HallTicketBucket = "dev.hiremee.qrcodepdf";
        public const string StudentIDCard = "dev.hiremee.studentidcard";
        public const string CollegeLogo = "dev.hiremee.collegelogos";
        public const string CompanyLogoBucket = "dev.hiremee.companylogos";
        public const string CompanyvideoBucket = "dev.hiremee.companyvideos";
        public const string VideoBucket = "dev.hiremee.videos";
        #endregion

        public static string PRO_CandidateAWS_KEY { get; set; } = "CAN";
        public static string PRO_CompanyAWS_KEY { get; set; } = "COM";
        public static string s3ResourceKey { get; set; } = "s3container";
        public static RegionEndpoint REGION { get; set; } = RegionEndpoint.APSoutheast1;
        public static string RecordedVideoPath { get; set; }

    }

  
    public static class APIData
    {
        #region API Details

        #region .NET Live API Details
        //public const string API_BASE_URL = "https://api.hiremee.co.in/api/";
        //public const string SampleAssessmentURL = "https://hiremee.co.in/assessment/mob/index/";
        //public const string TermsAndConditionURL = "https://hiremee.co.in/termsofuse";
        //public const string HOST_REACHABLE = "https://api.hiremee.co.in";
        //public const string CommonExceptionURL_Name = "Live";
        #endregion

        #region .NET Demo API Details
        //public const string API_BASE_URL = "http://demoapi.hiremee.co.in/api/";
        //public const string SampleAssessmentURL = "http://demohiremee.co.in/assessment/mob/index/";
        //public const string TermsAndConditionURL = "http://demohiremee.co.in/termsofuse";
        //public const string HOST_REACHABLE = "http://demoapi.hiremee.co.in";
        //public const string CommonExceptionURL_Name = "demoLive";
        #endregion

        #region .NET development API Details
        public const string API_BASE_URL = "http://devapi.hiremee.co.in:9083/api/";
        public const string HOST_REACHABLE = "http://devapi.hiremee.co.in:9083/";
        public const string SampleAssessmentURL = "http://dev.hiremee.co.in/assessment/mob/index/";
        public const string TermsAndConditionURL = "http://dev.hiremee.co.in/termsofuse";
        public const string CommonExceptionURL_Name = "UAT ";
        #endregion

        #region .NET Local Testing API  Details
        //public const string API_BASE_URL = "http://172.18.1.1:9082/api/";
        //public const string HOST_REACHABLE = "http://172.18.1.1:9082/";
        //public const string SampleAssessmentURL = "http://172.18.1.87:81/assessment/mob/index/";
        //public const string TermsAndConditionURL = "https://hiremee.co.in/termsofuse";
        //public const string CommonExceptionURL_Name = "Local Testing";
        #endregion

        #region .NET Local API Details
        //public const string API_BASE_URL = "http://172.18.1.1:9083/api/";
        //public const string HOST_REACHABLE = "http://172.18.1.1:9083/";
        //public const string SampleAssessmentURL = "http://172.18.1.87:81/assessment/mob/index/";
        //public const string TermsAndConditionURL = "https://hiremee.co.in/termsofuse";
        //public const string CommonExceptionURL_Name = "Local ";
        #endregion

        #region .NET RDS API Details
        //public const string API_BASE_URL = "http://52.76.103.21:8083/api/";
        //public const string SampleAssessmentURL = "http://13.228.117.254:86/assessment/mob/index/";
        //public const string TermsAndConditionURL = "http://13.228.117.254:86/terms-and-conditions";
        //public const string HOST_REACHABLE = "http://13.228.117.254:86";
        #endregion
        #endregion

        #region Linked In Credentials Email : androidveetech@gmail.com  Password: Temp!123  Website:https://www.linkedin.com/developers/login

        public static string LinkedinClientID { get; set; } = "86r15u0ogjlonr";
        public static string LinkedinClientSecret { get; set; }  = "HDkBbYesRgrlsdBD";

        #endregion

    }

    public static class APIMethods
    {

        #region  HireMe PRO Assessment API's
        public const string ValidateTestPin = "v11/validatetestpin";
        public const string Eventlog = "v11/eventlog";
        public const string Heartbeatlog = "v11/heartbeatlog";
        public const string Navigationlog = "v11/navigationlog";
        public const string ImageProctoredlog = "v11/imageproctoredlog";
        public const string GetSectionDetails = "v11/getsectiondetails";
        public const string GetQuestionDetails = "v11/getquestiondetails";
        public const string CandidateFeedback = "v11/candidatefeedback";
        public const string CompatiablityLog = "v11/compatibilitylog";
        public const string GetScore = "v11/getresult";
        #endregion

        #region HireMee CSR API's
        public const string PersonalDetailsUpdate_V8 = "v11/profile-details-update";
        public const string AddCollegeEducationDetails = "v11/add-degree-education";
        public const string UpdateSkillAndJObLocation = "v11/skill-update";
        public const string GetPersonalDetails = "v11/seekerdashboard";
        public const string CheckPanNumber = "v11/CheckPanNumber";
        public const string GetPinCodeDetails = "v11/GetPinCodeDetails";
        public const string APIVersionCheck = "v11/APIVersionCheck";
        public const string AddSchoolEducationDetails = "v11/add-school-education";
        public const string Login_v7 = "v11/login";
        public const string RecruiterDashboard = "v11/recruiterdashboard";
        public const string RegisterNewUser = "v11/register_email";

        public const string UpdateCrashReport = "v9/SendErrorNotification";
        public const string UpdateCertificationDetails = "v9/update-certificate-details";
        public const string DeleteCertificate = "v9/remove-certificate-details";
        public const string SearchCandidateByCourse = "v9/course";
        public const string SearchCandidateBySpecialization = "v9/specialization";
        public const string SearchCandidateByDistrict = "v9/district";
        public const string Previousrecruitersearch = "v9/previousrecruitersearch";
        public const string Selectedcandidatetohire = "v9/get-search-selected-lists";
        public const string RecruiterSearch = "v9/recruitersearch";
        public const string OTPVerify_v7 = "v9/verifyotpregister";
        public const string SocialOTPVerify_V9 = "v9/verifyotpregister-social";

        public const string ForgotPassword_V7 = "v9/password-reset";
        public const string SetPassword_v7 = "v9/passwordupdate";
        public const string Email_Mobile_Change_OTP_v7 = "v9/email_mobile_change_otp";
        public const string SocialLogin_v7 = "v9/social-login";
        public const string SocialRegister_v7 = "v9/social-login-register";
        public const string OTPVerify_forgot_V7 = "v9/forgot-password-update";
        public const string UpdateEmail_OTP_V7 = "v9/update_email_mobile";
        public const string FeedBack = "v9/feedback";
        public const string ChangePassword = "v9/changepassword";
        public const string ResetPassword = "v9/mresetpassword";
        public const string CheckMobileNumber = "v9/checkphonenumber";
        public const string UpdateBasicInfoDetails = "v9/basic-info-update";
        public const string CheckAadharNumber = "v9/checkaadharnumber";
        public const string GetEducationDetails = "v9/get-educational-details";
        public const string Comment = "v9/recruiteraboutcandidate";
        public const string ViewComment = "v9/recruitercomments";
        public const string AbouseReport = "v9/recruitercommentsabusevideo";
        public const string Templatelist = "v9/recruitertemplatelist";
        public const string StudentIDCardUpdate = "v9/studentidcardinsert";
        public const string StudentIDCardRetrive = "v9/studentidcardretrival";
        public const string CandidateHired = "v9/candidatehired";
        public const string RejectCandidate = "v9/rejectedcandidateinsert";
        public const string SelectCandidate = "v9/selectedcandidateinsert";
        public const string Profileviewer = "v9/profileviewer";
        public const string GetSearchRejectedLists = "v9/get-search-rejected-lists";
        public const string GetSearchSelectedLists = "v9/get-search-shortlisted-lists";
        public const string RecruiterProfileviewer = "v9/search-view-count";
        public const string Getfirebasenotification = "v9/getfirebasenotification";
        public const string Mailtoselectedcandidates = "v9/mailtoselectedcandidates";
        public const string Recruitersearchhistory = "v9/recruitersearchhistory";
        public const string Selectionlist = "v9/selectionlist";
        public const string Selectionshortlist = "v9/selectionshortlist";
        public const string RejectionList = "v9/rejection-lists";
        public const string SendMailPreview = "v9/recruitersendmailpreview";
        public const string FirebaseUpdate = "v9/firebaseupdate";//
        public const string FirebaseRemove = "v9/firebaseidremove";
        //public const string Userresourceretrival = "v9/userresourceretrieval";///
        public const string MasterTables = "v9/mastertables";
        public const string MultipleSkillSelection = "v9/skill-lists";
        public const string PreferredJobLocation = "v9/job-locations";
        public const string BoardNameList = "v9/board-lists";
        public const string BindCollegeName = "v9/registercollege";
        public const string BindCountryList = "v9/countrieslist";
        public const string BindDistrict = "v9/district";
        public const string BindCourse = "v9/course";
        public const string Specialization = "v9/specialization";
        public const string Recruiterprofiledetails = "v9/recruiterprofiledetails";
        public const string GetCollege = "v9/college";
        public const string UserResourceInsert = "v9/userresourceinsert";
        public const string Recruiterprofiledetailsretrival = "v9/recruiterprofiledetailsretrival";
        public const string CompanyFullDetails = "v9/companydetails";
        public const string CollegeWiseRegistration = "v9/candidate_register";
        public const string Regeneratetoken = "v9/regeneratetoken";
        public const string S3creidentails = "v9/s3creidentails";
        public const string CheckPassportNumber = "v9/checkpassportnumber";
        public const string CheckEmaiID = "v9/checkemailaddress";
        public const string CollegeDashboard = "v9/collegedashboard";
        public const string AssessmentReport = "v9/assessmentdetails";
        public const string RegisteredStudent = "v9/registerstudentlist";
        public const string UploadedStudent = "v9/uploadedstudentlist";
        public const string GetExamDetails = "v10/getexamDetailsforstudent";
        public const string Getloadbulkquestions = "v10/loadbulkquestions";
        public const string InvigilatorLogin = "v9/invigilatorlogin";
        public const string BulkInsertCopy = "v10/bulkinsertcopy";
        public const string IncreaseNoOfAttempt = "v9/increasenoofattempt";
        public const string CurrentOpenings = "v11/GetCurrentOpenings";
        public const string GetStateDistrictFromPicode = "http://postalpincode.in/api/pincode/";
        public const string GetSearchJobsList = "v11/CandidateSearchJobs";
        public const string JobDetails = "v11/ViewCandidateJobs";
        public const string GetCurrentWalinsList = "v11/GetCurrentWalkins";
        public const string ApplyJob = "v11/ApplyJob";
        public const string GetRecommendedJobs = "v11/GetRecommendedJobs";
        public const string GetAppliedJobs = "v11/CandidateAppliedJobs";
        public const string GetSavedSearchjobs = "v11/GetSavedSearchJobs";
        public const string GetWorkType = "v11/GetEmployeeWorkType"; 
        #endregion

    }
    
}
