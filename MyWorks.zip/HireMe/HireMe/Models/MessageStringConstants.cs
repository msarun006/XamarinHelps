﻿using System;

namespace HireMe
{
    public static class MessageStringConstants
    {
        static MessageStringConstants()  {  }
        public static bool IsTakeSnop { get; set; } = true;
        public static bool IsSchoolOrCollegeDetailsUpdated { get; set; } = false;
        public static bool IsCertificateDetailsModified { get; set; } = false;
        public static bool IsAPIProcess { get; set; } = true;
        public static bool IsSearchComplete { get; set; } = true;
        public static bool IsCanelButton { get; set; } = true;
        public static bool IsCurrentState { get; set; } = true;
        public static bool IsCurrentCity { get; set; } = true;
        public static string TempEmailID { get; set; }
        public static bool IsSyncupProcess { get; set; } = true;
        public static bool EmailLink { get; set; } = false;
        
        public static string OTPLimitExpired { get; set; } = "OTP Expired! Kindly click resend to generate OTP again!";
        public static string insufficientQuestion { get; set; } = "There is insufficient number of question for this assessment, please contact Support@hireMee.co.in";
        public static string HindiinsufficientQuestion { get; set; } = "इस मूल्यांकन के लिए अपर्याप्त संख्या में सवाल है, कृपया Support@hireMee.co.in से संपर्क करें";
        public static string SeekerPersonalPageName = "SeekerPersonal";
        public static string ChangeProfilePageName = "ChangeProfile";

        public static string CandidateDetailPage = "CandidateDetailPage";
        public static string EnterEducationalDetails = "Enter Educational Details";
        public static string UpdateYourSchoolDetails = "Update Your School Details";
        public static string CertificationNameEmptyMessage = "Enter your Certification Name";
        public static string CertificationYearEmptyMessage = "Select your Certification Year";
        public static string CertificationDuplicateMessage = "Certification details already exist.";
        public static string UpdateYourCollegeDetails = "Update Your College Details";

        public static string AlreadyCompletedAssessment { get; set; } = "You are already completed Assessment based on this education details. So, you can not change it. Futher details please contact Support@hireMee.co.in";

        public static string UpdateLatestVersion{get;set;}="Please Update the Latest Version of HireMee App";
             public static string EnterValidRegisterNumber { get; set; } = "Enter Valid Register Number";
        public static string EnterAboutMe { get; set; } = "Enter About me content";
        public static string EnterValidAboutMe { get; set; } = "About me content require minimum 50 Characters";
        public static string EnterValidPANNumber { get; set; } = "Enter Valid PAN Number";
        public static string EnterValidAadhaarNumber { get; set; } = "Enter Valid Aadhaar Number";
        public static string EnterValidPassportNumber { get; set; } = "Enter Valid Passport Number";
        public static string SelectPrimarySkills { get; set; } = "Select Primary Skills";
        public static string SelectSecondarySkills { get; set; } = "Select Secondary Skills";
        public static string AlreadyExamCompleted { get; set; } = "This group Already completed.";
        public static string AlreadyExamCompletedHindi { get; set; } = "यह अनुभाग पहले ही पूरा हो चुका है।";
        public static string EnterOthersSkill { get; set; } = "Enter Others Skill";
        public static string SelectSkill { get; set; } = "Select minimum one skill.";
        public static string EnterOldPassword { get; set; } = "Enter Valid Old Password";
        public static string EnterNewPassword { get; set; } = "Enter Valid New Password";
        public static string LastAttempt { get; set; } = "This is your last Attempt to take Assessment.";
        public static string LastAttemptHindi { get; set; } = "परीक्षा लेने के लिए यह अपका अंतिम प्रयास है.";
        public static string MaximumReached { get; set; } = "You have exceeded the maximum number of attempts to write assessment, please contact Support@hireMee.co.in";
        public static string CancelOTP { get; set; } = "Are you sure to close OTP Verification.";
        public static string CancelSetPassword { get; set; } = "Are you sure to close set Password.";
        public static string SelectPreferredLanguage { get; set; } = "Select Preferred language.";
        public static string MobileNumberNotVerified = "Mobile Number not yet Verified,Press 'OK' to verify.";
        public static string mobilenumbernotverify = "Mobile Number not yet Verified,Press 'OK' to verify or Press 'Cancel' to save details.";
        public static string InvalidEmailAddress { get; set; } = "Enter Valid Email Address";
        public static string EmailAddressAlreadyVerified { get; set; } = "Email Address Already Verified!";
        public static string InvalidEmailMobile { get; set; } = "Enter Valid Email or mobile number";
        public static string DeviceAlreadyLoggedIn { get; set; } = "This device already Logined with some other user, Make sure to Delete all the Existing Data";
        public static string EmailAlreadyExist = "The given email id was already present with us..!";
        public static string MobileNoAlreadyExist = "Your Mobile Number already with us..! Please try some other Mobile Number";
        public static string InvalidOTP { get; set; } = "Enter Valid OTP";
        public static string NullOTP { get; set; } = "Enter OTP";
        //public static string SubmitExam { get; set; } = "Thank you for submitting the assessment. Your results will be displayed in the  dashboard with in 24 hours";
        //public static string HindiSubmitExam { get; set; } = "परीक्षा सबमिट करने के लिए धन्यवाद। आपके परीक्षाफल को 24 घंटे के भीतर डैशबोर्ड में प्रदर्शित कर दिया जाएगा।";
        public static string SubmitExam { get; set; } = "Thank you for submitting the assessment. Your results will be displayed in the  dashboard.";
        public static string HindiSubmitExam { get; set; } = "परीक्षा जमा करने के लिए धन्यवाद। आपका परीक्षण डैशबोर्ड में प्रदर्शित किया जाएगा.";//"परीक्षा सबमिट करने के लिए धन्यवाद। आपके परीक्षाफल को 24 घंटे के भीतर डैशबोर्ड में प्रदर्शित कर दिया जाएगा।";

        public static string OfflineSubmitExam { get; set; } = "It seems you don’t have active internet connection at the moment.Connnect to internet to sync your data";
        public static string HindiOfflineSubmitExam { get; set; } = "ऐसा लगता है कि इस समय आपके पास सक्रिय इंटरनेट कनेक्शन नहीं है। अपने डेटा को सिंक करने के लिए इंटरनेट से कनेक्ट करें।";
        public static string SelectUniversity { get; set; } = "Select University";
        public static string SelectCollege { get; set; } = "Select College";
        public static string SelectCourse { get; set; } = "Select Course";
        public static string SelectCourseType { get; set; } = "Select Course Type";
        public static string SelectSpecialization { get; set; } = "Select Specialization";
        public static string EnterFeedback { get; set; } = "Enter Feedback";
        public static string EnterFeedbackSubject { get; set; } = "Enter Feedback Subject";
        public static string EnterPassword { get; set; } = "Enter Password";
        public static string DeleteCertificateAlert = "Are you sure to delete the Certificate?";
        public static string EntermobileNo { get; set; } = "Enter Mobile No";
        public static string EnterValidmobileNo { get; set; } = "Enter Valid Mobile No";
        public static string EnterValidLengthPassword { get; set; } = "Password must be Minimum 6 Digits";
        public static string EnterEmailAddress { get; set; } = "Enter Email Address";
        public static string EnterValidEmailAddress { get; set; } = "Enter Valid Email Address";
        public static string EnterInputMobile { get; set; } = "Enter Mobile Number";
        public static string EnterInputField { get; set; } = "Enter Email or Mobile No";
        public static string EnterInputEmail { get; set; } = "Enter Email Address";
        public static string EnterCGPAORPercentage { get; set; } = "Enter Valid CGPA or Percentage";
        public static string SelectedMaximumSkill { get; set; } = "You have selected maximum skills";
        public static string SelectedMaximumData { get; set; } = "You have selected maximum Data";
        public static string SelectedMaximumPerferedJobLocation { get; set; } = "You have selected maximum Preferred Job Locations";
        public static string MaximumCertifications { get; set; } = "You have added maximum Certifications.";
        public static string SelectedMaximumstate { get; set; } = "You have selected maximum States";
        public static string SelectedMaximumyears { get; set; } = "You have selected maximum Completion Years";
        public static string EnterEmailContent { get; set; } = "Enter the Subject";
        public static string SelectDate { get; set; } = "Select Interview Date";
        public static string SelectPlace { get; set; } = "Enter Interview Place";
        public static string AboutMeVideoNotAvailable { get; set; } = "About Me Video Not Available";
        public static string EnterValidTestPinMessage { get; set; } = "Enter Valid Test Pin";

        public static string IsAdmin_CompanyProfile { get; set; } = "IsAdmin_CompanyProfile";
        
        public static string SkillVideoNotAvailable { get; set; } = "Skill Video Not Available";
        public static string InterestVideoNotAvailable { get; set; } = "Interest Video Not Available";
        public static string CheckInternetConnection { get; set; } = "Check Internet Connection";
        public static string CheckInternetConnectionSlow { get; set; } = "Internet connection slow.";
        public static string ServerNotReachable { get; set; } = "Server not reachable. Please try again";
        public static string SelectCurrentState { get; set; } = "Select Present State";
        public static string SelectCurrentDistrict { get; set; } = "Select Present District";
        public static string SessionExpiered { get; set; } = "Your session has been expired, Please Login again.";
        public static string SelectHomeState { get; set; } = "Select Permanent State";
        public static string SelectHomeDistrict { get; set; } = "Select Permanent District";
        public static string SelectCandidate { get; set; } = "Select Candidate(s)";
        public static string SelectAtleastOneField { get; set; } = "Select at least one field";
        public static string PasswordMismatched { get; set; } = "Confirm Password does not match with Password";
        public static string WeakPassword { get; set; } = "Weak Password. Password must be minimum 6-15 characters long";
        public static string EnterValidMobileNumber { get; set; } = "Enter Valid Mobile Number";
        public static string EnterValidLastName { get; set; } = "Enter Valid Last Name and it should be alphabets.";
        //public static string EnterValidFirstName { get; set; } = "Name Should be Minimum 3 Characters and  it should be alphabets.";
        public static string EnterValidFirstName { get; set; } = "Name Should not be empty and it should be alphabets.";
        public static string EnterConfirmPassword { get; set; } = "Enter Valid Confirm Password";
        public static string CameraUnavailable { get; set; } = "Camera Unavailable";
        public static string UnableToUpdateProfilePicture { get; set; } = "Unable to update your Profile Picture";
        public static string VideoAlreadyExist { get; set; } = "Video Already Exist";
        public static string RecordNewVideo { get; set; } = "Record New Video";
        public static string IntroductionVideoUploaded { get; set; } = "About Me Video Uploaded";
        public static string SkillVideoUploaded { get; set; } = "Skill Video Uploaded";
        public static string InterestsVideoUploaded { get; set; } = "Interests Video Uploaded";
        public static string UploadMandatoryVideos { get; set; } = "Upload Mandatory Videos to Proceed Further";
        public static string ThankyouForUploadMandotoryVideos { get; set; } = "Thank you for upload the video profile and all the best for your career";
        public static string NoRecordsFound { get; set; } = "No records found.";
        public static string AreaOfInterestVideoApprovedStatus { get; set; } = "Area of Interest Video is Already Approved";
        public static string SkillVideoApprovedStatus { get; set; } = "Skill Video is Already Approved";
        public static string AboutVideoApprovedStatus { get; set; } = "About Me Video is Already Approved";
        public static string ShortListConfirmationAlert { get; set; } = "Do you want to Shortlist this candidate";
        public static string RejectConfirmationAlert { get; set; } = "Do you want to Reject this candidate";
        public static string EnsureVideoQuality { get; set; } = "Please ensure video and audio quality is good, Are you sure want to upload your video?";
        public static string EnterValidCurrentPincode { get; set; } = "Enter Valid Present Pincode";
        public static string EnterValidPermanentPincode { get; set; } = "Enter Valid Permanent Pincode";
        public static string EnterValidPincode { get; set; } = "Enter Valid Pincode";
        public static string SelectPermanentState { get; set; } = "Select Permanent State";
        public static string SelectPermanentDistrict { get; set; } = "Select Permanent District";
        public static string EnterCurrentAddress { get; set; } = "Enter Valid Present Address";
        public static string EnterCurrentAddressLength { get; set; } = "Enter Present Address Minimum 15 Charaters";
        public static string EnterPermanentAddress { get; set; } = "Enter Valid Permanent Address";

        public static string EnterPermanentAddressLength { get; set; } = "Enter Permanent Address Minimum 15 Charaters";
        public static string SelectSchoolName { get; set; } = "Select School Name";
        public static string SelectBoardType { get; set; } = "Select BoardType";
        public static string SelectYearOfCompletion { get; set; } = "Select Year Of Completion";
        public static string TokenMissing { get; set; } = "Missing token and values.";
        public static string SelectPreferredJobLocation { get; set; } = "Select Preferred Job Location";
        public static string SelectState { get; set; } = "Select State";
        public static string SelectCity { get; set; } = "Select City";
       // public static int SelectMonth { get; set; } = DateTime.Now.Month;
        public static string ProfileCompletence { get; set; } = "Profile Complete Status";
        public static string UpdateVideoProfile { get; set; } = "Please Update Video Profile";
        public static string UpdateEducationalDetails { get; set; } = "Please Update Education Details";
        public static string UpdateProfilePic { get; set; } = "Please Update Profile Picture";
        public static string UpdatePersonalDetails { get; set; } = "Please Update personal Profile";
        public static string OTPSendMessageEmail { get; set; } = "OTP will sent to your registered email.";
        public static string OTPSendMessageMobile { get; set; } = "OTP will sent to your entered Mobile Number";
        public static string EnterRegisterEmailAlert { get; set; } = "Enter your registered email";
        public static string ExamDataNotUpdatedMessage { get; set; } = "Your exam hasn't been uploaded to hiremee. Kindly syncronize your data.";
        public static bool IsSameUser { get; set; } = false;
        public static string FromWhichButton { get; set; }
        public static DateTime LastFacedCroppedTime { get; set; }
        public static DateTime LastQuestionViewedTime { get; set; }
        public static string DeviceIDNotMatch { get; set; } = "You have already taken the Assessment from some other device. Kindly use the same device to continue your assessment or else contact HireMee support@hiremee.co.in";
        public static string DeviceIDNotMatchHindi { get; set; } = "आपने किसी अन्य डिवाइस से परीक्षा ले ली है। कृपया परीक्षा दुबारा प्रारम्भ करने के लिए उसी डिवाइस का इस्तेमाल करें या HireMee टीम से संपर्क करें।.";
        public static string QuestionsNotFound { get; set; } = "Exam Questions not available, Please try again";
        public static string QuestionsNotFoundHinid { get; set; } = "परीक्षा प्रश्न नहीं मिला।";
        public static string EnterHireMeeID { get; set; } = "Enter HireMee ID";
        public static string EnterInvigilatorPassword { get; set; } = "Enter Invigilator Password";
        public static string ServerBusyMessage { get; set; } = "Server Busy. Please Try Again";
        public static string ExamTimeOutMessage { get; set; } = "You have exceeded the maximum Allocated Time for this assessment";
        public static string ExamTimeOutMessageForSection { get; set; } = "You have exceeded the maximum Allocated Time for this section";
        public static string SectionTimeOutMessageForPreviousSection { get; set; } = "You have exceeded the maximum Allocated Time for the previous section";
        public static string SectionTimeOutMessageForNextSection { get; set; } = "You have exceeded the maximum Allocated Time for the next section";
        public static string ExamTimeOutMessageHindi { get; set; } = "इस सत्र की समयसीमा समाप्त हो गयी है।";
        public static string PleaseSelectAnswer { get; set; } = "Select Your choice and rating for it.";
        public static string PleaseSelectOption { get; set; } = "Select rating for your choice.";
        public static string pleaseSelecteAnserHindi { get; set; } = "इसके लिए अपनी पसंद और रेटिंग का चयन करें।";
        public static string Answered { get; set; } = "Answered";
        public static string NotAnswered { get; set; } = "NotAnswered";
        public static string NotVisited { get; set; } = "NotVisited";
        public static string ExitAlert { get; set; } = "Are you sure want to Exit";
        public static string ExitAlertAssessment { get; set; } = "Are you sure want to Exit from Assessment";
        public static string ExitAlertAssessmentHindi { get; set; } = "परीक्षा से बाहर निकलने के लिए क्या आप निश्चित हैं?";
        public static string OKHindi { get; set; } = "ठीक है";
        public static string CancelHindi { get; set; } = "ख़ारिज करें।";
        public static string YesHindi { get; set; } = "हाँ";
        public static string NoHindi { get; set; } = "ना";
        public static string TermsAndCondition { get; set; } = "Please agree terms and conditions";
        public static string TermsAndConditionHindi { get; set; } = "कृपया नियमों और शर्तों पर सहमति दें";
        public static string CompletedColor { get; set; } = "#008001";
        public static string InCompletedColor { get; set; } = "#dd0707";
        public static string NotStatedColor { get; set; } = "#7f7f7f";
        public static string InvigilatorMessage { get; set; } = "Already a user has logged in with same credentials. Kindly Check with Invigilator";
        public static string DataSyncupSuccess { get; set; } = "Thank you for uploading the assessment data. Your results will be published shortly in your dashboard";
        public static string HindiDataSyncupSuccess { get; set; } = "परीक्षा डेटा अपलोड करने के लिए धन्यवाद। आपके परीक्षाफल को शीघ्र ही डैशबोर्ड में प्रदर्शित कर दिया जाएगा।";
        public static string DataSyncupSuccessHindi { get; set; } = "डाटा सफलतापूर्वक अपडेट हो चुका है..!";
        public static string ServerAvailableMessage { get; set; } = "HireMeeAssessment server available only 7AM to 10PM";


        public static string TakePhotoFaceNotDetected { get; set; } = "Your Face is not visible to the camera, Adjust your phone to be visible for your face.";

        public static string MultiFaceDetected { get; set; } = "Multiple faces occurs, Kindly capture the respective Assessment person";


        public static string CouldNotSetUpTheDetector { get; set; } = "We are unable to detect your Face, Please update your Google Play Service and Try Again";
        public static string FaceNotDetected { get; set; } = "Your Face is not visible to the camera, Adjust your phone to be visible for your face. If your face is not visible, your Assessment might be rejected";
        public static string HindiFaceNotDetected { get; set; } = "आपका चेहरा कैमरा के लिए अस्पष्ट है, अपने चेहरे को स्पष्ट करने के लिए अपने फोन को ठीक से रखें। यदि आपका चेहरा स्पष्ट दिखाई नहीं देगा, तो आपकी परीक्षा को खारिज कर दिया जा सकता है।";
        public static string MustCompleteAllGroups { get; set; } = "Must Complete all your assigned Groups";
        public static string MustCompleteAllGroupsHindi { get; set; } = "आपको असाइन किए गए सभी ग्रूप को पूरा करना होगा।";
        public static string BatteryLowMessage { get; set; } = "Your Battery is Low, Please connect charger for uninterrupted Assessment Experience";
        public static string HindiBatteryLowMessage { get; set; } = "आपकी बैटरी कम है, कृपया निर्बाध आकलन अनुभव के लिए चार्जर कनेक्ट करें";
        public static string Warning { get; set; } = "Clear Warnings!!!";
        public static string WarningHindi { get; set; } = "चेतावनियां साफ करें!!!";
        public static string FinishMessage { get; set; } = "Do you want to Finish the selected Group?";
        public static string FinishTheSection { get; set; } = "Do you want to Finish this Section?";
        public static string FinishMessageHindi { get; set; } = "क्या आप चयनित ग्रूप को समाप्त करना चाहते हैं?";
        public static string PermissionMessage { get; set; } = "Please enable permissions manually";
        public static string Remaining { get; set; } = "This is attempt ";
        public static string RemainingHindi { get; set; } = "This is attempt ";
        public static string Attempt { get; set; } = " of maximum ";
        public static string AttemptHindi { get; set; } = " of maximum ";
        public static string AlreadyLogin { get; set; } = "This device already Logined with some other user, Make sure to Delete all the Existing Data";
        public static string Feed1message { get; set; } = "Please give your feedback for Question1";
        public static string HindiFeed1message { get; set; } = "प्रश्न 1 के लिए कृपया अपनी प्रतिपुष्टि दें ";
        public static string Feed2message { get; set; } = "Please give your feedback for Question2";
        public static string HindiFeed2message { get; set; } = "प्रश्न 2 के लिए कृपया अपनी प्रतिपुष्टि दें ";
        public static string Feed3message { get; set; } = "Please give your feedback for Question3";
        public static string HindiFeed3message { get; set; } = "प्रश्न 3 के लिए कृपया अपनी प्रतिपुष्टि दें";
        public static string Feed4message { get; set; } = "Please enter your comments.";
        public static string HindiFeed4message { get; set; } = "कृपया अपनी टिप्पणियाँ दर्ज करें";
        public static string FillAllFeedbacks { get; set; } = "Please give your feedback for all Questions";
        public static string HindiFillAllFeedbacks { get; set; } = "कृपया सभी प्रश्नों के लिए आपकी फीडबैक दें।";
        public static string FeedbackSuccess { get; set; } = "Thank You for your valuable feedback.";//, your assessment scores will be updated in 24 hours.";
        public static string FeedbackSuccessHindi { get; set; } = "आपके मूल्यवान प्रतिपुष्टि के लिए धन्यवाद.";//, आपके परीक्षा अंक अगले 24 घंटे में अपडेट किए जाएंगे।.";        
        public static string RecruiterPasswordOLDCriteria { get; set; } = "Enter Valid Old Password. Use a combination of upper case, lower case, numbers and special characters";
        public static string RecruiterPasswordNewCriteria { get; set; } = "Enter Valid New Password. Use a combination of upper case, lower case, numbers and special characters";
        public static string RecruiterPasswordConfirmCriteria { get; set; } = "Enter Valid Confirm Password. Use a combination of upper case, lower case, numbers and special characters";
        public static string RegistrationSuccessMessage { get; set; } = "Registration Completed Successfully. Login Your Account";
        public static string UpdateGooglePlayService { get; set; } = "Please update your Google Play Service for uninterrupted Assessment Experience";
        public static string DoNotTilltMobile { get; set; } = "Video Capturing Orientation Should be in Portrait Mode.";
        public static string FilterSearch { get; set; } = "Select atleast one field to filter";
        public static string ServerNotReachableRefresh { get; set; } = "Server Not Reachable. Kindly Refresh Again";
        public static string AssesmentProfileMessage { get; set; } = "Use this Image as Profile Picture";
        public static string AssesmentProfileImageConfirm { get; set; } = "Please Accept to Use this Image as Profile Picture";
        public static string ModeValidationMessage { get; set; } = "Mobile device does not support this Assessment.Please take the Assessment on Web";
        public static string SectionAvailableMessage { get; set; } = "Section only available web portal assessment";
        #region PRO_Assessment
        public static string EmptyTestPin { get; set; } = "Enter Test PIN";
        public static string TestPinValidation { get; set; } = "Enter Valid Test PIN";
        public static string PRO_InstructionReadConfirmation { get; set; } = "Kindly Agree to Continue";
        public static string AreyousuretogoExamSection  { get; set; } = "Are you sure to go Exam Section Page";
        public static string FinishAlertAssessment { get; set; } = "Are you sure want to finish the Assessment";
        public static string SelectBehaviouralQuestion { get; set; } = "First select behavioural Question";
       
        public static string ExamCompletedColor { get; set; } = "#008001";
        public static string ExamProgressColor { get; set; } = "#326fc0";
        public static string ExamNotStartedColor { get; set; } = "#eaeaea";
        public static string ExamTimeElapsedColor { get; set; } = "#7f7f7f";
        public static string NoofRtries { get;  set; } = "Number of retries exceed the limit given by company";

        public static string PRO_FaceNotDetected { get; set; } = "App doesn't recognize your face in captured photo. Please Retake";
        public static string PRO_MultiFaceDetected { get; set; } = "App recognize muliple faces in captured photo. The captured photo should contains only one face";
        public static string PRO_CaptureYourAssesmentPhoto { get; set; } = "Your photo should be mandatory for Image Proctoring Assesment";
        public static string PRO_FinishExamusingEndTestButton { get; set; } = "If you want finish the assessment, click EndTest button";
        public static string PRO_YourProofImageAlreadyAvailable { get; set; } = "Your Proof Image Already Available";

        public static string LowNetworkSpeedAlert { get; set; } = "App doesn't support for LinkedIn Authentication in this network speed";



        #endregion
    }
}
