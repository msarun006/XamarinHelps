﻿using Newtonsoft.Json;

namespace HireMe.Models
{
    public class NoOfAttemptsRequestModel : BaseRequestDTO
    {
        public string examid { get; set; }
    }

    public class NoOfAttemptsResponse
    {

        [JsonProperty(PropertyName = "StatusCode")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "StatusMessage")]
        public string message { get; set; }
        public string NoofAttempt { get; set; }
 
    }
}
