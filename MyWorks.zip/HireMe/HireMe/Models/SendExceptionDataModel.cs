﻿namespace HireMe.Models
{
    public class ExceptionRequestData
    {
        public string Message { get; set; }
        public string StackTrace { get; set; }
        public string Source { get; set; }
        public string InnerException { get; set; }
    }
    public class ExceptionResponseData
    {
        public string code { get; set; }
        public string message { get; set; }
        public string responseText { get; set; }
    }





}
