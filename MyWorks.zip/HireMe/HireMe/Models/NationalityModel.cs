﻿using System.Collections.Generic;


namespace HireMe.Models
{
    public class NatioinalityResponseData
    {
        public string id { get; set; }
        public string country_name { get; set; }
    }

    public class NatioinalityResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public List<NatioinalityResponseData> responseText { get; set; }
    }
}
