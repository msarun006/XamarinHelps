﻿using Newtonsoft.Json;

namespace HireMe.Models
{
    #region Feedback Request Data
    public class FeedbackRequestData : BaseRequestDTO
    {

        [JsonProperty(PropertyName = "emailaddress")]
        public string EmailAddress { get; set; }

        [JsonProperty(PropertyName = "subject")]
        public string Subject { get; set; }

        [JsonProperty(PropertyName = "content")]
        public string Content { get; set; }

    }

    #endregion

    #region Feedback Response Data
    /// <summary>
    /// Feedbacks response data.
    /// </summary>
    public class FeedbacksResponseData
    {

        public string code { get; set; }
        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public string ResponseText { get; set; }

    }

    #endregion
}
