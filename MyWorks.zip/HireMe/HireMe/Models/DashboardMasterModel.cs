﻿using MvvmHelpers;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Xamarin.Forms;

namespace HireMe
{
    //public class DashboardMasterModel
    //{


    //    public String Title { get; set; }
    //    public String Icon { get; set; }
    //    public Type TargetType { get; set; }

    //}

    public class DashboardMasterModel : ObservableCollection<SubMenuItem>, INotifyPropertyChanged
    {

        private bool _expanded;

        public string Title { get; set; }

        public int ExpandIndex { get; set; }

      

        public bool Expanded
        {
            get { return _expanded; }
            set
            {
                if (_expanded != value)
                {
                    _expanded = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private string stateIcon;
        public string StateIcon
        {
            get { return Expanded ? "arrowdown.png" : "arrowright.png"; }
            set { stateIcon = value;
                NotifyPropertyChanged();
            }
        }
        
        public string DefaultIcon
        {
            get;
            set;
        }
        
        private bool _StateIconIsVisible;
        public bool StateIconIsVisible
        {
            get { return _StateIconIsVisible; }
            set { _StateIconIsVisible = value; NotifyPropertyChanged(); }
        }
        


        public int FoodCount { get; set; }
        public DashboardMasterModel(string defaultIcon,string title,  int expandIndex, bool stateIconIsVisible, bool expanded = false)
        {
            DefaultIcon = defaultIcon;
            Title = title;
            Expanded = expanded;
            ExpandIndex = expandIndex;
            StateIconIsVisible = stateIconIsVisible;
        }

        public static ObservableCollection<DashboardMasterModel> SeekerMenuItem { private set; get; }
        public static ObservableCollection<DashboardMasterModel> RecruiterMenuItem { private set; get; }

        static DashboardMasterModel()
        {
            

            ObservableCollection<DashboardMasterModel> seekerMenuItems = new ObservableCollection<DashboardMasterModel>{
                new DashboardMasterModel((string)Application.Current.Resources["IconDashboard"],"My Dashboard",0,false),
                new DashboardMasterModel((string)Application.Current.Resources["IconNotification"],"Notifications",1,false),
                new DashboardMasterModel((string)Application.Current.Resources["IconIdCard"],"Capture Student ID",2,false),
                new DashboardMasterModel((string)Application.Current.Resources["IconQRCode"],"QR Code Image",3,false),
                new DashboardMasterModel((string)Application.Current.Resources["IconMessage"],"Recruiter's Message",4,false),
                new DashboardMasterModel((string)Application.Current.Resources["IconCompany"],"Company Details",5,false),
                new DashboardMasterModel((string)Application.Current.Resources["IconAssessmentTest"],"Assessment",6,true){
                      new SubMenuItem { SubMenuitemName = "Mock Assessment", SubMenuitemIcon=(string)Application.Current.Resources["IconAssessmentTest"]},
                      new SubMenuItem { SubMenuitemName = "HireMee Assessment",  SubMenuitemIcon=(string)Application.Current.Resources["IconAssessmentTest"]},
                   },
                new DashboardMasterModel((string)Application.Current.Resources["CurrentOpenings"],"Current Openings",7,false),
                new DashboardMasterModel((string)Application.Current.Resources["CurrentWalkins"],"Current Walkins",8,false),

                new DashboardMasterModel((string)Application.Current.Resources["IconJobs"],"Jobs",9,true){
                      new SubMenuItem { SubMenuitemName = "Search Jobs", SubMenuitemIcon=(string)Application.Current.Resources["SearchJobs"]},
                      new SubMenuItem { SubMenuitemName = "Applied Jobs",  SubMenuitemIcon=(string)Application.Current.Resources["AppliedJobs"]},
                      new SubMenuItem { SubMenuitemName = "Recommended Jobs",SubMenuitemIcon=(string)Application.Current.Resources["RecommendedJobs"]},
                      },

                new DashboardMasterModel((string)Application.Current.Resources["IconSettings"],"More",10,true){
                      new SubMenuItem { SubMenuitemName = "FAQ's", SubMenuitemIcon=(string)Application.Current.Resources["IconFAQ"]},
                      new SubMenuItem { SubMenuitemName = "Settings",  SubMenuitemIcon=(string)Application.Current.Resources["IconSettings"]},
                      new SubMenuItem { SubMenuitemName = "Feedback",SubMenuitemIcon=(string)Application.Current.Resources["IconFeedback"]},
                      new SubMenuItem { SubMenuitemName = "Promote App",SubMenuitemIcon=(string)Application.Current.Resources["IconPromoteApp"]},
                      new SubMenuItem { SubMenuitemName = "About Us",SubMenuitemIcon=(string)Application.Current.Resources["IconAboutUs"]},
                      new SubMenuItem { SubMenuitemName = "Log Out",SubMenuitemIcon=(string)Application.Current.Resources["IconLogout"]},
                   },

                 };
            SeekerMenuItem = seekerMenuItems;
            
            ObservableCollection<DashboardMasterModel> recruiterMenuItems = new ObservableCollection<DashboardMasterModel>{
                new DashboardMasterModel((string)Application.Current.Resources["IconDashboard"],"Dashboard",0,false),
                new DashboardMasterModel((string)Application.Current.Resources["IconSearch"],"Search Candidate's",1,false),
                new DashboardMasterModel((string)Application.Current.Resources["IconShortListedCandidate"],"ShortListed Candidate's",2,false),
                new DashboardMasterModel((string)Application.Current.Resources["IconSelectedCandidate"],"Selected Candidate's",3,false),
                new DashboardMasterModel((string)Application.Current.Resources["IconRejectedCandidate"],"Rejected Candidate's",4,false),


                new DashboardMasterModel((string)Application.Current.Resources["IconSettings"],"More",5,true){
                      new SubMenuItem { SubMenuitemName = "FAQ's", SubMenuitemIcon=(string)Application.Current.Resources["IconFAQ"]},
                      new SubMenuItem { SubMenuitemName = "Settings",  SubMenuitemIcon=(string)Application.Current.Resources["IconSettings"]},
                      new SubMenuItem { SubMenuitemName = "Feedback",SubMenuitemIcon=(string)Application.Current.Resources["IconFeedback"]},
                      new SubMenuItem { SubMenuitemName = "Promote App",SubMenuitemIcon=(string)Application.Current.Resources["IconPromoteApp"]},
                      new SubMenuItem { SubMenuitemName = "About Us",SubMenuitemIcon=(string)Application.Current.Resources["IconAboutUs"]},
                      new SubMenuItem { SubMenuitemName = "Log Out",SubMenuitemIcon=(string)Application.Current.Resources["IconLogout"]},
                   },
               };
            RecruiterMenuItem = recruiterMenuItems;
            
        }
        
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

    }

    public class SubMenuItem
    {
        public string SubMenuitemName { get; set; }
        public string SubMenuitemIcon { get; set; }
    }


}
