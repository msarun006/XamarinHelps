﻿using SQLite;
using System.Collections.Generic;

namespace HireMe.Models.PRO_Assessment
{
    public class QuestionDetailsRequest
    {
        public string testpin { get; set; }
        public string login_audit_id { get; set; }
    }



    public class ExamQuestions
    {
        [PrimaryKey, AutoIncrement]
        public int examquestionid { get; set; }
        public int id { get; set; }
        public string company_id { get; set; }
        public string question_type { get; set; }
        public string pool_id { get; set; }
        public string topic_id { get; set; }
        public string question { get; set; }
        public string score { get; set; }
        public string negative_score { get; set; }
        public string section_name { get; set; }
        public string section_duration { get; set; }
        public string section_content { get; set; }
        public string section_count { get; set; }
        public string sno { get; set; }
        public string resume_point { get; set; }
        public string section_id { get; set; }
        public string IsMultipleOption { get; set; }
        public string section_sno { get; set; }
        public string question_palette_enum_Id { get; set; }
        public string last_elapsedtime_inSeconds { get; set; }
        public string last_elapsedtime { get; set; }
        public string is_question_mandatory { get; set; }
        public string is_subquestion { get; set; }
    }

    public class Exam_Question_Options
    {
        [PrimaryKey, AutoIncrement]
        public int examquestionoptionid { get; set; }
        public string id { get; set; }
        public string question_id { get; set; }
        public string options { get; set; }
        public string sub_question_id { get; set; }
    }

    public class Exam_Sub_Questions
    {
        [PrimaryKey, AutoIncrement]
        public int examsubquesionid { get; set; }
        public string subquestion_id { get; set; }
        public string question_id { get; set; }
        public string sub_question { get; set; }
        public string exam_answer { get; set; }
    }

    public class AssessmentAnswer
    {
        [PrimaryKey, AutoIncrement]
        public int answerid { get; set; }
        public string question_id { get; set; }
        public string sub_question_id { get; set; }
        public string exam_answer { get; set; }
    }

    public class QuestionDetailsResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public List<ExamQuestions> questions { get; set; }
        public List<Exam_Question_Options> questions_options { get; set; }
        public List<Exam_Sub_Questions> sub_questions { get; set; }
        public List<AssessmentAnswer> assessment_answer { get; set; }
    }

    //public class ExamQuestions
    //{
    //    public int id { get; set; }
    //    public string company_id { get; set; }
    //    public string question_type { get; set; }
    //  //  public string pool_id { get; set; }
    //  //  public string topic_id { get; set; }
    //    public string question { get; set; }
    //  //  public string score { get; set; }
    //   // public string negative_score { get; set; }
    //    public string section_name { get; set; }
    //    public string section_duration { get; set; }
    //    public string section_content { get; set; }
    //    public string section_count { get; set; }
    //    public string sno { get; set; }
    //    public string resume_point { get; set; }
    //    public string section_id { get; set; }
    //   // public string exam_answer { get; set; }
    //    public string IsMultipleOption { get; set; }
    //    public string Question_Palette_Enum_Id { get; set; }
    //    public bool is_Likert_type { get; set; }
    //    //public string question_group_id { get; set; }
    //    public string Last_ElapsedTime { get; set; }
    //    public string Last_ElapsedTime_inSeconds { get; set; }
    //    public string section_sno { get; set; }
    //}

    //public class Exam_Question_Options
    //{
    //    public string id { get; set; }
    //    public string score { get; set; }
    //    public string question_id { get; set; }
    //    public string options { get; set; }
    //    public string sub_question_id { get; set; }
    //    public string exam_answer { get; set; }
    //}

    //public class Exam_Sub_Questions
    //{
    //    public string question_id { get; set; }
    //    public string subquestion_id { get; set; }
    //    public string sub_question { get; set; }
    //    public string exam_answer { get; set; }

    //}

    //public class AssessmentAnswer
    //{
    //    public string question_id { get; set; }
    //    public string sub_question_id { get; set; }
    //    public string exam_answer { get; set; }
    
    //}
}