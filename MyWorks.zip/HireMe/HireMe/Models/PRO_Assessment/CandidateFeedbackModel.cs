﻿namespace HireMee.Models.PRO_Assessment
{
    public class CandidateFeedbackRequest
    {
        public string testpin { get; set; }
        public string feedback1 { get; set; }
        public string feedback2 { get; set; }
        public string feedback3 { get; set; }
        public string usercomments { get; set; }
        public string company_id { get; set; }
        public string assign_id { get; set; }
        public string login_audit_id { get; set; }
        public string candidate_id { get; set; }
    }
    public class CandidateFeedbackResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public string responseText { get; set; }
    }
}
