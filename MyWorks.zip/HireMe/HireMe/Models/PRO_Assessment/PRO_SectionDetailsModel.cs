﻿using SQLite;
using System.Collections.Generic;


namespace HireMe.Models.PRO_Assessment
{

    public class SectionDetailsRequest
    {
        public string testpin { get; set; }
        public string assign_id { get; set; }
        public string login_audit_id { get; set; }
    }

    public class SectionDetailsResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public List<SectionDetailsResponseData> responsedata { get; set; }
    }

    public class SectionDetailsResponseData
    {
        public string testpin { get; set; }
        public string company_id { get; set; }
        public string assign_id { get; set; }
        public string section_id { get; set; }
        public string login_audit_id { get; set; }
        public string id { get; set; }
        public string assessment_id { get; set; }
        public string question_type { get; set; }
        public string section_name { get; set; }
        public string name { get; set; }
        public string section_duration { get; set; }
        public List<SectionInstructionContent> content  { get; set; }
        public string section_count { get; set; }
        public string is_manual { get; set; }
        public string is_order_random { get; set; }
        public string is_option_random { get; set; }
        public string section_duration_in_secs { get; set; }
        public string Last_ElapsedTimeInSeconds { get; set; }
        public string timer { get; set; }
        public string section_status { get; set; }
        public string section_colour { get; set; }
    }



    public class SectionInstructionContent
    {
       
        public string section_content { get; set; }
        public string section_id { get; set; }
        public string section_count { get; set; }
        public string name { get; set; }
        public string section_duration { get; set; }
        public string  duration { get; set; }
        public bool isshow_instruction { get; set; }
        public string question_type { get; set; }

        public string section_status { get; set; }

    }


    public class tbl_timer
    {
        [PrimaryKey, AutoIncrement]
        public int ID { get; set; }
        public string section_id { get; set; }
        public string elapsed_time { get; set; }
        public string starttime { get; set; }
        public string endtime { get; set; }
        public string examstatus { get; set; }
        public string sectionname { get; set; }
        public string sectioncount { get; set; }
     public string   section_duration { get; set; }

    }

}
