﻿using MvvmHelpers;
using System.Collections.Generic;

namespace HireMee.Models.PRO_Assessment
{
    public class ResultResponseData:BaseViewModel
    {
        public string percentage { get; set; }

        public string _section_name;
        public string section_name 
        {
            get { return _section_name; }
            set { _section_name = value; OnPropertyChanged(); }
        }
        public string total_score { get; set; }
        public string overall_score { get; set; }

        private string _outof_score;
        public string outof_score
        {
            get { return _outof_score; }
            set { _outof_score = value; OnPropertyChanged(); }
        }

        public string _pool_name;
        public string pool_name
        {
            get { return _pool_name; }
            set { _pool_name = value; OnPropertyChanged(); }
        }

        public string _topic_name;
        public string topic_name
        {
            get { return _topic_name; }
            set { _topic_name = value; OnPropertyChanged(); }
        }

    }
    public class ResultResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public string testpin { get; set; }
        public string overall_score { get; set; }
        public string overall_percentage { get; set; }
        public string elapsed_time { get; set; }
        public string answered_question { get; set; }
        public string unanswered_question { get; set; }
        public string negative_mark { get; set; }
        public List<ResultResponseData> SectionResult { get; set; }
    }
    public class ResultRequestModel 
    {
        public string login_audit_id { get; set; }

        public string testpin { get; set; }
        //public int company_id { get; set; }
        public int assign_id { get; set; }
    }
}
