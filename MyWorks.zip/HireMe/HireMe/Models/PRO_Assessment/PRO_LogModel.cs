﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HireMe.Models.PRO_Assessment
{
    public class Navigation_LogRequestData
    {
        public string testpin { get; set; }
        public string company_id { get; set; }
        public string Login_audit_id { get; set; }
        public string assign_id { get; set; }
        public string navigation_mode { get; set; }

    }

    public class ImageProctored_LogRequestData
    {
        public string testpin { get; set; }
        public string company_id { get; set; }
        public string assign_id { get; set; }
        public string candidate_id { get; set; }
        public string s3_id { get; set; }
        public string login_audit_id { get; set; }
        public string is_trainingimage { get; set; }
        


    }

    public class HeartBeat_LogRequestData
    {
        public string testpin { get; set; }
        public string company_id { get; set; }
        public string assign_id { get; set; }
        public string section_id { get; set; }
        public string attempt_id { get; set; }
        public string login_audit_id { get; set; }
        public string elapse_time { get; set; }
        public string created_at { get; set; }
        public string Sectionstatus { get; set; }
        public string section_start_time { get; set; }
        public string section_end_time { get; set; }
    }

    public class Event_LogRequestData
    {
        public string test_pin { get; set; }
        public string company_id { get; set; }
        public string assign_id { get; set; }
        public string attempt_id { get; set; }
        public string section_id { get; set; }
        public string question_id { get; set; }
        public string exam_answer { get; set; }
        public string login_audit_id { get; set; }
        public string Question_Palette_Enum_Id { get; set; }
        public string Last_ElapsedTime { get; set; }
        public string Resume_point { get; set; }
        public string candidate_id { get; set; }
        public string question_type { get; set; }
        public List<Exam_Sub_Questions> subquestion { get; set; }
        public string Sectionstatus { get; set; }
        public string section_start_time { get; set; }
        public string section_end_time { get; set; }

    }
    public class Compatiablity_LogRequestData
    {
        public string testpin { get; set; }
        public string login_audit_id { get; set; }


    }

    public class LogResponseData
    {
        public string code { get; set; }
        public string message { get; set; }
        public int total_no_of_retries { get; set; }
        public int actual_no_of_retries { get; set; }
        
        //public object responseText { get; set; }
    }

}
