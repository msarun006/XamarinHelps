﻿using System;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace HireMe.Models.PRO_Assessment
{
    public class TestPinRequestData
    {
        public string testpin { get; set; }

        [JsonProperty(PropertyName = "os")]
        public string DeviceOS { get; set; }

        [JsonProperty(PropertyName = "udid")]
        public string DeviceID { get; set; }

        [JsonProperty(PropertyName = "mobile_model")]
        public string DeviceModel { get; set; }
        public string os_version { get; set; }
        public string mobile_brand { get; set; }

        [JsonProperty(PropertyName = "secret_key")]
        public string SecretKey { get; set; }

    }



    public class TestPinResponseData : SessionToken
    {
        public string code { get; set; }
        public string message { get; set; }
        public string company_name { get; set; }
        public string Last_ElapsedTime { get; set; }
        public string assessment_created_date { get; set; }
        public string Last_ElapsedTime_inSeconds { get; set; }
        public string last_updated_sectionid { get; set; }
        public string is_training_image_available { get; set; }
        public string s3_id_training_image { get; set; }
        
        public AssignedAssessmentDetails responseText { get; set; }
        public List<PRO_AWSCredentials> AWSCredential { get; set; }
    }

    public class PRO_AWSCredentials
    {
        public string aws_secretkey { get; set; }
        public string aws_accesskey { get; set; }
        public string buketname { get; set; }
        public string credential_type { get; set; }
    }

    public class AssignedAssessmentDetails
    {
        public string testpin { get; set; }
        public string company_id { get; set; }
        public string assign_id { get; set; }
        public string assessment_name { get; set; }
        public string syllabus { get; set; }
        public string exam_instruction { get; set; }
        public string mode { get; set; }
        public string duration_type { get; set; }
        public string exam_duration { get; set; }
        public string exam_duration_in_secs { get; set; }
        public string test_logo { get; set; }
        public string is_negative_mark { get; set; }
        public string redirect_url { get; set; }
        public string is_feedback { get; set; }
        public string is_score_display { get; set; }
        public string is_section_navigation { get; set; }
        public string is_question_pallete { get; set; }
        public string is_previous { get; set; }
        public string login_audit_id { get; set; }
        public string start_date { get; set; }
        public string end_date { get; set; }
        public string is_image_proctering { get; set; }
        public string is_window_proctering { get; set; }
        public string status { get; set; }
        public string attempt_id { get; set; }
        public string first_name { get; set; }
        public string last_name { get; set; }
        public string full_name { get; set; }
        public string email_id { get; set; }
        public string contact_no { get; set; }
        public string candidate_id { get; set; }
        public string total_no_sections { get; set; }
        public string total_no_questions { get; set; }
        public DateTime sever_time { get; set; }
        public string is_endtest { get; set; }
    }










}

