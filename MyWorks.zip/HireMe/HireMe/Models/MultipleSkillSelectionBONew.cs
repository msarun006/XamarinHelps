﻿using System;
using MvvmHelpers;
using SQLite;

namespace HireMe.DataLayer.Models
{
   public class MultipleSkillSelectionBO : BaseViewModel
    {
        [PrimaryKey, AutoIncrement]
        public string ID { get; set; }
        public string SearchName { get; set; }
        public string SkillID { get; set; }
        public string Title { get; set; }

		private bool isSelected;
        public bool IsSelected { 
			get { 
				MessageStringConstants.IsSearchComplete = true;
				return isSelected;
				

				}
			set { isSelected = value;

				 
				 MessageStringConstants.IsSearchComplete = true;
				 
				OnPropertyChanged(); }
		}
        public DateTime CreatedOn { get; set; }
        
    }
}
