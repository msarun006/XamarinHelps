﻿using Newtonsoft.Json;
using System.Collections.Generic;


namespace HireMe
{


	#region Course Response Data
	public class CollegeNameListDetails
	{
		[JsonProperty(PropertyName = "data")]
		public List<CollegeNameList> ResponseData { get; set; }
        
	}

	/// <summary>
	/// Course response data.
	/// </summary>
	public class CollegeNameListFullResponseData
	{
		[JsonProperty(PropertyName = "code")]
		public string code { get; set; }

		[JsonProperty(PropertyName = "message")]
		public string message { get; set; }

		[JsonProperty(PropertyName = "responseText")]
		public CollegeNameListDetails ResponseText { get; set; }
	}


	/// <summary>
	/// Course.
	/// </summary>
	public class CollegeNameList
	{
		//[JsonProperty(PropertyName = "college_id")]
		//public string ID { get; set; }

		//[JsonProperty(PropertyName = "college_name")]
		//public string Title { get; set; }

        [JsonProperty(PropertyName = "id")]
        public string ID { get; set; }

        [JsonProperty(PropertyName = "name")]
        public string Title { get; set; }
    }

#endregion


}