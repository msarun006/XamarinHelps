﻿using Newtonsoft.Json;

namespace HireMe.Models
{
    //public class BaseAPIRequestData
    //{


    //    //[JsonProperty(PropertyName = "token")]
    //    //public string Token { get; set; }

    //    [JsonProperty(PropertyName = "hiremee_id")]
    //    public string HireMeID { get; set; }

    //    [JsonProperty(PropertyName = "Token")]
    //    public string TokenID { get; set; }
    //    public string Refreshtoken { get; set; }
    //}


    //public class SessionToken : BaseAPIRequestData
    //{
    //    //[JsonProperty(PropertyName = "expire")]
    //    //public string Expire { get; set; }

    //    [JsonProperty(PropertyName = "Expire")]
    //    public string TokenExpiry { get; set; }

    //}


    //public class SessionToken 
    //{
    //    //[JsonProperty(PropertyName = "expire")]
    //    //public string Expire { get; set; }

    //    [JsonProperty(PropertyName = "Expire")]
    //    public string TokenExpiry { get; set; }

    //    [JsonProperty(PropertyName = "hiremee_id")]
    //    public string HireMeID { get; set; }

    //    [JsonProperty(PropertyName = "Token")]
    //    public string TokenID { get; set; }
    //    public string Refreshtoken { get; set; }
    //}
}
