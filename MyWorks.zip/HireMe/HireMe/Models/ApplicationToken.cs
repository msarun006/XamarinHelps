﻿using System;

namespace HireMe
{
    public class ApplicationToken
    {
        public string HireMeID { get; set; }
        public string Token { get; set; }
        public string UserType { get; set; }
        public DateTime Expire { get; set; }
        public string UserName { get; set; }
        public string EmailID { get; set; }
        public string MobileNo { get; set; }
        public bool SocialLoginPasswordStatus { get; set; }
        public string RefreshToken { get; set; }

    }

}
