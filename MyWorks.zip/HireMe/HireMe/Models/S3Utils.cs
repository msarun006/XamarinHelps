﻿using Acr.UserDialogs;
using Amazon.Runtime;
using Amazon.S3;
using HireMe.Helpers;
using HireMe.Models;
using System;
using System.Threading.Tasks;

namespace HireMe
{
    public class S3Utils
    {
        private static BasicAWSCredentials cognitoCredentials;
        private static IAmazonS3 s3Client;

        public static BasicAWSCredentials Credentials
        {
            get
            {
                if (cognitoCredentials == null)
                {
                    if (AppPreferences.Is_HireMee_PRO_User == true)
                    {

                        AppPreferences.S3AccessKeyID = AppPreferences.PRO_AWS_Credentials.aws_accesskey;
                        AppPreferences.S3SecretAccessKey = AppPreferences.PRO_AWS_Credentials.aws_secretkey;
                        cognitoCredentials = new BasicAWSCredentials(AppPreferences.S3AccessKeyID, AppPreferences.S3SecretAccessKey);
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(AppPreferences.S3AccessKeyID) && !string.IsNullOrEmpty(AppPreferences.S3SecretAccessKey))
                        {
                            cognitoCredentials = new BasicAWSCredentials(AppPreferences.S3AccessKeyID, AppPreferences.S3SecretAccessKey);
                        }
                    }
                }
                return cognitoCredentials;
            }
        }

        public static IAmazonS3 S3Client
        {
            get
            {
                if (AppPreferences.Is_HireMee_PRO_User == true)
                {
                    cognitoCredentials = null;
                    s3Client = new AmazonS3Client(Credentials, AmazonS3BucketDetails.REGION);
                }
                else
                {
                    if (s3Client == null && Credentials != null)
                    {
                        s3Client = new AmazonS3Client(Credentials, AmazonS3BucketDetails.REGION);
                    }
                }


                return s3Client;
            }
        }

        public async Task GetS3Credentials()
        {
            try
            {
                if (string.IsNullOrEmpty(AppPreferences.S3AccessKeyID))
                {
                    S3CredentialsRequestData objS3CredentialsRequest = new S3CredentialsRequestData();
                    objS3CredentialsRequest.S3CredentialsTypeID = AmazonS3BucketDetails.s3ResourceKey;

                    HttpCommonService _commonservice = new HttpCommonService();
                    var statusResult = await _commonservice.PostAsync<S3CredentialsResponseData, S3CredentialsRequestData>(APIData.API_BASE_URL + APIMethods.S3creidentails, objS3CredentialsRequest);

                    if (statusResult != null && statusResult.code == "200")
                    {
                        AppPreferences.S3AccessKeyID = statusResult.Response.S3AccessKeyid;
                        AppPreferences.S3SecretAccessKey = statusResult.Response.S3SecretAccesskey;
                    }
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "S3Utills.GetS3Credentials");
            }
        }

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
