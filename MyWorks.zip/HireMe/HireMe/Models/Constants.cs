﻿using HireMe.Models.Assessment;
using HireMe.Models.Recruiter;


namespace HireMe
{
    public class Constants
    {

        public class PromoteAppDetails
        {
            public static string PromoteSubject = "HireMee - Donwload Invitation Link";
            public static string AndroidPromoteURL = "https://play.google.com/store/apps/details?id=";
            public static string IOSPromoteURL = "https://appsto.re/in/Hdmkib.i";
        }

        public class VideoType
        {
            public static string AboutMeVideo = "AboutMeVideo";
            public static string MySkillsVideo = "SkillVideo";
            public static string MyInterestsVideo = "InterestsVideo";
        }

        public class FieldType
        {
            public static string City = "District";
            public static string State = "State";
            public static string University = "University";
            public static string College = "College";
            public static string CourseType = "CourseType";
            public static string Course = "Course";
            public static string Specialization = "Specialization";
            public static string Skill = "Skill";
            public static string PrimarySkill = "PrimarySkill";
            public static string SecondarySkill = "SecondarySkill";
            public static string Languages = "Languages";
            public static string BackLogs = "BackLogs";
            public static string YearOfCompletion = "Year Of Completion";
            public static string CollegeList = "College";
            public static string BoardName = "Board Name";
            public static string YearOfPassing = "Year Of Passing";
            public static string PreferredJobLocation = "Preferred Job Location";
            public static string CollegeName = "CollegeName";
            public static string Nationality = "Nationality";
            public static string AddEducation = "Add Education";
            public static string EditEducation = "Edit Education";
            public static string AddCertification = "Add your certification";
            public static string EditCertification = "Edit your certification";
            public static string SavedSearch = "Saved Search";
            public static string WorkType = "Work Type";
        }
    }



    public class VideoFileDetails
    {
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public string FileType { get; set; }
        public string ThumbnailImage { get; set; }
        public bool IsUploaded { get; set; }
        public string S3URLPath { get; set; }
        public int Status { get; set; }
        public string S3ThumbnailImage { get; set; }
        public string ReasonForBlocked { get; set; }
    }


    public static class Constant
    {
        //public static int AfterFifteenMinutesImageCaptureTimeDuration { get; set; } = 300;//sec
        //public static int MinuteToIncreaseImageCaptureTimeDuration { get; set; } = 15;
        //public static int NoOfAttempts { get; set; } = 3;
        //public static int DataSyncInterval { get; set; } = 300;//seconds
        //public static int BatteryPercentage { get; set; } = 30;
        public static int BeginFifteenMinutesImageCaptureTimeDuration { get; set; } = 20;//sec
        public static int PROImageCaptureTimeDuration { get; set; } = 60;//sec
        public static int BackgroundServiceCallingTimeInterval { get; set; } = 5;//min

        public static int heartbeatlogTimeInterval { get; set; } = 30;//sec


        public static bool heartbeatlogRunning { get; set; } = false;

        public static string IsImageProctoringOptionsShow { get; set; } = "1";
        public static string CapturedAssessmentFacialImageStatus { get; set; } = "0";
        //public static string ShowQuestionPallet { get; set; } = "1";
        //public static string HideQuestionPallet { get; set; } = "0";
        //public static string ShowPreviousButton { get; set; } = "1";
        //public static string HidePrevousButton { get; set; } = "0";
        //public static string ShowCameraPreview { get; set; } = "1";
        //public static string HideCameraPreview { get; set; } = "0";

        public static int MemorySize { get; set; } = 100;//MB
        public static int NotificationTriggeredInterval { get; set; } = 1800000;//1800000 = 30 min, 60000=1min
        public static double AutoQuestionNavigateDuration { get; set; } = 120.0;//seconds
        public static double FaceNotDedicationDuration { get; set; } = 60.0;//seconds
        public static bool IsSideMenuDashboard { get; set; } = false;
        public static int PRO_InstructionReadTiming { get; set; } = 10;//seconds
    }

    public static class AppSessionData
    {
        static AppSessionData() { }
        public static string AboutMeVideoStatus { get; set; }
        public static string SkillVideoStatus { get; set; }
        public static string InterestMeVideoStatus { get; set; }

        public static ApplicationToken ActiveToken { get { return AppPreferences.ActiveToken; } set { AppPreferences.ActiveToken = value; } }
        public static VideoFileDetails SkillVideo { get { return AppPreferences.SkillVideo; } set { AppPreferences.SkillVideo = value; } }
        public static VideoFileDetails AboutMeVideo { get { return AppPreferences.AboutMeVideo; } set { AppPreferences.AboutMeVideo = value; } }
        public static VideoFileDetails InterestsVideo { get { return AppPreferences.InterestVideo; } set { AppPreferences.InterestVideo = value; } }
        public static AvailableLanguage[] AvailableLanguage { get { return AppPreferences.AvailableLanguage; } set { AppPreferences.AvailableLanguage = value; } }
    }
    public enum ResourceTypeEnums
    {
        Documents,
        Photos,
        Videos
    }


    public enum IsMultipleOption
    {
        IS_Single_Slection,
        IS_Multi_Slection
    }
    


    public enum Is_image_proctering
    {
        Disable,
        Enable
    }

    public enum is_endtest
    {
        Disable,
        Enable
    }
    public enum Is_window_proctering
    {
        Disable,
        Enable
    }
    public enum is_previous
    {
        Disable,
        Enable
    }

    public enum is_question_pallete
    {
        Disable,
        Enable
    }

    public enum is_section_navigation
    {
        Disable,
        Enable
    }
    public enum is_score_display
    {
        Disable,
        Enable
    }
    public enum is_feedback
    {
        Disable,
        Enable
    }

    public enum duration_type
    {
        NoTimer,
        ExamDuration,
        SectionDuration
    }


    public enum mode
    {
        None,
        Web,
        Mobile,
        WebAndMobile
    }

    public enum question_type
    {
        None,
        MCQ,
        Behaviour,
        Situation_Reaction,
        likert,
    }

    public enum Question_Palette_Enum_Id
    {
        NotViewed,
        Answered,
        NotAnswered,
        MarkForReview
    }
}
