﻿using HireMe.Models;
using Newtonsoft.Json;

namespace HireMe
{
    public class ProfileScoreData
	{
		public int ID { get; set; }
		public string HiremeeID { get; set; }
		public string PersonalDetails { get; set; }
		public string EducationalDetails { get; set; }
		public string Video { get; set; }
		public string Resume { get; set; }
		public string ProfilePic { get; set; }
	}

	public class ProfileScoreResponseText : TokenRequestData
	{
		[JsonProperty(PropertyName="data")]
		public ProfileScoreData ProfileScoreData { get; set; }
	}

	public class ProfileScoreResponse
	{
		public string code { get; set; }
		public string message { get; set; }
		public ProfileScoreResponseText responseText { get; set; }
	}
}
