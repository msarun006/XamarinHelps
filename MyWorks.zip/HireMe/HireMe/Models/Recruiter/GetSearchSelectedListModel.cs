﻿using Newtonsoft.Json;
using System.Collections.Generic;
using Xamarin.Forms;

namespace HireMe.Models.Recruiter
{



    public class GetSearchSelectedListUser
	{
		public int id { get; set; }
		public string hiremee_id { get; set; }
		public string fullname { get; set; }
		public string lastname { get; set; }
		public int profileviewer { get; set; }
	}

	public class GetSearchSelectedListAssessment
	{
		public string hiremee_id { get; set; }
		public int verbalaptitude { get; set; }
		public int quantitativeaptitude { get; set; }
		public int logicalreasoning { get; set; }
		public int technicalcomputerfundamental { get; set; }
		public int personality { get; set; }
		public int communication { get; set; }
		public int technicalcoredomain { get; set; }
		public int interpersonalcompetencies { get; set; }
		public int personalcompetencies { get; set; }
		public int emotionalcompetencies { get; set; }
		public int motivationalcompetencies { get; set; }
		public int intellectualorientation { get; set; }
		public int totalscore { get; set; }
	}

	public class GetSearchSelectedListResponseData
	{
		public int id { get; set; }
		public int search_id { get; set; }
		public int jobposting_id { get; set; }
		public string hiremee_id { get; set; }
		public string recruiter_hiremee_id { get; set; }
		public string is_selected { get; set; }
		public string selected_date_time { get; set; }
		public int mail_history_id { get; set; }
		public string is_mailsent { get; set; }
		public int hiredbycompany { get; set; }
		public string hired_date { get; set; }
		public string mail_sent_date { get; set; }
		public string status { get; set; }
		public string accepted_by_student { get; set; }
		public string created_at { get; set; }
		public string updated_at { get; set; }
		public List<Video> video { get; set; }

		private Image _image;
		public Image image
		{
			get
			{

				return _image;
			}

			set
			{
				if (value != null)
				{
					_image = value;


				}
				else
				{
					_image = new Image();
					_image.S3_ID = (string)Application.Current.Resources["IconUser"]; ;
					//_image.S3_ID = string.Empty;

				}
			}
		}
		public Education education { get; set; }
		public User user { get; set; }
		public Assessment assessment { get; set; }
	}


    public class User
    {
        public int id { get; set; }
        public string hiremee_id { get; set; }
        public string fullname { get; set; }
        public string lastname { get; set; }
    }

    public class Image
    {
        public string hiremee_id { get; set; }
        // public string s3_id { get; set; }

        private string _s3ID;
        [JsonProperty(PropertyName = "s3_id")]
        public string S3_ID
        {
            get
            {
                return (string.IsNullOrEmpty(_s3ID) ? "user.png" : _s3ID);
            }
            set { _s3ID = value; }
        }
    }
    public class Coursetype
    {
        public int id { get; set; }
        public string name { get; set; }
    }
    public class Education
    {
        public int id { get; set; }
        public string hiremee_id { get; set; }
        public int cousre_id { get; set; }
        public int specialization_id { get; set; }
        public int coursetype_id { get; set; }
        public int education_level { get; set; }
        public string board { get; set; }
        public string school_name { get; set; }
        public string college_id { get; set; }
        public string university_id { get; set; }
        public string yearofcompletion { get; set; }
        public string cgpa { get; set; }
        public string percentage { get; set; }
        public string skill_id { get; set; }
        public string job_location_id { get; set; }
        public string status { get; set; }

        private int _backlog;
        public int backlog
        {
            get { return _backlog; }
            set
            {
                if (value != null)
                {
                    _backlog = value;


                }
                else
                {
                    _backlog = 0;
                }
            }
        }
        public string zipcode { get; set; }
        public string updated_at { get; set; }
        public string created_at { get; set; }
        public int is_sync { get; set; }
        public Course course { get; set; }
        public College college { get; set; }
        public Coursetype coursetype { get; set; }
        public Specialization specialization { get; set; }
        public University university { get; set; }
    }


    public class GetSearchSelectedListResponse
	{
		public string code { get; set; }
		public string message { get; set; }
		public List<GetSearchSelectedListResponseData> response { get; set; }
	}
}
