﻿using System.Collections.Generic;

namespace HireMe.Models.Recruiter
{




    public class RejectionSearchNameResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public RejectionSearchNameResponseData responseText { get; set; }
    }

    public class RejectionSearchNameResponseData
    {
        public string Message { get; set; }
        public List<RejectionSearchData> Data { get; set; }
    }

    public class RejectionSearchData
    {
        public string search_id { get; set; }
        public string Search_critria { get; set; }
    }

    //public class RejectionSearchNameResponseData
    //{
    //    public string Message { get; set; }
    //    public string Search_id { get; set; }
    //    public string Search_critria { get; set; }
    //    public object Advance_search_critria { get; set; }
    //}


    








}
