﻿using System;

namespace HireMe.Models.Recruiter
{
    public  class MultipleJobLocationSelectionModel
    {
       
        public int ID { get; set; }
        public string SearchName { get; set; }
        public string YearID { get; set; }
        public string Title { get; set; }
        public bool IsSelected { get; set; }
        public DateTime CreatedOn { get; set; }
    }
}
