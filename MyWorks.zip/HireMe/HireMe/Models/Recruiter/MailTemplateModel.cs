﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace HireMe.Models.Recruiter
{
    public class TemplateRecruiterListRequestData : BaseRequestDTO
    {
    }


    public class TemplateRecruiterListResponseData
    {

        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public TemplateRecruiterListResponse Response { get; set; }
    }

    public class TemplateRecruiterListResponse
    {

        [JsonProperty(PropertyName = "emailtemplate")]
        public List<Emailtemplate> EmailTemplates { get; set; }


    }

    public class Emailtemplate
    {
        [JsonProperty(PropertyName = "id")]
        public string ID { get; set; }
        [JsonProperty(PropertyName = "title")]
        public string Title { get; set; }
    }

}
