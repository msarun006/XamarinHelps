﻿using HireMe.Services;
using Newtonsoft.Json;
using Xamarin.Forms;

namespace HireMe.Models.Recruiter
{

    #region RejectedCandidate Request Data
    public class RejectedCandidateRequestData : BaseRequestDTO
    {
        public string search_id { get; set; }
    }
    #endregion

    #region RejectedCandidate Response Data
    public class RejectedCandidateEntireResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public Responsetext responseText { get; set; }
    }

    public class Responsetext
    {
        public object Message { get; set; }
        public string searchId { get; set; }
        public string searchname { get; set; }
        public Searchdetail[] SearchDetails { get; set; }
    }

    public class Searchdetail
    {
        public string candidateid { get; set; }
        public string search_id { get; set; }
        public Profiledetails profiledetails { get; set; }
        public Certification[] certifications { get; set; }
        public Prefer_Job_Location[] prefer_job_location { get; set; }
        public Selected selected { get; set; }
        public Edcuactionaldetails edcuactionaldetails { get; set; }

        private Profilepic _profilePic;
        public Profilepic profilePic
        {
            get
            {

                return _profilePic;
            }

            set
            {
                if (value != null)
                {
                    _profilePic = value;


                }
                else
                {
                    _profilePic = new Profilepic();
                    _profilePic.S3_ID = (string)Application.Current.Resources["IconUser"]; ;
                    //_image.S3_ID = string.Empty;

                }
            }
        }






        public Ambition ambition { get; set; }
        public Aboutmyself aboutmyself { get; set; }
        public Skill skill { get; set; }
        public Assessment assessment { get; set; }
    }

    public class Profiledetails
    {
        public string fullname { get; set; }
        public string email_verified { get; set; }
        public string mobile_verified { get; set; }
        public string candidate_disablity { get; set; }
    }

    public class Edcuactionaldetails
    {
        public string cousetype { get; set; }
        public string coursename { get; set; }
        public string universityname { get; set; }
        public string collegename { get; set; }
        public string mspecializationname { get; set; }
        public string yearofcompletion { get; set; }
        public string skills { get; set; }
        public string cgpa { get; set; }
        public string percentage { get; set; }
    }
    



    public class Profilepic
    {

        private string _s3ID;
        [JsonProperty(PropertyName = "s3_id")]
        public string S3_ID
        {
            get
            {
                return (string.IsNullOrEmpty(_s3ID) ? "user.png" : S3Manager.GeneratePreSignedURL(AmazonS3BucketDetails.PhotoBucket, _s3ID, 3));
            }
            set { _s3ID = value; }
        }



        public string resourceurl { get; set; }
        public string thumbnailurl { get; set; }
    }

    public class Ambition
    {
        public string s3_id { get; set; }
        public string resourceurl { get; set; }
        public string thumbnailurl { get; set; }
    }

    public class Aboutmyself
    {
        public string s3_id { get; set; }
        public string resourceurl { get; set; }
        public string thumbnailurl { get; set; }
    }

    public class Assessment
    {
        public string verbalaptitude { get; set; }
        public string quantitativeaptitude { get; set; }
        public string logicalreasoning { get; set; }
        public string technicalcomputerfundamental { get; set; }
        public string communication { get; set; }
        public string technicalcoredomain { get; set; }
        public string interpersonalcompetencies { get; set; }
        public string personalcompetencies { get; set; }
        public string emotionalcompetencies { get; set; }
        public string motivationalcompetencies { get; set; }
        public string intellectualorientation { get; set; }
    }

    public class Certification
    {
        public string certification_name { get; set; }
        public string certification_year { get; set; }
    }

    public class Prefer_Job_Location
    {
        public string prefer_job_location_id { get; set; }
        public string prefer_job_location { get; set; }
    }


    #endregion
}
