﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace HireMe.Models.Recruiter
{
    public class SearchHistoryResponseData
    {
        public string code { get; set; }
        public string message { get; set; }
        public HistoryResponseData responseText { get; set; }
    }

    public class HistoryResponseData
    {
        public string Message { get; set; }
        public List<SearchHistoryData> Data { get; set; }
    }

    public class SearchHistoryData
    {
        [JsonProperty(PropertyName = "search_id")]
        public int SearchID { get; set; }

        [JsonProperty(PropertyName = "Search_critria")]
        public string SearchCritria { get; set; }
    }
}
