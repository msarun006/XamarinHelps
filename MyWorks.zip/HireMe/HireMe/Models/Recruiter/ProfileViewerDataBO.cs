﻿using Newtonsoft.Json;

namespace HireMe.Models.Recruiter
{
    #region ProfileViewer Request Data
    public class ProfileViewerRequestData : BaseRequestDTO
    {
    
        public string candidate_hiremee_id { get; set; }
        public string search_id { get; set; }

    }
    #endregion


    public class ProfileViewerResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }

    }
}
