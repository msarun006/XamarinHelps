﻿using HireMe.Models;
using Newtonsoft.Json;

namespace HireMe
{
    public class RecruiterDashboardModel : BaseRequestDTO
    {

    }


    public class RecruiterProfiledetails
    {
        [JsonProperty(PropertyName = "hiremee_id")]
        public string HireMeeID { get; set; }

        [JsonProperty(PropertyName = "fullname")]
        public string FullName { get; set; }

        [JsonProperty(PropertyName = "email_address")]
        public string EmailAddress { get; set; }

        [JsonProperty(PropertyName = "mobile_number")]
        public string MobileNumber { get; set; }

        [JsonProperty(PropertyName = "aadhaar_number")]
        public string AadharNumber { get; set; }

        [JsonProperty(PropertyName = "date_of_birth")]
        public string Dateofbirth { get; set; }

        [JsonProperty(PropertyName = "gender")]
        public string Gender { get; set; }

        [JsonProperty(PropertyName = "company_name")]
        public string CompanyName { get; set; }
       

        [JsonProperty(PropertyName = "current_state")]
        public State State { get; set; }

        [JsonProperty(PropertyName = "current_city")]
        public District City { get; set; }

        [JsonProperty(PropertyName = "districtid")]
        public string DistrictID { get; set; }

        [JsonProperty(PropertyName = "stateid")]
        public string StateID { get; set; }

        [JsonProperty(PropertyName = "district")]
        public string DistrictName { get; set; }

        [JsonProperty(PropertyName = "state")]
        public string StateName { get; set; }


        [JsonProperty(PropertyName = "user_type")]
        public string IsAdmin { get; set; }
        //private string _isAdmin;
        //
        //public string IsAdmin
        //{
        //    get { return _isAdmin; }
        //    set {
        //        if(value)
        //        _isAdmin = value;
        //    }
        //}


    }

    public class RecruiterProfileweightage
    {

        [JsonProperty(PropertyName = "personaldetails")]
        public string PersonalDetails { get; set; }

        [JsonProperty(PropertyName = "companyname")]
        public string CompanyName { get; set; }

        [JsonProperty(PropertyName = "profilepic")]
        public string ProfilePic { get; set; }
        
        public string CareerPage { get; set; }
        public string profilevideo { get; set; }
        public string TotalWeightage { get; set; }

    }

    public class RecruiterUserresources
    {
        [JsonProperty(PropertyName = "hiremee_id")]
        public string HireMeeID { get; set; }

        [JsonProperty(PropertyName = "s3_id")]
        public string S3_ID { get; set; }

        [JsonProperty(PropertyName = "resourceurl")]
        public string ResourceURL { get; set; }

        [JsonProperty(PropertyName = "resourcetype_id")]
        public string ResourceTypeID { get; set; }

        [JsonProperty(PropertyName = "thumbnailurl")]
        public string ThumbnailURL { get; set; }

        [JsonProperty(PropertyName = "status")]
        public string Status { get; set; }
    }

    public class Recruiterdashboard
    {
        private int _searchTotal;

        [JsonProperty(PropertyName = "searchHistoryTotal")]
        public string SearchHistoryTotal { get; set; }

        [JsonProperty(PropertyName = "candidateselectionTotal")]
        public string CandidateSelectionTotal { get; set; }

        [JsonProperty(PropertyName = "candidaterejectionTotal")]
        public string CandidateRejectionTotal { get; set; }

        [JsonProperty(PropertyName = "invitedprofiles")]
        public string InvitedProfiles { get; set; }

        public string candidatehired { get; set; }
        public string totaljobposting { get; set; }
        public string closedjobs { get; set; }
        public string activejobs { get; set; }


    }

    public class RecruiterDashboardResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }

        public Appversioncheck apiVersionCheck { get; set; }

        [JsonProperty(PropertyName = "profiledetails")]
        public RecruiterProfiledetails RecruiterPersonalDetails { get; set; }

        [JsonProperty(PropertyName = "profileweightage")]
        public RecruiterProfileweightage RecruiterProfileCompletePercentage { get; set; }

        [JsonProperty(PropertyName = "userresources")]
        public RecruiterUserresources RecruiterProfilePicture { get; set; }

        [JsonProperty(PropertyName = "recruiterdashboare")]
        public Recruiterdashboard RecruiterDashboardDetails { get; set; }
    }

}
