﻿namespace HireMe.Models.Recruiter
{
    class RecruiterSearchResultModel
    {
    }
}
