﻿namespace HireMe.Models.Recruiter
{
    public class SelectionSearchListResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public ResponseData responseText { get; set; }
    }

    public class ResponseData
    {
        public object Message { get; set; }
        public SearchData[] Data { get; set; }
    }

    public class SearchData
    {
        public string search_id { get; set; }
        public string Search_critria { get; set; }
    }
}
