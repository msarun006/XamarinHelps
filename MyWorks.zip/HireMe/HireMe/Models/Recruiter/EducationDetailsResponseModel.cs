﻿using MvvmHelpers;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace HireMe.Models.Recruiter
{


    public class CandidateEducationRequest
    {
        [JsonProperty(PropertyName = "hiremee_id")]
        public string Candidate_HireMeeID { get; set; }
    }


    public class EducationalDetailsEntrieResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public EducationalDetailsResponseData responseText { get; set; }
    }

    public class EducationalDetailsResponseData
    {
        public Educational_Details[] educational_details { get; set; }
        public string AssessFlag { get; set; }
        public ObservableCollection<CertificationDetails> certifications { get; set; }
        public string Others { get; set; }
        public SkillOthers skill_others { get; set; }
        public List<Skill> Primaryskills { get; set; }
        public List<Skill> Secondaryskills { get; set; }

    }


    public class SkillOthers : BaseViewModel
    {
        private string _skill_name;
        public string skill_name
        {
            get { return _skill_name; }
            set { _skill_name = value; OnPropertyChanged(); }
        }

        public string temp_skill_id { get; set; }
    }


    public class CertificationDetails
    {
        public string certificate_id { get; set; }
        public string certification_name { get; set; }
        public string certification_year { get; set; }
    }

    public class Educational_Details
    {
        public string hiremee_id { get; set; }
        public string coursetype_id { get; set; }
        public string course_type_name { get; set; }
        public string course_id { get; set; }
        public string course_name { get; set; }
        public string specialization_id { get; set; }
        public string specialization_name { get; set; }
        public string educational_level { get; set; }
        public string board_id { get; set; }
        public string board_name { get; set; }
        public string school_name { get; set; }
        public string college_id { get; set; }
        public string college_name { get; set; }
        public string university_id { get; set; }
        public string university_name { get; set; }
        public string year_of_completion { get; set; }
        public string cgpa { get; set; }
        public string percentage { get; set; }
        public string backlog { get; set; }
        public string zip_code { get; set; }
        public string registerNo { get; set; }
        public string statename { get; set; } 
        public string stateid { get; set; }
        public string cityname { get; set; }
        public string cityid { get; set; }
        public string DisplayCourseTypeName { get; set; }
        public string DisplayBoardNameOrUniversityName { get; set; }
        public string DisplaySchoolNameOrCollegeName { get; set; }
        public string DisplayCGPAOrPercentage { get; set; }
        public string DisplayYearOfPassing { get; set; }
        public string city_id { get; set; }
        public string city_name { get; set; }
        public string state_id { get; set; }
        public string state_name { get; set; }
    }

}
