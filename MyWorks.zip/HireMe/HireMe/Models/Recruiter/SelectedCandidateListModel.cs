﻿using HireMe.Services;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.ComponentModel;
using Xamarin.Forms;

namespace HireMe.Models.Recruiter
{

    /// <summary>
    /// Filter request.
    /// </summary>
    public class FilterRequest : BaseRequestDTO
    {
        [JsonProperty(PropertyName = "search_id")]
        public string SearchID { get; set; }
    }

    /// <summary>
    /// Entire SelectedCandidatelist Response data.
    /// </summary>
    public class SelectedCandidatelistResponse
    {
      
        public string code { get; set; }


        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public SelectedCandidatelistResponseData ResponseText { get; set; }
    }

    
    /// <summary>
    /// Edcuactionaldetails.
    /// </summary>
    public class EducationalDetails
    {
        [JsonProperty(PropertyName = "cousetype")]
        public string CourseType { get; set; }

        [JsonProperty(PropertyName = "coursename")]
        public string CourseName { get; set; }

        [JsonProperty(PropertyName = "universityname")]
        public string UniversityName { get; set; }

        [JsonProperty(PropertyName = "collegename")]
        public string CollegeName { get; set; }

        [JsonProperty(PropertyName = "mspecializationname")]
        public string mSpecializationName { get; set; }
        [JsonProperty(PropertyName = "skills")]
        public string Skills { get; set; }

        [JsonProperty(PropertyName = "cgpa")]
        public string CGPA { get; set; }

        [JsonProperty(PropertyName = "percentage")]
        public string Percentage { get; set; }
        [JsonProperty(PropertyName = "yearofcompletion")]
        public string YearOfCompletion { get; set; }
    }


    public class Video
    {
        [JsonProperty(PropertyName = "aboutmyself")]
        public string AboutMySelf { get; set; }

        [JsonProperty(PropertyName = "skill")]
        public string Skill { get; set; }

        [JsonProperty(PropertyName = "ambition")]
        public string Ambition { get; set; }
    }

    public class Resume
    {

        [JsonProperty(PropertyName = "s3_id")]
        public string S3_ID { get; set; }


        [JsonProperty(PropertyName = "resourceurl")]
        public string Resourceurl { get; set; }

    }


    /// <summary>
    /// Profile picture.
    /// </summary>
    public class ProfilePicture
    {
        private string _s3ID;
        [JsonProperty(PropertyName = "s3_id")]
        public string S3_ID
        {
            get
            {
                return (string.IsNullOrEmpty(_s3ID) ? "user.png" : S3Manager.GeneratePreSignedURL(AmazonS3BucketDetails.PhotoBucket, _s3ID, 3));
            }
            set { _s3ID = value; }
        }
        [JsonProperty(PropertyName = "resourceurl")]
        [DefaultValue("")]
        public string ResourceUrl
        {
            get; set;

        }
    }




    public class SelectedCandidatelistResponseData
    {
        [JsonProperty(PropertyName = "searchDetails")]
        public RecruitersearchBO[] Data { get; set; }
    }

    public class RecruitersearchBO : INotifyPropertyChanged
    {
        [JsonProperty(PropertyName = "candidateid")]
        public string candidateID { get; set; }

        [JsonProperty(PropertyName = "search_id")]
        public int searchId { get; set; }

        [JsonProperty(PropertyName = "profiledetails")]
        public CandidateDetails profileDetails { get; set; }
        [JsonProperty(PropertyName = "edcuactionaldetails")]
        public EducationalDetails educationalDetails { get; set; }

        public List<PreferJobLocation> prefer_job_location { get; set; }
        public List<CertificationsData> certifications { get; set; }

        [JsonProperty(PropertyName = "resume")]
        public string resume { get; set; }
        private ProfilePicture _profilePicture;
        [JsonProperty(PropertyName = "profilePic")]
        public ProfilePicture ProfilePicture
        {
            get
            {

                return _profilePicture;
            }

            set
            {
                if (value != null)
                {
                    _profilePicture = value;


                }
                else
                {
                    _profilePicture = new ProfilePicture();
                    _profilePicture.S3_ID = (string)Application.Current.Resources["IconUser"]; ;
                    //_profilePicture.S3_ID = string.Empty;

                }
            }
        }
        [JsonProperty(PropertyName = "aboutmyself")]
        public AboutMeVideo AboutMeVideoDetails { get; set; }
        [JsonProperty(PropertyName = "skill")]
        public SkillVideo SkillVideoDetails { get; set; }
        [JsonProperty(PropertyName = "ambition")]
        public AmbitionVideo AmbitionVideoDetails { get; set; }

        private Selected _selected;

        public Selected selected
        {
            get
            {
                return _selected;
            }
            set
            {
                _selected = value;
                if (_selected.IsSelected > 0)
                {
                    if (_selected.isselectedbythis > 0)
                    {
                        IsBtnDisablePropery = true;
                    }
                    else
                    {
                        IsBtnDisablePropery = false;
                    }
                    if (_selected.IsHired > 0)
                    {
                        IsSelectedLabelVisiblePropery = false;
                        IsHiredLabelVisiblePropery = true;
                    }
                    else
                    {
                        IsSelectedLabelVisiblePropery = true;
                        IsHiredLabelVisiblePropery = false;
                    }
                }
                //BackgroundColor = Color.Beige;
                else
                {
                    IsSelectedLabelVisiblePropery = false;
                    IsHiredLabelVisiblePropery = false;
                    //BackgroundColor = Color.Black;
                }


            }
        }




        public Assessment assessment { get; set; }



        public bool IsSelectedLabelVisiblePropery { get; set; }
        public bool IsHiredLabelVisiblePropery { get; set; }

        public bool IsBtnDisablePropery { get; set; }


        #region INotifyPropertyChanged
        bool isSelected = false;
        public bool IsSelected
        {
            get
            {
                return isSelected;
            }
            set
            {
                if (isSelected != value)
                {
                    isSelected = value;
                    PropertyChanged(this, new PropertyChangedEventArgs("IsSelected"));

                }
            }
        }
        public event PropertyChangedEventHandler PropertyChanged = delegate { };

        #endregion
    }


    public class CertificationsData
    {
        public string certification_name { get; set; }
        public string certification_year { get; set; }
    }

    public class PreferJobLocation
    {
        public int prefer_job_location_id { get; set; }
        public string prefer_job_location { get; set; }
    }           
    public class CandidateDetails
    {
        [JsonProperty(PropertyName = "fullname")]
        public string FullName { get; set; }

        [JsonProperty(PropertyName = "candidate_disablity")]
        public string  CandidateDisablity { get; set; }
        
    }



    public class AboutMeVideo
    {
        [JsonProperty(PropertyName = "resourceurl")]
        public string ResourceURL { get; set; }
        [JsonProperty(PropertyName = "thumbnailurl")]
        public string ThumbnailURL { get; set; }
        [JsonProperty(PropertyName = "s3_id")]
        public string S3ID { get; set; }
    }

    public class SkillVideo
    {
        [JsonProperty(PropertyName = "resourceurl")]
        public string ResourceURL { get; set; }
        [JsonProperty(PropertyName = "thumbnailurl")]
        public string ThumbnailURL { get; set; }
        [JsonProperty(PropertyName = "s3_id")]
        public string S3ID { get; set; }
    }
    public class AmbitionVideo
    {
        [JsonProperty(PropertyName = "resourceurl")]
        public string ResourceURL { get; set; }
        [JsonProperty(PropertyName = "thumbnailurl")]
        public string ThumbnailURL { get; set; }
        [JsonProperty(PropertyName = "s3_id")]
        public string S3ID { get; set; }
    }


   






    public class Selected
    {
        [JsonProperty(PropertyName = "isselected")]

        public int IsSelected
        {
            get;

            set;
        }

        public int isselectedbythis { get; set; }
        [JsonProperty(PropertyName = "ishired")]
        public int IsHired { get; set; }
    }





}
