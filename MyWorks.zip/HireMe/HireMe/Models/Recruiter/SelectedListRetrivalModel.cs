﻿using HireMe.Models.Recruiter;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.ComponentModel;

namespace HireMe.Models
{
    #region SelectedListRetrival Request Data
    public class SelectedListRetrivalRequestData : BaseRequestDTO
    {

        [JsonProperty(PropertyName = "search_id")]
        public string SearchID { get; set; }

    }

    #endregion

    public class Listed : INotifyPropertyChanged
    {

        [JsonProperty(PropertyName = "is_mailsent")]
        string mailSent;




        #region INotifyPropertyChanged
        [JsonProperty(PropertyName = "is_selected")]
        string isSelected;

        public event PropertyChangedEventHandler PropertyChanged = delegate { };

        #endregion

    }

    public class SelectionListDataBO : INotifyPropertyChanged
    {

        [JsonProperty(PropertyName = "candidateid")]
        public string CandidateId { get; set; }

        [JsonProperty(PropertyName = "profiledetails")]
        public JobSeekerProfileDetails ProfileDetails { get; set; }

        [JsonProperty(PropertyName = "listed")]
        public Listed Listed { get; set; }

        [JsonProperty(PropertyName = "edcuactionaldetails")]
        public EducationalDetails EdcuactionalDetails { get; set; }

        [JsonProperty(PropertyName = "resume")]
        public Resume Resume { get; set; }

        [JsonProperty(PropertyName = "profilePic")]
        public ProfilePicture ProfilePic { get; set; }

        [JsonProperty(PropertyName = "video")]
        public Video Video { get; set; }

        bool isSelected;
        public bool IsSelected
        {
            get
            {
                return isSelected;
            }
            set
            {
                if (isSelected != value)
                {
                    isSelected = value;
                    PropertyChanged(this, new PropertyChangedEventArgs("IsSelected"));
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged = delegate { };
    }

    public class SelectedListRetrivalDetails
    {
        [JsonProperty(PropertyName = "data")]
        public List<SelectionListDataBO> data { get; set; }
    }

    public class SelectedListRetrivalResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string Code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string Message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public SelectedListRetrivalDetails Response { get; set; }
    }
}
