﻿using SQLite;
using System;

namespace HireMe.Models.Recruiter
{
    public class ProfileViewerCountBO
    {
        [PrimaryKey, AutoIncrement]
        public int ID { get; set; }
        public string CandidateID { get; set; }
        public string SearchID { get; set; }
        public bool IsViewed { get; set; }
        public DateTime CreatedOn { get; set; }

    }
}
