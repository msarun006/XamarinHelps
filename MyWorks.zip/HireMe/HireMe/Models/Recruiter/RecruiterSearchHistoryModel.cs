﻿using System.Collections.Generic;


namespace HireMe.Models.Recruiter
{
    public class SelectionListResponseText
    {
        public List<SearchDetailBO> data { get; set; }
    }

    public class SelectionListResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public SelectionListResponseText responseText { get; set; }
    }

    public class RecentSearchFullResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public List<SearchDetailBO> responseText { get; set; }
    }




   

}
