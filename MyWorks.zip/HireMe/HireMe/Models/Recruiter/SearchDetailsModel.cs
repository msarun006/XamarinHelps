﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace HireMe.Models.Recruiter
{
    public class SearchDetailRequestData : BaseRequestDTO, INotifyPropertyChanged
    {
        public SearchDetailRequestData()
        {
            EnglishScoreValue = "0,9";
            QuantitativeScoreValue = "0,9";
            LogicalScoreValue = "0,9";
            AptitudeScoreValue = "0,9";
            CommunicationScoreValue = "0,9";
            TechnicalScoreValue = "0,9";
            InterpersonalCompetencies = "0,9";
            PersonalCompetencies = "0,9";
            Emotionalcompetencies = "0,9";
            MotivationalCompetencies = "0,9";
            Intellectualorientation = "0,9";
        }

        [JsonProperty(PropertyName = "course_id")]
        public string CourseID { get; set; }

        [JsonProperty(PropertyName = "state")]
        public string StateID { get; set; }

        [JsonProperty(PropertyName = "city")]
        public string CityID { get; set; }

        [JsonProperty(PropertyName = "designation")]
        public string Designation { get; set; }


        [JsonProperty(PropertyName = "regcollege_id")]
        public string CollegeID { get; set; }

        [JsonProperty(PropertyName = "course_type_id")]
        public string CourseType { get; set; }

        [JsonProperty(PropertyName = "specialization_id")]
        public string SpecializationID { get; set; }

        [JsonProperty(PropertyName = "skill_id")]
        public string SkillID { get; set; }

        [JsonProperty(PropertyName = "year_of_completion")]
        public string YearOfCompletion { get; set; }

        [JsonProperty(PropertyName = "job_location")]
        public string JobLocation { get; set; }

        [JsonProperty(PropertyName = "search_name")]
        public string SearchName { get; set; }

        private string _EnglishScoreValue;
        [DefaultValue(1.0)]
        [JsonProperty(PropertyName = "verbalaptitude", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string EnglishScoreValue
        {
            get
            {
                return _EnglishScoreValue;
            }
            set
            {
                if (_EnglishScoreValue != value)
                {
                    _EnglishScoreValue = value;
                    RaisePropertyChanged();
                }
            }
        }

        private string _QuantitativeScoreValue;
        [DefaultValue(1.0)]
        [JsonProperty(PropertyName = "quantitativeaptitude", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string QuantitativeScoreValue
        {
            get
            {
                return _QuantitativeScoreValue;
            }
            set
            {
                if (_QuantitativeScoreValue != value)
                {
                    _QuantitativeScoreValue = value;
                    RaisePropertyChanged();
                }
            }
        }

        private string _LogicalScoreValue;
        [DefaultValue(1.0)]
        [JsonProperty(PropertyName = "logicalreasoning", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string LogicalScoreValue
        {
            get
            {
                return _LogicalScoreValue;
            }
            set
            {
                if (_LogicalScoreValue != value)
                {
                    _LogicalScoreValue = value;
                    RaisePropertyChanged();
                }
            }
        }

        private string _AptitudeScoreValue;
        [DefaultValue(1.0)]

        [JsonProperty(PropertyName = "technicalcomputerfundamental", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string AptitudeScoreValue
        {
            get
            {
                return _AptitudeScoreValue;
            }
            set
            {
                if (_AptitudeScoreValue != value)
                {
                    _AptitudeScoreValue = value;
                    RaisePropertyChanged();
                }
            }
        }
        private string _interpersonalcompetencies;
        [DefaultValue(1.0)]
        [JsonProperty(PropertyName = "interpersonalcompetencies", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string InterpersonalCompetencies
        {
            get
            {
                return _interpersonalcompetencies;
            }
            set
            {
                if (_interpersonalcompetencies != value)
                {
                    _interpersonalcompetencies = value;
                    RaisePropertyChanged();
                }
            }
        }

        private string _personalcompetencies;
        [DefaultValue(1.0)]
        [JsonProperty(PropertyName = "personalcompetencies", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string PersonalCompetencies
        {
            get
            {
                return _personalcompetencies;
            }
            set
            {
                if (_personalcompetencies != value)
                {
                    _personalcompetencies = value;
                    RaisePropertyChanged();
                }
            }

        }


        private string _emotionalcompetencies;
        [DefaultValue(1.0)]
        [JsonProperty(PropertyName = "emotionalcompetencies", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string Emotionalcompetencies
        {
            get
            {
                return _emotionalcompetencies;
            }
            set
            {
                if (_emotionalcompetencies != value)
                {
                    _emotionalcompetencies = value;
                    RaisePropertyChanged();
                }
            }
        }


        private string _motivationalcompetencies;
        [DefaultValue(1.0)]
        [JsonProperty(PropertyName = "motivationalcompetencies", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string MotivationalCompetencies
        {
            get
            {
                return _motivationalcompetencies;
            }
            set
            {
                if (_motivationalcompetencies != value)
                {
                    _motivationalcompetencies = value;
                    RaisePropertyChanged();
                }
            }
        }


        private string _intellectualorientation;
        [DefaultValue(1.0)]
        [JsonProperty(PropertyName = "intellectualorientation", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string Intellectualorientation
        {
            get
            {
                return _intellectualorientation;
            }
            set
            {
                if (_intellectualorientation != value)
                {
                    _intellectualorientation = value;
                    RaisePropertyChanged();
                }
            }
        }
        private string _CommunicationScoreValue;
        [DefaultValue(1.0)]
        [JsonProperty(PropertyName = "communication", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string CommunicationScoreValue
        {
            get
            {
                return _CommunicationScoreValue;
            }
            set
            {
                if (_CommunicationScoreValue != value)
                {
                    _CommunicationScoreValue = value;
                    RaisePropertyChanged();
                }
            }
        }

        private string _TechnicalScoreValue;
        [DefaultValue(1.0)]
        [JsonProperty(PropertyName = "technicalcoredomain", DefaultValueHandling = DefaultValueHandling.Populate)]
        public string TechnicalScoreValue
        {
            get
            {
                return _TechnicalScoreValue;
            }
            set
            {
                if (_TechnicalScoreValue != value)
                {
                    _TechnicalScoreValue = value;
                    RaisePropertyChanged();
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged = delegate { };
        private void RaisePropertyChanged([CallerMemberName] string propName = "")
        {
            if (!string.IsNullOrEmpty(propName))
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propName));
            }
        }
    }
    public class SearchDetailBO
    {
        [JsonProperty(PropertyName = "Search_id")]
        public int SearchID { get; set; }

        [JsonProperty(PropertyName = "Search_critria")]
        public string SearchCritria { get; set; }
    }

    public class SearchDetailData
    {
        [JsonProperty(PropertyName = "data")]
        public SearchDetailBO SearchDetail { get; set; }
    }
    /// <summary>
    /// Search detail response.
    /// </summary>
    public class SearchDetailResponse : NotifiyBase
    {
        public string code { get; set; }
        public string message { get; set; }

        private SearchResponseText _searchDetails;
        [JsonProperty(PropertyName = "responseText")]
        public SearchResponseText SearchDetailData
        {
            get { return _searchDetails; }
            set
            {
                _searchDetails = value;
                RaisePropertyChanged();
            }
        }
    }



    public class SearchResponseText
    {
        public int searchId { get; set; }
        public string searchname { get; set; }

        public List<RecruitersearchBO> searchDetails
        {
            get; set;
        }

    }









    #region Company Full Details Request Data
    public class RecentSearchListItemClickedRequestData : BaseRequestDTO
    {
        [JsonProperty(PropertyName = "search_id")]
        public string SearchId { get; set; }

    }
    #endregion



    #region Hired Request CadidateData

    public class HiredCandidateRequestData : RecentSearchListItemClickedRequestData
    {
        [JsonProperty(PropertyName = "candidate_hiremee_id")]
        public string CandidateID { get; set; }
    }
    #endregion





}
