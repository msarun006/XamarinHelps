﻿using Newtonsoft.Json;

namespace HireMe.Models.Recruiter
{

    #region RecruiterProfileDetails Request Data
    /// <summary>
    /// Recruiter profile details request data.
    /// </summary>
    public class UpdateRecruiterProfileRequestData : BaseRequestDTO
    {
        [JsonProperty(PropertyName = "fullname")]
        public string FullName { get; set; }

        [JsonProperty(PropertyName = "email_address")]
        public string EmailAddress { get; set; }

        [JsonProperty(PropertyName = "mobile_number")]
        public string MobileNumber { get; set; }

        [JsonProperty(PropertyName = "state")]
        public string StateID { get; set; }

        [JsonProperty(PropertyName = "city")]
        public string CityID { get; set; }

        [JsonProperty(PropertyName = "company_name")]
        public string CompanyName { get; set; }
    }

    #endregion

    #region RecruiterProfileDetails Response Data
    /// <summary>
    /// Recruiter profile data.
    /// </summary>
    public class RecruiterProfileData : BaseRequestDTO
    {
    }

    /// <summary>
    /// Recruiter profile details response data.
    /// </summary>
    public class UpdateRecruiterProfileResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public RecruiterProfileData Response { get; set; }
    }




    #endregion
}
