﻿using Newtonsoft.Json;

namespace HireMe.Models.Recruiter
{
    public class VideoBlockRequest : BaseRequestDTO
    {

        [JsonProperty(PropertyName = "candidate_hiremee_id")]
        public string CandidateHireMeeIDs { get; set; }


        [JsonProperty(PropertyName = "resourcetype_id")]
        public string resourcetype_id { get; set; }


        [JsonProperty(PropertyName = "abuse_reason")]
        public string abuse_reason { get; set; }

    }
    public class VideoBlockRespense
    {
        public string code { get; set; }
        public string message { get; set; }
        public string responseText { get; set; }
    }
}
