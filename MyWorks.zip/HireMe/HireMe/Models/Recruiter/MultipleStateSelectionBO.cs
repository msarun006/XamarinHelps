﻿using SQLite;
using System;

namespace HireMe.Models.Recruiter
{
    public class MultipleStateSelectionBO
    {
        [PrimaryKey, AutoIncrement]
        public int ID { get; set; }
        public string SearchName { get; set; }
        public string StateID { get; set; }
        public string Title { get; set; }
        public bool IsSelected { get; set; }
        public DateTime CreatedOn { get; set; }
    }
}
