﻿using MvvmHelpers;

namespace HireMe
{
    public class RecruiterSearchVideoProfileModel : BaseViewModel
	{

		private string searchtitle;
		 public string SearchTitle
		{
			get { return searchtitle;}
			set { searchtitle = value; OnPropertyChanged();}
		}
		private string designation;
		public string DesignationText
		{
			get { return designation; }
			set { designation = value; OnPropertyChanged();}
		}

		private string collegeName;
		public string CollegeName
		{
			get { return collegeName; }
			set { collegeName = value; OnPropertyChanged();}
		}

		private string coursetype;
		public string CourseType
		{
			get { return coursetype;}
			set { coursetype = value; OnPropertyChanged();}
		}

        private string _state;
        public string State
        {
            get { return _state; }
            set { _state = value; OnPropertyChanged(); }
        }

        private string _city;
        public string City
        {
            get { return _city; }
            set { _city = value; OnPropertyChanged(); }
        }

        private string coursename;
		public string CourseName
		{
			get { return coursename;}
			set { coursename = value; OnPropertyChanged();}
		}
		private string specialization;
		public string Specialization
		{
			get { return specialization;}
			set { specialization = value; OnPropertyChanged();}
		}
		private string skill;
		public string Skill
		{
			get { return skill;}
			set { skill = value; OnPropertyChanged();}
		}
		private string yearOfCompletion;
		public string YearOfCompletion
		{
			get { return yearOfCompletion;}
			set { yearOfCompletion = value; OnPropertyChanged();}
		}
        private string jobLocations;
        public string JobLocations
        {
            get { return jobLocations; }
            set { jobLocations = value; OnPropertyChanged(); }
        }

        private string jobLocationID;
        public string JobLocationID
        {
            get { return jobLocationID; }
            set { jobLocationID = value; OnPropertyChanged(); }
        }

        private string stateID;
        public string StateID
        {
            get { return stateID; }
            set { stateID = value; OnPropertyChanged(); }
        }

        private string _cityID;
        public string CityID
        {
            get { return _cityID; }
            set { _cityID = value; OnPropertyChanged(); }
        }
    }
}
