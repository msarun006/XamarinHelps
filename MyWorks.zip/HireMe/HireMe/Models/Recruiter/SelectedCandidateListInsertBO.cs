﻿using Newtonsoft.Json;

namespace HireMe.Models.Recruiter
{
    #region SelectedCandidateListInsert Request Data

    /// <summary>
    /// Selected candidate list insert request data.
    /// </summary>
    public class SelectedCandidateListInsertRequestData : BaseRequestDTO
    {


        [JsonProperty(PropertyName = "candidate_hiremee_id")]
        public string CandidateHiremeeID { get; set; }

        [JsonProperty(PropertyName = "search_id")]
        public string SearchId { get; set; }

        [JsonProperty(PropertyName = "searchname")]
        public string SearchName { get; set; }

        [JsonProperty(PropertyName = "is_selected")]
        public string IsSelected { get; set; }
    }

    #endregion

    #region SelectedCandidateListInsert Response Data

    /// <summary>
    /// Selected candidate list insert response data.
    /// </summary>
    public class SelectedCandidateListInsertResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public string ResponseText { get; set; }

    }




    #endregion
}
