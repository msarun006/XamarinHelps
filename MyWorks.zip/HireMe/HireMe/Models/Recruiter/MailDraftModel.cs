﻿using Newtonsoft.Json;

namespace HireMe.Models.Recruiter
{
    public class MailtoSelectedCandidatesRequestData : BaseRequestDTO
    {
        [JsonProperty(PropertyName = "search_id")]
        public string SearchID { get; set; }

        [JsonProperty(PropertyName = "mailtemplate")]
        public string MailTemplate { get; set; }

        [JsonProperty(PropertyName = "candidate_hiremee_id")]
        public string CandidateHireMeeIDs { get; set; }

        [JsonProperty(PropertyName = "subject")]
        public string Subject { get; set; }

        [JsonProperty(PropertyName = "anylink")]
        public string AnyLink { get; set; }

        [JsonProperty(PropertyName = "interviewdate")]
        public string InterviewDate { get; set; }

        [JsonProperty(PropertyName = "interviewlocation")]
        public string InterviewLocation { get; set; }

        [JsonProperty(PropertyName = "interviewtime")]
        public string InterviewTime { get; set; }

    }


    public class PreviewtoSelectedCandidatesResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public PreviewtoSelectedCandidatesResponse Response { get; set; }
    }

    public class PreviewtoSelectedCandidatesResponse
    {
        [JsonProperty(PropertyName = "mailcontent")]
        public string Mailcontent { get; set; }
    }


    public class MailSelectedCandidatesResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public string ResponseText { get; set; }
    }
}
