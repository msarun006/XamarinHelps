﻿using Newtonsoft.Json;

namespace HireMe.Models.Recruiter
{
    #region RecruiterProfileDetailsRetrival Request Data
    public class RecruiterProfileDetailsRetrivalRequestData : BaseRequestDTO
    {
    }

    #endregion

    #region RecruiterProfileDetailsRetrival Response Data

    /// <summary>
    /// Recruiter profile details.
    /// </summary>
    public class RecruiterProfileDetails : RecruiterProfileDetailsRetrivalRequestData
    {

        [JsonProperty(PropertyName = "fullname")]
        public string FullName { get; set; }

        [JsonProperty(PropertyName = "email_address")]
        public string EmailAddress { get; set; }

        [JsonProperty(PropertyName = "mobile_number")]
        public string MobileNumber { get; set; }

        [JsonProperty(PropertyName = "gender")]
        public string Gender { get; set; }

        [JsonProperty(PropertyName = "aadhar_number")]
        public string AadharNumber { get; set; }

        [JsonProperty(PropertyName = "current_state")]
        public State State { get; set; }

        [JsonProperty(PropertyName = "current_city")]
        public District City { get; set; }

        [JsonProperty(PropertyName = "date_of_birth")]
        public string DateOfBirth { get; set; }

        [JsonProperty(PropertyName = "company_name")]
        public string CompanyName { get; set; }
    }


    /// <summary>
    /// Recruiter profile details retrival response data.
    /// </summary>
    public class RecruiterProfileDetailsRetrivalResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public RecruiterProfileDetails Response { get; set; }
    }




    #endregion

}
