﻿namespace HireMe.Models
{
    public enum ResourceType
    {
        Resume = 1,
        ProfilePic = 2,
        CompanyPic = 6,
        AboutMe = 3,
        Skill = 4,
        Interest = 5,
        IdCard=10

    }

}
