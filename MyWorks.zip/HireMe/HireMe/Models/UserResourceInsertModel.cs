﻿using Newtonsoft.Json;

namespace HireMe.Models
{

    #region UserResourceInsert Request Data
    public class UserResourceInsertRequestData : BaseRequestDTO
    {
        [JsonProperty(PropertyName = "resourcetype_id")]
        public string ResourceTypeId { get; set; }

        [JsonProperty(PropertyName = "s3_id")]
        public string s3Id { get; set; }

        [JsonProperty(PropertyName = "resourceurl")]
        public string ResourceUrl { get; set; }

        [JsonProperty(PropertyName = "thumbnailurl")]
        public string ThumbnailUrl { get; set; }

    }

    #endregion

    #region UserResourceInsert Response Data
    public class UserResourceInsert : BaseRequestDTO
    {
        [JsonProperty(PropertyName = "expire")]
        public string Expire { get; set; }
    }

    public class UserResourceInsertResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public UserResourceInsert Response { get; set; }
    }
    #endregion

}
