﻿namespace HireMe.Models.JobSeeker
{
    public class UserEmailUpdateModel
    {

        public string token { get; set; }
        public string hiremee_id { get; set; }
        public string email_address { get; set; }

    }

    public class UserEmailUpdateResponseValue
    {
        public string email_address { get; set; }
        public int register_id { get; set; }
        public int resend { get; set; }
        public string message { get; set; }
        public string otp { get; set; }

    }




    public class UserEmailUpdateResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public UserEmailUpdateResponseValue responseText { get; set; }
    }

}
