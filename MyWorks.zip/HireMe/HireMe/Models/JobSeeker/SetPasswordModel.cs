﻿namespace HireMe.Models.JobSeeker
{


    public class SetPasswordRequestData
    {
        public string register_id { get; set; }
        public string password { get; set; }
        public string udid { get; set; }
        public string devos { get; set; }
        public string devmodel { get; set; }

    }



    public class SetPasswordResponseData
    {
        public string code { get; set; }
        public string message { get; set; }
        public string response { get; set; }
    }
}
