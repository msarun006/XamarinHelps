﻿using System.Collections.Generic;

namespace HireMe.Models.JobSeeker
{
    public class ResponseData
    {
        public string id { get; set; }
        public string board_name { get; set; }
    }

    public class BoardNameResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public List<ResponseData> response { get; set; }
    }
}
