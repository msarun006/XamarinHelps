﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace HireMe.Models.JobSeeker
{

    #region UserResourceType Request Data
    public class UserResourceTypeRequestData : BaseRequestDTO
    {

    }

    #endregion

    #region UserResourceType Response Data
    public class UserResourceTypeResponseDetails : UserResourceTypeRequestData
    {
        [JsonProperty(PropertyName = "data")]
        public List<UserResourceType> Response { get; set; }

    }

    public class UserResourceTypeResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string Code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string Message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public UserResourceTypeResponseDetails Response { get; set; }
    }

    public class UserResourceType
    {
        [JsonProperty(PropertyName = "id")]
        public string ID { get; set; }


        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }
    }


    #endregion
}
