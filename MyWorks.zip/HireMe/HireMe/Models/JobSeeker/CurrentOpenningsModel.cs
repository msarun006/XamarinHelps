﻿using HireMe.Services;
using MvvmHelpers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace HireMe.Models.JobSeeker
{
    #region Current Openings
    public class CurrentOpeningsResponseData : BaseViewModel
    {
        public string JobPostingId { get; set; }
        public string job_title { get; set; }
        public string industry_name { get; set; }
        public string skills { get; set; }
        public string last_date { get; set; }
        public string companyname { get; set; }
        public string qualification { get; set; }
        public string location { get; set; }
        public string description { get; set; }
        public string numberofpostion { get; set; }
        public string AppliedStatus { get; set; }
        public object PreferredSkills { get; set; }
        public object Gender { get; set; }
        public object EmpType { get; set; }
        public object MandatoryQualification { get; set; }
        public object job_working_days { get; set; }
        public object job_working_off { get; set; }
        public object CTC { get; set; }
        public object other_requirements { get; set; }
        private string _s3ID;
        public bool isNOImage { get; set; }
        [JsonProperty(PropertyName = "CompanyS3Id")]
        public string s3ID
        {
            get { return _s3ID; }
            set
            {

                if (isNOImage)
                {
                    _s3ID = value;
                }
                else
                {

                    if (!string.IsNullOrEmpty(value))
                    {
                        _s3ID = S3Manager.GeneratePreSignedURL(AmazonS3BucketDetails.CompanyLogoBucket, value, 5);
                    }
                    else
                    {
                        _s3ID = (string)Application.Current.Resources["NoImageAvailable"];
                    }
                }
                OnPropertyChanged();
            }
        }
        private string _txtJobApply;

        public string txtJobApply
        {
            get { return "  " + _txtJobApply + "  "; }
            set { _txtJobApply = value; }
        }
    }

    public class CurrentOpeningsResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public List<CurrentOpeningsResponseData> currentOpenings { get; set; }
    }
    public class CurrentOpeningsRequest : BaseRequestDTO
    {
        public string candidateHiremeeId { get; set; }
        public string commaSeperatedSkillId { get; set; }
        public string companyName { get; set; }
    }
    #endregion



    #region Get search job details
    public class SearchJobsResponseData : BaseViewModel
    {
        public string JobPostingId { get; set; }
       // public string job_title { get; set; }



        private string _job_title;

        public string job_title
        {
            get { return  _job_title; }
            set { _job_title = value; OnPropertyChanged(); }
        }

        public string industry_name { get; set; }
       // public string skills { get; set; }



        private string _skills;

        public string skills
        {
            get { return _skills; }
            set { _skills = value; }
        }



        public string last_date { get; set; }
        public string companyname { get; set; }
        public string qualification { get; set; }
        public string location { get; set; }
        public string description { get; set; }
        public string numberofpostion { get; set; }
        private string _s3ID;
        public bool isNOImage { get; set; }
        [JsonProperty(PropertyName = "CompanyS3Id")]
        public string s3ID
        {
            get { return _s3ID; }
            set
            {

                if (isNOImage)
                {
                    _s3ID = value;
                }
                else
                {

                    if (!string.IsNullOrEmpty(value))
                    {
                        _s3ID = S3Manager.GeneratePreSignedURL(AmazonS3BucketDetails.CompanyLogoBucket, value, 5);
                    }
                    else
                    {
                        _s3ID = (string)Application.Current.Resources["NoImageAvailable"];
                    }
                }
                OnPropertyChanged();
            }
        }
        public string AppliedStatus { get; set; }
        public string PreferredSkills { get; set; }
        public string Gender { get; set; }
        public string EmpType { get; set; }
        public string MandatoryQualification { get; set; }
        public string job_working_days { get; set; }
        public string job_working_off { get; set; }
        public string CTC { get; set; }
        public string other_requirements { get; set; }
        private string _txtJobApply;

        public string txtJobApply
        {
            get { return "  "+_txtJobApply+"  "; }
            set { _txtJobApply = value; }
        }
    }

    public class SearchJobsResponse
    {
        public string Code { get; set; }
        public string Message { get; set; }
        public List<SearchJobsResponseData> SearchJobs { get; set; }
    }

    public class SearchJobsRequest
    {
        public string CandidateHiremeeID { get; set; }
        public string SkillId { get; set; }
        public string Location { get; set; }
        public string CompanyName { get; set; }
        public string WorkType { get; set; }
        public string SearchJobHistoryID { get; set; }
    }
    #endregion


    #region Get Recommended job model class
    public class RecommendedJobResponseData : BaseViewModel
    {
        public string JobPostingId { get; set; }
        public string job_title { get; set; }
        public string industry_name { get; set; }
        public string companyname { get; set; }
        public string qualification { get; set; }
        public string location { get; set; }
        public string numberofpostion { get; set; }
        public string description { get; set; }
        public string last_date { get; set; }

        private string _s3ID;
        public bool isNOImage { get; set; }
        [JsonProperty(PropertyName = "CompanyS3Id")]
        public string s3ID
        {
            get { return _s3ID; }
            set
            {

                if (isNOImage)
                {
                    _s3ID = value;
                }
                else
                {

                    if (!string.IsNullOrEmpty(value))
                    {
                        _s3ID = S3Manager.GeneratePreSignedURL(AmazonS3BucketDetails.CompanyLogoBucket, value, 5);
                    }
                    else
                    {
                        _s3ID = (string)Application.Current.Resources["NoImageAvailable"];
                    }
                }
                OnPropertyChanged();
            }
        }
        public string AppliedStatus { get; set; }
        public string Skills { get; set; }
        private string _txtJobApply;

        public string txtJobApply
        {
            get { return "  " + _txtJobApply + "  "; }
            set { _txtJobApply = value; }
        }
    }

    public class RecommendedJobResponse
    {
        public string Code { get; set; }
        public string Message { get; set; }
        public List<RecommendedJobResponseData> RecommendedJobs { get; set; }
    }

    public class RecommendedJobsRequest
    {
        public string CandidateHiremeeId { get; set; }
        public string CommaSeperatedSecondarySkillId { get; set; }
        public string CompanyName { get; set; }
    }
    #endregion

    #region Saved Search Response

    public class SavedSearchJobResponseData
    {
        public int id { get; set; }
        public string search_name { get; set; }
    }

    public class SavedSearchJobResponse
    {
        public string Code { get; set; }
        public string Message { get; set; }
        public List<SavedSearchJobResponseData> SavedSearchJobs { get; set; }
    }
    public class SavedSearchRequest
    {
        public string CandidateHiremeeID { get; set; }
    }
    #endregion



    #region Load Work Type List
    public class WorkTypeResponseData
    {
        public int id { get; set; }
        public string type_name { get; set; }
    }

    public class WorkTypeResponse
    {
        public string Code { get; set; }
        public string Message { get; set; }
        public List<WorkTypeResponseData> EmployeeWorkTypeList { get; set; }
    }
    public class WorkTypeRequest : BaseRequestDTO
    {

    } 
    #endregion

}
