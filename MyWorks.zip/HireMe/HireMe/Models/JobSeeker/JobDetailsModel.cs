﻿using HireMe.Services;
using MvvmHelpers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace HireMe.Models.JobSeeker
{


    #region Get job full Details
    public class JobDetailsResponseData:BaseViewModel
    {
        public string JobPostingId { get; set; }
        public string job_title { get; set; }
        public string industry_name { get; set; }
        public string skills { get; set; }
        public string last_date { get; set; }
        public string companyname { get; set; }
        public string qualification { get; set; }
        public string location { get; set; }
        public string description { get; set; }
        public string numberofpostion { get; set; }
       // public string CompanyS3Id { get; set; }
        private string _s3ID;
        public bool isNOImage { get; set; }
        [JsonProperty(PropertyName = "CompanyS3Id")]
        public string s3ID
        {
            get { return _s3ID; }
            set
            {

                if (isNOImage)
                {
                    _s3ID = value;
                }
                else
                {

                    if (!string.IsNullOrEmpty(value))
                    {
                        _s3ID = S3Manager.GeneratePreSignedURL(AmazonS3BucketDetails.CompanyLogoBucket, value, 5);
                    }
                    else
                    {
                        _s3ID = (string)Application.Current.Resources["NoImageAvailable"];
                    }
                }
                OnPropertyChanged();
            }
        }
        public string AppliedStatus { get; set; }
        public string PreferredSkills { get; set; }
        public string Gender { get; set; }
        public string EmpType { get; set; }
        public string MandatoryQualification { get; set; }
        public string job_working_days { get; set; }
        public string job_working_off { get; set; }
        public string CTC { get; set; }
        public string other_requirements { get; set; }
        public string salary_from { get; set; }
        public string salary_to { get; set; }
        public string walkin_from { get; set; }
        public string walkin_to { get; set; }
        public string start_time { get; set; }
        public string to_time { get; set; }
        public string interview_slots { get; set; }



    }

    public class Language : BaseViewModel
    {
        public string lang_id { get; set; }
        public string languages { get; set; }
        public string proficiency { get; set; }
        public string speak { get; set; }
        public string read { get; set; }
        public string write { get; set; }

        private bool _isSpeak=false;
        public bool isSpeak
        {
            get { return _isSpeak; }
            set { _isSpeak = value; OnPropertyChanged(); }
        }
        private bool _isRead=false;
        public bool isRead
        {
            get { return _isRead; }
            set { _isRead = value; OnPropertyChanged(); }
        }

        private bool _isWrite=false;
        public bool isWrite
        {
            get { return _isWrite; }
            set { _isWrite = value; OnPropertyChanged(); }
        }

    }

    public class Qualification
    {
        public string course_id { get; set; }
        public string specialization_id { get; set; }
        public string CourseName { get; set; }
        public string SpecilizationName { get; set; }
    }

    public class JobDetailsResponse
    {
        public string Code { get; set; }
        public string Message { get; set; }
        public JobDetailsResponseData CommonJobDetails { get; set; }
        public List<Language> Languages { get; set; }
        public List<Qualification> Qualification { get; set; }
        public List<Venue> Venues { get; set; }
    }
    public class Venue
    {
        public string Address { get; set; }
    }
    public class JobDetailsRequest : BaseRequestDTO
    {
        public string CandidateHiremeeID { get; set; }
        public string JobPostingId { get; set; }

    }
    #endregion

    #region Apply Job
    public class ApplyJobRequest : BaseRequestDTO
    {
        public string jobPostingId { get; set; }
        public string seekerHiremeeId { get; set; }
        public string status { get; set; }
    }

    public class ApplyJobResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public string responseText { get; set; }
    } 
    #endregion

}
