﻿using Newtonsoft.Json;

namespace HireMe.Models.JobSeeker
{
    class JobSeekerVideoProfileModel
    {
    }
    #region UserResourceConfig Request Data
    public class UserResourceConfigRequestData : BaseRequestDTO
    {

    }

    #endregion

    #region UserResourceConfig Response Data
    public class UserResourceConfig
    {

        [JsonProperty(PropertyName = "aboutmyself")]
        public AboutMyselfData AboutMyself { get; set; }

        [JsonProperty(PropertyName = "skill")]
        public SkillData Skill { get; set; }

        [JsonProperty(PropertyName = "ambition")]
        public AmbitionData Ambition { get; set; }


    }
    public class AboutMyselfData
    {

        [JsonProperty(PropertyName = "maxRecordtime")]
        public string MaxRecordTime { get; set; }

        [JsonProperty(PropertyName = "minRecordtime")]
        public string MinRecordTime { get; set; }

        [JsonProperty(PropertyName = "maxResolution")]
        public string MaxResolution { get; set; }

        [JsonProperty(PropertyName = "minResolution")]
        public string MinResolution { get; set; }

        [JsonProperty(PropertyName = "maxFilesize")]
        public string MaxFilesize { get; set; }
        [JsonProperty(PropertyName = "compressquality")]
        public string CompressQuality { get; set; }
        [JsonProperty(PropertyName = "videoquality")]
        public string VideoQuality { get; set; }

    }
    public class SkillData
    {
        [JsonProperty(PropertyName = "maxRecordtime")]
        public string MaxRecordTime { get; set; }

        [JsonProperty(PropertyName = "minRecordtime")]
        public string MinRecordTime { get; set; }

        [JsonProperty(PropertyName = "maxResolution")]
        public string MaxResolution { get; set; }

        [JsonProperty(PropertyName = "minResolution")]
        public string MinResolution { get; set; }

        [JsonProperty(PropertyName = "maxFilesize")]
        public string MaxFilesize { get; set; }
        [JsonProperty(PropertyName = "compressquality")]
        public string CompressQuality { get; set; }
        [JsonProperty(PropertyName = "videoquality")]
        public string VideoQuality { get; set; }

    }
    public class AmbitionData
    {
        [JsonProperty(PropertyName = "maxRecordtime")]
        public string MaxRecordTime { get; set; }

        [JsonProperty(PropertyName = "minRecordtime")]
        public string MinRecordTime { get; set; }

        [JsonProperty(PropertyName = "maxResolution")]
        public string MaxResolution { get; set; }

        [JsonProperty(PropertyName = "minResolution")]
        public string MinResolution { get; set; }

        [JsonProperty(PropertyName = "maxFilesize")]
        public string MaxFilesize { get; set; }
        [JsonProperty(PropertyName = "compressquality")]
        public string CompressQuality { get; set; }
        [JsonProperty(PropertyName = "videoquality")]
        public string VideoQuality { get; set; }

    }

    public class UserResourceConfigResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string Code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string Message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public UserResourceConfig Response { get; set; }
    }

    #endregion
}
