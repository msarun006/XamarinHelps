﻿using Newtonsoft.Json;

namespace HireMe.Models.JobSeeker
{
    public class CheckMobileNumberResponse
    {

        public string code { get; set; }
        public string message { get; set; }
        public string verified { get; set; }
        public string responseText { get; set; }

    }

    public class CheckMobileNumberRequest : BaseRequestDTO
    {
        [JsonProperty(PropertyName = "mobile_number")]
        public string MobileNumber { get; set; }

        [JsonProperty(PropertyName = "aadhar_number")]
        public string AadharNumber { get; set; }

        [JsonProperty(PropertyName = "passport_number")]
        public string PassportNumber { get; set; }

        
             [JsonProperty(PropertyName = "panNo")]
        public string PANNumber { get; set; }


        [JsonProperty(PropertyName = "email_address")]
        public string EmailAddressStratus { get; set; }
        
    }
}
