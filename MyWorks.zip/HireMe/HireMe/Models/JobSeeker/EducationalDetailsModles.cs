﻿using Newtonsoft.Json;

namespace HireMe.Models.JobSeeker
{

  
    #region ProfileDetails Request Data
    public class SkillUpdateRequest : BaseRequestDTO
    {

        [JsonProperty(PropertyName = "skill_id")]
        public string SkillID { get; set; }

        [JsonProperty(PropertyName = "skill_name")]
        public string Others_Skill { get; set; }

        [JsonProperty(PropertyName = "skill_type")]
        public string SkillType { get; set; }

        [JsonProperty(PropertyName = "temp_skill_id")]
        public string Other_SkillID { get; set; }
    }
    #endregion

    #region EducaionalDetailsResponseData

    public class EducaionalDetailsResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public SchoolEducationRequest Response { get; set; }
    }
    #endregion

    #region SchoolEducationDetails
    public class SchoolEducationRequest: BaseRequestDTO
    {
        [JsonProperty(PropertyName = "course_type_id")]
        public string SchoolCourseTypeID { get; set; }

        [JsonProperty(PropertyName = "board_type_id")]
        public string SchoolBoardTypeID { get; set; }

        [JsonProperty(PropertyName = "school_name")]
        public string SchoolName { get; set; }

        [JsonProperty(PropertyName = "zip_code")]
        public string SchoolZipCode { get; set; }

        [JsonProperty(PropertyName = "percentage")]
        public string SchoolPercentage { get; set; }

        [JsonProperty(PropertyName = "year_of_passing")]
        public string schoolYearOfPassing { get; set; }
        public string registerNo { get; set; }
    }
    #endregion

    #region College Education Detials
    public class CollegeEducationDetailsRequest : BaseRequestDTO
    {
        [JsonProperty(PropertyName = "university_id")]
        public string UniversityID { get; set; }

        [JsonProperty(PropertyName = "college_id")]
        public string CollegeID { get; set; }

        [JsonProperty(PropertyName = "zip_code")]
        public string Zipcode { get; set; }

        [JsonProperty(PropertyName = "specialization_id")]
        public string SpecializationID { get; set; }

        [JsonProperty(PropertyName = "course_type_id")]
        public string CourseTypeID { get; set; }

        [JsonProperty(PropertyName = "course_id")]
        public string CourseID { get; set; }

        [JsonProperty(PropertyName = "percentage")]
        public string Percentage { get; set; }

        //[JsonProperty(PropertyName = "skill_id")]
        //public string SkillID { get; set; }

        //[JsonProperty(PropertyName = "night_shift")]
        //public string WillingNightShift { get; set; }

        //[JsonProperty(PropertyName = "relocate")]
        //public string WillingRelocate { get; set; }

        [JsonProperty(PropertyName = "cgpa")]
        public string CGPA { get; set; }

        [JsonProperty(PropertyName = "year_of_passing")]
        public string YearOfCompletion { get; set; }

        [JsonProperty(PropertyName = "backlog")]
        public string BackLog { get; set; }

        public string registerNo { get; set; }
    }
    #endregion

}
