﻿namespace HireMe
{
    public class AddUserMobile_OTP_model
    {
        public string mobile_number { get; set; }
        public string email_address { get; set; }
        public string hiremee_id { get; set; }
        public string otp { get; set; }
        
        public string register_id { get; set; }
        public string token { get; set; }
       // public int type { get; set; }
    }

    public class AddUserMobile_OTP_Response
    {
        public string code { get; set; }
        public string message { get; set; }
        public string response { get; set; }     
    }
}