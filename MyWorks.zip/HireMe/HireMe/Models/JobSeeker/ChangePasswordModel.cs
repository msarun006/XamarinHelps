﻿using Newtonsoft.Json;

namespace HireMe.Models.JobSeeker
{
    public class ChangePasswordModel
    {
        /// <summary>
        /// Change password request data.
        /// </summary>
        #region ChangePassword Request Data
        public class ChangePasswordRequestData : BaseRequestDTO
        {

            [JsonProperty(PropertyName = "old_password")]
            public string OldPassword { get; set; }

            [JsonProperty(PropertyName = "current_password")]
            public string CurrentPassword { get; set; }

            [JsonProperty(PropertyName = "password")]
            public string password { get; set; }
        }

        #endregion

        #region ChangePassword Response Data

        /// <summary>
        /// Change passwords response data.
        /// </summary>
        public class ChangePasswordsResponseData
        {

            public string code { get; set; }

         
            public string message { get; set; }

            [JsonProperty(PropertyName = "responseText")]
            public ChangePasswordData Response { get; set; }
        }

        /// <summary>
        /// Change password data.
        /// </summary>
        public class ChangePasswordData : ChangePasswordRequestData
        {


        }


        #endregion
    }
}
