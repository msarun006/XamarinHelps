﻿using HireMe.Models;
using HireMe.Models.JobSeeker;
using HireMe.Models.Recruiter;
using MvvmHelpers;
using Newtonsoft.Json;

namespace HireMe
{
    public class SeekerDashboardModel : BaseRequestDTO
    {

    }

    #region JobSeekerProfileDetails

    public class JobSeekerProfileDetails : BaseViewModel
    {
        [JsonProperty(PropertyName = "hiremee_id")]
        public string HireMeeID { get; set; }

        [JsonProperty(PropertyName = "fullname")]
        public string FullName { get; set; }

        [JsonProperty(PropertyName = "first_name")]
        public string FirstName { get; set; }

        [JsonProperty(PropertyName = "last_name")]
        public string LastName { get; set; }

        [JsonProperty(PropertyName = "email_address")]
        public string EmailAddress { get; set; }

        [JsonProperty(PropertyName = "mobile_number")]
        public string MobileNumber { get; set; }

        [JsonProperty(PropertyName = "aadhaar_number")]
        public string AadharNumber { get; set; }

        [JsonProperty(PropertyName = "candidate_disablity")]
        public string Disablity { get; set; }

        [JsonProperty(PropertyName = "date_of_birth")]
        public string Dateofbirth { get; set; }

        [JsonProperty(PropertyName = "gender")]
        public string Gender { get; set; }


        [JsonProperty(PropertyName = "total_score")]
        public string TotalScore { get; set; }

        [JsonProperty(PropertyName = "languageknown")]
        public Languageknown[] Languages { get; set; }

        [JsonProperty(PropertyName = "email_verified")]
        public string EmailVerified { get; set; }

        [JsonProperty(PropertyName = "mobile_verified")]
        public string MobileVerified { get; set; }


        [JsonProperty(PropertyName = "passport_number")]
        public string PassportNumber { get; set; }

        [JsonProperty(PropertyName = "current_address")]
        public string CurrentAddress { get; set; }

        [JsonProperty(PropertyName = "current_state_id")]
        public string CurrentStateId { get; set; }

        [JsonProperty(PropertyName = "current_state_name")]
        public string CurrentStateName { get; set; }

        [JsonProperty(PropertyName = "current_city_id")]
        public string CurrentCityId { get; set; }

        [JsonProperty(PropertyName = "current_city_name")]
        public string CurrentCityName { get; set; }

        [JsonProperty(PropertyName = "current_zipcode")]
        public string CurrentZipcode { get; set; }

        [JsonProperty(PropertyName = "permanent_address")]
        public string PermanentAddress { get; set; }

        [JsonProperty(PropertyName = "permanent_zipcode")]
        public string PermanentZipcode { get; set; }

        [JsonProperty(PropertyName = "permanent_state_id")]
        public string PermanentStateID { get; set; }

        [JsonProperty(PropertyName = "permanent_state_name")]
        public string PermanentStateName { get; set; }

        [JsonProperty(PropertyName = "permanent_city_id")]
        public string PermanentCityID { get; set; }

        [JsonProperty(PropertyName = "permanent_city_name")]
        public string PermanentCityName { get; set; }

        [JsonProperty(PropertyName = "nationality_name")]
        public string NationalityName { get; set; }

        [JsonProperty(PropertyName = "nationality")]
        public string NationalityID { get; set; }

        [JsonProperty(PropertyName = "prefered_job_location")]
        public string prefer_location_id { get; set; }

        [JsonProperty(PropertyName = "job_location_name")]
        public string prefer_location_name { get; set; }

        public string is_copy { get; set; }

        public string aboutMe { get; set; }
        public string panNo { get; set; }
        public string faceBookLink { get; set; }
        public string twitterLink { get; set; }
        public string linkedinLink { get; set; }
        public string googlePlusLink { get; set; }
    }

    public class JobSeekerProfileweightage
    {
        [JsonProperty(PropertyName = "personaldetails")]
        public string PersonalDetails { get; set; }

        [JsonProperty(PropertyName = "educationaldetails")]
        public string EducationalDetails { get; set; }

        [JsonProperty(PropertyName = "video")]
        public string Video { get; set; }

        [JsonProperty(PropertyName = "profilepic")]
        public string ProfilePic { get; set; }

    }

    public class JobSeekerProfileImage
    {

        [JsonProperty(PropertyName = "hiremee_id")]
        public string HireMeeID { get; set; }

        [JsonProperty(PropertyName = "s3_id")]
        public string S3_ID { get; set; }

        [JsonProperty(PropertyName = "resourceurl")]
        public string ResourceURL { get; set; }

        [JsonProperty(PropertyName = "resourcetype_id")]
        public string ResourceTypeID { get; set; }

        [JsonProperty(PropertyName = "thumbnailurl")]
        public string ThumbnailURL { get; set; }

        [JsonProperty(PropertyName = "status")]
        public string Status { get; set; }
    }

    #region JobSeekerAssessmentDetails
    public class JobSeekerAssessmentDetails
    {

        [JsonProperty(PropertyName = "verbalaptitude")]
        public string VerbalAptitude { get; set; }

        [JsonProperty(PropertyName = "quantitativeaptitude")]
        public string QuantitativeAptitude { get; set; }

        [JsonProperty(PropertyName = "logicalreasoning")]
        public string LogicalResoning { get; set; }

        [JsonProperty(PropertyName = "technicalcomputerfundamental")]
        public string TechnicalComputerFundamental { get; set; }

        [JsonProperty(PropertyName = "communication")]
        public string Communication { get; set; }

        [JsonProperty(PropertyName = "technicalcoredomain")]
        public string TechnicalCoreDomain { get; set; }


        [JsonProperty(PropertyName = "interpersonalcompetencies")]
        public string InterPersonalCompetencies { get; set; }

        [JsonProperty(PropertyName = "personalcompetencies")]
        public string PersonalCompetencies { get; set; }

        [JsonProperty(PropertyName = "emotionalcompetencies")]
        public string EmotionalCompetencies { get; set; }

        [JsonProperty(PropertyName = "motivationalcompetencies")]
        public string MotivationalCompetencies { get; set; }

        [JsonProperty(PropertyName = "intellectualorientation")]
        public string IntellectualOrientation { get; set; }


        [JsonProperty(PropertyName = "totalscore")]
        public string Totalscore { get; set; }
        public string PercenTile { get; set; }
        public string Status { get; set; }
        public string Reason { get; set; }
    }
    #endregion

    #region SeekerDashboardOverallResponseModel
    public class SeekerDashboardResponseModel
    {
        [JsonProperty(PropertyName = "code")]
        public string Code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string Message { get; set; }

        [JsonProperty(PropertyName = "profiledetails")]
        public JobSeekerProfileDetails ProfileDetails { get; set; }

        [JsonProperty(PropertyName = "profileweightage")]
        public JobSeekerProfileweightage ProfileWeightage { get; set; }

        [JsonProperty(PropertyName = "userresources")]
        public JobSeekerProfileImage ProfileImage { get; set; }

        [JsonProperty(PropertyName = "assement")]
        public JobSeekerAssessmentDetails AssessmentScore { get; set; }
        [JsonProperty(PropertyName = "languageknown")]
        public Languageknown[] Languages { get; set; }

        public Prefer_Job_Location[] prefer_job_location { get; set; }

        [JsonProperty(PropertyName = "EducationDetails")]
        public EducationalDetailsResponseData EducationalDetailsResponseData { get; set; }

        [JsonProperty(PropertyName = "UserResource")]
        public VideoResourceRetrivalResponseData UserResource { get; set; }

        public Appversioncheck apiVersionCheck { get; set; }
    }


    #endregion



    public class Prefer_Job_Location
    {
        public string location_id { get; set; }
        public string hiremee_id { get; set; }
        public Joblocation joblocation { get; set; }
    }

    public class Joblocation
    {
        public string id { get; set; }
        public string district { get; set; }
    }


    #endregion
}
