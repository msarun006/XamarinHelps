﻿using Newtonsoft.Json;
using System.Collections.Generic;
using Xamarin.Forms;
using MvvmHelpers;

namespace HireMe.Models.JobSeeker
{


    #region Company Full Details Request Data
    public class CompanyFullDetailsRequestData : BaseRequestDTO
    {
        [JsonProperty(PropertyName = "company_id")]
        public string CompanyID { get; set; }

    }
    #endregion



    //#region Company Full Details Response Data

    //public class Companyvideo
    //{
    //	public int id { get; set; }
    //	public int collegecompany_id { get; set; }
    //	public string s3_id { get; set; }
    //}



    //public class Citys
    //{
    //	public int id { get; set; }
    //	public string district { get; set; }
    //}

    //public class Districts
    //{
    //	public int id { get; set; }
    //	public string name { get; set; }
    //}

    ////public class Companylogo
    ////{
    ////	public int id { get; set; }
    ////	public string collegecompany_id { get; set; }
    ////	private string _s3ID;
    ////	public bool isNOImage { get; set; }
    ////	[JsonProperty(PropertyName = "s3_id")]
    ////	public string s3ID
    ////	{
    ////		get { return S3Manager.GeneratePreSignedURL(Constants.CompanyLogoBucket, _s3ID, 5); }
    ////		set { _s3ID = value; }
    ////	}
    ////}

    //public class CompanyDetailsResponseData : BaseViewModel
    //{
    //	public int id { get; set; }
    //	public string companyname { get; set; }
    //	public string email_address { get; set; }
    //	public string mobile_number { get; set; }
    //	public string spoc_name { get; set; }
    //	public string website_address { get; set; }
    //	public string address { get; set; }
    //	public string city { get; set; }
    //	public string state { get; set; }
    //	public string country { get; set; }
    //	public Companyvideo companyvideo { get; set; }
    //	//public Companylogo companylogo { get; set; }
    //	private Companylogo _companylogo;
    //	[JsonProperty(PropertyName = "companylogo")]
    //	public Companylogo companylogo
    //	{
    //		get
    //		{

    //			return _companylogo;
    //		}

    //		set
    //		{
    //			if (value != null)
    //			{
    //				_companylogo = value;


    //			}
    //			else
    //			{
    //				_companylogo = new Companylogo();
    //				_companylogo.isNOImage = true;
    //				_companylogo.s3ID = (string)Application.Current.Resources["NoImageAvailable"];

    //			}

    //               OnPropertyChanged(); 
    //		}

    //	}
    //	public Citys citys { get; set; }
    //	public Districts districts { get; set; }
    //}

    //public class CompanyFullDetailsResponse
    //{
    //	public string code { get; set; }
    //	public string message { get; set; }
    //	public CompanyDetailsResponseData response { get; set; }
    //}
    //#endregion

    #region Company Full Details Response Data
    public class BranchDetail
    {
        public string address { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string FullAddress { get; set; }
    }

    public class Companyvideo
    {
        public int id { get; set; }
        public string collegecompany_id { get; set; }
        public string s3_id { get; set; }
    }

    //public class Companylogo
    //{
    //    public int id { get; set; }
    //    public string collegecompany_id { get; set; }
    //    public string s3_id { get; set; }
    //    public string resourceurl { get; set; }
    //}

    public class Citys
    {
        public int id { get; set; }
        public string district { get; set; }
    }

    public class Districts
    {
        public int id { get; set; }
        public string name { get; set; }
    }

    public class CompanyDetailsResponseData : BaseViewModel
    {
        public int id { get; set; }
        public string companyname { get; set; }
        public string spoc_name { get; set; }
        public string website_address { get; set; }
        public string address { get; set; }
        public string country { get; set; }
        public string corporate_address { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string corporate_city { get; set; }
        public string corporate_state { get; set; }
        public string email_address { get; set; }
        public string mobile_number { get; set; }
        public string no_of_employees { get; set; }
        public string company_type { get; set; }
        public List<BranchDetail> branch_details { get; set; }
        public Companyvideo companyvideo { get; set; }

        private Companylogo _companylogo;
        [JsonProperty(PropertyName = "companylogo")]
        public Companylogo companylogo
        {
            get
            {

                return _companylogo;
            }

            set
            {
                if (value != null)
                {
                    _companylogo = value;


                }
                else
                {
                    _companylogo = new Companylogo();
                    _companylogo.isNOImage = true;
                    _companylogo.s3ID = (string)Application.Current.Resources["NoImageAvailable"];

                }

                OnPropertyChanged();
            }

        }


        public Citys citys { get; set; }
        public Districts districts { get; set; }
    }

    public class CompanyFullDetailsResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public CompanyDetailsResponseData responseText { get; set; }
    }

    #endregion
}
