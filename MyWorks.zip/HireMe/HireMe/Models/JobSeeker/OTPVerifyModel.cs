﻿namespace HireMe
{
    public class OTPVerifyRequest
    {
        public string otp { get; set; }
        public string register_id { get; set; }
        public string social { get; set; }
        public string udid { get; set; }
        public string devos { get; set; }
        public string devmodel { get; set; }
        public string password { get; set; }
    }
    public class OTPVerifyResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public string response { get; set; }
    }
}
