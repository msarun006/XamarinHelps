﻿using Newtonsoft.Json;

namespace HireMe.Models.JobSeeker
{
    #region ProfileDetails Request Data
    /// <summary>
    /// Profile details request data.
    /// </summary>
    public class ProfileDetailsRequestData : BaseRequestDTO
    {
        public ProfileDetailsRequestData() : base()
        {

        }


        [JsonProperty(PropertyName = "nationality")]
        public string Nationality { get; set; }



        [JsonProperty(PropertyName = "fullname")]
        public string FirstName { get; set; }

        [JsonProperty(PropertyName = "lastname")]
        public string LastName { get; set; }

        [JsonProperty(PropertyName = "email_address")]
        public string EmailAddress { get; set; }


        [JsonProperty(PropertyName = "mobile_number")]
        public string MobileNumber { get; set; }


        [JsonProperty(PropertyName = "date_of_birth")]
        public string DateOfBirth { get; set; }

        [JsonProperty(PropertyName = "gender")]
        public string Gender { get; set; }

        [JsonProperty(PropertyName = "candidate_disability")]
        public string Disablity { get; set; }

        [JsonProperty(PropertyName = "aadhaar_number")]
        public string AadharNumber { get; set; }

        [JsonProperty(PropertyName = "passport_number")]
        public string PassportNumber { get; set; }

        [JsonProperty(PropertyName = "current_address")]
        public string CurrentAddress { get; set; }

        [JsonProperty(PropertyName = "current_state")]
        public string CurrentStateID { get; set; }

        [JsonProperty(PropertyName = "current_city")]
        public string CurrentCityID { get; set; }

        [JsonProperty(PropertyName = "current_pincode")]
        public string CurrentPinCode { get; set; }


        [JsonProperty(PropertyName = "permanent_address")]
        public string PermanentAddress { get; set; }

        [JsonProperty(PropertyName = "permanent_state")]
        public string PermanentStateID { get; set; }

        [JsonProperty(PropertyName = "permanent_city")]
        public string PermanentCityID { get; set; }

        [JsonProperty(PropertyName = "permanent_pincode")]
        public string PermanentPinCode { get; set; }

        [JsonProperty(PropertyName = "job_location")]
        public string JobLocationId { get; set; }

        public string aboutMe { get; set; }
        public string panNo { get; set; }
        public string faceBookLink { get; set; }
        public string twitterLink { get; set; }
        public string linkedinLink { get; set; }
        public string googlePlusLink { get; set; }



        //languageknown
        [JsonProperty(PropertyName = "language")]
        public Languageknown[] Languages { get; set; }

       

        public string is_copy { get; set; }



    }


    #endregion

    #region ProfileDetails Response Data

    /// <summary>
    /// Profile details response data.
    /// </summary>
   
    public class ProfileDetailsResponseData
    {
        public string code { get; set; }
        public string message { get; set; }
        public string responseText { get; set; }
    }

    #endregion
}
