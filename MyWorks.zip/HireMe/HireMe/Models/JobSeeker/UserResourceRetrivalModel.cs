﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace HireMe.Models.JobSeeker
{

    #region UserResourceRetrival Request Data
    public class UserResourceRetrivalRequestData : BaseRequestDTO
    {
        [JsonProperty(PropertyName = "resourcetype_id")]
        public string ResourceTypeId { get; set; }
    }

    #endregion

    #region UserResourceRetrival Response Data
    public class UserResourceRetrival : BaseRequestDTO
    {

        [JsonProperty(PropertyName = "token_expiry")]
        public string TokenExpiry { get; set; }

        [JsonProperty(PropertyName = "resourcetype_id")]
        public string ResourceTypeId { get; set; }

        [JsonProperty(PropertyName = "s3_id")]
        public string s3Id { get; set; }

        [JsonProperty(PropertyName = "resourceurl")]
        public string ResourceUrl { get; set; }

        [JsonProperty(PropertyName = "status")]
        public string VideoStatus { get; set; }

        //[JsonProperty(PropertyName = "thumbnailurl")]
        //public string ThumbnailUrl { get; set; }

        [JsonProperty(PropertyName = "thumbnailurl")]
        public string s3ThumbnailImage { get; set; }

    }

    public class UserResourceRetrivalResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public UserResourceRetrival Response { get; set; }
    }

    #endregion



    public class VideoResourceRetrivalResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }
        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }
        [JsonProperty(PropertyName = "userresourcetype")]
        public List<UserResourceType> UserResourceType { get; set; }
        [JsonProperty(PropertyName = "userresourceconfig")]
        public UserResourceConfiguration UserResourceConfig { get; set; }
        [JsonProperty(PropertyName = "picture")]
        public ResourceInformation ProfilePicture { get; set; }
        [JsonProperty(PropertyName = "video1")]
        public ResourceInformation AboutMeVideo { get; set; }
        [JsonProperty(PropertyName = "video2")]
        public ResourceInformation SkillVideo { get; set; }
        [JsonProperty(PropertyName = "video3")]
        public ResourceInformation AreaOfInterestVideo { get; set; }
    }

    public class UserResourceConfiguration
    {
        [JsonProperty(PropertyName = "aboutmyself")]
        public ResourceConfig AboutMeConfig { get; set; }
        [JsonProperty(PropertyName = "skill")]
        public ResourceConfig SkillConfig { get; set; }
        [JsonProperty(PropertyName = "ambition")]
        public ResourceConfig AmbitionConfig { get; set; }
    }

    public class ResourceConfig
    {
        [JsonProperty(PropertyName = "maxRecordtime")]
        public string MaxRecordTime { get; set; }
        [JsonProperty(PropertyName = "minRecordtime")]
        public string MinRecordTime { get; set; }
        [JsonProperty(PropertyName = "maxResolution")]
        public string MaxResolution { get; set; }
        [JsonProperty(PropertyName = "minResolution")]
        public string MinResolution { get; set; }
        [JsonProperty(PropertyName = "maxFilesize")]
        public string MaxFileSize { get; set; }
    }



    public class ResourceInformation
    {
        [JsonProperty(PropertyName = "s3_id")]
        public string S3ID { get; set; }
        [JsonProperty(PropertyName = "resourceurl")]
        public string ResourceURL { get; set; }
        [JsonProperty(PropertyName = "resourcetype_id")]
        public string ResourceTypeID { get; set; }
        [JsonProperty(PropertyName = "thumbnailurl")]
        public string ThumbnailURL { get; set; }
        [JsonProperty(PropertyName = "status")]
        public string Status { get; set; }
        [JsonProperty(PropertyName = "reasonforblock")]
        public string ReasonForBlock { get; set; }
    }









}
