﻿namespace HireMe.Models.JobSeeker
{
    public class ForgotPasswordVerifyModel
    {
        public string token { get; set; }
        public string hiremee_id { get; set; }
        public string otp { get; set; }
        public string password { get; set; }
        public string register_id { get; set; }
        //public int type { get; set; }

    }
    
    public class ForgotPasswordVerifyResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public string response { get; set; }
    }


}
