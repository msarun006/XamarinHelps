﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HireMe.Models.JobSeeker
{
    class BindStateAndCityRequestModel
    {
        public string pinCode { get; set; }
    }


    //public class BindStateAndCityResponseModel
    //{
    //    public string code { get; set; }
    //    public string message { get; set; }
    //    public Responsetext[] responseText { get; set; }
    //}

    //public class Responsetext
    //{
    //    public string pincode { get; set; }
    //    public string stateId { get; set; }
    //    public string stateName { get; set; }
    //    public string districtId { get; set; }
    //    public string districtName { get; set; }
    //}

    public class BindStateAndCityResponseModel
    {
        public string Code { get; set; }
        public string Message { get; set; }
        public Pincodedetail[] responseText { get; set; }
    }

    public class Pincodedetail
    {
        public string Pincode { get; set; }
        public string StateId { get; set; }
        public string StateName { get; set; }
        public string DistrictId { get; set; }
        public string DistrictName { get; set; }
    }

}
