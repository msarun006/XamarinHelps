﻿using HireMe.Services;
using MvvmHelpers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace HireMe.Models.JobSeeker
{

    public class CurrentWalkinsResponseData :BaseViewModel
    {
        public string JobPostingId { get; set; }
        public string job_title { get; set; }
        public string industry_name { get; set; }
        public string Skills { get; set; }
        public string walkin_from { get; set; }
        public string walkin_to { get; set; }
        public string start_date { get; set; }
        public string end_date { get; set; }
        public string companyname { get; set; }
        public string qualification { get; set; }
        public string location { get; set; }
        public string description { get; set; }
        public string numberofpostion { get; set; }
        private string _txtJobApply;

        public string txtJobApply
        {
            get { return "  " + _txtJobApply + "  "; }
            set { _txtJobApply = value; }
        }
        private string _Timing;

        public string Timing
        {
            get { return _Timing; }
            set { _Timing = value; OnPropertyChanged(); }
        }

        //public string CompanyS3Id { get; set; }
        private string _s3ID;
        public bool isNOImage { get; set; }
        [JsonProperty(PropertyName = "CompanyS3Id")]
        public string s3ID
        {
            get { return _s3ID; }
            set
            {

                if (isNOImage)
                {
                    _s3ID = value;
                }
                else
                {

                    if (!string.IsNullOrEmpty(value))
                    {
                        _s3ID = S3Manager.GeneratePreSignedURL(AmazonS3BucketDetails.CompanyLogoBucket, value, 5);
                    }
                    else
                    {
                        _s3ID = (string)Application.Current.Resources["NoImageAvailable"];
                    }
                }
                OnPropertyChanged();
            }
        }
        public string AppliedStatus { get; set; }
        public string to_time { get; set; }
        public string Venue { get; set; }
        public string start_time { get; set; }
        public string last_date { get; set; }
    }

    public class CurrentWalkinsResponse
    {
        public string Code { get; set; }
        public string Message { get; set; }
        public List<CurrentWalkinsResponseData> CurrentWalkins { get; set; }
    }

    public class CurrenWalkinsRequest :BaseRequestDTO
    {
        public string CandidateHiremeeId { get; set; }
        public string CommaSeperatedSkillId { get; set; }
        public string CompanyName { get; set; }
        public string WalkinFrom { get; set; }
        public string WalkinTo { get; set; }
    }

}
