﻿using MvvmHelpers;
using Newtonsoft.Json;
using Xamarin.Forms;

namespace HireMe
{
    public class CompanyFullDetailsModel : BaseViewModel
	{
		public CompanyFullDetailsModel()
		{



		}
		private Companylogo _CompanyLogo;

        [JsonProperty(PropertyName = "companylogo")]

        public Companylogo CompanyLogo
        {
            get
            {

                return _CompanyLogo;
            }

            set
            {
                if (value != null)
                {
                    _CompanyLogo = value;


                }
                else
                {
                    _CompanyLogo = new Companylogo();
                    _CompanyLogo.isNOImage = true;
                    _CompanyLogo.s3ID = (string)Application.Current.Resources["NoImageAvailable"];

                }
                OnPropertyChanged();
            }
        }


        private string _CompanyName;
		public string CompanyName
		{
			get { return _CompanyName; }
			set { _CompanyName = value; OnPropertyChanged(); }
		}


		private string _Email;
		public string Email
		{
			get { return _Email; }
			set { _Email = value; OnPropertyChanged(); }
		}


		private string _Mobile;
		public string Mobile
		{
			get { return _Mobile; }
			set { _Mobile = value; OnPropertyChanged(); }
		}


		private string _Address;
		public string Address
		{
			get { return _Address; }
			set { _Address = value; OnPropertyChanged(); }
		}


		private string _City;
		public string City
		{
			get { return _City; }
			set { _City = value; OnPropertyChanged(); }
		}

		private string _State;
		public string State
		{
			get { return _State; }
			set { _State = value; OnPropertyChanged(); }
		}

		private string _Country;

		public string Country
		{
			get { return _Country; }
			set { _Country = value; OnPropertyChanged(); }
		}

        private string _Corporateaddress;

        public string Corporateaddress
        {
            get { return _Corporateaddress; }
            set { _Corporateaddress = value; OnPropertyChanged(); }
        }

        private string _Branchaddress;

        public string Branchaddress
        {
            get { return _Branchaddress; }
            set { _Branchaddress = value; OnPropertyChanged(); }
        }

        private string _Totalemployees;

        public string Totalemployees
        {
            get { return _Totalemployees; }
            set { _Totalemployees = value; OnPropertyChanged(); }
        }

        private string _Companytype;

        public string Companytype
        {
            get { return _Companytype; }
            set { _Companytype = value; OnPropertyChanged(); }
        }
    }
}