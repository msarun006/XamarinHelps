﻿namespace HireMe
{

    public class UserMobileNoUpdateModel
        {
            public string token { get; set; }
             public string hiremee_id { get; set; }
            public string mobile_number { get; set; }

        }

    public class UserMobileNoUpdateResponseValue
    {
        public string mobile_number { get; set; }
        public string email_address { get; set; }
        public int register_id { get; set; }
        public int resend { get; set; }
        public string message { get; set; }
        public string otp { get; set; }
       
    }

    public class UserMobileNoUpdateResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public UserMobileNoUpdateResponseValue responseText { get; set; }
    }
   
}



