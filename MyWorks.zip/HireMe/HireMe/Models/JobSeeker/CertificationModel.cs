﻿using HireMe.Models.Recruiter;
using System.Collections.ObjectModel;

namespace HireMe.Models.JobSeeker
{
    public class CertificationRequestModel : BaseRequestDTO
    {
       // public string token { get; set; }
      //  public string hiremee_id { get; set; }
        public string certification_id { get; set; }
        public string certification_year { get; set; }
        public string certification_name { get; set; }

         
    }
    

    public class CertificationResponseModel
    {
        public string code { get; set; }
        public string message { get; set; }
        public string responseText { get; set; }

        public ObservableCollection<CertificationDetails> certificationlist { get; set; }
    }

    public class CertificateDeleteResponseModel
    {
        public string code { get; set; }
        public string message { get; set; }
        public string responseText { get; set; }
        public ObservableCollection<CertificationDetails> certificationlist { get; set; }
    }

    public class CertificateDeleteRequestModel:BaseRequestDTO
    {
        public string certification_id { get; set; }
     //   public string token { get; set; }
      //  public string hiremee_id { get; set; }
    }





}
