﻿using Newtonsoft.Json;
using System.Collections.Generic;


namespace HireMe.Models.JobSeeker
{
    #region Notification Request Data
    public class NotificationRequestData : BaseRequestDTO
    {
        //[JsonProperty(PropertyName = "hiremee_id")]
        //public string HiremeID { get; set; }

        //[JsonProperty(PropertyName = "token")]
        //public string Token { get; set; }
    }

    #endregion

    #region Notification Response Data
    /// <summary>
    /// Notification details.
    /// </summary>

    public class Notification
    {
        [JsonProperty(PropertyName = "hiremee_id")]
        public string HiremeID { get; set; }

        [JsonProperty(PropertyName = "recruiter_hiremee_id")]
        public string RecruiterHiremeID { get; set; }

        [JsonProperty(PropertyName = "company_name")]
        public string CompanyName { get; set; }

        [JsonProperty(PropertyName = "company_id")]
        public string CompanyID { get; set; }


        [JsonProperty(PropertyName = "mail_content")]
        public string MailContent { get; set; }

        [JsonProperty(PropertyName = "created_at")]
        public string Date { get; set; }

        [JsonProperty(PropertyName = "recruitername")]
        public string RecruiterName { get; set; }

        [JsonProperty(PropertyName = "state")]
        public string State { get; set; }

    }
    /// <summary>
    /// Notification response data.
    /// </summary>
    public class NotificationResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }

        //[JsonProperty(PropertyName = "profilecount")]
        [JsonProperty(PropertyName = "profileviewer")]
        public string ProfileCount { get; set; }

        [JsonProperty(PropertyName = "notification")]
        public List<Notification> notification { get; set; }
    }

    #endregion

    public class NotificationResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public NotificationResponsetext[] responseText { get; set; }
    }

    public class NotificationResponsetext
    {
        private string _body;
        [JsonProperty(PropertyName = "title")]
        public string NotificationTitle { get; set; }
        [JsonProperty(PropertyName = "body")]
        public string NotificationBody
        {
            get
            {
                if (!string.IsNullOrEmpty(_body) && _body.Trim().Length > 100)

                    return _body.Trim().Substring(0, 100);
                else
                    return _body.Trim();
            }
            set { _body = value;
                MailContent = value;
            }
        }
        public string MailContent
        {
            get;
            set;
        }
        [JsonProperty(PropertyName = "type")]
        public string NotificationType { get; set; }

        [JsonProperty(PropertyName = "created_at")]
        public string NotifiedDate { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string FileName { get; set; }
    }
}