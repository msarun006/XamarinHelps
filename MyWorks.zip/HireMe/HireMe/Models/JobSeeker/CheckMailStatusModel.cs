﻿using Newtonsoft.Json;

namespace HireMe.Models.JobSeeker
{
    /// <summary>
    /// Check mail response data.
    /// </summary>
    public class CheckMailResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string Code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string Message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public string Response { get; set; }
    }


    /// <summary>
    /// Check mail request data.
    /// </summary>
    public class CheckMailRequestData
    {
        [JsonProperty(PropertyName = "email_address")]
        public string EmailAddress { get; set; }

        [JsonProperty(PropertyName = "mobile_number")]
        public string MobileNumber { get; set; }

    }
}
