﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace HireMe.Models.JobSeeker
{
    public class PreferredJobLocationResponseDate
    {
        [JsonProperty(PropertyName = "name")]
        public string PreferredJobLocation { get; set; }
        public string id { get; set; }
    }
    public class PreferredJobLocationResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public List<PreferredJobLocationResponseDate> response { get; set; }
    }
}
