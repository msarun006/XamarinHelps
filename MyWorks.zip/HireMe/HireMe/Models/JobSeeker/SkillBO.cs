﻿using HireMe.Models;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace HireMe
{

    public class SkillRequestData : BaseRequestDTO
    {
        [JsonProperty(PropertyName = "speclization_id")]
        public string Specialization { get; set; }
    }
    public class NewSkillResponseData
    {
        public string code { get; set; }
        public string message { get; set; }
        [JsonProperty(PropertyName = "responseText")]
        public NewSkillResponsetext SkillResponseData { get; set; }
    }

    public class NewSkillResponsetext
    {
        [JsonProperty(PropertyName = "data")]
        public List<Skill> SkillData { get; set; }
    }

    //public class DependantSkillResponseData
    //{
    //    public string code { get; set; }
    //    public string message { get; set; }
    //    public List<Skill> response { get; set; }
    //}



    public class DependantSkillResponseData
    {
        public string code { get; set; }
        public string message { get; set; }
        public SkillList responseText { get; set; }
    }

    public class SkillList
    {
        public List<Skill> data { get; set; }
    }

    //public class SkillListData
    //{
    //    public string id { get; set; }
    //    public string name { get; set; }
    //}


}