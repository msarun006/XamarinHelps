﻿using MvvmHelpers;
using Newtonsoft.Json;

namespace HireMe
{
    #region CollegeRegistration Response Date
    /// <summary>
    /// CollageViseRegistrations response data.
    /// </summary>
    public class CollegeViseRegistrationsResponseData
	{
		[JsonProperty(PropertyName = "code")]
		public string code { get; set; }

		[JsonProperty(PropertyName = "message")]
		public string message { get; set; }

		[JsonProperty(PropertyName = "response")]
		public CollegeViseRegistrationsRequestData Response { get; set; }
	}
	#endregion
    
	#region CollegeRegistration Request Date
	/// <summary>
	/// CollageViseRegistrations response data.
	/// </summary>
	public class CollegeViseRegistrationsRequestData : BaseViewModel
	{
		[JsonProperty(PropertyName = "id")]
		public int ID { get; set; }

		[JsonProperty(PropertyName = "fullname")]
		//public string FirstName { get; set; }
		public string firstName;
		public string FirstName
		{
			get { return firstName; }
			set { firstName = value; OnPropertyChanged(); }
		}



		[JsonProperty(PropertyName = "lastname")]
		//public string LastName { get; set; }
		public string lastName;
		public string LastName
		{
			get { return lastName; }
			set { lastName = value; OnPropertyChanged(); }
		}


		[JsonProperty(PropertyName = "email_address")]
		//public string EmailAddress { get; set; }
		public string emailAddress;
		public string EmailAddress
		{
			get { return emailAddress; }
			set { emailAddress = value; OnPropertyChanged(); }
		}

		[JsonProperty(PropertyName = "mobile_number")]
		//public string MobileNumber { get; set; }
		public string mobileNumber;
		public string MobileNumber
		{
			get { return mobileNumber; }
			set { mobileNumber = value; OnPropertyChanged(); }
		}

		[JsonProperty(PropertyName = "password")]
		//public string Password { get; set; }
		public string password;
		public string Password
		{
			get { return password; }
			set { password = value; OnPropertyChanged(); }
		}

		[JsonProperty(PropertyName = "aadhaar_number")]
		//public string AadharNumber { get; set; }
		public string aadharNumber;
		public string AadharNumber
		{
			get { return aadharNumber; }
			set { aadharNumber = value; OnPropertyChanged(); }
		}

		[JsonProperty(PropertyName = "college_id")]
		public string CollegeID { get; set; }

		[JsonProperty(PropertyName = "dob")]
		//public string DOB { get; set; }
		public string dOB;
		public string DOB
		{
			get { return dOB; }
			set { dOB = value; OnPropertyChanged(); }
		}


	}
	#endregion



}