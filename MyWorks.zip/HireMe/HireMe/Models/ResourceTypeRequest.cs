﻿namespace HireMe
{
    public class ResourceTypeRequest
    {
        public string token { get; set; }
        public string hiremee_id { get; set; }
        public string resourcetype_id { get; set; }
    }
}
