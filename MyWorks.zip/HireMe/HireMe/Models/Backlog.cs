﻿namespace HireMe
{
	public class Backlog
	{
		public string BacklogID { get; set; }
		public string Title { get; set; }
	}
}
