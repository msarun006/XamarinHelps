﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HireMe.Models
{
    

    public class CheckVersionUpdate
    {
        public object code { get; set; }
        public object message { get; set; }
        public Appversioncheck apiVersionCheck { get; set; }
    }

    //public class Appversioncheck
    //{
    //    public object ioS_VersionName { get; set; }
    //    public object ioS_VersionCode { get; set; }
    //    public object android_VersionName { get; set; }
    //    public object android_VersionCode { get; set; }
    //}

}
