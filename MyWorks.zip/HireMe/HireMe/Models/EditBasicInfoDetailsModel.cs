﻿using Newtonsoft.Json;

namespace HireMe.Models
{
    public class EditBasicInfoDetailsRequest : BaseRequestDTO
    {
        [JsonProperty(PropertyName = "fullname")]
        public string FirstName { get; set; }

        [JsonProperty(PropertyName = "lastname")]
        public string LastName { get; set; }

        [JsonProperty(PropertyName = "email_address")]
        public string EmailAddress { get; set; }

        [JsonProperty(PropertyName = "mobile_number")]
        public string MobileNumber { get; set; }
    }
    public class EditBasicInfoDetailsResponse
    {

        public string code { get; set; }


        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public string Response { get; set; }
    }
}
