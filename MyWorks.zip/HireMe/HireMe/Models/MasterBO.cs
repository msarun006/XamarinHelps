﻿using HireMe.Models;
using HireMe.Models.JobSeeker;
using HireMe.Services;
using MvvmHelpers;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Xamarin.Forms;

namespace HireMe
{
    /// <summary>
    /// Master table request data.
    /// </summary>
    #region Master Request Data
    public class MasterTableRequestData : BaseRequestDTO
    {


        [JsonProperty(PropertyName = "tabletype")]
        public string TableName { get; set; }


        [JsonProperty(PropertyName = "candidate_hiremee_id")]
        public string CandidateID { get; set; }

        [JsonProperty(PropertyName = "recruitercomments")]
        public string RecruiterComment { get; set; }


    }

    #endregion
    /// <summary>
    /// State response details.
    /// </summary>
    #region State Master Table
    public class StateResponseDetails : MasterTableRequestData
    {
        [JsonProperty(PropertyName = "state")]
        public List<State> Response { get; set; }

    }
    /// <summary>
    /// State response data.
    /// </summary>
    public class StateResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public StateResponseDetails Response { get; set; }
    }
    /// <summary>
    /// State.
    /// </summary>
    public class State : BaseViewModel
    {
        [JsonProperty(PropertyName = "id")]
        public string ID { get; set; }

        [JsonProperty(PropertyName = "name")]
        public string Title { get; set; }
        private string _title;
        public string title
        {
            get { return _title; }
            set { _title = value; OnPropertyChanged(); }
        }

    }

    public class States : INotifyPropertyChanged
    {
        [JsonProperty(PropertyName = "id")]
        public string ID { get; set; }

        [JsonProperty(PropertyName = "name")]
        public string Title { get; set; }


        private bool _isSelected;
        public bool IsSelected
        {
            get { return _isSelected; }
            set { _isSelected = value; RaisePropertyChanged(); }
        }

        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged([CallerMemberName] string propertyname = null)
        {
            if (PropertyChanged != null && propertyname != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
        }
        #endregion
    }

    #endregion
    /// <summary>
    /// University response details.
    /// </summary>
    #region university Master Table
    public class UniversityResponseDetails : MasterTableRequestData
    {
        [JsonProperty(PropertyName = "university")]
        public List<University> Response { get; set; }

    }
    /// <summary>
    /// University response data.
    /// </summary>
    public class UniversityResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public UniversityResponseDetails Response { get; set; }
    }
    /// <summary>
    /// University.
    /// </summary>
    public class University : BaseViewModel
    {
        [JsonProperty(PropertyName = "id")]
        public string ID { get; set; }

        //[JsonProperty(PropertyName = "name")]
        //public string Title { get; set; }
        private string _titile;
        [JsonProperty(PropertyName = "name")]
        public string UniversityName
        {
            get { return _titile; }
            set { _titile = value; OnPropertyChanged(); }
        }


    }
    #endregion

    /// <summary>
    /// Skill response details.
    /// </summary>
    #region Skill Master Table
    public class SkillResponseDetails : MasterTableRequestData
    {
        [JsonProperty(PropertyName = "skill")]
        public List<Skill> Response { get; set; }
    }
    /// <summary>
    /// Skill response data.
    /// </summary>
    public class SkillResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public SkillResponseDetails Response { get; set; }
    }
    /// <summary>
    /// Skill.
    /// </summary>
    public class Skill : INotifyPropertyChanged
    {
        [JsonProperty(PropertyName = "id")]
        public string ID { get; set; }

        //[JsonProperty(PropertyName = "name")]
        //public string Title { get; set; }
        private string _title;
        [JsonProperty(PropertyName = "name")]
        public string SkillName
        {
            get { return _title; }
            set { _title = value; RaisePropertyChanged(); }
        }

        private bool _isSelected;
        public bool IsSelected
        {
            get { return _isSelected; }
            set { _isSelected = value; RaisePropertyChanged(); }
        }

        public string skill_Type { get; set; }

        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged([CallerMemberName] string propertyname = null)
        {
            if (PropertyChanged != null && propertyname != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
        }
        #endregion
    }






    public class LanguageResponseDetails : MasterTableRequestData
    {
        [JsonProperty(PropertyName = "languagelist")]
        public List<Languageknown> responseText { get; set; }
    }

    public class LanguageResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public LanguageResponseDetails Response { get; set; }
    }

    public class Languages
    {

        private string _LanguageName;
        [JsonProperty(PropertyName = "languages")]
        public string LanguageName
        {
            get { return _LanguageName; }
            set { _LanguageName = value; }
        }
        [JsonProperty(PropertyName = "id")]
        public string ID { get; set; }
    }
    public class Languageknown : INotifyPropertyChanged
    {
        [JsonProperty(PropertyName = "languagesname")]
        public Languages Languages { get; set; }


        [JsonProperty(PropertyName = "id")]
        public string ID { get; set; }

        [JsonProperty(PropertyName = "languages_id")]
        public string LanguageID { get; set; }

        private string _title;
        [JsonProperty(PropertyName = "name")]
        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }

        private bool _isSelected;
        public bool IsSelected
        {
            get { return _isSelected; }
            set { _isSelected = value; RaisePropertyChanged(); }
        }
        private int _isRead;
        [JsonProperty(PropertyName = "read")]
        public int IsRead
        {
            get { return _isRead; }
            set { _isRead = value; RaisePropertyChanged(); }
        }
        private int _isWrite;
        [JsonProperty(PropertyName = "write")]
        public int IsWrite
        {
            get { return _isWrite; }
            set { _isWrite = value; RaisePropertyChanged(); }
        }
        private int _isSpeak;
        [JsonProperty(PropertyName = "speak")]
        public int IsSpeak
        {
            get { return _isSpeak; }
            set { _isSpeak = value; RaisePropertyChanged(); }
        }

        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged([CallerMemberName] string propertyname = null)
        {
            if (PropertyChanged != null && propertyname != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
        }
        #endregion
    }



    public class Year : INotifyPropertyChanged
    {
        [JsonProperty(PropertyName = "id")]
        public string ID { get; set; }

        [JsonProperty(PropertyName = "name")]
        public string Title { get; set; }

        private bool _isSelected;
        public bool IsSelected
        {
            get { return _isSelected; }
            set { _isSelected = value; RaisePropertyChanged(); }
        }

        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged([CallerMemberName] string propertyname = null)
        {
            if (PropertyChanged != null && propertyname != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
        }
        #endregion
    }



    public class JobLocation : INotifyPropertyChanged
    {
        [JsonProperty(PropertyName = "id")]
        public string ID { get; set; }

        [JsonProperty(PropertyName = "name")]
        public string Title { get; set; }

        private bool _isSelected;
        public bool IsSelected
        {
            get { return _isSelected; }
            set { _isSelected = value; RaisePropertyChanged(); }
        }

        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;

        protected void RaisePropertyChanged([CallerMemberName] string propertyname = null)
        {
            if (PropertyChanged != null && propertyname != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
        }
        #endregion
    }


    #endregion

    #region CourseType  Master Table
    /// <summary>
    /// Course type response details.
    /// </summary>
    public class CourseTypeResponseDetails : MasterTableRequestData
    {
        [JsonProperty(PropertyName = "coursetype")]
        public List<CourseType> Response { get; set; }

    }
    /// <summary>
    /// Course type response data.
    /// </summary>
    public class CourseTypeResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public CourseTypeResponseDetails Response { get; set; }
    }

    public class CourseType : BaseViewModel
    {
        [JsonProperty(PropertyName = "id")]
        public string ID { get; set; }


        public string educational_level { get; set; }

        //[JsonProperty(PropertyName = "name")]
        //public string Title { get; set; }
        private string _title;
        [JsonProperty(PropertyName = "name")]
        public string Title
        {
            get { return _title; }
            set { _title = value; OnPropertyChanged(); }
        }

        private bool _isSelected;
        public bool IsSelected
        {
            get { return _isSelected; }
            set { _isSelected = value; OnPropertyChanged(); }
        }
    }


    #endregion

    #region College Master Table
    /// <summary>
    /// College response details.
    /// </summary>
    public class CollegeResponseDetails : MasterTableRequestData
    {
        [JsonProperty(PropertyName = "data")]
        public List<College> Response { get; set; }

    }
    /// <summary>
    /// College response data.
    /// </summary>
    public class CollegeResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public CollegeResponseDetails Response { get; set; }
    }
    /// <summary>
    /// College.
    /// </summary>
    public class College : BaseViewModel
    {
        [JsonProperty(PropertyName = "id")]
        public string ID { get; set; }

        //[JsonProperty(PropertyName = "name")]
        //public string Title { get; set; }
        private string _title;
        [JsonProperty(PropertyName = "name")]
        public string Title
        {
            get { return _title; }
            set { _title = value; OnPropertyChanged(); }
        }
        private bool _isSelected;
        public bool IsSelected
        {
            get { return _isSelected; }
            set { _isSelected = value; OnPropertyChanged(); }
        }

    }



    public class CommonBO : BaseViewModel
    {
        [JsonProperty(PropertyName = "id")]
        public string ID { get; set; }

        //[JsonProperty(PropertyName = "name")]
        //public string Title { get; set; }
        private string _title;
        [JsonProperty(PropertyName = "name")]
        public string Title
        {
            get { return _title; }
            set { _title = value; OnPropertyChanged(); }
        }
        private bool _isSelected;
        public bool IsSelected
        {
            get { return _isSelected; }
            set { _isSelected = value; OnPropertyChanged(); }
        }

    }


    #endregion


    #region YearOfCompletion

    public class YearOfCompletionResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public YearOfCompletionResponseText responseText { get; set; }
    }

    public class YearOfCompletionResponseText
    {
        public List<Yearofcompletion> yearofcompletion { get; set; }
    }

    public class Yearofcompletion
    {
        public int id { get; set; }
        public string name { get; set; }
    }

    #endregion

    #region Comments ResponseText

    public class CommentsResponseText
    {
        public string code { get; set; }
        public string message { get; set; }
        public string responseText { get; set; }
    }

    #endregion

    #region View Candidate Previous Comments

    public class ViewPreviousComments
    {
        public string code { get; set; }
        public string message { get; set; }
        [JsonProperty(PropertyName = "responseText")]
        public List<ViewCommentsResponse> CommentsDetails { get; set; }
    }



    public class CommentsListResponseData
    {
        public string code { get; set; }
        public string message { get; set; }
        public Responsetext responseText { get; set; }
    }

    public class Responsetext
    {
        public List<Recruitercommentsdetail>  RecruiterCommentsDetails { get; set; }
    }

    public class Recruitercommentsdetail
    {
        private string _byName;
        public string fullname
        {
            get { return "By " + _byName + " at "; }
            set { _byName = value; }
        }
        public string recruiter_comments { get; set; }
        public string created_at { get; set; }
    }


    public class ViewCommentsResponse
    {

        private string _byName;
        public string fullname
        {
            get { return "By " + _byName + " at "; }
            set { _byName = value; }
        }
        public string recruiter_comments { get; set; }
        public string created_at { get; set; }
    }

    #endregion

    #region company List Master Table


    public class CompanydetailsResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public CompanyListData ResponseText { get; set; }

    }

    public class CompanyListData
    {
        public List<Companylist> companylist { get; set; }
    }

    public class Companylist : BaseViewModel
    {
        public int id { get; set; }
        public string name { get; set; }
        public string address { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string country { get; set; }
        // public Companylogo companylogo { get; set; }
        private Companylogo _companylogo;
        [JsonProperty(PropertyName = "companylogo")]
        public Companylogo companylogo
        {
            get
            { return _companylogo; }
            set
            {
                if (value != null)
                {
                    _companylogo = value;
                }
                else
                {
                    _companylogo = new Companylogo();
                    _companylogo.isNOImage = true;
                    _companylogo.s3ID = (string)Application.Current.Resources["NoImageAvailable"];

                    //_companylogo.S3_ID = string.Empty;

                }
                OnPropertyChanged();
            }

        }
        public Citys citys { get; set; }
        public Districts districts { get; set; }
        private string _combineaddress;
        public string CombineAddress
        {
            get { return _combineaddress; }
            set { _combineaddress = value; OnPropertyChanged(); }
        }
    }

    public class Companylogo : BaseViewModel
    {
        public int id { get; set; }
        public string collegecompany_id { get; set; }
        private string _s3ID;
        public bool isNOImage { get; set; }
        [JsonProperty(PropertyName = "s3_id")]
        public string s3ID
        {
            get { return _s3ID; }
            set
            {

                if (isNOImage)
                {

                    _s3ID = value;
                    //_companylogo.S3_ID = string.Empty;

                }
                else
                {

                    if(!string.IsNullOrEmpty(value))
                    {
                        _s3ID = S3Manager.GeneratePreSignedURL(AmazonS3BucketDetails.CompanyLogoBucket, value, 5);
                    }else
                    {
                        _s3ID = (string)Application.Current.Resources["NoImageAvailable"];
                    }

                  


                }
                OnPropertyChanged();
            }


        }

    }


    /// <summary>
    /// University response data.
    /// </summary>

    /// <summary>
    /// University.
    /// </summary>


    public class CompanylogoRequest
    {
        [JsonProperty(PropertyName = "id")]
        public int ID { get; set; }

        [JsonProperty(PropertyName = "collegecompany_id")]
        public int CollegeCompanyID { get; set; }





    }
    #endregion



}
