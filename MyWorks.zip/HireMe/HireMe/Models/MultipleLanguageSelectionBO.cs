﻿using System;
using SQLite;

namespace HireMe.DataLayer.Models
{
    public class MultipleLanguageSelectionBO
    {
        [PrimaryKey, AutoIncrement]
        public string ID { get; set; }
        public string SearchName { get; set; }
        //public string LanguageTitle { get; set; }
        private string languageTitle;

        public string LanguageTitle
        {
            get { return languageTitle; }
            set { languageTitle = value; }
        }

        public string LanguageID { get; set; }
        public int IsRead { get; set; }
        public int IsWrite { get; set; }
        public int IsSpeak { get; set; }
        public bool IsSelected { get; set; }
        public DateTime CreatedOn { get; set; }
    }
}
