﻿using HireMe.Models;
using Newtonsoft.Json;

namespace HireMe
{
    /// <summary>
    /// College table request data.
    /// </summary>
	public class CollegeTableRequestData :BaseRequestDTO
    {

        [JsonProperty(PropertyName = "university_id")]
        public string UniversityID { get; set; }
      
    }

}
