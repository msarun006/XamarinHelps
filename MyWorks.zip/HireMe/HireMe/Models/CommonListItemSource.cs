﻿namespace HireMe
{
    public class CommonListItemSource
	{


		public string ID
		{
			get;
			set;
		}
		public string Title
		{
			get;
			set;
		}


		public string fieldType;

        public string educational_level { get; set; }

    }
}
