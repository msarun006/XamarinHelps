﻿using MvvmHelpers;
using Newtonsoft.Json;

namespace HireMe.Models
{
    public class BaseRequestDTO : BaseViewModel
    {
        [JsonProperty(PropertyName = "token")]
        public string Token { get; set; }

        [JsonProperty(PropertyName = "hiremee_id")]
        public string HiremeeID { get; set; }

        [JsonProperty(PropertyName = "RefreshToken")]
        public string RefreshToken { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="T:HireMe.BaseRequestDTO"/> class.
        /// </summary>
        public BaseRequestDTO()
        {
            if (AppSessionData.ActiveToken != null)
            {
                //Token = AppSessionData.ActiveToken.Token;
                HiremeeID = AppSessionData.ActiveToken.HireMeID;
               // RefreshToken = AppPreferences.RefreshToken;
                // throw new Exception("No token found, Please login to application");
                // Navigate To Login Page;
            }
            //else
            //{
            //    TimeZoneInfo localTime = TimeZoneInfo.Local;

            //    // DateTime Expire = Convert.ToDateTime(AppSessionData.TokenExpires); // DateTime.ParseExact(AppSessionData.TokenExpires, "dd-MM-yyyy hh:mm:ss:tt",

            //    System.Globalization.CultureInfo cultureinfo = new System.Globalization.CultureInfo("en-US");
            //    //TimeSpan time = TimeSpan.FromSeconds(Convert.ToDouble(AppSessionData.ActiveToken.Expire));
            //    //DateTime tmpTokenExpiry = new DateTime(time.Ticks);
            //    DateTime Expire = Convert.ToDateTime(AppSessionData.ActiveToken.Expire);// DateTime.Parse(tmpTokenExpiry.ToString(), cultureinfo); //DateTime.ParseExact(AppSessionData.TokenExpires, "M/dd/yyyy hh:mm:ss:tt", CultureInfo.);

            //    TimeSpan localTimeDifference = TimeZoneInfo.Local.GetUtcOffset(Expire);
            //    Expire.AddMinutes(localTimeDifference.TotalMinutes);
            //    if (Convert.ToDateTime(Expire) < DateTime.Now)
            //    {
            //        Task.Run(() => RefreshTokenAsync()).Wait();
            //        Task.Delay(1000);
            //        //App.Current.MainPage = new NavigationPage(new LoginPageNew());
            //    }
            //    else
            //    {
            //        Token = AppSessionData.ActiveToken.Token;
            //        HiremeeID = AppSessionData.ActiveToken.HireMeID;
            //        RefreshToken = AppPreferences.RefreshToken;
            //    }

            //    //TimeSpan localTimeDifference = TimeZoneInfo.Utc.BaseUtcOffset;
            //    //Expire= Expire.AddMinutes(localTimeDifference.TotalMinutes);

            //}
        }

        public BaseRequestDTO(string token, string hiremeeid, string _RefreshToken)
        {
            //Token = token;
            HiremeeID = hiremeeid;
            RefreshToken = _RefreshToken;
        }

        /// <summary>
        /// Refreshs the token async.
        /// </summary>
        /// <returns>The token async.</returns>
        //async Task RefreshTokenAsync()
        //{
        //    try
        //    {
        //        HttpCommonService _commonservice = new HttpCommonService();
        //        var baserequest = new BaseRequestDTO(AppSessionData.ActiveToken.Token, AppSessionData.ActiveToken.HireMeID, AppSessionData.ActiveToken.RefreshToken);
        //        RegenerateTokenResponseBO responsetoken = null;
        //        responsetoken = await _commonservice.PostAsync<RegenerateTokenResponseBO, BaseRequestDTO>(APIData.API_BASE_URL + APIMethods.Regeneratetoken, baserequest);
        //        if (responsetoken != null && responsetoken.code == "200")
        //        {
        //            ApplicationToken token = new ApplicationToken();
        //            HiremeeID = responsetoken.Response.HireMeID;
        //            Token = responsetoken.Response.Token;
        //            token.HireMeID = responsetoken.Response.HireMeID;
        //            token.Token = responsetoken.Response.Token;
        //            token.RefreshToken = responsetoken.Response.Refreshtoken;
        //            token.Expire = DateTime.Now.AddSeconds(Convert.ToDouble(responsetoken.Response.Expire));
        //            token.EmailID = AppSessionData.ActiveToken.EmailID;
        //            token.UserType = AppSessionData.ActiveToken.UserType;
        //            AppSessionData.ActiveToken = token;
        //        }
        //        else //if (responsetoken.Code == "401")
        //        {
        //            //UserDialogs.Instance.Toast(MessageStringConstants.SessionExpiered);
        //            //  App.Current.MainPage = new NavigationPage(new LoginPageNew());
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        SendErrorMessageToServer(ex, "BaseRequestDTO.RefreshToken");
        //    }

        //}

        //#region SendErrorMessageToServer
        //public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        //{
        //    CommonException _commonexception = new CommonException();
        //    _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        //}
        //#endregion


    }
}
