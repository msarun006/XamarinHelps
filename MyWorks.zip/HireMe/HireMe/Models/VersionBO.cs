﻿namespace HireMe.Models
{

    public class VersionRequest
    {
        public string ostype { get; set; }
    }
    public class VersionResponse
    {
        public string code { get; set; }
        public ResponseText data { get; set; }
    }

    public class ResponseText
    {
        public string version_name { get; set; }
        public string release_date { get; set; }
        public string os_type { get; set; }
    }

}
