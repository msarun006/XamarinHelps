﻿using SQLite;
using System;

namespace HireMe.DataLayer.Models
{
    public class MultipleSelectionBO
    {
        [PrimaryKey, AutoIncrement]
        public int ID { get; set; }
        public string SearchName { get; set; }
        public string SelectedItemID { get; set; }
        public string Title { get; set; }
        public bool IsSelected { get; set; }
        public DateTime CreatedOn { get; set; }
    }

}
