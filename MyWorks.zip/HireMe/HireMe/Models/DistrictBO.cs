﻿using HireMe.Models;
using Newtonsoft.Json;
using System.Collections.Generic;
using MvvmHelpers;

namespace HireMe
{
    
        #region District Request Data
        public class DistrictRequestData :BaseRequestDTO
        {
            [JsonProperty(PropertyName = "state_id")]
            public string StateID { get; set; }
        }

        #endregion

        #region District Response Data
        public class DistrictResponseDetails : DistrictRequestData
    {
            [JsonProperty(PropertyName = "data")]
            public List<District> Response { get; set; }

        }

        public class DistrictResponseData
        {
            public string code { get; set; }
            public string message { get; set; }

            [JsonProperty(PropertyName = "responseText")]
            public DistrictResponseDetails Response { get; set; }
        }

        public class District : BaseViewModel
        {



        [JsonProperty(PropertyName = "id")]
        public string ID { get; set; }





        [JsonProperty(PropertyName = "name")]
		public string Title { get { return title;} set { title = value; OnPropertyChanged();} }
		private string title { get; set; }

       
        }


        #endregion
    
}
