﻿using Newtonsoft.Json;
namespace HireMe.Models
{
    public class SendOTPRequest : BaseRequestDTO
    {
        [JsonProperty(PropertyName = "email_address")]
        public string EmailID { get; set; }
    }


    public class TimeZone
    {
        public string date { get; set; }
        public int timezone_type { get; set; }
        public string timezone { get; set; }
    }

    public class SendOTPResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        public string responseText { get; set; }
        public string status { get; set; }
        public string process { get; set; }
        public TimeZone time { get; set; }
    }

    public class OTPVerificationRequest:BaseRequestDTO
    {
        [JsonProperty(PropertyName = "email_address")]
        public string EmailID { get; set; }

        [JsonProperty(PropertyName = "otp")]
        public string OTP { get; set; }
    }
}
