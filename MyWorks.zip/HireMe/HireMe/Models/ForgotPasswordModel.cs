﻿using Newtonsoft.Json;

namespace HireMe.Models
{
    #region ForgotPassword Request Data
    /// <summary>
    /// Forgot passwords request data.
    /// </summary>
    public class ForgotPasswordRequestData
    {
        [JsonProperty(PropertyName = "email_address")]
        public string EmailAddress { get; set; }
        //public string email { get; set; }
        //public string mobilenumber { get; set; }

        public string key_param { get; set; }
        public int type { get; set; }

    }
    #endregion
        
    #region ForgotPassword Response Data

    /// <summary>
    /// Forgot passwords response data.
    /// </summary>
    //public class ForgotPasswordFullResponse
    //{
    //    [JsonProperty(PropertyName = "code")]
    //    public string Code { get; set; }

    //    [JsonProperty(PropertyName = "message")]
    //    public string Message { get; set; }

    //    [JsonProperty(PropertyName = "responseText")]
    //    public ForgotPasswordData Response { get; set; }
        
    //}

    public class ForgotPasswordData
    {
        public string email { get; set; }
        public string hiremee_id { get; set; }
        public string password { get; set; }

        public string mobile_number { get; set; }
        public int register_id { get; set; }
        public int resend { get; set; }
        public string message { get; set; }
        public string otp { get; set; }
        
    }

    public class ForgotPasswordFullResponse
    {
        public string code { get; set; }
        public string message { get; set; }
        //public ForgotPasswordData responseText { get; set; } //Need to change reponse type as response for both mobile type and email type . Ask john
        //public ForgotPasswordData response { get; set; }

        public ForgotPasswordNewResponse responseText { get; set; }


    }

    public class ForgotPasswordNewResponse
    {
        public string register_id { get; set; }
    }










    /// <summary>
    /// Forgot password data.
    /// </summary>
    //public class ForgotPasswordData
    //{
    //    [JsonProperty(PropertyName = "email")]
    //    public string Email { get; set; }

    //    [JsonProperty(PropertyName = "hiremee_id")]
    //    public string HiremeeID { get; set; }

    //}
    #endregion


}
