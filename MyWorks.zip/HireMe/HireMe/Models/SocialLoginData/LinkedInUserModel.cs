﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HireMe.Models.SocialLoginData
{
    //public class LinkedInUserModel
    //{
    //    public string Id { get; set; }
    //    public string FirstName { get; set; }
    //    public string LastName { get; set; }

    //    [JsonProperty(PropertyName = "email-address")]
    //    public string EmailID { get; set; }
    //}
    public class LinkedInAPIResponse
    {
        public LinkedInUserModel person { get; set; }
    }
    public class LinkedInUserModel
    {
        public string id { get; set; }

        [JsonProperty(PropertyName = "first-name")]
        public string firstname { get; set; }


        [JsonProperty(PropertyName = "email-address")]
        public string emailaddress { get; set; }


        [JsonProperty(PropertyName = "last-name")]
        public string lastname { get; set; }
    }
}
