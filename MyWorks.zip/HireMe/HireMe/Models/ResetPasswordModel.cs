﻿using Newtonsoft.Json;

namespace HireMe.Models
{
    #region Reset Password Request Data
    public class ResetPasswordRequestData
    {
        public string register_id { get; set; }
        public string email_address { get; set; }
        public string NewPassword { get; set; }
        public string ConfirmPassword { get; set; }
    }
    #endregion

    #region Reset Password Response Data
    public class ResetPasswordResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string Code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string Message { get; set; }

        [JsonProperty(PropertyName = "response")]
        public string Response { get; set; }
    }
    #endregion
    public class ResetPasswordData : ResetPasswordRequestData
    {


    }
}