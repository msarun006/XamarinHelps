﻿using Newtonsoft.Json;

namespace HireMe.Models
{
    #region S3Credentials Request Data
    /// <summary>
    /// S3 credentials request data.
    /// </summary>
	public class S3CredentialsRequestData : BaseRequestDTO
    {


        [JsonProperty(PropertyName = "userResource")]
        public string S3CredentialsTypeID { get; set; }


    }

    #endregion

    #region S3Credentials Response Data

    /// <summary>
    /// S3 credentials response data.
    /// </summary>
    public class S3CredentialsResponseData
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public S3Credentials Response { get; set; }
    }

    public class S3Credentials : S3CredentialsRequestData
    {
        [JsonProperty(PropertyName = "systemname")]
        public string SystemName { get; set; }

        [JsonProperty(PropertyName = "s3accesskeyid")]
        public string S3AccessKeyid { get; set; }

        [JsonProperty(PropertyName = "s3secretaccesskey")]
        public string S3SecretAccesskey { get; set; }

        [JsonProperty(PropertyName = "baseurl")]
        public string BaseURL { get; set; }

    }


    #endregion

}
