﻿using HireMe.Models;
using MvvmHelpers;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace HireMe
{

    #region Specialization Request Data
    public class SpecializationRequestData : BaseRequestDTO
    {
        [JsonProperty(PropertyName = "course_id")]
        public string CourseID { get; set; }
    }

    #endregion

    #region Specialization Response Data
    public class SpecializationResponseDetails : SpecializationRequestData
    {
        [JsonProperty(PropertyName = "data")]
        public List<Specialization> Response { get; set; }

    }

    public class SpecializationResponseData
    {
        public string code { get; set; }
        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public SpecializationResponseDetails Response { get; set; }
    }

    public class Specialization : BaseViewModel
    {
        [JsonProperty(PropertyName = "id")]
        public string ID { get; set; }

        //[JsonProperty(PropertyName = "name")]
        //public string Title { get; set; }
        private string _title;
        [JsonProperty(PropertyName = "name")]
        public string Title
        {
            get { return _title; }
            set { _title = value; OnPropertyChanged(); }
        }

        private bool _isSelected;
        public bool IsSelected
        {
            get { return _isSelected; }
            set { _isSelected = value; OnPropertyChanged(); }
        }


    }


    #endregion
   

}
