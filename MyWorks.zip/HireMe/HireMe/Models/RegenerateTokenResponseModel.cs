﻿using Newtonsoft.Json;

namespace HireMe.Models
{
    public class RegenerateTokenResponseBO
    {
        [JsonProperty(PropertyName = "code")]
        public string code { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string message { get; set; }

        [JsonProperty(PropertyName = "responseText")]
        public SessionToken Response { get; set; }

    }

    public class SessionToken
    {

        [JsonProperty(PropertyName = "Expire")]
        public string TokenExpiry { get; set; }

        [JsonProperty(PropertyName = "hiremee_id")]
        public string HireMeID { get; set; }

        [JsonProperty(PropertyName = "Token")]
        public string TokenID { get; set; }


        public string Refreshtoken { get; set; }
    }
}
