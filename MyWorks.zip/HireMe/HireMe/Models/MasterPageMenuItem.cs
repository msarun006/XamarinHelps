﻿using System;
namespace HireMe
{
	public class MasterPageMenuItem
	{
		public string Title { get; set; }
		public string Description { get; set; }
		public Type TargetType { get; set; }
		public string IconSource { get; set; }

    }
}
