﻿using System;
using Plugin.Connectivity;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Plugin.Media;
using HireMe.UI;
using HireMe.Models;
using System.Diagnostics;
using HireMe.Views;
using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.Views.Assessment;
using HireMe.Models.SocialLoginData;
using HireMe.Services.SocialAuthentication;
using System.Threading.Tasks;
using HireMe.Views.PRO_Assessment;
using HireMe.Helpers.PRO_Assement;
[assembly: XamlCompilation(XamlCompilationOptions.Compile)]
namespace HireMe
{
    public partial class App : Application
    {

        public static byte[] CroppedImage { get; set; }
        public static String CroppedImageFilePath { get; set; }
        public static string CultureCode { get; internal set; }
        private HttpCommonService _commonservice { get; set; }
        SocialLoginRequest _socialLoginRequest { get; set; }
        public string SocialName { get; set; }


        public App()
        {

            InitializeComponent();
            try
            {//// Issue Occur in iOS Application Launch
                AppPreferences.Screenshotcount = "0";
            }
            catch (Exception ex)
            {

            }
            AppPreferences.Is_HireMee_PRO_User = false;
            AppPreferences.IsPRO_Assesment_TimerRunning = true;


            if (Xamarin.Forms.Device.RuntimePlatform.Equals("Android"))
            {
                GoogleAnalyticService.Track_App_Page("Android Main");
            }
            else
            {
                GoogleAnalyticService.Track_App_Page("iOS Main Page");
            }
            CrossMedia.Current.Initialize();


            // MainPage = new NavigationPage(new AssesmentTakePhotoPage());

            #region Page Navigation Prefereneces
            if (AppPreferences.IsvalidURI != "" && AppPreferences.IsvalidURI != APIData.API_BASE_URL)
            {
                AppPreferences.IsvalidURI = string.Empty;
                AppPreferences.IsLoggeedIn = false;
                AppPreferences.IsPasscode = false;
                AppPreferences.IsPasscodeValue = string.Empty;
                var page = new NavigationPage(new LoginPageNew());
                Application.Current.MainPage = page;
            }
            else
            {
                if (MessageStringConstants.EmailLink == true)
                {
                    var page = new PRO_TestPinPage();
                    MainPage = new NavigationPage(page);
                }
                else if (AppPreferences.IsCollegeViseRegistraiton == true)
                {
                    var page = new CollegeViceRegistrationPage();
                    MainPage = new NavigationPage(page);
                }
                else if (AppPreferences.IsPasswordReset == true)
                {
                    var page = new ResetPasswordPage();
                    MainPage = new NavigationPage(page);
                }
                //  Before call following code for completed Video, doc upload functionlaity
                else if (AppPreferences.IsFirstRun == true)
                {
                    AppPreferences.IsFBLoggeedIn = false;
                    AppPreferences.IsGoogleLoggedIn = false;
                    AppPreferences.IsLinkedInLoggedIn = false;
                    var page = new UserRegistration_mobile();
                    MainPage = new NavigationPage(page);
                }
                else if (AppPreferences.IsCollege == true)
                {
                    var page = new NavigationPage(new CollegeDashboardPage());
                    MainPage = page;

                }
                else if (AppPreferences.isManualSync)
                {
                    AppPreferences.isManualSync = false;
                    var page = new NavigationPage(new ManualDataSyncupPage());
                    MainPage = page;
                }
                else if (AppPreferences.IsLoggeedIn == true)
                {
                    #region Normal LoggedIN
                    if (Convert.ToBoolean(AppPreferences.IsDashboard))
                    {

                        bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                        if (isNetworkAvailable)
                        {
                            if (AppSessionData.ActiveToken != null)
                                if (AppPreferences.IsPasscode)
                                {
                                    var page = new AppLock("Check Passcode", "Dashboard");
                                    MainPage = new NavigationPage(page);
                                }
                                else
                                {
                                    var page = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                                    //var page = new CollegeDashboardPage();
                                    MainPage = page;
                                }
                            return;
                        }
                        else
                        {
                            var page = new InternetUnavailable("Dashboard");
                            MainPage = new NavigationPage(page);
                            return;
                        }
                    }
                    else if (AppPreferences.IsProfileCompleted == true && AppPreferences.IsEducationCompleted)
                    {
                        if (AppPreferences.IsVideosUploaded == true)
                        {
                            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                            if (isNetworkAvailable)
                            {
                                if (AppPreferences.IsPasscode)
                                {
                                    var page = new AppLock("Check Passcode", "Dashboard");
                                    MainPage = new NavigationPage(page);
                                    // PopupNavigation.PushAsync(new LockScreen("Check Passcode", "Dashboard"));
                                    // MainPage = new PasscodeVerificationPage("Check Passcode", "Dashboard");
                                }
                                else
                                {
                                    MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                                }
                            }
                            else
                            {
                                MainPage = new NavigationPage(new InternetUnavailable("Dashboard"));
                            }
                        }
                        else
                        {
                            //Show Videos Page
                            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                            if (isNetworkAvailable)
                            {
                                if (AppPreferences.IsPasscode)
                                {
                                    //MainPage = new PasscodeVerificationPage("Check Passcode", "Dashboard");
                                    var page = new AppLock("Check Passcode", "VideoProfilePage");
                                    MainPage = new NavigationPage(page);
                                }
                                else
                                {
                                    //var page = new VideoProfilePage(true);
                                    //MainPage = new NavigationPage(page);
                                    MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                                }
                            }
                            else
                            {
                                MainPage = new NavigationPage(new InternetUnavailable("VideoProfilePage"));
                            }
                        }
                    }
                    else
                    {
                        bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                        if (isNetworkAvailable)
                        {
                            if (AppPreferences.IsPasscode)
                            {
                                //MainPage = new PasscodeVerificationPage("Check Passcode", "Dashboard");
                                var page = new AppLock("Check Passcode", "SeekerPersonalAndEducationPage");
                                MainPage = new NavigationPage(page);
                            }
                            else
                            {
                                var page = new SeekerPersonalAndEducationPage(AppPreferences.IsProfileCompleted);
                                MainPage = new NavigationPage(page);
                            }
                        }
                        else if (!isNetworkAvailable && AppPreferences.IsFirstRun == false)
                        {
                            if (AppPreferences.IsPasscode)
                            {
                                var page = new AppLock("Check Passcode", "SeekerPersonalAndEducationPage");
                                MainPage = new NavigationPage(page);
                                //MainPage = new PasscodeVerificationPage("Check Passcode", "Dashboard");
                            }
                            else
                            {
                                MainPage = new NavigationPage(new SeekerPersonalAndEducationPage(true));
                            }
                        }
                        else
                        {
                            MainPage = new NavigationPage(new InternetUnavailable("SeekerPersonalAndEducationPage"));
                        }
                    }
                    #endregion
                }
                else if (AppPreferences.IsFBLoggeedIn == true)
                {
                    #region FB LoggedIn
                    if (Convert.ToBoolean(AppPreferences.IsDashboard))
                    {
                        bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                        if (isNetworkAvailable)
                        {
                            if (AppSessionData.ActiveToken != null)
                                if (AppPreferences.IsPasscode)
                                {
                                    var page = new AppLock("Check Passcode", "Dashboard");
                                    MainPage = new NavigationPage(page);
                                }
                                else
                                {
                                    var page = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                                    //var page = new CollegeDashboardPage();
                                    MainPage = page;
                                }
                            return;
                        }
                        else
                        {
                            var page = new InternetUnavailable("Dashboard");
                            MainPage = new NavigationPage(page);
                            return;
                        }
                    }
                    else if (AppPreferences.IsProfileCompleted == true && AppPreferences.IsEducationCompleted)
                    {
                        if (AppPreferences.IsVideosUploaded == true)
                        {
                            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                            if (isNetworkAvailable)
                            {
                                if (AppPreferences.IsPasscode)
                                {
                                    var page = new AppLock("Check Passcode", "Dashboard");
                                    MainPage = new NavigationPage(page);
                                    // PopupNavigation.PushAsync(new LockScreen("Check Passcode", "Dashboard"));
                                    // MainPage = new PasscodeVerificationPage("Check Passcode", "Dashboard");
                                }
                                else
                                {
                                    var page = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                                    MainPage = page;
                                }
                            }
                            else
                            {
                                var page = new InternetUnavailable("Dashboard");
                                MainPage = new NavigationPage(page);
                            }
                        }
                        else
                        {
                            //Show Videos Page
                            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                            if (isNetworkAvailable)
                            {
                                if (AppPreferences.IsPasscode)
                                {
                                    //MainPage = new PasscodeVerificationPage("Check Passcode", "Dashboard");
                                    var page = new AppLock("Check Passcode", "VideoProfilePage");
                                    MainPage = new NavigationPage(page);
                                }
                                else
                                {
                                    //var page = new VideoProfilePage(true);
                                    //MainPage = new NavigationPage(page);
                                    MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                                }
                            }
                            else
                            {
                                var page = new InternetUnavailable("VideoProfilePage");
                                MainPage = new NavigationPage(page);
                            }
                        }
                    }
                    else
                    {
                        //Show Profile page
                        bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                        if (isNetworkAvailable)
                        {
                            if (AppPreferences.IsPasscode)
                            {
                                //MainPage = new PasscodeVerificationPage("Check Passcode", "Dashboard");
                                var page = new AppLock("Check Passcode", "SeekerPersonalAndEducationPage");
                                MainPage = new NavigationPage(page);
                            }
                            else
                            {
                                var page = new SeekerPersonalAndEducationPage(AppPreferences.IsProfileCompleted);
                                MainPage = new NavigationPage(page);
                            }
                        }
                        else if (!isNetworkAvailable && AppPreferences.IsFirstRun == false)
                        {
                            if (AppPreferences.IsPasscode)
                            {
                                var page = new AppLock("Check Passcode", "SeekerPersonalAndEducationPage");
                                MainPage = new NavigationPage(page);
                                //MainPage = new PasscodeVerificationPage("Check Passcode", "Dashboard");
                            }
                            else
                            {
                                MainPage = new NavigationPage(new SeekerPersonalAndEducationPage(true));
                            }
                        }
                        else
                        {
                            MainPage = new NavigationPage(new InternetUnavailable("SeekerPersonalAndEducationPage"));
                        }
                    }
                    #endregion
                }
                else if (AppPreferences.IsGoogleLoggedIn == true)
                {
                    #region Google LoggedIn
                    if (Convert.ToBoolean(AppPreferences.IsDashboard))
                    {
                        bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                        if (isNetworkAvailable)
                        {
                            if (AppSessionData.ActiveToken != null)
                                if (AppPreferences.IsPasscode)
                                {
                                    var page = new AppLock("Check Passcode", "Dashboard");
                                    MainPage = new NavigationPage(page);
                                }
                                else
                                {
                                    var page = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                                    //var page = new CollegeDashboardPage();
                                    MainPage = page;
                                }
                            return;
                        }
                        else
                        {
                            var page = new InternetUnavailable("Dashboard");
                            MainPage = new NavigationPage(page);
                            return;
                        }
                    }
                    else if (AppPreferences.IsProfileCompleted == true && AppPreferences.IsEducationCompleted)
                    {
                        if (AppPreferences.IsVideosUploaded == true)
                        {
                            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                            if (isNetworkAvailable)
                            {
                                if (AppPreferences.IsPasscode)
                                {
                                    var page = new AppLock("Check Passcode", "Dashboard");
                                    MainPage = new NavigationPage(page);
                                    // PopupNavigation.PushAsync(new LockScreen("Check Passcode", "Dashboard"));
                                    // MainPage = new PasscodeVerificationPage("Check Passcode", "Dashboard");
                                }
                                else
                                {
                                    var page = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                                    MainPage = page;
                                }
                            }
                            else
                            {
                                var page = new InternetUnavailable("Dashboard");
                                MainPage = new NavigationPage(page);
                            }
                        }
                        else
                        {
                            //Show Videos Page
                            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                            if (isNetworkAvailable)
                            {
                                if (AppPreferences.IsPasscode)
                                {
                                    //MainPage = new PasscodeVerificationPage("Check Passcode", "Dashboard");
                                    var page = new AppLock("Check Passcode", "VideoProfilePage");
                                    MainPage = new NavigationPage(page);
                                }
                                else
                                {
                                    MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                                }
                            }
                            else
                            {
                                MainPage = new NavigationPage(new InternetUnavailable("VideoProfilePage"));
                            }
                        }
                    }
                    else
                    {
                        bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                        if (isNetworkAvailable)
                        {
                            if (AppPreferences.IsPasscode)
                            {
                                //MainPage = new PasscodeVerificationPage("Check Passcode", "Dashboard");
                                var page = new AppLock("Check Passcode", "SeekerPersonalAndEducationPage");
                                MainPage = new NavigationPage(page);
                            }
                            else
                            {
                                var page = new SeekerPersonalAndEducationPage(AppPreferences.IsProfileCompleted);
                                MainPage = new NavigationPage(page);
                            }
                        }
                        else if (!isNetworkAvailable && AppPreferences.IsFirstRun == false)
                        {
                            if (AppPreferences.IsPasscode)
                            {
                                var page = new AppLock("Check Passcode", "SeekerPersonalAndEducationPage");
                                MainPage = new NavigationPage(page);
                                //MainPage = new PasscodeVerificationPage("Check Passcode", "Dashboard");
                            }
                            else
                            {
                                MainPage = new NavigationPage(new SeekerPersonalAndEducationPage(true));
                            }
                        }
                        else
                        {
                            MainPage = new NavigationPage(new InternetUnavailable("SeekerPersonalAndEducationPage"));
                        }
                    }
                    #endregion
                }
                else
                {
                    MainPage = new NavigationPage(new LoginPageNew());
                }
            }
            #endregion
        }

        #region NavigateToPage
        public void NavigateToPage(LoginResponseData result)
        {
            CommonLoginResponse _commonLoginResponse = new CommonLoginResponse();
            _commonLoginResponse.NavigateToNextPage(result);
        }
        #endregion

        public void LinkedInLoggedIn(string id, string first_name, string last_name, string email)
        {
            Xamarin.Forms.Device.BeginInvokeOnMainThread(async () =>
            {
                await Task.Delay(500);
                UserDialogs.Instance.ShowLoading();
                LinkedInUserModel objLinkedInUserModel = new LinkedInUserModel();
                objLinkedInUserModel.id = id;
                objLinkedInUserModel.firstname = first_name;
                objLinkedInUserModel.lastname = last_name;
                objLinkedInUserModel.emailaddress = email;
                AppPreferences.LinkedInUserDetails = objLinkedInUserModel;
                if (AppPreferences.LinkedInUserDetails != null)
                {
                    SocialLinkedInLoginAPI();
                }
            });
        }

        public async void SocialLinkedInLoginAPI()
        {
            try
            {
                UserDialogs.Instance.ShowLoading();
                _commonservice = new HttpCommonService();
                _socialLoginRequest = new SocialLoginRequest();
                SocialName = string.Empty;
                #region  Social Account Login
                string DeviceID, DeviceModel, DeviceOS;
                DeviceID = Utilities.GetDeviceID();
                DeviceModel = Utilities.GetDeviceModel();
                DeviceOS = Xamarin.Forms.Device.RuntimePlatform;
                if (!(string.IsNullOrEmpty(DeviceID)) && !(string.IsNullOrEmpty(DeviceModel)) && !(string.IsNullOrEmpty(DeviceOS) && !(string.IsNullOrEmpty(AppPreferences.UserValues.register_id.ToString()))))
                {
                    _socialLoginRequest.DeviceID = DeviceID;
                    _socialLoginRequest.DeviceModel = DeviceModel;
                    _socialLoginRequest.DeviceOS = DeviceOS;
                }
                string SocialFullName = AppPreferences.LinkedInUserDetails.firstname + " " + AppPreferences.LinkedInUserDetails.lastname;
                SocialName = SocialFullName;
                _socialLoginRequest.SocialID = AppPreferences.LinkedInUserDetails.id;
                _socialLoginRequest.emailAddress = AppPreferences.LinkedInUserDetails.emailaddress;
                _socialLoginRequest.ProviderType = "LinkedIn";

                var result = await _commonservice.PostAsync<LoginResponseData, SocialLoginRequest>(APIData.API_BASE_URL + APIMethods.SocialLogin_v7, _socialLoginRequest);
                if (result != null)
                {

                    if (result.code == "200")
                    {
                        
                        AppPreferences.IsLinkedInLoggedIn = false;
                        NavigateToPage(result);
                    }
                    else if (result.code == "505")
                    {
                        AppPreferences.IsLinkedInLoggedIn = false;
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerNotReachable);
                    }
                    else
                    {
                        AppPreferences.IsLinkedInLoggedIn = true;
                        UserDialogs.Instance.HideLoading();
                        var page = new NavigationPage(new UserRegistration_mobile());
                        MainPage = page;
                    }
                    UserDialogs.Instance.HideLoading();
                }
                else
                {

                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    AppPreferences.IsLinkedInLoggedIn = false;
                }


                #endregion
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                AppPreferences.IsLinkedInLoggedIn = false;
                Debug.WriteLine(ex.Message);
            }
        }



        public void FBLoggedIn(string id, string first_name, string last_name, string email)
        {
            Xamarin.Forms.Device.BeginInvokeOnMainThread(() =>
            {
                UserDialogs.Instance.ShowLoading();
                FacebookUserModel objFacebookUserModel = new FacebookUserModel();
                objFacebookUserModel.id = id;
                objFacebookUserModel.first_name = first_name;
                objFacebookUserModel.last_name = last_name;
                objFacebookUserModel.email = email;
                AppPreferences.FacebookUserDetails = objFacebookUserModel;
                DependencyService.Get<IFacebookManager>().Logout();
                if (AppPreferences.FacebookUserDetails != null)
                {
                    SocialFBLoginAPI();
                }
            });
        }

        public async void SocialFBLoginAPI()
        {
            try
            {

                UserDialogs.Instance.ShowLoading();
                _commonservice = new HttpCommonService();
                _socialLoginRequest = new SocialLoginRequest();
                SocialName = string.Empty;
                #region  Social Account Login
                string DeviceID, DeviceModel, DeviceOS;
                DeviceID = Utilities.GetDeviceID();
                DeviceModel = Utilities.GetDeviceModel();
                DeviceOS = Xamarin.Forms.Device.RuntimePlatform;
                if (!(string.IsNullOrEmpty(DeviceID)) && !(string.IsNullOrEmpty(DeviceModel)) && !(string.IsNullOrEmpty(DeviceOS) && !(string.IsNullOrEmpty(AppPreferences.UserValues.register_id.ToString()))))
                {
                    _socialLoginRequest.DeviceID = DeviceID;
                    _socialLoginRequest.DeviceModel = DeviceModel;
                    _socialLoginRequest.DeviceOS = DeviceOS;
                }
                string FacebookFullName = AppPreferences.FacebookUserDetails.first_name + " " + AppPreferences.FacebookUserDetails.last_name;
                SocialName = FacebookFullName;
                _socialLoginRequest.SocialID = AppPreferences.FacebookUserDetails.id;
                _socialLoginRequest.emailAddress = AppPreferences.FacebookUserDetails.email;
                _socialLoginRequest.ProviderType = "Facebook";

                var result = await _commonservice.PostAsync<LoginResponseData, SocialLoginRequest>(APIData.API_BASE_URL + APIMethods.SocialLogin_v7, _socialLoginRequest);
                if (result != null)
                {

                    if (result.code == "200")
                    {
                        AppPreferences.IsFBLoggeedIn = false;
                        NavigateToPage(result);
                    }
                    else if (result.code == "505")
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerNotReachable);
                        AppPreferences.IsFBLoggeedIn = false;
                    }
                    else
                    {
                        AppPreferences.IsFBLoggeedIn = true;
                        UserDialogs.Instance.HideLoading();
                        var page = new NavigationPage(new UserRegistration_mobile());
                        MainPage = page;
                    }
                    UserDialogs.Instance.HideLoading();
                }
                else
                {

                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    AppPreferences.IsFBLoggeedIn = false;
                }

                #endregion
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                AppPreferences.IsFBLoggeedIn = false;
                Debug.WriteLine(ex.Message);
            }
        }

        public void GoogleLoggedIn(string id, string name, string email)
        {
            Xamarin.Forms.Device.BeginInvokeOnMainThread(() =>
            {
                UserDialogs.Instance.ShowLoading();
                GoogleUserModel objGoogleUserModel = new GoogleUserModel();
                objGoogleUserModel.ID = id;
                objGoogleUserModel.Name = name;
                objGoogleUserModel.Email = email;
                AppPreferences.GoogleUserDetails = objGoogleUserModel;
                DependencyService.Get<IGoogleManager>().Logout();
                if (AppPreferences.GoogleUserDetails != null)
                {
                    SocialGoogleLoginAPI();
                }
            });
        }

        public async void SocialGoogleLoginAPI()
        {
            try
            {
                _commonservice = new HttpCommonService();
                _socialLoginRequest = new SocialLoginRequest();
                #region  Google Login
                string DeviceID, DeviceModel, DeviceOS;
                DeviceID = Utilities.GetDeviceID();
                DeviceModel = Utilities.GetDeviceModel();
                DeviceOS = Xamarin.Forms.Device.RuntimePlatform;
                if (!(string.IsNullOrEmpty(DeviceID)) && !(string.IsNullOrEmpty(DeviceModel)) && !(string.IsNullOrEmpty(DeviceOS) && !(string.IsNullOrEmpty(AppPreferences.UserValues.register_id.ToString()))))
                {
                    _socialLoginRequest.DeviceID = DeviceID;
                    _socialLoginRequest.DeviceModel = DeviceModel;
                    _socialLoginRequest.DeviceOS = DeviceOS;
                }
                SocialName = AppPreferences.GoogleUserDetails.Name;
                _socialLoginRequest.SocialID = AppPreferences.GoogleUserDetails.ID;
                _socialLoginRequest.ProviderType = "Google";
                _socialLoginRequest.emailAddress = AppPreferences.GoogleUserDetails.Email;

                var result = await _commonservice.PostAsync<LoginResponseData, SocialLoginRequest>(APIData.API_BASE_URL + APIMethods.SocialLogin_v7, _socialLoginRequest);
                if (result != null)
                {
                    if (result.code == "200")
                    {
                        AppPreferences.IsGoogleLoggedIn = false;
                        NavigateToPage(result);
                    }
                    else if (result.code == "505")
                    {
                        UserDialogs.Instance.HideLoading();
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerNotReachable);
                        AppPreferences.IsGoogleLoggedIn = false;
                    }
                    else
                    {
                        AppPreferences.IsGoogleLoggedIn = true;
                        UserDialogs.Instance.HideLoading();
                        var page = new NavigationPage(new UserRegistration_mobile());
                        MainPage = page;
                    }
                }
                else
                {
                    AppPreferences.IsGoogleLoggedIn = false;
                    UserDialogs.Instance.HideLoading();
                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                }
                #endregion
            }
            catch (Exception ex)
            {
                AppPreferences.IsGoogleLoggedIn = false;
                UserDialogs.Instance.HideLoading();
                await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                Debug.WriteLine(ex.Message);
            }
        }


        public void GetPhotoforAssessment(string filePath)
        {
            try
            {
                AppPreferences.CapturedAssesmentImageFilePath = filePath;
                if (AppPreferences.Is_HireMee_PRO_User == true)
                {
                    MainPage = new NavigationPage(new PRO_ExternalDeviceStatusPage());
                }
                else
                {
                    var page = new NavigationPage(new AssesmentPhotoPreviewPage());
                    MainPage = page;
                }


            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                UserDialogs.Instance.HideLoading();
            }
        }

        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
            try
            {
                AppPreferences.IsPRO_Assesment_TimerRunning = false;
                if (AppPreferences.Is_HireMee_PRO_User == true && AppPreferences.Is_NavigationLog == true)
                {
                    if (AppPreferences.TestPinMasterData.is_window_proctering == Convert.ToString((int)Is_window_proctering.Enable))
                    {
                        PRO_CommonLog obj_NavigationLog = new PRO_CommonLog();
                        obj_NavigationLog.NavigationLog("0");
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "App.xaml.cs.OnSleep");
            }
        }
        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
        protected override void OnResume()
        {
            AppPreferences.IsPRO_Assesment_TimerRunning = true;
            try
            {
                if (AppPreferences.Is_HireMee_PRO_User == true && AppPreferences.Is_NavigationLog == true)
                {
                    if (AppPreferences.TestPinMasterData.is_window_proctering == Convert.ToString((int)Is_window_proctering.Enable))
                    {
                        PRO_CommonLog obj_NavigationLog = new PRO_CommonLog();
                        obj_NavigationLog.NavigationLog("1");
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "App.xaml.cs.OnSleep");
            }
            // Handle when your app resumes
            Debug.WriteLine("Application OnResume");
        }
    }
}
