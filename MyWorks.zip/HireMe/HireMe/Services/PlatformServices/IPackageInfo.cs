﻿namespace HireMe
{
    public interface IPackageInfo
    {
        string VersionName
        {
            get;
        }

        string VersionCode
        {
            get;
        }

        string PackageName
        {
            get;
        }
    }
}
