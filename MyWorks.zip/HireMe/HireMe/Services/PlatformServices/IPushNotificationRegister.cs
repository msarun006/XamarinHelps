﻿using System.Threading.Tasks;

namespace HireMe
{
    public interface IPushNotificationRegister
    {
        Task<string> ExtractTokenAndRegister();
    }
}
