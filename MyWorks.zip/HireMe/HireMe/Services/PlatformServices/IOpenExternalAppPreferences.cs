﻿namespace HireMe
{
    public interface IOpenExternalAppPreferences
    {
        void SetValue(string key, string value);
        string GetValue(string key);
        void ClearPreferencesValueAndKey();




    }
}
