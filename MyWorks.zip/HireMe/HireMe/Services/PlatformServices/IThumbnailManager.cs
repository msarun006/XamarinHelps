﻿namespace HireMe
{
    public interface IThumbnailManager
    {
        byte[] GetThumbnailImage(string vidoeUrl,int frameminutes,int frameseconds);
		bool CheckFileExist(string path);
    }
}
