﻿namespace HireMe
{
    public interface IPromoteAppActions
    {
        void OpenActions();
    }
}
