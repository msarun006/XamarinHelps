﻿using System.Threading.Tasks;

namespace HireMe
{
    public interface IS3ImageManager
    {
       
        Task<string> DownloadFile(string filename,string BucketName);
    }
}
