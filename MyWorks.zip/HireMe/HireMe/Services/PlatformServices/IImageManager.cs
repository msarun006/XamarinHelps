﻿namespace HireMe
{
    public interface IImageManager
    {
        string CopyFile(string sourceFile, string destinationFilename, bool overwrite = true);
        byte[] ReadImageFile(string imageLocation);
        string SaveImageBytes(byte[] imageBytes, string filename);
        void CleanUpMediaFiles();
        string GetStorageDirectory(HireMe.ResourceTypeEnums resourcetype);
        string CopyFileToHiremeDocs(string sourceFile, string filename, bool overwrite = true);
    }
}
