﻿using HireMe.Models.Recruiter;
using HireMe.Models.JobSeeker;
using System;
using Xamarin.Forms;
using HireMe.Models;
using HireMe.Models.SocialLoginData;
using HireMe.Models.Assessment;
using HireMe.Models.PRO_Assessment;

namespace HireMe
{
    public static class AppPreferences
    {
        public static IUserPreferences _userPref = DependencyService.Get<IUserPreferences>();
        public static IUserPreferences UserPreferences
        {
            get
            {
                return _userPref;
            }

        }

        #region IsIntroScreenShowed
        public static bool IsIntroScreenShowed
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsIntroScreenShowed")))
                {
                    UserPreferences.SetValue("IsIntroScreenShowed", false.ToString());

                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsIntroScreenShowed"));
                }
            }
            set
            {
                UserPreferences.SetValue("IsIntroScreenShowed", value.ToString());
            }
        }

        #endregion     

        //public static IOpenExternalAppPreferences _userExternalPref = DependencyService.Get<IOpenExternalAppPreferences>();
        //public static IOpenExternalAppPreferences ExternalAppPreferences
        //{
        //    get
        //    {
        //        return _userExternalPref;
        //    }

        //}



        //#region ShareHireMeeIDToExternalApp
        //public static string ShareHireMeeIDToExternalApp
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(ExternalAppPreferences.GetValue("ShareHireMeeIDToExternalApp")))
        //        {
        //            ExternalAppPreferences.SetValue("ShareHireMeeIDToExternalApp", string.Empty);
        //            return string.Empty;
        //        }
        //        else
        //        {
        //            return ExternalAppPreferences.GetValue("ShareHireMeeIDToExternalApp");
        //        }
        //    }
        //    set
        //    {
        //        ExternalAppPreferences.SetValue("ShareHireMeeIDToExternalApp", value);
        //    }

        //}
        //#endregion

        #region SelectedStateID
        public static string SelectedStateID
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("SelectedStateID")))
                {
                    UserPreferences.SetValue("SelectedStateID", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("SelectedStateID");
                }
            }
            set
            {
                UserPreferences.SetValue("SelectedStateID", value);
            }

        }

        #endregion

        //#region Register userID
        //public static string Reg_UserID
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(UserPreferences.GetValue("Reg_UserID")))
        //        {
        //            UserPreferences.SetValue("Reg_UserID", string.Empty);
        //            return string.Empty;
        //        }
        //        else
        //        {
        //            return UserPreferences.GetValue("Reg_UserID");
        //        }
        //    }
        //    set
        //    {
        //        UserPreferences.SetValue("Reg_UserID", value);
        //    }

        //}

        //#endregion



        #region isManualSync
        public static bool isManualSync
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("isManualSync")))
                {
                    UserPreferences.SetValue("isManualSync", false.ToString());

                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("isManualSync"));
                }
            }
            set
            {
                UserPreferences.SetValue("isManualSync", value.ToString());
            }

        }

        #endregion

        //#region isNextButtonClicked
        //public static bool isNextButtonClicked
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(UserPreferences.GetValue("isNextButtonClicked")))
        //        {
        //            UserPreferences.SetValue("isNextButtonClicked", false.ToString());


        #region IsPasswordReset
        public static bool IsPasswordReset
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsPasswordReset")))
                {
                    UserPreferences.SetValue("IsPasswordReset", false.ToString());

                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsPasswordReset"));
                }
            }
            set
            {
                UserPreferences.SetValue("IsPasswordReset", value.ToString());
            }

        }

        #endregion

        #region IsVerifyEmail
        public static bool IsVerifyEmail
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsVerifyEmail")))
                {
                    UserPreferences.SetValue("IsVerifyEmail", false.ToString());

                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsVerifyEmail"));
                }
            }
            set
            {
                UserPreferences.SetValue("IsVerifyEmail", value.ToString());
            }

        }

        #endregion

        #region IsVerifyMobileNo
        public static bool IsVerifyMobileNo
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsVerifyMobileNo")))
                {
                    UserPreferences.SetValue("IsVerifyMobileNo", false.ToString());

                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsVerifyMobileNo"));
                }
            }
            set
            {
                UserPreferences.SetValue("IsVerifyMobileNo", value.ToString());
            }

        }

        #endregion

        #region IsCollegeViseRegistraiton
        public static bool IsCollegeViseRegistraiton
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsCollegeViseRegistraiton")))
                {
                    UserPreferences.SetValue("IsCollegeViseRegistraiton", false.ToString());

                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsCollegeViseRegistraiton"));
                }
            }
            set
            {
                UserPreferences.SetValue("IsCollegeViseRegistraiton", value.ToString());
            }

        }

        #endregion

        #region IsPasscodeValue
        public static string IsPasscodeValue
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsPasscodeValue")))
                {
                    UserPreferences.SetValue("IsPasscodeValue", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("IsPasscodeValue");
                }
            }
            set
            {
                UserPreferences.SetValue("IsPasscodeValue", value);
            }

        }

        #endregion

        //      #region Forgot UserName
        //      public static string UserName
        //{
        //	get
        //	{
        //              if (string.IsNullOrEmpty(UserPreferences.GetValue("UserName")))
        //		{
        //                  UserPreferences.SetValue("UserName", string.Empty);
        //			return string.Empty;
        //		}
        //		else
        //		{
        //                  return UserPreferences.GetValue("UserName");
        //		}
        //	}
        //	set
        //	{
        //              UserPreferences.SetValue("UserName", value);
        //	}

        //}

        //#endregion

        //#region Forgot EmailID
        //public static string EmailID
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(UserPreferences.GetValue("EmailID")))
        //        {
        //            UserPreferences.SetValue("EmailID", string.Empty);
        //            return string.Empty;
        //        }
        //        else
        //        {
        //            return UserPreferences.GetValue("EmailID");
        //        }
        //    }
        //    set
        //    {
        //        UserPreferences.SetValue("EmailID", value);
        //    }
        //}

        //#endregion

        #region Forgot EmailAddress
        public static string EmailAddress
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("EmailAddress")))
                {
                    UserPreferences.SetValue("EmailAddress", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("EmailAddress");
                }
            }
            set
            {
                UserPreferences.SetValue("EmailAddress", value);
            }
        }

        #endregion


        //#region User password for Assessment
        //public static string UserPassword
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(UserPreferences.GetValue("UserPassword")))
        //        {
        //            UserPreferences.SetValue("UserPassword", string.Empty);
        //            return string.Empty;
        //        }
        //        else
        //        {
        //            return UserPreferences.GetValue("UserPassword");
        //        }
        //    }
        //    set
        //    {
        //        UserPreferences.SetValue("UserPassword", value);
        //    }

        //}

        //#endregion

        #region Forgot password user Input
        public static string ForgotPasswordEmailAddress
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ForgotPasswordEmailAddress")))
                {
                    UserPreferences.SetValue("ForgotPasswordEmailAddress", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("ForgotPasswordEmailAddress");
                }
            }
            set
            {
                UserPreferences.SetValue("ForgotPasswordEmailAddress", value);
            }
        }
        #endregion

        #region LinkedinAccessToken
        public static string LinkedinAccessToken
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("LinkedinAccessToken")))
                {
                    UserPreferences.SetValue("LinkedinAccessToken", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("LinkedinAccessToken");
                }
            }
            set
            {
                UserPreferences.SetValue("LinkedinAccessToken", value);
            }
        }
        #endregion


        #region IsPasscode
        public static bool IsPasscode
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsPasscode")))
                {
                    UserPreferences.SetValue("IsPasscode", false.ToString());

                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsPasscode"));
                }
            }
            set
            {
                UserPreferences.SetValue("IsPasscode", value.ToString());
            }
        }

        #endregion

        #region IsNavigateNotification
        public static bool IsNavigateNotification
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsNavigateNotification")))
                {
                    UserPreferences.SetValue("IsNavigateNotification", false.ToString());

                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsNavigateNotification"));
                }
            }
            set
            {
                UserPreferences.SetValue("IsNavigateNotification", value.ToString());
            }
        }

        #endregion

        #region IsNotificationEnabled
        public static bool IsNotificationEnabled
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsNotificationEnabled")))
                {
                    UserPreferences.SetValue("IsNotificationEnabled", false.ToString());

                    return true;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsNotificationEnabled"));
                }
            }
            set
            {
                UserPreferences.SetValue("IsNotificationEnabled", value.ToString());
            }
        }

        #endregion

        #region IsFirstRun
        public static bool IsFirstRun
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsFirstRun")))
                {
                    UserPreferences.SetValue("IsFirstRun", true.ToString());

                    return true;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsFirstRun"));
                }
            }
            set
            {
                UserPreferences.SetValue("IsFirstRun", value.ToString());
            }
        }

        #endregion

        #region IsCollege
        public static bool IsCollege
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsCollege")))
                {
                    UserPreferences.SetValue("IsCollege", true.ToString());

                    return true;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsCollege"));
                }
            }
            set
            {
                UserPreferences.SetValue("IsCollege", value.ToString());
            }
        }

        #endregion

        #region IsInstructionClicked
        public static bool IsInstructionClicked
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsInstructionClicked")))
                {
                    UserPreferences.SetValue("IsInstructionClicked", true.ToString());

                    return true;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsInstructionClicked"));
                }
            }
            set
            {
                UserPreferences.SetValue("IsInstructionClicked", value.ToString());
            }
        }

        #endregion

        #region IsvalidURI
        public static string IsvalidURI
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsvalidURI")))
                {
                    UserPreferences.SetValue("IsvalidURI", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("IsvalidURI");
                }
            }
            set
            {
                UserPreferences.SetValue("IsvalidURI", value);
            }
        }
        #endregion

        #region S3 Credentials
        public static string S3AccessKeyID
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("S3AccessKeyID")))
                {
                    UserPreferences.SetValue("S3AccessKeyID", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("S3AccessKeyID");
                }
            }
            set
            {
                UserPreferences.SetValue("S3AccessKeyID", value);
            }

        }
        public static string S3SecretAccessKey
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("S3SecretKeyID")))
                {
                    UserPreferences.SetValue("S3SecretKeyID", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("S3SecretKeyID");
                }
            }
            set
            {
                UserPreferences.SetValue("S3SecretKeyID", value);
            }
        }
        #endregion

        #region ActiveToken
        public static ApplicationToken ActiveToken
        {
            get
            {
                string value = UserPreferences.GetValue("ActiveToken");

                if (string.IsNullOrEmpty(value))
                {
                    UserPreferences.SetValue("ActiveToken", Newtonsoft.Json.JsonConvert.SerializeObject(new ApplicationToken()));
                    return null;
                }
                else
                {
                    var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<ApplicationToken>(value);
                    return obj;
                }
            }
            set
            {
                if (value != null)
                {
                    var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
                    UserPreferences.SetValue("ActiveToken", jsonstring);
                }
                else
                {
                    UserPreferences.SetValue("ActiveToken", String.Empty);
                }
            }
        }

        #endregion

        #region SkillVideo
        //SkillVideo
        public static VideoFileDetails SkillVideo
        {
            get
            {
                string value = UserPreferences.GetValue("SkillVideo");
                if (string.IsNullOrEmpty(value))
                {
                    UserPreferences.SetValue("SkillVideo", Newtonsoft.Json.JsonConvert.SerializeObject(new VideoFileDetails()));

                    return null;
                }
                else
                {
                    var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<VideoFileDetails>(value);
                    return obj;
                }
            }

            set
            {
                if (value != null)
                {
                    var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
                    UserPreferences.SetValue("SkillVideo", jsonstring);
                }
                else
                {
                    UserPreferences.SetValue("SkillVideo", String.Empty);
                }
            }
        }
        #endregion

        #region InterestVideo
        public static VideoFileDetails InterestVideo
        {
            get
            {
                var value = UserPreferences.GetValue("InterestVideo");
                if (string.IsNullOrEmpty(value))
                {
                    UserPreferences.SetValue("InterestVideo", Newtonsoft.Json.JsonConvert.SerializeObject(new VideoFileDetails()));
                    return null;
                }
                else
                {
                    var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<VideoFileDetails>(value);
                    return obj;
                }
            }
            set
            {
                if (value != null)
                {
                    var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
                    UserPreferences.SetValue("InterestVideo", jsonstring);
                }
                else
                {
                    UserPreferences.SetValue("InterestVideo", String.Empty);
                }
            }
        }

        #endregion

        #region AboutMeVideo
        //AboutmeVideo
        public static VideoFileDetails AboutMeVideo
        {
            get
            {
                var value = UserPreferences.GetValue("AboutMeVideo");
                if (string.IsNullOrEmpty(value))
                {
                    UserPreferences.SetValue("AboutMeVideo", Newtonsoft.Json.JsonConvert.SerializeObject(new VideoFileDetails()));
                    return null;
                }
                else
                {
                    var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<VideoFileDetails>(value);
                    return obj;
                }
            }
            set
            {
                if (value != null)
                {
                    var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
                    UserPreferences.SetValue("AboutMeVideo", jsonstring);
                }
                else
                {
                    UserPreferences.SetValue("AboutMeVideo", String.Empty);
                }
            }
        }

        #endregion

        //#region CurrentUser
        ////ProfileDetails
        //public static JobSeekerProfileDetails CurrentUser
        //{
        //    get
        //    {
        //        var value = UserPreferences.GetValue("CurrentUser");
        //        if (string.IsNullOrEmpty(value))
        //        {
        //            UserPreferences.SetValue("CurrentUser", Newtonsoft.Json.JsonConvert.SerializeObject(new JobSeekerProfileDetails()));
        //            return null;
        //        }
        //        else
        //        {
        //            var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<JobSeekerProfileDetails>(value);
        //            return obj;
        //        }
        //    }
        //    set
        //    {
        //        if (value != null)
        //        {
        //            var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
        //            UserPreferences.SetValue("CurrentUser", jsonstring);
        //        }
        //        else
        //        {
        //            UserPreferences.SetValue("CurrentUser", string.Empty);
        //        }
        //    }
        //}
        //#endregion


        #region IsAdmin_CompanyProfile
        public static string IsAdmin_CompanyProfile
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsAdmin_CompanyProfile")))
                {
                    UserPreferences.SetValue("IsAdmin_CompanyProfile", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("IsAdmin_CompanyProfile");
                }
            }
            set
            {
                UserPreferences.SetValue("IsAdmin_CompanyProfile", value);
            }

        }
        #endregion

        #region ProfilePicture
        //Profile Picture
        public static string ProfilePicture
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ProfilePicture")))
                {
                    UserPreferences.SetValue("ProfilePicture", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("ProfilePicture");
                }
            }
            set
            {
                UserPreferences.SetValue("ProfilePicture", value);
            }

        }
        #endregion

        #region IdCard
        public static string IdCard
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IdCard")))
                {
                    UserPreferences.SetValue("IdCard", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("IdCard");
                }
            }
            set
            {
                UserPreferences.SetValue("IdCard", value);
            }

        }

        #endregion

        #region PreferredLanguageCount
        public static string PreferredLanguageCount
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("PreferredLanguageCount")))
                {
                    UserPreferences.SetValue("PreferredLanguageCount", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("PreferredLanguageCount");
                }
            }
            set
            {
                UserPreferences.SetValue("PreferredLanguageCount", value);
            }

        }

        #endregion

        #region IsProfileCompleted
        public static bool IsProfileCompleted
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsProfileCompleted")))
                {
                    UserPreferences.SetValue("IsProfileCompleted", false.ToString());
                    return false;

                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsProfileCompleted"));
                }

            }
            set
            {
                string boolstring = "false";
                if (value)
                {
                    boolstring = "true";
                }
                UserPreferences.SetValue("IsProfileCompleted", boolstring);
            }
        }

        #endregion

        #region IsEducationCompleted
        public static bool IsEducationCompleted
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsEducationCompleted")))
                {
                    UserPreferences.SetValue("IsEducationCompleted", false.ToString());
                    return false;

                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsEducationCompleted"));
                }

            }
            set
            {
                string boolstring = "false";
                if (value)
                {
                    boolstring = "true";
                }
                UserPreferences.SetValue("IsEducationCompleted", boolstring);
            }
        }

        #endregion



        //#region IsSchoolDetailsCompleted
        //public static bool IsSchoolDetailsCompleted
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(UserPreferences.GetValue("IsSchoolDetailsCompleted")))
        //        {
        //            UserPreferences.SetValue("IsSchoolDetailsCompleted", false.ToString());
        //            return false;

        //        }
        //        else
        //        {
        //            return Convert.ToBoolean(UserPreferences.GetValue("IsSchoolDetailsCompleted"));
        //        }

        //    }
        //    set
        //    {
        //        string boolstring = "false";
        //        if (value)
        //        {
        //            boolstring = "true";
        //        }
        //        UserPreferences.SetValue("IsSchoolDetailsCompleted", boolstring);
        //    }
        //}

        //#endregion


        //#region IsCollegeDetailsCompleted
        //public static bool IsCollegeDetailsCompleted
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(UserPreferences.GetValue("IsCollegeDetailsCompleted")))
        //        {
        //            UserPreferences.SetValue("IsCollegeDetailsCompleted", false.ToString());
        //            return false;

        //        }
        //        else
        //        {
        //            return Convert.ToBoolean(UserPreferences.GetValue("IsCollegeDetailsCompleted"));
        //        }

        //    }
        //    set
        //    {
        //        string boolstring = "false";
        //        if (value)
        //        {
        //            boolstring = "true";
        //        }
        //        UserPreferences.SetValue("IsCollegeDetailsCompleted", boolstring);
        //    }
        //}

        //#endregion

        //#region IsNeedToSkillUpdate
        //public static bool IsNeedToSkillUpdate
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(UserPreferences.GetValue("IsNeedToSkillUpdate")))
        //        {
        //            UserPreferences.SetValue("IsNeedToSkillUpdate", false.ToString());
        //            return false;

        //        }
        //        else
        //        {
        //            return Convert.ToBoolean(UserPreferences.GetValue("IsNeedToSkillUpdate"));
        //        }

        //    }
        //    set
        //    {
        //        string boolstring = "false";
        //        if (value)
        //        {
        //            boolstring = "true";
        //        }
        //        UserPreferences.SetValue("IsNeedToSkillUpdate", boolstring);
        //    }
        //}

        //#endregion



        #region IsVideosUploaded
        public static bool IsVideosUploaded
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsVideosUploaded")))
                {
                    UserPreferences.SetValue("IsVideosUploaded", false.ToString());
                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsVideosUploaded"));
                }
            }
            set
            {
                string boolstring = "false";
                if (value)
                {
                    boolstring = "true";

                }
                UserPreferences.SetValue("IsVideosUploaded", boolstring);
            }
        }

        #endregion

        #region IsResumeUploaded
        public static bool IsResumeUploaded
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsResumeUploaded")))
                {
                    UserPreferences.SetValue("IsResumeUploaded", false.ToString());
                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsResumeUploaded"));
                }

            }
            set
            {
                string boolstring = "false";
                if (value)
                {
                    boolstring = "true";

                }
                UserPreferences.SetValue("IsResumeUploaded", boolstring);
            }
        }

        #endregion

        #region IsGoogleLoggedIn
        public static bool IsGoogleLoggedIn
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsGoogleLoggeedIn")))
                {
                    UserPreferences.SetValue("IsGoogleLoggeedIn", false.ToString());
                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsGoogleLoggeedIn"));
                }
            }
            set
            {
                string boolstring = "false";
                if (value)
                {
                    boolstring = "true";

                }
                UserPreferences.SetValue("IsGoogleLoggeedIn", boolstring);
            }
        }

        #endregion

        #region IsFBLoggeedIn
        public static bool IsFBLoggeedIn
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsFBLoggeedIn")))
                {
                    UserPreferences.SetValue("IsFBLoggeedIn", false.ToString());
                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsFBLoggeedIn"));
                }
            }
            set
            {
                string boolstring = "false";
                if (value)
                {
                    boolstring = "true";

                }
                UserPreferences.SetValue("IsFBLoggeedIn", boolstring);
            }
        }

        #endregion

        #region IsLinkedInLoggedIn
        public static bool IsLinkedInLoggedIn
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsLinkedInLoggedIn")))
                {
                    UserPreferences.SetValue("IsLinkedInLoggedIn", false.ToString());
                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsLinkedInLoggedIn"));
                }
            }
            set
            {
                string boolstring = "false";
                if (value)
                {
                    boolstring = "true";

                }
                UserPreferences.SetValue("IsLinkedInLoggedIn", boolstring);
            }
        }

        #endregion

        #region IsSocialLoggedIn
        public static bool IsSocialLoggedIn
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsSocialLoggedIn")))
                {
                    UserPreferences.SetValue("IsSocialLoggedIn", false.ToString());
                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsSocialLoggedIn"));
                }
            }
            set
            {
                string boolstring = "false";
                if (value)
                {
                    boolstring = "true";

                }
                UserPreferences.SetValue("IsSocialLoggedIn", boolstring);
            }
        }

        #endregion

        #region IsLoggeedIn
        public static bool IsLoggeedIn
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsLogged")))
                {
                    UserPreferences.SetValue("IsLogged", false.ToString());
                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsLogged"));
                }
            }
            set
            {
                string boolstring = "false";
                if (value)
                {
                    boolstring = "true";

                }
                UserPreferences.SetValue("IsLogged", boolstring);
            }
        }

        #endregion

        //#region IsLogout
        //public static bool IsLogout
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(UserPreferences.GetValue("IsLogout")))
        //        {
        //            UserPreferences.SetValue("IsLogout", false.ToString());
        //            return false;
        //        }
        //        else
        //        {
        //            return Convert.ToBoolean(UserPreferences.GetValue("IsLogout"));
        //        }


        //    }
        //    set
        //    {
        //        string boolstring = "false";
        //        if (value)
        //        {
        //            boolstring = "true";

        //        }
        //        UserPreferences.SetValue("IsLogout", boolstring);
        //    }
        //}

        //#endregion

        #region IsDashboard
        public static bool IsDashboard
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsDashboard")))
                {
                    UserPreferences.SetValue("IsDashboard", false.ToString());
                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsDashboard"));
                }

            }
            set
            {
                string boolstring = "false";
                if (value)
                {
                    boolstring = "true";

                }
                UserPreferences.SetValue("IsDashboard", boolstring);
            }
        }

        #endregion

        #region userName
        public static string userName
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("UserName")))
                {
                    UserPreferences.SetValue("UserName", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("UserName");
                }
            }
            set
            {
                UserPreferences.SetValue("UserName", value);
            }
        }
        #endregion

        #region PRO_ExamInstruction_Content
        public static string PRO_ExamInstruction_Content
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("PRO_ExamInstruction_Content")))
                {
                    UserPreferences.SetValue("PRO_ExamInstruction_Content", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("PRO_ExamInstruction_Content");
                }
            }
            set
            {
                UserPreferences.SetValue("PRO_ExamInstruction_Content", value);
            }
        }
        #endregion

        #region LastName
        public static string LastName
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("LastName")))
                {
                    UserPreferences.SetValue("LastName", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("LastName");
                }
            }
            set
            {
                UserPreferences.SetValue("LastName", value);
            }
        }
        #endregion

        #region MobileNumber
        public static string MobileNumber
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("MobileNumber")))
                {
                    UserPreferences.SetValue("MobileNumber", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("MobileNumber");
                }
            }
            set
            {
                UserPreferences.SetValue("MobileNumber", value);
            }
        }
        #endregion

        //#region Temporary Token

        //public static string TempToken
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(UserPreferences.GetValue("TempToken")))
        //        {
        //            UserPreferences.SetValue("TempToken", string.Empty);
        //            return string.Empty;
        //        }
        //        else
        //        {
        //            return UserPreferences.GetValue("TempToken");
        //        }
        //    }
        //    set
        //    {
        //        UserPreferences.SetValue("TempToken", value);
        //    }
        //}
        //#endregion


        #region  RefreshToken
        public static string RefreshToken
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("RefreshToken")))
                {
                    UserPreferences.SetValue("RefreshToken", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("RefreshToken");
                }
            }
            set
            {
                UserPreferences.SetValue("RefreshToken", value);
            }
        }
        #endregion

        #region HireMeeID
        public static string HireMeeID
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("HireMeeID")))
                {
                    UserPreferences.SetValue("HireMeeID", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("HireMeeID");
                }
            }
            set
            {
                UserPreferences.SetValue("HireMeeID", value);
            }
        }
        #endregion
        //public static string PreviousHireMeeID
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(UserPreferences.GetValue("HireMeeID")))
        //        {
        //            UserPreferences.SetValue("HireMeeID", string.Empty);
        //            return string.Empty;
        //        }
        //        else
        //        {
        //            return UserPreferences.GetValue("HireMeeID");
        //        }
        //    }
        //    set
        //    {
        //        UserPreferences.SetValue("HireMeeID", value);
        //    }
        //}


        //#region ProfileScore


        #region CanUploadInterestsVideo

        public static bool CanUploadInterestsVideo
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("CanUploadInterestsVideo")))
                {
                    UserPreferences.SetValue("CanUploadInterestsVideo", false.ToString());
                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("CanUploadInterestsVideo"));
                }
            }
            set
            {
                UserPreferences.SetValue("CanUploadInterestsVideo", value.ToString());
            }
        }
        #endregion
        
        #region CanUploadAboutMeVideo

        public static bool CanUploadAboutMeVideo
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("CanUploadAboutMeVideo")))
                {
                    UserPreferences.SetValue("CanUploadAboutMeVideo", false.ToString());
                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("CanUploadAboutMeVideo"));
                }
            }
            set
            {
                UserPreferences.SetValue("CanUploadAboutMeVideo", value.ToString());
            }
        }
        #endregion

        #region CanUploadSkillVideo
        public static bool CanUploadSkillVideo
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("CanUploadSkillVideo")))
                {
                    UserPreferences.SetValue("CanUploadSkillVideo", false.ToString());
                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("CanUploadSkillVideo"));
                }
            }
            set
            {
                UserPreferences.SetValue("CanUploadSkillVideo", value.ToString());
            }
        }

        #endregion

        //#region AssessmentScores
        //public static JobSeekerAssessmentDetails AssessmentScores
        //{
        //    get
        //    {
        //        var value = UserPreferences.GetValue("AssessmentScores");
        //        if (string.IsNullOrEmpty(value))
        //        {
        //            UserPreferences.SetValue("AssessmentScores", Newtonsoft.Json.JsonConvert.SerializeObject(new JobSeekerAssessmentDetails()));
        //            return null;
        //        }
        //        else
        //        {
        //            var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<JobSeekerAssessmentDetails>(value);
        //            return obj;
        //        }
        //    }
        //    set
        //    {
        //        if (value != null)
        //        {
        //            var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
        //            UserPreferences.SetValue("AssessmentScores", jsonstring);
        //        }
        //        else
        //        {
        //            UserPreferences.SetValue("AssessmentScores", string.Empty);
        //        }
        //    }
        //}


        //#endregion


        #region HelpScreen
        public static string HelpScreen
        {

            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ShowHelpScreen")))
                {

                    UserPreferences.SetValue("ShowHelpScreen", "ShowHelpScreen");
                    return UserPreferences.GetValue("ShowHelpScreen").ToString();
                }

                else
                {
                    return UserPreferences.GetValue("ShowHelpScreen").ToString();
                }

            }

            set
            {
                UserPreferences.SetValue("ShowHelpScreen", value.ToString());
            }
        }

        #endregion

        #region IsVisibleOthersSkill
        public static string IsVisibleOthersSkill
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsVisibleOthersSkill")))
                {
                    UserPreferences.SetValue("IsVisibleOthersSkill", "false");
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("IsVisibleOthersSkill");
                }
            }
            set
            {
                UserPreferences.SetValue("IsVisibleOthersSkill", value);
            }
        }

        #endregion
        
        #region SelectedCourseTypeID
        public static string SelectedCourseTypeID
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("SelectedCourseTypeID")))
                {
                    UserPreferences.SetValue("SelectedCourseTypeID", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("SelectedCourseTypeID");
                }
            }
            set
            {
                UserPreferences.SetValue("SelectedCourseTypeID", value);
            }

        }
        #endregion

                #region SelectedCourseID
        public static string SelectedCourseID
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("SelectedCourseID")))
                {
                    UserPreferences.SetValue("SelectedCourseID", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("SelectedCourseID");
                }
            }
            set
            {
                UserPreferences.SetValue("SelectedCourseID", value);
            }

        }
        #endregion

        //#region UserForgotPassword response values
        //public static ForgotPasswordData ForgotPasswordValues
        //{
        //    get
        //    {
        //        string value = UserPreferences.GetValue("ForgotPasswordValues");

        //        if (string.IsNullOrEmpty(value))
        //        {
        //            UserPreferences.SetValue("ForgotPasswordValues", Newtonsoft.Json.JsonConvert.SerializeObject(new UserResponseValues()));
        //            return null;
        //        }
        //        else
        //        {
        //            var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<ForgotPasswordData>(value);
        //            return obj;

        //        }
        //    }
        //    set
        //    {
        //        if (value != null)
        //        {
        //            var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
        //            UserPreferences.SetValue("ForgotPasswordValues", jsonstring);
        //        }
        //        else
        //        {
        //            UserPreferences.SetValue("ForgotPasswordValues", String.Empty);
        //        }
        //    }
        //}

        //#endregion

        #region UserForgotPassword response values
        public static ForgotPasswordNewResponse ForgotPasswordNewValues
        {
            get
            {
                string value = UserPreferences.GetValue("ForgotPasswordNewValues");

                if (string.IsNullOrEmpty(value))
                {
                    UserPreferences.SetValue("ForgotPasswordNewValues", Newtonsoft.Json.JsonConvert.SerializeObject(new UserResponseValues()));
                    return null;
                }
                else
                {
                    var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<ForgotPasswordNewResponse>(value);
                    return obj;

                }
            }
            set
            {
                if (value != null)
                {
                    var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
                    UserPreferences.SetValue("ForgotPasswordNewValues", jsonstring);
                }
                else
                {
                    UserPreferences.SetValue("ForgotPasswordNewValues", String.Empty);
                }
            }
        }

        #endregion

        #region UserMobileNoUpdateResponseValue
        public static UserMobileNoUpdateResponseValue MobileNoUpdateValues
        {
            get
            {
                string value = UserPreferences.GetValue("MobileNoUpdateValues");

                if (string.IsNullOrEmpty(value))
                {
                    UserPreferences.SetValue("MobileNoUpdateValues", Newtonsoft.Json.JsonConvert.SerializeObject(new UserMobileNoUpdateResponseValue()));
                    return null;
                }
                else
                {
                    var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<UserMobileNoUpdateResponseValue>(value);
                    return obj;

                }
            }
            set
            {
                if (value != null)
                {
                    var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
                    UserPreferences.SetValue("MobileNoUpdateValues", jsonstring);
                }
                else
                {
                    UserPreferences.SetValue("MobileNoUpdateValues", String.Empty);
                }
            }
        }

        #endregion

        #region UserEmailUpdateResponseValue
        public static UserEmailUpdateResponseValue EmailUpdateValues
        {
            get
            {
                string value = UserPreferences.GetValue("EmailUpdateValues");

                if (string.IsNullOrEmpty(value))
                {
                    UserPreferences.SetValue("EmailUpdateValues", Newtonsoft.Json.JsonConvert.SerializeObject(new UserEmailUpdateResponseValue()));
                    return null;
                }
                else
                {
                    var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<UserEmailUpdateResponseValue>(value);
                    return obj;

                }
            }
            set
            {
                if (value != null)
                {
                    var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
                    UserPreferences.SetValue("EmailUpdateValues", jsonstring);
                }
                else
                {
                    UserPreferences.SetValue("EmailUpdateValues", String.Empty);
                }
            }
        }

        #endregion

        #region UserRegisteration response values
        public static UserResponseValues UserValues
        {
            get
            {
                string value = UserPreferences.GetValue("UserValues");

                if (string.IsNullOrEmpty(value))
                {
                    UserPreferences.SetValue("UserValues", Newtonsoft.Json.JsonConvert.SerializeObject(new UserResponseValues()));
                    return null;
                }
                else
                {
                    var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<UserResponseValues>(value);
                    return obj;

                }
            }
            set
            {
                if (value != null)
                {
                    var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
                    UserPreferences.SetValue("UserValues", jsonstring);
                }
                else
                {
                    UserPreferences.SetValue("UserValues", String.Empty);
                }
            }
        }

        #endregion

        //#region Others Skill
        //public static SkillOthers OthersSkill
        //{
        //    get
        //    {
        //        string value = UserPreferences.GetValue("OthersSkill");

        //        if (string.IsNullOrEmpty(value))
        //        {
        //            UserPreferences.SetValue("OthersSkill", Newtonsoft.Json.JsonConvert.SerializeObject(new SkillOthers()));
        //            return null;
        //        }
        //        else
        //        {
        //            var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<SkillOthers>(value);
        //            return obj;

        //        }
        //    }
        //    set
        //    {
        //        if (value != null)
        //        {
        //            var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
        //            UserPreferences.SetValue("OthersSkill", jsonstring);
        //        }
        //        else
        //        {
        //            UserPreferences.SetValue("OthersSkill", null);
        //        }
        //    }
        //}

        //#endregion

        #region GoogleUserDetails
        public static GoogleUserModel GoogleUserDetails
        {
            get
            {
                string value = UserPreferences.GetValue("GoogleUserDetails");

                if (string.IsNullOrEmpty(value))
                {
                    UserPreferences.SetValue("GoogleUserDetails", Newtonsoft.Json.JsonConvert.SerializeObject(new GoogleUserModel()));
                    return null;
                }
                else
                {
                    var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<GoogleUserModel>(value);
                    return obj;

                }
            }
            set
            {
                if (value != null)
                {
                    var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
                    UserPreferences.SetValue("GoogleUserDetails", jsonstring);
                }
                else
                {
                    UserPreferences.SetValue("GoogleUserDetails", String.Empty);
                }
            }
        }

        #endregion

        #region FacebookUserDetails
        public static FacebookUserModel FacebookUserDetails
        {
            get
            {
                string value = UserPreferences.GetValue("FacebookUserDetails");

                if (string.IsNullOrEmpty(value))
                {
                    UserPreferences.SetValue("FacebookUserDetails", Newtonsoft.Json.JsonConvert.SerializeObject(new FacebookUserModel()));
                    return null;
                }
                else
                {
                    var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<FacebookUserModel>(value);
                    return obj;

                }
            }
            set
            {
                if (value != null)
                {
                    var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
                    UserPreferences.SetValue("FacebookUserDetails", jsonstring);
                }
                else
                {
                    UserPreferences.SetValue("FacebookUserDetails", String.Empty);
                }
            }
        }

        #endregion

        #region LinkedInUserDetails
        public static LinkedInUserModel LinkedInUserDetails
        {
            get
            {
                string value = UserPreferences.GetValue("LinkedInUserDetails");

                if (string.IsNullOrEmpty(value))
                {
                    UserPreferences.SetValue("LinkedInUserDetails", Newtonsoft.Json.JsonConvert.SerializeObject(new LinkedInUserModel()));
                    return null;
                }
                else
                {
                    var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<LinkedInUserModel>(value);
                    return obj;

                }
            }
            set
            {
                if (value != null)
                {
                    var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
                    UserPreferences.SetValue("LinkedInUserDetails", jsonstring);
                }
                else
                {
                    UserPreferences.SetValue("LinkedInUserDetails", String.Empty);
                }
            }
        }

        #endregion

        #region ProfileViewerCount
        public static ProfileViewerCountBO ProfileViewerCount
        {
            get
            {
                var value = UserPreferences.GetValue("ProfileViewerCount");
                if (string.IsNullOrEmpty(value))
                {
                    UserPreferences.SetValue("ProfileViewerCount", Newtonsoft.Json.JsonConvert.SerializeObject(new ProfileViewerCountBO()));
                    return null;
                }
                else
                {
                    var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<ProfileViewerCountBO>(value);
                    return obj;
                }
            }
            set
            {
                if (value != null)
                {
                    var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
                    UserPreferences.SetValue("ProfileViewerCount", jsonstring);
                }
                else
                {
                    UserPreferences.SetValue("AssessmentScores", string.Empty);
                }
            }
        }

        #endregion

        #region Collegeviseregistraiton
        public static CollegeViseRegistrationsRequestData Collegeviseregistraiton
        {
            get
            {
                string value = UserPreferences.GetValue("Collegeviseregistraiton");

                if (string.IsNullOrEmpty(value))
                {
                    UserPreferences.SetValue("Collegeviseregistraiton", Newtonsoft.Json.JsonConvert.SerializeObject(new CollegeViseRegistrationsRequestData()));
                    return null;
                }
                else
                {
                    var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<CollegeViseRegistrationsRequestData>(value);
                    return obj;

                }
            }
            set
            {
                if (value != null)
                {
                    var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
                    UserPreferences.SetValue("Collegeviseregistraiton", jsonstring);
                }
                else
                {
                    UserPreferences.SetValue("Collegeviseregistraiton", String.Empty);
                }
            }
        }

        #endregion

        #region Language
        public static Languageknown[] Language
        {
            get
            {
                string value = UserPreferences.GetValue("Language");

                if (string.IsNullOrEmpty(value))
                {
                    UserPreferences.SetValue("Language", Newtonsoft.Json.JsonConvert.SerializeObject(new Languageknown()));
                    return null;
                }
                else
                {
                    var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<Languageknown[]>(value);
                    return obj;

                }
            }
            set
            {
                if (value != null)
                {
                    var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
                    UserPreferences.SetValue("Language", jsonstring);
                }
                else
                {
                    UserPreferences.SetValue("Language", String.Empty);
                }
            }
        }
        #endregion

        #region AvailableLanguage
        public static AvailableLanguage[] AvailableLanguage
        {
            get
            {
                string value = UserPreferences.GetValue("AvailableLanguage");

                if (string.IsNullOrEmpty(value))
                {
                    UserPreferences.SetValue("AvailableLanguage", Newtonsoft.Json.JsonConvert.SerializeObject(new AvailableLanguage()));
                    return null;
                }
                else
                {
                    var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<AvailableLanguage[]>(value);
                    return obj;

                }
            }
            set
            {
                if (value != null)
                {
                    var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
                    UserPreferences.SetValue("AvailableLanguage", jsonstring);
                }
                else
                {
                    UserPreferences.SetValue("AvailableLanguage", String.Empty);
                }
            }
        }
        #endregion

        #region Screenshotcount
        public static string Screenshotcount
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("Screenshotcount")))
                {
                    UserPreferences.SetValue("Screenshotcount", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("Screenshotcount");
                }
            }
            set
            {
                UserPreferences.SetValue("Screenshotcount", value);
            }

        }
        #endregion

        #region GroupDetailsSerialize
        public static string GroupDetailsSerialize
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("GroupDetailsSerialize")))
                {
                    UserPreferences.SetValue("GroupDetailsSerialize", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("GroupDetailsSerialize");
                }
            }
            set
            {
                UserPreferences.SetValue("GroupDetailsSerialize", value);
            }
        }
        #endregion




        #region GroupDetailsSerialize
        public static string TestPinGroupDetailsSerialize
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("TestPinGroupDetailsSerialize")))
                {
                    UserPreferences.SetValue("TestPinGroupDetailsSerialize", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("TestPinGroupDetailsSerialize");
                }
            }
            set
            {
                UserPreferences.SetValue("TestPinGroupDetailsSerialize", value);
            }
        }
        #endregion

        #region IsSeekerDashboardDataDownloaded
        public static bool IsSeekerDashboardDataDownloaded
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsSeekerDashboardDataDownloaded")))
                {
                    UserPreferences.SetValue("IsSeekerDashboardDataDownloaded", false.ToString());
                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsSeekerDashboardDataDownloaded"));
                }
            }
            set
            {
                string boolstring = "false";
                if (value)
                {
                    boolstring = "true";

                }
                UserPreferences.SetValue("IsSeekerDashboardDataDownloaded", boolstring);
            }
        }
        #endregion

        #region ExamDuration
        public static string ExamDuration
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ExamDuration")))
                {
                    UserPreferences.SetValue("ExamDuration", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("ExamDuration");
                }
            }
            set
            {
                UserPreferences.SetValue("ExamDuration", value);
            }
        }
        #endregion

        #region NoOfQuestions
        public static string NoOfQuestions
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("NoOfQuestions")))
                {
                    UserPreferences.SetValue("NoOfQuestions", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("NoOfQuestions");
                }
            }
            set
            {
                UserPreferences.SetValue("NoOfQuestions", value);
            }

        }

        #endregion

        #region NoofAttempts
        public static string NoofAttempts
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("NoofAttempts")))
                {
                    UserPreferences.SetValue("NoofAttempts", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("NoofAttempts");
                }
            }
            set
            {
                UserPreferences.SetValue("NoofAttempts", value);
            }

        }

        #endregion

        #region BatteryLevel
        public static string BatteryLevel
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("BatteryLevel")))
                {
                    UserPreferences.SetValue("BatteryLevel", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("BatteryLevel");
                }
            }
            set
            {
                UserPreferences.SetValue("BatteryLevel", value);
            }

        }

        #endregion

        //#region AccessToken
        //public static string AccessToken
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(UserPreferences.GetValue("AccessToken")))
        //        {
        //            UserPreferences.SetValue("AccessToken", string.Empty);
        //            return string.Empty;
        //        }
        //        else
        //        {
        //            return UserPreferences.GetValue("AccessToken");
        //        }
        //    }
        //    set
        //    {
        //        UserPreferences.SetValue("AccessToken", value);
        //    }

        //}

        //#endregion

        #region AutoID
        public static string AutoID
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("AutoID")))
                {
                    UserPreferences.SetValue("AutoID", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("AutoID");
                }
            }
            set
            {
                UserPreferences.SetValue("AutoID", value);
            }

        }

        #endregion

        #region ExamID
        public static string ExamID
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ExamID")))
                {
                    UserPreferences.SetValue("ExamID", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("ExamID");
                }
            }
            set
            {
                UserPreferences.SetValue("ExamID", value);
            }

        }
        #endregion

        #region ExamName
        public static string ExamName
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ExamName")))
                {
                    UserPreferences.SetValue("ExamName", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("ExamName");
                }
            }
            set
            {
                UserPreferences.SetValue("ExamName", value);
            }

        }

        #endregion

        #region ExamCenterName
        public static string ExamCenterName
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ExamCenterName")))
                {
                    UserPreferences.SetValue("ExamCenterName", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("ExamCenterName");
                }
            }
            set
            {
                UserPreferences.SetValue("ExamCenterName", value);
            }

        }

        #endregion

        #region AssignedID
        public static string AssignedID
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("AssignedID")))
                {
                    UserPreferences.SetValue("AssignedID", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("AssignedID");
                }
            }
            set
            {
                UserPreferences.SetValue("AssignedID", value);
            }

        }

        #endregion

        //#region AppCurrentState
        //public static string AppCurrentState
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(UserPreferences.GetValue("AppCurrentState")))
        //        {
        //            UserPreferences.SetValue("AppCurrentState", string.Empty);
        //            return string.Empty;
        //        }
        //        else
        //        {
        //            return UserPreferences.GetValue("AppCurrentState");
        //        }
        //    }
        //    set
        //    {
        //        UserPreferences.SetValue("AppCurrentState", value);
        //    }

        //}

        //#endregion

        //#region AppOwnTimer
        //public static string AppOwnTimer
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(UserPreferences.GetValue("AppOwnTimer")))
        //        {
        //            UserPreferences.SetValue("AppOwnTimer", string.Empty);
        //            return string.Empty;
        //        }
        //        else
        //        {
        //            return UserPreferences.GetValue("AppOwnTimer");
        //        }
        //    }
        //    set
        //    {
        //        UserPreferences.SetValue("AppOwnTimer", value);
        //    }

        //}
        //#endregion

        #region ServerDateTime
        public static string ServerDateTime
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ServerDateTime")))
                {
                    UserPreferences.SetValue("ServerDateTime", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("ServerDateTime");
                }
            }
            set
            {
                UserPreferences.SetValue("ServerDateTime", value);
            }

        }

        #endregion

        #region ExamTime
        public static string ExamTime
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ExamTime")))
                {
                    UserPreferences.SetValue("ExamTime", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("ExamTime");
                }
            }
            set
            {
                UserPreferences.SetValue("ExamTime", value);
            }

        }

        #endregion

        #region ExamMode
        public static string ExamMode
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ExamMode")))
                {
                    UserPreferences.SetValue("ExamMode", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("ExamMode");
                }
            }
            set
            {
                UserPreferences.SetValue("ExamMode", value);
            }

        }
        #endregion

        //#region UserAttemptCount
        //public static string UserAttemptCount
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(UserPreferences.GetValue("UserAttemptCount")))
        //        {
        //            UserPreferences.SetValue("UserAttemptCount", string.Empty);
        //            return string.Empty;
        //        }
        //        else
        //        {
        //            return UserPreferences.GetValue("UserAttemptCount");
        //        }
        //    }
        //    set
        //    {
        //        UserPreferences.SetValue("UserAttemptCount", value);
        //    }

        //}
        //#endregion

        #region HintStack
        public static string HintStack
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("HintStack")))
                {
                    UserPreferences.SetValue("HintStack", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("HintStack");
                }
            }
            set
            {
                UserPreferences.SetValue("HintStack", value);
            }

        }

        #endregion  

        #region ExamMinute
        public static string ExamMinute
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ExamMinute")))
                {
                    UserPreferences.SetValue("ExamMinute", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("ExamMinute");
                }
            }
            set
            {
                UserPreferences.SetValue("ExamMinute", value);
            }
        }

        #endregion

        #region ExamMinute
        public static string ImageCapturingTimeInterval
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ImageCapturingTimeInterval")))
                {
                    UserPreferences.SetValue("ImageCapturingTimeInterval", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("ImageCapturingTimeInterval");
                }
            }
            set
            {
                UserPreferences.SetValue("ImageCapturingTimeInterval", value);
            }
        }

        #endregion

        #region ExamSecond
        public static string ExamSecond
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ExamSecond")))
                {
                    UserPreferences.SetValue("ExamSecond", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("ExamSecond");
                }
            }
            set
            {
                UserPreferences.SetValue("ExamSecond", value);
            }
        }

        #endregion   

        #region ExamHour
        public static string ExamHour
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ExamHour")))
                {
                    UserPreferences.SetValue("ExamHour", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("ExamHour");
                }
            }
            set
            {
                UserPreferences.SetValue("ExamHour", value);
            }
        }

        #endregion 

        #region ExamInstruction
        public static string ExamInstruction
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ExamInstruction")))
                {
                    UserPreferences.SetValue("ExamInstruction", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("ExamInstruction");
                }
            }
            set
            {
                UserPreferences.SetValue("ExamInstruction", value);
            }
        }
        #endregion


        #region SectionInstruction
        public static string SectionInstruction
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("SectionInstruction")))
                {
                    UserPreferences.SetValue("SectionInstruction", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("SectionInstruction");
                }
            }
            set
            {
                UserPreferences.SetValue("SectionInstruction", value);
            }
        }
        #endregion

        #region DeviceId
        public static string DeviceId
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("DeviceId")))
                {
                    UserPreferences.SetValue("DeviceId", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("DeviceId");
                }
            }
            set
            {
                UserPreferences.SetValue("DeviceId", value);
            }
        }
        #endregion 

        //#region NoOfGroups
        //public static string NoOfGroups
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(UserPreferences.GetValue("NoOfGroups")))
        //        {
        //            UserPreferences.SetValue("NoOfGroups", string.Empty);
        //            return string.Empty;
        //        }
        //        else
        //        {
        //            return UserPreferences.GetValue("NoOfGroups");
        //        }
        //    }
        //    set
        //    {
        //        UserPreferences.SetValue("NoOfGroups", value);
        //    }
        //}
        //#endregion


        #region ServerHour
        public static string ServerHour
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ServerHour")))
                {
                    UserPreferences.SetValue("ServerHour", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("ServerHour");
                }
            }
            set
            {
                UserPreferences.SetValue("ServerHour", value);
            }
        }

        #endregion

        #region ServerMinute
        public static string ServerMinute
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ServerMinute")))
                {
                    UserPreferences.SetValue("ServerMinute", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("ServerMinute");
                }
            }
            set
            {
                UserPreferences.SetValue("ServerMinute", value);
            }
        }

        #endregion

        #region ServerSecond
        public static string ServerSecond
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ServerSecond")))
                {
                    UserPreferences.SetValue("ServerSecond", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("ServerSecond");
                }
            }
            set
            {
                UserPreferences.SetValue("ServerSecond", value);
            }
        }

        #endregion

        #region IsActivityDestroy
        public static string IsActivityDestroy
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsActivityDestroy")))
                {
                    UserPreferences.SetValue("IsActivityDestroy", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("IsActivityDestroy");
                }
            }
            set
            {
                UserPreferences.SetValue("IsActivityDestroy", value);
            }
        }

        #endregion

        #region ExamDurationHour
        public static string ExamDurationHour
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ExamDurationHour")))
                {
                    UserPreferences.SetValue("ExamDurationHour", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("ExamDurationHour");
                }
            }
            set
            {
                UserPreferences.SetValue("ExamDurationHour", value);
            }
        }

        #endregion

        #region ExamDurationMinute
        public static string ExamDurationMinute
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ExamDurationMinute")))
                {
                    UserPreferences.SetValue("ExamDurationMinute", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("ExamDurationMinute");
                }
            }
            set
            {
                UserPreferences.SetValue("ExamDurationMinute", value);
            }
        }

        #endregion

        #region ServerDate
        public static string ServerDate
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ServerDate")))
                {
                    UserPreferences.SetValue("ServerDate", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("ServerDate");
                }
            }
            set
            {
                UserPreferences.SetValue("ServerDate", value);
            }
        }

        #endregion

        #region LastUpdatedSectionID
        public static string LastUpdatedSectionID
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("LastUpdatedSectionID")))
                {
                    UserPreferences.SetValue("LastUpdatedSectionID", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("LastUpdatedSectionID");
                }
            }
            set
            {
                UserPreferences.SetValue("LastUpdatedSectionID", value);
            }
        }

        #endregion

        #region ServerUpdatedDateTime
        public static string ServerUpdatedDateTime
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ServerUpdatedDateTime")))
                {
                    UserPreferences.SetValue("ServerUpdatedDateTime", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("ServerUpdatedDateTime");
                }
            }
            set
            {
                UserPreferences.SetValue("ServerUpdatedDateTime", value);
            }
        }

        #endregion

        #region UpdatedLocalTime
        public static string UpdatedLocalTime
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("UpdatedLocalTime")))
                {
                    UserPreferences.SetValue("UpdatedLocalTime", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("UpdatedLocalTime");
                }
            }
            set
            {
                UserPreferences.SetValue("UpdatedLocalTime", value);
            }
        }

        #endregion

        #region NotificationCount
        public static string NotificationCount
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("NotificationCount")))
                {
                    UserPreferences.SetValue("NotificationCount", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("NotificationCount");
                }
            }
            set
            {
                UserPreferences.SetValue("NotificationCount", value);
            }
        }

        #endregion

        #region IsSyncupTryingCount
        public static string IsSyncupTryingCount
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsSyncupTryingCount")))
                {
                    UserPreferences.SetValue("IsSyncupTryingCount", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("IsSyncupTryingCount");
                }
            }
            set
            {
                UserPreferences.SetValue("IsSyncupTryingCount", value);
            }
        }

        #endregion   

    
        #region IsStartWithLogin
        public static bool IsStartWithLogin
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsStartWithLogin")))
                {
                    UserPreferences.SetValue("IsStartWithLogin", false.ToString());

                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsStartWithLogin"));
                }
            }
            set
            {
                UserPreferences.SetValue("IsStartWithLogin", value.ToString());
            }
        }
        #endregion



        #region IsPROTimerRunning
        public static bool IsPRO_Assesment_TimerRunning
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsPROTimerRunning")))
                {
                    UserPreferences.SetValue("IsPROTimerRunning", false.ToString());

                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsPROTimerRunning"));
                }
            }
            set
            {
                UserPreferences.SetValue("IsPROTimerRunning", value.ToString());
            }
        }
        #endregion 

        //#region FaceNotDetectedAlertCount
        //public static string FaceNotDetectedAlertCount
        //{
        //    get
        //    {
        //        if (string.IsNullOrEmpty(UserPreferences.GetValue("FaceNotDetectedAlertCount")))
        //        {
        //            UserPreferences.SetValue("FaceNotDetectedAlertCount", "0");
        //            return "0";
        //        }
        //        else
        //        {
        //            return UserPreferences.GetValue("FaceNotDetectedAlertCount");
        //        }
        //    }
        //    set
        //    {
        //        UserPreferences.SetValue("FaceNotDetectedAlertCount", value);
        //    }
        //}
        //#endregion


        #region LoadSeekerDashboardData
        public static SeekerDashboardResponseModel LoadSeekerDashboardData
        {
            get
            {
                string value = UserPreferences.GetValue("LoadSeekerDashboardData");

                if (string.IsNullOrEmpty(value))
                {
                    UserPreferences.SetValue("LoadSeekerDashboardData", Newtonsoft.Json.JsonConvert.SerializeObject(new SeekerDashboardResponseModel()));
                    return null;
                }
                else
                {
                    var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<SeekerDashboardResponseModel>(value);
                    return obj;

                }
            }
            set
            {
                if (value != null)
                {
                    var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
                    UserPreferences.SetValue("LoadSeekerDashboardData", jsonstring);
                }
                else
                {
                    UserPreferences.SetValue("LoadSeekerDashboardData", String.Empty);
                }
            }
        }
        #endregion

        #region IsEnglish
        public static bool IsEnglish
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsEnglish")))
                {
                    UserPreferences.SetValue("IsEnglish", false.ToString());
                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsEnglish"));
                }

            }
            set
            {
                string boolstring = "false";
                if (value)
                {
                    boolstring = "true";

                }
                UserPreferences.SetValue("IsEnglish", boolstring);
            }
        }

        #endregion

        #region IsHindi
        public static bool IsHindi
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsHindi")))
                {
                    UserPreferences.SetValue("IsHindi", false.ToString());
                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsHindi"));
                }

            }
            set
            {
                string boolstring = "false";
                if (value)
                {
                    boolstring = "true";

                }
                UserPreferences.SetValue("IsHindi", boolstring);
            }
        }

        #endregion

        #region IsToggledEnglish
        public static bool IsToggledEnglish
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsToggledEnglish")))
                {
                    UserPreferences.SetValue("IsToggledEnglish", false.ToString());
                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsToggledEnglish"));
                }

            }
            set
            {
                string boolstring = "false";
                if (value)
                {
                    boolstring = "true";

                }
                UserPreferences.SetValue("IsToggledEnglish", boolstring);
            }
        }

        #endregion

        #region IsToggledHindi
        public static bool IsToggledHindi
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("IsToggledHindi")))
                {
                    UserPreferences.SetValue("IsToggledHindi", false.ToString());
                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("IsToggledHindi"));
                }

            }
            set
            {
                string boolstring = "false";
                if (value)
                {
                    boolstring = "true";

                }
                UserPreferences.SetValue("IsToggledHindi", boolstring);
            }
        }

        #endregion

        #region SelectedlanguageID
        public static string SelectedlanguageID
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("SelectedlanguageID")))
                {
                    UserPreferences.SetValue("SelectedlanguageID", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("SelectedlanguageID");
                }
            }
            set
            {
                UserPreferences.SetValue("SelectedlanguageID", value);
            }
        }
        #endregion


        #region OldVersion
        public static bool OldVersion
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("OldVersion")))
                {
                    UserPreferences.SetValue("OldVersion", false.ToString());
                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("OldVersion"));
                }
            }
            set
            {
                UserPreferences.SetValue("OldVersion", value.ToString());
            }

        }

        #endregion


        #region PRO_CompanyName
        public static string PRO_CompanyName
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("PRO_CompanyName")))
                {
                    UserPreferences.SetValue("PRO_CompanyName", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("PRO_CompanyName");
                }
            }
            set
            {
                UserPreferences.SetValue("PRO_CompanyName", value);
            }
        }
        #endregion

        #region PRO_CompanyName
        public static string PRO_ExamLastElapsedTime
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("PRO_ExamLastElapsedTime")))
                {
                    UserPreferences.SetValue("PRO_ExamLastElapsedTime", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("PRO_ExamLastElapsedTime");
                }
            }
            set
            {
                UserPreferences.SetValue("PRO_ExamLastElapsedTime", value);
            }
        }
        #endregion

        #region PRO_CompanyName
        public static string PRO_ServerTime
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("PRO_ServerTime")))
                {
                    UserPreferences.SetValue("PRO_ServerTime", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("PRO_ServerTime");
                }
            }
            set
            {
                UserPreferences.SetValue("PRO_ServerTime", value);
            }
        }
        #endregion

        #region PRO_TestPinCreatedAt
        public static string PRO_TestPinCreatedAt
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("PRO_TestPinCreatedAt")))
                {
                    UserPreferences.SetValue("PRO_TestPinCreatedAt", string.Empty);
                    return string.Empty;
        }
                else
                {
                    return UserPreferences.GetValue("PRO_TestPinCreatedAt");
                }
            }
            set
            {
                UserPreferences.SetValue("PRO_TestPinCreatedAt", value);
            }
        }
        #endregion

        #region PRO_TestLogo
        public static string PRO_TestLogo
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("PRO_TestLogo")))
                {
                    UserPreferences.SetValue("PRO_TestLogo", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("PRO_TestLogo");
                }
            }
            set
            {
                UserPreferences.SetValue("PRO_TestLogo", value);
            }
        }
        #endregion

        #region TestPinMasterData
        public static AssignedAssessmentDetails TestPinMasterData
        {
            get
            {
                string value = UserPreferences.GetValue("TestPinMasterData");

                if (string.IsNullOrEmpty(value))
                {
                    UserPreferences.SetValue("TestPinMasterData", Newtonsoft.Json.JsonConvert.SerializeObject(new AssignedAssessmentDetails()));
                    return null;
                }
                else
                {
                    var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<AssignedAssessmentDetails>(value);
                    return obj;

                }
            }
            set
            {
                if (value != null)
                {
                    var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
                    UserPreferences.SetValue("TestPinMasterData", jsonstring);
                }
                else
                {
                    UserPreferences.SetValue("TestPinMasterData", String.Empty);
                }
            }
        }

        #endregion

        #region PRO_AWS_Credentials
        public static PRO_AWSCredentials PRO_AWS_Credentials
        {
            get
            {
                string value = UserPreferences.GetValue("PRO_AWS_Credentials");

                if (string.IsNullOrEmpty(value))
                {
                    UserPreferences.SetValue("PRO_AWS_Credentials", Newtonsoft.Json.JsonConvert.SerializeObject(new PRO_AWSCredentials()));
                    return null;
                }
                else
                {
                    var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<PRO_AWSCredentials>(value);
                    return obj;

                }
            }
            set
            {
                if (value != null)
                {
                    var jsonstring = Newtonsoft.Json.JsonConvert.SerializeObject(value);
                    UserPreferences.SetValue("PRO_AWS_Credentials", jsonstring);
                }
                else
                {
                    UserPreferences.SetValue("PRO_AWS_Credentials", String.Empty);
                }
            }
        }

        #endregion

    
        #region Is_HireMee_PRO_User
        public static bool Is_HireMee_PRO_User
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("Is_HireMee_PRO_User")))
                {
                    UserPreferences.SetValue("Is_HireMee_PRO_User", false.ToString());
                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("Is_HireMee_PRO_User"));
                }
            }
            set
            {
                UserPreferences.SetValue("Is_HireMee_PRO_User", value.ToString());
            }

        }

        #endregion

        #region Is_NavigationLog
        public static bool Is_NavigationLog
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("Is_NavigationLog")))
                {
                    UserPreferences.SetValue("Is_NavigationLog", false.ToString());
                    return false;
                }
                else
                {
                    return Convert.ToBoolean(UserPreferences.GetValue("Is_NavigationLog"));
                }
            }
            set
            {
                UserPreferences.SetValue("Is_NavigationLog", value.ToString());
            }

        }

        #endregion

        #region CapturedAssesmentImageFilePath
        public static string CapturedAssesmentImageFilePath
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("CapturedAssesmentImageFilePath")))
                {
                    UserPreferences.SetValue("CapturedAssesmentImageFilePath", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("CapturedAssesmentImageFilePath");
                }
            }
            set
            {
                UserPreferences.SetValue("CapturedAssesmentImageFilePath", value);
            }
        }
        #endregion

        #region Is_Traning_Image_Available
        public static string Is_Traning_Image_Available
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("Is_Traning_Image_Available")))
                {
                    UserPreferences.SetValue("Is_Traning_Image_Available", string.Empty);
                    return string.Empty;
                }
                else
                {
                    return UserPreferences.GetValue("Is_Traning_Image_Available");
                }
            }
            set
            {
                UserPreferences.SetValue("Is_Traning_Image_Available", value);
            }
        }
        #endregion

        #region ElapsedSeconds
        public static string ElapsedSeconds
        {
            get
            {
                if (string.IsNullOrEmpty(UserPreferences.GetValue("ElapsedSeconds")))
                {
                    UserPreferences.SetValue("ElapsedSeconds", "0");
                    return "0";
                }
                else
                {
                    return UserPreferences.GetValue("ElapsedSeconds");
                }
            }
            set
            {
                UserPreferences.SetValue("ElapsedSeconds", value);
            }
        }
        #endregion




    }
}
