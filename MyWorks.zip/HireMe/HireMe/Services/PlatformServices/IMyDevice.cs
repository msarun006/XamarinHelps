﻿namespace HireMe
{
    public interface IMyDevice
    {
        string GetDeviceID();
        string GetDeviceModel();
        string GetDeviceBrandName();
        void closeApplication();
        string GetDeviceType();
        string GetDeviceVersion();
        bool PermissionStatus();
        bool IsInternetAvailable();
        bool IsHostReachable();
        bool IsDeviceSupportToDetectTheUserFace();
        void OpenGooglePlayService();
        void OpnePlayStore();

        string NetworkType();


    }
}
