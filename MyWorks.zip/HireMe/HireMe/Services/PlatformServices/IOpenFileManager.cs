﻿using System.Threading.Tasks;

namespace HireMe
{
    public interface IOpenFileManager
    {
        Task<string> OpenFile();
    }
}
