﻿using System;
namespace HireMe
{
	public interface IAnalyticService
	{
		void Track_App_Page(String PageNameToTrack);
		void Track_App_Event(String GAEventCategory, String EventToTrack);

		void Track_App_Exception(String ExceptionMessageToTrack, Boolean isFatalException);
	}
}
