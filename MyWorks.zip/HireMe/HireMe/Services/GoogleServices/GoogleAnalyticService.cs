﻿using System;
using Xamarin.Forms;

namespace HireMe
{
	public static class GoogleAnalyticService
	{
		public static void Track_App_Page(String PageNameToTrack)
		{
			DependencyService.Get<IAnalyticService>().Track_App_Page(PageNameToTrack);
		}

		public static void Track_App_Event(String GAEventCategory, String EventToTrack)
		{
			DependencyService.Get<IAnalyticService>().Track_App_Event(GAEventCategory, EventToTrack);
		}

		public static void Track_App_Exception(String ExceptionMessageToTrack, Boolean isFatalException)
		{
			DependencyService.Get<IAnalyticService>().Track_App_Exception(ExceptionMessageToTrack, isFatalException);
		}
	}
}
