﻿using Amazon.S3;
using Amazon.S3.Model;
using HireMe.Helpers;
using System;
using System.IO;
using Amazon.S3.Transfer;
using System.Threading.Tasks;

namespace HireMe.Services
{
    public class S3Manager
    {

        public static async Task<string> UploadFile(string filepath, string filekey, string bucket)
        {
            string s3path = string.Empty;

            try
            {
                TransferUtilityUploadRequest _request = new TransferUtilityUploadRequest();
                _request.BucketName = bucket;
                _request.FilePath = filepath;
                _request.Key = filekey;

                using (TransferUtility _transferUtility = new TransferUtility(S3Utils.S3Client))
                {
                    await _transferUtility.UploadAsync(_request);
                }
                GetPreSignedUrlRequest request = new GetPreSignedUrlRequest();
                request.BucketName = bucket;
                request.Key = filekey;
                request.Expires = DateTime.Now.AddMinutes(5);
                request.Protocol = Protocol.HTTP;
                string url = S3Utils.S3Client.GetPreSignedURL(request);
                s3path = filekey;

            }
            catch (AmazonS3Exception exception)
            {
                s3path = string.Empty;
                System.Diagnostics.Debug.WriteLine("AMAZON-S3-EXCEPTION: Could not process upload request" + exception.StackTrace);
                SendErrorMessageToServer(exception, "S3Manager.UploadFile");
            }
            return s3path;
        }




        //public static async Task<string> UploadFile(string filepath, string filekey, string bucket)
        //{
        //    string s3path = string.Empty;

        //    try
        //    {
        //        //if (string.IsNullOrEmpty(AppPreferences.S3AccessKeyID))
        //        //{
        //        //    var obj = new S3Utils();
        //        //    await obj.GetS3Credentials();
        //        //}
        //        //await GetS3Credentials("s3container");
        //        //Amazon.S3.Model.PutBucketRequest _PutBucketRequest = new Amazon.S3.Model.PutBucketRequest();
        //        Amazon.S3.Transfer.TransferUtilityUploadRequest _request = new Amazon.S3.Transfer.TransferUtilityUploadRequest();
        //        _request.BucketName = bucket;
        //        _request.FilePath = filepath;
        //        // _request.CannedACL = Amazon.S3.S3CannedACL.AuthenticatedRead;
        //        _request.Key = filekey;


        //        using (Amazon.S3.Transfer.TransferUtility _transferUtility = new Amazon.S3.Transfer.TransferUtility(S3Utils.S3Client))
        //        {
        //            await _transferUtility.UploadAsync(_request);
        //        }
        //        GetPreSignedUrlRequest request = new GetPreSignedUrlRequest();
        //        request.BucketName = bucket;
        //        request.Key = filekey;
        //        request.Expires = DateTime.Now.AddMinutes(5);// DateTime.Now.AddSeconds(30);
        //        request.Protocol = Protocol.HTTP;
        //        string url = S3Utils.S3Client.GetPreSignedURL(request);

        //        ////s3path = APIData.S3_BASE_URL + bucket + "/" + filekey;
        //        //s3path = url;
        //        s3path = filekey;

        //    }
        //    catch (Amazon.S3.AmazonS3Exception exception)
        //    {
        //        s3path = string.Empty;
        //        System.Diagnostics.Debug.WriteLine("AMAZON-S3-EXCEPTION: Could not process upload request" + exception.StackTrace);
        //        SendErrorMessageToServer(exception, "S3Manager.UploadFile");
        //    }
        //    return s3path;
        //}


        public static byte[] ReadFully(Stream stream, int initialLength = -1)

        {

            // If we've been passed an unhelpful initial length, just

            // use 32K.

            if (initialLength < 1)

            {

                initialLength = 32768;

            }



            byte[] buffer = new byte[initialLength];

            int read = 0;



            int chunk;

            while ((chunk = stream.Read(buffer, read, buffer.Length - read)) > 0)

            {

                read += chunk;



                // If we've reached the end of our buffer, check to see if there's

                // any more information
                if (read == buffer.Length)

                {

                    int nextByte = stream.ReadByte();

                    // End of stream? If so, we're done

                    if (nextByte == -1)

                    {
                        return buffer;
                    }
                    // Nope. Resize the buffer, put in the byte we've just

                    // read, and continue

                    byte[] newBuffer = new byte[buffer.Length * 2];

                    Array.Copy(buffer, newBuffer, buffer.Length);

                    newBuffer[read] = (byte)nextByte;

                    buffer = newBuffer;
                    read++;
                }
            }
            // Buffer is now too big. Shrink it.

            byte[] ret = new byte[read];

            Array.Copy(buffer, ret, read);
            return ret;
        }

        public static async Task<string> UploadFileStream(System.IO.Stream stream, string filekey, string bucket)
        {
            string s3path = string.Empty;

            try
            {
                Amazon.S3.Transfer.TransferUtilityUploadRequest _request = new Amazon.S3.Transfer.TransferUtilityUploadRequest();


                MemoryStream mstream = new MemoryStream();
                var binaryData = ReadFully(stream);
                _request.BucketName = bucket;
                _request.InputStream = new MemoryStream(binaryData);
                _request.AutoResetStreamPosition = true;
                _request.AutoCloseStream = false;
                _request.CannedACL = Amazon.S3.S3CannedACL.AuthenticatedRead;
                _request.Key = filekey;
                _request.UploadProgressEvent += _request_UploadProgressEvent;

                using (Amazon.S3.Transfer.TransferUtility _transferUtility = new Amazon.S3.Transfer.TransferUtility(S3Utils.S3Client))
                {
                    await _transferUtility.UploadAsync(_request);
                }


                GetPreSignedUrlRequest request = new GetPreSignedUrlRequest();
                request.BucketName = bucket;
                request.Key = filekey;
                request.Expires = DateTime.Now.AddSeconds(30);
                request.Protocol = Protocol.HTTP;
                string url = S3Utils.S3Client.GetPreSignedURL(request);


                s3path = url;


            }
            catch (Amazon.S3.AmazonS3Exception exception)
            {
                s3path = string.Empty;
                System.Diagnostics.Debug.WriteLine("AMAZON-S3-EXCEPTION: Could not process upload request" + exception.StackTrace);
                SendErrorMessageToServer(exception, "S3Manager.UploadFile");
            }
            return s3path;
        }

        private static void _request_UploadProgressEvent(object sender, UploadProgressArgs e)
        {

        }

        public static string GeneratePreSignedURL(string bucketName, string objectKey, int minutes)
        {
            string urlString = "";
            GetPreSignedUrlRequest request = new GetPreSignedUrlRequest
            {
                BucketName = bucketName,
                Key = objectKey,
                Expires = DateTime.Now.AddMinutes(minutes)

            };

            try
            {
                urlString = S3Utils.S3Client.GetPreSignedURL(request);
                //string url = s3Client.GetPreSignedURL(request1);
            }
            catch (AmazonS3Exception amazonS3Exception)
            {
                if (amazonS3Exception.ErrorCode != null &&
                    (amazonS3Exception.ErrorCode.Equals("InvalidAccessKeyId")
                    ||
                    amazonS3Exception.ErrorCode.Equals("InvalidSecurity")))
                {
                    System.Diagnostics.Debug.WriteLine("Check the provided AWS Credentials.");
                    System.Diagnostics.Debug.WriteLine(
                    "To sign up for service, go to http://aws.amazon.com/s3");
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine(
                    "Error occurred. Message:'{0}' when listing objects",
                     amazonS3Exception.Message);
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
                SendErrorMessageToServer(e, "S3Manager.GeneratePreSignedURL");
            }

            return urlString;

        }

        #region SendErrorMessageToServer
        public static void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
