﻿using HireMe.Models.SocialLoginData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HireMe.Services.SocialAuthentication
{
    public interface IFacebookManager
    {
        // void Login(Action<FacebookUserModel, string> onLoginComplete);
        void Login();
        void Logout();
    }
}
