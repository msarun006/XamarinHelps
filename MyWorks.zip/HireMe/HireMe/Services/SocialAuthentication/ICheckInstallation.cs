﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HireMe.Services.SocialAuthentication
{
    public interface ICheckInstallation
    {
        bool IsAppInstalled(string packageName);
    }
}
