﻿using Xamarin.Forms;
using HireMe.ViewModels;

namespace HireMe.UI
{

    public partial class ResetPasswordPage : ContentPage
    {
        private ResetPasswordViewModel _ResetPasswordViewModel { get; set; }
        public ResetPasswordPage()
        {
            InitializeComponent();
            _ResetPasswordViewModel = new ResetPasswordViewModel(Navigation);
            BindingContext = _ResetPasswordViewModel;
        }

        private void UnfocusedEvent(object sender, FocusEventArgs e)
        {
            var entry = (Entry)sender;
            var entryclassid = entry.ClassId;
            _ResetPasswordViewModel.TapCommand.Execute(entryclassid);
        }
    }
}