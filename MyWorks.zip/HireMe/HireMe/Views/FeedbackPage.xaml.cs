using HireMe.ViewModels;

using Xamarin.Forms;

namespace HireMe
{
    public partial class FeedbackPage : ContentPage
	{
        private FeedbackViewModel _feedbackViewModel;
        public FeedbackPage()
		{
			InitializeComponent();
            if(Device.RuntimePlatform.Equals("Android"))
            {
                //Track Page 
                GoogleAnalyticService.Track_App_Page("Android FeedbackPage");
            }
            //or iOS 
            else
            { //Track Page 
                GoogleAnalyticService.Track_App_Page("iOS  FeedbackPage");
            }
            _feedbackViewModel = new FeedbackViewModel();
            BindingContext = _feedbackViewModel;

        }
        

    }
}
