﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class LinkedInIOSPage : ContentPage
    {
        public LinkedInIOSPage()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this,false);
        }

        async protected override void OnAppearing()
        {
           // base.OnAppearing();
            await Task.Yield();
            // Remove activity indicator and set up real views
        }
    }
}