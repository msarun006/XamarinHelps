﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using HireMe.ViewModels;

namespace HireMe
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ChangeProfilePicturePage : ContentPage
    {
        public ChangeProfilePicturePage()
        {
            InitializeComponent();
            BindingContext =new ChangeProfilePictrurePageViewModel(Navigation);
        }

      
    }
}
