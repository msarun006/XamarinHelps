﻿
using Xamarin.Forms;

namespace HireMe
{
    public partial class GoogleLoginPage : ContentPage
    {
        public GoogleLoginPage()
        {
            NavigationPage.SetHasNavigationBar(this, false);
            InitializeComponent();
        }
    }
}
