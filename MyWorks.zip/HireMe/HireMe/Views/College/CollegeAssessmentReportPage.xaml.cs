﻿
using Xamarin.Forms;

namespace HireMe
{
    public partial class CollegeAssessmentReportPage : ContentPage
    {
        public CollegeAssessmentReportPage()
        {
            InitializeComponent();
            Title = "Assessment Report";
            BindingContext = new AssessmentReportViewModel(Navigation);
        }
    }
}
