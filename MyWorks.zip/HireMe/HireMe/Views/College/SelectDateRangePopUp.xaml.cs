﻿using System;
using System.Collections.Generic;
using MvvmHelpers;
using Rg.Plugins.Popup.Pages;
using Xamarin.Forms;

namespace HireMe
{
    public partial class SelectDateRangePopUp : PopupPage
    {

        DatePopUpViewModel DatePopUpViewModel;
        public SelectDateRangePopUp(String type, int year, int month)
        {


            InitializeComponent();
            DatePopUpViewModel = new DatePopUpViewModel(type, year, month);


            BindingContext = DatePopUpViewModel;


        }
    }




    public class DatePopUpViewModel : BaseViewModel
    {
        INavigation navigationService;
        List<String> monthList, yearList;
        String formatType;
        DatePopUpModel objDatePopUpModel;

        public int year { get; set; }

        public int month { get; set; }


        public Command CommonCommand
        {
            get;
            set;
        }

        public DatePopUpViewModel(String type, int year, int month)
        {

            this.year = year;
            this.month = month;

            formatType = type;
            CommonCommand = new Command(CommonFunctionCall);
        
            DateTiemItemSource = new List<DatePopUpModel>();

            yearList = new List<string>() { "2016",
            "2017",
            "2018",
            "2019",
            "2020" };

            monthList = new List<string>() { "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November","December",
            };



            if (formatType == "month")
            {
                for (int i = 0; i < 12; i++)
                {
                    objDatePopUpModel = new DatePopUpModel();
                    objDatePopUpModel.CommonStirng = monthList[i];
                    DateTiemItemSource.Add(objDatePopUpModel);

                }
            }

            if (formatType == "year")
            {
                for (int i = 0; i < yearList.Count; i++)
                {
                    objDatePopUpModel = new DatePopUpModel();
                    objDatePopUpModel.CommonStirng = yearList[i];
                    DateTiemItemSource.Add(objDatePopUpModel);

                }
            }
            if (this.month != 0)
                SetNumberOfDays = DateTime.DaysInMonth(this.year, this.month);
            TitleText = formatType.ToUpper();
        }

        private void CommonFunctionCall(object obj)
        {
            if(obj.ToString().Equals("cancel"))
            {
                Rg.Plugins.Popup.Services.PopupNavigation.PopAsync();
            }
        }

        private int _SetNumberOfDays;

        public int SetNumberOfDays
        {
            get { return _SetNumberOfDays; }
            set
            {
                _SetNumberOfDays = value; OnPropertyChanged();

                if (formatType == "day")
                {
                    for (int i = 1; i <= SetNumberOfDays; i++)
                    {
                        objDatePopUpModel = new DatePopUpModel();
                        objDatePopUpModel.CommonStirng = i.ToString();
                        DateTiemItemSource.Add(objDatePopUpModel);
                    }
                }
            }
        }




        private String _TitleText;

        public String TitleText
        {
            get { return _TitleText; }
            set { _TitleText = value; OnPropertyChanged(); }
        }


        public Command SelectedCommand => new Command(() =>
        {


            String value = SelectedItem.CommonStirng;

            if (formatType == "day")
            {








                MessagingCenter.Send<DatePopUpViewModel, String>(this, "day", value);







            }
            else if (formatType == "month")
            {



                for (int i = 0; i < monthList.Count; i++)
                {
                    if (monthList[i].Equals(value))
                    {

                        MessagingCenter.Send(this, "month", (i + 1).ToString());
                    }

                }


            }
            else if (formatType == "year")
            {

                for (int i = 0; i < yearList.Count; i++)
                {
                    if (yearList[i].Equals(value))
                    {

                        MessagingCenter.Send(this, "year", (i + 1).ToString());
                    }

                }

              //  MessageStringConstants.SelectYear = value;
              //  MessagingCenter.Send<DatePopUpViewModel, String>(this, "year", value);
            }




            Rg.Plugins.Popup.Services.PopupNavigation.PopAsync();


        });


        public List<DatePopUpModel> _DateTiemItemSource;
        public List<DatePopUpModel> DateTiemItemSource
        {
            get { return _DateTiemItemSource; }
            set { _DateTiemItemSource = value; OnPropertyChanged(); }
        }


        private DatePopUpModel _SelectedItem;


        public DatePopUpModel SelectedItem
        {
            get { return _SelectedItem; }
            set
            {
                _SelectedItem = value; OnPropertyChanged();

            }
        }

    }

    public class DatePopUpModel
    {
        public String CommonStirng { get; set; }

    }

}