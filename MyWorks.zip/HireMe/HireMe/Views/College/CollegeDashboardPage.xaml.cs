﻿
using Xamarin.Forms;

namespace HireMe
{
    public partial class CollegeDashboardPage : ContentPage
    {

        CollegeDashboardViewModel CollegeDashboardViewModel;
       
        public CollegeDashboardPage()
        {
            InitializeComponent();
            Title = "College Dashboard";
            CollegeDashboardViewModel = new CollegeDashboardViewModel(Navigation);
            BindingContext = CollegeDashboardViewModel;

        }



      

        

        private void Handle_ValueChanged(object sender, SegmentedControl.FormsPlugin.Abstractions.ValueChangedEventArgs e)
        {

            int selectedNumber = e.NewValue;


            switch (selectedNumber)
            {
                case 0:
                    //mainPageViewModel.SelectedDate = DateTime.Now.Year.ToString();
                    CollegeDashboardViewModel.Index = 0;
                    CollegeDashboardViewModel.CommonFunctionCall("openpopup");

                    break;
                case 1:
                    // mainPageViewModel.SelectedDate = monthList[DateTime.Now.Month].ToString();
                    CollegeDashboardViewModel.Index = 1;
                    CollegeDashboardViewModel.CommonFunctionCall("openpopup");

                    break;
                case 2:
                    //  mainPageViewModel.SelectedDate = DateTime.Now.Day.ToString();


                    CollegeDashboardViewModel.Index = 2;
                    CollegeDashboardViewModel.CommonFunctionCall("openpopup");

                    break;

            }

        }
    }
}
 