﻿using System;

using Xamarin.Forms;
using Rg.Plugins.Popup.Pages;
using Acr.UserDialogs;

namespace HireMe
{
    public partial class CustomDatePicker : PopupPage
    {
        int _pagenumber;
        int numberOfClick;
        Button newButton;

        int firstDay, secondDay;
        public CustomDatePicker(int day)
        {
            InitializeComponent();
            _pagenumber = day;
            GeneratePageNumbers();
            numberOfClick = 0;
            firstDay = 0;
            secondDay = 0;



        }


        private void GeneratePageNumbers()
        {
            int TotalNumberPages = _pagenumber;
            int remainder = _pagenumber % 5;
            int NoOfRows = (TotalNumberPages - remainder) / 5;
            if (remainder > 0)
            {
                NoOfRows = NoOfRows + 1;
            }
            //Grid grid = new Grid();
            grid.VerticalOptions = LayoutOptions.Start;
            grid.HorizontalOptions = LayoutOptions.Fill;
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
            int count = 0;
            for (int r = 0; r < NoOfRows; r++)
            {
                grid.RowDefinitions.Add(new RowDefinition { Height = 55 });
                for (int c = 0; c < 5; c++)
                {
                    if (TotalNumberPages > count)
                    {
                        count++;
                        newButton = new Button
                        {
                            Text = count.ToString(),
                            TextColor = Color.Black,
                            Font = Font.SystemFontOfSize(NamedSize.Large),
                            BackgroundColor = Color.White,

                        };
                        newButton.Clicked += Button_Clicked;
                        grid.Children.Add(newButton);
                        Grid.SetRow(newButton, r);
                        Grid.SetColumn(newButton, c);
                    }
                }
            }
        }

        private void Button_Clicked(object sender, EventArgs e)
        {

            if (numberOfClick <= 1)
            {
                Button button = (Button)sender;
                string text = (string)button.Text;

                if (numberOfClick == 0)
                {
                    numberOfClick++;
                    button.BackgroundColor = Color.Green;
                    firstDay = int.Parse(text);

                }
                else if (numberOfClick == 1)
                {
                    secondDay = int.Parse(text);
                    if (firstDay < secondDay)
                    {
                        numberOfClick++;
                        button.BackgroundColor = Color.Green;
                        Rg.Plugins.Popup.Services.PopupNavigation.PopAsync();
                    }
                    else
                    {
                           UserDialogs.Instance.ShowError("Select Valid Date", 500);
                    }


                }



            }
            else
            {
                Rg.Plugins.Popup.Services.PopupNavigation.PopAsync();
            }





        }
    }
}