﻿
using Xamarin.Forms;

namespace HireMe
{
    public partial class StudentListPage : ContentPage
    {
        public StudentListPage(string title,string fromdate,string todate)
        {
            InitializeComponent();
            Title = "Candidate List";
            BindingContext = new StudentListViewModel(title,fromdate,todate);
        }
    }
}
