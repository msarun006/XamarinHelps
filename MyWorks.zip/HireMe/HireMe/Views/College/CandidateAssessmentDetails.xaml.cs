﻿using System.Collections.ObjectModel;
using Xamarin.Forms;

namespace HireMe
{
    public partial class CandidateAssessmentDetails : ContentPage
    {
        private CandidateAssessmentDetailsViewModel _CandidateDetailsViewModel;
        public CandidateAssessmentDetails(ObservableCollection<AssessmentReportResponseModel.Response> candidateslist, AssessmentReportResponseModel.Response objSearchDetails)
        {
            InitializeComponent();
            Title = "Candidate Details";
            _CandidateDetailsViewModel = new CandidateAssessmentDetailsViewModel(candidateslist,objSearchDetails);
            BindingContext = _CandidateDetailsViewModel;
        }
    }
}
