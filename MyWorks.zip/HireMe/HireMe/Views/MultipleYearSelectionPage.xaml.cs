﻿using System.Collections.Generic;

using Xamarin.Forms;

namespace HireMe.UI
{

    public partial class MultipleYearSelectionPage : ContentPage
	{
		MultipleYearSelectionPageViewModel MultipleYearSelectionPageViewModel;

		public MultipleYearSelectionPage(string PageName,List<Year> skills)
		{
			InitializeComponent();
            MultipleYearSelectionPageViewModel = new MultipleYearSelectionPageViewModel(Navigation, PageName, skills);
			BindingContext = MultipleYearSelectionPageViewModel;
		}

 

        void OnSkill_Toggled(object sender, ToggledEventArgs args)
		{
			MultipleYearSelectionPageViewModel.OnSkill_Toggled(sender, args);
		}

	}
}
