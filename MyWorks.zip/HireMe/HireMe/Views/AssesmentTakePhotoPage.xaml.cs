﻿using Acr.UserDialogs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AssesmentTakePhotoPage : ContentPage
    {
        public AssesmentTakePhotoPage()
        {
            InitializeComponent();
        }
        #region Handled BackButton Pressed
        protected override bool OnBackButtonPressed()
        {

            try
            {
                bool result;
                Device.BeginInvokeOnMainThread(async () =>
                {
                    result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.ExitAlertAssessment, "", "OK", "Cancel");
                    if (result)
                    {
                        if (AppPreferences.IsLoggeedIn == true)
                        {
                            var page = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                            App.Current.MainPage = page;
                        }
                        else
                        {
                            var page = new NavigationPage(new LoginPageNew());
                            App.Current.MainPage = page;
                        }
                    }

                });
                return true;
            }
            catch (Exception ex)
            {

                return true;
            }


        }
        #endregion
    }
}