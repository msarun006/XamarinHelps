﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.ViewModels.Assessment;
using System;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.Assessment
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ExternalDeviceStatusPage : ContentPage
    {
        ExternalDeviceStatusViewModel ExternalDeviceStatusViewModel;
        public ExternalDeviceStatusPage()
        {
            InitializeComponent();
            ExternalDeviceStatusViewModel = new ExternalDeviceStatusViewModel(Navigation);
            BindingContext = ExternalDeviceStatusViewModel;
            NavigationPage.SetHasNavigationBar(this, false);
        }
        protected override void OnAppearing()
        {
            base.OnAppearing();
            //ExternalDeviceStatusViewModel.CommonFunction("refresh");

        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
        }


        #region Handled BackButton Pressed
        protected override bool OnBackButtonPressed()
        {

            try
            {
                Device.BeginInvokeOnMainThread(async () =>
                  {
                      bool result;
                      if (AppPreferences.IsHindi)
                      {
                          result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.ExitAlertAssessmentHindi, null, MessageStringConstants.YesHindi, MessageStringConstants.NoHindi);
                      }
                      else
                      {
                          result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.ExitAlertAssessment, null, "Yes", "No");
                      }
                      if (result)
                      {
                          //DependencyService.Get<IExitApplication>().closeApplication();
                          var page = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                          App.Current.MainPage = page;
                          return;
                      }
                  });
                return true;
            }
            catch (Exception ex)
            {
                SendErrorMessageToServer(ex, "ExternalDeviceStatusPage.OnBackButtonPressed");
                return true;
            }


        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}