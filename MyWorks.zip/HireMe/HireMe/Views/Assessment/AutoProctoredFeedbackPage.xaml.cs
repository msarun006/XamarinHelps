﻿using HireMe.ViewModels.Assessment;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.Assessment
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AutoProctoredFeedbackPage : ContentPage
    {
        public AutoProctoredFeedbackPage()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            BindingContext = new AutoProctoredFeedbackViewModel();
        }

        //#region Handled BackButton Pressed
        //protected override bool OnBackButtonPressed()
        //{
        //    Device.BeginInvokeOnMainThread(async () =>
        //    {
        //        var result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.ExitAlert, null, "Yes", "No");
        //        if (result)
        //        {
        //           // DependencyService.Get<IExitApplication>().closeApplication();
        //        }
        //    });
        //    return true;
        //}
        //#endregion
    }
}