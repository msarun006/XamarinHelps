﻿
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.Assessment
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class BannerInstruction : ContentPage
    {
        public BannerInstruction()
        {
            InitializeComponent();
        }
    }
}