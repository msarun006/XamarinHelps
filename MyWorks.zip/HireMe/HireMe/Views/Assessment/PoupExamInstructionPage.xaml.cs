﻿using HireMe.ViewModels.Assessment;
using Rg.Plugins.Popup.Pages;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.Assessment
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PoupExamInstructionPage : PopupPage
    {
        PoupExamInstructionViewModel PoupExamInstructionViewModel;
        public PoupExamInstructionPage()
        {
            InitializeComponent();
            PoupExamInstructionViewModel = new PoupExamInstructionViewModel(Navigation);
            BindingContext = PoupExamInstructionViewModel;
        }
    }
}