﻿
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.Assessment
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AssessmentForgetPasswordPage : ContentPage
    {
        public AssessmentForgetPasswordPage()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);

            //BindingContext = new AssessmentForgetPasswordViewModel();
        }
    }
}