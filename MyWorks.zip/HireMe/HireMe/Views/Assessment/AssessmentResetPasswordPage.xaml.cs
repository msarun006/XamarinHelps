﻿
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.Assessment
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AssessmentResetPasswordPage : ContentPage
    {
        public AssessmentResetPasswordPage()
        {
            InitializeComponent();
        }
    }
}