﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.ViewModels.Assessment;
using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.JobSeeker
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AssessmentLanguageSelection : ContentPage
    {
        public AssessmentLanguageSelection()
        {
            InitializeComponent();
            BindingContext = new AssessmentLanguageViewModal(Navigation);
        }
        #region Handled BackButton Pressed
        protected override bool OnBackButtonPressed()
        {

            try
            {
                Device.BeginInvokeOnMainThread(async () =>
                {
                    bool result;
                    if (AppPreferences.IsHindi)
                    {
                        result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.ExitAlertAssessmentHindi, null, MessageStringConstants.YesHindi, MessageStringConstants.NoHindi);
                    }
                    else
                    {
                        result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.ExitAlertAssessment, null, "Yes", "No");
                    }
                    if (result)
                    {
                        //DependencyService.Get<IExitApplication>().closeApplication();
                        var page = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                        App.Current.MainPage = page;
                        return;
                    }
                });
                return true;
            }
            catch (Exception ex)
            {
                SendErrorMessageToServer(ex, "AssessmentLanguageSelection.OnBackButtonPressed");
                return true;
            }


        }
        #endregion
        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}