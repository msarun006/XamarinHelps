﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.Assessment
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AssessmentLoginPage : ContentPage
    {
       // AssessmentLoginViewModel AssessmentLoginViewModel;
        public AssessmentLoginPage()
        {
            InitializeComponent();
            //AssessmentLoginViewModel = new AssessmentLoginViewModel(Navigation);
            //BindingContext = AssessmentLoginViewModel;
        }
    }
}