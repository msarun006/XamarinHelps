﻿using HireMe.ViewModels.Assessment;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.Assessment
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ProctoredFeedbackPage : ContentPage
    {
        public ProctoredFeedbackPage()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            BindingContext = new ProctoredFeedbackViewModel();
        }
    }
}