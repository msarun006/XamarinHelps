﻿
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.Assessment
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class IntroCarouselPage : ContentPage
    {
        public IntroCarouselPage()
        {
            InitializeComponent();
        }
    }
}