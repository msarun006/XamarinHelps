﻿using HireMe.ViewModels.Assessment;
using Rg.Plugins.Popup.Pages;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.Assessment
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ZoomImageViewPage : PopupPage
    {
        public ZoomImageViewPage(string question)
        {
            InitializeComponent();
            BindingContext = new ZoomImageViewModel(question);
        }
        protected override bool OnBackButtonPressed()
        {
            return true;
        }
        protected override bool OnBackgroundClicked()
        {
            return false;
        }
    }
}