﻿using Acr.UserDialogs;
using HireMe.ViewModels.Assessment;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.Assessment
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ExamInstruction_Page : ContentPage
    {
        
        public ExamInstruction_Page()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            BindingContext = new ExamInstructionViewModel(Navigation);

        }

        #region Handled BackButton Pressed
        protected override bool OnBackButtonPressed()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                bool result;
                if (AppPreferences.IsHindi)
                {
                    result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.ExitAlertAssessmentHindi, null, MessageStringConstants.YesHindi, MessageStringConstants.NoHindi);
                }
                else
                {
                    result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.ExitAlertAssessment, null, "Yes", "No");
                }
                if (result)
                {
                    //DependencyService.Get<IExitApplication>().closeApplication();
                    var page = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                    App.Current.MainPage = page;
                    return;
                }
            });
            return true;
        }
        #endregion
    }
}