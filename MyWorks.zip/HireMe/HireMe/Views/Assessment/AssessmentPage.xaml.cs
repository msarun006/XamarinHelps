﻿using Acr.UserDialogs;
using HireMe.ViewModels.Assessment;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.Assessment
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AssessmentPage : ContentPage
    {
        AssessmentViewModel _AssessmentViewModel;
        public AssessmentPage()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            _AssessmentViewModel = new AssessmentViewModel(Navigation, dynamicButtonGrid, accordionstack, dynamicBtnScroll);
            BindingContext = _AssessmentViewModel;
        }
        #region Handled BackButton Pressed
        protected override bool OnBackButtonPressed()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                bool result;
                if (AppPreferences.IsHindi)
                {
                    result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.ExitAlertAssessmentHindi, null, MessageStringConstants.YesHindi, MessageStringConstants.NoHindi);
                }
                else
                {
                    result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.ExitAlertAssessment, null, "Yes", "No");
                }
                if (result)
                {
                    _AssessmentViewModel.TimerStop();
                    //DependencyService.Get<IExitApplication>().closeApplication();
                    var page = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                    App.Current.MainPage = page;
                    return;
                }
            });
            return true;
        }
        #endregion

        private void Switch_Toggled(object sender, ToggledEventArgs e)
        {
            _AssessmentViewModel.Switch_Toggled(sender, e);
        }


    }
}