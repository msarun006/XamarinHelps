﻿using Xamarin.Forms;

namespace HireMe
{

    public partial class CollegeViceRegistrationPage : ContentPage
	{
		#region CreateViewModelObject
		CollegeViceRegistrationPageViewModel CollegeViceRegistrationPageViewModel;
		#endregion


		#region Constructor
		public CollegeViceRegistrationPage()
		{
			NavigationPage.SetHasNavigationBar(this, false);
			InitializeComponent();
			CollegeViceRegistrationPageViewModel = new CollegeViceRegistrationPageViewModel(Navigation);
			BindingContext = CollegeViceRegistrationPageViewModel;
		}
		#endregion


		private void DatepickerDateofBirth_DateSelected(object sender, DateChangedEventArgs e)
		{
			CollegeViceRegistrationPageViewModel.RegistrationData.DOB = datepickerDateofBirth.Date.ToString("dd-MM-yyyy");
			CollegeViceRegistrationPageViewModel.DOBisVisible = true;
			CollegeViceRegistrationPageViewModel.DOBTextColor = Color.Black;
			CollegeViceRegistrationPageViewModel.DatePickerIsVisible = false;

		}
		//Password Field Unfocused Event Triggered
		private void EntryPassword_Unfocused(object sender, FocusEventArgs args)
		{
			CollegeViceRegistrationPageViewModel.EntryPassword_Unfocused(sender, args);

		}

		//ConfirmPassword Field Unfocused Event Triggered
		private void EntryConfirmPassword_Unfocused(object sender, FocusEventArgs args)
		{
			CollegeViceRegistrationPageViewModel.EntryConfirmPassword_Unfocused(sender, args);
		}
	}
}

