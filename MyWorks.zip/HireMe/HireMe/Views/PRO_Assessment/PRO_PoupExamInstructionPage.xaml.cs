﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using HireMe.ViewModels.Assessment;
using Rg.Plugins.Popup.Pages;
using Xamarin.Forms.Xaml;
using Acr.UserDialogs;
using HireMe.Interface;

namespace HireMe
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PRO_PoupExamInstructionPage : PopupPage
    {
       PRO_PoupExamInstructionViewModel PRO_PoupExamInstructionViewModel;
        public PRO_PoupExamInstructionPage(bool IsShowExamInstruction)
        {
            InitializeComponent();
            PRO_PoupExamInstructionViewModel = new PRO_PoupExamInstructionViewModel(Navigation, IsShowExamInstruction);
            BindingContext = PRO_PoupExamInstructionViewModel;
        }
        #region Handled BackButton Pressed
        protected override bool OnBackButtonPressed()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                bool result;
                result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.ExitAlert, null, "Yes", "No");
                if (result)
                {
                    DependencyService.Get<IExitApplication>().closeApplication();
                    return;
                }
            });
            return true;
        }
        #endregion
    }
}