﻿
using Acr.UserDialogs;
using HireMe.Interface;
using HireMe.ViewModels.PRO_Assessment;
using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace HireMe.Views.PRO_Assessment
{
    public partial class PRO_TestPinPage : ContentPage
    {
        #region View Model Declaration
        public PRO_TestPinViewModel _PRO_TestPinViewModel { get; set; }
        #endregion

        #region Main Constructors
        public PRO_TestPinPage()
        {
            InitializeComponent();
            _PRO_TestPinViewModel = new PRO_TestPinViewModel(Navigation);
            BindingContext = _PRO_TestPinViewModel;
        }
        #endregion

        #region Handled BackButton Pressed
        protected override bool OnBackButtonPressed()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                bool result;
                result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.ExitAlert, null, "Yes", "No");
                if (result)
                {
                   DependencyService.Get<IExitApplication>().closeApplication();
                   return;
                }
            });
            return true;
        }
        #endregion
    }
}
