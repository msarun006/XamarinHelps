﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.Interface;
using HireMe.ViewModels.PRO_Assessment;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.PRO_Assessment
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PRO_ExternalDeviceStatusPage : ContentPage
    {
        public PRO_ExternalDeviceStatusPage()
        {
            
            PRO_ExternalDeviceStatusViewModel CompatiablityCheckViewModel;
            InitializeComponent();
            CompatiablityCheckViewModel = new PRO_ExternalDeviceStatusViewModel();
            BindingContext = CompatiablityCheckViewModel;
            NavigationPage.SetHasNavigationBar(this, false);
        }
        protected override void OnAppearing()
        {
            base.OnAppearing();
           

        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
        }

        #region Handled BackButton Pressed
        protected override bool OnBackButtonPressed()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                bool result;
                result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.ExitAlert, null, "Yes", "No");
                if (result)
                {
                    DependencyService.Get<IExitApplication>().closeApplication();
                    return;
                }
            });
            return true;
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}