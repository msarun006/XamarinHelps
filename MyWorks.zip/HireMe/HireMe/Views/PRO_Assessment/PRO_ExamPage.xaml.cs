﻿using Acr.UserDialogs;
using HireMe.LocalDataBase;
using HireMe.Models.PRO_Assessment;
using HireMe.ViewModels.PRO_Assessment;
using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.PRO_Assessment
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PRO_ExamPage : ContentPage
    {
        PRO_ExamViewModel _viewModel { get; set; }
        public PRO_ExamPage(SectionInstructionContent content)
        {
            InitializeComponent();
            _viewModel = new PRO_ExamViewModel(Navigation, dynamicButtonGrid, content);
            BindingContext = _viewModel;
        }

        public PRO_ExamPage()
        {
            InitializeComponent();
            _viewModel = new PRO_ExamViewModel(Navigation, dynamicButtonGrid, null);
            BindingContext = _viewModel;
        }



        #region Handled BackButton Pressed
        protected override bool OnBackButtonPressed()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                if (AppPreferences.TestPinMasterData.is_section_navigation == Convert.ToString((int)is_section_navigation.Enable))
                {
                    var resultdata = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.AreyousuretogoExamSection, null, "Yes", "No");
                    if (resultdata)
                    {
                        _viewModel.TimerStop();
                        Application.Current.MainPage = new NavigationPage(new PRO_ExamSectionPage());
                    }
                }
                else
                {
                    var result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.ExitAlert, null, "Yes", "No");
                    if (result)
                    {
                        _viewModel.TimerStop();
                        Application.Current.MainPage = new NavigationPage(new PRO_TestPinPage());
                    }
                }
              
            });
            return true;
        }
        #endregion


        protected override void OnDisappearing()
        {
            base.OnDisappearing();
        }


        private void Switch_Toggled(object sender, ToggledEventArgs e)
        {
            //  _viewModel.Switch_Toggled(sender, e);
        }
    }
}