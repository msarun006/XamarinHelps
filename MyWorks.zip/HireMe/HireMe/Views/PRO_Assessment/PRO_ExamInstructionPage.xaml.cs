﻿using Acr.UserDialogs;
using HireMe.Interface;
using HireMe.ViewModels.PRO_Assessment;
using System;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.PRO_Assessment
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PRO_ExamInstructionPage : ContentPage
    {
        PRO_ExamInstructionViewModel _viewModel { get; set; }
        public PRO_ExamInstructionPage(HireMe.Models.PRO_Assessment.SectionInstructionContent objContent)
        {
            InitializeComponent();
             _viewModel = new PRO_ExamInstructionViewModel(objContent);
            BindingContext = _viewModel;
        }


        #region Handled BackButton Pressed
        protected override bool OnBackButtonPressed()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                bool result;
                result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.ExitAlert, null, "Yes", "No");
                if (result)
                {
                    DependencyService.Get<IExitApplication>().closeApplication();
                    return;
                }
            });
            return true;
        }
        #endregion
    }
}