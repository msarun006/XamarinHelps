﻿

using Acr.UserDialogs;
using HireMe.Interface;
using HireMe.ViewModels.PRO_Assessment;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.PRO_Assessment
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PRO_ExamFeedbackPage : ContentPage
    {
        public PRO_ExamFeedbackPage(HireMee.Models.PRO_Assessment.ResultResponse result)
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            BindingContext = new PRO_ExamFeedBackViewModel(result);
        }
        #region Handled BackButton Pressed
        protected override bool OnBackButtonPressed()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                bool result;
                result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.ExitAlert, null, "Yes", "No");
                if (result)
                {
                    DependencyService.Get<IExitApplication>().closeApplication();
                    return;
                }
            });
            return true;
        }
        #endregion
    }
}