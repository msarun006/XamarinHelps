﻿using System.Collections.Generic;
using Acr.UserDialogs;
using HireMe.Models.PRO_Assessment;
using HireMe.ViewModels.Assessment;
using HireMe.ViewModels.PRO_Assessment;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System;
using HireMe.Interface;

namespace HireMe.Views.PRO_Assessment
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PRO_ExamSectionPage : ContentPage
    {
        PRO_ExamSectionViewModel _AssessmentViewModel;
        public PRO_ExamSectionPage()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            _AssessmentViewModel = new PRO_ExamSectionViewModel(Navigation, accordionstack);
            BindingContext = _AssessmentViewModel;
        }


        #region Handled BackButton Pressed
        protected override bool OnBackButtonPressed()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                bool result;
                result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.ExitAlert, null, "Yes", "No");
                if (result)
                {
                    DependencyService.Get<IExitApplication>().closeApplication();
                    return;
                }
            });
            return true;
        }
        #endregion

        private void Switch_Toggled(object sender, ToggledEventArgs e)
        {

        }
    }
}