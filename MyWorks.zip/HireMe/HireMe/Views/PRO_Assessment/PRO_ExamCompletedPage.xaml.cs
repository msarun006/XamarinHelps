﻿using Acr.UserDialogs;
using HireMe.Interface;
using HireMe.ViewModels.PRO_Assessment;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.PRO_Assessment
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PRO_ExamCompletedPage : ContentPage
    {
       // public PRO_ExamCompletedViewModel _PRO_ExamCompletedViewModel { get; set; }
        public PRO_ExamCompletedPage(HireMee.Models.PRO_Assessment.ResultResponse result)
        {
            InitializeComponent();
            BindingContext = new PRO_ExamCompletedViewModel(result);
            
        Title = "Exam Completed";
        }
     
        #region Handled BackButton Pressed
        protected override bool OnBackButtonPressed()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                bool result;
                result = await UserDialogs.Instance.ConfirmAsync(MessageStringConstants.ExitAlert, null, "Yes", "No");
                if (result)
                {
                    DependencyService.Get<IExitApplication>().closeApplication();
                    return;
                }
            });
            return true;
        }
        #endregion
    }
}