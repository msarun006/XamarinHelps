﻿using HireMe.ViewModels;
using Xamarin.Forms;

namespace HireMe
{
    public partial class TermsOfUse : ContentPage
    {
        public TermsOfUse()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, true);
            BindingContext = new TermsOfUseViewModel();
        }
   
    }
}
