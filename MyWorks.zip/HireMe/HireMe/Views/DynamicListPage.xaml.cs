using System;
using Xamarin.Forms;

namespace HireMe
{
    public partial class DynamicListPage : ContentPage
{
	DynamicListPageViewModel DynamicListPageViewModel;
	public DynamicListPage(string PageName,string fieldtype, string fieldvalue = null)
	{
		System.Diagnostics.Debug.WriteLine("@ DynamicListPage.DynamicListPage");
            try
            {
                InitializeComponent();
                Title = fieldtype;
                DynamicListPageViewModel = new DynamicListPageViewModel(Navigation, PageName, fieldtype, fieldvalue);

                BindingContext = DynamicListPageViewModel;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
		
	}
}

}
//	public partial class DynamicListPage : ContentPage
//	{
//		#region ClassVariables

//		string _fieldType;
//		string _fieldValue;
//		MasterManager _masterDataManager;
//		IValueGetter _valueGetterInterface;


//		List<CollegeNameList> _collegeNameList;


//		List<State> _stateList;
//		List<District> _cityList;

//		ObservableCollection<Year> _yearList;
//		List<University> _universityList;
//		List<College> _collegeList;
//		List<CourseType> _coursetypeList;
//		List<Course> _courseList;
//		List<Specialization> _spealicationList;
//		List<Skill> _skillList;
//		Boolean isListAvailable = false;
//		Boolean isButtonClicked = false;

//		#endregion

//		#region Constructors

//		/// <summary>
//		/// Initializes a new instance of the <see cref="T:HireMe.DynamicListPage"/> class.
//		/// </summary>
//		/// <param name="fieldtype">Fieldtype.</param>
//		/// <param name="fieldvalue">Fieldvalue.</param>
//		/// <param name="valuegetter">Valuegetter.</param>
//		public DynamicListPage(string fieldtype, string fieldvalue = null, IValueGetter valuegetter = null)
//		{
//			System.Diagnostics.Debug.WriteLine("@ DynamicListPage.DynamicListPage");
//			_fieldType = fieldtype;
//			_fieldValue = fieldvalue;
//			_valueGetterInterface = valuegetter;
//			_masterDataManager = new MasterManager();
//			InitializeComponent();
//			BindData();

//			searchbarText.IsEnabled = false;
//		}

//		void Handle_SearchButtonPressed(object sender, System.EventArgs e)
//		{
//			var searchtext = ((SearchBar)sender).Text;
//			if (string.IsNullOrEmpty(searchtext))
//			{
//				BindData();
//				return;
//			}

//			if (_fieldType == Constants.FieldType.CollegeName)
//			{
//				var searchresults = _collegeNameList.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
//				listviewDynamic.ItemsSource = searchresults;
//			}

//			if (_fieldType == Constants.FieldType.State)
//			{
//				var searchresults = _stateList.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
//				listviewDynamic.ItemsSource = searchresults;
//			}

//			if (_fieldType == Constants.FieldType.City)
//			{
//				var searchresults = _cityList.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
//				listviewDynamic.ItemsSource = searchresults;

//			}
//			if (_fieldType == Constants.FieldType.University)
//			{
//				searchbarText.IsEnabled = false;
//				var searchresults = _universityList.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
//				listviewDynamic.ItemsSource = searchresults;
//				if (searchresults.Count > 0)
//					searchbarText.IsEnabled = true;

//			}

//			if (_fieldType == Constants.FieldType.College)
//			{
//				searchbarText.IsEnabled = false;
//				var searchresults = _collegeList.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
//				listviewDynamic.ItemsSource = searchresults;
//				if (searchresults.Count > 0)
//					searchbarText.IsEnabled = true;

//			}

//			if (_fieldType == Constants.FieldType.CourseType)
//			{
//				var searchresults = _coursetypeList.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
//				listviewDynamic.ItemsSource = searchresults;

//			}

//			if (_fieldType == Constants.FieldType.Course)
//			{
//				var searchresults = _courseList.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
//				listviewDynamic.ItemsSource = searchresults;

//			}

//			if (_fieldType == Constants.FieldType.Specialization)
//			{
//				var searchresults = _spealicationList.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
//				listviewDynamic.ItemsSource = searchresults;

//			}
//		}

//		void SearchText_TextChanged(object sender, Xamarin.Forms.TextChangedEventArgs e)
//		{
//			var searchtext = e.NewTextValue;
//			if (string.IsNullOrEmpty(searchtext))
//			{
//				BindData();
//				return;
//			}

//			if (_fieldType == Constants.FieldType.CollegeName)
//			{
//				var searchresults = _collegeNameList.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
//				listviewDynamic.ItemsSource = searchresults;
//			}

//			if (_fieldType == Constants.FieldType.State)
//			{
//				var searchresults = _stateList.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
//				listviewDynamic.ItemsSource = searchresults;
//			}

//			if (_fieldType == Constants.FieldType.City)
//			{
//				var searchresults = _cityList.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
//				listviewDynamic.ItemsSource = searchresults;
//			}
//			if (_fieldType == Constants.FieldType.University)
//			{
//				var searchresults = _universityList.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
//				listviewDynamic.ItemsSource = searchresults;
//			}

//			if (_fieldType == Constants.FieldType.College)
//			{
//				var searchresults = _collegeList.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
//				listviewDynamic.ItemsSource = searchresults;
//			}

//			if (_fieldType == Constants.FieldType.CourseType)
//			{
//				var searchresults = _coursetypeList.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
//				listviewDynamic.ItemsSource = searchresults;
//			}

//			if (_fieldType == Constants.FieldType.Course)
//			{
//				var searchresults = _courseList.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
//				listviewDynamic.ItemsSource = searchresults;
//			}

//			if (_fieldType == Constants.FieldType.Specialization)
//			{
//				var searchresults = _spealicationList.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
//				listviewDynamic.ItemsSource = searchresults;
//			}

//			if (_fieldType == Constants.FieldType.Skill)
//			{
//				var searchresults = _skillList.FindAll((obj) => obj.Title.ToLower().Contains(searchtext.ToLower()));
//				listviewDynamic.ItemsSource = searchresults;
//			}



//		}

//		#endregion

//		#region private methods

//		/// <summary>
//		/// Binds the data.
//		/// </summary>
//		public async void BindData()
//		{
//			System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindData");
//			this.Title = _fieldType;

//			if (_fieldType == Constants.FieldType.CollegeName)
//			{
//				UserDialogs.Instance.ShowLoading("Loading College, Please Wait...", MaskType.Black);
//				await BindCollegeNameData();
//				UserDialogs.Instance.HideLoading();
//			}


//			if (_fieldType == Constants.FieldType.State)
//			{
//				UserDialogs.Instance.ShowLoading("Loading State, Please Wait...", MaskType.Black);
//				await BindStateData();
//				UserDialogs.Instance.HideLoading();
//			}

//			if (_fieldType == Constants.FieldType.City)
//			{
//				UserDialogs.Instance.ShowLoading("Loading District, Please Wait...", MaskType.Black);
//				await BindDistrictData();
//				UserDialogs.Instance.HideLoading();
//			}

//			if (_fieldType == Constants.FieldType.University)
//			{
//				UserDialogs.Instance.ShowLoading("Loading University, Please Wait...", MaskType.Black);
//				await BindUniversityData();
//				UserDialogs.Instance.HideLoading();
//			}

//			if (_fieldType == Constants.FieldType.College)
//			{
//				UserDialogs.Instance.ShowLoading("Loading College, Please Wait...", MaskType.Black);
//				await BindCollegeData();
//				UserDialogs.Instance.HideLoading();
//			}

//			if (_fieldType == Constants.FieldType.CourseType)
//			{
//				UserDialogs.Instance.ShowLoading("Loading Course Type, Please Wait...", MaskType.Black);
//				await BindCourseTypeData();
//				UserDialogs.Instance.HideLoading();
//			}


//			if (_fieldType == Constants.FieldType.Course)
//			{
//				UserDialogs.Instance.ShowLoading("Loading Course, Please Wait...", MaskType.Black);
//				await BindCourseData();
//				UserDialogs.Instance.HideLoading();
//			}

//			if (_fieldType == Constants.FieldType.Specialization)
//			{
//				UserDialogs.Instance.ShowLoading("Loading Specialization, Please Wait...", MaskType.Black);
//				await BindSpecializationData();
//				UserDialogs.Instance.HideLoading();
//			}

//			if (_fieldType == Constants.FieldType.Skill)
//			{
//				UserDialogs.Instance.ShowLoading("Loading Skills, Please Wait...", MaskType.Black);
//				await BindSkillData();
//				UserDialogs.Instance.HideLoading();
//			}

//			if (_fieldType == Constants.FieldType.BackLogs)
//			{
//				BindBacklogsData();
//			}

//			if (_fieldType == Constants.FieldType.YearOfCompletion)
//			{
//				BindCompletionYearData();
//			}


//			if (_fieldType == Constants.FieldType.CollegeName)
//			{
//				UserDialogs.Instance.ShowLoading("Loading College, Please Wait...", MaskType.Black);
//				await BindCollegeNameData();
//				UserDialogs.Instance.HideLoading();
//			}
//		}


//		/// <summary>
//		/// Binds the college name data.
//		/// </summary>
//		public async Task BindCollegeNameData()
//		{
//			System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindCollegeNameData");



//			Transport objAPICall = new Transport("v3/registercollege");
//			var objRequestData = new BaseRequestDTO();
//			{
//			};

//			var responseobj = await objAPICall.PostAsync<CollegeNameListFullResponseData, BaseRequestDTO>(objRequestData);
//			stackSearchAddNewItem.IsVisible = false;
//			if (responseobj != null)
//			{
//				if (responseobj.Code == "200" && responseobj.ResponseText != null)
//				{
//					_collegeNameList = responseobj.ResponseText.ResponseData;
//				}
//				UserDialogs.Instance.HideLoading();
//			}
//			lblMessage.IsVisible = false;
//			listviewDynamic.ItemsSource = _collegeNameList;
//			if (_collegeNameList != null && _collegeNameList.Count > 0)
//			{
//				searchbarText.IsEnabled = true;
//			}




//		}

//		/// <summary>
//		/// Binds the university data.
//		/// </summary>
//		public async Task BindUniversityData()
//		{
//			System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindUniversityData");
//			if (_universityList == null)
//			{
//				lblMessage.IsVisible = true;
//				//stackSearchAddNewItem.IsVisible = true;
//				var universities = await _masterDataManager.GetUniversityData(
//					new MasterTableRequestData()
//					{
//						HiremeeID = AppSessionData.ActiveToken.HireMeID,
//						Token = AppSessionData.ActiveToken.Token,
//						TableName = "university"
//					});
//				_universityList = universities;
//			}
//			lblMessage.IsVisible = false;
//			listviewDynamic.ItemsSource = _universityList;
//			if (_universityList != null && _universityList.Count > 0)
//			{
//				searchbarText.IsEnabled = true;
//			}
//		}

//		/// <summary>
//		/// Binds the college data.
//		/// </summary>
//		/// <returns>The college data.</returns>
//		async Task BindCollegeData()
//		{
//			System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindCollegeData");
//			if (_collegeList == null)
//			{
//				lblMessage.IsVisible = true;
//				//stackSearchAddNewItem.IsVisible = true;
//				var colleges = await new CollegeMasterManager().GetCollegeData(
//					new CollegeTableRequestData()
//					{
//						HiremeeID = AppSessionData.ActiveToken.HireMeID,
//						Token = AppSessionData.ActiveToken.Token,
//						UniversityID = _fieldValue
//					});
//				_collegeList = colleges;
//			}
//			lblMessage.IsVisible = false;
//			listviewDynamic.ItemsSource = _collegeList;

//			if (_collegeList != null && _collegeList.Count > 0)
//			{
//				searchbarText.IsEnabled = true;
//			}
//		}

//		/// <summary>
//		/// Binds the course type data.
//		/// </summary>
//		/// <returns>The course type data.</returns>
//		async Task BindCourseTypeData()
//		{
//			System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindCourseTypeData");
//			if (_coursetypeList == null)
//			{
//				lblMessage.IsVisible = true;
//				var coursetypes = await _masterDataManager.GetCourseData(
//					new MasterTableRequestData()
//					{
//						HiremeeID = AppSessionData.ActiveToken.HireMeID,
//						Token = AppSessionData.ActiveToken.Token,
//						TableName = "coursetype"
//					});
//				_coursetypeList = coursetypes;
//			}
//			lblMessage.IsVisible = false;
//			listviewDynamic.ItemsSource = _coursetypeList;
//			if (_coursetypeList != null && _coursetypeList.Count > 0)
//			{
//				searchbarText.IsEnabled = true;
//			}

//		}

//		/// <summary>
//		/// Binds the course data.
//		/// </summary>
//		/// <returns>The course data.</returns>
//		async Task BindCourseData()
//		{
//			System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindCourseData");
//			if (_courseList == null)
//			{
//				lblMessage.IsVisible = true;
//				var courses = await new CourseManager().GetCourseData(
//					new CourseRequestData()
//					{
//						HiremeeID = AppSessionData.ActiveToken.HireMeID,
//						Token = AppSessionData.ActiveToken.Token,
//						CourseTypeID = _fieldValue
//					});
//				_courseList = courses;
//			}
//			lblMessage.IsVisible = false;
//			listviewDynamic.ItemsSource = _courseList;

//			if (_courseList != null && _courseList.Count > 0)
//			{
//				searchbarText.IsEnabled = true;
//			}

//		}

//		/// <summary>
//		/// Binds the specialization data.
//		/// </summary>
//		/// <returns>The specialization data.</returns>
//		async Task BindSpecializationData()
//		{
//			System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindSpecializationData");
//			if (_spealicationList == null)
//			{
//				lblMessage.IsVisible = true;
//				var specializations = await new SpecializationManager().GetSpecializationData(
//					new SpecializationRequestData()
//					{
//						HiremeeID = AppSessionData.ActiveToken.HireMeID,
//						Token = AppSessionData.ActiveToken.Token,
//						CourseID = _fieldValue
//					});
//				_spealicationList = specializations;
//			}
//			lblMessage.IsVisible = false;
//			listviewDynamic.ItemsSource = _spealicationList;


//			if (_spealicationList != null && _spealicationList.Count > 0)
//			{
//				searchbarText.IsEnabled = true;
//			}
//		}


//		async Task BindSkillData()
//		{
//			System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindSkillData");
//			if (_skillList == null)
//			{
//				lblMessage.IsVisible = true;
//				var skills = await _masterDataManager.GetSkillData(
//					new MasterTableRequestData()
//					{
//						HiremeeID = AppSessionData.ActiveToken.HireMeID,
//						Token = AppSessionData.ActiveToken.Token,
//						TableName = "skill"
//					});
//				_skillList = skills;
//			}
//			lblMessage.IsVisible = false;
//			listviewDynamic.ItemsSource = _skillList;



//			if (_skillList != null && _skillList.Count > 0)
//			{
//				searchbarText.IsEnabled = true;
//			}
//		}

//		/// <summary>
//		/// Binds the district data.
//		/// </summary>
//		/// <returns>The district data.</returns>
//		async Task BindDistrictData()
//		{
//			System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindDistrictData");
//			if (_cityList == null)
//			{
//				lblMessage.IsVisible = true;
//				var districts = await new DistrictManager().GetDistrictData(
//					new DistrictRequestData()
//					{
//						HiremeeID = AppSessionData.ActiveToken.HireMeID,
//						Token = AppSessionData.ActiveToken.Token,
//						StateID = _fieldValue
//					});
//				_cityList = districts;
//			}
//			lblMessage.IsVisible = false;
//			listviewDynamic.ItemsSource = _cityList;

//			if (_cityList != null && _cityList.Count > 0)
//			{
//				searchbarText.IsEnabled = true;
//			}
//		}

//		/// <summary>
//		/// Binds the state data.
//		/// </summary>
//		/// <returns>The state data.</returns>
//		async Task BindStateData()
//		{
//			if (_stateList == null)
//			{
//				lblMessage.IsVisible = true;
//				System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindStateData");
//				var states = await _masterDataManager.GetStateData(
//					new MasterTableRequestData()
//					{
//						HiremeeID = AppSessionData.ActiveToken.HireMeID,
//						Token = AppSessionData.ActiveToken.Token,
//						TableName = "state"
//					});
//				_stateList = states;
//			}
//			lblMessage.IsVisible = false;
//			listviewDynamic.ItemsSource = _stateList;


//			if (_stateList != null && _stateList.Count > 0)
//			{
//				searchbarText.IsEnabled = true;
//			}
//		}

//		/// <summary>
//		/// Binds the backlogs data.
//		/// </summary>
//		void BindBacklogsData()
//		{
//			System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindBacklogsData");
//			List<Backlog> backlogs = new List<Backlog>();
//			lblMessage.IsVisible = true;
//			for (int a = 0; a < 10; a++)
//			{
//				backlogs.Add(new Backlog { BacklogID = a.ToString(), Title = a.ToString() });
//			}
//			lblMessage.IsVisible = false;
//			listviewDynamic.ItemsSource = backlogs;
//		}

//		async

//		/// <summary>
//		/// Binds the completion year data.
//		/// </summary>
//		void BindCompletionYearData()
//		{
//			System.Diagnostics.Debug.WriteLine("@ DynamicListPage.BindCompletionYearData");
//			int currentYear = DateTime.Now.Year;
//			//List<CompletionYear> yearlist = new List<CompletionYear>();
//			List<Year> yearlist = new List<Year>();
//			lblMessage.IsVisible = true;
//			//for (int a = currentYear + 1; a >= currentYear - 1; a--)
//			//{
//			//	yearlist.Add(new CompletionYear { YearID = a.ToString(), Title = a.ToString() });
//			//}if (_yearList == null)
//			{
//				try
//				{
//					UserDialogs.Instance.ShowLoading("Loading Year of Completion...");
//					var requestdata = new MasterTableRequestData()
//					{
//						HiremeeID = AppSessionData.ActiveToken.HireMeID,
//						Token = AppSessionData.ActiveToken.Token,
//						TableName = "yearofcompletion"
//					};
//					Transport objAPICall = new Transport("mastertables");
//					var responseobj = await objAPICall.PostAsync<YearOfCompletionResponse, MasterTableRequestData>(requestdata);

//					if (responseobj != null)
//					{
//						if (responseobj.code == "200" && responseobj.responseText.yearofcompletion != null)
//						{
//							foreach (var item in responseobj.responseText.yearofcompletion)
//							{
//								yearlist.Add(new Year { ID = item.id.ToString(), Title = item.name });
//							}
//						}
//						else
//						{
//							UserDialogs.Instance.HideLoading();
//							await DisplayAlert("", responseobj.message, "OK");
//						}
//					}
//					else
//					{
//						UserDialogs.Instance.HideLoading();
//						await DisplayAlert("", MessageStringConstants.YearOfCompletion, "OK");
//					}
//				}
//				catch (Exception ex)
//				{
//					Debug.WriteLine(ex.Message);
//					UserDialogs.Instance.HideLoading();
//				}
//				UserDialogs.Instance.HideLoading();
//				_yearList = new ObservableCollection<Year>(yearlist);
//				lblMessage.IsVisible = false;
//				listviewDynamic.ItemsSource = _yearList;
//			}
//		}
//		#endregion

//		#region event handlers
//		/// <summary>
//		/// Dynamics the list view item tapped.
//		/// </summary>
//		/// <param name="sender">Sender.</param>
//		/// <param name="e">E.</param>
//		void DynamicListView_ItemTapped(object sender, Xamarin.Forms.ItemTappedEventArgs e)

//		{
//			System.Diagnostics.Debug.WriteLine("@ DynamicListPage.DynamicListView_ItemTapped");
//			if (_valueGetterInterface != null)
//				_valueGetterInterface.SetFieldValue(_fieldType, e.Item);

//			Navigation.PopAsync();
//		}
//		#endregion

//		#region AddButtonclicked
//		async public void AddButtonclicked(object sender, EventArgs e)
//		{
//			if (!String.IsNullOrEmpty(entryNewText.Text))
//			{
//				if (!isButtonClicked)
//				{
//					isButtonClicked = true;
//					if (_fieldType == Constants.FieldType.University)
//					{

//						var newuniversity = await AddUniversity();
//						if (newuniversity != null)
//						{
//							_valueGetterInterface.SetFieldValue(_fieldType, newuniversity.Response);
//							await DisplayAlert("", newuniversity.Message, "OK");
//							await Navigation.PopAsync();
//						}
//						else
//						{
//							await DisplayAlert("", MessageStringConstants.UniversityNotAdded, "OK");
//							isButtonClicked = false;
//						}
//					}

//					if (_fieldType == Constants.FieldType.College)
//					{

//						var newcollege = await AddCollege();
//						if (newcollege != null)
//						{
//							_valueGetterInterface.SetFieldValue(_fieldType, newcollege.Response);
//							await DisplayAlert("", newcollege.Message, "OK");
//							await Navigation.PopAsync();
//						}
//						else
//						{
//							await DisplayAlert("", MessageStringConstants.CollegeNotAdded, "OK");
//							isButtonClicked = false;
//						}
//					}
//				}
//			}
//			else
//			{
//				if (_fieldType == Constants.FieldType.University)
//				{
//					await DisplayAlert("", MessageStringConstants.EnterUniversity, "OK");
//				}
//				else if (_fieldType == Constants.FieldType.College)
//				{
//					await DisplayAlert("", MessageStringConstants.EnterCollege, "OK");
//				}
//			}
//		}
//		#endregion


//		async Task<AddUniversityResponseData> AddUniversity()
//		{
//			AddUniversityResponseData response = null;

//			var adduniversity = new TempUniversityInsertManager();

//			response = await adduniversity.AddUniversity(new AddUniversityRequestData
//			{
//				HiremeeID = AppSessionData.ActiveToken.HireMeID,
//				Token = AppSessionData.ActiveToken.Token,
//				UniversityName = entryNewText.Text
//			});

//			if (response != null)
//			{
//				University newuniversity = new University();
//				newuniversity.ID = response.Response.ID;
//				newuniversity.Title = response.Response.Title;
//			}
//			return response;
//		}

//		async Task<AddCollegeResponseData> AddCollege()
//		{
//			AddCollegeResponseData response = null;
//			if (!string.IsNullOrEmpty(_fieldValue))
//			{
//				var addcollege = new TempCollegeInsertManager();

//				response = await addcollege.AddCollege(new AddCollegeRequestData
//				{
//					HiremeeID = AppSessionData.ActiveToken.HireMeID,
//					Token = AppSessionData.ActiveToken.Token,
//					CollegeName = entryNewText.Text
//				});
//				if (response != null)
//				{
//					College newCollege = new College();
//					newCollege.Title = response.Response.ID;
//					newCollege.ID = response.Response.Title;
//				}
//			}
//			return response;
//		}
//	}
//}
