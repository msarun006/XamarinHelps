using Xamarin.Forms;
using HireMe.ViewModels;

namespace HireMe
{
    public partial class ForgotPasswordPage : ContentPage
    {
        private ForgotPasswordViewModel _ForgotPasswordViewModel { get; set; }
        public ForgotPasswordPage()
        {
            InitializeComponent();

            _ForgotPasswordViewModel = new ForgotPasswordViewModel(Navigation);
            BindingContext = _ForgotPasswordViewModel;

        }
        private void UnfocusedEvent(object sender, FocusEventArgs e)
        {
            var entry = (Entry)sender;
            var entryclassid = entry.ClassId;
            _ForgotPasswordViewModel.TapCommand.Execute(entryclassid);
        }
    }
}