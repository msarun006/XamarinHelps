﻿using Xamarin.Forms;
using HireMe.ViewModels;

namespace HireMe
{
    public partial class InternetUnavailable : ContentPage
	{
	
		public InternetUnavailable(string className)
		{
			
			InitializeComponent();
            NavigationPage.SetHasNavigationBar(this,false);
            BindingContext = new InternetUnavailableViewModel(className);
		}

     

    }
}
