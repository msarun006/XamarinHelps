﻿using Xamarin.Forms;
using HireMe.ViewModels;

namespace HireMe
{
    public partial class PlayVideo : ContentPage
	{
		public PlayVideoViewModel _viewModel { get; set; }
		private string candidateID;
		private int resocureType;

        #region Constructor
        public PlayVideo(string videoFilePath = null)
        {
            InitializeComponent();
            _viewModel = new PlayVideoViewModel(videoFilePath,Navigation);
            BindingContext = _viewModel;
        }

        public PlayVideo(string videoFilePath = null, string candidateID = null, int resocureType = 0)
        {
            InitializeComponent();
            _viewModel = new PlayVideoViewModel(videoFilePath, candidateID, resocureType, Navigation);
            BindingContext = _viewModel;
        }

        #endregion
		protected override void OnDisappearing()
		{
			base.OnDisappearing();
			customVideoControl.Stop();
			customVideoControl.FileSource = null;
		}
		protected override void OnAppearing()
		{
			base.OnAppearing();

			if (UserType.JobSeeker == AppSessionData.ActiveToken.UserType)
			{
				BtnBlockVideo.IsVisible = false;
			}
		}
	}
}
		
