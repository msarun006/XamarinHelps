﻿using HireMe.ViewModels;
using Xamarin.Forms;

namespace HireMe
{
    public partial class AboutUsPage : ContentPage
    {
        public AboutUsViewModel _viewModel { get; set; }
        public AboutUsPage()
        {
            InitializeComponent();
            _viewModel = new AboutUsViewModel();
            BindingContext = _viewModel;
      
        }
    }
}
