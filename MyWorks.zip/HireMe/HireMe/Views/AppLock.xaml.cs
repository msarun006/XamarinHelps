﻿using System;
using Xamarin.Forms;
using HireMe.ViewModels;

namespace HireMe
{

    public partial class AppLock : ContentPage
    {
        #region View Model Declaration
        public AppLockViewModel _ApplockViewModel { get; set; }
        #endregion

        #region Main Constructors
        #region Main Constructor1
        public AppLock()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            _ApplockViewModel = new AppLockViewModel(Navigation);
            BindingContext = _ApplockViewModel;
        }
        #endregion

        #region Main Constructor2 with Title
        public AppLock(string pageOperation)
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            _ApplockViewModel = new AppLockViewModel(pageOperation, Navigation);
            BindingContext = _ApplockViewModel;
        }
        #endregion

        #region Main Constructor3 Title & Next Navigating Page
        public AppLock(string pageOperation, string navigationPage)
        {
            InitializeComponent();
            _ApplockViewModel = new AppLockViewModel(pageOperation, navigationPage, Navigation);
            BindingContext = _ApplockViewModel;
            NavigationPage.SetHasNavigationBar(this, false);

        }
        #endregion
        #endregion

        #region TapCommand by ClassID
        private void InputPasscode(object sender, EventArgs e)
        {
            var buttonEvent = (Button)sender;
            var ButtonClassId = buttonEvent.ClassId;
            _ApplockViewModel.TapCommand.Execute(ButtonClassId);
        }
        #endregion
    }
}
