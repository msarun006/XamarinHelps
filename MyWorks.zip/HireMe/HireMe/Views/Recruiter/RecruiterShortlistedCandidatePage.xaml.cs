﻿using Xamarin.Forms;
using HireMe.ViewModels.Recruiter;

namespace HireMe
{
	public partial class RecruiterShortlistedCandidatePage : ContentPage
	{


		RecruiterShortlistedCandidateViewModel RecruiterShortlistedCandidateViewModel;
		public RecruiterShortlistedCandidatePage(string searchid)
		{
			InitializeComponent();
			RecruiterShortlistedCandidateViewModel = new RecruiterShortlistedCandidateViewModel(Navigation, searchid);
			BindingContext = RecruiterShortlistedCandidateViewModel;
		}

		private void Switch_Toggled(object sender, ToggledEventArgs e)
		{
			RecruiterShortlistedCandidateViewModel.Switch_Toggled(sender, e);
		}


	}
}
