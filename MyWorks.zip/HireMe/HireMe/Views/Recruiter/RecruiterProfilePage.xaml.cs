using Xamarin.Forms;
using HireMe.ViewModels.Recruiter;

namespace HireMe
{
    //public partial class RecruiterProfilePage : ContentPage, IValueGetter
    public partial class RecruiterProfilePage : ContentPage
    {


        RecruiterProfileViewModel RecruiterProfileViewModel;
        public RecruiterProfilePage()
        {
            InitializeComponent();
            RecruiterProfileViewModel = new RecruiterProfileViewModel(Navigation);
            BindingContext = RecruiterProfileViewModel;
        }



        //      RecruiterProfileDetails ObjRecruiterpersonalDetails = null;

        //public RecruiterProfilePage()
        //{
        //          ObjRecruiterpersonalDetails = new RecruiterProfileDetails();
        //	System.Diagnostics.Debug.WriteLine("@ RecruiterProfilePage.RecruiterProfilePage");
        //	InitializeComponent();

        //	profilepic.Source = AppPreferences.ProfilePicture;
        //	MessagingCenter.Subscribe<SideMenuPage, string>(this, "ChangeProfilePicture", ChangeProfilePicture);

        //	LoadDefaults();
        //}

        //public async void LoadDefaults()
        //{
        //	UserDialogs.Instance.ShowLoading("Loading Profile Data, Please Wait", MaskType.Black);
        //	await GetUserProfileData();
        //	UserDialogs.Instance.HideLoading();
        //}
        //      #region GetUserProfileData
        //      public async Task GetUserProfileData()
        //      {
        //          System.Diagnostics.Debug.WriteLine("@ RecruiterProfilePage.GetUserProfileData");
        //          RecruiterProfileDetailsRetrivalRequestData objRequestdata = new RecruiterProfileDetailsRetrivalRequestData();


        //          RecruiterProfileDetailsRetrivalManager manager = new RecruiterProfileDetailsRetrivalManager();
        //          ObjRecruiterpersonalDetails = await manager.GetRecruiterProfileDetails(objRequestdata);

        //          if (ObjRecruiterpersonalDetails != null)
        //          {
        //              lblFullName.Text = ObjRecruiterpersonalDetails.FullName;
        //              lblEmailID.Text = ObjRecruiterpersonalDetails.EmailAddress;
        //              lblHireMeID.Text = AppSessionData.ActiveToken.HireMeID;
        //              lblMobileNo.Text = ObjRecruiterpersonalDetails.MobileNumber;
        //              lblCompanyName.Text = ObjRecruiterpersonalDetails.CompanyName;

        //              if (!string.IsNullOrEmpty(ObjRecruiterpersonalDetails.State.Title))
        //              {
        //                  lblCurrentState.Text = ObjRecruiterpersonalDetails.State.Title;
        //              }
        //              else
        //              {
        //                  lblCurrentState.Text = "Select State";
        //              }

        //              if (!string.IsNullOrEmpty(ObjRecruiterpersonalDetails.City.Title))
        //              {
        //                  lblCurrentCity.Text = ObjRecruiterpersonalDetails.City.Title;
        //              }
        //              else
        //              {
        //                  lblCurrentCity.Text = "Select District";
        //              }
        //          }
        //      }

        //      #endregion


        //      void ChangeProfilePicture(SideMenuPage sender, string profilepicsource)
        //{
        //	if (!string.IsNullOrEmpty(profilepicsource))
        //		profilepic.Source = profilepicsource;
        //	else
        //		profilepicsource = AppPreferences.ProfilePicture;
        //}
        //      #region SaveRecruiterPersonalDetails
        //      public async void SaveRecruiterPersonalDetails(object sender, EventArgs args)
        //      {
        //          System.Diagnostics.Debug.WriteLine("@ RecruiterProfilePage.SaveRecruiterPersonalDetails");

        //          if (IsValidatePersonalDetails())
        //          {
        //              buttonRecriterPersonalSave.IsEnabled = false;

        //RecruiterProfileDetailsRequestData personaldetailsrequest = new RecruiterProfileDetailsRequestData();
        //personaldetailsrequest.FullName = lblFullName.Text;
        //        personaldetailsrequest.MobileNumber = lblMobileNo.Text;
        //        personaldetailsrequest.EmailAddress = lblEmailID.Text;
        //        personaldetailsrequest.CompanyName = lblCompanyName.Text;
        //        personaldetailsrequest.State = ObjRecruiterpersonalDetails.State.ID;
        //        personaldetailsrequest.City = ObjRecruiterpersonalDetails.City.ID;

  //              RecruiterProfileDetailsManager manager = new RecruiterProfileDetailsManager();
  //              var response = await manager.UpdateRecruiterProfileDetails(personaldetailsrequest);
  //              if (response != null)
  //              {
  //                  if (!string.IsNullOrEmpty(response))
  //                  {
  //                      await DisplayAlert("", response, "OK");
  //                  }
  //                  else
  //                  {
  //                      await DisplayAlert("", MessageStringConstants.CouldNotProcessRequest, "OK");
  //                  }

  //              }
  //              else
  //              {
  //                  await DisplayAlert("", MessageStringConstants.CouldNotProcessRequest, "OK");
  //              }
  //              buttonRecriterPersonalSave.IsEnabled = true;
  //          }
  //      }

  //      #endregion
  //      #region IsValidatePersonalDetails
  //      bool IsValidatePersonalDetails()
  //      {
  //          if (ObjRecruiterpersonalDetails != null)
  //          {
  //              if (lblCurrentState.Text == "Select State" || ObjRecruiterpersonalDetails.State == null)
  //              {
  //                  DisplayAlert("", MessageStringConstants.SelectHomeState, "OK");
  //                  return false;
  //              }
  //              if (lblCurrentCity.Text == "Select District" || ObjRecruiterpersonalDetails.City == null)
  //              {
  //                  DisplayAlert("", MessageStringConstants.SelectHomeDistrict, "OK");
  //                  return false;
  //              }
  //              return true;
  //          }
  //          else
  //          {
  //              return false;
  //          }
  //      }

  //      #endregion
  //      #region Tapped Event
  //      public void OnStateItemTapped(object sender, EventArgs args)
  //      {
  //          bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
  //          if (isNetworkAvailable)
  //          {
  //              this.Navigation.PushAsync(new DynamicListPage(Constants.FieldType.State, "", this));
  //          }
  //          else
  //          {
  //              UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
  //          }
  //      }

  //      public void OnCityItemTapped(object sender, EventArgs args)
  //      {
  //          if (ObjRecruiterpersonalDetails.State != null)
  //          {
  //              bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
  //              if (isNetworkAvailable)
  //              {
  //                  this.Navigation.PushAsync(new DynamicListPage(Constants.FieldType.City, ObjRecruiterpersonalDetails.State.ID, this));
  //              }
  //              else
  //              {
  //                  UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
  //              }

  //          }
  //      }
  //      #endregion
  //      #region SetFieldValue
  //      public void SetFieldValue(string fieldtype, object fieldvalue)
  //      {
  //          if (fieldtype == Constants.FieldType.State)
  //          {
  //              lblCurrentCity.Text = "Select District";
  //              ObjRecruiterpersonalDetails.City = null;

  //              lblCurrentState.Text = ((State)fieldvalue).Title;
  //              ObjRecruiterpersonalDetails.State = new State { ID = ((State)fieldvalue).ID, Title = ((State)fieldvalue).Title };
  //          }
  //          else if (fieldtype == Constants.FieldType.City)
  //          {
  //              lblCurrentCity.Text = ((District)fieldvalue).Title;
  //              ObjRecruiterpersonalDetails.City = new District { ID = ((District)fieldvalue).ID, Title = ((District)fieldvalue).Title };
  //          }
  //      }

  //      #endregion
    }
}
