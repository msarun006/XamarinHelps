﻿using HireMe.ViewModels.Recruiter;
using Xamarin.Forms.Xaml;
using Xamarin.Forms;

namespace HireMe.UI
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class BlockVideo :  ContentPage
    {
        public BlockVideoViewModel _viewmodel { get; set; }
        public BlockVideo(string candidateID, int resocureType)
        {
            InitializeComponent();
            _viewmodel = new BlockVideoViewModel(candidateID, resocureType,Navigation);
            BindingContext = _viewmodel;
        }
        protected override bool OnBackButtonPressed()
        {
            return false;
        }
        //protected override bool OnBackgroundClicked()
        //{
        //    return false;
        //}
    }
}
