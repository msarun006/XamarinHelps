﻿using HireMe.ViewModels.Recruiter;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.Recruiter
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class RejectedCandidatePage : ContentPage
    {
        public RejectedCandidatePage(string searchId)
        {
            InitializeComponent();
            BindingContext = new RejectedCandidateViewModel(Navigation, searchId);
        }
    }
}