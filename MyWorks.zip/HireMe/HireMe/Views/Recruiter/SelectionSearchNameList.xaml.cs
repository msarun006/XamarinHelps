﻿using HireMe.ViewModels.Recruiter;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.Recruiter
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SelectionSearchNameList : ContentPage
    {
        public SelectionSearchNameList()
        {
            InitializeComponent();
            BindingContext = new SelectionSearchNameViewModel(Navigation);
        }
    }
}