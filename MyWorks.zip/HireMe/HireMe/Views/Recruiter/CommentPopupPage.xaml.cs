﻿using Xamarin.Forms.Xaml;
using System.Collections.ObjectModel;
using HireMe.ViewModels.Recruiter;
using Xamarin.Forms;

namespace HireMe.UI
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class CommentPopupPage : ContentPage
	{
		string candidateid;
		ObservableCollection<Recruitercommentsdetail> _CandidateComments;
        private CommentPopupViewModel _CommentPopupViewModel;
        #region Constructor
        public CommentPopupPage(string objcandidateid, ObservableCollection<Recruitercommentsdetail> CandidateComments)
		{
			InitializeComponent();
			candidateid = objcandidateid;
            _CommentPopupViewModel = new CommentPopupViewModel(objcandidateid, CandidateComments,Navigation);
            BindingContext = _CommentPopupViewModel;
			
		}
		#endregion

		#region OnBackButtonPressed
		protected override bool OnBackButtonPressed()
		{
			// Prevent hide popup
			//return base.OnBackButtonPressed();
			return true;
		}
		#endregion

		#region OnBackgroundClicked

		// Invoced when background is clicked
		//protected override bool OnBackgroundClicked()
		//{
		//	// Return default value - CloseWhenBackgroundIsClicked
		//	//return base.OnBackgroundClicked();
		//	return false;
		//}
		#endregion
        
	}
}