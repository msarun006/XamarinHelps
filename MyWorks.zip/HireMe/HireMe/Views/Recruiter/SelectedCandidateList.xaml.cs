using Xamarin.Forms;
using HireMe.ViewModels.Recruiter;

namespace HireMe
{
    public partial class SelectedCandidateList : ContentPage
	{
        //#region ClassVariables

        //ObservableCollection<RecruitersearchBO> _multiSelectList;
        ////ToolbarItem toolbarItem = null;
        //RecruitersearchBO objSearchdetail;
        //public bool isClicked = false;
        //#endregion


        //public SelectedCandidateList()
        //{
        //	InitializeComponent();
        //	isClicked = true;
        //	objSearchdetail = new RecruitersearchBO();

        //	LoadSelectedCandidates();
        //}


        SelectedCandidateListViewModel SelectedCandidateListViewModel;
        public SelectedCandidateList(string SearchID)
        {
            InitializeComponent();
            SelectedCandidateListViewModel = new SelectedCandidateListViewModel(Navigation, SearchID);
            BindingContext = SelectedCandidateListViewModel;
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();
            SelectedCandidateListViewModel.BindSelectedCandidateList();

        }


        //#region Load SelectedCandidates
        //public async void LoadSelectedCandidates()
        //{
        //	UserDialogs.Instance.ShowLoading("Loading Selected Candidates, Please Wait", MaskType.Black);
        //	await ShowSelectedCandidates();
        //	UserDialogs.Instance.HideLoading();
        //}
        //#endregion

        //#region Load ShowSelectedCandidates
        //private async Task ShowSelectedCandidates()
        //{
        //	try
        //	{
        //		var requestdata = new BaseRequestDTO()
        //		{
        //			HiremeeID = AppSessionData.ActiveToken.HireMeID,
        //			Token = AppSessionData.ActiveToken.Token
        //		};
        //		Transport objAPICall = new Transport("v3/selectedcandidatetohire");
        //		var responseobj = await objAPICall.PostAsync<SelectedCandidatelistResponse, BaseRequestDTO>(requestdata);

        //		if (responseobj != null)
        //		{

        //			if (responseobj.Code == "200" && responseobj.ResponseText != null)
        //			{
        //				if (responseobj.ResponseText.Data.Length > 0)
        //				{
        //					if (_multiSelectList == null)
        //					{
        //						_multiSelectList = new ObservableCollection<RecruitersearchBO>(responseobj.ResponseText.Data);
        //					}
        //					listView.ItemsSource = _multiSelectList;
        //				}
        //                      else
        //                      {
        //                          lblNoRecords.IsVisible = true;
        //                          listView.IsVisible = false;
        //                      }
        //			}
        //		}
        //		else
        //		{
        //			UserDialogs.Instance.HideLoading();
        //                  lblNoRecords.IsVisible = true;
        //                  listView.IsVisible = false;
        //                  //await DisplayAlert("", MessageStringConstants.ProfileDetailsUnavailable, "OK");
        //              }
        //	}
        //	catch (Exception ex)
        //	{
        //		Debug.WriteLine(ex.Message);
        //		UserDialogs.Instance.HideLoading();
        //	}
        //}

        //async
        //#endregion



        //#region OnProfilePicImageTapped
        //      void OnItemTapped(object sender, EventArgs e)
        //{
        //	if (isClicked)
        //	{
        //		isClicked = false;
        //		if (CrossConnectivity.Current.IsConnected)
        //		{
        //			var imageSender = (StackLayout)sender;
        //			var objRecruiterSearchBO = imageSender.BindingContext as RecruitersearchBO;

        //			// var objSearchdetail = imageSender.BindingContext as Searchdetail;

        //			//objSearchdetail.candidateid = objRecruiterSearchBO.candidateid;


        //			if (objRecruiterSearchBO != null)
        //			{
        //				var toCandidateDetails = new CandidateDetailsPage(objRecruiterSearchBO, _multiSelectList, "HireMee");
        //				//var videoplayer = new RecruiterPlayVideo(objRecruiterSearchBO.profileDetails.FullName, objRecruiterSearchBO.AboutMeVideoDetails, objRecruiterSearchBO.SkillVideoDetails, objRecruiterSearchBO.AmbitionVideoDetails, objRecruiterSearchBO.candidateID);
        //				await Navigation.PushAsync(toCandidateDetails);
        //			}
        //		}
        //		else
        //		{
        //			UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
        //		}
        //	}
        //	await Task.Run(async () =>
        //	{
        //		await Task.Delay(500);
        //		isClicked = true;
        //	});
        //}

        //#endregion

    }
}
