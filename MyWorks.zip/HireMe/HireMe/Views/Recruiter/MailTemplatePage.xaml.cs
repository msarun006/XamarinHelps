﻿using HireMe.Models.Recruiter;
using HireMe.ViewModels.Recruiter;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.UI
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MailTemplatePage : ContentPage
    {

        private string mailcontent;
        private MailtoSelectedCandidatesRequestData objRequestData;

        MailTemplateViewModel MailTemplateViewModel;

        public MailTemplatePage(MailtoSelectedCandidatesRequestData objRequestData, string mailcontent)
        {
            InitializeComponent();
            this.objRequestData = objRequestData;
            this.mailcontent = mailcontent;

            MailTemplateViewModel = new MailTemplateViewModel(Navigation, objRequestData,mailcontent);
            BindingContext = MailTemplateViewModel;

        }
       
    }
}
