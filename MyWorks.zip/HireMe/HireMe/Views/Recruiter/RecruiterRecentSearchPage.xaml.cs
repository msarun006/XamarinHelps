﻿using Xamarin.Forms;
using HireMe.ViewModels.Recruiter;

namespace HireMe
{
    public partial class RecruiterRecentSearchPage : ContentPage
	{

        RecruiterRecentSearchViewModel RecruiterRecentSearchViewModel;
        public RecruiterRecentSearchPage()
        {
            InitializeComponent();
            RecruiterRecentSearchViewModel = new RecruiterRecentSearchViewModel(Navigation);
            BindingContext = RecruiterRecentSearchViewModel;
        }

    }
}
