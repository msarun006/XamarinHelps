using HireMe.ViewModels.Recruiter;
using Xamarin.Forms;

namespace HireMe
{
    public partial class RecruiterDraftEmailPage : ContentPage
	{
        string strSearchid;
        int selectedTemplateID;
        string strselectedCandidatelist = string.Empty;
        public RecruiterDraftEmailPageViewModel _viewModel { get; set; }
        #region Constructor
        public RecruiterDraftEmailPage(string selectedCandidatelist, string searchID)
        {
            InitializeComponent();
            _viewModel = new RecruiterDraftEmailPageViewModel(selectedCandidatelist, searchID,Navigation);
            BindingContext = _viewModel;
        }
        #endregion

        private void DatepickerDateofBirth_DateSelected(object sender, DateChangedEventArgs e)
        {
            var datepicker = (DatePicker)sender;
            _viewModel.DateChangedCommand.Execute(datepicker);
        }
    }
}
