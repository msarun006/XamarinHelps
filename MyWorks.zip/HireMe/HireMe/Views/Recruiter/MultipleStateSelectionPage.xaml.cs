﻿using HireMe.ViewModels.Recruiter;
using System.Collections.Generic;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.Recruiter
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MultipleStateSelectionPage : ContentPage
    {
        MultipleStateSelectionViewModel MultipleStateSelectionViewModel;
        public MultipleStateSelectionPage(string PageName, List<States> skills)
        {
            InitializeComponent();
            MultipleStateSelectionViewModel = new MultipleStateSelectionViewModel(Navigation, PageName, skills);
            BindingContext = MultipleStateSelectionViewModel;
        }

        void OnSkill_Toggled(object sender, ToggledEventArgs args)
        {
            MultipleStateSelectionViewModel.OnSkill_Toggled(sender, args);
        }
    }
}