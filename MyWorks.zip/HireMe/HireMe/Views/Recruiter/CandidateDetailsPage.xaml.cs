﻿using System.Collections.ObjectModel;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using HireMe.Models.Recruiter;
using HireMe.ViewModels.Recruiter;

namespace HireMe.UI
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CandidateDetailsPage : ContentPage
    {
     
        private CandidateDetailsViewModel _CandidateDetailsViewModel;

        public CandidateDetailsPage(RecruitersearchBO objSearchDetails, ObservableCollection<RecruitersearchBO> candidateslist, int searchID, string searchName)
        {
            InitializeComponent();
            _CandidateDetailsViewModel = new CandidateDetailsViewModel(Navigation, objSearchDetails, candidateslist, searchID, searchName);
            BindingContext = _CandidateDetailsViewModel;

        }

        public CandidateDetailsPage(RecruitersearchBO objSearchDetails)
        {
            InitializeComponent();
            _CandidateDetailsViewModel = new CandidateDetailsViewModel(Navigation, objSearchDetails);
            BindingContext = _CandidateDetailsViewModel;
        }

        
        public CandidateDetailsPage(RecruitersearchBO objSearchDetails, ObservableCollection<RecruitersearchBO> candidateslist, string selectedPage)
        {
            InitializeComponent();
            _CandidateDetailsViewModel = new CandidateDetailsViewModel(Navigation,objSearchDetails, candidateslist, selectedPage);
            BindingContext = _CandidateDetailsViewModel;
        }

     

    }
}