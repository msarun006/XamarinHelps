﻿using System.Collections.Generic;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.Recruiter
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MultipleJobLocationSelectionPage : ContentPage
    {
      

        MultipleJobLocationSelectionViewModel MultipleJobLocationSelectionViewModel;

        public MultipleJobLocationSelectionPage(string PageName,  List<JobLocation> skills)
        {
            InitializeComponent();
            MultipleJobLocationSelectionViewModel = new MultipleJobLocationSelectionViewModel(Navigation, PageName, skills);
            BindingContext = MultipleJobLocationSelectionViewModel;
        }



        void On_Toggled(object sender, ToggledEventArgs args)
        {
            MultipleJobLocationSelectionViewModel.On_Toggled(sender, args);
        }

    }
}