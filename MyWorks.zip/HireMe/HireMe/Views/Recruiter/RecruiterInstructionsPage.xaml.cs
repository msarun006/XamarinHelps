﻿using System;
using Plugin.Connectivity;
using Xamarin.Forms;

namespace HireMe
{
    public partial class RecruiterInstructionsPage : ContentPage
    {
		public RecruiterInstructionsPage()
		{
			InitializeComponent();
            if(Device.RuntimePlatform.Equals("Android"))
            {
                //Track Page 
                GoogleAnalyticService.Track_App_Page("Android RecruiterInstructionsPage");
            }
            //or iOS 
            else
            { //Track Page 
                GoogleAnalyticService.Track_App_Page("iOS  RecruiterInstructionsPage");
            }
            AppPreferences.IsDashboard = true;
        }

		public void OnSkipRecruiterLabelTapped(object sender, EventArgs args)
		{
           

            bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
            if (isNetworkAvailable)
            {
                Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                return;
            }
            else
            {
                Application.Current.MainPage = new InternetUnavailable("Dashboard");
                return;
            }

        }
    }
}