using Xamarin.Forms;

namespace HireMe
{
	public partial class RecruiterSearchVideoProfile : ContentPage
	{
		#region Object Creation
		RecruiterSearchVideoProfileViewModel RecruiterSearchVideoProfileViewModel;
		#endregion


		#region RecruiterSearchVideoProfile()
		public RecruiterSearchVideoProfile()
		{
			InitializeComponent();
			RecruiterSearchVideoProfileViewModel = new RecruiterSearchVideoProfileViewModel(Navigation);
			BindingContext = RecruiterSearchVideoProfileViewModel;
		}
		#endregion


		protected override void OnAppearing()
		{
			base.OnAppearing();
		}

	}
}
