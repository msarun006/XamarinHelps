﻿using HireMe.ViewModels.Recruiter;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.Recruiter
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CandidateEducationDetailsViewPage : ContentPage
    {
        public CandidateEducationDetailsViewPage(string candidateID)
        {
            InitializeComponent();
            BindingContext = new CandidateEducationViewModel(candidateID);
        }
        protected override bool OnBackButtonPressed()
        {
            // Prevent hide popup
            return false;
        }

        // Invoced when background is clicked
        //protected override bool OnBackgroundClicked()
        //{
        //    return false;
        //}
    }
}