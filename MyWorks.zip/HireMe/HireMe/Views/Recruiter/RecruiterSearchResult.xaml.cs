﻿using System;
using Xamarin.Forms;
using HireMe.Models.Recruiter;
using HireMe.ViewModels.Recruiter;

namespace HireMe
{
    public partial class RecruiterSearchResult : ContentPage
	{
        private string strSearchid;
        private SearchResponseText searchDetailData;
        RecruitersearchBO objSearchDetails;

        RecruiterSearchResultViewModel RecruiterSearchResultViewModel;
        public RecruiterSearchResult(SearchResponseText searchDetailData)
        {
            InitializeComponent();
            objSearchDetails = new RecruitersearchBO();
            this.searchDetailData = searchDetailData;

            RecruiterSearchResultViewModel = new RecruiterSearchResultViewModel(Navigation, searchDetailData);
            BindingContext = RecruiterSearchResultViewModel;
        }

        public RecruiterSearchResult(String searchID)
        {
            strSearchid = searchID;
            InitializeComponent();

            RecruiterSearchResultViewModel = new RecruiterSearchResultViewModel(Navigation, strSearchid);
            BindingContext = RecruiterSearchResultViewModel;

        }



        //ObservableCollection<RecruitersearchBO> _candidateslist = null;
        //string strSearchid;
        //private SearchResponseText searchDetailData;
        //RecruitersearchBO objSearchDetails;
        //public bool isClicked = true;

        //#region Constructor
        //public RecruiterSearchResult(SearchResponseText searchDetailData)
        //{

        //    InitializeComponent();
        //    strSearchid = "";
        //    objSearchDetails = new RecruitersearchBO();
        //    this.searchDetailData = searchDetailData;
        //    if (Device.RuntimePlatform.Equals("Android"))
        //    {
        //        //Track Page 
        //        GoogleAnalyticService.Track_App_Page("Android RecruiterSearchResult");
        //    }
        //    //or iOS 
        //    else
        //    { //Track Page 
        //        GoogleAnalyticService.Track_App_Page("iOS  RecruiterSearchResult");
        //    }
        //    //_candidateslist.Clear();
        //    _candidateslist = new ObservableCollection<RecruitersearchBO>(searchDetailData.searchDetails);
        //    listView.ItemsSource = _candidateslist;
        //}
        //#endregion


        //protected override void OnAppearing()
        //{
        //    if (strSearchid == "")
        //        listView.ItemsSource = _candidateslist;
        //}


        //#region Constructor
        //public RecruiterSearchResult(String searchID)
        //{
        //    strSearchid = searchID;
        //    InitializeComponent();
        //    if (Device.RuntimePlatform.Equals("Android"))
        //    {
        //        //Track Page 
        //        GoogleAnalyticService.Track_App_Page("Android RecruiterSearchResult");
        //    }
        //    //or iOS 
        //    else
        //    { //Track Page 
        //        GoogleAnalyticService.Track_App_Page("iOS  RecruiterSearchResult");
        //    }

        //    LoadListDetails();

        //}
        //#endregion

        //public async void LoadListDetails()
        //{
        //    UserDialogs.Instance.ShowLoading("Loading List Details");
        //    await BindListDetails();
        //    UserDialogs.Instance.HideLoading();
        //}


        //private async Task BindListDetails()
        //{
        //    try
        //    {
        //        var requestdata = new RecentSearchListItemClickedRequestData()
        //        {
        //            HiremeeID = AppSessionData.ActiveToken.HireMeID,
        //            Token = AppSessionData.ActiveToken.Token,
        //            SearchId = strSearchid
        //        };
        //        Transport objAPICall = new Transport("v3/previousrecruitersearch");
        //        var responseobj = await objAPICall.PostAsync<SearchDetailResponse, RecentSearchListItemClickedRequestData>(requestdata);
        //        if (responseobj != null)
        //        {
        //            if (responseobj.Code == "200" && responseobj.SearchDetailData != null)
        //            {
        //                objSearchDetails = new RecruitersearchBO();
        //                this.searchDetailData = responseobj.SearchDetailData;
        //                _candidateslist = new ObservableCollection<RecruitersearchBO>(searchDetailData.searchDetails);
        //                listView.ItemsSource = _candidateslist;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Debug.WriteLine(ex.Message);
        //        UserDialogs.Instance.HideLoading();
        //    }

        //}





        ////public async void CandidateList(string searchid)
        ////      {
        ////          _candidateslist = candList;
        ////          RecruitersearchManager manager = new RecruitersearchManager();
        ////          FilterRequest objFilterRequest = new FilterRequest();
        ////	objFilterRequest.UserToken = AppSessionData.ActiveToken.Token;
        ////	objFilterRequest.RecruiterHireMeeID = AppSessionData.ActiveToken.HireMeID;
        ////	objFilterRequest.SearchID = searchid;
        ////	UserDialogs.Instance.ShowLoading("Loading Filter Candidates, Please Wait", MaskType.Black);
        ////	var response = await manager.GetFilterViewCount(objFilterRequest);
        ////	UserDialogs.Instance.HideLoading();
        ////	if (response != null && response.Code == "200")
        ////	{
        ////		if (response.ResponseText != null && response.ResponseText.Data != null)
        ////		{
        ////			if (_candidateslist == null)
        ////			{
        ////				_candidateslist = new ObservableCollection<RecruitersearchBO>(response.ResponseText.Data);
        ////			}
        ////			else
        ////			{
        ////				_candidateslist.Clear();
        ////				_candidateslist = new ObservableCollection<RecruitersearchBO>(response.ResponseText.Data);
        ////			}
        ////                  if (_candidateslist.Count==0)
        ////                  {
        ////				await DisplayAlert("", MessageStringConstants.NoCandidateFound, "OK");
        ////                      await Navigation.PopAsync();
        ////                  }
        ////                  else
        ////                  {
        ////                      listView.ItemsSource = _candidateslist;
        ////                  }
        ////		}
        ////	}else if (response.Code == "203")
        ////	{
        ////		await DisplayAlert("", response.Message, "OK");
        ////		await Navigation.PopAsync();
        ////	}
        ////	else
        ////	{
        ////		await DisplayAlert("", response.Message, "OK");
        ////		await Navigation.PopAsync();
        ////	}
        ////}


        //#region OnProfilePicImageTapped
        ///// <summary>
        ///// handles tapgesture for profile pic image.
        ///// </summary>
        ///// <param name="sender"></param>
        ///// <param name="args"></param>
        //async void OnProfilePicImageTapped(object sender, EventArgs e)
        //{
        //    if (isClicked)
        //    {
        //        isClicked = false;
        //        if (CrossConnectivity.Current.IsConnected)
        //        {
        //            var imageSender = (StackLayout)sender;
        //            var objRecruiterSearchBO = imageSender.BindingContext as RecruitersearchBO;
        //            if (objRecruiterSearchBO != null)
        //            {
        //                //var recruiterToCandidate = new CandidateDetailsPage(objRecruiterSearchBO, _candidateslist, searchDetailData.searchId, searchDetailData.searchname);
        //                //await Navigation.PushAsync(recruiterToCandidate);
        //            }
        //        }
        //        else
        //        {
        //            UserDialogs.Instance.Toast(MessageStringConstants.CheckInternetConnection);
        //        }


        //    }
        //    await Task.Run(async () =>
        //    {
        //        await Task.Delay(500);
        //        isClicked = true;
        //    });

        //}

        //#endregion		

        //#region OnSelect
        ////public async void OnSelect(object sender, EventArgs e)
        ////{
        ////    if (isClicked)
        ////    {
        ////        isClicked = false;

        ////        var selecteditem = (RecruitersearchBO)(((MenuItem)sender).BindingContext);

        ////        var data = new SelectedCandidateListInsertRequestData();
        ////        data.Token = AppSessionData.ActiveToken.Token;
        ////        data.HiremeeID = AppSessionData.ActiveToken.HireMeID;
        ////        data.CandidateHiremeeID = selecteditem.candidateID;
        ////        data.SearchId = searchDetailData.searchId.ToString();
        ////        data.SearchName = searchDetailData.searchname;
        ////        data.IsSelected = "Y";
        ////        SelectedCandidateListInsertManager obj = new SelectedCandidateListInsertManager();
        ////        var response = await obj.InsertSelectedCandidateList(data);
        ////        if (response != null)
        ////        {
        ////            if (response.Code == "200")
        ////            {
        ////                if (!RemoveItemFromList(selecteditem.candidateID))
        ////                {
        ////                    await DisplayAlert("", MessageStringConstants.SomethingNotRight, "OK");
        ////                }
        ////            }
        ////        }

        ////    }
        ////    await Task.Run(async () =>
        ////    {
        ////        await Task.Delay(500);
        ////        isClicked = true;
        ////    });


        ////}

        ////#endregion

        //////#region OnReject
        ////public async void OnReject(object sender, EventArgs e)
        ////{
        ////    if (isClicked)
        ////    {
        ////        isClicked = false;

        ////        var selecteditem = (RecruitersearchBO)(((MenuItem)sender).BindingContext);
        ////        SelectedCandidateListInsertRequestData data = new SelectedCandidateListInsertRequestData();
        ////        data.Token = AppSessionData.ActiveToken.Token;
        ////        data.HiremeeID = AppSessionData.ActiveToken.HireMeID;
        ////        data.CandidateHiremeeID = selecteditem.candidateID;
        ////        data.SearchId = searchDetailData.searchId.ToString();
        ////        data.SearchName = searchDetailData.searchname;

        ////        var obj = new CandidateRejectListInsertManager();
        ////        var response = await obj.RejectedCandidateList(data);
        ////        if (response != null && response.Code == "200")
        ////        {
        ////            if (!RemoveItemFromList(selecteditem.candidateID))
        ////            {
        ////                await DisplayAlert("", MessageStringConstants.SomethingNotRight, "OK");
        ////            }
        ////        }

        ////    }
        ////    await Task.Run(async () =>
        ////    {
        ////        await Task.Delay(500);
        ////        isClicked = true;
        ////    });

        ////}
        //#endregion

        //#region Remove Item FromList
        //private bool RemoveItemFromList(string hiremeeid)
        //{
        //    bool isremoved = false;
        //    if (_candidateslist != null && _candidateslist.Count > 0)
        //    {
        //        var selectedCandidate = _candidateslist.FirstOrDefault(o => o.candidateID == hiremeeid);
        //        if (selectedCandidate != null)
        //        {
        //            _candidateslist.Remove(selectedCandidate);
        //            isremoved = true;
        //        }
        //    }
        //    return isremoved;
        //}

        //#endregion

    }
}
