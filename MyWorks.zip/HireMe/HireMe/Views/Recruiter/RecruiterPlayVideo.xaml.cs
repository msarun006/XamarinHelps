﻿using Xamarin.Forms;
using HireMe.Models.Recruiter;
using HireMe.ViewModels.Recruiter;

namespace HireMe
{
    public partial class RecruiterPlayVideo : ContentPage
    {
        public RecruiterPlayVideoViewModel _viewModel { get; set; }

        #region Constructor
        //public RecruiterPlayVideo(string title, AboutMeVideo aboutme, SkillVideo skill, AmbitionVideo ambition, string strCandidateID, string strSearchID)
        //{
        //    InitializeComponent();
        //    _viewModel = new RecruiterPlayVideoViewModel(title, aboutme, skill, ambition,strCandidateID, strSearchID,Navigation);
        //    BindingContext = _viewModel;
        //}

        #endregion

        #region RecruiterPlayVideo
        public RecruiterPlayVideo(string title, AboutMeVideo aboutme, SkillVideo skill, AmbitionVideo ambition, string strCandidateID, string strSearchID)
        {

            InitializeComponent();
            _viewModel = new RecruiterPlayVideoViewModel(title, aboutme, skill, ambition, strCandidateID, strSearchID,Navigation);
            BindingContext = _viewModel;

        }

        #endregion
    }
}
