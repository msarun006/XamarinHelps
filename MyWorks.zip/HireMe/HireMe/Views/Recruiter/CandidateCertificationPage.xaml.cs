﻿using HireMe.ViewModels.Recruiter;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using HireMe.Models.Recruiter;
using System.Collections.ObjectModel;

namespace HireMe.Views.Recruiter
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CandidateCertificationPage : ContentPage
    {
        private ObservableCollection<CertificationsData> certificationItemSource;

        public CandidateCertificationPage(ObservableCollection<CertificationsData> certificationItemSource)
        {
            InitializeComponent();
            BindingContext = new CandidateCertificationViewModel(certificationItemSource);
        }
        protected override bool OnBackButtonPressed()
        {
            // Prevent hide popup
            return true;
        }

        // Invoced when background is clicked
        //protected override bool OnBackgroundClicked()
        //{
        //    return false;
        //}
    }
}