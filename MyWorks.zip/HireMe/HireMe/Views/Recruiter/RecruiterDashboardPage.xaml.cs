﻿using Xamarin.Forms;

namespace HireMe
{
    public partial class RecruiterDashboardPage : ContentPage
    {
        public RecruiterDashboardPage()
        {
            System.Diagnostics.Debug.WriteLine("@ RecruiterDashboardPage.RecruiterDashboardPage");

            InitializeComponent();

            BindingContext = new RecruiterDashboardViewModel(Navigation);
        }
    }
}
