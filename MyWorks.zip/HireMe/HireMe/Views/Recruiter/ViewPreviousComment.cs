﻿
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using HireMe.ViewModels.Recruiter;

namespace HireMe.UI
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class ViewPreviousComment : ContentPage
	{
		
		string candidateid;
        private PreviousCommentViewModel _PreviousCommentViewModel;
        #region Constructor
        public ViewPreviousComment(string objcandidateid)
		{
			InitializeComponent();
			candidateid = objcandidateid;
            _PreviousCommentViewModel = new PreviousCommentViewModel(objcandidateid,Navigation);
            BindingContext = _PreviousCommentViewModel;
		}
		#endregion
	}
}


