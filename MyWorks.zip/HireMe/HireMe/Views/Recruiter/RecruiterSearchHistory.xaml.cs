﻿using Xamarin.Forms;
using HireMe.ViewModels.Recruiter;

namespace HireMe
{
    public partial class RecruiterSearchHistory : ContentPage
    {
        
        RecruiterSearchHistoryViewModel RecruiterSearchHistoryViewModel;
        public RecruiterSearchHistory()
        {
            InitializeComponent();
            RecruiterSearchHistoryViewModel = new RecruiterSearchHistoryViewModel(Navigation);
            BindingContext = RecruiterSearchHistoryViewModel;
        }

    }
}
