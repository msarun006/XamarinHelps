﻿using System;
using Xamarin.Forms;
using HireMe.Models.Recruiter;
using HireMe.ViewModels.Recruiter;
using Xamarin.RangeSlider.Forms;

namespace HireMe
{
    public partial class AdvancedSearchOption : ContentPage
    {
        public AdvancedSearchOptionViewModel _viewModel;
        public AdvancedSearchOption(SearchDetailRequestData data)
        {
            InitializeComponent();
            _viewModel = new AdvancedSearchOptionViewModel(data, Navigation);
            BindingContext = _viewModel;     
  
        }
    
        #region Slider value changed.
        
        private void OnLowerValueChanged(object sender, EventArgs e)
        {
            RangeSlider objSlider = (RangeSlider)sender;
            string LowerValue = objSlider.LowerValue.ToString();
            string styleid = objSlider.StyleId;
           _viewModel.OnLowerValue(styleid, LowerValue);
          
        }

        private void OnUpperValueChanged(object sender, EventArgs e)
        {
            RangeSlider objSlider = (RangeSlider)sender;
            string UpperValue = objSlider.UpperValue.ToString();
            string styleid = objSlider.StyleId;
            _viewModel.OnUpperValue(styleid, UpperValue);
        }

        #endregion

        private void btnApply_Clicked(object sender, EventArgs e)
        {

        }
    }
}
