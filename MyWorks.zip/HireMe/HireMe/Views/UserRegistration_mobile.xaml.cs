﻿using HireMe.ViewModels.JobSeeker;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class UserRegistration_mobile : ContentPage
    {
        UserRegistration_mobile_ViewModel _UserRegistration_mobile_ViewModel;
        public UserRegistration_mobile()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            if (Device.RuntimePlatform.Equals("Android"))
            {
                //Track Page 
                GoogleAnalyticService.Track_App_Page("Android RegistationPageNew");
            }
            //or iOS 
            else
            { //Track Page 
                GoogleAnalyticService.Track_App_Page("iOS  RegistationPageNew");
            }
            _UserRegistration_mobile_ViewModel = new UserRegistration_mobile_ViewModel(Navigation);
            BindingContext = _UserRegistration_mobile_ViewModel;
        }

        private void UnfocusedEvent(object sender, FocusEventArgs e)
        {
            var entry = (Entry)sender;
            var entryclassid = entry.ClassId;
            _UserRegistration_mobile_ViewModel.TapCommand.Execute(entryclassid);
        }

        #region OnBackButton Press Event
        protected override bool OnBackButtonPressed()
        {
            base.OnBackButtonPressed();
            return false; //Do not navigate backwards by pressing the button
        }
        #endregion
    }
}