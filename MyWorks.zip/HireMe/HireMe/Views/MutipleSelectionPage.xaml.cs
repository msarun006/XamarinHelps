﻿using HireMe.ViewModels;
using System.Collections.Generic;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MutipleSelectionPage : ContentPage
    {

        MultipleSelectionViewModel _multipleSelectionViewModel;

        public MutipleSelectionPage(string ListData, List<CommonBO> SelectedList)
        {
            InitializeComponent();
            _multipleSelectionViewModel = new MultipleSelectionViewModel(Navigation, ListData, SelectedList);
            BindingContext = _multipleSelectionViewModel;
        }

   

        private void OnSelectionSwitch_Toggled(object sender, ToggledEventArgs e)
        {
            _multipleSelectionViewModel.OnSelectionSwitch_Toggled(sender,e);
        }
    }
}