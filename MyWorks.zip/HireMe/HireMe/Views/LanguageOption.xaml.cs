﻿using System.Threading.Tasks;

using Xamarin.Forms;

namespace HireMe
{

    public partial class LanguageOption : ContentPage
    {
        LanguageOptionViewModel LanguageOptionViewModel;
        Languageknown _language;
        public LanguageOption(Languageknown language)
        {
            InitializeComponent();
            _language = language;
            NavigationPage.SetHasBackButton(this, false);
            LanguageOptionViewModel = new LanguageOptionViewModel(Navigation, _language);
            BindingContext = LanguageOptionViewModel;

        }



        protected override bool OnBackButtonPressed()
        {
            // Prevent hide popup
            //return base.OnBackButtonPressed();
            _language.IsRead = 0;
            _language.IsSpeak = 0;
            _language.IsWrite = 0;
            _language.IsSelected = false;
            return false;
        }

        // Invoced when background is clicked
        //protected override bool OnBackgroundClicked()
        //{
        //	// Return default value - CloseWhenBackgroundIsClicked
        //	//return base.OnBackgroundClicked();
        //	return false;
        //}
        // Method for animation child in PopupPage
        // Invoced after custom animation end
        protected virtual Task OnAppearingAnimationEnd()
        {
            return Content.FadeTo(1);
        }

        // Method for animation child in PopupPage
        // Invoked before custom animation begin
        protected virtual Task OnDisappearingAnimationBegin()
        {
            return Content.FadeTo(1); ;
        }


    }
}