using Xamarin.Forms;
using HireMe.ViewModels;

namespace HireMe
{
    public partial class LoginPageNew : ContentPage
    {

        #region Main Contructor
        private LoginPageViewModel _loginPageViewmodel { get; set; }
        public LoginPageNew()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            _loginPageViewmodel = new LoginPageViewModel(Navigation);
            BindingContext = _loginPageViewmodel;
        }
        #endregion
        
        #region OnBackButton Press Event
        protected override bool OnBackButtonPressed()
        {
            base.OnBackButtonPressed();
            return false; //Do not navigate backwards by pressing the button
        }


        #endregion
    }
}