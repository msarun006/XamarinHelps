﻿using System;
using Rg.Plugins.Popup.Pages;

namespace HireMe
{
    public partial class AppUpdatePopupDialog : PopupPage
    {

        AppUpdatePopupDialogViewModel AppUpdatePopupDialogViewModel;
        public AppUpdatePopupDialog(String message)
        {
            InitializeComponent();
            AppUpdatePopupDialogViewModel = new AppUpdatePopupDialogViewModel(message);
            BindingContext = AppUpdatePopupDialogViewModel;
            



        }
        protected override bool OnBackgroundClicked()
        {
            return false;
        }
         
    }
}
