﻿using Acr.UserDialogs;
using HireMe.Helpers;
using HireMe.Helpers.Assessment;
using HireMe.LocalDataBase;
using HireMe.Models.Assessment;
using HireMe.Services.SocialAuthentication;
using HireMe.UI;
using HireMe.Views.Assessment;
using HireMe.Views.JobSeeker;
using HireMe.Views.Recruiter;
using Plugin.Connectivity;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Xamarin.Forms;
namespace HireMe
{
    public partial class DashBoardMaster : MasterDetailPage, IMasterDetailChangeListener, IMasterDetailProfilePicture, IMasterEditBasicDetailsPage
    {
        string str_usertype;

        bool isClicked = true;

        GetAssessmentDetails GetAssessmentDetails;
        private HttpCommonService _commonservice { get; set; }
        public FCMHelper _FCMHelper { get; set; }



        private ObservableCollection<DashboardMasterModel> _allGroups;
        private ObservableCollection<DashboardMasterModel> _expandedGroups;


        public DashBoardMaster(string usertype)
         {
            InitializeComponent();
            try {

                BindingContext = new DashboardMasterViewModel(usertype, Navigation, this, this);
                GetAssessmentDetails = new GetAssessmentDetails();
                str_usertype = usertype;

                if (usertype == UserType.JobSeeker)
                {
                    _allGroups = DashboardMasterModel.SeekerMenuItem;
                }
                else if (usertype == UserType.Recruiter)
                {
                    _allGroups = DashboardMasterModel.RecruiterMenuItem;
                }

                _FCMHelper = new FCMHelper();
                _commonservice = new HttpCommonService();

                if (AppPreferences.IsNavigateNotification)
                {
                    if (usertype == UserType.JobSeeker)
                    {
                        AppPreferences.IsNavigateNotification = false;
                        Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(SeekerNotificationPage)));
                    }
                }
                else
                {
                    if (usertype == UserType.JobSeeker)
                    {
                        Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(SeekerDashboardPage)));
                    }
                    else if (usertype == UserType.Recruiter)
                    {
                        Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(RecruiterDashboardPage)));
                    }
                }
                if (Device.RuntimePlatform.Equals("iOS"))
                {
                    IsGestureEnabled = false;
                }

                UpdateListContent();
                groupedListView.ItemSelected += GroupedListView_ItemSelected;

            }
            catch (Exception ex)
            {

                SendErrorMessageToServer(ex, "DashBoardMaster.Constructor");
            }



        }


        #region SubMenuItemTapped
        private async void GroupedListView_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {


            try
            {

                if (e.SelectedItem == null)
                    return;

                SubMenuItem subMenuItem = (SubMenuItem)e.SelectedItem;
                String selecteditem = subMenuItem.SubMenuitemName;
                if (selecteditem == null)
                    return;
                if (str_usertype == UserType.JobSeeker)
                {
                    if (selecteditem == "Mock Assessment")
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(SampleAssessmentTest)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selecteditem == "HireMee Assessment")
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            GetAssessmentDetails.AssessmentLoginAPI();
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1500);
                            isClicked = true;
                        });
                    }
                    else if (selecteditem == "Search Jobs")
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(SearchJobsView)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selecteditem == "Applied Jobs")
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(AppliedJobsViewPage)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selecteditem == "Recommended Jobs")
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(RecommendedJobsViewPage)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });

                    }
                    else if (selecteditem == "FAQ's")
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(FAQPage)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selecteditem == "Settings")
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(SettingsPage)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selecteditem == "Feedback")
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(FeedbackPage)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selecteditem == "Promote App")
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            IsPresented = false;
                            DependencyService.Get<IPromoteAppActions>().OpenActions();
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(100);
                            isClicked = true;
                        });
                    }
                    else if (selecteditem == "About Us")
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(AboutUsPage)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selecteditem == "Log Out")
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            try
                            {

                                UpdateListContent();

                                IsPresented = false;
                                UserDialogs.Instance.ShowLoading();
                                await _FCMHelper.UnRegisterFirebaseToken();

                                ClearAppPreferences();
                                UserDialogs.Instance.HideLoading();

                                var page = new NavigationPage(new LoginPageNew());
                                Application.Current.MainPage = page;
                                return;
                            }
                            catch (Exception ex)
                            {
                                UserDialogs.Instance.HideLoading();
                                Debug.WriteLine(ex.Message);
                                var page = new NavigationPage(new LoginPageNew());
                                Application.Current.MainPage = page;
                                return;
                            }
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }

                }
                else if (str_usertype == UserType.Recruiter)
                {
                    if (selecteditem == "FAQ's")
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(FAQPage)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selecteditem == "Settings")
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(SettingsPage)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selecteditem == "Feedback")
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(FeedbackPage)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selecteditem == "Promote App")
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            IsPresented = false;
                            DependencyService.Get<IPromoteAppActions>().OpenActions();
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(100);
                            isClicked = true;
                        });
                    }
                    else if (selecteditem == "About Us")
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(AboutUsPage)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selecteditem == "Log Out")
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            try
                            {
                                IsPresented = false;
                                UserDialogs.Instance.ShowLoading();
                                await _FCMHelper.UnRegisterFirebaseToken();

                                ClearAppPreferences();
                                UserDialogs.Instance.HideLoading();
                                var page = new NavigationPage(new LoginPageNew());
                                Application.Current.MainPage = page;
                                return;
                            }
                            catch (Exception ex)
                            {
                                UserDialogs.Instance.HideLoading();
                                Debug.WriteLine(ex.Message);
                                var page = new NavigationPage(new LoginPageNew());
                                Application.Current.MainPage = page;
                                return;
                            }
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                }
                ((ListView)sender).SelectedItem = null;
            }
            catch(Exception ex)
            {
                SendErrorMessageToServer(ex, "DashBoardMaster.SubMenuItemTapped_GroupedListView_ItemSelected");
            }


           
        }
        #endregion

        #region MenuItemTapped if have any submenu Item
        private void HeaderTapped(object sender, EventArgs args)
        {

            try
            {
                int selectedIndex = _expandedGroups.IndexOf(
               ((DashboardMasterModel)((Button)sender).CommandParameter));
                _allGroups[selectedIndex].Expanded = !_allGroups[selectedIndex].Expanded;
                UpdateListContent();
            }
            catch(Exception ex)
            {
                SendErrorMessageToServer(ex, "DashBoardMaster.ExpandMenuItem_HeaderTapped");
            }


           
        }
        #endregion

        #region MenuItemTapped
        private async void TapGestureRecognizer_Tapped(object sender, EventArgs e)
        {


            try
            {
                var args = (TappedEventArgs)e;
                var myObject = (int)args.Parameter;
                int selectedIndex = myObject;




                if (str_usertype == UserType.JobSeeker)
                {

                    if (selectedIndex == 0)
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Constant.IsSideMenuDashboard = true;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(SeekerDashboardPage)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selectedIndex == 1)
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(SeekerNotificationPage)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selectedIndex == 2)
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(StudentIdCardPage)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selectedIndex == 3)
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(QRCodeGeneratorPage)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selectedIndex == 4)
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(RecruitersMessage)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selectedIndex == 5)
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(CompanyDetails)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selectedIndex == 6)
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            _allGroups[selectedIndex].Expanded = !_allGroups[selectedIndex].Expanded;
                            UpdateListContent();
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selectedIndex == 7)
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(CurrentOpningsViewPage)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selectedIndex == 8)
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(CurrentWalkinsViewPage)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });

                    }
                    else if (selectedIndex == 9)
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            _allGroups[selectedIndex].Expanded = !_allGroups[selectedIndex].Expanded;
                            UpdateListContent();
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });

                    }
                    else if (selectedIndex == 10)
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            _allGroups[selectedIndex].Expanded = !_allGroups[selectedIndex].Expanded;
                            UpdateListContent();
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                }
                else if (str_usertype == UserType.Recruiter)
                {


                    if (selectedIndex == 0)
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(RecruiterDashboardPage)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selectedIndex == 1)
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(RecruiterSearchVideoProfile)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selectedIndex == 2)
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(RecruiterSearchHistory)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selectedIndex == 3)
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(SelectionSearchNameList)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selectedIndex == 4)
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(RejectionSearchNameList)));
                            IsPresented = false;
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }
                    else if (selectedIndex == 5)
                    {
                        if (isClicked)
                        {
                            isClicked = false;
                            _allGroups[selectedIndex].Expanded = !_allGroups[selectedIndex].Expanded;
                            UpdateListContent();
                        }
                        await Task.Run(async () =>
                        {
                            await Task.Delay(1000);
                            isClicked = true;
                        });
                    }

                }
            }
            catch(Exception ex)
            {
                SendErrorMessageToServer(ex, "DashBoardMaster.MenuItemTapped_TapGestureRecognizer_Tapped");

            }




        }
        #endregion

        #region Refresh the menuitem here
        private void UpdateListContent()
        {
         
            try
            {
                _expandedGroups = new ObservableCollection<DashboardMasterModel>();
                foreach (DashboardMasterModel group in _allGroups)
                {
                    //Create new FoodGroups so we do not alter original list
                    DashboardMasterModel newGroup = new DashboardMasterModel(group.DefaultIcon, group.Title, group.ExpandIndex, group.StateIconIsVisible, group.Expanded);
                    //Add the count of food items for Lits Header Titles to use
                    newGroup.FoodCount = group.Count;
                    if (group.Expanded)
                    {
                        foreach (SubMenuItem item in group)
                        {
                            newGroup.Add(item);
                        }
                    }
                    _expandedGroups.Add(newGroup);
                }

                 groupedListView.ItemsSource = _expandedGroups;
            }
            catch (Exception ex)
            {
                SendErrorMessageToServer(ex, "ChangeProfilePicturePageViewModel.Refresh the menuitem here_TakeProfilePicture");
            }

        }
        #endregion



        //  private async void OnMenuItemSelected(object sender, SelectedItemChangedEventArgs e)
        //  {

        //try
        //{
        //    bool isClicked = true;
        //    if (e.SelectedItem == null)
        //        return;

        //    var item = (DashboardMasterModel)e.SelectedItem;
        //    if (item.Title == "Promote App")
        //    {
        //        if (isClicked)
        //        {
        //            isClicked = false;
        //            IsPresented = false;
        //            DependencyService.Get<IPromoteAppActions>().OpenActions();
        //        }
        //        await Task.Run(async () =>
        //        {
        //            await Task.Delay(100);
        //            isClicked = true;
        //        });
        //    }
        //    else if (item.Title == "HireMee Assessment")
        //    {
        //        if (isClicked)
        //        {
        //            isClicked = false;
        //            GetAssessmentDetails.AssessmentLoginAPI();
        //        }
        //        await Task.Run(async () =>
        //        {
        //            await Task.Delay(1500);
        //            isClicked = true;
        //        });
        //    }
        //    else if (item.Title == "Log Out")
        //    {
        //        try
        //        {
        //            IsPresented = false;
        //            UserDialogs.Instance.ShowLoading();
        //            await _FCMHelper.UnRegisterFirebaseToken();

        //            ClearAppPreferences();
        //            UserDialogs.Instance.HideLoading();
        //            //AppPreferences.LoadEducationDetails = null;
        //            //AppPreferences.LoadSeekerDashboardData = null;
        //            //AppPreferences.IsDashboard = false;
        //            //AppPreferences.IsSocialLoggedIn = false;
        //            //AppPreferences.IsFBLoggeedIn = false;
        //            //AppPreferences.IsGoogleLoggedIn = false;
        //            //AppPreferences.IsLogout = true;
        //            //AppPreferences.IsLoggeedIn = false;
        //            //AppPreferences.IsPasscode = false;
        //            //AppPreferences.IsVerifyEmail = false;
        //            //AppPreferences.IsPasscodeValue = string.Empty;
        //            //AppPreferences.IdCard = string.Empty;
        //            //AppPreferences.SeekerDashboardData = string.Empty;
        //            //AppPreferences.IsSeekerDashboardDataDownloaded = false;


        //            var page = new NavigationPage(new LoginPageNew());
        //            Application.Current.MainPage = page;
        //        }
        //        catch (Exception ex)
        //        {
        //            UserDialogs.Instance.HideLoading();
        //            Debug.WriteLine(ex.Message);
        //            var page = new NavigationPage(new LoginPageNew());
        //            Application.Current.MainPage = page;
        //        }

        //    }
        //    else
        //    {
        //        //Type page = item.TargetType;
        //        Detail = new NavigationPage((Page)Activator.CreateInstance(item.TargetType));
        //        IsPresented = false;
        //    }
        //((ListView)sender).SelectedItem = null;
        //}
        //catch (Exception ex)
        //{
        //    Debug.WriteLine(ex.Message);
        //    SendErrorMessageToServer(ex, "DashBoardMaster.OnMenuItemSelected");

        //}

        // }


        #region ClearAppPreferences
        private void ClearAppPreferences()
        {

            AppPreferences.IsSeekerDashboardDataDownloaded = false;
            AppPreferences.IsVisibleOthersSkill = "false";
            MessageStringConstants.IsAPIProcess = true;
            AppPreferences.LoadSeekerDashboardData = null;
            AppPreferences.IsFBLoggeedIn = false;
            AppPreferences.IsGoogleLoggedIn = false;
            AppPreferences.IsPasswordReset = false;
            AppPreferences.IsLinkedInLoggedIn = false;
            //AppPreferences.IsLogout = true;
            AppPreferences.IsFirstRun = true;
            AppPreferences.IsLoggeedIn = false;
            AppPreferences.IsDashboard = false;
            AppPreferences.IsResumeUploaded = false;
            AppPreferences.IsVideosUploaded = false;
            AppPreferences.IsProfileCompleted = false;
            AppPreferences.SkillVideo = null;
            AppPreferences.AboutMeVideo = null;
            AppPreferences.IsPasscode = false;
            AppPreferences.IsPasscodeValue = String.Empty;
            AppPreferences.InterestVideo = null;
            AppPreferences.ProfilePicture = string.Empty;
            AppPreferences.userName = String.Empty;
            AppPreferences.CanUploadSkillVideo = false;
            AppPreferences.CanUploadAboutMeVideo = false;
            AppPreferences.CanUploadSkillVideo = false;
            AppPreferences.IdCard = string.Empty;
            AppPreferences.IsNavigateNotification = false;
            AppPreferences.EmailAddress = String.Empty;
            AppPreferences.MobileNumber = String.Empty;
            AppPreferences.HireMeeID = String.Empty;
            //AppPreferences.ProfileScore = String.Empty;
            //AppPreferences.CurrentProgress = String.Empty;
            //AppPreferences.FirstName = string.Empty;
            //AppPreferences.LastName = string.Empty;
            AppPreferences.IsCollege = false;
            //AppPreferences.TempToken = string.Empty;
            AppPreferences.IsVerifyEmail = false;
            AppPreferences.IsVerifyMobileNo = false;

        }
        #endregion




        #region DashBoardMaster.OnChange
        public void OnChange(MasterPageMenuItem item)
        {
            System.Diagnostics.Debug.WriteLine("@ DashBoardMaster.OnChange()");
            if (item != null)
            {
                if (item.TargetType == null && item.Title == "Logout")
                {
                    // Clear All Session Data;
                    IsPresented = false;
                    var page = new NavigationPage(new LoginPageNew());

                    Application.Current.MainPage = page;
                    return;
                }
                else if (item.Title == "Promote App")
                {
                    IsPresented = false;
                    DependencyService.Get<IPromoteAppActions>().OpenActions();
                }
                else
                {
                    Detail = new NavigationPage((Page)Activator.CreateInstance(item.TargetType));
                    IsPresented = false;
                }
                System.Diagnostics.Debug.WriteLine("## Page has changed to : {0}", item.Title);
            }
        }
        #endregion



        protected override bool OnBackButtonPressed()
        {
            base.OnBackButtonPressed();
            return true; //Do not navigate backwards by pressing the button
        }


        public void OnDetail(ChangeProfilePicturePage item)
        {
            IsPresented = false;
            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(ChangeProfilePicturePage)));
        }
        public void OnDetail(HireMe.Views.JobSeeker.EditBasicDetailsPage p)
        {
            if (str_usertype == UserType.JobSeeker)
            {
                IsPresented = false;
                Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(EditBasicDetailsPage)));
            }
            else if (str_usertype == UserType.Recruiter)
            {
                IsPresented = false;
                Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(ChangeProfilePicturePage)));
            }
        }

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion


    }

    public interface IMasterDetailChangeListener
    {
        void OnChange(MasterPageMenuItem item);
    }

    public interface IMasterDetailProfilePicture
    {
        void OnDetail(ChangeProfilePicturePage p);
    }
    public interface IMasterEditBasicDetailsPage
    {
        void OnDetail(EditBasicDetailsPage p);
    }


}

