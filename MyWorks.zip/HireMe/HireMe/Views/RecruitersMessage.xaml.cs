﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using HireMe.ViewModels.JobSeeker;

namespace HireMe.UI
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class RecruitersMessage : ContentPage
    {
        RecruitersMessageViewModel RecruitersMessageViewModel;
        public RecruitersMessage()
        {
            InitializeComponent();
            RecruitersMessageViewModel = new RecruitersMessageViewModel(Navigation);
            BindingContext = RecruitersMessageViewModel;
        }
    }
}