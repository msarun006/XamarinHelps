﻿using HireMe.ViewModels.JobSeeker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.JobSeeker
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class FilterView : ContentPage
    {
        FilterViewModel FilterViewModel;
        public FilterView(string pageName)
        {
            InitializeComponent();
            FilterViewModel = new FilterViewModel(Navigation, pageName);
            BindingContext = FilterViewModel;
        }
        private void DatepickerToDate_DateSelected(object sender, DateChangedEventArgs e)
        {
            var datepicker = (DatePicker)sender;
            FilterViewModel.ToDateChangedCommand.Execute(datepicker);
        }

        private void DatepickerFromDate_DateSelected(object sender, DateChangedEventArgs e)
        {
            var datepicker = (DatePicker)sender;
            FilterViewModel.FromDateChangedCommand.Execute(datepicker);
        }
    }
}