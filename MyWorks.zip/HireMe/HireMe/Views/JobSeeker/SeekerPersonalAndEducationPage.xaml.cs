#region Usings
using System;
using Xamarin.Forms;
using HireMe.ViewModels.JobSeeker;
using HireMe.Models.Recruiter;
using Acr.UserDialogs;
#endregion

namespace HireMe
{
    #region IValueGetter
    public interface IValueGetter
    {
        void SetFieldValue(string fieldtype, object fieldvalue);
    }
    #endregion

    public partial class SeekerPersonalAndEducationPage : ContentPage, IValueGetter
    {
        #region  Object Creation
        bool _isFristTime = true;
        private bool _canShowPersonal;
        private SeekerPersonalAndEducationViewModel _SeekerPersonalAndEducationViewModel { get; set; }
        public string fieldvalues;

        private void OnTextchanged(object sender, TextChangedEventArgs e)
        {
            var entry = (Entry)sender;
            var entryclassid = entry.ClassId;
            _SeekerPersonalAndEducationViewModel.TextChangedCommand.Execute(entryclassid);
        }

        private void DatepickerDateofBirth_DateSelected(object sender, DateChangedEventArgs e)
        {
            var datepicker = (DatePicker)sender;
            _SeekerPersonalAndEducationViewModel.DateChangedCommand.Execute(datepicker);
        }

        #region SeekerPersonalAndEducationPage
        public SeekerPersonalAndEducationPage(bool canShowPersonal)
        {
            try
            {
                _canShowPersonal = canShowPersonal;
                InitializeComponent();
                UserDialogs.Instance.ShowLoading();
                _SeekerPersonalAndEducationViewModel = new SeekerPersonalAndEducationViewModel(Navigation, dynamic_StackLayout_SchoolorCollege, PrimarySkillsCustomScrollView, PrimarySkillsStackLayout, SecondarySkillsCustomScrollView, SecondarySkillsStackLayout, CertificateCustomScrollView, CertificateStackLayout);
                BindingContext = _SeekerPersonalAndEducationViewModel;
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);
            }
        }
        #endregion


        async protected override void OnAppearing()
        {
            base.OnAppearing();

            if (MessageStringConstants.IsSchoolOrCollegeDetailsUpdated)
            {
                await _SeekerPersonalAndEducationViewModel.GetJobSeekerDetails();
                MessageStringConstants.IsSchoolOrCollegeDetailsUpdated = false;
            }

            if (_isFristTime == true)
            {
                if (_canShowPersonal == true)
                {
                    _SeekerPersonalAndEducationViewModel.PersonalBackbtnColor = Color.Transparent;
                    _SeekerPersonalAndEducationViewModel.EducationBackbtnColor = Color.FromHex("#F7CC59");
                    await _SeekerPersonalAndEducationViewModel.ShowEducationalTab();
                }
                else
                {
                    _SeekerPersonalAndEducationViewModel.PersonalBackbtnColor = Color.FromHex("#F7CC59");
                    _SeekerPersonalAndEducationViewModel.EducationBackbtnColor = Color.Transparent;
                    await _SeekerPersonalAndEducationViewModel.ShowPersonalTab();
                }
                _isFristTime = false;
            }

            if (MessageStringConstants.IsCertificateDetailsModified)
            {
                var result = AppPreferences.LoadSeekerDashboardData;
                await _SeekerPersonalAndEducationViewModel.BindCertificateData(result.EducationalDetailsResponseData.certifications);
                MessageStringConstants.IsCertificateDetailsModified = false;
            }
        }

        private  void OnPersonalButton(object sender, EventArgs e)
        {
            //PersonalBackbtnColor.BackgroundColor = Color.FromHex("#F7CC59");
            //EducationBackbtnColor.BackgroundColor = Color.Transparent;
            //await _SeekerPersonalAndEducationViewModel.ShowPersonalTab();
        }

        private  void ONEducationButton(object sender, EventArgs e)
        {
            //PersonalBackbtnColor.BackgroundColor = Color.Transparent;
            //EducationBackbtnColor.BackgroundColor = Color.FromHex("#F7CC59");
            //await _SeekerPersonalAndEducationViewModel.ShowEducationalTab();
        }

        private void ToggleSameAddress(object sender, ToggledEventArgs e)
        {
            var switchtoggle = (Switch)sender;
            var switchclassid = switchtoggle.ClassId;    //Switch ToggleEvent Identified by ClassID
            _SeekerPersonalAndEducationViewModel.TapCommand.Execute(switchclassid);
        }

        private void Unfocused(object sender, FocusEventArgs e)
        {
            var entry = (Entry)sender;
            var entryclassid = entry.ClassId;
            _SeekerPersonalAndEducationViewModel.TapCommand.Execute(entryclassid);
        }

        private void Email_Unfocused(object sender, FocusEventArgs e)
        { 
            var entry = (Entry)sender;
            var entryclassid = entry.ClassId;
            _SeekerPersonalAndEducationViewModel.TapCommand.Execute(entryclassid);

        }

        public void SetFieldValue(string fieldtype, object fieldvalue)
        {
            fieldvalues = ((CommonListItemSource)fieldvalue).Title;
            _SeekerPersonalAndEducationViewModel.SetFieldValue(fieldtype, fieldvalue);
        }
        #endregion

        private void EditorUnfocues(object sender, FocusEventArgs e)
        {
            var entry = (Editor)sender;
            var entryclassid = entry.ClassId;
            _SeekerPersonalAndEducationViewModel.TapCommand.Execute(entryclassid);
        }
    
    }
}