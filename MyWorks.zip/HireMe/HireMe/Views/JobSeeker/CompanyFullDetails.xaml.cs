﻿using System;
using Xamarin.Forms;

namespace HireMe
{
	public partial class CompanyFullDetails : ContentPage
	{

		CompanyFullDetailsViewModel CompanyFullDetailsViewModel;

		#region Constructor
		public CompanyFullDetails(String companyID, String companyName)
		{

			InitializeComponent();
			Title = companyName;
			CompanyFullDetailsViewModel = new CompanyFullDetailsViewModel(Navigation, companyID, companyName);
			BindingContext = CompanyFullDetailsViewModel;

		}
		#endregion

	}
}
