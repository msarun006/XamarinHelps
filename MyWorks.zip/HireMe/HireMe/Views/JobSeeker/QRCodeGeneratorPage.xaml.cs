﻿using HireMe.ViewModels.JobSeeker;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.JobSeeker
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class QRCodeGeneratorPage : ContentPage
    {
        public QRCodeGeneratorPage()
        {
            InitializeComponent();
            BindingContext = new QRCodeGeneratorViewModel();
        }
    }
}