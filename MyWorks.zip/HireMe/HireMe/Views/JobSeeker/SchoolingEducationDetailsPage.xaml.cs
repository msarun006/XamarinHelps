﻿using HireMe.ViewModels.JobSeeker;
using System;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using HireMe.Models.Recruiter;
using System.Collections.ObjectModel;

namespace HireMe.Views.JobSeeker
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SchoolingEducationDetailsPage : ContentPage
    {
        private string editEducation;
        private Educational_Details selectedItem;

        public SchoolingEducationDetailsPage(string editEducation, ObservableCollection<Educational_Details> itemsource, string id)
        {
            InitializeComponent();
            BindingContext = new SchoolEducationDetailsViewModel(Navigation, itemsource, id);
        }
        public SchoolingEducationDetailsPage(string editEducation, ObservableCollection<Educational_Details> itemsource, Educational_Details selectedItem)
        {
            InitializeComponent();
            this.editEducation = editEducation;
            BindingContext = new SchoolEducationDetailsViewModel(Navigation, itemsource,selectedItem);
        }

        private void OnPercetageTapped(object sender, EventArgs e)
        {
            entryPercentage.Focus();
        }
    }
}