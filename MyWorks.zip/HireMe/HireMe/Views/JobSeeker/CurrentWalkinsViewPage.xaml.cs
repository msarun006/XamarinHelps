﻿using HireMe.ViewModels.JobSeeker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.JobSeeker
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CurrentWalkinsViewPage : ContentPage
    {
        CurrentWalkinsViewModel CurrentWalkinsViewModel;
        public CurrentWalkinsViewPage()
        {
            InitializeComponent();
            CurrentWalkinsViewModel = new CurrentWalkinsViewModel(Navigation);
            BindingContext = CurrentWalkinsViewModel;
        }

        private void DatepickerToDate_DateSelected(object sender, DateChangedEventArgs e)
        {
            var datepicker = (DatePicker)sender;
            CurrentWalkinsViewModel.ToDateChangedCommand.Execute(datepicker);
        }

        private void DatepickerFromDate_DateSelected(object sender, DateChangedEventArgs e)
        {
            var datepicker = (DatePicker)sender;
            CurrentWalkinsViewModel.FromDateChangedCommand.Execute(datepicker);
        }
    }
}