﻿//using HireMe.Models.Recruiter;
//using HireMe.ViewModels.JobSeeker;
//using System;

//using Xamarin.Forms;
//using Xamarin.Forms.Xaml;

//namespace HireMe.Views.JobSeeker
//{
//    [XamlCompilation(XamlCompilationOptions.Compile)]
//    public partial class SeekerEducationPage : ContentPage
//    {
        
//        #region  Object Creation
//        SeekerEducationViewModel SeekerEducationViewModel;  
//        bool _isFristTime = true;
//        private bool _canShowPersonal;
//        Educational_Details _modifiEducationalDetails;
//        public string fieldvalues;

//        public SeekerEducationPage()
//        {
//            InitializeComponent();            
//            SeekerEducationViewModel = new SeekerEducationViewModel(Navigation);
//            BindingContext = SeekerEducationViewModel;
//            if (Device.RuntimePlatform.Equals("Android"))
//            {
//                //Track Page 
//                GoogleAnalyticService.Track_App_Page("Android SeekerPersonalAndEducationPage");
//            }
//            //or iOS 
//            else
//            { //Track Page 
//                GoogleAnalyticService.Track_App_Page("iOS  SeekerPersonalAndEducationPage");
//            }
//        }
//        private void OnTextchanged(object sender, TextChangedEventArgs e)
//        {
//            var entry = (Entry)sender;
//            var entryclassid = entry.ClassId;
//            SeekerEducationViewModel.TextChangedCommand.Execute(entryclassid);
//        }

//        private void DatepickerDateofBirth_DateSelected(object sender, DateChangedEventArgs e)
//        {
//            var datepicker = (DatePicker)sender;
//            SeekerEducationViewModel.DateChangedCommand.Execute(datepicker);
//        }
        


//        async protected override void OnAppearing()
//        {
//            base.OnAppearing();
//            if (MessageStringConstants.IsSchoolOrCollegeDetailsUpdated)
//            {
//                await SeekerEducationViewModel.ShowEducationalTab();
//                MessageStringConstants.IsSchoolOrCollegeDetailsUpdated = false;
//            }
//            //if (MessageStringConstants.IsSchoolOrCollegeDetailsUpdated)
//            //{
//            //    await SeekerEducationViewModel.ShowEducationalTab();
//            //    MessageStringConstants.IsSchoolOrCollegeDetailsUpdated = false;
//            //}

//            //if (_isFristTime == true)
//            //{
//            //    if (_canShowPersonal == true)
//            //    {
//            //        SeekerEducationViewModel.PersonalBackbtnColor = Color.Transparent;
//            //        SeekerEducationViewModel.EducationBackbtnColor = Color.FromHex("#F7CC59");
//            //        await SeekerEducationViewModel.ShowEducationalTab();

//            //    }
//            //    else
//            //    {
//            //        SeekerEducationViewModel.PersonalBackbtnColor = Color.FromHex("#F7CC59");
//            //        SeekerEducationViewModel.EducationBackbtnColor = Color.Transparent;
//            //        await SeekerEducationViewModel.ShowPersonalTab();
//            //    }
//            //    _isFristTime = false;
//            //}
//        }

//        private async void OnPersonalButton(object sender, EventArgs e)
//        {
//            //PersonalBackbtnColor.BackgroundColor = Color.FromHex("#F7CC59");
//            //EducationBackbtnColor.BackgroundColor = Color.Transparent;
//            //await _SeekerPersonalAndEducationViewModel.ShowPersonalTab();
//        }

//        private async void ONEducationButton(object sender, EventArgs e)
//        {
//            //PersonalBackbtnColor.BackgroundColor = Color.Transparent;
//            //EducationBackbtnColor.BackgroundColor = Color.FromHex("#F7CC59");
//            //await _SeekerPersonalAndEducationViewModel.ShowEducationalTab();
//        }

//        private void ToggleSameAddress(object sender, ToggledEventArgs e)
//        {
//            var switchtoggle = (Switch)sender;
//            var switchclassid = switchtoggle.ClassId;    //Switch ToggleEvent Identified by ClassID
//            SeekerEducationViewModel.TapCommand.Execute(switchclassid);
//        }

//        private void Unfocused(object sender, FocusEventArgs e)
//        {
//            var entry = (Entry)sender;
//            var entryclassid = entry.ClassId;
//            SeekerEducationViewModel.TapCommand.Execute(entryclassid);
//        }

//        public void SetFieldValue(string fieldtype, object fieldvalue)
//        {
//            fieldvalues = ((CommonListItemSource)fieldvalue).Title;
//            SeekerEducationViewModel.SetFieldValue(fieldtype, fieldvalue);
//        }
//        #endregion
//    }
//}