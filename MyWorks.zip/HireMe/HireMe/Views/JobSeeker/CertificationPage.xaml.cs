﻿using HireMe.Models.Recruiter;
using HireMe.ViewModels.JobSeeker;
using System;
using System.Collections.ObjectModel;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.JobSeeker
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CertificationPage : ContentPage
    {
        public CertificationPage(ObservableCollection<CertificationDetails> certifications)
        {
            InitializeComponent();
            BindingContext = new CertificationViewModel(Navigation,certifications);
        }

        private void TapGestureRecognizer_Tapped(object sender, EventArgs e)
        {
            Picker_Year.Focus();
        }
    }
}