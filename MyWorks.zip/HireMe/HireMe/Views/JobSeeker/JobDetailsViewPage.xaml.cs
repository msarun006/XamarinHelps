﻿using HireMe.Models.JobSeeker;
using HireMe.ViewModels.JobSeeker;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.JobSeeker
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class JobDetailsViewPage : ContentPage
    {
        JobDetailsViewModel JobDetailsViewModel;
        public JobDetailsViewPage(string pageName, string JobPostingID, ObservableCollection<CurrentOpeningsResponseData> currentOpenings, ObservableCollection<SearchJobsResponseData> searjobs, ObservableCollection<RecommendedJobResponseData> recommendedJobs, ObservableCollection<CurrentWalkinsResponseData> CurrentWalkins)
        {
            InitializeComponent();
            JobDetailsViewModel = new JobDetailsViewModel(Navigation,pageName, JobPostingID, dynamic_StackLayout_LanguageKnown, currentOpenings,searjobs,recommendedJobs,CurrentWalkins);
            BindingContext = JobDetailsViewModel;
        }
    }
}