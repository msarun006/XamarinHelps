﻿using HireMe.Models.JobSeeker;
using HireMe.ViewModels.JobSeeker;
using Rg.Plugins.Popup.Pages;
using System.Collections.Generic;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.JobSeeker
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class BranchAddressPopupPage : PopupPage
    {
        public BranchAddressPopupPage(List<BranchDetail> _brachDetails)
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            BindingContext = new BranchAddressPopupViewModel(Navigation, _brachDetails);
        }
        protected override bool OnBackButtonPressed()
        {
            // Prevent hide popup
            //return base.OnBackButtonPressed();
            return true;
        }

        // Invoced when background is clicked
        protected override bool OnBackgroundClicked()
        {
            // Return default value - CloseWhenBackgroundIsClicked
            //return base.OnBackgroundClicked();
            return false;
        }
    }
}