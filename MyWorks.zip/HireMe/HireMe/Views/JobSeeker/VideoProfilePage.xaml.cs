using Xamarin.Forms;
using HireMe.ViewModels.JobSeeker;

namespace HireMe
{
    public partial class VideoProfilePage : ContentPage
    {
        #region ClassVariable
        
        SeekerVideoProfileViewModel SeekerVideoProfileViewModel;
        #endregion

        #region Constructor
        public VideoProfilePage(bool showNextButton = false)
        {

            System.Diagnostics.Debug.WriteLine("@ VideoProfilePage.VideoProfilePage");
            InitializeComponent();
            SeekerVideoProfileViewModel = new SeekerVideoProfileViewModel(Navigation, showNextButton);
            BindingContext = SeekerVideoProfileViewModel;
        }
        #endregion
    }
}
