﻿using HireMe.Models.Recruiter;
using HireMe.ViewModels.JobSeeker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.JobSeeker
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class FloatingLabelEntry : ContentPage
    {
        bool _isFristTime = true;
        private bool _canShowPersonal;
        JobSeekerProfileDetails _personalDetails;
        //EducationalDetailBO _educationaldetails;
        Educational_Details _modifiEducationalDetails;
      //  private FloatingLabelEntryViewModel _FloatingLabelEntryViewModel { get; set; }
        public string fieldvalues;
        public FloatingLabelEntry()
        {
            InitializeComponent();
          //  _FloatingLabelEntryViewModel = new FloatingLabelEntryViewModel(Navigation, dynamic_StackLayout_SchoolorCollege, dynamicSkillScroll, dynamicLabelGrid);
          //  BindingContext = _FloatingLabelEntryViewModel;
            if (Device.RuntimePlatform.Equals("Android"))
            {
                //Track Page 
                GoogleAnalyticService.Track_App_Page("Android SeekerPersonalAndEducationPage");
            }
            //or iOS 
            else
            { //Track Page 
                GoogleAnalyticService.Track_App_Page("iOS  SeekerPersonalAndEducationPage");
            }
        }
        private void OnTextchanged(object sender, TextChangedEventArgs e)
        {
            var entry = (Entry)sender;
            var entryclassid = entry.ClassId;
        //    _FloatingLabelEntryViewModel.TextChangedCommand.Execute(entryclassid);
        }

        private void DatepickerDateofBirth_DateSelected(object sender, DateChangedEventArgs e)
        {
            var datepicker = (DatePicker)sender;
         //   _FloatingLabelEntryViewModel.DateChangedCommand.Execute(datepicker);
        }

        #region SeekerPersonalAndEducationPage
        public FloatingLabelEntry(bool canShowPersonal)
        {
            try
            {
                InitializeComponent();
                //_canShowPersonal = canShowPersonal;
                //_personalDetails = new JobSeekerProfileDetails();
                //_modifiEducationalDetails = new Educational_Details();
                //_FloatingLabelEntryViewModel = new FloatingLabelEntryViewModel(Navigation, dynamic_StackLayout_SchoolorCollege, dynamicSkillScroll, dynamicLabelGrid);
                //BindingContext = _FloatingLabelEntryViewModel;

            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);

            }

        }
        #endregion


        async protected override void OnAppearing()
        {
            base.OnAppearing();

            //if (MessageStringConstants.IsSchoolOrCollegeDetailsUpdated)
            //{
            //    await _FloatingLabelEntryViewModel.ShowEducationalTab();
            //    MessageStringConstants.IsSchoolOrCollegeDetailsUpdated = false;
            //}

            //// if (AppPreferences.ProfilePicture != string.Empty)
            ////profilepic.Source = AppPreferences.ProfilePicture;
            //if (_isFristTime == true)
            //{
            //    if (_canShowPersonal == true)
            //    {
            //        _FloatingLabelEntryViewModel.PersonalBackbtnColor = Color.Transparent;
            //        _FloatingLabelEntryViewModel.EducationBackbtnColor = Color.FromHex("#F7CC59");
            //        await _FloatingLabelEntryViewModel.ShowEducationalTab();

            //    }
            //    else
            //    {
            //        _FloatingLabelEntryViewModel.PersonalBackbtnColor = Color.FromHex("#F7CC59");
            //        _FloatingLabelEntryViewModel.EducationBackbtnColor = Color.Transparent;
            //        await _FloatingLabelEntryViewModel.ShowPersonalTab();
            //    }
            //    _isFristTime = false;
            //}
        }

        private async void OnPersonalButton(object sender, EventArgs e)
        {
            //PersonalBackbtnColor.BackgroundColor = Color.FromHex("#F7CC59");
            //EducationBackbtnColor.BackgroundColor = Color.Transparent;
            //await _FloatingLabelEntryViewModel.ShowPersonalTab();
        }

        private async void ONEducationButton(object sender, EventArgs e)
        {
            //PersonalBackbtnColor.BackgroundColor = Color.Transparent;
            //EducationBackbtnColor.BackgroundColor = Color.FromHex("#F7CC59");
            //await _FloatingLabelEntryViewModel.ShowEducationalTab();
        }

        private void ToggleSameAddress(object sender, ToggledEventArgs e)
        {
            var switchtoggle = (Switch)sender;
            var switchclassid = switchtoggle.ClassId;    //Switch ToggleEvent Identified by ClassID
         //   _FloatingLabelEntryViewModel.TapCommand.Execute(switchclassid);
        }

        private void Unfocused(object sender, FocusEventArgs e)
        {
            var entry = (Entry)sender;
            var entryclassid = entry.ClassId;
       //     _FloatingLabelEntryViewModel.TapCommand.Execute(entryclassid);
        }

        private void Email_Unfocused(object sender, FocusEventArgs e)
        {
            var entry = (Entry)sender;
            var entryclassid = entry.ClassId;
       //     _FloatingLabelEntryViewModel.TapCommand.Execute(entryclassid);

        }

        public void SetFieldValue(string fieldtype, object fieldvalue)
        {
            fieldvalues = ((CommonListItemSource)fieldvalue).Title;
        //    _FloatingLabelEntryViewModel.SetFieldValue(fieldtype, fieldvalue);
        }

        private void EditorUnfocues(object sender, FocusEventArgs e)
        {
            var entry = (Editor)sender;
            var entryclassid = entry.ClassId;
      //      _FloatingLabelEntryViewModel.TapCommand.Execute(entryclassid);
        }

        private void PincodeUnfocused(object sender, FocusEventArgs e)
        {
            var entry = (Entry)sender;
            var entryclassid = entry.ClassId;
         //   _FloatingLabelEntryViewModel.TapCommand.Execute(entryclassid);
        }
    }
}