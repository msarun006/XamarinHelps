using HireMe.ViewModels.JobSeeker;
using Xamarin.Forms;

namespace HireMe
{
    public partial class SeekerChangePassword : ContentPage
	{
        #region Main Constructor
        private SeekerChangePasswordPageViewModel ViewModel { get; set; }
        public SeekerChangePassword()
        {
            InitializeComponent();
            ViewModel = new SeekerChangePasswordPageViewModel();
            BindingContext = ViewModel;
        }
        #endregion

        #region Entry UnFocused TapCommand
        private void NewPasswordUnFocused(object sender, FocusEventArgs e)
        {
            var entry = (Entry)sender;
            var entryclassid = entry.ClassId;
            ViewModel.TapCommand.Execute(entryclassid);
        }
        private void ConfirmPasswordUnFocused(object sender, FocusEventArgs e)
        {
            var entry = (Entry)sender;
            var entryclassid = entry.ClassId;
            ViewModel.TapCommand.Execute(entryclassid);
        }


        private void OldPasswordUnFocused(object sender, FocusEventArgs e)
        {
            var entry = (Entry)sender;
            var entryclassid = entry.ClassId;
            ViewModel.TapCommand.Execute(entryclassid);
        }
        #endregion
    }
}
