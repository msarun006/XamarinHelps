﻿using System;
using Xamarin.Forms;

namespace HireMe
{
    public partial class CompanyWebSide : ContentPage
	{
		CompanyWebSideViewModel CompanyWebSideViewModel;

		#region Constructor
		public CompanyWebSide(String title, String url)
		{
			Title = title;
			InitializeComponent();
			CompanyWebSideViewModel = new CompanyWebSideViewModel(url);
			BindingContext = CompanyWebSideViewModel;
			 
		}
		#endregion
		protected async override void OnAppearing()
		{
			base.OnAppearing();
			await progressLoad.ProgressTo(0.9, 900, Easing.BounceIn);

		}
		void progressLoad_Navigated(object sender, Xamarin.Forms.WebNavigatedEventArgs e)
		{
			progressLoad.IsVisible = false;
		}

		void progressLoad_Navigating(object sender, Xamarin.Forms.WebNavigatingEventArgs e)
		{
			progressLoad.IsVisible = true;
		}
	}
}
