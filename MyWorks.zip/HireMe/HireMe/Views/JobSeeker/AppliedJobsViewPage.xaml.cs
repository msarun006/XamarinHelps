﻿using HireMe.ViewModels.JobSeeker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.JobSeeker
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AppliedJobsViewPage : ContentPage
    {
        AppliedJobsViewModel AppliedJobsViewModel;
        public AppliedJobsViewPage()
        {
            InitializeComponent();
            AppliedJobsViewModel = new AppliedJobsViewModel(Navigation);
            BindingContext = AppliedJobsViewModel;
        }
    }
}