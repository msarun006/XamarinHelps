﻿using Xamarin.Forms;

namespace HireMe
{
    public partial class CompanyDetails : ContentPage
	{
		string _idCard = string.Empty;
        public bool isClicked = true;

		CompanyDetailsViewModel CompanyDetailsViewModel;


		#region Constructor
		public CompanyDetails()
		{
			InitializeComponent();
			CompanyDetailsViewModel = new CompanyDetailsViewModel(Navigation);
			BindingContext = CompanyDetailsViewModel;



			//LoadcomapanyDetails();
			
		}
		#endregion

		//Commented by sudhagar

		/*
		#region LoadcomapanyDetails
		public async void LoadcomapanyDetails()
		{
			UserDialogs.Instance.ShowLoading("Loading Company Details");
			await ShowCompanyList();
			UserDialogs.Instance.HideLoading();
		}
		#endregion

        #region ShowCompanyList
		private async Task ShowCompanyList()
		{
			try
			{
				var requestdata = new MasterTableRequestData()
				{
					
					TableName = "companylist"
				};
				Transport objAPICall = new Transport("mastertables");
				var responseobj = await objAPICall.PostAsync<CompanydetailsResponseData, MasterTableRequestData>(requestdata);

				if (responseobj != null)
				{

					if (responseobj.Code == "200" && responseobj.ResponseText != null)
					{
						if (responseobj.ResponseText.companylist.Count > 0)
						{
							listCompanyDetails.IsVisible = true;
							listCompanyDetails.ItemsSource = responseobj.ResponseText.companylist;
							lblNoRecords.IsVisible = false;
						}
						else
						{
							listCompanyDetails.IsVisible = false;
							lblNoRecords.IsVisible = true;
						}

					}
					else
					{
						listCompanyDetails.IsVisible = false;
						lblNoRecords.IsVisible = true;
					}
				}
				else
				{
					UserDialogs.Instance.HideLoading();
					await DisplayAlert("", MessageStringConstants.ProfileDetailsUnavailable, "OK");
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine(ex.Message);
				UserDialogs.Instance.HideLoading();
			}
		}
        #endregion

        #region NotificationListView_ItemTapped
        async void ListView_ItemTapped(object sender, ItemTappedEventArgs e)
        {
            Debug.WriteLine("@ SeekerNotificationPage.NotificationListView_ItemTapped");
            var data = e.Item as Companylist;
            if (isClicked)
            {
                isClicked = false;
               await Navigation.PushAsync(new CompanyFullDetails(data.id.ToString(), data.name));

            }
            await Task.Run(async () =>
            {
                await Task.Delay(500);
                isClicked = true;
            });

        }
        #endregion
        */
    }
}
