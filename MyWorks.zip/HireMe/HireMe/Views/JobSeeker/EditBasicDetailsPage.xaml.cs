﻿using HireMe.ViewModels.JobSeeker;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.JobSeeker
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class EditBasicDetailsPage : ContentPage
    {
        EditBasicDetailsViewModel _EditBasicDetailsViewModel;
        //public EditBasicDetailsPage(string firstname, string lastname, string emailid, string mobile)
        //{
        //    InitializeComponent();
        //    _EditBasicDetailsViewModel = new EditBasicDetailsViewModel(Navigation, firstname, lastname, emailid, mobile);
        //    BindingContext = _EditBasicDetailsViewModel;
        //}
        public EditBasicDetailsPage()
        {
            InitializeComponent();
            _EditBasicDetailsViewModel = new EditBasicDetailsViewModel(Navigation);
            BindingContext = _EditBasicDetailsViewModel;
        }

        private void UnfocusedEvent(object sender, FocusEventArgs e)
        {
            var entry = (Entry)sender;
            var entryclassid = entry.ClassId;
            _EditBasicDetailsViewModel.TapCommand.Execute(entryclassid);

        }
    }
}