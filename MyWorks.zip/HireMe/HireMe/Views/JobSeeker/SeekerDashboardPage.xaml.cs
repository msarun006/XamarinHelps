using Xamarin.Forms;

namespace HireMe
{
    public partial class SeekerDashboardPage : ContentPage
    {

        #region Constructor
        public SeekerDashboardPage()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, true);
            BindingContext = new SeekerDashboardViewModel(Navigation);
        }
        #endregion

        protected override bool OnBackButtonPressed()
        {
            return true;
        }
    }
}
