using HireMe.ViewModels.JobSeeker;
using Xamarin.Forms;

namespace HireMe
{
    public partial class SeekerAssessmentPage : ContentPage
	{
        #region Main Constructor
   
		public SeekerAssessmentPage()
		{
			InitializeComponent();
            BindingContext = new SeekerAssessmentPageViewModel();
        }
        #endregion
    }
}
