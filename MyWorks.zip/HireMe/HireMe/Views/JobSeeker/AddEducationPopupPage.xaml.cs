﻿using HireMe.Models.Recruiter;
using HireMe.ViewModels.JobSeeker;
using System.Collections.Generic;
using System.Collections.ObjectModel;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.JobSeeker
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AddEducationPopupPage : ContentPage
    {
        AddEducationPopupViewModel _AddEducationPopupViewModel;

       

        public AddEducationPopupPage(List<string> _courseTypeID, List<CourseType> GlobalCommonListItemSource, ObservableCollection<Educational_Details> ItemSource)
        {
            InitializeComponent();
            //NavigationPage.SetHasNavigationBar(this, false);
            //NavigationPage.SetHasBackButton(this, false);
            _AddEducationPopupViewModel = new AddEducationPopupViewModel(Navigation, _courseTypeID, GlobalCommonListItemSource, ItemSource);
            BindingContext = _AddEducationPopupViewModel;
        }

        protected override bool OnBackButtonPressed()
        {
            // Prevent hide popup
            //return base.OnBackButtonPressed();
            return false;
        }

        // Invoced when background is clicked
        //protected override bool OnBackgroundClicked()
        //{
        //    // Return default value - CloseWhenBackgroundIsClicked
        //    //return base.OnBackgroundClicked();
        //    return false;
        //}
    }
}