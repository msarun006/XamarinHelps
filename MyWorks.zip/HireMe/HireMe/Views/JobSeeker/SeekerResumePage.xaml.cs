using Xamarin.Forms;

namespace HireMe
{
    public partial class SeekerResumePage : ContentPage
    {
    //    List<UserResourceType> ltUserResourceType = new List<UserResourceType>();
    //    public SeekerResumePage()
    //    {
    //        InitializeComponent();
    //    }
    //    private async void GetS3Credentials()
    //    {
    //        if (string.IsNullOrEmpty(AppPreferences.S3AccessKeyID))
    //        {
    //            S3Utils obj = new S3Utils();
    //            await obj.GetS3Credentials();
    //        }
    //    }
    //    async void OnResumeUploadTapped(object sender, EventArgs args)
    //    {
    //        SetResumeCompletedFlag();
    //        bool canProceed = true;
    //        var fileName = string.Empty;
    //        var filePath = string.Empty;


    //        try
    //        {
    //            var selectedfile = await CrossFilePicker.Current.PickFile();
    //            filePath = selectedfile.FilePath;
    //            fileName = selectedfile.FileName;
    //            fileName = AppSessionData.ActiveToken.HireMeID + "_" + "ProfileDoc" + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + System.IO.Path.GetExtension(fileName);

    //        }
    //        catch (Exception ex)
    //        {
    //            System.Diagnostics.Debug.WriteLine("EXCEPTION :" + ex.StackTrace);
    //            canProceed = false;
    //        }

    //        if (canProceed)
    //        {
    //            if (!string.IsNullOrEmpty(fileName) && !string.IsNullOrEmpty(filePath))
    //            {
    //                try
    //                {
    //                    var appdirectory = DependencyService.Get<IImageManager>().GetStorageDirectory(ResourceTypeEnums.Documents);
    //                    var localFilePath = DependencyService.Get<IImageManager>().CopyFileToHiremeDocs(filePath, fileName, true);
    //                    labelFileName.Text = fileName;
    //                    var responseData = await S3Manager.UploadFile(localFilePath, fileName, "hiremee.docs");

    //                    if (!Convert.ToBoolean(AppPreferences.IsResumeUploaded))
    //                    {
    //                        SetResumeCompletedFlag();
    //                    }
    //                }
    //                catch (Exception e)
    //                {
    //                    await DisplayAlert("", e.Message, "ok");
    //                }
    //            }
    //        }
    //    }

    //    public void SetResumeCompletedFlag()
    //    {

    //        AppPreferences.IsResumeUploaded = true;
    //    }

    //    public async Task SaveDetails(object sender, EventArgs args)
    //    {
    //        SetResumeCompletedFlag();
    //        UserResourceInsertRequestData data = new UserResourceInsertRequestData();
    //        data.ResourceTypeId = Convert.ToInt32(Models.ResourceType.Resume).ToString();
    //        data.s3Id = labelFileName.Text;
    //        data.ResourceUrl = Path.Combine(APIData.S3DocURL, labelFileName.Text);
    //        UserResourceInsertManager manager = new UserResourceInsertManager();
    //        var statusResult = await manager.GetUserResourceInsertData(data);
    //        if (statusResult != null)
    //        {
    //            await DisplayAlert("", "Resume Uploaded Successfully", "Ok");
    //        }
    //    }
    }
}
