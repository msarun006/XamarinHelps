﻿using HireMe.ViewModels.JobSeeker;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.UI
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class StudentIdCardPage : ContentPage
    {
        public StudentIdCardPageViewModel _viewModel { get; set; }

        public StudentIdCardPage()
        {
            InitializeComponent();
            _viewModel = new StudentIdCardPageViewModel(Navigation);
            BindingContext = _viewModel;
        }

    }
}
