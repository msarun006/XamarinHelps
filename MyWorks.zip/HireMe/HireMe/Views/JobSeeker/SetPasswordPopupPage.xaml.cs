﻿using HireMe.ViewModels.JobSeeker;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.JobSeeker
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SetPasswordPopupPage : ContentPage
    {
        SetPasswordPopupViewModel _viewModel;
        public SetPasswordPopupPage()
        {
            InitializeComponent();
            //NavigationPage.SetHasNavigationBar(this,false);
            NavigationPage.SetHasBackButton(this,false);
            _viewModel = new SetPasswordPopupViewModel(Navigation);
            BindingContext = _viewModel;
            

        }

        #region OnBackButtonPressed
        protected override bool OnBackButtonPressed()
        {
            // Prevent hide popup
            //return base.OnBackButtonPressed();
            return true;
        }
        #endregion

        //#region OnBackgroundClicked

        //// Invoced when background is clicked
        //protected override bool OnBackgroundClicked()
        //{
        //    // Return default value - CloseWhenBackgroundIsClicked
        //    //return base.OnBackgroundClicked();
        //    return false;
        //}
        //#endregion
    }
}