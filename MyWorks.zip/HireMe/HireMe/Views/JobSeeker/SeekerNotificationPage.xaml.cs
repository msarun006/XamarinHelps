using Xamarin.Forms;
using HireMe.ViewModels.JobSeeker;

namespace HireMe
{
    public partial class SeekerNotificationPage : ContentPage
	{
        SeekerNotificationViewModel SeekerNotificationViewModel;
        public SeekerNotificationPage()
        {
            InitializeComponent();
            SeekerNotificationViewModel = new SeekerNotificationViewModel(Navigation);
            BindingContext = SeekerNotificationViewModel;
        }
    }
}