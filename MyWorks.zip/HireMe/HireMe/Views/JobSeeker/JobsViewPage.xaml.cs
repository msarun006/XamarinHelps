﻿using HireMe.ViewModels.JobSeeker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.JobSeeker
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class JobsViewPage : ContentPage
    {
        JobsViewModel JobsViewModel;
        public JobsViewPage()
        {
            InitializeComponent();
            JobsViewModel = new JobsViewModel(Navigation);
            BindingContext = JobsViewModel;
        }
    }
}