﻿
using HireMe.Models.Recruiter;
using HireMe.ViewModels.JobSeeker;
using System.Collections.ObjectModel;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.JobSeeker
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CollegeEducationDetailsPage : ContentPage
    {
        CollegeEducationDetailsViewModel objCollegeEducationDetailsViewModel;
        public CollegeEducationDetailsPage(string fieldtype, ObservableCollection<Educational_Details> itemsource, Educational_Details EducationalDetailBO)
        {
            InitializeComponent();
            Title = fieldtype;
            objCollegeEducationDetailsViewModel = new CollegeEducationDetailsViewModel(Navigation, itemsource, EducationalDetailBO);
            BindingContext = objCollegeEducationDetailsViewModel;
        }
        public CollegeEducationDetailsPage(string fieldtype, ObservableCollection<Educational_Details> itemsource, string courseid)
        {
            InitializeComponent();
            Title = fieldtype;
            objCollegeEducationDetailsViewModel = new CollegeEducationDetailsViewModel(Navigation, itemsource, courseid);
            BindingContext = objCollegeEducationDetailsViewModel;
        }
        private void OnTextchanged(object sender, TextChangedEventArgs e)
        {
            var entry = (Entry)sender;
            var entryclassid = entry.ClassId;
            objCollegeEducationDetailsViewModel.TextChangedCommand.Execute(entryclassid);
        }

        private void OnCGPATapped(object sender, System.EventArgs e)
        {
            if (objCollegeEducationDetailsViewModel.IsEntryCGPA == true)
                entryCGPA.Focus();
        }

        private void OnPercetageTapped(object sender, System.EventArgs e)
        {
            if (objCollegeEducationDetailsViewModel.IsEntryPercentage == true)
                entryPercentage.Focus();
        }
    }
}
