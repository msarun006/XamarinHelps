﻿using HireMe.ViewModels.JobSeeker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views.JobSeeker
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class RecommendedJobsViewPage : ContentPage
    {
        SearchJobsViewModel SearchJobsViewModel;
        public RecommendedJobsViewPage()
        {
            InitializeComponent();
            SearchJobsViewModel = new SearchJobsViewModel(Navigation, "Recommended Jobs");
            BindingContext = SearchJobsViewModel;
            Title = "Recommended Jobs";
        }
    }
}