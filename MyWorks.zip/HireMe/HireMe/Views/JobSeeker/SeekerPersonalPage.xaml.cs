﻿namespace HireMe.Views.JobSeeker
{
    //[XamlCompilation(XamlCompilationOptions.Compile)]
    //public partial class SeekerPersonalPage : ContentPage
    //{
    //    SeekerPersonalViewModel SeekerPersonalViewModel;


    //    #region  Object Creation
    //    bool _isFristTime = true;
    //   // JobSeekerProfileDetails _personalDetails;
    //    public string fieldvalues;
    //    public SeekerPersonalPage()
    //    {
    //        InitializeComponent();
    //       // SeekerPersonalViewModel = new SeekerPersonalViewModel(Navigation);
    //        BindingContext = SeekerPersonalViewModel;
    //        if (Device.RuntimePlatform.Equals("Android"))
    //        {
    //            //Track Page 
    //            GoogleAnalyticService.Track_App_Page("Android SeekerPersonalAndEducationPage");
    //        }
    //        //or iOS 
    //        else
    //        { //Track Page 
    //            GoogleAnalyticService.Track_App_Page("iOS  SeekerPersonalAndEducationPage");
    //        }
    //    }
    //    private void OnTextchanged(object sender, TextChangedEventArgs e)
    //    {
    //        var entry = (Entry)sender;
    //        var entryclassid = entry.ClassId;
    //        SeekerPersonalViewModel.TextChangedCommand.Execute(entryclassid);
    //    }

    //    private void DatepickerDateofBirth_DateSelected(object sender, DateChangedEventArgs e)
    //    {
    //        var datepicker = (DatePicker)sender;
    //        SeekerPersonalViewModel.DateChangedCommand.Execute(datepicker);
    //    }


    //    async protected override void OnAppearing()
    //    {
    //        base.OnAppearing();

    //        //if (MessageStringConstants.IsSchoolOrCollegeDetailsUpdated)
    //        //{
    //        //    await _SeekerPersonalAndEducationViewModel.ShowEducationalTab();
    //        //    MessageStringConstants.IsSchoolOrCollegeDetailsUpdated = false;
    //        //}

    //        //if (AppPreferences.ProfilePicture != string.Empty)
    //        //    //profilepic.Source = AppPreferences.ProfilePicture;
    //        //    if (_isFristTime == true)
    //        //    {
    //        //        if (_canShowPersonal == true)
    //        //        {
    //        //            _SeekerPersonalAndEducationViewModel.PersonalBackbtnColor = Color.Transparent;
    //        //            _SeekerPersonalAndEducationViewModel.EducationBackbtnColor = Color.FromHex("#F7CC59");
    //        //            await _SeekerPersonalAndEducationViewModel.ShowEducationalTab();

    //        //        }
    //        //        else
    //        //        {
    //        //            _SeekerPersonalAndEducationViewModel.PersonalBackbtnColor = Color.FromHex("#F7CC59");
    //        //            _SeekerPersonalAndEducationViewModel.EducationBackbtnColor = Color.Transparent;
    //        //            await _SeekerPersonalAndEducationViewModel.ShowPersonalTab();
    //        //        }
    //        //        _isFristTime = false;
    //        //    }
    //    }

    //    private async void OnPersonalButton(object sender, EventArgs e)
    //    {
    //        //PersonalBackbtnColor.BackgroundColor = Color.FromHex("#F7CC59");
    //        //EducationBackbtnColor.BackgroundColor = Color.Transparent;
    //        //await _SeekerPersonalAndEducationViewModel.ShowPersonalTab();
    //    }

    //    private async void ONEducationButton(object sender, EventArgs e)
    //    {
    //        //PersonalBackbtnColor.BackgroundColor = Color.Transparent;
    //        //EducationBackbtnColor.BackgroundColor = Color.FromHex("#F7CC59");
    //        //await _SeekerPersonalAndEducationViewModel.ShowEducationalTab();
    //    }

    //    private void ToggleSameAddress(object sender, ToggledEventArgs e)
    //    {
    //        var switchtoggle = (Switch)sender;
    //        var switchclassid = switchtoggle.ClassId;    //Switch ToggleEvent Identified by ClassID
    //        SeekerPersonalViewModel.TapCommand.Execute(switchclassid);
    //    }

    //    private void Unfocused(object sender, FocusEventArgs e)
    //    {
    //        var entry = (Entry)sender;
    //        var entryclassid = entry.ClassId;
    //        SeekerPersonalViewModel.TapCommand.Execute(entryclassid);
    //    }

    //    public void SetFieldValue(string fieldtype, object fieldvalue)
    //    {
    //        fieldvalues = ((CommonListItemSource)fieldvalue).Title;
    //        SeekerPersonalViewModel.SetFieldValue(fieldtype, fieldvalue);
    //    }
    //    #endregion
    //}
}