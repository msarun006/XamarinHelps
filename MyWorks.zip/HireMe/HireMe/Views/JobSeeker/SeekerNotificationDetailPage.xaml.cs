﻿using HireMe.Models.JobSeeker;
using HireMe.ViewModels.JobSeeker;
using Xamarin.Forms;

namespace HireMe
{
    public partial class SeekerNotificationDetailPage : ContentPage
	{

        private Notification selectedItem;

        SeekerNotificationDetailsViewModel SeekerNotificationDetailsViewModel;
        private string title;
        private string mailContent;

        public SeekerNotificationDetailPage(Notification selectedItem)
        {
            InitializeComponent();
            this.selectedItem = selectedItem;
            SeekerNotificationDetailsViewModel = new SeekerNotificationDetailsViewModel(Navigation, this.selectedItem);
            BindingContext = SeekerNotificationDetailsViewModel;
        }

        public SeekerNotificationDetailPage(string title, string mailContent)
        {
            InitializeComponent();
            this.title = title;
            this.mailContent = mailContent;
            SeekerNotificationDetailsViewModel = new SeekerNotificationDetailsViewModel(Navigation, title, mailContent);
            BindingContext = SeekerNotificationDetailsViewModel;
        }
    }
    
}
