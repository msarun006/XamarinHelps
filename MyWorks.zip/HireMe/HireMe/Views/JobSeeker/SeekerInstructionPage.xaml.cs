﻿using HireMe.ViewModels.JobSeeker;

using Xamarin.Forms;

namespace HireMe
{
    public partial class SeekerInstructionPage : ContentPage
    {
        private SeekerInstructionPageViewModel _seekerInstructionPageViewModel { get; set; }
        public SeekerInstructionPage()
        {
            InitializeComponent();
            _seekerInstructionPageViewModel = new SeekerInstructionPageViewModel();
            BindingContext = _seekerInstructionPageViewModel;
        }


    }
}
