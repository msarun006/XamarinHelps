﻿using HireMe.ViewModels;
using Xamarin.Forms;
namespace HireMe.Views.JobSeeker
{
    public partial class OTPVerifyPage : ContentPage
    {
        OTPVerifyViewModel _oTPVerifyViewModel{ get; set; }

        public OTPVerifyPage(string verificationClass)
        {
            InitializeComponent();
            NavigationPage.SetHasBackButton(this,false);
            _oTPVerifyViewModel = new OTPVerifyViewModel(Navigation, verificationClass);
            BindingContext = _oTPVerifyViewModel;
        }




        #region Handled BackButton Pressed
        protected override bool OnBackButtonPressed()
        {

            if(!_oTPVerifyViewModel._isRunning)
            {
                _oTPVerifyViewModel.StopTimer();
            }
            return true;
        }
        #endregion

        protected override void OnDisappearing()
        {
            base.OnDisappearing();

             

            // _oTPVerifyViewModel.StopTimer();
        }



    }
}
