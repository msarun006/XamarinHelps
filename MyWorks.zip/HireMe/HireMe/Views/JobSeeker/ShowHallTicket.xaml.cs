﻿
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using HireMe.ViewModels.JobSeeker;

namespace HireMe.UI
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ShowHallTicket : ContentPage
    {
        

        ShowHallTicketViewModel ShowHallTicketViewModel;
        public ShowHallTicket(string _FileName)
        {
            InitializeComponent();
            ShowHallTicketViewModel = new ShowHallTicketViewModel(Navigation, _FileName);
            BindingContext = ShowHallTicketViewModel;
        }


        //String FileName;
        //public ShowHallTicket(string _FileName)
        //{
        //    InitializeComponent();      

        //    LoadHallTicket(_FileName);

        //}
        //public async Task LoadHallTicket(String _FileName)
        //{
        //    UserDialogs.Instance.ShowLoading("Loading HallTicket");
        //    var HallTicketPath = await DependencyService.Get<IS3ImageManager>().DownloadFile(_FileName, Constants.HallTicketBucket);
        //    PDFView.Uri = HallTicketPath;
        //    UserDialogs.Instance.HideLoading();

        //}
    }
}