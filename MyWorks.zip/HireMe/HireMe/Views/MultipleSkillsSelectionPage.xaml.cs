﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace HireMe.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MultipleSkillsSelectionPage : ContentPage
    {
        MultipleSkillsSelectionViewModel MultipleSkillsSelectionViewModel;

        public MultipleSkillsSelectionPage(string PageName, List<Skill> skills,string _skillType)
        {
            InitializeComponent();
            if (AppSessionData.ActiveToken.UserType == UserType.JobSeeker)
            {
                Title = "Select Skills (Max 10)";
            }
            MultipleSkillsSelectionViewModel = new MultipleSkillsSelectionViewModel(Navigation, PageName, skills, _skillType);
            BindingContext = MultipleSkillsSelectionViewModel;
        }



        void On_Toggled(object sender, ToggledEventArgs args)
        {
            MultipleSkillsSelectionViewModel.On_Toggled(sender, args);
        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            GC.Collect();
        }

        private void FlatEntry_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}