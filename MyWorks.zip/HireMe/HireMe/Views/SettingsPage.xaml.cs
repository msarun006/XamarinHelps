﻿using HireMe.ViewModels;
using Xamarin.Forms;

namespace HireMe
{
    public partial class SettingsPage : ContentPage
    {

        #region Main Constructor
        private SettingsPageViewModel ViewModel { get; set; }
        public SettingsPage()
        {
            InitializeComponent();
            ViewModel = new SettingsPageViewModel(Navigation);
            BindingContext = ViewModel;
        }
        #endregion

        #region Toggle Events Commands
        private void ToggleSwitchNotification(object sender, ToggledEventArgs e)
        {
            var switchtoggle = (Switch)sender;
            var switchclassid = switchtoggle.ClassId;     //Switch ToggleEvent Identified by ClassID
            ViewModel.TapCommand.Execute(switchclassid);  // Class ID send to Viewmodel to Execute Toggle Event
        }

        private void ToggleSwitchPasscode(object sender, ToggledEventArgs e)
        {
            var switchtoggle = (Switch)sender;
            var switchclassid = switchtoggle.ClassId;    //Switch ToggleEvent Identified by ClassID
            ViewModel.TapCommand.Execute(switchclassid);  // Class ID send to Viewmodel to Execute Toggle Event
        }
        #endregion
        protected override void OnAppearing()
        {
            System.Diagnostics.Debug.WriteLine("@ SeekerDashboardPage.OnAppearing");
            base.OnAppearing();

            if (ViewModel._isLocked == false)
                ViewModel. _isLocked = true;
            ViewModel.isToggled = AppPreferences.IsPasscode;
            ViewModel._initial = true;
            ViewModel.IsToggleSwitchPasscode = AppPreferences.IsPasscode;
            if (AppPreferences.IsPasscode)
            {
                ViewModel.IsVisibleChangePaascode = true;
            }
            else
            {
                ViewModel.IsVisibleChangePaascode = false;
            }
        }
    }
}
