﻿using System.Collections.Generic;
using Xamarin.Forms;

namespace HireMe
{

    public partial class MultipleLanguageSelectionPage : ContentPage
	{

		MultipleLanguageSelectionPageViewModel MultipleLanguageSelectionPageViewModel;
		public MultipleLanguageSelectionPage( List<Languageknown> languages,IValueGetter valuesgetter)
		{
			InitializeComponent();
			MultipleLanguageSelectionPageViewModel = new MultipleLanguageSelectionPageViewModel(Navigation, languages,valuesgetter);
			BindingContext = MultipleLanguageSelectionPageViewModel;
		}

		#region OnSkill_Toggled
		async void OnSkill_Toggled(object sender, ToggledEventArgs e)
		{
			MultipleLanguageSelectionPageViewModel.OnSkill_Toggled(sender, e);
		}
		#endregion

	}
}
