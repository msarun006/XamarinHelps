﻿
using Xamarin.Forms;

namespace HireMe
{
    public partial class FacebookLoginPage : ContentPage
    {
        public FacebookLoginPage()
        {
            NavigationPage.SetHasNavigationBar(this, false);
            InitializeComponent();
        }
    }
}
