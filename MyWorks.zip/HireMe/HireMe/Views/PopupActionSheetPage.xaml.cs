﻿using Rg.Plugins.Popup.Pages;
using Xamarin.Forms.Xaml;
using HireMe.ViewModels;

namespace HireMe.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PopupActionSheetPage : PopupPage
    {
        public PopupActionSheetPage(string pageName)
        {
            InitializeComponent();
            BindingContext = new ActionSheetPageViewModel(Navigation,pageName);

        }

      
        //protected override bool OnBackgroundClicked()
        //{
        //    //Return default value - CloseWhenBackgroundIsClicked
        //    return base.OnBackgroundClicked();
        //}
    }
}