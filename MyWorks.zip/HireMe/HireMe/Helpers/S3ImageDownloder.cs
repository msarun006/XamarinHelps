﻿using System;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace HireMe.Helpers
{
    public class S3ImageDownloder
    {
        public void DownloadProfilePicture(string S3ID)
        {
            try
            {
                if (AppPreferences.ProfilePicture != null && AppPreferences.ProfilePicture.Contains(S3ID) && DependencyService.Get<IThumbnailManager>().CheckFileExist(AppPreferences.ProfilePicture))
                {
                    var _ProfileImage = AppPreferences.ProfilePicture;
                    MessagingCenter.Send(this, "ChangeProfilePicture", _ProfileImage);
                }
                else
                {
                    if (!string.IsNullOrEmpty(S3ID) && S3ID != null)
                    {
                        var _ProfileImage = Task.Run(async () => { return await DependencyService.Get<IS3ImageManager>().DownloadFile(S3ID, AmazonS3BucketDetails.PhotoBucket); }).Result;
                        if (_ProfileImage != null)
                        {
                            if (DependencyService.Get<IThumbnailManager>().CheckFileExist(_ProfileImage))
                            {
                                if (_ProfileImage.Contains("png") || _ProfileImage.Contains("jpg"))
                                {
                                    AppPreferences.ProfilePicture = _ProfileImage;
                                }

                            }
                            MessagingCenter.Send(this, "ChangeProfilePicture", _ProfileImage);
                        }
                        else
                        {
                            AppPreferences.ProfilePicture = (string)Application.Current.Resources["IconUser"];
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                AppPreferences.ProfilePicture = (string)Application.Current.Resources["IconUser"];
                System.Diagnostics.Debug.WriteLine(ex.Message);
                //SendErrorMessageToServer(ex, "S3ImageDownloder.DownloadProfilePicture");
            }
        }

        public void DownloadProfilePicture(string S3ID,string strBucketName)
        {
            try
            {
                if (AppPreferences.ProfilePicture != null && AppPreferences.ProfilePicture.Contains(S3ID) && DependencyService.Get<IThumbnailManager>().CheckFileExist(AppPreferences.ProfilePicture))
                {
                    var _ProfileImage = AppPreferences.ProfilePicture;
                    MessagingCenter.Send(this, "ChangeProfilePicture", _ProfileImage);
                }
                else
                {
                    if (!string.IsNullOrEmpty(S3ID) && S3ID != null)
                    {
                        var _ProfileImage = Task.Run(async () => { return await DependencyService.Get<IS3ImageManager>().DownloadFile(S3ID, strBucketName); }).Result;
                        if (_ProfileImage != null)
                        {
                            if (DependencyService.Get<IThumbnailManager>().CheckFileExist(_ProfileImage))
                            {
                                if (_ProfileImage.Contains("png") || _ProfileImage.Contains("jpg"))
                                {
                                    AppPreferences.ProfilePicture = _ProfileImage;
                                }

                            }
                            MessagingCenter.Send(this, "ChangeProfilePicture", _ProfileImage);
                        }
                        else
                        {
                            AppPreferences.ProfilePicture = (string)Application.Current.Resources["IconUser"];
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                AppPreferences.ProfilePicture = (string)Application.Current.Resources["IconUser"];
                System.Diagnostics.Debug.WriteLine(ex.Message);
                //SendErrorMessageToServer(ex, "S3ImageDownloder.DownloadProfilePicture");
            }
        }

        public string DownloadS3Image(string S3ID, string strBucketName)
        {
            string ImageURL = string.Empty;
            try
            {
                    if (!string.IsNullOrEmpty(S3ID) && S3ID != null)
                    {
                        var _downloadedFile = Task.Run(async () => { return await DependencyService.Get<IS3ImageManager>().DownloadFile(S3ID, strBucketName); }).Result;
                        if (_downloadedFile != null)
                        {
                            if (DependencyService.Get<IThumbnailManager>().CheckFileExist(_downloadedFile))
                            {
                                if (_downloadedFile.Contains("png") || _downloadedFile.Contains("jpg"))
                                {
                                    ImageURL = _downloadedFile;
                                }
                            }
                        }
                    }

            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                //SendErrorMessageToServer(ex, "S3ImageDownloder.DownloadProfilePicture");
            }
            return ImageURL;
        }

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
