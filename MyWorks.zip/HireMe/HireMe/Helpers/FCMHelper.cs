﻿using Acr.UserDialogs;
using HireMe.Models;
using System.Threading.Tasks;
using Xamarin.Forms;
using System;

namespace HireMe.Helpers
{
    public class FCMHelper
    {
        public async Task RegisterFirebaseToken()
        {
            try
            {
                string registerToken = await DependencyService.Get<IPushNotificationRegister>().ExtractTokenAndRegister();
                if (registerToken != null)
                {
                    AppPreferences.IsNotificationEnabled = true;

                    HttpCommonService _commonservice = new HttpCommonService();
                    FirebaseMessagingRequestData objRequestData = new FirebaseMessagingRequestData();
                    objRequestData.FirebaseToken = registerToken;
                    var result = await _commonservice.PostAsync<FirebaseMessagingResponseData, FirebaseMessagingRequestData>(APIData.API_BASE_URL + APIMethods.FirebaseUpdate, objRequestData);

                }
                UserDialogs.Instance.HideLoading();
                //if (result != null)
                //{
                // UserDialogs.Instance.Alert("Notification Enabled");
                //}
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "FCMHelper.RegisterFirebaseToken");
            }

        }





        public async Task UnRegisterFirebaseToken()
        {
            try
            {
                HttpCommonService _commonservice = new HttpCommonService();
                FirebaseMessagingUnRegisterRequestData objRequestData = new FirebaseMessagingUnRegisterRequestData();
                AppPreferences.IsNotificationEnabled = false;
                var result = await _commonservice.PostAsync<FirebaseMessagingUnRegisterResponseData, FirebaseMessagingUnRegisterRequestData>(APIData.API_BASE_URL + APIMethods.FirebaseRemove, objRequestData);
                UserDialogs.Instance.HideLoading();
                //if (result != null)
                //{
                //    //UserDialogs.Instance.Alert("Notification Disabled");
                //}
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "FCMHelper.UnRegisterFirebaseToken");
            }
        }


        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
