﻿using HireMe.Models;
using Plugin.Connectivity;
using System;
using Xamarin.Forms;

namespace HireMe.Helpers
{
    public class CommonException
    {
        public async void CallCommonException(Exception ex, String PageNameAndFunctionName)
        {
            try
            {
                string innerexception;
                string source;
                string stacktrace;

                if (ex.Source == null)
                {
                    source = string.Empty;
                }
                else
                {
                    source = ex.Source;
                }

                if (ex.StackTrace == null)
                {
                    stacktrace = string.Empty;
                }
                else
                {
                    stacktrace = ex.StackTrace;
                }

                if (ex.InnerException == null)
                {
                    innerexception = string.Empty;
                }
                else
                {
                    innerexception = ex.InnerException.ToString();
                }


                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {
                    ExceptionRequestData _exRequestdata = new ExceptionRequestData();
                    var HireMeeID = AppPreferences.LoadSeekerDashboardData.ProfileDetails.HireMeeID;
                    var Version = DependencyService.Get<IPackageInfo>().VersionName;
                    var MobileVersion = DependencyService.Get<IMyDevice>().GetDeviceVersion() ?? string.Empty;
                    var Platform = Device.RuntimePlatform;
                    var DeviceModel = Utilities.GetDeviceModel();
                    if(AppPreferences.Is_HireMee_PRO_User == true)
                    {
                        _exRequestdata.Message = "HireMeePro " +  APIData.CommonExceptionURL_Name + " Version: " + Version + " TestPin: " + AppPreferences.TestPinMasterData.testpin + " Platform:" + Platform + "-" + MobileVersion + " DeviceModel:" + DeviceModel + " PageName & FunctionName:----->" + PageNameAndFunctionName + " ErrorMessage:------->" + ex.Message;
                    }
                    else
                    {
                        _exRequestdata.Message = "HireMee " + APIData.CommonExceptionURL_Name + " Version: " + Version + " HireMeeID: " + HireMeeID + " Platform:" + Platform + "-" + MobileVersion + " DeviceModel:" + DeviceModel + " PageName & FunctionName:----->" + PageNameAndFunctionName + " ErrorMessage:------->" + ex.Message;
                    }
                    _exRequestdata.StackTrace = stacktrace;
                    _exRequestdata.Source = source;
                    _exRequestdata.InnerException = innerexception;
                    HttpCommonService _commonservice = new HttpCommonService();
                    var result = await _commonservice.PostAsync<ExceptionResponseData, ExceptionRequestData>(APIData.API_BASE_URL + APIMethods.UpdateCrashReport, _exRequestdata);
                }
            }
            catch (Exception exception)
            {
                System.Diagnostics.Debug.WriteLine(exception.Message);
            }
        }
    }
}
