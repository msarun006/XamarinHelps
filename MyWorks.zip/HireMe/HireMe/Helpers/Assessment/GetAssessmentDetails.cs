﻿using Acr.UserDialogs;
using HireMe.Interface;
using HireMe.LocalDataBase;
using HireMe.Models.Assessment;
using HireMe.Views.Assessment;
using HireMe.Views.JobSeeker;
using Plugin.Connectivity;
using System;
using System.Linq;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace HireMe.Helpers.Assessment
{
    public class GetAssessmentDetails
    {
        private string limit;
        public LocalDB _localDB { get; set; }
        SqliteOperations sqliteOperations;
        private HttpCommonService _commonservice { get; set; }
        public GetAssessmentDetails()
        {
            _commonservice = new HttpCommonService();
            sqliteOperations = new SqliteOperations();
            _localDB = new LocalDB();
        }
        #region Assessment API Call
        public async void AssessmentLoginAPI()
        {
            try
            {
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;

                if (isNetworkAvailable)
                {
                    UserDialogs.Instance.ShowLoading();
                    var loginRequest = new LoginModel();
                    loginRequest.Username = AppSessionData.ActiveToken.HireMeID;
                    loginRequest.DeviceID = DependencyService.Get<IMyDevice>().GetDeviceID() ?? string.Empty;
                    loginRequest.DeviceOS = DependencyService.Get<IMyDevice>().GetDeviceType() ?? string.Empty;
                    loginRequest.DeviceModel = DependencyService.Get<IMyDevice>().GetDeviceModel() ?? string.Empty;
                    loginRequest.DeviceBrand = DependencyService.Get<IMyDevice>().GetDeviceModel() ?? string.Empty;
                    loginRequest.DeviceOSVersion = DependencyService.Get<IMyDevice>().GetDeviceVersion() ?? string.Empty;

                    var result = await _commonservice.PostAsync<LoginResponse, LoginModel>(APIData.API_BASE_URL + APIMethods.GetExamDetails, loginRequest);
                    UserDialogs.Instance.HideLoading();
                    if (result != null)
                    {
                        if (result.code == "200")
                        {
                            if (AppPreferences.HireMeeID == result.CandidateDetails.HireMeeID && AppPreferences.ExamID == result.ExamDetails.ExamID)
                            {
                                MessageStringConstants.IsSameUser = true;
                                await CallExamSelectionPageAsync(result);
                            }
                            else
                            {
                                MessageStringConstants.IsSameUser = false;
                                await CheckExistingDataIsAvailabe(result);
                            }
                        }
                        else if (result.code == "203")
                        {

                            if (result.ExamDetails != null)
                            {
                                if (DependencyService.Get<IMyDevice>().GetDeviceID() == result.ExamDetails.DeviceID)
                                {
                                    if (_localDB.TableExists("AssignedExamModel"))
                                    {
                                        var res = _localDB.GetAllAssignedExamData();
                                        if (res.Status == "C")
                                        {
                                            Application.Current.MainPage = new NavigationPage(new ManualDataSyncupPage());
                                            return;
                                        }
                                    }
                                }
                                else if (result.CandidateDetails != null)
                                {
                                    //if (!string.IsNullOrEmpty(AppPreferences.HireMeeID))
                                    //{
                                    if (AppPreferences.HireMeeID == result.CandidateDetails.HireMeeID && AppPreferences.ExamID == result.ExamDetails.ExamID)
                                    {
                                        MessageStringConstants.IsSameUser = true;
                                    }
                                    else
                                    {
                                        MessageStringConstants.IsSameUser = false;
                                    }
                                    //}
                                    //else
                                    //{
                                    //    MessageStringConstants.IsSameUser = false;
                                    //}
                                    UserDialogs.Instance.HideLoading();
                                    await UserDialogs.Instance.AlertAsync(result.message);
                                    Application.Current.MainPage = new InvigilatorLoginPage();
                                    return;
                                }
                                else
                                {
                                    await UserDialogs.Instance.AlertAsync(result.message);
                                }
                            }
                            else
                            {
                                await UserDialogs.Instance.AlertAsync(result.message);
                            }
                        }
                        else
                        {

                            SqliteOperations sqliteOperations = new SqliteOperations();
                            if (!sqliteOperations.CheckIfAnySyncupDataIsAvailable())
                            {
                                Clear();
                                sqliteOperations.DeleteAllLocalRecords();
                                DependencyService.Get<Interface.ISyncDataWhileInternetAvailable>().IStopAlarmService();
                            }
                            else
                            {
                                if (_localDB.TableExists("AssignedExamModel"))
                                {
                                    var res = _localDB.GetAllAssignedExamData();
                                    if (res.Status == "C")
                                    {
                                        Application.Current.MainPage = new NavigationPage(new ManualDataSyncupPage());
                                        return;
                                    }
                                }
                                //Device.BeginInvokeOnMainThread(async () =>
                                //{
                                //    await sqliteOperations.BulkInsert("Auto");
                                //});
                            }

                            UserDialogs.Instance.HideLoading();
                            await UserDialogs.Instance.AlertAsync(result.message);
                        }
                    }
                    else
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.ServerBusyMessage);
                    }
                }
                else
                {
                    UserDialogs.Instance.HideLoading();
                    UserDialogs.Instance.Alert(MessageStringConstants.CheckInternetConnection);
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "GetAssessmentDetails.AssessmentLoginAPI");
            }
        }
        #endregion
        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
        #region CallExamSelectionPageAsync
        public async Task CallExamSelectionPageAsync(LoginResponse result)
        {
            try
            {


                //AppPreferences.AccessToken = result.AccessToken ?? string.Empty;
                AppPreferences.NoofAttempts = result.NoofAttempts ?? string.Empty;
                AppPreferences.BatteryLevel = result.BatteryLevel ?? string.Empty;
                AppPreferences.AutoID = result.CandidateDetails.AutoID ?? string.Empty;
                AppPreferences.HireMeeID = result.CandidateDetails.HireMeeID ?? string.Empty;
                AppPreferences.userName = result.CandidateDetails.CandidateName ?? string.Empty;
                AppPreferences.NoOfQuestions = result.ExamDetails.TotalNoOfQuestions ?? string.Empty;
                AppPreferences.PreferredLanguageCount = result.AvailableLanguages.Count().ToString();
                AppSessionData.AvailableLanguage = result.AvailableLanguages;

                AppPreferences.ImageCapturingTimeInterval = Constant.BeginFifteenMinutesImageCaptureTimeDuration.ToString();
                AppPreferences.ExamMinute = "0";


                if (result.ExamDetails != null && result.ExamDetails != null)
                {
                    AppPreferences.ExamMode = result.ExamDetails.IsAutoProctored ?? string.Empty;
                    AppPreferences.AssignedID = result.ExamDetails.AssignedID ?? string.Empty;
                    AppPreferences.ExamID = result.ExamDetails.ExamID ?? string.Empty;
                    AppPreferences.ExamName = result.ExamDetails.ExamName ?? string.Empty;
                    AppPreferences.ExamInstruction = result.ExamDetails.ExamInstruction ?? string.Empty;
                    AppPreferences.DeviceId = result.ExamDetails.DeviceID ?? string.Empty;
                    TimeSpan ExamDuration = TimeSpan.FromMinutes(int.Parse(result.ExamDetails.Duration)); ;
                    AppPreferences.ExamDurationHour = ExamDuration.Hours.ToString();
                    AppPreferences.ExamDurationMinute = ExamDuration.Minutes.ToString();
                    AppPreferences.ServerDate = result.ExamDetails.ServerTime.Date.ToString("yyyy-MM-dd");
                    AppPreferences.ServerUpdatedDateTime = result.ExamDetails.ServerTime.Date.ToString();
                    int ServerTime = result.ExamDetails.ServerTime.TimeOfDay.Hours;
                    limit = (1 + Int32.Parse(result.ExamDetails.NoOfAttempt)).ToString();
                    //Same User Used Same Device ID 
                    if (DependencyService.Get<IMyDevice>().GetDeviceID() != result.ExamDetails.DeviceID && limit != "1")
                    {
                        if (AppPreferences.IsHindi)
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.DeviceIDNotMatchHindi, null, MessageStringConstants.OKHindi);
                        }
                        else
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.DeviceIDNotMatch);
                        }
                        return;
                    }
                    else
                    {


                        //Same User Exam Completed But Data Not Upload to Server, This Scenario Worked at Offline and Clicked  Notification IOS Only. 
                        if (_localDB.TableExists("AssignedExamModel"))
                        {



                            var res = _localDB.GetAllAssignedExamData();
                            //User already login, User is Proctored Candidate
                            if (result.ExamDetails.LoginStatus.Equals("DEACTIVE") && result.ExamDetails.IsAutoProctored.Equals("False"))
                            {
                                if (res != null)
                                {
                                    if (res.Status == "C")
                                    {
                                        Application.Current.MainPage = new NavigationPage(new ManualDataSyncupPage());
                                        return;
                                    }
                                    else
                                    {
                                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.InvigilatorMessage);
                                        Application.Current.MainPage = new InvigilatorLoginPage();
                                        return;
                                    }
                                }
                                else
                                {
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.InvigilatorMessage);
                                    Application.Current.MainPage = new InvigilatorLoginPage();
                                    return;
                                }
                            }
                            else if (res != null && result.ExamDetails.IsAutoProctored.Equals("True"))
                            {
                                if (res.Status == "C" || AppPreferences.AssignedID != res.AssignedID)
                                {
                                    if (!sqliteOperations.CheckIfAnySyncupDataIsAvailable())
                                    {
                                        _localDB.DeleteAllTables();
                                        DependencyService.Get<ISyncDataWhileInternetAvailable>().IStopAlarmService();
                                    }
                                    else
                                    {
                                        Application.Current.MainPage = new NavigationPage(new ManualDataSyncupPage());
                                        return;
                                    }
                                }
                            }
                        }
                        else
                        {
                            _localDB.CreateTables();
                        }
                    }
                    limit = (1 + Int32.Parse(result.ExamDetails.NoOfAttempt)).ToString();

                    if (result.ExamDetails.IsAutoProctored.Equals("True"))
                    {
                        if (int.Parse(AppPreferences.PreferredLanguageCount) <= 1)
                        {
                            foreach (var item in AppSessionData.AvailableLanguage)
                            {
                                if (item.LanguageName == "Hindi")
                                {
                                    AppPreferences.SelectedlanguageID = item.LanguageId;
                                    AppPreferences.IsEnglish = false;
                                    AppPreferences.IsHindi = true;
                                    DependencyService.Get<ILocalize>().ChangeLocale("hi");
                                    App.CultureCode = "hi";
                                }
                                else //if (item.LanguageName == "English")
                                {
                                    AppPreferences.SelectedlanguageID = item.LanguageId;
                                    AppPreferences.IsEnglish = true;
                                    AppPreferences.IsHindi = false;
                                    DependencyService.Get<ILocalize>().ChangeLocale("en");
                                    App.CultureCode = "en";
                                }

                            }
                            if (Int32.Parse(limit) == 1)
                            {
                                Application.Current.MainPage = new NavigationPage(new ExamInstruction_Page());
                                return;
                            }

                        }
                        else if (!AppPreferences.IsHindi && !AppPreferences.IsEnglish)
                        {
                            Application.Current.MainPage = new NavigationPage(new AssessmentLanguageSelection());
                            return;
                        }
                        //User is AutoProctored Candidate, User allow to login only three times. This User No Invigilator Login
                        if (!string.IsNullOrEmpty(limit) && Int32.Parse(limit) <= Int32.Parse(result.NoofAttempts))
                        {
                            //  if (Int32.Parse(limit) <= Models.Assessment.Constants.NoOfAttempts)
                            if (int.Parse(limit) == int.Parse(result.NoofAttempts))
                            {
                                if (AppPreferences.IsHindi)
                                {
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.LastAttemptHindi, null, MessageStringConstants.OKHindi);
                                }
                                else
                                {
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.LastAttempt);
                                }
                            }
                            else
                            {
                                if (AppPreferences.IsHindi)
                                {
                                    await UserDialogs.Instance.AlertAsync("अधिकतम " + result.NoofAttempts + " में से यह प्रयास " + limit + " है", null, MessageStringConstants.OKHindi);
                                }
                                else
                                {
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.Remaining + limit + MessageStringConstants.Attempt + result.NoofAttempts);
                                }

                            }
                            if (AppPreferences.IsEnglish == true)
                            {
                                DependencyService.Get<ILocalize>().ChangeLocale("en");
                                App.CultureCode = "en";
                            }
                            else if (AppPreferences.IsHindi == true)
                            {
                                DependencyService.Get<ILocalize>().ChangeLocale("hi");
                                App.CultureCode = "hi";
                            }
                            else
                            {
                                DependencyService.Get<ILocalize>().SetLocale();
                                App.CultureCode = "en";
                            }
                            Application.Current.MainPage = new NavigationPage(new ExternalDeviceStatusPage());

                        }
                        else
                        {
                            await UserDialogs.Instance.AlertAsync(MessageStringConstants.MaximumReached);
                        }
                    }



                }
                else
                {
                    if (AppPreferences.IsHindi)
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.DeviceIDNotMatchHindi, null, MessageStringConstants.OKHindi);
                    }
                    else
                    {
                        await UserDialogs.Instance.AlertAsync(MessageStringConstants.DeviceIDNotMatch);
                    }
                }
            }
            catch (Exception ex)
            {
                SendErrorMessageToServer(ex, "GetAssessmentDetails.CallExamSelectionPageAsync");
            }
        }
        #endregion

        #region CheckExistingDataIsAvailabe
        public async Task CheckExistingDataIsAvailabe(LoginResponse result)
        {
            SqliteOperations sqliteOperations = new SqliteOperations();

            bool checkExistingData = sqliteOperations.CheckIfAnySyncupDataIsAvailable();
            if (!checkExistingData)
            {
                Clear();
                sqliteOperations.DeleteAllLocalRecords();
                DependencyService.Get<Interface.ISyncDataWhileInternetAvailable>().IStopAlarmService();
                await CallExamSelectionPageAsync(result);
            }
            else
            {
                Device.BeginInvokeOnMainThread(async () =>
                {
                    await sqliteOperations.BulkInsert("Auto");
                });
            }
        }
        #endregion

        #region Clear
        public void Clear()
        {
           // AppPreferences.AccessToken = string.Empty;
            AppPreferences.AutoID = string.Empty;
            AppPreferences.ExamID = string.Empty;
            AppPreferences.ExamName = string.Empty;
            AppPreferences.ExamCenterName = string.Empty;
            AppPreferences.AssignedID = string.Empty;
            //AppPreferences.AppCurrentState = string.Empty;
            //AppPreferences.AppOwnTimer = string.Empty;
            AppPreferences.GroupDetailsSerialize = string.Empty;
            AppPreferences.ExamDuration = string.Empty;
            AppPreferences.NoOfQuestions = string.Empty;
            AppPreferences.ServerDateTime = string.Empty;
            AppPreferences.ExamTime = string.Empty;
            AppPreferences.ExamMode = string.Empty;
            //AppPreferences.UserAttemptCount = string.Empty;
            AppPreferences.HintStack = string.Empty;
        }
        #endregion
    }
}
