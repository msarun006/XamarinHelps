﻿using PCLStorage;
using System;
using System.Diagnostics;
using System.Net.Http;
using System.Threading.Tasks;

namespace HireMe.Helpers.Assessment
{
    public static class PCLStorageMethod
    {
   
        private const string subFolderName = "Questions";
        public static async Task<string> DownloadQuestionImage(string Url)
        {
          //  DependencyService.Get<IMyDevice>().DownloadImageToGallery(Url);

            string LocalPath = string.Empty;
            try
            {
                Uri url = new Uri(Url);
                var client = new HttpClient();
                byte[] dataBuffer;
                // string fileName = System.IO.Path.GetFileName("@" + Url);

                string extension = System.IO.Path.GetExtension(Url);
                string fileName = DateTime.Now.ToString("yyyyMMddHHmmssfff")+extension;


                IFolder rootfolder = FileSystem.Current.LocalStorage;
                //IFolder appfolder = await rootfolder.CreateFolderAsync(subFolderName, CreationCollisionOption.OpenIfExists);
                IFile file = await rootfolder.CreateFileAsync(fileName, CreationCollisionOption.ReplaceExisting);
                using (var fileHandler = await file.OpenAsync(FileAccess.ReadAndWrite))
                {
                    var httpResponse = await client.GetAsync(url);
                      dataBuffer = await httpResponse.Content.ReadAsByteArrayAsync();
                    await fileHandler.WriteAsync(dataBuffer, 0, dataBuffer.Length);
                }


                LocalPath = file.Path;


            }
            catch (Exception ex)
            {
                Debug.WriteLine("-------------------------------------------->"+ex.Message);
                SendErrorMessageToServer(ex, "PCLStorageMethod.DownloadQuestionImage");
            }
            return LocalPath;
        }



        #region SendErrorMessageToServer
        public  static void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion

        //public static async Task<byte[]> LoadImage(this byte[] image, String fileName, IFolder rootFolder = null)
        //{
        //    // get hold of the file system  
        //    IFolder folder = rootFolder ?? FileSystem.Current.LocalStorage;

        //    //open file if exists  
        //    IFile file = await folder.GetFileAsync(fileName);
        //    //load stream to buffer  
        //    using (System.IO.Stream stream = await file.OpenAsync(FileAccess.ReadAndWrite))
        //    {
        //        long length = stream.Length;
        //        byte[] streamBuffer = new byte[length];
        //        stream.Read(streamBuffer, 0, (int)length);
        //        return streamBuffer;
        //    }

        //}




        //public static async Task SaveImage(this byte[] image, String fileName, IFolder rootFolder = null)
        //{

        //    try
        //    {
        //        // get hold of the file system  
        //        IFolder folder = rootFolder ?? FileSystem.Current.LocalStorage;

        //        // create a file, overwriting any existing file  
        //        IFile file = await folder.CreateFileAsync(fileName, CreationCollisionOption.ReplaceExisting);

        //        // populate the file with image data  
        //        using (System.IO.Stream stream = await file.OpenAsync(FileAccess.ReadAndWrite))
        //        {
        //            stream.Write(image, 0, image.Length);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Debug.WriteLine(ex.Message);
        //    }


        //}









    }
}
