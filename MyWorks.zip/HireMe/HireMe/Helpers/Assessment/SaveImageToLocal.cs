﻿using Plugin.Connectivity;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace HireMe.Helpers.Assessment
{
    public class SaveImageToLocal
    {
        public SaveImageToLocal()
        {

        }
        public string SaveImageData(string HTMLInput)
        {

            string LocalImagePath = string.Empty;

            // Match the  RegularExpression of Image URL
            string ImageUrlREGX = "(?im)(?:(?:(?:href)|(?:src))[ ]*?=[ ]*?[\"'])(((?:http|https)(?::\\/{2}[\\w]+)(?:[\\/|\\.]?)(?:[^\\s\"]*))|((?:\\/{0,1}[\\w\\.]+)+))[\"']";
            Regex r = new Regex(ImageUrlREGX, RegexOptions.IgnoreCase);
            Match matchedItems = r.Match(HTMLInput);


            // Instantiate the regular expression object.


            if (matchedItems.Success)
            {
                //Get Image URL & Save to Local Folder
                string MatchedValue = matchedItems.Groups[2].ToString();
                string ImageURL = MatchedValue;
                bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                if (isNetworkAvailable)
                {
                    if ((ImageURL.Contains(".jpg") || ImageURL.Contains(".jpeg") || ImageURL.Contains(".png")))
                    {
                        LocalImagePath = Task.Run(async () =>
                       {

                           return await PCLStorageMethod.DownloadQuestionImage(ImageURL);

                           // return await DependencyService.Get<IDownloadManager>().DownloadFile(ImageURL);
                       }).Result;
                    }
                }
                if ((LocalImagePath.Contains(".jpg") || LocalImagePath.Contains(".jpeg") || LocalImagePath.Contains(".png")))
                {
                    HTMLInput = Regex.Replace(HTMLInput, MatchedValue, LocalImagePath);
                }
            }

            return HTMLInput;
        }
    }
}
