﻿using Acr.UserDialogs;
using HireMe.Models.PRO_Assessment;
using HireMe.Views.PRO_Assessment;
using Plugin.Connectivity;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace HireMe.Helpers.PRO_Assement
{
    public class PRO_CommonLog
    {
       

        public async void NavigationLog(string value)
        {
            try
            {

                if ((AppPreferences.TestPinMasterData.testpin !=null) &&
                    (AppPreferences.TestPinMasterData.company_id != null) &&
                    (AppPreferences.TestPinMasterData.assign_id != null) &&
                    (AppPreferences.TestPinMasterData.login_audit_id != null))
                {

                    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                    if (isNetworkAvailable)
                    {
                        Navigation_LogRequestData _logRequestdata = new Navigation_LogRequestData();
                        HttpCommonService _commonservice = new HttpCommonService();
                        _logRequestdata.testpin = AppPreferences.TestPinMasterData.testpin;
                        _logRequestdata.company_id = AppPreferences.TestPinMasterData.company_id;
                        _logRequestdata.assign_id = AppPreferences.TestPinMasterData.assign_id;
                        _logRequestdata.Login_audit_id = AppPreferences.TestPinMasterData.login_audit_id;
                        _logRequestdata.navigation_mode = value;


                        var result = await _commonservice.PostAsync<LogResponseData, Navigation_LogRequestData>(APIData.API_BASE_URL + APIMethods.Navigationlog, _logRequestdata);
                        if (result !=null)
                        {
                            Debug.WriteLine(result.code + result.message);
                            if(result.code == "200")
                            {
                                if (result.actual_no_of_retries > result.total_no_of_retries && value == "1")
                                {
                                    await UserDialogs.Instance.AlertAsync(MessageStringConstants.NoofRtries);
                                    Application.Current.MainPage = new NavigationPage(new PRO_TestPinPage());
                                }
                            }
                            else if (result.code == "199")
                            {
                                await UserDialogs.Instance.AlertAsync(result.message);
                                Application.Current.MainPage = new NavigationPage(new PRO_TestPinPage());
                            }
                        }
                       
                    }
                }
              
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "HireMe.Helpers.PRO_Assement.PRO_CommonLog.NavigationLog");
            }

        }


     



        public async void ImageProctored_Log(string S3_ID, string TrainingImageStatus)
        {
            try
            {

                if ((AppPreferences.TestPinMasterData.testpin != null) &&
                   (AppPreferences.TestPinMasterData.company_id != null) &&
                   (AppPreferences.TestPinMasterData.assign_id != null) &&
                    (AppPreferences.TestPinMasterData.candidate_id != null) &&
                   (AppPreferences.TestPinMasterData.login_audit_id != null))
                {

                    bool isNetworkAvailable = CrossConnectivity.Current.IsConnected;
                    if (isNetworkAvailable)
                    {
                        HttpCommonService _commonservice = new HttpCommonService();
                        ImageProctored_LogRequestData _logRequestdata = new ImageProctored_LogRequestData();
                        _logRequestdata.s3_id = S3_ID;
                        _logRequestdata.is_trainingimage = TrainingImageStatus;
                        _logRequestdata.testpin = AppPreferences.TestPinMasterData.testpin;
                        _logRequestdata.company_id = AppPreferences.TestPinMasterData.company_id;
                        _logRequestdata.assign_id = AppPreferences.TestPinMasterData.assign_id;
                        _logRequestdata.login_audit_id = AppPreferences.TestPinMasterData.login_audit_id;
                        _logRequestdata.candidate_id = AppPreferences.TestPinMasterData.candidate_id;
                        var result = await _commonservice.PostAsync<LogResponseData, ImageProctored_LogRequestData>(APIData.API_BASE_URL + APIMethods.ImageProctoredlog, _logRequestdata);
                        if (result != null)
                        {
                            // Debug.WriteLine(result.code + result.message);
                            if (result.code == "200")
                            {
                                //if (TrainingImageStatus == Constant.CapturedTrainingImageStatus)
                                //{
                                //    Application.Current.MainPage = new NavigationPage(new PRO_AssessmentPage());
                                //}
                            }
                            else if (result.code == "199")
                            {
                                await UserDialogs.Instance.AlertAsync(result.message);
                                Application.Current.MainPage = new NavigationPage(new PRO_TestPinPage());
                            }
                        }
                        else
                        {

                        }
                    }
                }


            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "HireMe.Helpers.PRO_Assement.PRO_CommonLog.ImageProctored_Log");
            }
        }

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
