﻿using System;
using System.Threading.Tasks;
using GalaSoft.MvvmLight.Views;
using Xamarin.Forms;

namespace HireMe
{
	public class DialogService : IDialogService
	{
		private Page _dialogPage;

		public void Initialize(Page dialogPage)
		{
            
			_dialogPage = dialogPage;
		}

		public async Task ShowError(string message, string title, string buttonText, Action afterHideCallback)
		{
			await _dialogPage.DisplayAlert(
				title,
				message,
				buttonText);

			if (afterHideCallback != null)
			{
				afterHideCallback();
			}
		}

		public async Task ShowError(Exception error, string title, string buttonText, Action afterHideCallback)
		{
			await _dialogPage.DisplayAlert(
				title,
				error.Message,
				buttonText);

			if (afterHideCallback != null)
			{
				afterHideCallback();
			}
		}

		public async Task ShowMessage(string message, string title)
		{
			await _dialogPage.DisplayAlert(
				title,
				message,
				"OK");
		}

		public async Task ShowMessage(string message, string title, string buttonText, Action afterHideCallback)
		{
			await _dialogPage.DisplayAlert(
				title,
				message,
				buttonText);

			if (afterHideCallback != null)
			{
				afterHideCallback();
			}
		}

		public async Task<bool> ShowMessage(string message, string title, string buttonConfirmText, string buttonCancelText, Action<bool> afterHideCallback)
		{
			var result = await _dialogPage.DisplayAlert(
				title,
				message,
				buttonConfirmText,
				buttonCancelText);

			if (afterHideCallback != null)
			{
				afterHideCallback(result);
			}

			return result;
		}

		public async Task ShowMessageBox(string message, string title)
		{
			await _dialogPage.DisplayAlert(
				title,
				message,
				"OK");
		}

		public void ShowAlert(string message)
		{
			Device.BeginInvokeOnMainThread(async () =>
			{
				await _dialogPage.DisplayAlert(
				"HireMee",
				message,
				"OK");
			});

		}
        public void ShowAlertMessage(string title,string message)
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                await _dialogPage.DisplayAlert(
               title,
                message,
                "OK");
            });

        }

        public async Task<bool> ShowAlertOKCancel(string message)
		{
			var Status = false;
			Status = await _dialogPage.DisplayAlert(
				"HireMee",
				message,
				"OK", "Cancel");
			return Status;
		}

		public async Task<string> ShowActionSheet()
		{
			var action = await _dialogPage.DisplayActionSheet("HireMee", "Cancel", null, "Camera", "Pick from Gallery");
			return action;
		}
        public  Task<string> ShowInputActionSheet()
        {
            var action =  _dialogPage.DisplayActionSheet("HireMee Login", "Cancel", null, "Seeker", "Recruiter");
            return action;
        }
    }
}
