﻿using Acr.UserDialogs;
using HireMe.LocalDataBase;
using HireMe.Models;
using System;
using Xamarin.Forms;

namespace HireMe.Helpers
{
    public class CommonLoginResponse
    {
        public LocalDB _localDB { get; set; }
        public CheckVersionUpdates _CheckVersionUpdates { get; set; }
        public CommonLoginResponse()
        {
            _localDB = new LocalDB();
            _CheckVersionUpdates = new CheckVersionUpdates();
        }
        public async void NavigateToNextPage(LoginResponseData result)
        {
            try
            {
                #region Response Data

                //CheckVersionUpdates _CheckVersionUpdates = new CheckVersionUpdates();               
                    _CheckVersionUpdates.CheckVersion(result.apiVersionCheck);
                
                if (AppPreferences.OldVersion == false)
                {

                //#region VersionCheck
                //if (result.apiVersionCheck != null)
                //{
                //    if (Device.RuntimePlatform == Device.iOS)
                //    {
                //        var installedIOSVersionName = Convert.ToDouble(DependencyService.Get<IPackageInfo>().VersionName);
                //        var LatestIOSName = Convert.ToDouble(result.apiVersionCheck.ioS_VersionCode);
                //        //if iOS mean check with version name
                //        if (installedIOSVersionName < LatestIOSName)
                //        {
                //            String message = MessageStringConstants.UpdateLatestVersion;
                //            await UserDialogs.Instance.AlertAsync(message);
                //            DependencyService.Get<IMyDevice>().OpnePlayStore();
                //        }
                //    }
                //    else if (Device.RuntimePlatform == Device.Android)
                //    {
                //        var installedAndroidVersionCode = Convert.ToDouble(DependencyService.Get<IPackageInfo>().VersionCode);
                //        var LatestVersionCode = Convert.ToDouble(result.apiVersionCheck.android_VersionCode);
                //        //android mean check with version code
                //        if (installedAndroidVersionCode < LatestVersionCode)
                //        {
                //            String message = MessageStringConstants.UpdateLatestVersion;
                //            await UserDialogs.Instance.AlertAsync(message);
                //            DependencyService.Get<IMyDevice>().OpnePlayStore();
                //        }
                //    }
                //} 
                //#endregion


                AppPreferences.LoadSeekerDashboardData = null;
                AppPreferences.IsSeekerDashboardDataDownloaded = false;
                AppPreferences.Is_HireMee_PRO_User = false;
                var token = new ApplicationToken()
                {
                    Token = result.TokenID,
                    HireMeID = result.HireMeID,
                    Expire = DateTime.Now.AddSeconds(Convert.ToDouble(result.TokenExpiry)),
                    RefreshToken = result.Refreshtoken,
                    UserType = result.UserType,
                    EmailID = result.EmailAddress,
                    MobileNo = result.MobileNo,
                    SocialLoginPasswordStatus = result.SocialLoginPasswordStatus,
                    UserName = result.user_name
                };

                if (_localDB.TableExists("AssignedExamModel"))
                {
                    SqliteOperations sqliteOperations = new SqliteOperations();
                    var res = _localDB.GetAllAssignedExamData();
                    var dataIsSyncup = sqliteOperations.CheckIfAnySyncupDataIsAvailable();
                    //User already login, User is Proctored Candidate

                    if (res != null && res.Status == "C" && dataIsSyncup == true)
                    {
                        Device.BeginInvokeOnMainThread(async () =>
                        {
                            await sqliteOperations.BulkInsert("Auto");
                        });
                    }
                    else if (AppSessionData.ActiveToken.HireMeID != token.HireMeID)
                    {
                        AppPreferences.IsHindi = false;
                        AppPreferences.IsEnglish = false;
                        //Need to check is all record sync with server
                        if (dataIsSyncup)
                        {
                            Device.BeginInvokeOnMainThread(async () =>
                            {
                                await sqliteOperations.BulkInsert("Auto");
                            });
                        }
                    }
                }
                AppSessionData.ActiveToken = token;
                AppPreferences.userName = result.user_name;
                AppPreferences.EmailAddress = result.EmailAddress;
                AppPreferences.HireMeeID = result.HireMeID;
                AppPreferences.S3AccessKeyID = result.Userresourcecredential.s3accesskeyid;
                AppPreferences.S3SecretAccessKey = result.Userresourcecredential.s3secretaccesskey;
                if (!string.IsNullOrEmpty(result.s3_id))
                {
                    BindProfilePic(result.s3_id);
                }

               // await _FCMHelper.RegisterFirebaseToken();

                AppPreferences.IsLoggeedIn = true;
                AppPreferences.IsvalidURI = APIData.API_BASE_URL;
                if (AppSessionData.ActiveToken.UserType == UserType.Recruiter)
                {
                    AppPreferences.IsFirstRun = false;
                    AppPreferences.IsCollege = false;
                    UserDialogs.Instance.HideLoading();
                    Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                    return;
                }
                else if (AppSessionData.ActiveToken.UserType == UserType.College)
                {
                    AppPreferences.IsFirstRun = false;
                    AppPreferences.IsCollege = true;
                    UserDialogs.Instance.HideLoading();
                    Application.Current.MainPage = new NavigationPage(new CollegeDashboardPage());
                    return;
                }
                else
                {
                    AppPreferences.IsProfileCompleted = false;
                    AppPreferences.IsVideosUploaded = false;
                    AppPreferences.IsEducationCompleted = false;
                    AppPreferences.IsCollege = false;
                    if (result.ProfileWeightage == null || (result.ProfileWeightage.PersonalDetails == null && result.ProfileWeightage.EducationalDetails == null && result.ProfileWeightage.Video == null && result.ProfileWeightage.ProfilePicture == null))
                    {
                        UserDialogs.Instance.HideLoading();
                        Application.Current.MainPage = new NavigationPage(new SeekerInstructionPage());
                        return;
                    }
                    else
                    {
                        if (result.ProfileWeightage.PersonalDetails == null)
                        {
                            AppPreferences.IsProfileCompleted = false;
                            AppPreferences.IsVideosUploaded = false;
                            AppPreferences.IsEducationCompleted = false;
                            AppPreferences.IsFirstRun = false;
                            AppPreferences.IsDashboard = false;
                            UserDialogs.Instance.HideLoading();
                            Application.Current.MainPage = new NavigationPage(new SeekerPersonalAndEducationPage(false));
                            return;
                        }
                        else if (result.ProfileWeightage.EducationalDetails == null)
                        {
                            AppPreferences.IsEducationCompleted = false;
                            AppPreferences.IsProfileCompleted = true;
                            AppPreferences.IsVideosUploaded = false;
                            AppPreferences.IsFirstRun = false;
                            AppPreferences.IsDashboard = false;
                            UserDialogs.Instance.HideLoading();
                            Application.Current.MainPage = new NavigationPage(new SeekerPersonalAndEducationPage(true));
                            return;
                            // Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                        }
                        else if (result.ProfileWeightage.Video == null)
                        {
                            AppPreferences.IsEducationCompleted = true;
                            AppPreferences.IsProfileCompleted = true;
                            AppPreferences.IsVideosUploaded = false;
                            AppPreferences.IsFirstRun = false;
                            AppPreferences.IsDashboard = true;
                            UserDialogs.Instance.HideLoading();
                            //Application.Current.MainPage = new NavigationPage(new VideoProfilePage(true));
                            Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                            return;
                        }
                        else
                        {
                            AppPreferences.IsEducationCompleted = true;
                            AppPreferences.IsVideosUploaded = true;
                            AppPreferences.IsProfileCompleted = true;
                            AppPreferences.IsDashboard = true;
                            AppPreferences.IsFirstRun = false;
                            UserDialogs.Instance.HideLoading();
                            Application.Current.MainPage = new DashBoardMaster(AppSessionData.ActiveToken.UserType);
                            return;
                        }
                    }
                }
                    #endregion
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "CommonLoginResponse.NavigateToNextPage");
            }        
    }

        #region BindProfilePic

        private void BindProfilePic(string s3_id)
        {
            try
            {
                if (!string.IsNullOrEmpty(s3_id))
                {

                    var Imagedownloader = new S3ImageDownloder();
                    Imagedownloader.DownloadProfilePicture(s3_id);

                }
                else
                {
                    AppPreferences.ProfilePicture = (string)Application.Current.Resources["IconUser"];
                }
                //ProfileImage = AppPreferences.ProfilePicture;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                UserDialogs.Instance.HideLoading();
                SendErrorMessageToServer(ex, "LoginPageViewModel.BindProfilePic");
            }
        }


        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion






        //private string _profileImage;
        //public string ProfileImage
        //{
        //    get { return _profileImage; }
        //    set
        //    {
        //        _profileImage = value;
        //        OnPropertyChanged();

        //    }
        //}

        #endregion
    }
}
