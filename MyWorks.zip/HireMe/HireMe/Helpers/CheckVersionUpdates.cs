﻿using System;
using HireMe.Helpers;
using HireMe.Models;
using Xamarin.Forms;
using Acr.UserDialogs;

namespace HireMe
{
    public class CheckVersionUpdates
    {
        public CheckVersionUpdates() { }

        #region CheckVersion
        public async void CheckVersion(Appversioncheck apiVersionCheck)
        {
            try
            {
                if (apiVersionCheck != null)
                {
                    if (Device.RuntimePlatform == Device.Android)
                    {
                       
                        var installedAndroidVersionCode = new Version(DependencyService.Get<IPackageInfo>().VersionName);
                        var LatestVersionCode = new Version(apiVersionCheck.android_VersionName.ToString());
                        // Convert.ToDouble(apiVersionCheck.android_VersionCode);
                        //android mean check with version code
                        if (installedAndroidVersionCode < LatestVersionCode)
                        {
                            AppPreferences.OldVersion = true;
                            String message = MessageStringConstants.UpdateLatestVersion + " " +apiVersionCheck.android_VersionName;
                            await UserDialogs.Instance.AlertAsync(message );
                            DependencyService.Get<IMyDevice>().OpnePlayStore();
                        }
                        AppPreferences.OldVersion = false;
                    }
                    else if (Device.RuntimePlatform == Device.iOS)
                    {
                        var installedIOSVersionName = new Version(DependencyService.Get<IPackageInfo>().VersionName);
                        var LatestIOSName = new Version(apiVersionCheck.ioS_VersionName.ToString());
                        //if iOS mean check with version name
                        if (installedIOSVersionName < LatestIOSName)
                        {
                            AppPreferences.OldVersion = true;
                            String message = MessageStringConstants.UpdateLatestVersion;
                            await UserDialogs.Instance.AlertAsync(message);
                            DependencyService.Get<IMyDevice>().OpnePlayStore();
                        }
                        AppPreferences.OldVersion = false;
                    }
                }
            }
            catch (Exception ex)
            {
                UserDialogs.Instance.HideLoading();
                System.Diagnostics.Debug.WriteLine(ex.Message);
                SendErrorMessageToServer(ex, "CheckVersionUpdates.CheckVersion");
            }
        }
        #endregion

        #region SendErrorMessageToServer
        public void SendErrorMessageToServer(Exception ex, String ClassNameAndFunctionName)
        {
            CommonException _commonexception = new CommonException();
            _commonexception.CallCommonException(ex, ClassNameAndFunctionName);
        }
        #endregion
    }
}
