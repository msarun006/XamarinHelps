﻿namespace HireMe.Renderers
{
    public enum CameraOptions
    {
        Rear,
        Front
    }
}
