﻿namespace HireMe
{
    public class CustomEditor : Xamarin.Forms.Editor
    {


    }
}
