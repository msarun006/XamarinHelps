﻿namespace HireMe
{
    public class CircleButtonRenderer : Xamarin.Forms.Label
    {




    }
}
