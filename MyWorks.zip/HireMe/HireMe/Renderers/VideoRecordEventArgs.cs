﻿using System;

namespace HireMe
{
    public class VideoRecordEventArgs : EventArgs
    {
        public string RecordedVideoFilePath { get; set; }
        public string OTPValue { get; set; }

    }
}