﻿namespace HireMe
{
    public class CustomProgressBar : Xamarin.Forms.ProgressBar
    {
        public CustomProgressBar()
        {
        }
    }
}
