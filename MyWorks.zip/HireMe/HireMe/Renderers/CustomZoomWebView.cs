﻿using Xamarin.Forms;

namespace HireMe
{
    public class CustomZoomWebView : WebView
    {
        public int ZoomInLevel
        {
            get { return (int)GetValue(ZoomInLevelProperty); }
            set { SetValue(ZoomInLevelProperty, value); }
        }
        public static readonly BindableProperty ZoomInLevelProperty = BindableProperty.Create
            (
            propertyName: "ZoomInLevel",
            returnType: typeof(int),
            declaringType: typeof(WebView),
            defaultValue: 16,
            propertyChanged: onZoomInLevelPropertyChanged
            );

        private static void onZoomInLevelPropertyChanged(BindableObject bindable, object oldValue, object newValue)
        {



        }
    }
}
