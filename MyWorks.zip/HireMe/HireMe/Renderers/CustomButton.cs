﻿namespace HireMe
{
    public  class CustomButton :Xamarin.Forms.Button
    {


    }
}
