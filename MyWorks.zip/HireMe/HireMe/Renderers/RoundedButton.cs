﻿
using Xamarin.Forms;
namespace HireMe
{
    public class RoundedButton : Button
    {
    }
}
