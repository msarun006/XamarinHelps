﻿using Xamarin.Forms;

namespace HireMe
{
    public class CustomWebView : WebView
	{
		public static readonly BindableProperty UriProperty = BindableProperty.Create(propertyName: "Uri",
			returnType: typeof(string),
			declaringType: typeof(CustomWebView),
			defaultValue: default(string));

		public static readonly BindableProperty IsHtmlContentPropery = BindableProperty.Create(propertyName: "IsHtmlContent",
																							   returnType: typeof(bool),
			declaringType: typeof(CustomWebView),
																							   defaultValue: default(bool));

		public string Uri
		{
			get { return (string)GetValue(UriProperty); }
			set { SetValue(UriProperty, value); }
		}

		public bool IsHtmlContent
		{
			get { return (bool)GetValue(IsHtmlContentPropery); }
			set { SetValue(IsHtmlContentPropery, value); }
		}
	}
}
