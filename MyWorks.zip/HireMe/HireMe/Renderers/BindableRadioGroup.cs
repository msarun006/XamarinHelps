﻿using System;
using System.Collections;
using System.Collections.ObjectModel;
using Xamarin.Forms;

namespace HireMe
{
    public class BindableRadioGroup : StackLayout
    {
        public static readonly BindableProperty FontNameProperty;
        public static readonly BindableProperty FontSizeProperty;
        public static BindableProperty ItemsSourceProperty;
        public static BindableProperty SelectedIndexProperty;
        public static readonly BindableProperty TextColorProperty;
        public ObservableCollection<CustomRadioButton> Items;

        public BindableRadioGroup() { }

        public string FontName { get; set; }
        public double FontSize { get; set; }
        public IEnumerable ItemsSource { get; set; }
        public int SelectedIndex { get; set; }
        public Color TextColor { get; set; }

#pragma warning disable CS0067 // The event 'BindableRadioGroup.CheckedChanged' is never used
        public event EventHandler<int> CheckedChanged;
#pragma warning restore CS0067 // The event 'BindableRadioGroup.CheckedChanged' is never used
    }
}
