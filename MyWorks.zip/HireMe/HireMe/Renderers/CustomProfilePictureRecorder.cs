﻿
using Xamarin.Forms;
namespace HireMe
{
    public class CustomProfilePictureRecorder : ContentPage
    {

        public delegate void CancelVideoRecordDelegate(VideoRecordEventArgs eventargs);
        public event CancelVideoRecordDelegate VideoRecordCancelled;
        public event CancelVideoRecordDelegate VideoRecordCompleted;
        public event CancelVideoRecordDelegate GetOTPValue;
        public CustomProfilePictureRecorder()
        {
            NavigationPage.SetHasNavigationBar(this, false);
        }



        public void SetVieoResults(VideoRecordEventArgs eventargs)
        {
            VideoRecordCompleted?.Invoke(eventargs);
            //Navigation.PopAsync();

        }
        public void SetCancelResults(VideoRecordEventArgs eventargs)
        {
            VideoRecordCancelled?.Invoke(eventargs);
        }



        protected override bool OnBackButtonPressed()
        {
            return true;
        }

        public void GetOTP(VideoRecordEventArgs eventargs)
        {
            GetOTPValue?.Invoke(eventargs);
        }


    }
}
