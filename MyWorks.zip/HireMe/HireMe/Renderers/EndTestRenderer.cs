﻿namespace HireMe
{
    public class EndTestRenderer : Xamarin.Forms.Label
    {




    }
}
