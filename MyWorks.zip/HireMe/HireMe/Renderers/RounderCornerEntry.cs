﻿using Xamarin.Forms;

namespace HireMe
{
    public class RounderCornerEntry :Entry 
    {
    }
}
