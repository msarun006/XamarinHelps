﻿using Xamarin.Forms;

namespace HireMe
{
    public class AssessmentCustomWebView :WebView
    {
    }
}
