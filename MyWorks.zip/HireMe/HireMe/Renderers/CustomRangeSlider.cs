﻿using Xamarin.Forms;

namespace HireMe.Renderers
{
    class CustomRangeSlider :View
    {

    }
}
