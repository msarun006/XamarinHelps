﻿namespace HireMe
{
    public class TimerBackground : Xamarin.Forms.Label
    {




    }
}
