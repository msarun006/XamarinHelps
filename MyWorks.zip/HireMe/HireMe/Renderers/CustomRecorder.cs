﻿using System;
using Xamarin.Forms;

namespace HireMe
{
    public class CustomRecorder : ContentPage
    {

        public delegate void CancelVideoRecordDelegate(VideoRecordEventArgs eventargs);
        public event CancelVideoRecordDelegate VideoRecordCancelled;
        public event CancelVideoRecordDelegate VideoRecordCompleted;


        public CustomRecorder()
        {
            NavigationPage.SetHasNavigationBar(this, false);
        }

        public static readonly BindableProperty FileSourceProperty =
#pragma warning disable CS0618 // 'BindableProperty.Create<TDeclarer, TPropertyType>(Expression<Func<TDeclarer, TPropertyType>>, TPropertyType, BindingMode, BindableProperty.ValidateValueDelegate<TPropertyType>, BindableProperty.BindingPropertyChangedDelegate<TPropertyType>, BindableProperty.BindingPropertyChangingDelegate<TPropertyType>, BindableProperty.CoerceValueDelegate<TPropertyType>, BindableProperty.CreateDefaultValueDelegate<TDeclarer, TPropertyType>)' is obsolete: 'Generic versions of Create () are no longer supported and deprecated. They will be removed soon.'
           BindableProperty.Create<CustomRecorder, string>(
               p => p.FileSource, string.Empty);
#pragma warning restore CS0618 // 'BindableProperty.Create<TDeclarer, TPropertyType>(Expression<Func<TDeclarer, TPropertyType>>, TPropertyType, BindingMode, BindableProperty.ValidateValueDelegate<TPropertyType>, BindableProperty.BindingPropertyChangedDelegate<TPropertyType>, BindableProperty.BindingPropertyChangingDelegate<TPropertyType>, BindableProperty.CoerceValueDelegate<TPropertyType>, BindableProperty.CreateDefaultValueDelegate<TDeclarer, TPropertyType>)' is obsolete: 'Generic versions of Create () are no longer supported and deprecated. They will be removed soon.'

        public static readonly BindableProperty FramesPerSecondProperty =
#pragma warning disable CS0618 // 'BindableProperty.Create<TDeclarer, TPropertyType>(Expression<Func<TDeclarer, TPropertyType>>, TPropertyType, BindingMode, BindableProperty.ValidateValueDelegate<TPropertyType>, BindableProperty.BindingPropertyChangedDelegate<TPropertyType>, BindableProperty.BindingPropertyChangingDelegate<TPropertyType>, BindableProperty.CoerceValueDelegate<TPropertyType>, BindableProperty.CreateDefaultValueDelegate<TDeclarer, TPropertyType>)' is obsolete: 'Generic versions of Create () are no longer supported and deprecated. They will be removed soon.'
          BindableProperty.Create<CustomRecorder, Int32>(
              p => p.FramesPerSecond, 24);
#pragma warning restore CS0618 // 'BindableProperty.Create<TDeclarer, TPropertyType>(Expression<Func<TDeclarer, TPropertyType>>, TPropertyType, BindingMode, BindableProperty.ValidateValueDelegate<TPropertyType>, BindableProperty.BindingPropertyChangedDelegate<TPropertyType>, BindableProperty.BindingPropertyChangingDelegate<TPropertyType>, BindableProperty.CoerceValueDelegate<TPropertyType>, BindableProperty.CreateDefaultValueDelegate<TDeclarer, TPropertyType>)' is obsolete: 'Generic versions of Create () are no longer supported and deprecated. They will be removed soon.'

        public static readonly BindableProperty MaxDurationSecondsProperty =
#pragma warning disable CS0618 // 'BindableProperty.Create<TDeclarer, TPropertyType>(Expression<Func<TDeclarer, TPropertyType>>, TPropertyType, BindingMode, BindableProperty.ValidateValueDelegate<TPropertyType>, BindableProperty.BindingPropertyChangedDelegate<TPropertyType>, BindableProperty.BindingPropertyChangingDelegate<TPropertyType>, BindableProperty.CoerceValueDelegate<TPropertyType>, BindableProperty.CreateDefaultValueDelegate<TDeclarer, TPropertyType>)' is obsolete: 'Generic versions of Create () are no longer supported and deprecated. They will be removed soon.'
          BindableProperty.Create<CustomRecorder, Int32>(
              p => p.MaxDurationSeconds, default(int));
#pragma warning restore CS0618 // 'BindableProperty.Create<TDeclarer, TPropertyType>(Expression<Func<TDeclarer, TPropertyType>>, TPropertyType, BindingMode, BindableProperty.ValidateValueDelegate<TPropertyType>, BindableProperty.BindingPropertyChangedDelegate<TPropertyType>, BindableProperty.BindingPropertyChangingDelegate<TPropertyType>, BindableProperty.CoerceValueDelegate<TPropertyType>, BindableProperty.CreateDefaultValueDelegate<TDeclarer, TPropertyType>)' is obsolete: 'Generic versions of Create () are no longer supported and deprecated. They will be removed soon.'

        public string FileSource
        {
            get { return (string)GetValue(FileSourceProperty); }
            set { SetValue(FileSourceProperty, value); }
        }

        public int MaxDurationSeconds
        {
            get { return (int)GetValue(MaxDurationSecondsProperty); }
            set { SetValue(MaxDurationSecondsProperty, value); }
        }

        public Int32 FramesPerSecond
        {
            get { return (int)GetValue(FramesPerSecondProperty); }
            set { SetValue(FramesPerSecondProperty, value); }
        }


        public void SetVieoResults(VideoRecordEventArgs eventargs)
        {
            VideoRecordCompleted?.Invoke(eventargs);
            //Navigation.PopAsync();
            
        }
        public void SetCancelResults(VideoRecordEventArgs eventargs)
        {
            VideoRecordCancelled?.Invoke(eventargs);
        }



        protected override bool OnBackButtonPressed()
        {
            return true;
        }

    }
}
