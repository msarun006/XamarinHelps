﻿using Xamarin.Forms;

namespace HireMe
{
    public class SearchFrame : ContentView
    {

        public readonly static BindableProperty BorderRadiusProperty = BindableProperty.Create("BorderRadius", typeof(int), typeof(SearchFrame), 5, BindingMode.OneWay, null, null, null, null, null);

        public readonly static BindableProperty OutlineColorProperty = BindableProperty.Create("OutlineColor", typeof(Color), typeof(SearchFrame), Color.Default, BindingMode.OneWay, null, null, null, null, null);

        public readonly static BindableProperty BorderWidthProperty = BindableProperty.Create("BorderWidth", typeof(int), typeof(SearchFrame), 2, BindingMode.OneWay, null, null, null, null, null);

        public int BorderWidth
        {
            get
            {
                return (int)base.GetValue(SearchFrame.BorderWidthProperty);
            }
            set
            {
                base.SetValue(SearchFrame.BorderWidthProperty, value);
            }
        }

        public Color OutlineColor
        {
            get
            {
                return (Color)base.GetValue(SearchFrame.OutlineColorProperty);
            }
            set
            {
                base.SetValue(SearchFrame.OutlineColorProperty, value);
            }
        }

        public int BorderRadius
        {
            get
            {
                return (int)base.GetValue(SearchFrame.BorderRadiusProperty);
            }
            set
            {
                base.SetValue(SearchFrame.BorderRadiusProperty, value);
            }
        }

        public SearchFrame()
        {
            base.Padding = new Size(20, 20);
        }
    }
}
