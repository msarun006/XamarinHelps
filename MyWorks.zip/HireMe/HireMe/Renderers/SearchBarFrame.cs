﻿using Xamarin.Forms;

namespace HireMe
{

    public class SearchBarFrame : ContentView
{

	public readonly static BindableProperty BorderRadiusProperty = BindableProperty.Create("BorderRadius", typeof(int), typeof(SearchBarFrame), 5, BindingMode.OneWay, null, null, null, null, null);

	public readonly static BindableProperty OutlineColorProperty = BindableProperty.Create("OutlineColor", typeof(Color), typeof(SearchBarFrame), Color.Default, BindingMode.OneWay, null, null, null, null, null);

	public readonly static BindableProperty BorderWidthProperty = BindableProperty.Create("BorderWidth", typeof(int), typeof(SearchBarFrame), 2, BindingMode.OneWay, null, null, null, null, null);

	public int BorderWidth
	{
		get
		{
			return (int)base.GetValue(SearchBarFrame.BorderWidthProperty);
		}
		set
		{
			base.SetValue(SearchBarFrame.BorderWidthProperty, value);
		}
	}

	public Color OutlineColor
	{
		get
		{
			return (Color)base.GetValue(SearchBarFrame.OutlineColorProperty);
		}
		set
		{
			base.SetValue(SearchBarFrame.OutlineColorProperty, value);
		}
	}

	public int BorderRadius
	{
		get
		{
			return (int)base.GetValue(SearchBarFrame.BorderRadiusProperty);
		}
		set
		{
			base.SetValue(SearchBarFrame.BorderRadiusProperty, value);
		}
	}

public SearchBarFrame()
	{
		base.Padding = new Size(20, 20);
	}
    }
}
