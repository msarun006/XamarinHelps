﻿using System;

using Xamarin.Forms;

namespace HireMe
{
    public class CustomAllViewCellRenderer : ViewCell
    {


    }
}

