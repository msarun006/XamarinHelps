﻿
using Android.App;
using Android.Content;
using Firebase.Messaging;
using Android.Media;
using Android.Support.V4.App;
using Android.OS;
using Android.Graphics;
using System;

namespace HireMe.Droid
{
    [Service]
    [IntentFilter(new[] { "com.google.firebase.MESSAGING_EVENT" })]


    public class HireMeeFirebaseMessagingService : FirebaseMessagingService
    {
        private static readonly int ButtonClickNotification = 9999;
        public const string URGENT_CHANNEL = "com.mobility.hiremeeapp";
        const string TAG = "HireMeeFCMService";
        public override void OnMessageReceived(RemoteMessage message)
        {
            // TODO(developer): Handle FCM messages here.
            // If the application is in the foreground handle both data and notification messages here.
            // Also if you intend on generating your own notifications as a result of a received FCM
            // message, here is where that should be initiated. See sendNotification method below.
            Android.Util.Log.Debug(TAG, "From: " + message.From);
            Android.Util.Log.Debug(TAG, "Notification Message Body: " + message.GetNotification().Body);
            string[] args = message.GetNotification().GetBodyLocalizationArgs();
            SendNotification(message.GetNotification().Body, message.GetNotification().Title);
        }
        // [END receive_message]

        /**
         * Create and show a simple notification containing the received FCM message.
         */
        void SendNotification(string messageBody, string Title)
        {


            try
            {
                // Bitmap largeIcon = BitmapFactory.DecodeResource(Resources, Resource.Drawable.icon);

                Bundle valuesForActivity = new Bundle();
                valuesForActivity.PutString("Type", "Notification");

                // When the user clicks the notification, SecondActivity will start up.
                Intent intent = new Intent(this, typeof(MainActivity));
                // Pass some values to SecondActivity:
                intent.PutExtras(valuesForActivity);
                intent.AddFlags(ActivityFlags.ClearTop);
                var pendingIntent = PendingIntent.GetActivity(this, 0 /* Request code */, intent, PendingIntentFlags.OneShot);

                var defaultSoundUri = RingtoneManager.GetDefaultUri(RingtoneType.Notification);
                var notificationBuilder = new NotificationCompat.Builder(this)
                    .SetSmallIcon(getNotificationIcon())
                  .SetColor(Color.Gray)
                    .SetContentTitle(Title)
                    .SetContentText(messageBody)
                    .SetAutoCancel(true)
                    .SetSound(defaultSoundUri)
                    .SetContentIntent(pendingIntent);



                if (Build.VERSION.SdkInt >= Build.VERSION_CODES.O)
                {
                    var name = "HireMee";
                    var description = GetString(Resource.String.default_notification_channel_id);//"Default Notification News Channel";
                    var importance = Android.App.NotificationImportance.Default;
                    NotificationChannel channel = new NotificationChannel(URGENT_CHANNEL, name, importance);
                    channel.Description = description;
                    NotificationManager manager = (NotificationManager)GetSystemService(NotificationService);
                    manager.CreateNotificationChannel(channel);
                    Notification.Builder builder = new Notification.Builder(this)
                    .SetSmallIcon(getNotificationIcon())
                    .SetColor(Color.Gray)
                    .SetContentTitle(Title)
                    .SetContentText(messageBody)
                    .SetContentIntent(pendingIntent)
                    .SetChannelId(URGENT_CHANNEL);
                    NotificationManager notificationManager = (NotificationManager)GetSystemService(NotificationService);
                    manager.Notify(ButtonClickNotification, builder.Build());
                }
                else
                {
                    var notificationManager = NotificationManager.FromContext(this);
                    notificationManager.Notify(0 /* ID of notification */, notificationBuilder.Build());
                }


            }
            catch (Exception e)
            {

            }
        }


        private int getNotificationIcon()
        {
            bool useWhiteIcon = (Android.OS.Build.VERSION.SdkInt >= Build.VERSION_CODES.Lollipop);
            //      return useWhiteIcon ? Resource.Drawable.hiremee_logo_transparent : Resource.Drawable.icon;
            return useWhiteIcon ? Resource.Drawable.ic_stat_transparent : Resource.Drawable.icon;
        }


    }
}