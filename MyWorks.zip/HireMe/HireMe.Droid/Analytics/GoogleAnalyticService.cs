﻿using Android.Content;
using Android.Gms.Analytics;
using Xamarin.Forms;

[assembly: Dependency(typeof(HireMe.Droid.GoogleAnalyticService))]
namespace HireMe.Droid
{
    public class GoogleAnalyticService : IAnalyticService
	{
		//replace with your tracking id https://analytics.google.com/
		public string TrackingId = "UA-96468473-1";

	private static GoogleAnalytics GAInstance;
		private static Tracker GATracker;

		#region Instantiation ...
		private static GoogleAnalyticService thisRef;
		public GoogleAnalyticService()
		{
		}
		public static GoogleAnalyticService GetGASInstance()
		{
			if (thisRef == null)
				// it's ok, we can call this constructor
				thisRef = new GoogleAnalyticService();
			return thisRef;
		}
		#endregion

		public void Initialize_NativeGAS(Context AppContext = null)
		{
            GAInstance = GoogleAnalytics.GetInstance(AppContext.ApplicationContext);
            GAInstance.SetLocalDispatchPeriod(10);
            GATracker = GAInstance.NewTracker(TrackingId);
            GATracker.EnableExceptionReporting(true);
            GATracker.EnableAdvertisingIdCollection(true);
            GATracker.EnableAutoActivityTracking(true);
        }

		public void Track_App_Event(string GAEventCategory, string EventToTrack)
		{
            HitBuilders.EventBuilder builder = new HitBuilders.EventBuilder();
            builder.SetCategory(GAEventCategory);
            builder.SetAction(EventToTrack);
            builder.SetLabel("AppEvent");
            GATracker.Send(builder.Build());
        }

		public void Track_App_Exception(string ExceptionMessageToTrack, bool isFatalException)
		{
            HitBuilders.ExceptionBuilder builder = new HitBuilders.ExceptionBuilder();
            builder.SetDescription(ExceptionMessageToTrack);
            builder.SetFatal(isFatalException);
            GATracker.Send(builder.Build());
        }

		public void Track_App_Page(string PageNameToTrack)
		{
            GATracker.SetScreenName(PageNameToTrack);
            GATracker.Send(new HitBuilders.ScreenViewBuilder().Build());
        }


	}
}
